[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1692544676/collection-of-vintage-botanical-prints?content_source=080a78d6-b865-4b40-b8a2-57ffa518edab%253ALT58fa33eb8796477727750a4efd23c2b2f263eefc&frs=1&ga_order=most_relevant&ga_search_query=vintage+botanical+prints+set&ga_search_type=all&ga_view_type=gallery&ls=s&pro=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?content_source=080a78d6-b865-4b40-b8a2-57ffa518edab%253ALT58fa33eb8796477727750a4efd23c2b2f263eefc&frs=1&ga_order=most_relevant&ga_search_query=vintage+botanical+prints+set&ga_search_type=all&ga_view_type=gallery&ls=s&pro=1&explicit=1&ref=catnav_breadcrumb-0)
- [Prints](https://www.etsy.com/c/art-and-collectibles/prints?content_source=080a78d6-b865-4b40-b8a2-57ffa518edab%253ALT58fa33eb8796477727750a4efd23c2b2f263eefc&frs=1&ga_order=most_relevant&ga_search_query=vintage+botanical+prints+set&ga_search_type=all&ga_view_type=gallery&ls=s&pro=1&explicit=1&ref=catnav_breadcrumb-1)
- [Giclée](https://www.etsy.com/c/art-and-collectibles/prints/giclee?content_source=080a78d6-b865-4b40-b8a2-57ffa518edab%253ALT58fa33eb8796477727750a4efd23c2b2f263eefc&frs=1&ga_order=most_relevant&ga_search_query=vintage+botanical+prints+set&ga_search_type=all&ga_view_type=gallery&ls=s&pro=1&explicit=1&ref=catnav_breadcrumb-2)

[Back to search results](https://www.etsy.com/search?content_source=080a78d6-b865-4b40-b8a2-57ffa518edab%253ALT58fa33eb8796477727750a4efd23c2b2f263eefc&frs=1&ga_order=most_relevant&ga_search_query=vintage+botanical+prints+set&ga_search_type=all&ga_view_type=gallery&ls=s&pro=1&explicit=1&q=vintage+botanical+prints+set&ref=return_to_search)


Add to Favorites


- ![May include: A green sofa with a white pillow and a long white pillow with a gold trim. The wall behind the sofa is covered in a light green wallpaper with eight framed botanical prints of various flowers.](https://i.etsystatic.com/7608365/r/il/776862/5993914583/il_794xN.5993914583_k84o.jpg)
- ![Collection of Vintage Botanical Prints, Set of 12 Antique Botanical Prints, Rustic Botanical Wall Art, Floral Art Prints, Watercolor Floral image 2](https://i.etsystatic.com/7608365/r/il/9c4578/6761048094/il_794xN.6761048094_d7rh.jpg)
- ![May include: A watercolor painting of a pink flower with green leaves and stem on a white background.](https://i.etsystatic.com/7608365/r/il/3932ef/5993906803/il_794xN.5993906803_2nai.jpg)
- ![May include: Nine framed botanical prints with illustrations of various flowers in shades of pink, yellow, blue, and orange. The frames are gold with a white mat and a green background. The text at the top of the image reads 'BUY MORE SAVE MORE: 35% OFF 3+ | 45% OFF 6+ | 60% OFF 9+'. The text at the bottom of the image reads 'VOLUME ONE'.](https://i.etsystatic.com/7608365/r/il/7302aa/6103446189/il_794xN.6103446189_3p6i.jpg)
- ![May include: Nine framed botanical illustrations of flowers in various colors, including pink, yellow, blue, and orange. The frames are gold and the background is a light green. The text at the top of the image reads 'BUY MORE SAVE MORE: 35% OFF 3+ | 45% OFF 6+ | 60% OFF 9+'. The text at the bottom of the image reads 'VOLUME TWO'.](https://i.etsystatic.com/7608365/r/il/65dc99/6055384112/il_794xN.6055384112_llm1.jpg)
- ![May include: Three gold picture frames with a light green mat and a white background. The frames are displayed on a light green textured background. The frames are different sizes and have different details. The frames are labeled with the text 'Frames starting at $25', 'Frames starting at $50', and 'Frames starting at $65'. The frames are all showcasing a watercolor painting of a blue flower.](https://i.etsystatic.com/7608365/r/il/3d4064/6010565246/il_794xN.6010565246_l5ed.jpg)
- ![a set of six framed pictures of wildflowers](https://i.etsystatic.com/7608365/r/il/8c2a5d/6103446489/il_794xN.6103446489_3zyu.jpg)
- ![a set of six framed flowers on a wall](https://i.etsystatic.com/7608365/r/il/861083/6103446605/il_794xN.6103446605_g3ly.jpg)
- ![a set of six framed flower prints on a wall](https://i.etsystatic.com/7608365/r/il/6ee035/6055384502/il_794xN.6055384502_fdpx.jpg)
- ![a set of six framed pictures of wildflowers](https://i.etsystatic.com/7608365/r/il/8fa803/6055384634/il_794xN.6055384634_3jvn.jpg)

- ![May include: A green sofa with a white pillow and a long white pillow with a gold trim. The wall behind the sofa is covered in a light green wallpaper with eight framed botanical prints of various flowers.](https://i.etsystatic.com/7608365/c/1496/1188/174/493/il/776862/5993914583/il_75x75.5993914583_k84o.jpg)
- ![Collection of Vintage Botanical Prints, Set of 12 Antique Botanical Prints, Rustic Botanical Wall Art, Floral Art Prints, Watercolor Floral image 2](https://i.etsystatic.com/7608365/r/il/9c4578/6761048094/il_75x75.6761048094_d7rh.jpg)
- ![May include: A watercolor painting of a pink flower with green leaves and stem on a white background.](https://i.etsystatic.com/7608365/r/il/3932ef/5993906803/il_75x75.5993906803_2nai.jpg)
- ![May include: Nine framed botanical prints with illustrations of various flowers in shades of pink, yellow, blue, and orange. The frames are gold with a white mat and a green background. The text at the top of the image reads 'BUY MORE SAVE MORE: 35% OFF 3+ | 45% OFF 6+ | 60% OFF 9+'. The text at the bottom of the image reads 'VOLUME ONE'.](https://i.etsystatic.com/7608365/r/il/7302aa/6103446189/il_75x75.6103446189_3p6i.jpg)
- ![May include: Nine framed botanical illustrations of flowers in various colors, including pink, yellow, blue, and orange. The frames are gold and the background is a light green. The text at the top of the image reads 'BUY MORE SAVE MORE: 35% OFF 3+ | 45% OFF 6+ | 60% OFF 9+'. The text at the bottom of the image reads 'VOLUME TWO'.](https://i.etsystatic.com/7608365/r/il/65dc99/6055384112/il_75x75.6055384112_llm1.jpg)
- ![May include: Three gold picture frames with a light green mat and a white background. The frames are displayed on a light green textured background. The frames are different sizes and have different details. The frames are labeled with the text 'Frames starting at $25', 'Frames starting at $50', and 'Frames starting at $65'. The frames are all showcasing a watercolor painting of a blue flower.](https://i.etsystatic.com/7608365/r/il/3d4064/6010565246/il_75x75.6010565246_l5ed.jpg)
- ![a set of six framed pictures of wildflowers](https://i.etsystatic.com/7608365/r/il/8c2a5d/6103446489/il_75x75.6103446489_3zyu.jpg)
- ![a set of six framed flowers on a wall](https://i.etsystatic.com/7608365/r/il/861083/6103446605/il_75x75.6103446605_g3ly.jpg)
- ![a set of six framed flower prints on a wall](https://i.etsystatic.com/7608365/r/il/6ee035/6055384502/il_75x75.6055384502_fdpx.jpg)
- ![a set of six framed pictures of wildflowers](https://i.etsystatic.com/7608365/r/il/8fa803/6055384634/il_75x75.6055384634_3jvn.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1692544676%2Fcollection-of-vintage-botanical-prints%23report-overlay-trigger)

In 17 carts

NowPrice:$26.25+


Original Price:
$35.00+


Loading


**New markdown!**

25% off


•

Sale ends in 18:49:32

# Collection of Vintage Botanical Prints, Set of 12 Antique Botanical Prints, Rustic Botanical Wall Art, Floral Art Prints, Watercolor Floral

[shopemblemart](https://www.etsy.com/shop/shopemblemart?ref=shop-header-name&listing_id=1692544676&from_page=listing)

[5 out of 5 stars](https://www.etsy.com/listing/1692544676/collection-of-vintage-botanical-prints?content_source=080a78d6-b865-4b40-b8a2-57ffa518edab%253ALT58fa33eb8796477727750a4efd23c2b2f263eefc&frs=1&ga_order=most_relevant&ga_search_query=vintage+botanical+prints+set&ga_search_type=all&ga_view_type=gallery&ls=s&pro=1#reviews)

Arrives soon! Get it by

Nov 14-24


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Exchanges accepted

Size + Framing Options - (overall size)


Select an option

5" x 7" - Artwork Only ($26.25 - $204.75)

8" x 10" - Artwork Only ($30.00 - $234.00)

8" x 10" - Art with Mat (Art is 5x7) ($41.25 - $321.75)

11" x 14" - Artwork Only ($37.50 - $292.50)

11" x 14" - Art with Mat (Art is 8x10) ($52.50 - $409.50)

16" x 20" - Artwork Only ($45.00 - $351.00)

16" x 20" - Art with Mat (Art is 11x14) ($63.75 - $497.25)

Please select an option


Artwork Selection


Select an option

Single Print - Your Choice - specify in personalization ($26.25 - $63.75)

Set of 3 - Your Choice - (15% less per piece) - specify in personalization ($66.75 - $162.75)

Set of 3 - \*Curated\* - (15% less per piece) ($66.75 - $162.75)

Set of 4 - Your Choice - (15% less per piece) - specify in personalization ($89.25 - $216.75)

Set of 4 - "Curated" - (15% less per piece) ($89.25 - $216.75)

Set of 6 - Your Choice - (25% less per piece) - specify in personalization ($118.50 - $287.25)

Set of 6 - \*Curated\* - (25% less per piece) ($118.50 - $287.25)

Set of 9 - Your Choice- (35% less per piece) - specify in personalization ($153.75 - $372.75)

Set of 9 - \*Curated\* - (35% less per piece) ($153.75 - $372.75)

Full Set of 12 - (35% less per piece) ($204.75 - $497.25)

Please select an option


Add personalization


- Personalization





Please let me know which prints you would like.

.

⚜️ Thank you so much!


















0/256


4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Made by [shopemblemart](https://www.etsy.com/shop/shopemblemart)

- Materials: artist grade watercolor paper, archival inks



- Width: 11 inches

Height: 14 inches

➢ Frames shown in listing:

[https://shopemblemart.etsy.com/listing/1720961435](https://shopemblemart.etsy.com/listing/1720961435/1-antique-pale-gold-picture-frame-real)

➢ Mat package shown in listing: [https://shopemblemart.etsy.com/listing/1699934024/11x14-premium-double-mats-for-8-x-10](https://shopemblemart.etsy.com/listing/1699934024/11x14-premium-double-mats-for-8-x-10)

Explore our collection of 12 vintage watercolor botanical paintings that capture the delicate grace of wildflowers. Each piece is a careful reproduction of classic botanical art, meticulously printed on premium Italian artist-grade watercolor paper. The archival inks used in our ultra high-fidelity, high-resolution printing process ensure every subtle hue and line is faithfully rendered for an authentic vintage feel.

These timeless fine art reproductions are printed on imported Italian artist-grade watercolor paper, selected for its superior quality and durability. Utilizing archival inks and ultra high-fidelity, high-resolution printing technology, each illustration bursts with crisp detail and rich, lasting color, clarity and depth.

• • • • • • • • • • • • • • • • • • • •

Size + Framing Options

• • • • • • • • • • • • • • • • • • • •

\*please note: dimensions represent overall size

➢ Artwork Only

Great for DIY. Versatile option to match any style.

Available sizes: 5x7, 8x10, 11x14, 12x16, 16x20 (measured overall)

➢ Artwork with Mats

Pair our recommended mat selection with your frames

Available sizes: 11x14 (measured overall) - suitable for 11x14 frame

\*more sizes coming soon

• • • • • • • • • • • • • • • • • • • •

Buy More, Save More

• • • • • • • • • • • • • • • • • • • •

Set of 3+ : 35% Off

Set of 6+ : 45% Off

Set of 9+ : 60% Off

Discount in addition to promotional sale! Priced as listed.

➢ Mix + Match!

Purchase a set from any listing and specify the collection + artwork you'd like from another listing in the personalization section.

• • • • • • • • • • • • • • • • • • • •

Fine Art Printing

• • • • • • • • • • • • • • • • • • • •

Artist-grade cold-pressed watercolor paper

Archival Inks

Ultra high-fidelity, high resolution printing technology

• • • • • • • • • • • • • • • • • • • •

Recommended For

• • • • • • • • • • • • • • • • • • • •

➢ Spaces:

Dining Room

Living Room

Kitchen

Office

Entryway

Hallway

Foyer

Guest Room

➢ Perfect Gift For:

Mother

Mother-in-Law

Mother’s Day Gift

Sister

Sister-in-Law

Wife

Daughter

Teacher

➢ Decor Style:

Classic

Traditional

Transitional

New Traditional

These wildflower prints are more than just wall art—they are a symphony of color and texture that bring the serene beauty of nature into your home. Ideal for a gallery wall, these botanical watercolors will imbue any room with a sense of peace and natural wonder.

Whether you're looking to enrich your living room, bedroom, or office with floral art, or searching for a thoughtful gift for a nature lover, our collection is a perfect choice. Embrace the charm of wildflowers and elevate your interior with our timeless art prints. Shop now and transform your space with the spirit of the outdoors.

• • • • • • • • • • • • • • • • • • • •

The Fine Print

• • • • • • • • • • • • • • • • • • • •

The previews are grouped in pairs due to a restriction Etsy places on the number of photos per listing; photos are not indicative of quantity you're purchasing. If you have any questions, please contact me. Bundle pricing (i.e. "extra 25% off) applies to artwork only; not applicable to mats or frames)

I do not offer personalization of graphics. Personalization section is restricted to confirmation of prints you intend to purchase.

Please note that this item is a final sale. I do not accept returns or offer refunds. Please read the listing description before purchasing. If you're unable to understand the product or nature of the sale, please contact me prior to purchase. All files are copyrighted by Emblematic Creative. Products are for personal use only and must not be re-sold or redistributed. Do not use this item commercially without the explicit approval of Emblematic Creative.

Visit my shop for more

[https://www.etsy.com/shop/emblematiccreative](https://www.etsy.com/shop/emblematiccreative)

## Shipping and return policies

Loading


- Order today to get by

**Nov 14-24**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 14 days


- Free shipping


- Ships from: **Jackson, MS**


Deliver to United States

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (10)

5.0/5

item average

5.0Item quality

5.0Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Beautiful

Well packaged

Great quality

As described

Fast shipping

Stunning

Love it


Filter by category


Quality (7)


Appearance (5)


Shipping & Packaging (3)


Description accuracy (2)


Seller service (1)


Value (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Lindsay Ware](https://www.etsy.com/people/lindsayparker1991?ref=l_review)
Oct 16, 2025


Package was shipped really well. Everything came as expected.



[Lindsay Ware](https://www.etsy.com/people/lindsayparker1991?ref=l_review)
Oct 16, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/34c465/34107546/iusa_75x75.34107546_tezt.jpg?version=0)

[Lindsay](https://www.etsy.com/people/drrsgirl?ref=l_review)
Sep 6, 2025


I received a matted set of 12 absolutely gorgeous prints. No complaints! Stunning quality paper, printing and mat quality. Quick, well packaged shipment. Can't wait to hang them. Thank you so much!



![](https://i.etsystatic.com/iusa/34c465/34107546/iusa_75x75.34107546_tezt.jpg?version=0)

[Lindsay](https://www.etsy.com/people/drrsgirl?ref=l_review)
Sep 6, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/ef700f/104565920/iusa_75x75.104565920_goab.jpg?version=0)

[Melissa](https://www.etsy.com/people/lknwjody?ref=l_review)
Jul 15, 2025


Love, love, love my order!! Beautiful, better than expected, and high quality!



![](https://i.etsystatic.com/iusa/ef700f/104565920/iusa_75x75.104565920_goab.jpg?version=0)

[Melissa](https://www.etsy.com/people/lknwjody?ref=l_review)
Jul 15, 2025


5 out of 5 stars
5

This item

[Sign in with Apple user](https://www.etsy.com/people/sn9ogwb6215rylf2?ref=l_review)
May 28, 2025


Beautiful prints highly recommend these



[Sign in with Apple user](https://www.etsy.com/people/sn9ogwb6215rylf2?ref=l_review)
May 28, 2025


View all reviews for this item

[![shopemblemart](https://i.etsystatic.com/iusa/91424f/96021198/iusa_75x75.96021198_1drs.jpg?version=0)](https://www.etsy.com/shop/shopemblemart?ref=shop_profile&listing_id=1692544676)

[shopemblemart](https://www.etsy.com/shop/shopemblemart?ref=shop_profile&listing_id=1692544676)

[Owned by Claire](https://www.etsy.com/shop/shopemblemart?ref=shop_profile&listing_id=1692544676) \|

Mississippi, United States

4.9
(3.3k)


19.4k sales

12 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=28225225&referring_id=1692544676&referring_type=listing&recipient_id=28225225&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyODIyNTIyNToxNzYyNzczNjI1OjdiZGViNTQ0YmYzNmNjYTkzNzBjNzg2NGM2NTdhYWM2&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1692544676%2Fcollection-of-vintage-botanical-prints%3Fcontent_source%3D080a78d6-b865-4b40-b8a2-57ffa518edab%25253ALT58fa33eb8796477727750a4efd23c2b2f263eefc%26frs%3D1%26ga_order%3Dmost_relevant%26ga_search_query%3Dvintage%2Bbotanical%2Bprints%2Bset%26ga_search_type%3Dall%26ga_view_type%3Dgallery%26ls%3Ds%26pro%3D1)

This seller usually responds **within a few hours.**

Rave reviewsAverage review rating is 4.8 or higher.

Loading recommendations

Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 4, 2025


[670 favorites](https://www.etsy.com/listing/1692544676/collection-of-vintage-botanical-prints/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?content_source=080a78d6-b865-4b40-b8a2-57ffa518edab%253ALT58fa33eb8796477727750a4efd23c2b2f263eefc&frs=1&ga_order=most_relevant&ga_search_query=vintage+botanical+prints+set&ga_search_type=all&ga_view_type=gallery&ls=s&pro=1&explicit=1&ref=breadcrumb_listing) [Prints](https://www.etsy.com/c/art-and-collectibles/prints?content_source=080a78d6-b865-4b40-b8a2-57ffa518edab%253ALT58fa33eb8796477727750a4efd23c2b2f263eefc&frs=1&ga_order=most_relevant&ga_search_query=vintage+botanical+prints+set&ga_search_type=all&ga_view_type=gallery&ls=s&pro=1&explicit=1&ref=breadcrumb_listing) [Giclée](https://www.etsy.com/c/art-and-collectibles/prints/giclee?content_source=080a78d6-b865-4b40-b8a2-57ffa518edab%253ALT58fa33eb8796477727750a4efd23c2b2f263eefc&frs=1&ga_order=most_relevant&ga_search_query=vintage+botanical+prints+set&ga_search_type=all&ga_view_type=gallery&ls=s&pro=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Paper

[Wedding Content Creator Pricing Guide Template](https://www.etsy.com/listing/1556005171/wedding-content-creator-pricing-guide)

Handbags

[Buy Coach Vintage Strap Online](https://www.etsy.com/market/coach_vintage_strap)

Home Decor

[Antique Swedish silver and wood pipe head made in 1862 Sweden Scandinavian mancave decor Victorian gift for him 1800s 19 century Collectible](https://www.etsy.com/listing/655750231/antique-swedish-silver-and-wood-pipe) [Mermaid Wall Decals - Sea Ocean - Dolphin Decal - Nautical Vinyl Sticker - Animal - Bathroom - Nursery - Home Decor - Art Water Nature Ms699 - Home Decor](https://www.etsy.com/listing/253025162/mermaid-wall-decals-sea-ocean-dolphin) [Witch Hand With Red Rose Sphere Holder](https://www.etsy.com/listing/1789293415/witch-hand-with-red-rose-sphere-holder)

Rings

[4 Claw Prong Solitaire Oval Cut Ring](https://www.etsy.com/listing/4301888385/3ct-oval-cut-moissanite-engagement-ring) [Exotic Wooden Ring for Sale](https://www.etsy.com/market/exotic_wooden_ring)

Prints

[Decisive Pink Geometric Shapes Abstract Painting By Wassily Kandinsky Repro - Prints](https://www.etsy.com/listing/1240759797/decisive-pink-geometric-shapes-abstract) [PRINTABLE / INSTANT DOWNLOAD Pdf - Prints](https://www.etsy.com/listing/1333438264/vitamin-foods-reference-chart-printable) [Art Packard Custom 8 wood Framed print with Glass - Prints](https://www.etsy.com/listing/1904776235/art-packard-custom-8-wood-framed-print) [000 Savings / Savings Tracker / Budgeting / 5K Savings Plan / Digital / BTS Savings Plan / BTS / BTS Printable by ElizabethsSpace](https://www.etsy.com/listing/1615295870/bts-2025-comeback-savings-5000-savings) [Framed and Canvas Print - Prints](https://www.etsy.com/listing/780767261/exhibition-poster-japanese-art-japan-art) [Steal Here Poster](https://www.etsy.com/listing/4338054517/bob-marley-poster-print-steal-here) [IPhone 15 Pro Max X-Ray Internal Structure iPhone Wallpaper - Prints](https://www.etsy.com/listing/1768963274/iphone-15-pro-max-x-ray-internal) [Buy Vintage Surf Magazine Framed Online](https://www.etsy.com/market/vintage_surf_magazine_framed)

Gender Neutral Kids Clothing

[Party Animal Birthday Sweatshirt by RyLexDesign](https://www.etsy.com/listing/1077513764/party-animal-funny-crewneck-fleece)

Shopping

[Parchment Baking Paper for Sale](https://www.etsy.com/market/parchment_baking_paper)

Painting

[Capybara Oil Painting Animal Original Art Pet Portrait Impasto Artwork Rodents Wall Art Decor Personalized Gifts by ArtSenya by ArtSenya](https://www.etsy.com/listing/1672902555/capybara-oil-painting-animal-original)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1692544676%2Fcollection-of-vintage-botanical-prints%3Fcontent_source%3D080a78d6-b865-4b40-b8a2-57ffa518edab%25253ALT58fa33eb8796477727750a4efd23c2b2f263eefc%26frs%3D1%26ga_order%3Dmost_relevant%26ga_search_query%3Dvintage%2Bbotanical%2Bprints%2Bset%26ga_search_type%3Dall%26ga_view_type%3Dgallery%26ls%3Ds%26pro%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc3MzYyNTo3M2JhZjA5MjBjZjJjYzRmNmNlMTE3ZTY1NzBjMDgyYQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1692544676%2Fcollection-of-vintage-botanical-prints%3Fcontent_source%3D080a78d6-b865-4b40-b8a2-57ffa518edab%25253ALT58fa33eb8796477727750a4efd23c2b2f263eefc%26frs%3D1%26ga_order%3Dmost_relevant%26ga_search_query%3Dvintage%2Bbotanical%2Bprints%2Bset%26ga_search_type%3Dall%26ga_view_type%3Dgallery%26ls%3Ds%26pro%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1692544676/collection-of-vintage-botanical-prints?content_source=080a78d6-b865-4b40-b8a2-57ffa518edab%253ALT58fa33eb8796477727750a4efd23c2b2f263eefc&frs=1&ga_order=most_relevant&ga_search_query=vintage+botanical+prints+set&ga_search_type=all&ga_view_type=gallery&ls=s&pro=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1692544676%2Fcollection-of-vintage-botanical-prints%3Fcontent_source%3D080a78d6-b865-4b40-b8a2-57ffa518edab%25253ALT58fa33eb8796477727750a4efd23c2b2f263eefc%26frs%3D1%26ga_order%3Dmost_relevant%26ga_search_query%3Dvintage%2Bbotanical%2Bprints%2Bset%26ga_search_type%3Dall%26ga_view_type%3Dgallery%26ls%3Ds%26pro%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for shopemblemart

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: not accepted

Please contact the seller if you have any problems with your order.

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## Seller details

### Business registration number

### Location

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=28225225&referring_id=7608365&referring_type=shop&recipient_id=28225225&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: A green sofa with a white pillow and a long white pillow with a gold trim. The wall behind the sofa is covered in a light green wallpaper with eight framed botanical prints of various flowers.](https://i.etsystatic.com/7608365/c/1496/1496/174/339/il/776862/5993914583/il_300x300.5993914583_k84o.jpg)
- ![Collection of Vintage Botanical Prints, Set of 12 Antique Botanical Prints, Rustic Botanical Wall Art, Floral Art Prints, Watercolor Floral image 2](https://i.etsystatic.com/7608365/r/il/9c4578/6761048094/il_300x300.6761048094_d7rh.jpg)
- ![May include: A watercolor painting of a pink flower with green leaves and stem on a white background.](https://i.etsystatic.com/7608365/r/il/3932ef/5993906803/il_300x300.5993906803_2nai.jpg)
- ![May include: Nine framed botanical prints with illustrations of various flowers in shades of pink, yellow, blue, and orange. The frames are gold with a white mat and a green background. The text at the top of the image reads 'BUY MORE SAVE MORE: 35% OFF 3+ | 45% OFF 6+ | 60% OFF 9+'. The text at the bottom of the image reads 'VOLUME ONE'.](https://i.etsystatic.com/7608365/r/il/7302aa/6103446189/il_300x300.6103446189_3p6i.jpg)
- ![May include: Nine framed botanical illustrations of flowers in various colors, including pink, yellow, blue, and orange. The frames are gold and the background is a light green. The text at the top of the image reads 'BUY MORE SAVE MORE: 35% OFF 3+ | 45% OFF 6+ | 60% OFF 9+'. The text at the bottom of the image reads 'VOLUME TWO'.](https://i.etsystatic.com/7608365/r/il/65dc99/6055384112/il_300x300.6055384112_llm1.jpg)
- ![May include: Three gold picture frames with a light green mat and a white background. The frames are displayed on a light green textured background. The frames are different sizes and have different details. The frames are labeled with the text 'Frames starting at $25', 'Frames starting at $50', and 'Frames starting at $65'. The frames are all showcasing a watercolor painting of a blue flower.](https://i.etsystatic.com/7608365/r/il/3d4064/6010565246/il_300x300.6010565246_l5ed.jpg)
- ![a set of six framed pictures of wildflowers](https://i.etsystatic.com/7608365/r/il/8c2a5d/6103446489/il_300x300.6103446489_3zyu.jpg)
- ![a set of six framed flowers on a wall](https://i.etsystatic.com/7608365/r/il/861083/6103446605/il_300x300.6103446605_g3ly.jpg)
- ![a set of six framed flower prints on a wall](https://i.etsystatic.com/7608365/r/il/6ee035/6055384502/il_300x300.6055384502_fdpx.jpg)
- ![a set of six framed pictures of wildflowers](https://i.etsystatic.com/7608365/r/il/8fa803/6055384634/il_300x300.6055384634_3jvn.jpg)