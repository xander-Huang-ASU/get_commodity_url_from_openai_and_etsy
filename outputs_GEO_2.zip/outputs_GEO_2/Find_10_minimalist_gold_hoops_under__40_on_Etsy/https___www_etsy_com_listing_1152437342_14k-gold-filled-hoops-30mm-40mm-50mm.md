[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1152437342/14k-gold-filled-hoops-30mm-40mm-50mm#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Jewelry](https://www.etsy.com/c/jewelry?explicit=1&ref=catnav_breadcrumb-0)
- [Earrings](https://www.etsy.com/c/jewelry/earrings?explicit=1&ref=catnav_breadcrumb-1)
- [Hoop Earrings](https://www.etsy.com/c/jewelry/earrings/hoop-earrings?explicit=1&ref=catnav_breadcrumb-2)

Bestseller

This item has had a high sales volume over the past 6 months.



Add to Favorites


- ![May include: Four gold hoop earrings of different sizes, hanging from a dried palm leaf.](https://i.etsystatic.com/7566366/r/il/2142a0/3668149623/il_794xN.3668149623_tsdh.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![May include: Four gold hoop earrings of varying sizes](https://i.etsystatic.com/7566366/r/il/e43d09/3620528482/il_794xN.3620528482_q6zo.jpg)
- ![May include: Three gold hoop earrings of different sizes hanging from a beige surface.](https://i.etsystatic.com/7566366/r/il/65f91d/3620528478/il_794xN.3620528478_iup6.jpg)

- ![May include: Four gold hoop earrings of different sizes, hanging from a dried palm leaf.](https://i.etsystatic.com/7566366/c/533/423/0/164/il/2142a0/3668149623/il_75x75.3668149623_tsdh.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/IMG_3496_jedmdz.jpg)

- ![May include: Four gold hoop earrings of varying sizes](https://i.etsystatic.com/7566366/r/il/e43d09/3620528482/il_75x75.3620528482_q6zo.jpg)
- ![May include: Three gold hoop earrings of different sizes hanging from a beige surface.](https://i.etsystatic.com/7566366/r/il/65f91d/3620528478/il_75x75.3620528478_iup6.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1152437342%2F14k-gold-filled-hoops-30mm-40mm-50mm%23report-overlay-trigger)

In 20+ carts

NowPrice:$29.40+


Original Price:
$42.00+


Loading


**New markdown!**

30% off


•

Sale ends in 18:34:38

# 14K gold filled hoops, 30mm, 40mm, 50mm, Light weight hoops, Large hoop Earrings, Endless Hoops, Thin hoops, Minimalist, Everyday jewelry

Designed by [Designbydd](https://www.etsy.com/shop/Designbydd)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1152437342/14k-gold-filled-hoops-30mm-40mm-50mm#reviews)

Arrives soon! Get it by

Nov 14-24


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

Hoop Size


Select an option

30mm ($29.40)

40mm ($30.80)

50mm ($32.20)

Please select an option


4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Designed by [Designbydd](https://www.etsy.com/shop/Designbydd)

- Materials: 14kt gold filled

- Made to Order


These gorgeous minimalist hoops are light and comfortable to wear daily.

These hoops are 14K gold-filled to American standard, they will not tarnish.

They are shower friendly!

-Details

2 pieces - 1 pair

14K Gold Filled

50mm, 40mm, 30mm

Thickness: 1.25mm

shiny gold

-Questions

Remember photos can make pieces look larger or smaller in photos, please see the description for exact details. All of our jewelry comes ready for gift giving.

If you are wanting more pieces than available, send me a quick email and I will update the listing for you

-Production Information

Each design is handcrafted to order, shipping is 3-7 days for production, this does not include the shipping time for delivery.

First class in the US is usually 3-5 business days and international is 10-15 business days.

Faster shipping & production times are available at checkout.

➳What is gold filled

Gold filled jewelry is beautiful long lasting material, it is very durable and will not chip or turn colors. With proper care it can last many years. It is also safe for those with metal allergies.

www.designbydd.com - my new website

Follow me ➳ ➳

Instagram @ddlydig

Facebook https://www.facebook.com/designbydd

All Photos, Designs and Text Copyright © designbydd

Thank you for your support & for supporting a small business! :)


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-24**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 14 days


- Ships from: **Buckley, WA**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## FAQs

PRODUCTION/SHIPPING & TRANSIT TIMES - within the US


During this time USPS is very slow, and even slower for international purchases.

I have no control over this so please use your tracking number & find updated shipping information via www.USPS.com

2-4 business days ... non-personalized pieces\*

3-7 business days ... personalized necklaces & bracelets

2-3 business days ... orders with expedited shipping

\*In stock items, approximate business days before your order\* ships

PRODUCTION / SHIPPING TRANSIT TIMES - within the US

USPS - Standard Shipping:

• 3-6 business days shipping transit time

USPS - Priority:

• 2-4 business days shipping transit time

USPS - Express:

• 1-2 business days shipping transit time

• Guaranteed delivery

You select the shipping method you want when you check out.


RUSH ORDERS


If you need your order rushed, please make sure to select an expedited form of shipping. Also, please note the date you need it by (in the "notes to seller" section) so we can work to make it happen, or contact you if it’s cutting it too close and discuss options.


ALL RETURNS...


♥♥ Our Policy on Return & Exchanges:

\- We offer returns and exchanges, contact us within 3 days and return to us within 7 days of the delivery of your order.

\- Certain products are non-returnable; such as made-to-order/ custom necklaces and also earrings due to hygienic reasons.

\- Buyer is generally responsible for the return shipping cost and the original shipping cost of $4.75 will

Please contact us with any questions.


EXCHANGES


INCORRECT LENGTH / SIZE:

Let's get you something that fits. If you send it back to us, we'll adjust it for you here in the studio. Send us a note first to set it up.

You will be responsible for the postage to mail the exchange back to you.


INTERNATIONAL ORDERS


We ship worldwide.

With Covid transit times are impacted and are taking up to 30days

TRANSIT TIMES:

Typical transit times are 7-14 days, but occasionally packages can be substantially delayed if held up at customs, We don't have any control over your country's customs officials, so please understand the risk of delay. This isn't common, but it happens occasionally.

CUSTOMS / DUTY CHARGES:

We have no control over your country's customs officials. Some countries will charge duty for international packages and others will not, and all at different rates! Most packages go through without any charges, it is somewhat random, but please be advised that we have no control over how your country charges duty. These are NOT extra shipping charges.


When will my order ship


1-3 business days ... non-personalized pieces\*

3-7 business days ... personalized necklaces & bracelets

2-3 business days ... orders with expedited shipping

\*In stock items, approximate business days before your order\* ships

–––

PRODUCTION / SHIPPING TRANSIT TIMES - within the US

USPS - Standard Shipping:

• 3-5 business days shipping transit time

USPS - Priority:

• 2-3 business days shipping transit time

USPS - Express:

• 1-2 business days shipping transit time

• Guaranteed delivery

You select the shipping method you want when you check out.


CONTACT


Etsy handles all payment transactions.

We do not see your billing information as it is secured with Etsy. For billing changes please check the Etsy FAQ: https://www.etsy.com/help/article/1939?

We accept Paypal, Credit Cards, and Etsy gift cards.

Sales tax is added to your purchase, if required by your state.

For Paypal E-Check payments: your order will not ship until the check has cleared (approximately 5 business days)


Is There Any Nickel in Any of Our Jewelry?


There is NO NICKEL in any of our jewelry. We are committed to selling top quality products and are mindful of our materials and their sources.


Free Shipping Promotions & All Returns


During our free shipping promotions, any item returned will be charged the cost of the postage and handling. All returns will be charged the cost of the postage and handling shop paid to mail the jewelry to you. If you have any questions please let us know.


Jewelry Photos - Jewelry can look larger or smaller in photos... please read our detailed description of each piece. If you have questions please send us a quick email.


Remember photos can make pieces look larger or smaller in photos, please read the description for exact details of all of the pieces. If you have any questions please send us a quick email.


## Meet your seller

![DeeDee](https://i.etsystatic.com/7566366/r/isla/ef9a3e/49103396/isla_75x75.49103396_86nsn0wr.jpg)

DeeDee

Owner of [Designbydd](https://www.etsy.com/shop/Designbydd?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyNzE0ODMzNToxNzYyNzgxNzExOmFiMTBlNmI0MjQ4M2U3MTg2NTJjMWQzOTZhYzYxNzQ4&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1152437342%2F14k-gold-filled-hoops-30mm-40mm-50mm)

[Message DeeDee](https://www.etsy.com/messages/new?with_id=27148335&referring_id=1152437342&referring_type=listing&recipient_id=27148335&from_action=contact-seller)

This seller usually responds **within a few hours.**

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (41)

5.0/5

item average

4.9Item quality

4.7Shipping

4.7Customer service

95%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Love it

Beautiful

Lightweight

Exactly what I wanted

Perfect size

Great quality

Fast shipping


Filter by category


Appearance (13)


Comfort (11)


Description accuracy (7)


Quality (6)


Sizing & Fit (5)


Ease of use (4)


Shipping & Packaging (3)


Value (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Stella Lew](https://www.etsy.com/people/5a0dcsf8?ref=l_review)
Nov 9, 2025


I LOVE these hoops! So lightweight and comfortable. 40mm is such a great size.



[Stella Lew](https://www.etsy.com/people/5a0dcsf8?ref=l_review)
Nov 9, 2025


5 out of 5 stars
5

This item

[tgasti](https://www.etsy.com/people/tgasti?ref=l_review)
Nov 6, 2025


Love these hoops! Needed a new pair and these are beautiful. Perfect size, comfortable and already my favorite.



[tgasti](https://www.etsy.com/people/tgasti?ref=l_review)
Nov 6, 2025


![](https://i.etsystatic.com/iusa/6c6945/29096771/iusa_75x75.29096771_3koh.jpg?version=0)

Response from DeeDee

Thank you!



5 out of 5 stars
5

This item

[Natalie](https://www.etsy.com/people/cud0jp49causuu5g?ref=l_review)
Nov 1, 2025


Very lightweight, cute, and well made. Love for everyday wear.



[Natalie](https://www.etsy.com/people/cud0jp49causuu5g?ref=l_review)
Nov 1, 2025


![](https://i.etsystatic.com/iusa/6c6945/29096771/iusa_75x75.29096771_3koh.jpg?version=0)

Response from DeeDee

Thank you!



5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/924491/101445871/iusa_75x75.101445871_kme0.jpg?version=0)

[Alexandrea Reeser](https://www.etsy.com/people/alexandreamchl2?ref=l_review)
Oct 27, 2025


So cute and perfect for that subtle hoop look!



![](https://i.etsystatic.com/iusa/924491/101445871/iusa_75x75.101445871_kme0.jpg?version=0)

[Alexandrea Reeser](https://www.etsy.com/people/alexandreamchl2?ref=l_review)
Oct 27, 2025


![](https://i.etsystatic.com/iusa/6c6945/29096771/iusa_75x75.29096771_3koh.jpg?version=0)

Response from DeeDee

Thank you so much for your kind review. :)



View all reviews for this item

[![Designbydd](https://i.etsystatic.com/iusa/6c6945/29096771/iusa_75x75.29096771_3koh.jpg?version=0)](https://www.etsy.com/shop/Designbydd?ref=shop_profile&listing_id=1152437342)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[Designbydd](https://www.etsy.com/shop/Designbydd?ref=shop_profile&listing_id=1152437342)

[Owned by DeeDee](https://www.etsy.com/shop/Designbydd?ref=shop_profile&listing_id=1152437342) \|

Buckley, Washington

4.8
(10.1k)


53.7k sales

12 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=27148335&referring_id=1152437342&referring_type=listing&recipient_id=27148335&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyNzE0ODMzNToxNzYyNzgxNzExOmFiMTBlNmI0MjQ4M2U3MTg2NTJjMWQzOTZhYzYxNzQ4&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1152437342%2F14k-gold-filled-hoops-30mm-40mm-50mm)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/Designbydd?ref=lp_mys_mfts)

- [![14K gold filled hoops, 30mm, 40mm, 50mm, Light weight, Large hoop Earrings, Endless Hoops, Thin hoops, Minimalist, Birthday gift, Gift idea](https://i.etsystatic.com/7566366/c/469/469/85/65/il/83196d/6924005064/il_340x270.6924005064_q6zo.jpg)\\
\\
**14K gold filled hoops, 30mm, 40mm, 50mm, Light weight, Large hoop Earrings, Endless Hoops, Thin hoops, Minimalist, Birthday gift, Gift idea**\\
\\
Sale Price $29.40\\
$29.40\\
\\
$42.00\\
Original Price $42.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4317466350/14k-gold-filled-hoops-30mm-40mm-50mm?click_key=cc68dcb234b8fc28962777fae54cdc95%3ALTa7836f389aa3ae3525295d5ca1b21efff37c9dfe&click_sum=241e7e84&ls=r&ref=related-1&pro=1&sts=1&content_source=cc68dcb234b8fc28962777fae54cdc95%253ALTa7836f389aa3ae3525295d5ca1b21efff37c9dfe "14K gold filled hoops, 30mm, 40mm, 50mm, Light weight, Large hoop Earrings, Endless Hoops, Thin hoops, Minimalist, Birthday gift, Gift idea")




Add to Favorites


- [![14K gold filled hoops, sterling silver hoops, 30mm, 40mm, 50mm, Light weight hoops, Endless Hoops, Thin hoops, Minimalist, Everyday jewelry](https://i.etsystatic.com/7566366/c/619/619/139/204/il/f69c62/6934609628/il_340x270.6934609628_77kd.jpg)\\
\\
**14K gold filled hoops, sterling silver hoops, 30mm, 40mm, 50mm, Light weight hoops, Endless Hoops, Thin hoops, Minimalist, Everyday jewelry**\\
\\
Sale Price $28.00\\
$28.00\\
\\
$40.00\\
Original Price $40.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4311565968/14k-gold-filled-hoops-sterling-silver?click_key=cc68dcb234b8fc28962777fae54cdc95%3ALT0c88a91e34178eb7e0ffca061bf15b3ae93246d5&click_sum=0de7247c&ls=r&ref=related-2&pro=1&sts=1&content_source=cc68dcb234b8fc28962777fae54cdc95%253ALT0c88a91e34178eb7e0ffca061bf15b3ae93246d5 "14K gold filled hoops, sterling silver hoops, 30mm, 40mm, 50mm, Light weight hoops, Endless Hoops, Thin hoops, Minimalist, Everyday jewelry")




Add to Favorites


- [![14kt Gold Filled Hoop earrings w/Greek coin, Coin Hoop Earrings, Hoops, Everyday Earrings, Large Hoop Earrings, 30mm, 40mm 0r 50mm hoop size](https://i.etsystatic.com/7566366/c/2362/1877/232/222/il/37b7fd/6013316689/il_340x270.6013316689_am9n.jpg)\\
\\
**14kt Gold Filled Hoop earrings w/Greek coin, Coin Hoop Earrings, Hoops, Everyday Earrings, Large Hoop Earrings, 30mm, 40mm 0r 50mm hoop size**\\
\\
Sale Price $33.60\\
$33.60\\
\\
$48.00\\
Original Price $48.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1725468105/14kt-gold-filled-hoop-earrings-wgreek?click_key=cc68dcb234b8fc28962777fae54cdc95%3ALT43d05db0b2a38ea6b6dd82aa6c8875a7b12826df&click_sum=ab0b89fa&ls=r&ref=related-3&pro=1&sts=1&content_source=cc68dcb234b8fc28962777fae54cdc95%253ALT43d05db0b2a38ea6b6dd82aa6c8875a7b12826df "14kt Gold Filled Hoop earrings w/Greek coin, Coin Hoop Earrings, Hoops, Everyday Earrings, Large Hoop Earrings, 30mm, 40mm 0r 50mm hoop size")




Add to Favorites


- [![Saint Francis of Assisi Medal Necklace, Animal Lover, Artisan Greek Coin Necklace, Bohemian Jewelry, Gold Medallion, Layering Necklace](https://i.etsystatic.com/7566366/c/505/402/34/151/il/2452f8/2459810031/il_340x270.2459810031_9pe3.jpg)\\
\\
**Saint Francis of Assisi Medal Necklace, Animal Lover, Artisan Greek Coin Necklace, Bohemian Jewelry, Gold Medallion, Layering Necklace**\\
\\
Sale Price $33.60\\
$33.60\\
\\
$48.00\\
Original Price $48.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/824940434/saint-francis-of-assisi-medal-necklace?click_key=079dda2efb0b3937cf15b03df5339f7a05357f35%3A824940434&click_sum=231637fc&ref=related-4&pro=1&sts=1 "Saint Francis of Assisi Medal Necklace, Animal Lover, Artisan Greek Coin Necklace, Bohemian Jewelry, Gold Medallion, Layering Necklace")




Add to Favorites



Loading...

Loading


**Disclaimer:** Button/coin batteries may cause serious injury and even death if swallowed. Items containing button/coin batteries should not be easily accessible without the use of a tool. Sellers are responsible for complying with all applicable labeling, design, testing, packaging, and other safety requirements. Etsy assumes no responsibility for the accuracy or contents of a seller’s listing. If you have questions about button/coin batteries, contact the seller by sending a Message. See Etsy's [Terms of Use](https://www.etsy.com/legal/terms-of-use/?ref=product_safety_banner_info_button_batteries_risk#warranties) for more information.

Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 10, 2025


[654 favorites](https://www.etsy.com/listing/1152437342/14k-gold-filled-hoops-30mm-40mm-50mm/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Jewelry](https://www.etsy.com/c/jewelry?explicit=1&ref=breadcrumb_listing) [Earrings](https://www.etsy.com/c/jewelry/earrings?explicit=1&ref=breadcrumb_listing) [Hoop Earrings](https://www.etsy.com/c/jewelry/earrings/hoop-earrings?explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Shopping

[Buy Nike Iron On Vinyl Online](https://www.etsy.com/market/nike_iron_on_vinyl) [Pico Planter - US](https://www.etsy.com/market/pico_planter)

Patches & Pins

[World Refugee Day Pin](https://www.etsy.com/listing/1471590622/world-refugee-day-pin)

Photography

[Antique Cabinet Card / United States Dept of Treasury Washinton DC / J.F.Jarvis Publisher / Sepia Color / Was 14.50 Now 7.25)](https://www.etsy.com/listing/653218416/antique-cabinet-card-united-states-dept)

Earrings

[Tiffanys Blue Earrings - US](https://www.etsy.com/market/tiffanys_blue_earrings) [Star Shaped Beaded Dangle Earrings - Handmade Jewelry - Gift For Her - Christmas Present - Bohemian Earrings - Beaded Earrings - Seed Beads](https://www.etsy.com/listing/1768733899/star-shaped-beaded-dangle-earrings) [Deep Green Jade](https://www.etsy.com/listing/1298815775/natural-jade-ring-hoop-earrings-and) [2-in-1 hoop earrings](https://www.etsy.com/listing/1862777128/gold-filled-or-sterling-silver)

Painting

[Black & White Minimalist Wall Art Large Black 3D Texture Painting on Canvas Contemporary Abstract Minimalist Painting Modern Art Framed by Getcanvaswallart](https://www.etsy.com/listing/1508913202/black-white-minimalist-wall-art-large)

Paper

[EDITABLE Five is A Vibe Daisy Groovy Birthday Invitation](https://www.etsy.com/listing/1851096506/five-is-a-vibe-birthday-invitation)

Kitchen & Dining

[Shop Suck Up To Boss](https://www.etsy.com/market/suck_up_to_boss)

Artist Trading Cards

[Buy Firstkhaotung Photocard Online](https://www.etsy.com/market/firstkhaotung_photocard)

Gender Neutral Adult Clothing

[You make the Whole Class Shimmer Gildan short sleeve tee Teacher Shirt](https://www.etsy.com/listing/1050064155/you-make-the-whole-class-shimmer-gildan)

Party Supplies

[Animal Polymer Clay Sprinkle (NOT EDIBLE) D26-03/04](https://www.etsy.com/listing/1823916034/fake-5mm10mm-cow-spot-animal-polymer)

Rings

[Shop Simply Meant To Be Wedding Rings](https://www.etsy.com/market/simply_meant_to_be_wedding_rings)

Furniture

[Vintage cardboard wood storage drawers Quilted cardboard wood dresser BakeLite Handle 4 Drawer CardBoard & Wood dresser Henry A Enrich Co - Furniture](https://www.etsy.com/listing/1554490298/vintage-cardboard-wood-storage-drawers)

Spa & Relaxation

[Buy Made In Virginia Gift Baskets Online](https://www.etsy.com/market/made_in_virginia_gift_baskets)

Bedding

[Buy Pontiac Blanket Online](https://www.etsy.com/market/pontiac_blanket)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1152437342%2F14k-gold-filled-hoops-30mm-40mm-50mm&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc4MTcxMTo2NGQ0NzI5OTk1OTMxMWQzY2Q1NWZmODhlOTMzOGI2MA==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1152437342%2F14k-gold-filled-hoops-30mm-40mm-50mm) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1152437342/14k-gold-filled-hoops-30mm-40mm-50mm#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1152437342%2F14k-gold-filled-hoops-30mm-40mm-50mm)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

On


Saved

Done

## Shop policies for Designbydd

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 12 hours of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## Seller details

### Other details

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=27148335&referring_id=7566366&referring_type=shop&recipient_id=27148335&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![May include: Four gold hoop earrings of different sizes, hanging from a dried palm leaf.](https://i.etsystatic.com/7566366/c/533/533/0/107/il/2142a0/3668149623/il_300x300.3668149623_tsdh.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/IMG_3496_jedmdz.jpg)

- ![May include: Four gold hoop earrings of varying sizes](https://i.etsystatic.com/7566366/r/il/e43d09/3620528482/il_300x300.3620528482_q6zo.jpg)
- ![May include: Three gold hoop earrings of different sizes hanging from a beige surface.](https://i.etsystatic.com/7566366/r/il/65f91d/3620528478/il_300x300.3620528478_iup6.jpg)