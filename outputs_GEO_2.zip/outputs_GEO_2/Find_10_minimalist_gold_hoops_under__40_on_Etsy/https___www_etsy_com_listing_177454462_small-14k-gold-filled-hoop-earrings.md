[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Jewelry](https://www.etsy.com/c/jewelry?explicit=1&ref=catnav_breadcrumb-0)
- [Earrings](https://www.etsy.com/c/jewelry/earrings?explicit=1&ref=catnav_breadcrumb-1)
- [Hoop Earrings](https://www.etsy.com/c/jewelry/earrings/hoop-earrings?explicit=1&ref=catnav_breadcrumb-2)


Add to Favorites


- ![May include: Three pairs of 14k yellow gold fill hoop earrings in different sizes. The text '14k Yellow Gold Fill Hoops' is at the top of the image. The text 'Choose your size' is at the bottom of the image.](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_794xN.2974995587_mfo3.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![May include: Three gold hoop earrings in different sizes, 10mm, 10mm, and 12mm. The earrings are shown on a person's ear. The text 'Small Hoop Earrings 22 gauge' is below the earrings.](https://i.etsystatic.com/5438927/r/il/8059b5/3856336788/il_794xN.3856336788_4w9f.jpg)
- ![May include: Three silver hoop earrings in different sizes, 8mm, 10mm, and 12mm, are shown in a person's earlobe.](https://i.etsystatic.com/5438927/r/il/72a038/3856336830/il_794xN.3856336830_6cgu.jpg)
- ![May include: A close-up of a person's ear with a small gold hoop earring in the lobe. The text below the ear reads: '24 gauge 8mm diameter Please note: this size will NOT fit on large or thick earlobes. Try 10 or 12mm diameter instead.'](https://i.etsystatic.com/5438927/r/il/890278/3903836063/il_794xN.3903836063_1xx4.jpg)
- ![May include: A close-up of a person's ear with a small gold hoop earring. The text below the ear reads '24 gauge 10mm diameter'.](https://i.etsystatic.com/5438927/r/il/97a906/3903836079/il_794xN.3903836079_or4v.jpg)
- ![May include: A close-up of a person's ear with a small, thin, gold hoop earring. The text below the ear reads '22 gauge 10mm diameter'.](https://i.etsystatic.com/5438927/r/il/6250e9/3856336948/il_794xN.3856336948_pso5.jpg)
- ![May include: A close-up of a person's ear with a small, thin, gold hoop earring. The earring is 12mm in diameter and 24 gauge. The text '24 gauge 12mm diameter' is visible below the ear.](https://i.etsystatic.com/5438927/r/il/2ae39a/3856337008/il_794xN.3856337008_9jpb.jpg)
- ![May include: Two images showing how to measure for hoop earrings. The image on the left shows a ruler measuring 9mm from the piercing to the edge of the ear. The image on the right shows a ruler measuring 7mm from the piercing to the edge of the ear. Text on the left image reads: '9mm', '10mm hoop minimum size for this ear. (12mm hoop is shown in piercing)'. Text on the right image reads: '7mm', '8mm hoop will be a snug fit as shown', 'Measure from the piercing to the edge of the ear with a millimeter ruler.', 'Add 1-2mm for the hoop itself and that is your minimum size.', 'Order a larger size if you want space between the hoop and your ear.'](https://i.etsystatic.com/5438927/r/il/5dcceb/3856337046/il_794xN.3856337046_frc5.jpg)
- ![May include: Three silver hoop earrings of different sizes. The smallest hoop is 10mm, the middle hoop is 10mm, and the largest hoop is 12mm or 1.5 inches (38mm).](https://i.etsystatic.com/5438927/r/il/969de7/3903836321/il_794xN.3903836321_ajog.jpg)
- ![May include: How to Open the Hoops. Two gold hoop earrings, one is twisted open correctly, the other is incorrectly pulled open.  To help the hoops maintain their round shape, gently twist the ends away from each other instead of pulling them apart.](https://i.etsystatic.com/5438927/r/il/7b624f/3856337178/il_794xN.3856337178_qlq2.jpg)

- ![May include: Three pairs of 14k yellow gold fill hoop earrings in different sizes. The text '14k Yellow Gold Fill Hoops' is at the top of the image. The text 'Choose your size' is at the bottom of the image.](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_75x75.2974995587_mfo3.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/7A01C6CE-AD38-42CD-87CA-CFA3B7E8A58C_2_0_a_v7fhrp.jpg)

- ![May include: Three gold hoop earrings in different sizes, 10mm, 10mm, and 12mm. The earrings are shown on a person's ear. The text 'Small Hoop Earrings 22 gauge' is below the earrings.](https://i.etsystatic.com/5438927/r/il/8059b5/3856336788/il_75x75.3856336788_4w9f.jpg)
- ![May include: Three silver hoop earrings in different sizes, 8mm, 10mm, and 12mm, are shown in a person's earlobe.](https://i.etsystatic.com/5438927/r/il/72a038/3856336830/il_75x75.3856336830_6cgu.jpg)
- ![May include: A close-up of a person's ear with a small gold hoop earring in the lobe. The text below the ear reads: '24 gauge 8mm diameter Please note: this size will NOT fit on large or thick earlobes. Try 10 or 12mm diameter instead.'](https://i.etsystatic.com/5438927/r/il/890278/3903836063/il_75x75.3903836063_1xx4.jpg)
- ![May include: A close-up of a person's ear with a small gold hoop earring. The text below the ear reads '24 gauge 10mm diameter'.](https://i.etsystatic.com/5438927/r/il/97a906/3903836079/il_75x75.3903836079_or4v.jpg)
- ![May include: A close-up of a person's ear with a small, thin, gold hoop earring. The text below the ear reads '22 gauge 10mm diameter'.](https://i.etsystatic.com/5438927/r/il/6250e9/3856336948/il_75x75.3856336948_pso5.jpg)
- ![May include: A close-up of a person's ear with a small, thin, gold hoop earring. The earring is 12mm in diameter and 24 gauge. The text '24 gauge 12mm diameter' is visible below the ear.](https://i.etsystatic.com/5438927/r/il/2ae39a/3856337008/il_75x75.3856337008_9jpb.jpg)
- ![May include: Two images showing how to measure for hoop earrings. The image on the left shows a ruler measuring 9mm from the piercing to the edge of the ear. The image on the right shows a ruler measuring 7mm from the piercing to the edge of the ear. Text on the left image reads: '9mm', '10mm hoop minimum size for this ear. (12mm hoop is shown in piercing)'. Text on the right image reads: '7mm', '8mm hoop will be a snug fit as shown', 'Measure from the piercing to the edge of the ear with a millimeter ruler.', 'Add 1-2mm for the hoop itself and that is your minimum size.', 'Order a larger size if you want space between the hoop and your ear.'](https://i.etsystatic.com/5438927/r/il/5dcceb/3856337046/il_75x75.3856337046_frc5.jpg)
- ![May include: Three silver hoop earrings of different sizes. The smallest hoop is 10mm, the middle hoop is 10mm, and the largest hoop is 12mm or 1.5 inches (38mm).](https://i.etsystatic.com/5438927/r/il/969de7/3903836321/il_75x75.3903836321_ajog.jpg)
- ![May include: How to Open the Hoops. Two gold hoop earrings, one is twisted open correctly, the other is incorrectly pulled open.  To help the hoops maintain their round shape, gently twist the ends away from each other instead of pulling them apart.](https://i.etsystatic.com/5438927/r/il/7b624f/3856337178/il_75x75.3856337178_qlq2.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F177454462%2Fsmall-14k-gold-filled-hoop-earrings%23report-overlay-trigger)

In 20+ carts

Price:$16.80+


Original Price:
$21.00+


Loading


**New markdown!**

20% off


•

Limited time sale


# Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size

[SunlightSilver](https://www.etsy.com/shop/SunlightSilver?ref=shop-header-name&listing_id=177454462&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings#reviews)

Arrives soon! Get it by

Nov 15-21


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

Gauge and Size


Select an option

22 gauge, 12mm ($19.20)

22 gauge, 10mm ($19.20)

22 gauge, 8mm ($19.20)

24 gauge, 12mm ($16.80)

24 gauge, 10mm ($16.80)

24 gauge, 8mm ($16.80)

Please select an option


Quantity



12345678910111213141516171819202122232425262728

4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Item details

### Highlights

Made by [SunlightSilver](https://www.etsy.com/shop/SunlightSilver)

- Materials: Yellow gold

- Location: Cartilage, Earlobe, Tragus

- Closure: Latch back

- Recycled

- Made to Order


- Gift wrapping available

See details

Gift wrapping by SunlightSilver

Item will be placed in a jewelry box, wrapped with pretty paper & tied with a string bow. Messages are hand written on a card.

Beautiful and comfortable small hoops made from your choice of 14k yellow or rose gold fill (20% gold) or solid 925 sterling silver. These hoops are designed to be placed in your piercings and left there as long as you like--even while sleeping and showering! Sold in pairs (2 hoops). Available in extra thin 24 gauge or standard 22 gauge. These hoops are hypoallergenic (NO nickel or lead). Both gauges are perfect for new piercings and sensitive ears. They are so comfortable you won't even know they are there.

These hoops are handmade by me and my employees. They are forged by hand, rough edges removed, polished by hand and machine for eye-catching shine. Listing is for one pair of hoops (two individual hoops.)

Choose your preferred gauge (thickness):

\\* 24 gauge - extra thin and lightweight

\\* 22 gauge - standard thickness

Choose your size:

\\* 8mm or 1/4 inch (inside opening is 6.5-7mm)

\\* 10mm or 3/8 inch (inside opening is 8.5-9mm)

\\* 12mm or 1/2 inch (inside opening is 10-11mm)

\*How do I know what size I should order? Every ear and piercing is different. Fit depends on genetics (size and shape of ear lobe) and not age. Some people have tiny earlobes, some have larger thicker earlobes. When in doubt go with the 10mm size. 8mm is best for cartilage or second (+) piercings. Or if you want space between your ear and the hoop, go with the 12mm size. See a video demonstrating how to measure your piercings here: www.sunlightsilver.com then click on videos

\*Are the hoops easy to put in? These hoops are tiny and delicate. The photos were taken with a macro setting. Because of their tiny size, they can be a little tricky to get in your ears. It is best to put them in when you aren't rushed and have time and patience to work with them. See a video demonstrating how to put hoops in your piercings as well as a few other tips at www.sunlightsilver.com then click on videos.

\*Are these hoops available in other options? Yes! They are also available in:

14K and 18K Solid YELLOW Gold Hoops: [https://www.etsy.com/listing/271113362/](https://www.etsy.com/listing/271113362/14k-solid-gold-hoops-18k-solid-gold)

14K Solid ROSE Gold Hoops: [https://www.etsy.com/listing/494599572/](https://www.etsy.com/listing/494599572/solid-14k-rose-gold-hoops-14k-solid-gold)

14K Solid WHITE Gold Hoops: [https://www.etsy.com/listing/480498921/](https://www.etsy.com/listing/480498921/thin-solid-14k-white-gold-palladium)

Solid Platinum Hoops: [https://www.etsy.com/listing/559202285/](https://www.etsy.com/listing/559202285/thin-solid-platinum-hoops-small-hoop)

Solid Sterling Silver Hoops: [https://www.etsy.com/listing/177457651/](https://www.etsy.com/listing/177457651/tiny-hoop-earrings-in-solid-925-sterling)

14k YELLOW Gold Fill Hoops: [https://www.etsy.com/listing/177454462/](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings)

14k ROSE Gold Fill Hoops: [https://www.etsy.com/listing/224123931/](https://www.etsy.com/listing/224123931/little-rose-gold-hoop-earrings-14k-rose)

Larger 1, 1.5 and 2 inch Hoops: [https://www.etsy.com/shop/SunlightSilver?ref=seller-platform-mcnav§ion\_id=6924493](https://www.etsy.com/shop/SunlightSilver?ref=seller-platform-mcnav%C2%A7ion_id=6924493)

FREE silver polishing cloth is included with all orders of $50 or more.

Buy more save more! Automatically get 25% off regular price when you purchase 3+ items from my shop!


## Shipping and return policies

Loading


- Order today to get by

**Nov 15-21**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 30 days


- Free shipping


- Ships from: **Provo, UT**


Deliver to United States

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBrazilBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaGabonGambiaGeorgiaGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuineaGuinea-BissauGuyanaHaitiHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth KoreaSpainSri LankaSudanSurinameSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## Meet your seller

![Julie Pope](https://i.etsystatic.com/5438927/r/isla/bc268c/55344393/isla_75x75.55344393_nagmu2df.jpg)

Julie Pope

Owner of [SunlightSilver](https://www.etsy.com/shop/SunlightSilver?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo2NzI4MTQ4OjE3NjI3ODE2NDY6YzA3MjFmODllYjM4NGQ3NjUzYmU3MjNiODY1ODgyOTQ%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F177454462%2Fsmall-14k-gold-filled-hoop-earrings)

[Message Julie](https://www.etsy.com/messages/new?with_id=6728148&referring_id=177454462&referring_type=listing&recipient_id=6728148&from_action=contact-seller)

This seller usually responds **within a few hours.**

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (561)

4.9/5

item average

4.9Item quality

5.0Shipping

5.0Customer service

98%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Fast shipping

Love it

Cute

Great quality

Exactly what I wanted

Dainty

Comfortable


Filter by category


Shipping & Packaging (105)


Quality (86)


Comfort (79)


Appearance (79)


Sizing & Fit (53)


Description accuracy (52)


Ease of use (40)


Seller service (39)


Value (5)


Condition (3)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Jolene Alves](https://www.etsy.com/people/Jobell12?ref=l_review)
Nov 6, 2025


Love them, perfectly dainty, fit great.



[Jolene Alves](https://www.etsy.com/people/Jobell12?ref=l_review)
Nov 6, 2025


5 out of 5 stars
5

This item

[Sarah](https://www.etsy.com/people/okxlmgfs?ref=l_review)
Nov 6, 2025


Love your products. Order again and again. Very well crafted and great PR. Five stars from me all around.



[Sarah](https://www.etsy.com/people/okxlmgfs?ref=l_review)
Nov 6, 2025


5 out of 5 stars
5

This item

[Kay](https://www.etsy.com/people/cazlt7s6?ref=l_review)
Nov 4, 2025


On time shipping and arrival, wonderful packaging and durable and attractive product. Price point is right. I ordered and rec'd. the smallest size of hoop, realized I'd like a larger one. Will be a repeat customer and will order soon. Highly recommend!



[Kay](https://www.etsy.com/people/cazlt7s6?ref=l_review)
Nov 4, 2025


5 out of 5 stars
5

This item

[Katherine Needs](https://www.etsy.com/people/r8x3fjrrvaei5dc3?ref=l_review)
Oct 30, 2025


These earrings are great. However, they are too small but I returned them easily to exchange for a larger size and thickness.



[Katherine Needs](https://www.etsy.com/people/r8x3fjrrvaei5dc3?ref=l_review)
Oct 30, 2025


View all reviews for this item

### Photos from reviews

![Colleen added a photo of their purchase](https://i.etsystatic.com/iap/97d61d/6860890853/iap_300x300.6860890853_6gwwzmso.jpg?version=0)

![Joann added a photo of their purchase](https://i.etsystatic.com/iap/aa8a0c/6324577909/iap_300x300.6324577909_9gis1xj6.jpg?version=0)

![Cami added a photo of their purchase](https://i.etsystatic.com/iap/74ae44/7248129784/iap_300x300.7248129784_ibh0706u.jpg?version=0)

![Paula added a photo of their purchase](https://i.etsystatic.com/iap/cb3875/6716366890/iap_300x300.6716366890_rrcogctv.jpg?version=0)

![Jole added a photo of their purchase](https://i.etsystatic.com/iap/d22af9/3805761191/iap_300x300.3805761191_7d3huau9.jpg?version=0)

![Jole added a photo of their purchase](https://i.etsystatic.com/iap/19c267/3792541137/iap_300x300.3792541137_39m5dkbx.jpg?version=0)

![SylviaEB added a photo of their purchase](https://i.etsystatic.com/iap/4295b6/3596461682/iap_300x300.3596461682_3tp31p53.jpg?version=0)

![Tabi added a photo of their purchase](https://i.etsystatic.com/iap/8482b2/3256976581/iap_300x300.3256976581_bhp2e553.jpg?version=0)

![Karen added a photo of their purchase](https://i.etsystatic.com/iap/7df278/2922410316/iap_300x300.2922410316_hn5u6qn9.jpg?version=0)

![Cailyn added a photo of their purchase](https://i.etsystatic.com/iap/6b9356/2475146476/iap_300x300.2475146476_20fw3zqy.jpg?version=0)

![Rebecca added a photo of their purchase](https://i.etsystatic.com/iap/216b78/2416341146/iap_300x300.2416341146_3h0w8hf2.jpg?version=0)

![Lisa added a photo of their purchase](https://i.etsystatic.com/iap/1b344e/2451897147/iap_300x300.2451897147_r5qxms2g.jpg?version=0)

![Angelique1212 added a photo of their purchase](https://i.etsystatic.com/iap/91fe2c/2327623857/iap_300x300.2327623857_9ac0911a.jpg?version=0)

![cruztristan added a photo of their purchase](https://i.etsystatic.com/iap/d6a752/2046895946/iap_300x300.2046895946_pl42lxsr.jpg?version=0)

![Monika added a photo of their purchase](https://i.etsystatic.com/iap/00d7bc/2018054753/iap_300x300.2018054753_21njw4zi.jpg?version=0)

![Sydney added a photo of their purchase](https://i.etsystatic.com/iap/ec9e71/1985700305/iap_300x300.1985700305_oqdoyjvw.jpg?version=0)

![Peachy added a photo of their purchase](https://i.etsystatic.com/iap/2da271/1942573005/iap_300x300.1942573005_qchjlfsc.jpg?version=0)

![Laura added a photo of their purchase](https://i.etsystatic.com/iap/90363c/1888462958/iap_300x300.1888462958_fd1q07r3.jpg?version=0)

![Angelique1212 added a photo of their purchase](https://i.etsystatic.com/iap/78b696/1848798388/iap_300x300.1848798388_q1x8e076.jpg?version=0)

![Sarah added a photo of their purchase](https://i.etsystatic.com/iap/9a4316/1680118666/iap_300x300.1680118666_e7rjo4ti.jpg?version=0)

[![SunlightSilver](https://i.etsystatic.com/iusa/9c5348/81429196/iusa_75x75.81429196_mvmu.jpg?version=0)](https://www.etsy.com/shop/SunlightSilver?ref=shop_profile&listing_id=177454462)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[SunlightSilver](https://www.etsy.com/shop/SunlightSilver?ref=shop_profile&listing_id=177454462)

[Owned by Julie Pope](https://www.etsy.com/shop/SunlightSilver?ref=shop_profile&listing_id=177454462) \|

Provo, Utah

4.9
(15.9k)


72.4k sales

16 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=6728148&referring_id=177454462&referring_type=listing&recipient_id=6728148&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo2NzI4MTQ4OjE3NjI3ODE2NDY6YzA3MjFmODllYjM4NGQ3NjUzYmU3MjNiODY1ODgyOTQ%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F177454462%2Fsmall-14k-gold-filled-hoop-earrings)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/SunlightSilver?ref=lp_mys_mfts)

- [![Little 14K Yellow Gold Filled Hoop Earrings. Small Huggy Hoops, Little Hoop Minimalist Earrings. Tiny Hugger Hypoallergenic Earrings](https://i.etsystatic.com/5438927/r/il/455f16/2927271796/il_340x270.2927271796_qs0m.jpg)\\
\\
**Little 14K Yellow Gold Filled Hoop Earrings. Small Huggy Hoops, Little Hoop Minimalist Earrings. Tiny Hugger Hypoallergenic Earrings**\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/94214205/little-14k-yellow-gold-filled-hoop?click_key=1d4c361215f5230abf9e5e592a432685%3ALTfb60cd98a60958080bd6b2925e381d907df3f335&click_sum=e9e395b4&ls=r&ref=related-1&pro=1&sts=1&content_source=1d4c361215f5230abf9e5e592a432685%253ALTfb60cd98a60958080bd6b2925e381d907df3f335 "Little 14K Yellow Gold Filled Hoop Earrings. Small Huggy Hoops, Little Hoop Minimalist Earrings. Tiny Hugger Hypoallergenic Earrings")




Add to Favorites


- [![Minimalist 14k Gold Filled Hoop Earrings | Everyday Yellow Gold Hoops in Multiple Sizes | Classic Dainty Lightweight](https://i.etsystatic.com/5438927/r/il/8bfe41/6430680678/il_340x270.6430680678_remv.jpg)\\
\\
**Minimalist 14k Gold Filled Hoop Earrings \| Everyday Yellow Gold Hoops in Multiple Sizes \| Classic Dainty Lightweight**\\
\\
Sale Price $22.40\\
$22.40\\
\\
$28.00\\
Original Price $28.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/177454625/minimalist-14k-gold-filled-hoop-earrings?click_key=1d4c361215f5230abf9e5e592a432685%3ALT03fdd366f80c378d13afe8c64166c0b8cd19dcc4&click_sum=204d8bc9&ls=r&ref=related-2&pro=1&sts=1&content_source=1d4c361215f5230abf9e5e592a432685%253ALT03fdd366f80c378d13afe8c64166c0b8cd19dcc4 "Minimalist 14k Gold Filled Hoop Earrings | Everyday Yellow Gold Hoops in Multiple Sizes | Classic Dainty Lightweight")




Add to Favorites


- [![Large Gold Hoop Earrings. 14K Gold Yellow Fill Thin Lightweight Hoops. Perfect for Sensitive Ears. Choose your size: 2 inch or smaller](https://i.etsystatic.com/5438927/r/il/e1f119/3905597621/il_340x270.3905597621_satj.jpg)\\
\\
**Large Gold Hoop Earrings. 14K Gold Yellow Fill Thin Lightweight Hoops. Perfect for Sensitive Ears. Choose your size: 2 inch or smaller**\\
\\
Sale Price $22.40\\
$22.40\\
\\
$28.00\\
Original Price $28.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/79830086/large-gold-hoop-earrings-14k-gold-yellow?click_key=1d4c361215f5230abf9e5e592a432685%3ALTc773105e5b7a282163432c5c28e83c0b1f900c7b&click_sum=ae28c583&ls=r&ref=related-3&pro=1&sts=1&content_source=1d4c361215f5230abf9e5e592a432685%253ALTc773105e5b7a282163432c5c28e83c0b1f900c7b "Large Gold Hoop Earrings. 14K Gold Yellow Fill Thin Lightweight Hoops. Perfect for Sensitive Ears. Choose your size: 2 inch or smaller")




Add to Favorites


- [![Purple and White Wampum Quahog Shell and Sterling Silver Earrings](https://i.etsystatic.com/5438927/r/il/a1124c/6266412423/il_340x270.6266412423_efy0.jpg)\\
\\
**Purple and White Wampum Quahog Shell and Sterling Silver Earrings**\\
\\
Sale Price $36.00\\
$36.00\\
\\
$45.00\\
Original Price $45.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1782985741/purple-and-white-wampum-quahog-shell-and?click_key=ebd62722c977da4d8bb495aaabcfef55efe35297%3A1782985741&click_sum=a8d29c38&ref=related-4&pro=1&sts=1 "Purple and White Wampum Quahog Shell and Sterling Silver Earrings")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 8, 2025


[1326 favorites](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Jewelry](https://www.etsy.com/c/jewelry?explicit=1&ref=breadcrumb_listing) [Earrings](https://www.etsy.com/c/jewelry/earrings?explicit=1&ref=breadcrumb_listing) [Hoop Earrings](https://www.etsy.com/c/jewelry/earrings/hoop-earrings?explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Furniture

[Psychedelic Groovy Retro Bean Bag Chair Cover](https://www.etsy.com/listing/1269554930/psychedelic-groovy-retro-bean-bag-chair)

Computers & Peripherals

[Blue Ridge Mousepad for Sale](https://www.etsy.com/market/blue_ridge_mousepad)

Soaps

[Eucalyptus Lemon Essential Oil by AnnaLouiseFarm](https://www.etsy.com/listing/1265102475/zero-waste-dish-soap-chunky)

Earrings

[Opal Earrings](https://www.etsy.com/listing/4331538014/opal-earrings-nap-earrings-cosmic) [Pearl And Coral Earring - US](https://www.etsy.com/market/pearl_and_coral_earring) [Shop Anatoli Jewelry](https://www.etsy.com/market/anatoli_jewelry) [Bronze Teal Purple teardrop medallion dangle drop earrings french hook 1.25" long Teal Green Purple bronze pendant enamel](https://www.etsy.com/listing/1046271702/bronze-teal-purple-teardrop-medallion) [Antler Earrings Turquoise Bear-Hand Painted](https://www.etsy.com/listing/756249438/antler-earrings-turquoise-bear-hand)

Shopping

[Buy Diy String Puppets Online](https://www.etsy.com/market/diy_string_puppets)

Collectibles

[Buy Ranger Station Vintage Online](https://www.etsy.com/market/ranger_station_vintage) [Buy Mark Sean Orr Online](https://www.etsy.com/market/mark_sean_orr)

Necklaces

[Kore Chain Necklaces for Sale](https://www.etsy.com/market/kore_chain_necklaces)

Drawing & Illustration

[Shop Font Awesome Icons](https://www.etsy.com/market/font_awesome_icons)

Brooches Pins & Clips

[Vintage Kenneth Jay Lane Crystal Dragonfly Brooch](https://www.etsy.com/listing/1798356507/vintage-kenneth-jay-lane-crystal)

Knives & Cutting Tools

[Shop Clay Embedding Tool Stl](https://www.etsy.com/market/clay_embedding_tool_stl)

Canvas & Surfaces

[Galloping Grace transfer Redesign with Prima](https://www.etsy.com/listing/1729978724/galloping-grace-transfer-redesign-with)

Sculpture

[Shop Brass Copper Sailboat Sculpture](https://www.etsy.com/market/brass_copper_sailboat_sculpture)

Kitchen & Dining

[Girlfriend Gift. Girlfriend Mug. Coffee Lover Girlfriend Mug. Gift to Girlfriend. Hot Girlfriend Gift. My Girlfriend is Hotter Than #a474 by StrictlyBusinessMugs](https://www.etsy.com/listing/615907379/girlfriend-gift-girlfriend-mug-coffee)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F177454462%2Fsmall-14k-gold-filled-hoop-earrings&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc4MTY0NjplZGY5ZGYyMmVhNDYxZjYyZDczZDI0ZWYyMTJhZWQzNQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F177454462%2Fsmall-14k-gold-filled-hoop-earrings) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F177454462%2Fsmall-14k-gold-filled-hoop-earrings)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for SunlightSilver

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: before item has shipped

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## Seller details

### Other details

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=6728148&referring_id=5438927&referring_type=shop&recipient_id=6728148&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![May include: Three pairs of 14k yellow gold fill hoop earrings in different sizes. The text '14k Yellow Gold Fill Hoops' is at the top of the image. The text 'Choose your size' is at the bottom of the image.](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_300x300.2974995587_mfo3.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/7A01C6CE-AD38-42CD-87CA-CFA3B7E8A58C_2_0_a_v7fhrp.jpg)

- ![May include: Three gold hoop earrings in different sizes, 10mm, 10mm, and 12mm. The earrings are shown on a person's ear. The text 'Small Hoop Earrings 22 gauge' is below the earrings.](https://i.etsystatic.com/5438927/r/il/8059b5/3856336788/il_300x300.3856336788_4w9f.jpg)
- ![May include: Three silver hoop earrings in different sizes, 8mm, 10mm, and 12mm, are shown in a person's earlobe.](https://i.etsystatic.com/5438927/r/il/72a038/3856336830/il_300x300.3856336830_6cgu.jpg)
- ![May include: A close-up of a person's ear with a small gold hoop earring in the lobe. The text below the ear reads: '24 gauge 8mm diameter Please note: this size will NOT fit on large or thick earlobes. Try 10 or 12mm diameter instead.'](https://i.etsystatic.com/5438927/r/il/890278/3903836063/il_300x300.3903836063_1xx4.jpg)
- ![May include: A close-up of a person's ear with a small gold hoop earring. The text below the ear reads '24 gauge 10mm diameter'.](https://i.etsystatic.com/5438927/r/il/97a906/3903836079/il_300x300.3903836079_or4v.jpg)
- ![May include: A close-up of a person's ear with a small, thin, gold hoop earring. The text below the ear reads '22 gauge 10mm diameter'.](https://i.etsystatic.com/5438927/r/il/6250e9/3856336948/il_300x300.3856336948_pso5.jpg)
- ![May include: A close-up of a person's ear with a small, thin, gold hoop earring. The earring is 12mm in diameter and 24 gauge. The text '24 gauge 12mm diameter' is visible below the ear.](https://i.etsystatic.com/5438927/r/il/2ae39a/3856337008/il_300x300.3856337008_9jpb.jpg)
- ![May include: Two images showing how to measure for hoop earrings. The image on the left shows a ruler measuring 9mm from the piercing to the edge of the ear. The image on the right shows a ruler measuring 7mm from the piercing to the edge of the ear. Text on the left image reads: '9mm', '10mm hoop minimum size for this ear. (12mm hoop is shown in piercing)'. Text on the right image reads: '7mm', '8mm hoop will be a snug fit as shown', 'Measure from the piercing to the edge of the ear with a millimeter ruler.', 'Add 1-2mm for the hoop itself and that is your minimum size.', 'Order a larger size if you want space between the hoop and your ear.'](https://i.etsystatic.com/5438927/r/il/5dcceb/3856337046/il_300x300.3856337046_frc5.jpg)
- ![May include: Three silver hoop earrings of different sizes. The smallest hoop is 10mm, the middle hoop is 10mm, and the largest hoop is 12mm or 1.5 inches (38mm).](https://i.etsystatic.com/5438927/r/il/969de7/3903836321/il_300x300.3903836321_ajog.jpg)
- ![May include: How to Open the Hoops. Two gold hoop earrings, one is twisted open correctly, the other is incorrectly pulled open.  To help the hoops maintain their round shape, gently twist the ends away from each other instead of pulling them apart.](https://i.etsystatic.com/5438927/r/il/7b624f/3856337178/il_300x300.3856337178_qlq2.jpg)

- ![](https://i.etsystatic.com/iap/97d61d/6860890853/iap_640x640.6860890853_6gwwzmso.jpg?version=0)

5 out of 5 stars

- Finish:

14K Yellow Gold Fill

- Gauge and Size:

22 gauge, 12mm


I have extremely sensitive skin and these earrings feel great! No itching, burning, or irritation. I bought a second pair for my daughter.

![](https://i.etsystatic.com/iusa/2fe032/83768040/iusa_75x75.83768040_65da.jpg?version=0)

Apr 23, 2025


[Colleen Nye](https://www.etsy.com/people/cnye9)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/aa8a0c/6324577909/iap_640x640.6324577909_9gis1xj6.jpg?version=0)

5 out of 5 stars

- Finish:

14K Yellow Gold Fill

- Gauge and Size:

22 gauge, 12mm


Gorgeous earrings! The design of the hoop is perfect and so comfortable, I wear them 24/7. Fast delivery too. Will definitely purchase more!

![](https://i.etsystatic.com/iusa/31cf09/70083101/iusa_75x75.70083101_ebjh.jpg?version=0)

Sep 15, 2024


[Joann Leese](https://www.etsy.com/people/a8s3kh4e)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/74ae44/7248129784/iap_640x640.7248129784_ibh0706u.jpg?version=0)

1 out of 5 stars

- Finish:

14K Yellow Gold Fill

- Gauge and Size:

24 gauge, 10mm


NOT hyperallergenic!!!I don’t react to real gold but I’m reacting to this. Becoming painful to wear and my ear is swelling.
It’s cute, but I won’t be able to keep wearing. They aren’t telling all the metals they used in the earrings. Don’t buy if there are any metals you react to.

Oct 1, 2025


[Cami](https://www.etsy.com/people/pqgipkyk)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/cb3875/6716366890/iap_640x640.6716366890_rrcogctv.jpg?version=0)

5 out of 5 stars

- Finish:

14K Yellow Gold Fill

- Gauge and Size:

24 gauge, 12mm


Great little earrings. I love the looks, quality, just everything about them. I do like how they put care tips with the jewelry. I will definitely come back to buy more!

![](https://i.etsystatic.com/iusa/1dd0df/112626592/iusa_75x75.112626592_td0c.jpg?version=0)

Mar 14, 2025


[Paula Mckenzie](https://www.etsy.com/people/yk3lzvgc)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/d22af9/3805761191/iap_640x640.3805761191_7d3huau9.jpg?version=0)

5 out of 5 stars

- Finish:

14K Yellow Gold Fill

- Gauge and Size:

22 gauge, 10mm


I love the size I picked out. These earrings are light enough to sleep in and I just love them.

![](https://i.etsystatic.com/iusa/ca4f8b/99106775/iusa_75x75.99106775_hm3c.jpg?version=0)

Mar 23, 2022


[Jole](https://www.etsy.com/people/koyjdzjo)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/19c267/3792541137/iap_640x640.3792541137_39m5dkbx.jpg?version=0)

5 out of 5 stars

- Finish:

14K Yellow Gold Fill

- Gauge and Size:

24 gauge, 12mm


So light and cute. Perfect for everyday wear.

![](https://i.etsystatic.com/iusa/ca4f8b/99106775/iusa_75x75.99106775_hm3c.jpg?version=0)

Mar 17, 2022


[Jole](https://www.etsy.com/people/koyjdzjo)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/4295b6/3596461682/iap_640x640.3596461682_3tp31p53.jpg?version=0)

5 out of 5 stars

- Finish:

14K Yellow Gold Fill

- Gauge and Size:

22 gauge, 12mm


Seriously so cute. And my ears aren’t angry! Super lightweight which is good because my ears used to be gauged and I didn’t want them weighed down. These are perfect!

![](https://i.etsystatic.com/iusa/3d46f3/55863756/iusa_75x75.55863756_fa9q.jpg?version=0)

Jan 14, 2022


[SylviaEB](https://www.etsy.com/people/SylviaEB)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/8482b2/3256976581/iap_640x640.3256976581_bhp2e553.jpg?version=0)

5 out of 5 stars

- Finish:

14K Yellow Gold Fill

- Gauge and Size:

22 gauge, 10mm


I purchased these exact earrings 3 yrs ago and they have held up great. They have never tarnished even with taking showers with them on. Highly recommend, great quality and fast shipping as well.

![](https://i.etsystatic.com/iusa/cd8474/68749283/iusa_75x75.68749283_i63o.jpg?version=0)

Jul 16, 2021


[Tabi Myers](https://www.etsy.com/people/TabiMyers)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/7df278/2922410316/iap_640x640.2922410316_hn5u6qn9.jpg?version=0)

5 out of 5 stars

- Finish:

14K Yellow Gold Fill

- Gauge and Size:

22 gauge, 8mm


I Love Em!!!!! They are the exact size I was looking for!!! And it locks!!! Perfect!!!!! Photo on its way!!!!

![](https://i.etsystatic.com/iusa/8d5e0d/100899242/iusa_75x75.100899242_1hkf.jpg?version=0)

Mar 6, 2021


[Karen](https://www.etsy.com/people/o96ivubu)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/6b9356/2475146476/iap_640x640.2475146476_20fw3zqy.jpg?version=0)

5 out of 5 stars

- Finish:

14K Yellow Gold Fill

- Gauge and Size:

24 gauge, 10mm


I searched high and low for simple gold hoops and was excited to find this shop. I have these in my second holes and they are the perfect size for an elevated, everyday look. I haven't taken them out in 3 months, they show no noticeable signs of wear or damage, and have never fallen out. Would certainly purchase from this shop again!

![](https://i.etsystatic.com/iusa/35edac/102426098/iusa_75x75.102426098_i5a3.jpg?version=0)

Aug 18, 2020


[Cailyn](https://www.etsy.com/people/ql1jy0tg)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/216b78/2416341146/iap_640x640.2416341146_3h0w8hf2.jpg?version=0)

5 out of 5 stars

- Finish:

14K Yellow Gold Fill

- Gauge and Size:

24 gauge, 10mm


Super fast shipping and great quality. Has some trouble getting them on with my long nails but they look great!

![](https://i.etsystatic.com/iusa/cad0cb/92172388/iusa_75x75.92172388_de6f.jpg?version=0)

Jul 16, 2020


[Rebecca Ross](https://www.etsy.com/people/beccaross09)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/1b344e/2451897147/iap_640x640.2451897147_r5qxms2g.jpg?version=0)

5 out of 5 stars

- Finish:

14K Yellow Gold Fill

- Gauge and Size:

22 gauge, 12mm


I absolutely love my earrings! I ordered them this week and I received my order within 3 days which was super fast! I will definitely be ordering from this shop again in the future ❤️

![](https://i.etsystatic.com/iusa/8c3348/88568600/iusa_75x75.88568600_kmvu.jpg?version=0)

Jul 9, 2020


[Lisa](https://www.etsy.com/people/3soyvfn0)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/91fe2c/2327623857/iap_640x640.2327623857_9ac0911a.jpg?version=0)

5 out of 5 stars

- Finish:

14K Yellow Gold Fill

- Gauge and Size:

22 gauge, 10mm


I love, love, love these earrings. Have I said Love enough times? I had 2 sets before and I ordered another so I can wear them as a set of three everyday. And I do wear them everyday! They are light and comfortable. I never take them out!!

See in original language


Translated by [Microsoft](http://aka.ms/MicrosoftTranslatorAttribution)

I love, love, love these earrings. Have I said Love enough times? I had 2 sets before and I ordered another so I can wear them as a set of three everyday. And I do wear them everyday! They are light and comfortable. I never take them out!!


![](https://i.etsystatic.com/iusa/a40a0f/102707095/iusa_75x75.102707095_l41i.jpg?version=0)

Apr 25, 2020


[Angelique1212](https://www.etsy.com/people/Angelique1212)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/d6a752/2046895946/iap_640x640.2046895946_pl42lxsr.jpg?version=0)

5 out of 5 stars

- Finish:

14K Yellow Gold Fill

- Gauge and Size:

22 gauge, 8mm


Perfect tiny hoop with that doesn’t poke you when you sleep!

Oct 16, 2019


[cruztristan](https://www.etsy.com/people/cruztristan)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/00d7bc/2018054753/iap_640x640.2018054753_21njw4zi.jpg?version=0)

5 out of 5 stars

- Finish:

14K Yellow Gold Fill

- Gauge and Size:

24 gauge, 10mm


Love it!

![](https://i.etsystatic.com/iusa/091d1c/110030208/iusa_75x75.110030208_pdu8.jpg?version=0)

Aug 9, 2019


[Monika Goodman](https://www.etsy.com/people/muncie18)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/ec9e71/1985700305/iap_640x640.1985700305_oqdoyjvw.jpg?version=0)

5 out of 5 stars

- Finish:

14K Yellow Gold Fill

- Gauge and Size:

24 gauge, 10mm


These are perfect. I ordered two sets of the 8mm gold fill hoops for my ears and one set of the 10mm for my nose. Have already ordered a solid gold set. Love the closure (a bit challenging to close fully, but once closed you’re all set), super fast shipping, great quality.

![](https://i.etsystatic.com/iusa/5cdf1d/50062317/iusa_75x75.50062317_22b0.jpg?version=0)

Jul 10, 2019


[Sydney Bilodeau](https://www.etsy.com/people/sydneybilodeau)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/2da271/1942573005/iap_640x640.1942573005_qchjlfsc.jpg?version=0)

5 out of 5 stars

- Finish:

14K Yellow Gold Fill

- Gauge and Size:

22 gauge, 8mm


I bought two sizes and wear them everyday. Super simple and easy to take care of. I wear them to sleep and in the shower and they don’t tarnish it’s been about a month. Super simple minimalistic piece :)

![](https://i.etsystatic.com/iusa/53dd41/82495863/iusa_75x75.82495863_5rmb.jpg?version=0)

May 30, 2019


[Peachy Clouds](https://www.etsy.com/people/hipsterdoll101)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/90363c/1888462958/iap_640x640.1888462958_fd1q07r3.jpg?version=0)

5 out of 5 stars

- Finish:

14K Yellow Gold Fill

- Gauge and Size:

22 gauge, 12mm


I got the largest kind, gold. I’ve had them for a week and had no problems with them falling out or hurting my ears when I sleep. They look super classy and delicate - buying smaller ones now for my second piercings :))

See in original language


Translated by [Microsoft](http://aka.ms/MicrosoftTranslatorAttribution)

I got the largest kind, gold. I’ve had them for a week and had no problems with them falling out or hurting my ears when I sleep. They look super classy and delicate - buying smaller ones now for my second piercings :))


![](https://i.etsystatic.com/iusa/69e29e/59534548/iusa_75x75.59534548_6wsr.jpg?version=0)

May 24, 2019


[Laura Bardewyck](https://www.etsy.com/people/laurabenot)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/78b696/1848798388/iap_640x640.1848798388_q1x8e076.jpg?version=0)

5 out of 5 stars

- Finish:

14K Yellow Gold Fill

- Gauge and Size:

22 gauge, 10mm


Love love love. They are perfect to hug my ear.

![](https://i.etsystatic.com/iusa/a40a0f/102707095/iusa_75x75.102707095_l41i.jpg?version=0)

Apr 17, 2019


[Angelique1212](https://www.etsy.com/people/Angelique1212)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/9a4316/1680118666/iap_640x640.1680118666_e7rjo4ti.jpg?version=0)

5 out of 5 stars

- Finish:

14K Yellow Gold Fill

- Gauge and Size:

24 gauge, 8mm


The 8mm are perfect and hug just how I wanted them to. I wanted thin I guess I didn’t realize how hard they’d be to see but I do still like them. Takes a little work to get them in and hooked but then very comfortable. There’s some definite flex to them. I’m not sure if they’re circles or ovals after my man-handling; but since they hug it doesn’t matter.

Nov 10, 2018


[Sarah](https://www.etsy.com/people/nz8cvnv0)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)

Purchased item:

[![Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size](https://i.etsystatic.com/5438927/r/il/e26ca5/2974995587/il_170x135.2974995587_mfo3.jpg)\\
\\
Small 14K Gold Filled Hoop Earrings. Yellow Gold Minimalist Hoops. Hypoallergenic Everyday Hoops. Tiny Loop Earrings. Choose your size\\
\\
Sale Price $16.80\\
$16.80\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/177454462/small-14k-gold-filled-hoop-earrings?ref=ap-listing)