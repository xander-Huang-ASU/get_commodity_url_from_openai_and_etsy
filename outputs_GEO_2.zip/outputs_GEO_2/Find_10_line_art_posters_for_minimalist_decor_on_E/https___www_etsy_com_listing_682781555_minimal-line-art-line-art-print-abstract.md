[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/682781555/minimal-line-art-print-abstract-poster#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?explicit=1&ref=catnav_breadcrumb-0)
- [Prints](https://www.etsy.com/c/art-and-collectibles/prints?explicit=1&ref=catnav_breadcrumb-1)
- [Digital Prints](https://www.etsy.com/c/art-and-collectibles/prints/digital-prints?explicit=1&ref=catnav_breadcrumb-2)


Add to Favorites


- ![May include: A white couch with tufted cushions sits in a room with white walls. A potted green plant sits on a white pedestal stand. A framed black and white line drawing hangs on the wall above the couch.](https://i.etsystatic.com/19497239/r/il/a1a670/6245819128/il_794xN.6245819128_9vhx.jpg)
- ![May include: A white round table with a white base and two wooden chairs with metal legs. There is a white mug, a magazine, and a piece of bread on the table. There is a green plant in a pot in the background. There are two black and white framed pictures on the wall behind the table.](https://i.etsystatic.com/19497239/r/il/e91aad/1826243995/il_794xN.1826243995_pbra.jpg)
- ![May include: A black and white line art print in a white frame hanging on a white wall. The print features a simple abstract design of curved lines. A white vase with dried flowers sits on a table with a beige tablecloth. A wooden chair with metal legs sits next to the table.](https://i.etsystatic.com/19497239/r/il/e5337e/1778784362/il_794xN.1778784362_ewnh.jpg)
- ![May include: A white framed picture with a black line drawing of an abstract design. The picture is on a wooden nightstand with a stack of books, including a red book on top. The nightstand is next to a bed with a white and beige pillow and a white blanket.](https://i.etsystatic.com/19497239/r/il/04dd93/1778784420/il_794xN.1778784420_kyrd.jpg)
- ![May include: A white wall with a black and white line art print, a framed print of three women, a black framed print with a black brush stroke, a gold metal stand with a round top and three legs, a full-length mirror, and a clothing rack with a variety of clothing hanging on it.](https://i.etsystatic.com/19497239/r/il/433e74/1826244269/il_794xN.1826244269_c2rg.jpg)
- ![May include: A framed black and white line art print of an abstract design. The print is in a light wood frame and is sitting on a white surface.](https://i.etsystatic.com/19497239/r/il/e3421a/1778784544/il_794xN.1778784544_mfmh.jpg)
- ![May include: A black framed print with a white background and a single black line drawing of an abstract shape.](https://i.etsystatic.com/19497239/r/il/73aafe/1826244181/il_794xN.1826244181_qixf.jpg)
- ![May include: A framed black and white line art print of a simple abstract design. The print is hanging on a white wall above a white dresser with a straw hat and a magazine on top.](https://i.etsystatic.com/19497239/r/il/6feded/1826244131/il_794xN.1826244131_c0nd.jpg)

- ![May include: A white couch with tufted cushions sits in a room with white walls. A potted green plant sits on a white pedestal stand. A framed black and white line drawing hangs on the wall above the couch.](https://i.etsystatic.com/19497239/c/1315/1315/593/51/il/a1a670/6245819128/il_75x75.6245819128_9vhx.jpg)
- ![May include: A white round table with a white base and two wooden chairs with metal legs. There is a white mug, a magazine, and a piece of bread on the table. There is a green plant in a pot in the background. There are two black and white framed pictures on the wall behind the table.](https://i.etsystatic.com/19497239/r/il/e91aad/1826243995/il_75x75.1826243995_pbra.jpg)
- ![May include: A black and white line art print in a white frame hanging on a white wall. The print features a simple abstract design of curved lines. A white vase with dried flowers sits on a table with a beige tablecloth. A wooden chair with metal legs sits next to the table.](https://i.etsystatic.com/19497239/r/il/e5337e/1778784362/il_75x75.1778784362_ewnh.jpg)
- ![May include: A white framed picture with a black line drawing of an abstract design. The picture is on a wooden nightstand with a stack of books, including a red book on top. The nightstand is next to a bed with a white and beige pillow and a white blanket.](https://i.etsystatic.com/19497239/r/il/04dd93/1778784420/il_75x75.1778784420_kyrd.jpg)
- ![May include: A white wall with a black and white line art print, a framed print of three women, a black framed print with a black brush stroke, a gold metal stand with a round top and three legs, a full-length mirror, and a clothing rack with a variety of clothing hanging on it.](https://i.etsystatic.com/19497239/r/il/433e74/1826244269/il_75x75.1826244269_c2rg.jpg)
- ![May include: A framed black and white line art print of an abstract design. The print is in a light wood frame and is sitting on a white surface.](https://i.etsystatic.com/19497239/r/il/e3421a/1778784544/il_75x75.1778784544_mfmh.jpg)
- ![May include: A black framed print with a white background and a single black line drawing of an abstract shape.](https://i.etsystatic.com/19497239/r/il/73aafe/1826244181/il_75x75.1826244181_qixf.jpg)
- ![May include: A framed black and white line art print of a simple abstract design. The print is hanging on a white wall above a white dresser with a straw hat and a magazine on top.](https://i.etsystatic.com/19497239/r/il/6feded/1826244131/il_75x75.1826244131_c0nd.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F682781555%2Fminimal-line-art-print-abstract-poster%23report-overlay-trigger)

Low in stock, only 7 left

Price:$3.00


Loading


# Minimal Line Art Print, Abstract Poster, Black and White Minimalist Wall Art, Modern Printable Art, Digital Download

[MinimoPrintsStudio](https://www.etsy.com/shop/MinimoPrintsStudio?ref=shop-header-name&listing_id=682781555&from_page=listing)

[5 out of 5 stars](https://www.etsy.com/listing/682781555/minimal-line-art-print-abstract-poster#reviews)

4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Designed by [MinimoPrintsStudio](https://www.etsy.com/shop/MinimoPrintsStudio)

- Digital download


- Digital file type(s): 5 JPG


I N S T A N T D O W N L O A D

Add this minimal line art to any room in your house to give it a sophisticated and artistic style. This is an instant download so your files are delivered to your email within minutes.

You will receive 5 high-res printable files that work with a wide range of standard frame sizes so you can select the exact size you wish to print and hang. If you wish for a custom size, just message us and we'll adjust for your preferred dimensions.

This artwork is yours to print as many times as you like for personal use. You can also always find your purchases on your Easy profile in case you need to re-download at any point.

H O W I T W O R K S

Once your purchase clears on Etsy, you will receive 5 high quality (300 DPI) JPEGs

This artwork can be printed in all these sizes:

R A T I O 2:3

4x6” \| 8x12” \| 12x18” \| 16x24” \| 20x30” \| 24x36”

R A T I O 3:4

6x8” \| 9x12” \| 12x16” \| 15x20” \| 18x24”

R A T I O 4:5

4x5” \| 8x10” \| 11x14” \| 12x15” \| 16x20”

I S O (International Standard Size)

A1 \| A2 \| A3 \| A4 \| A5

H O W T O P R I N T

1\. Download the size of your choice and print at home. Be sure to use high quality paper for a better end result.

2\. For the best quality result, take your file to your local print shop or a place like Staples, Kinkos or Office Depot.

3\. Another professional option is to utilize an online printer such as Mpix, Shutterfly or Snapfish and have it delivered to your door.

I M P O R T A N T

No physical product will be shipped, this is a digital file for you to print.

THIS FILE IS FOR PERSONAL USE ONLY and the property of Minimo Prints Studio. It is illegal to share and/or re-sell this product.

The final print quality depends on the printer and paper used. Colors may appear different in person than on screen.

T H A N K Y O U

Thank you so much for visiting my shop, and I hope you will return!

© Copyright 2019 - Minimo Prints Studio

All Rights Reserved


## Delivery

Instant Download

Your files will be available to download once payment is confirmed.
[Here's how.](https://www.etsy.com/help/article/3949)

Instant download items don’t accept returns, exchanges or cancellations. Please contact the seller about any problems with your order.

## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

## Meet your sellers

![Lindsey](https://i.etsystatic.com/19497239/r/isla/c11d54/34287636/isla_75x75.34287636_aewbn543.jpg)

Lindsey

Owner of [MinimoPrintsStudio](https://www.etsy.com/shop/MinimoPrintsStudio?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoxOTkzMDAxNTg6MTc2Mjc3NTcwMDozNDVhZTUzY2Q0M2I0OTVkMmY0MzI3OWMyYTRlZTgyNw%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F682781555%2Fminimal-line-art-print-abstract-poster)

[Message Lindsey](https://www.etsy.com/messages/new?with_id=199300158&referring_id=682781555&referring_type=listing&recipient_id=199300158&from_action=contact-seller)

## Reviews for this item (2)

5.0/5

item average

5.0Item quality

5.0Shipping

5.0Customer service

100%
Buyers recommend

Loading


5 out of 5 stars
5

This item

[Eleni Katopodi](https://www.etsy.com/people/geduju171f9eqqaf?ref=l_review)
Jan 6, 2025


Love it! I highly recommend it!



[Eleni Katopodi](https://www.etsy.com/people/geduju171f9eqqaf?ref=l_review)
Jan 6, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/1536fe/111854476/iusa_75x75.111854476_llce.jpg?version=0)

[Alex Shahan](https://www.etsy.com/people/alexshahan?ref=l_review)
Aug 2, 2019


![](https://i.etsystatic.com/iusa/1536fe/111854476/iusa_75x75.111854476_llce.jpg?version=0)

[Alex Shahan](https://www.etsy.com/people/alexshahan?ref=l_review)
Aug 2, 2019


[![MinimoPrintsStudio](https://i.etsystatic.com/iusa/e42539/110232362/iusa_75x75.110232362_magv.jpg?version=0)](https://www.etsy.com/shop/MinimoPrintsStudio?ref=shop_profile&listing_id=682781555)

[MinimoPrintsStudio](https://www.etsy.com/shop/MinimoPrintsStudio?ref=shop_profile&listing_id=682781555)

[Owned by Lindsey](https://www.etsy.com/shop/MinimoPrintsStudio?ref=shop_profile&listing_id=682781555) \|

Los Angeles, California

5.0
(2)


39 sales

6 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=199300158&referring_id=682781555&referring_type=listing&recipient_id=199300158&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoxOTkzMDAxNTg6MTc2Mjc3NTcwMDozNDVhZTUzY2Q0M2I0OTVkMmY0MzI3OWMyYTRlZTgyNw%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F682781555%2Fminimal-line-art-print-abstract-poster)

## All reviews from this shop (2)

Show all

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

## More from this shop

[Visit shop](https://www.etsy.com/shop/MinimoPrintsStudio?ref=lp_mys_mfts)

- [![Minimal Abstract Line Art Print, Black and White Minimalist Wall Art, Modern Printable Art, Line Drawing, Poster, Digital Download](https://i.etsystatic.com/19497239/c/1851/1470/108/544/il/c90326/1826234727/il_340x270.1826234727_776k.jpg)\\
\\
Digital download\\
\\
\\
**Minimal Abstract Line Art Print, Black and White Minimalist Wall Art, Modern Printable Art, Line Drawing, Poster, Digital Download**\\
\\
$3.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/668932730/minimal-abstract-line-art-print-black?click_key=c8d61b36629a64957997d666e68a8a00%3ALTe08ea85ba5992d49c77cffe1fb33c71c319a8e93&click_sum=488436aa&ls=r&ref=related-1&dd=1&content_source=c8d61b36629a64957997d666e68a8a00%253ALTe08ea85ba5992d49c77cffe1fb33c71c319a8e93 "Minimal Abstract Line Art Print, Black and White Minimalist Wall Art, Modern Printable Art, Line Drawing, Poster, Digital Download")




Add to Favorites


- [![Minimal Line Art, Line Drawing Print, Black and White Wall Art, Minimalist Art Poster, Contemporary Print, Digital Downlaod](https://i.etsystatic.com/19497239/c/1573/1573/231/456/il/d0aa06/6245826626/il_340x270.6245826626_ijjx.jpg)\\
\\
Digital download\\
\\
\\
**Minimal Line Art, Line Drawing Print, Black and White Wall Art, Minimalist Art Poster, Contemporary Print, Digital Downlaod**\\
\\
$2.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/680327127/minimal-line-art-line-drawing-print?click_key=c8d61b36629a64957997d666e68a8a00%3ALT3e422531ccb02ebd768131c94eec877ca29982e4&click_sum=82e825dc&ls=r&ref=related-2&dd=1&content_source=c8d61b36629a64957997d666e68a8a00%253ALT3e422531ccb02ebd768131c94eec877ca29982e4 "Minimal Line Art, Line Drawing Print, Black and White Wall Art, Minimalist Art Poster, Contemporary Print, Digital Downlaod")




Add to Favorites


- [![Minimal Line Art, Abstract Poster, Black and White Minimalist Wall Art, Modern Printable Art, Line Drawing Wall Art, Digital Download](https://i.etsystatic.com/19497239/c/1550/1550/154/559/il/938130/6293882067/il_340x270.6293882067_mqp4.jpg)\\
\\
Digital download\\
\\
\\
**Minimal Line Art, Abstract Poster, Black and White Minimalist Wall Art, Modern Printable Art, Line Drawing Wall Art, Digital Download**\\
\\
$3.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/668934212/minimal-line-art-abstract-poster-black?click_key=c8d61b36629a64957997d666e68a8a00%3ALT6cedc2879d29fdf12c9a5aad51ae1cfe572cca16&click_sum=284da432&ls=r&ref=related-3&dd=1&content_source=c8d61b36629a64957997d666e68a8a00%253ALT6cedc2879d29fdf12c9a5aad51ae1cfe572cca16 "Minimal Line Art, Abstract Poster, Black and White Minimalist Wall Art, Modern Printable Art, Line Drawing Wall Art, Digital Download")




Add to Favorites


- [![Minimal Neutral Wall Art, Geometric Print, Beige and Black, Modern Art Poster, Minimalist Art Print, Wall Decor, Printable Art, Japandi](https://i.etsystatic.com/19497239/r/il/befe97/6258633568/il_340x270.6258633568_c933.jpg)\\
\\
Digital download\\
\\
\\
**Minimal Neutral Wall Art, Geometric Print, Beige and Black, Modern Art Poster, Minimalist Art Print, Wall Decor, Printable Art, Japandi**\\
\\
$5.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1791139653/minimal-neutral-wall-art-geometric-print?click_key=3e1411897cc541ce113991696ef38d6c751c2fab%3A1791139653&click_sum=7a6e923b&ref=related-4&dd=1 "Minimal Neutral Wall Art, Geometric Print, Beige and Black, Modern Art Poster, Minimalist Art Print, Wall Decor, Printable Art, Japandi")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Sep 5, 2025


[68 favorites](https://www.etsy.com/listing/682781555/minimal-line-art-print-abstract-poster/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?explicit=1&ref=breadcrumb_listing) [Prints](https://www.etsy.com/c/art-and-collectibles/prints?explicit=1&ref=breadcrumb_listing) [Digital Prints](https://www.etsy.com/c/art-and-collectibles/prints/digital-prints?explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Car Parts & Accessories

[Buy Spiritual Car Charm Online](https://www.etsy.com/market/spiritual_car_charm)

Paper

[Digital Marketing Course Template - US](https://www.etsy.com/market/digital_marketing_course_template) [Toxico Car Decal - Paper, Stationery & Cards](https://www.etsy.com/listing/1186873941/i-love-my-gordito-toxico-car-decal) [Buy 64 Decal Online](https://www.etsy.com/market/64_decal) [Shop Big Boy Train Card](https://www.etsy.com/market/big_boy_train_card)

Necklaces

[OPALIZED PETRIFIED WOOD necklace - Necklaces](https://www.etsy.com/listing/1080000599/opalized-petrified-wood-necklace)

Brooches Pins & Clips

[Small Pink & Gray Rhinestone Pin by TreatyourselfFinds](https://www.etsy.com/listing/1276382308/small-pink-gray-rhinestone-pin-vintage)

Prints

[Or without a tick list.](https://www.etsy.com/listing/917456894/the-munros-line-illustration-detailing) [Pink Tropical Flamingo 21 PNG Bird Clipart Bundle 23AP083 by NebulousNoonStudio](https://www.etsy.com/listing/1470198851/pink-tropical-flamingo-21-png-bird) [Shop Happy Mothers Day With Footprint](https://www.etsy.com/market/happy_mothers_day_with_footprint) [Shop Creepy Texture](https://www.etsy.com/market/creepy_texture) [Hero Clip Art - US](https://www.etsy.com/market/hero_clip_art) [Latina Dance Art for Sale](https://www.etsy.com/market/latina_dance_art) [Cash Preferred Business Sign: Printable Payment Options (Digital Download)](https://www.etsy.com/listing/1636317244/cash-is-preffered-and-appreciated-cash) [Pregnancy Announcement Digital by JLEWahines](https://www.etsy.com/listing/1793237230/pregnancy-announcement-digital-baby)

Party Supplies

[Under The Sea Half Birthday Chalkboard - DIGITAL - Underwater Birthday Sign - Fish Chalkboard - Baby's 6 Month Sign - Milestones - Party Supplies](https://www.etsy.com/listing/539404968/under-the-sea-half-birthday-chalkboard)

Shopping

[Buy Bleached Basketball Shirts Online](https://www.etsy.com/market/bleached_basketball_shirts)

Fabric & Notions

[25/SUMMER NinthIsle Inspiration Exclusive Elegant Art 100 % Rayon Fabric - Magic Jellyfish Series - By the Yard - Fabric & Notions](https://www.etsy.com/listing/4306521357/25summer-ninthisle-inspiration-exclusive)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F682781555%2Fminimal-line-art-print-abstract-poster&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc3NTcwMDpjYmM1NWNjODUzZDM5ZDI1NDRkZDMzZjMwMTUwNmY0Mw==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F682781555%2Fminimal-line-art-print-abstract-poster) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/682781555/minimal-line-art-print-abstract-poster#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F682781555%2Fminimal-line-art-print-abstract-poster)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: A white couch with tufted cushions sits in a room with white walls. A potted green plant sits on a white pedestal stand. A framed black and white line drawing hangs on the wall above the couch.](https://i.etsystatic.com/19497239/c/1315/1315/593/51/il/a1a670/6245819128/il_300x300.6245819128_9vhx.jpg)
- ![May include: A white round table with a white base and two wooden chairs with metal legs. There is a white mug, a magazine, and a piece of bread on the table. There is a green plant in a pot in the background. There are two black and white framed pictures on the wall behind the table.](https://i.etsystatic.com/19497239/r/il/e91aad/1826243995/il_300x300.1826243995_pbra.jpg)
- ![May include: A black and white line art print in a white frame hanging on a white wall. The print features a simple abstract design of curved lines. A white vase with dried flowers sits on a table with a beige tablecloth. A wooden chair with metal legs sits next to the table.](https://i.etsystatic.com/19497239/r/il/e5337e/1778784362/il_300x300.1778784362_ewnh.jpg)
- ![May include: A white framed picture with a black line drawing of an abstract design. The picture is on a wooden nightstand with a stack of books, including a red book on top. The nightstand is next to a bed with a white and beige pillow and a white blanket.](https://i.etsystatic.com/19497239/r/il/04dd93/1778784420/il_300x300.1778784420_kyrd.jpg)
- ![May include: A white wall with a black and white line art print, a framed print of three women, a black framed print with a black brush stroke, a gold metal stand with a round top and three legs, a full-length mirror, and a clothing rack with a variety of clothing hanging on it.](https://i.etsystatic.com/19497239/r/il/433e74/1826244269/il_300x300.1826244269_c2rg.jpg)
- ![May include: A framed black and white line art print of an abstract design. The print is in a light wood frame and is sitting on a white surface.](https://i.etsystatic.com/19497239/r/il/e3421a/1778784544/il_300x300.1778784544_mfmh.jpg)
- ![May include: A black framed print with a white background and a single black line drawing of an abstract shape.](https://i.etsystatic.com/19497239/r/il/73aafe/1826244181/il_300x300.1826244181_qixf.jpg)
- ![May include: A framed black and white line art print of a simple abstract design. The print is hanging on a white wall above a white dresser with a straw hat and a magazine on top.](https://i.etsystatic.com/19497239/r/il/6feded/1826244131/il_300x300.1826244131_c0nd.jpg)

Scroll previousScroll next