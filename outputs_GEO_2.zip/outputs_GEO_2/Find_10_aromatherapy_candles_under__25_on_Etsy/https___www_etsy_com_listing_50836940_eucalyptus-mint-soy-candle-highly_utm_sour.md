[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/50836940/eucalyptus-mint-soy-candle-highly?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?utm_source=openai&explicit=1&ref=catnav_breadcrumb-3)
- [Container Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/container-candles?utm_source=openai&explicit=1&ref=catnav_breadcrumb-4)


Add to Favorites


- ![May include: A glass jar candle with a silver lid. The candle is a light green color and has a brown label that reads 'Eucalyptus Mint', 'Premium Artisan SOY Candle', 'Net Wt. 8.5 oz', and 'AjsCountryCottage.etsy.com'.](https://i.etsystatic.com/5204752/r/il/867794/3836222684/il_794xN.3836222684_t6vj.jpg)
- ![May include: A glass jar candle with a silver lid. The label on the jar reads 'Eucalyptus Spearmint', 'AJ's Country Cottage Candle & Bath', 'ajscountrycottage.etsy.com', 'Fragrant SOY Candle', and 'Net Wt. 8 oz.'](https://i.etsystatic.com/5204752/r/il/92009b/272073847/il_794xN.272073847.jpg)

- ![May include: A glass jar candle with a silver lid. The candle is a light green color and has a brown label that reads 'Eucalyptus Mint', 'Premium Artisan SOY Candle', 'Net Wt. 8.5 oz', and 'AjsCountryCottage.etsy.com'.](https://i.etsystatic.com/5204752/r/il/867794/3836222684/il_75x75.3836222684_t6vj.jpg)
- ![May include: A glass jar candle with a silver lid. The label on the jar reads 'Eucalyptus Spearmint', 'AJ's Country Cottage Candle & Bath', 'ajscountrycottage.etsy.com', 'Fragrant SOY Candle', and 'Net Wt. 8 oz.'](https://i.etsystatic.com/5204752/r/il/92009b/272073847/il_75x75.272073847.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F50836940%2Feucalyptus-mint-soy-candle-highly%23report-overlay-trigger)

Only 3 left and in 5 carts

Price:$15.00


Loading


# EUCALYPTUS MINT SOY Candle - Highly Scented - Mint Candles, Fresh Clean Candles, Eucalyptus Candles, Strong Candles, Scented Soy Candles

[AJsCountryCottage](https://www.etsy.com/shop/AJsCountryCottage?ref=shop-header-name&listing_id=50836940&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/50836940/eucalyptus-mint-soy-candle-highly?utm_source=openai#reviews)

Arrives soon! Get it by

Nov 14-17


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns accepted

Quantity



123

4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Item details

### Highlights

Made by [AJsCountryCottage](https://www.etsy.com/shop/AJsCountryCottage)

- Materials: Wax type: Soy


EUCALYPTUS SPEARMINT SOY CANDLE is a super clean scent that REALLY freshens a room! Aromatic eucalyptus smells wonderful with a touch of spearmint to sweeten the blend. Fabulous combination and a perennial best-seller!

\- Handmade with pure soy wax, a cotton wick, and a cute 8 oz. square mason jar.

\- Scented an average-sized room in our test burns.

\- Helps you create an inviting, relaxing atmosphere for any occasion! Pamper yourself with the scents you love. :) GREAT gift idea!

\- Burn time varies according to your conditions, but 52 hours is average.\*

\- We ship promptly (usually 1-2 business days) via USPS Priority Mail. Most customers receive orders 2-3 business days after shipment.

TO ORDER MORE THAN 3 CANDLES, you'll probably save money by using flat-rate boxes. Check out our flat-rate box shipping here and SAVE! [https://www.etsy.com/shop/AJsCountryCottage?section\_id=7627409&ref=shopsection\_leftnav\_3](https://www.etsy.com/shop/AJsCountryCottage?section_id=7627409&ref=shopsection_leftnav_3)

\*FOR BEST RESULTS, burn out of a draft, keep wick trimmed to 1/4 inch, and do not extinguish until a full melt pool is achieved (this typically takes about 3 hours). Please note that pure soy candles burn slower in cold temperatures; you may need to move candle to a warmer location if it is burning too slowly.

If you prefer non-soy (traditional) candles with maximum scent throw, check out this section of our shop: [https://www.etsy.com/shop/AJsCountryCottage?section\_id=5196873&ref=shopsection\_leftnav\_2](https://www.etsy.com/shop/AJsCountryCottage?section_id=5196873&ref=shopsection_leftnav_2)

We've made handcrafted artisan candles since 2003. We have a passion for fragrance and hope you do, too!


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-17**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 30 days


- Ships from: **Harrisonville, MO**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## Reviews for this item (22)

Loading


Buyer highlights, summarized by AI

Smells amazing

Fast shipping

Love it

Would recommend

Soft

Beautiful

Great experience


Filter by category


Appearance (3)


Quality (4)


Shipping & Packaging (3)


Comfort (1)


Seller service (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Sharon Mayes](https://www.etsy.com/people/6mc0m0j2oe9fw46t?ref=l_review)
Apr 7, 2023


LOVE THESE CANDLES !!
If you want candles that actually keep their scent and your friends and family can be greeted with the fresh,clean variety of aromas,when they enter,( and leave), your home,you HAVE TO HAVE THESE !!!
I purchased several scents (I like earthy scents),and the eucalyptus mint,blackberry sage are two of my favorites ( I've just placed my second order as my daughter took half of my first order,after enjoying the aromas @ my house).
None of these candle scents are over bearing or loud,but " just right."
I guarantee you that if you buy,just one--- YOU'LL BE BACK QUICKLY FOR MORE !!!
ENJOY 😊😊😊

SHARON FROM FLORIDA



[Sharon Mayes](https://www.etsy.com/people/6mc0m0j2oe9fw46t?ref=l_review)
Apr 7, 2023


5 out of 5 stars
5

This item

[Diane Davi](https://www.etsy.com/people/davimom2?ref=l_review)
Dec 20, 2020


This scent is amazing! Fresh and soft!



[Diane Davi](https://www.etsy.com/people/davimom2?ref=l_review)
Dec 20, 2020


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/be8840/78037175/iusa_75x75.78037175_8oyu.jpg?version=0)

[Susie Lisle](https://www.etsy.com/people/bvn3vujh?ref=l_review)
Dec 13, 2020


Awesome scents.



![](https://i.etsystatic.com/iusa/be8840/78037175/iusa_75x75.78037175_8oyu.jpg?version=0)

[Susie Lisle](https://www.etsy.com/people/bvn3vujh?ref=l_review)
Dec 13, 2020


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/72c93e/37876352/iusa_75x75.37876352_nat2.jpg?version=0)

[Bethney Seifert](https://www.etsy.com/people/bethneyrn?ref=l_review)
May 13, 2020


So beautiful! Arrived quickly and smells amazing!



![](https://i.etsystatic.com/iusa/72c93e/37876352/iusa_75x75.37876352_nat2.jpg?version=0)

[Bethney Seifert](https://www.etsy.com/people/bethneyrn?ref=l_review)
May 13, 2020


View all reviews for this item

[![AJsCountryCottage](https://i.etsystatic.com/iusa/f56305/33650012/iusa_75x75.33650012_lte1.jpg?version=0)](https://www.etsy.com/shop/AJsCountryCottage?ref=shop_profile&listing_id=50836940)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[AJsCountryCottage](https://www.etsy.com/shop/AJsCountryCottage?ref=shop_profile&listing_id=50836940)

[Owned by AJ](https://www.etsy.com/shop/AJsCountryCottage?ref=shop_profile&listing_id=50836940) \|

Kansas City, Missouri

4.9
(4.6k)


12.9k sales

18 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=5343490&referring_id=50836940&referring_type=listing&recipient_id=5343490&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo1MzQzNDkwOjE3NjI3ODY0Njc6YTFiOTZmMTg3NDNkNWM5YmMzZTlhYTE5NzgwMmNlZjU%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F50836940%2Feucalyptus-mint-soy-candle-highly%3Futm_source%3Dopenai)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/AJsCountryCottage?ref=lp_mys_mfts)

- [![LEMONGRASS SAGE SOY Candle, Lemon Candles, Herbal Candles, Grass Candles, Fresh Clean Candles, Scented Soy Candles, Spring Candles, Summer](https://i.etsystatic.com/5204752/r/il/792da0/5283833544/il_340x270.5283833544_i9lc.jpg)\\
\\
**LEMONGRASS SAGE SOY Candle, Lemon Candles, Herbal Candles, Grass Candles, Fresh Clean Candles, Scented Soy Candles, Spring Candles, Summer**\\
\\
$15.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/15916794/lemongrass-sage-soy-candle-lemon-candles?click_key=df038c5171811b0bed465f6802eab257%3ALT4f4076f035e71b44a11beeecbdec3f248cf365e7&click_sum=875e4b0b&ls=r&ref=related-1&sts=1&content_source=df038c5171811b0bed465f6802eab257%253ALT4f4076f035e71b44a11beeecbdec3f248cf365e7 "LEMONGRASS SAGE SOY Candle, Lemon Candles, Herbal Candles, Grass Candles, Fresh Clean Candles, Scented Soy Candles, Spring Candles, Summer")




Add to Favorites


- [![FRESH SAGE CANDLE - Fresh Clean Candles, Spring Summer Candles, Scented Candles, Sage Candles, Herbal Candles, Fresh Herb Candles](https://i.etsystatic.com/5204752/r/il/a48abb/3877453979/il_340x270.3877453979_mgd8.jpg)\\
\\
**FRESH SAGE CANDLE - Fresh Clean Candles, Spring Summer Candles, Scented Candles, Sage Candles, Herbal Candles, Fresh Herb Candles**\\
\\
$15.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/611179697/fresh-sage-candle-fresh-clean-candles?click_key=df038c5171811b0bed465f6802eab257%3ALT9b950598d19be97711ceab40bb4eda1113566aee&click_sum=32761d64&ls=r&ref=related-2&sts=1&content_source=df038c5171811b0bed465f6802eab257%253ALT9b950598d19be97711ceab40bb4eda1113566aee "FRESH SAGE CANDLE - Fresh Clean Candles, Spring Summer Candles, Scented Candles, Sage Candles, Herbal Candles, Fresh Herb Candles")




Add to Favorites


- [![ROSEMARY MINT SOY Candle - Scented Candles - Herbal Herb Candle, Fresh and Clean Scents, Green Scents, Soy Mason Jar Candles, Rustic Decor](https://i.etsystatic.com/5204752/r/il/c96aff/3839432348/il_340x270.3839432348_jl1a.jpg)\\
\\
**ROSEMARY MINT SOY Candle - Scented Candles - Herbal Herb Candle, Fresh and Clean Scents, Green Scents, Soy Mason Jar Candles, Rustic Decor**\\
\\
$15.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/59184522/rosemary-mint-soy-candle-scented-candles?click_key=df038c5171811b0bed465f6802eab257%3ALT4bfdd5e069e83438eded60c97bb3a4f9d3681b74&click_sum=a18461a5&ls=r&ref=related-3&sts=1&content_source=df038c5171811b0bed465f6802eab257%253ALT4bfdd5e069e83438eded60c97bb3a4f9d3681b74 "ROSEMARY MINT SOY Candle - Scented Candles - Herbal Herb Candle, Fresh and Clean Scents, Green Scents, Soy Mason Jar Candles, Rustic Decor")




Add to Favorites


- [![SWEETGRASS SAGE SOY Candle - Sweet Grass Candle, Sage Candle - Fresh Green Candle, Herb Herbal Candle](https://i.etsystatic.com/5204752/r/il/bb4acb/3891391713/il_340x270.3891391713_j2nf.jpg)\\
\\
**SWEETGRASS SAGE SOY Candle - Sweet Grass Candle, Sage Candle - Fresh Green Candle, Herb Herbal Candle**\\
\\
$15.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/47531190/sweetgrass-sage-soy-candle-sweet-grass?click_key=1d5648cc2e18f154f6f4f0cf73b91075461003ea%3A47531190&click_sum=2dddb33f&ref=related-4&sts=1 "SWEETGRASS SAGE SOY Candle - Sweet Grass Candle, Sage Candle - Fresh Green Candle, Herb Herbal Candle")




Add to Favorites



Loading...

Loading


**Disclaimer:** Button/coin batteries may cause serious injury and even death if swallowed. Items containing button/coin batteries should not be easily accessible without the use of a tool. Sellers are responsible for complying with all applicable labeling, design, testing, packaging, and other safety requirements. Etsy assumes no responsibility for the accuracy or contents of a seller’s listing. If you have questions about button/coin batteries, contact the seller by sending a Message. See Etsy's [Terms of Use](https://www.etsy.com/legal/terms-of-use/?ref=product_safety_banner_info_button_batteries_risk#warranties) for more information.

Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Aug 21, 2025


[276 favorites](https://www.etsy.com/listing/50836940/eucalyptus-mint-soy-candle-highly/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Container Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/container-candles?utm_source=openai&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Prints

[The Lord's Prayer. Sunday School Decor. Christian Wall Art. Bible Verse. Scripture. Christian Kids Decor. Sunday School Art. Matthew 6:9-13 - Prints](https://www.etsy.com/listing/271408225/the-lords-prayer-sunday-school-decor)

Shopping

[Buy Penguin Tail Jacket Online](https://www.etsy.com/market/penguin_tail_jacket)

Home Decor

[Seaglass Art 5 X 7 for Sale](https://www.etsy.com/market/seaglass_art_5_x_7) [Map In Black: A Mysterious Map of North America by CelticMaps](https://www.etsy.com/listing/1621492148/map-in-black-a-mysterious-map-of-north) [Shop 20 X 24 Frame With Mat](https://www.etsy.com/market/20_x_24_frame_with_mat) [Cappadocia Ornament - Home Decor](https://www.etsy.com/listing/1604216251/cappadocia-ornament-christmas-ornament) [Yoshitomo Nara - "Time Is..." Matte Art Print - Home Decor](https://www.etsy.com/listing/1735126605/yoshitomo-nara-time-is-matte-art-print) [Vintage Enesco Planter Lucy Rigg Angels Christmas Vase Candy 1979 EUC - Home Decor](https://www.etsy.com/listing/4354994687/vintage-enesco-planter-lucy-rigg-angels) [Easter Bunny Rabbit Food Personalised for every child with their name tube filled with wildlife friendly food pet friendly easter egg box by Beagardenuk](https://www.etsy.com/listing/1892941353/easter-bunny-rabbit-food-personalised) [Wwe Wall Art - US](https://www.etsy.com/market/wwe_wall_art) [Buy Linnea Flower Online](https://www.etsy.com/market/linnea_flower) [Nursery Cactuses Watercolor Print](https://www.etsy.com/listing/1709681254/nursery-cactuses-watercolor-print-set-of)

Womens Clothing

[1990s Vintage BLUMARINE Jeans M size exquisitely beaded long sleeve top by UniquesdeDi](https://www.etsy.com/listing/1354451425/1990s-vintage-blumarine-jeans-m-size)

Paper

[Pregnancy And Postpartum Planner for Sale](https://www.etsy.com/market/pregnancy_and_postpartum_planner) [First Day Of School Gift Tag Printable Back to School Classroom Gift Tag Canva Template Cute Pencil Write Start Welcome Back To School Corjl by MulberryStPaperGoods](https://www.etsy.com/listing/4323568384/first-day-of-school-gift-tag-printable)

Gender Neutral Kids Clothing

[So Franken Cute Sweatshirt by BroCoApparel](https://www.etsy.com/listing/1322658247/so-franken-cute-sweatshirt-frankenstein)

Necklaces

[18k Gold And Green Necklace for Sale](https://www.etsy.com/market/18k_gold_and_green_necklace)

Paper & Party Supplies

[Mickey Mouse Party by SweetPaperPartyDecor](https://www.etsy.com/listing/399128331/mickey-mouse-pirate-banner-pirate-mickey)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F50836940%2Feucalyptus-mint-soy-candle-highly%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc4NjQ2Nzo4NjhmNjIzMmU1YWNjZWU2MDdjMjg1NjRmZmE1YWM5ZA==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F50836940%2Feucalyptus-mint-soy-candle-highly%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/50836940/eucalyptus-mint-soy-candle-highly?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F50836940%2Feucalyptus-mint-soy-candle-highly%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for AJsCountryCottage

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: not accepted

Please contact the seller if you have any problems with your order.

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: A glass jar candle with a silver lid. The candle is a light green color and has a brown label that reads 'Eucalyptus Mint', 'Premium Artisan SOY Candle', 'Net Wt. 8.5 oz', and 'AjsCountryCottage.etsy.com'.](https://i.etsystatic.com/5204752/r/il/867794/3836222684/il_300x300.3836222684_t6vj.jpg)
- ![May include: A glass jar candle with a silver lid. The label on the jar reads 'Eucalyptus Spearmint', 'AJ's Country Cottage Candle & Bath', 'ajscountrycottage.etsy.com', 'Fragrant SOY Candle', and 'Net Wt. 8 oz.'](https://i.etsystatic.com/5204752/r/il/92009b/272073847/il_300x300.272073847.jpg)