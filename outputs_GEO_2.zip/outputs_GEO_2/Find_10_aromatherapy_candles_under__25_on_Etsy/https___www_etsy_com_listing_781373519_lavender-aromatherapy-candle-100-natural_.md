[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/781373519/lavender-aromatherapy-candle-100-natural?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?utm_source=openai&explicit=1&ref=catnav_breadcrumb-3)


Add to Favorites


- ![May include: A white candle in a clear glass jar with a brown label that reads 'Red Barn Candle Company' and 'LAVENDER' in a decorative font. The candle is lit and the flame is visible. The candle is sitting on a wooden surface with a bunch of dried lavender flowers in the foreground.](https://i.etsystatic.com/22375113/r/il/623a6b/2349336692/il_794xN.2349336692_qfa2.jpg)
- ![May include: A clear glass jar candle with a white wax candle inside. The candle has a brown paper label with black text that reads 'Red Barn Candle Company' and 'Honeysuckle' in a larger font. The label also has a small pink house illustration and the text 'Handmade in the U.S.A.'](https://i.etsystatic.com/22375113/r/il/39ded3/2348009748/il_794xN.2348009748_du2q.jpg)
- ![May include: A clear glass candle jar with a white candle inside. The candle is lit and the flame is visible. The jar has a brown label with the text 'Red Barn Candle Company' and 'Sage & Citrus' printed on it. The candle is surrounded by dried orange peels and a bundle of sage.](https://i.etsystatic.com/22375113/r/il/d28ef0/2349362394/il_794xN.2349362394_p9ae.jpg)
- ![May include: A clear glass jar candle with a brown label that reads 'Red Barn Candle Company Vanilla Latte Handmade in the U.S.A.' The candle is lit and the flame is visible. The candle is surrounded by coffee beans.](https://i.etsystatic.com/22375113/r/il/1e5b06/2396953479/il_794xN.2396953479_belo.jpg)
- ![May include: A white candle in a clear glass jar with a white label that says 'Red Barn Candle Company' and 'Flower Shop' in black text. The candle is surrounded by dried rose petals.](https://i.etsystatic.com/22375113/r/il/987512/2349362132/il_794xN.2349362132_fivt.jpg)
- ![May include: A clear glass jar candle with a white label that reads 'Red Barn Candle Company Eucalyptus Spearmint Handmade in the U.S.A.' The candle is lit and the flame is visible. There are green leaves on the table next to the candle.](https://i.etsystatic.com/22375113/r/il/3fc6c5/2405440820/il_794xN.2405440820_i234.jpg)
- ![May include: Five glass candle jars with gold lids and labels. The labels are brown with white text and a black and white illustration of a farmhouse. The candles are arranged in a row from left to right: Flower Shop, Sage & Citrus, Lavender, Vanilla Latte, Cedarwood. The candles are surrounded by dried flower petals, lavender, and wood shavings.](https://i.etsystatic.com/22375113/r/il/5765cd/2577710689/il_794xN.2577710689_f3ku.jpg)
- ![May include: Three glass jars with white candle wax inside. Each jar has a brown paper label with a red barn and fall foliage design. The labels read 'Pumpkin Spice', 'Apple Cinnamon', and 'Mulled Cider'. The jars are surrounded by cinnamon sticks, apples, and fall-colored berries.](https://i.etsystatic.com/22375113/r/il/13d002/2530056720/il_794xN.2530056720_hc6n.jpg)
- ![May include: Three glass jars with gold lids and white labels. The labels have a red barn illustration and text that reads 'Red Barn Candle Company.' The jars are filled with white candle wax. The jars are arranged from left to right: 'Frankincense & Myrrh', 'Christmas Tree', and 'Gingerbread'. The jars are surrounded by pine cones, holly berries, and other Christmas decorations.](https://i.etsystatic.com/22375113/r/il/92026f/2577710969/il_794xN.2577710969_f7jj.jpg)
- ![May include: Three glass jars with white candles and dried flowers inside. The jars have labels with the words 'Sacred Smudge', 'Tranquility', and 'Positive Energy'.](https://i.etsystatic.com/22375113/r/il/d26cc8/2952115486/il_794xN.2952115486_5wp1.jpg)

- ![May include: A white candle in a clear glass jar with a brown label that reads 'Red Barn Candle Company' and 'LAVENDER' in a decorative font. The candle is lit and the flame is visible. The candle is sitting on a wooden surface with a bunch of dried lavender flowers in the foreground.](https://i.etsystatic.com/22375113/c/1215/966/62/83/il/623a6b/2349336692/il_75x75.2349336692_qfa2.jpg)
- ![May include: A clear glass jar candle with a white wax candle inside. The candle has a brown paper label with black text that reads 'Red Barn Candle Company' and 'Honeysuckle' in a larger font. The label also has a small pink house illustration and the text 'Handmade in the U.S.A.'](https://i.etsystatic.com/22375113/r/il/39ded3/2348009748/il_75x75.2348009748_du2q.jpg)
- ![May include: A clear glass candle jar with a white candle inside. The candle is lit and the flame is visible. The jar has a brown label with the text 'Red Barn Candle Company' and 'Sage & Citrus' printed on it. The candle is surrounded by dried orange peels and a bundle of sage.](https://i.etsystatic.com/22375113/r/il/d28ef0/2349362394/il_75x75.2349362394_p9ae.jpg)
- ![May include: A clear glass jar candle with a brown label that reads 'Red Barn Candle Company Vanilla Latte Handmade in the U.S.A.' The candle is lit and the flame is visible. The candle is surrounded by coffee beans.](https://i.etsystatic.com/22375113/r/il/1e5b06/2396953479/il_75x75.2396953479_belo.jpg)
- ![May include: A white candle in a clear glass jar with a white label that says 'Red Barn Candle Company' and 'Flower Shop' in black text. The candle is surrounded by dried rose petals.](https://i.etsystatic.com/22375113/r/il/987512/2349362132/il_75x75.2349362132_fivt.jpg)
- ![May include: A clear glass jar candle with a white label that reads 'Red Barn Candle Company Eucalyptus Spearmint Handmade in the U.S.A.' The candle is lit and the flame is visible. There are green leaves on the table next to the candle.](https://i.etsystatic.com/22375113/r/il/3fc6c5/2405440820/il_75x75.2405440820_i234.jpg)
- ![May include: Five glass candle jars with gold lids and labels. The labels are brown with white text and a black and white illustration of a farmhouse. The candles are arranged in a row from left to right: Flower Shop, Sage & Citrus, Lavender, Vanilla Latte, Cedarwood. The candles are surrounded by dried flower petals, lavender, and wood shavings.](https://i.etsystatic.com/22375113/r/il/5765cd/2577710689/il_75x75.2577710689_f3ku.jpg)
- ![May include: Three glass jars with white candle wax inside. Each jar has a brown paper label with a red barn and fall foliage design. The labels read 'Pumpkin Spice', 'Apple Cinnamon', and 'Mulled Cider'. The jars are surrounded by cinnamon sticks, apples, and fall-colored berries.](https://i.etsystatic.com/22375113/r/il/13d002/2530056720/il_75x75.2530056720_hc6n.jpg)
- ![May include: Three glass jars with gold lids and white labels. The labels have a red barn illustration and text that reads 'Red Barn Candle Company.' The jars are filled with white candle wax. The jars are arranged from left to right: 'Frankincense & Myrrh', 'Christmas Tree', and 'Gingerbread'. The jars are surrounded by pine cones, holly berries, and other Christmas decorations.](https://i.etsystatic.com/22375113/r/il/92026f/2577710969/il_75x75.2577710969_f7jj.jpg)
- ![May include: Three glass jars with white candles and dried flowers inside. The jars have labels with the words 'Sacred Smudge', 'Tranquility', and 'Positive Energy'.](https://i.etsystatic.com/22375113/r/il/d26cc8/2952115486/il_75x75.2952115486_5wp1.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F781373519%2Flavender-aromatherapy-candle-100-natural%23report-overlay-trigger)

Price:$12.99+


Loading


# Lavender Aromatherapy Candle \| 100% Natural Soy Wax & Essential Oil Infused \| Pet Safe + Smoke Odor Eliminating \| Non Toxic Scented Candles

[RedBarnCandlesCo](https://www.etsy.com/shop/RedBarnCandlesCo?ref=shop-header-name&listing_id=781373519&from_page=listing)

[4 out of 5 stars](https://www.etsy.com/listing/781373519/lavender-aromatherapy-candle-100-natural?utm_source=openai#reviews)

Returns & exchanges accepted

Size


Select an option

4 fl oz ($12.99)

8 fl oz ($19.99)

12 fl oz ($25.99)

Please select an option


Scent


Select an option

Lavender

Vanilla Latte

Sage & Citrus

Flower Shop

Cedarwood

Cotton Blossom

Honeysuckle

Eucalyptus Spearmint

Mandarin Lime Basil

Mulled Cider

Apple Cinnamon

Salted Carmel

Pumpkin Spice

Drunken Pumpkin

Gingerbread

Christmas Tree

Frankincense & Myrrh

Spicy Cranberry

Candy Cane

Positive Energy

Sacred Smudge

Tranquility

Please select an option


Quantity



123456789101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899100101102103104105106107108109110111112113114115116117118119120121122123124125126127128129130131132133134135136137138139140141142143144145146147148149150151152153154155156157158159160161162163164165166167168169170171172173174175176177178179180181182183184185186187188189190191192193194195196197198199200201202203204205206207208209210211212213214215216217218219220221222223224225226227228229230231232233234235236237238239240241242243244245246247248249250251252253254255256257258259260261262263264265266267268269270271272273274275276277278279280281282283284285286287288289290291292293294295296297298299300301302303304305306307308309310311312313314315316317318

You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Made by [RedBarnCandlesCo](https://www.etsy.com/shop/RedBarnCandlesCo)

- Materials: Wax type: Soy


- Width: 2.75 inches

Height: 4.75 inches

- Gift wrapping available

See details![](https://i.etsystatic.com/igwp/728a0e/2210669282/igwp_300xN.2210669282_ivjtkzp4.jpg?version=0)

Gift wrapping by RedBarnCandlesCo

Item will be wrapped in Hallmark wrapping paper & gift message will included inside.

Enjoy premium soy candles at affordable pricing with Red Barn Candle Company! Aromatherapy in every breath with natural essential and fragrance oils containing no harmful chemicals or toxins. We believe in a truly all natural product and grow much of the flowers and herbs ourselves. We promise as a small business to always put forth the extra time, love, and positive energy into every single product we offer.

● Essential oils blended to perfection!

● Made with 100% natural eco-soy wax!

● Only made with U.S.A. products!

● No zinc or carcinogenic dyes, paraben & paraffin free!

● Perfect for wedding favors, smudging, chakra, gift giving, and more!

Burn in increments of 4 hours for best results. Trim wicks to 1/4" before each use.

Burn Times by Size - 4 oz. (30 hours) - 8 oz. (60 hours) - 12 oz. (90 hours)

Heavily Scented - Scented candles are meant to fill your whole home with beautiful aromas, and these are crafted to hold the maximum fragrance load giving you a delightful smell!

Clean & Long Lasting - 30 to 90+ hours of burning free of harmful chemicals and toxins can only be achieved with superior quality wax and responsibly sourced essential oils and fragrances. Zinc free and 100% cotton wicks burn without carcinogens!

A Perfect Gift - Our scented candles come in beautifully designed and re-usable wooden dough bowls. Excellent as a gift or to keep for yourself. Makes a great birthday present, hostess gift, housewarming gift, bridal shower present, Christmas gift, teacher appreciation gift, Mother's Day gift, Valentine's Day gift and much more!

About Us - Handmade in Dallas, Texas with 100% all-natural and organic soy wax, pure cotton braided wicks, high quality fragrance and essential oil blend, and dried herbs & flowers sourced from our own gardens. Vegan and Organic. No paraffin wax or carcinogenic dyes! Each candle is hand poured in small batches using all-natural essential oils and the purest quality fragrances. Instead of adding toxic dyes for color, we display our beautiful candles with real dried flowers, herbs, or fruits!

Shipping - Orders greater than 12 ounces receive a free shipping upgrade to Priority Mail (1-3 day). Orders under this limit ship via First Class Mail (2-6 day). The greater the purchase, the quicker the shipping!

 ---------------------------------------------

S C E N T - D E S C R I P T I O N S:

❀Lavender❀ - Original French Lavender homegrown in our garden!

❀Sage & Citrus❀ - A perfect blend of citrus fruits with the aromatic and refreshing scent of sage.

❀Flower Shop❀ - A fresh and subtle mix of floral scents with light sweet teas. This scent smells exactly like your local florist!

❀Garden Sage❀ - An aromatic scent with earthy and green tones mixes with spicy woods and light florals.

❀Mahogany Teakwood❀ - Earthy and warm, just like the smell of teakwood.

❀Cotton Blossom❀ - Very fresh blend of floral blossoms added to a subtle vanilla musk of cotton.

❀Grapefruit❀ - The tart and sweet aroma of a ripe and juicy grapefruit.

❀Rosemary❀ - A crisp herbal fragrance with hints of cool and soothing eucalyptus.

❀Vanilla Latte❀ - Sweet creamy top notes with a mixture of coffee, vanilla, and milk. Your favorite coffee treat! But please don't eat it!

❀Cedarwood❀ - Woodsy scent that reminds you of walking through a forest of cedar trees. Great for the outdoor enthusiast.

❀Honeysuckle❀ - Sweet and rich honeysuckle with light florals, a perfect scent for spring-time and summer.

❀Eucalyptus Spearmint❀ - The relaxing scent of fresh eucalyptus blended with the cool and invigorating scent of spearmint.

❀Mandarin Lime & Basil❀ - Savory basil with sweet lime and orange. We grow all three at our in-house garden!

❀Pumpkin Spice❀ - The best smell of the fall - pumpkin with cinnamon.

❀Mulled Cider❀ - Warm and spicy scent of cinnamon, clove, sweet apple and spicy orange with sweet musk.

❀Apple Cinnamon❀ - Warm, baked apples fresh out of the oven sprinkled with cinnamon.

❀Christmas Tree❀ - A sharp but fresh smell of pine needles on a freshly cut Christmas tree.

❀Gingerbread❀ - Sweet and spicy scent of fresh baked gingerbread cookies with molasses and spices taking you back to Christmas time.

❀Frankincense & Myrrh❀ - Enchanting blend of frankincense and myrrh-woody and musk notes.

❀Positive Energy❀ - A refreshing and uplifting twist between grapefruit, jasmine, and rosemary. Great for good vibes!

❀Tranquility❀ - A tribute to those who are in need of relaxation! Wipe away stress with a wonderful blend of eucalyptus, rosemary, spearmint and refreshing lavender.

❀Sacred Smudge❀ - A native way to cleanse bad energy and invoke the power of aromatic healing! A perfect blend of cedar, sage, and rosemary.

 ---------------------------------------------

Candle Safety Instructions

1\. Never leave a burning candle unattended.

2\. Never use water to extinguish a candle; this is extremely dangerous as it can cause excess heat and steam, which may cause the container/glass to explode.

3\. Ensure wicks are upright and trimmed to 7mm (1/4 inch) during use and each time candle is relit.

4\. Never move a burning candle. Ensure candle is extinguished, wax is solid and jar is cold before handling.

5\. Candle tins may become hot. Burn candle on an appropriate flat heat-resistant surface.

6\. Avoid using in drafty areas, near an open window, air duct or fan.

7\. Keep away from children, pets and flammable materials.

8\. Do not use lid to extinguish candle.

9\. Don't burn a candle all the way down. Extinguish the flame if it comes too close to the holder or container.


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-Dec 6**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 30 days


- Free shipping


- Ships from: **Forney, TX**


Deliver to United States

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

## Meet your seller

![Brooke and Elliott](https://i.etsystatic.com/22375113/r/isla/e4d6e7/39903909/isla_75x75.39903909_rzbfz3w3.jpg)

Brooke and Elliott

Owner of [RedBarnCandlesCo](https://www.etsy.com/shop/RedBarnCandlesCo?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyNzI4NTAxNzg6MTc2Mjc4NjU3NDo4MGY2ZjAyMWExYWRjMmUxZGM4ZDE0OWMxZjllYWY1Yw%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F781373519%2Flavender-aromatherapy-candle-100-natural%3Futm_source%3Dopenai)

[Message Brooke and Elliott](https://www.etsy.com/messages/new?with_id=272850178&referring_id=781373519&referring_type=listing&recipient_id=272850178&from_action=contact-seller)

This seller usually responds **within a few hours.**

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (469)

5.0/5

item average

5.0Item quality

2.5Shipping

3.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Smells amazing

Love it

Fast shipping

Great product

Would recommend

Gift-worthy

Beautiful


Filter by category


Quality (189)


Shipping & Packaging (60)


Appearance (55)


Seller service (32)


Description accuracy (23)


Value (14)


Comfort (7)


Condition (4)


Sizing & Fit (3)


Ease of use (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Nela](https://www.etsy.com/people/w6ixfuhd8rqe298q?ref=l_review)
Sep 3, 2025


The items matched the description



[Nela](https://www.etsy.com/people/w6ixfuhd8rqe298q?ref=l_review)
Sep 3, 2025


5 out of 5 stars
5

This item

[Emilie Burke](https://www.etsy.com/people/eaburke85?ref=l_review)
Mar 17, 2025


I love the scent of the candle and I love the fact that there’s dried lavender buds in the candle. I can’t wait to burn it.



[Emilie Burke](https://www.etsy.com/people/eaburke85?ref=l_review)
Mar 17, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/0eab74/103058570/iusa_75x75.103058570_9bea.jpg?version=0)

[Amy](https://www.etsy.com/people/cgfnvqcr?ref=l_review)
Sep 5, 2024


Amazing candles! They’re def a favorite and I’ve tried quite a few



![](https://i.etsystatic.com/iusa/0eab74/103058570/iusa_75x75.103058570_9bea.jpg?version=0)

[Amy](https://www.etsy.com/people/cgfnvqcr?ref=l_review)
Sep 5, 2024


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/6503e2/47591566/iusa_75x75.47591566_hthz.jpg?version=0)

[Holly Lujah](https://www.etsy.com/people/hollyfloralconcepts?ref=l_review)
Feb 27, 2024


Smells so lovely! Perfect for my flower shop!



![](https://i.etsystatic.com/iusa/6503e2/47591566/iusa_75x75.47591566_hthz.jpg?version=0)

[Holly Lujah](https://www.etsy.com/people/hollyfloralconcepts?ref=l_review)
Feb 27, 2024


View all reviews for this item

### Photos from reviews

![Jacquelyn added a photo of their purchase](https://i.etsystatic.com/iap/320e1c/5156244037/iap_300x300.5156244037_2kvfo70e.jpg?version=0)

![Jacquelyn added a photo of their purchase](https://i.etsystatic.com/iap/42a9e7/5108039742/iap_300x300.5108039742_tpd21uda.jpg?version=0)

![Autumn added a photo of their purchase](https://i.etsystatic.com/iap/32663a/5628433436/iap_300x300.5628433436_1bipneg8.jpg?version=0)

![☾ added a photo of their purchase](https://i.etsystatic.com/iap/385694/5155896837/iap_300x300.5155896837_91phjqpy.jpg?version=0)

![Inactive user added a photo of their purchase](https://i.etsystatic.com/iap/acc497/4624966240/iap_300x300.4624966240_a4iwyc9o.jpg?version=0)

![Sandra added a photo of their purchase](https://i.etsystatic.com/iap/478ec2/5564766067/iap_300x300.5564766067_qgiwc21b.jpg?version=0)

![Roselle added a photo of their purchase](https://i.etsystatic.com/iap/93b56c/4426025356/iap_300x300.4426025356_1ppk4zpf.jpg?version=0)

![Ruth added a photo of their purchase](https://i.etsystatic.com/iap/ebfd45/3818560912/iap_300x300.3818560912_q1hiiol3.jpg?version=0)

![Kamreyn added a photo of their purchase](https://i.etsystatic.com/iap/6b768e/3857014805/iap_300x300.3857014805_hfofl0w2.jpg?version=0)

![Meghan added a photo of their purchase](https://i.etsystatic.com/iap/fbbc35/3800112107/iap_300x300.3800112107_ftyum1vd.jpg?version=0)

![exclusive added a photo of their purchase](https://i.etsystatic.com/iap/640850/3680506360/iap_300x300.3680506360_dognp502.jpg?version=0)

![Lauren added a photo of their purchase](https://i.etsystatic.com/iap/975eed/3725683151/iap_300x300.3725683151_ipk26dnj.jpg?version=0)

![Gabriella added a photo of their purchase](https://i.etsystatic.com/iap/29fd1b/3698802361/iap_300x300.3698802361_6ezhrpro.jpg?version=0)

![Mira added a photo of their purchase](https://i.etsystatic.com/iap/2c79f9/3654767275/iap_300x300.3654767275_49e8grwd.jpg?version=0)

![Sandra added a photo of their purchase](https://i.etsystatic.com/iap/225ebd/3291690725/iap_300x300.3291690725_j94v93p2.jpg?version=0)

![Denise added a photo of their purchase](https://i.etsystatic.com/iap/3057ae/3079679211/iap_300x300.3079679211_4aifaan3.jpg?version=0)

![Cartoony added a photo of their purchase](https://i.etsystatic.com/iap/6039f2/3078799521/iap_300x300.3078799521_exlk84ij.jpg?version=0)

![Sarai added a photo of their purchase](https://i.etsystatic.com/iap/44db93/3061048117/iap_300x300.3061048117_pmtw5x8b.jpg?version=0)

![Rocio added a photo of their purchase](https://i.etsystatic.com/iap/d26ccd/3003533125/iap_300x300.3003533125_s1oty89j.jpg?version=0)

![Jade added a photo of their purchase](https://i.etsystatic.com/iap/91edea/2885156116/iap_300x300.2885156116_lra3q20c.jpg?version=0)

[![RedBarnCandlesCo](https://i.etsystatic.com/iusa/327498/72680729/iusa_75x75.72680729_nor4.jpg?version=0)](https://www.etsy.com/shop/RedBarnCandlesCo?ref=shop_profile&listing_id=781373519)

[RedBarnCandlesCo](https://www.etsy.com/shop/RedBarnCandlesCo?ref=shop_profile&listing_id=781373519)

[Owned by Brooke and Elliott](https://www.etsy.com/shop/RedBarnCandlesCo?ref=shop_profile&listing_id=781373519) \|

Dallas, Texas

4.1
(8.2k)


40.9k sales

5 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=272850178&referring_id=781373519&referring_type=listing&recipient_id=272850178&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyNzI4NTAxNzg6MTc2Mjc4NjU3NDo4MGY2ZjAyMWExYWRjMmUxZGM4ZDE0OWMxZjllYWY1Yw%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F781373519%2Flavender-aromatherapy-candle-100-natural%3Futm_source%3Dopenai)

This seller usually responds **within a few hours.**

## More from this shop

[Visit shop](https://www.etsy.com/shop/RedBarnCandlesCo?ref=lp_mys_mfts)

- [![Red Barn Spring Aromatherapy Candles | 100% Natural Soy Essential Oil Infused | Pet Safe + Odor Eliminating + Relaxing | Toxin Free Candle](https://i.etsystatic.com/22375113/c/1749/1390/628/67/il/55e5c4/3199651865/il_340x270.3199651865_q4l5.jpg)\\
\\
**Red Barn Spring Aromatherapy Candles \| 100% Natural Soy Essential Oil Infused \| Pet Safe + Odor Eliminating + Relaxing \| Toxin Free Candle**\\
\\
$12.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/823017924/red-barn-spring-aromatherapy-candles-100?click_key=8b84b565690ce7ebc38598f82b3339e2%3ALTc086e3392ac3ffced67acc22f37046bf85a3fdb9&click_sum=88704106&ls=r&ref=related-1&content_source=8b84b565690ce7ebc38598f82b3339e2%253ALTc086e3392ac3ffced67acc22f37046bf85a3fdb9 "Red Barn Spring Aromatherapy Candles | 100% Natural Soy Essential Oil Infused | Pet Safe + Odor Eliminating + Relaxing | Toxin Free Candle")




Add to Favorites


- [![Red Barn Aromatherapy Candles | 100% Soy Wax & Essential Oil Infused | Pet Safe + Odor Eliminating | Scented Candle Gifts for Men and Women](https://i.etsystatic.com/22375113/c/869/691/360/44/il/ec92e5/3331869208/il_340x270.3331869208_1hz2.jpg)\\
\\
**Red Barn Aromatherapy Candles \| 100% Soy Wax & Essential Oil Infused \| Pet Safe + Odor Eliminating \| Scented Candle Gifts for Men and Women**\\
\\
$12.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/778609881/red-barn-aromatherapy-candles-100-soy?click_key=8b84b565690ce7ebc38598f82b3339e2%3ALT29cc4bef346f530928836e3b8a1232abd9bcd484&click_sum=0db46cc5&ls=r&ref=related-2&content_source=8b84b565690ce7ebc38598f82b3339e2%253ALT29cc4bef346f530928836e3b8a1232abd9bcd484 "Red Barn Aromatherapy Candles | 100% Soy Wax & Essential Oil Infused | Pet Safe + Odor Eliminating | Scented Candle Gifts for Men and Women")




Add to Favorites


- [![Red Barn Fall Aromatherapy Candles | All-Natural Soy Wax & Dried Flowers | Essential Oil Infused | Odor Eliminate + Relaxation | Toxin Free](https://i.etsystatic.com/22375113/c/1587/1261/149/0/il/75c791/5271471476/il_340x270.5271471476_n47z.jpg)\\
\\
**Red Barn Fall Aromatherapy Candles \| All-Natural Soy Wax & Dried Flowers \| Essential Oil Infused \| Odor Eliminate + Relaxation \| Toxin Free**\\
\\
$12.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/806750422/red-barn-fall-aromatherapy-candles-all?click_key=8b84b565690ce7ebc38598f82b3339e2%3ALT885c90e78b243ce68cec0af538a25dcae3344ae3&click_sum=466e3250&ls=r&ref=related-3&content_source=8b84b565690ce7ebc38598f82b3339e2%253ALT885c90e78b243ce68cec0af538a25dcae3344ae3 "Red Barn Fall Aromatherapy Candles | All-Natural Soy Wax & Dried Flowers | Essential Oil Infused | Odor Eliminate + Relaxation | Toxin Free")




Add to Favorites


- [![Fall Candles 100% Natural Soy Wax & Essential Oil Infused | Odor Eliminating + Pet Safe | Toxin / Paraffin Free | Red Barn Scented Candle](https://i.etsystatic.com/22375113/c/1587/1261/138/0/il/49ec6b/5271469188/il_340x270.5271469188_n47z.jpg)\\
\\
**Fall Candles 100% Natural Soy Wax & Essential Oil Infused \| Odor Eliminating + Pet Safe \| Toxin / Paraffin Free \| Red Barn Scented Candle**\\
\\
$12.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1562515251/fall-candles-100-natural-soy-wax?click_key=8b84b565690ce7ebc38598f82b3339e2%3ALTea5d9162a7252ef29e36cbaddcad7dd1b4dfe535&click_sum=6874fb7a&ls=r&ref=related-4&content_source=8b84b565690ce7ebc38598f82b3339e2%253ALTea5d9162a7252ef29e36cbaddcad7dd1b4dfe535 "Fall Candles 100% Natural Soy Wax & Essential Oil Infused | Odor Eliminating + Pet Safe | Toxin / Paraffin Free | Red Barn Scented Candle")




Add to Favorites



Loading...

Loading


**Disclaimer:** Button/coin batteries may cause serious injury and even death if swallowed. Items containing button/coin batteries should not be easily accessible without the use of a tool. Sellers are responsible for complying with all applicable labeling, design, testing, packaging, and other safety requirements. Etsy assumes no responsibility for the accuracy or contents of a seller’s listing. If you have questions about button/coin batteries, contact the seller by sending a Message. See Etsy's [Terms of Use](https://www.etsy.com/legal/terms-of-use/?ref=product_safety_banner_info_button_batteries_risk#warranties) for more information.

Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Sep 5, 2025


[2066 favorites](https://www.etsy.com/listing/781373519/lavender-aromatherapy-candle-100-natural/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?utm_source=openai&explicit=1&ref=breadcrumb_listing)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F781373519%2Flavender-aromatherapy-candle-100-natural%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc4NjU3NDo4Yjk4ODViMmU2NGRiNDgwNTJkOTEzYjA2YzM3ZmQyYQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F781373519%2Flavender-aromatherapy-candle-100-natural%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/781373519/lavender-aromatherapy-candle-100-natural?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F781373519%2Flavender-aromatherapy-candle-100-natural%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Seller details

### Business registration number

### Location

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=272850178&referring_id=22375113&referring_type=shop&recipient_id=272850178&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Item in the photo is in **Scent: Lavender**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Scent: Honeysuckle**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Scent: Sage & Citrus**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Scent: Vanilla Latte**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Scent: Flower Shop**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Scent: Eucalyptus Spearmint**




Select this option








Option selected!













This option is sold out.



Click to zoom

- ![May include: A white candle in a clear glass jar with a brown label that reads 'Red Barn Candle Company' and 'LAVENDER' in a decorative font. The candle is lit and the flame is visible. The candle is sitting on a wooden surface with a bunch of dried lavender flowers in the foreground.](https://i.etsystatic.com/22375113/c/1215/1215/62/0/il/623a6b/2349336692/il_300x300.2349336692_qfa2.jpg)
- ![May include: A clear glass jar candle with a white wax candle inside. The candle has a brown paper label with black text that reads 'Red Barn Candle Company' and 'Honeysuckle' in a larger font. The label also has a small pink house illustration and the text 'Handmade in the U.S.A.'](https://i.etsystatic.com/22375113/r/il/39ded3/2348009748/il_300x300.2348009748_du2q.jpg)
- ![May include: A clear glass candle jar with a white candle inside. The candle is lit and the flame is visible. The jar has a brown label with the text 'Red Barn Candle Company' and 'Sage & Citrus' printed on it. The candle is surrounded by dried orange peels and a bundle of sage.](https://i.etsystatic.com/22375113/r/il/d28ef0/2349362394/il_300x300.2349362394_p9ae.jpg)
- ![May include: A clear glass jar candle with a brown label that reads 'Red Barn Candle Company Vanilla Latte Handmade in the U.S.A.' The candle is lit and the flame is visible. The candle is surrounded by coffee beans.](https://i.etsystatic.com/22375113/r/il/1e5b06/2396953479/il_300x300.2396953479_belo.jpg)
- ![May include: A white candle in a clear glass jar with a white label that says 'Red Barn Candle Company' and 'Flower Shop' in black text. The candle is surrounded by dried rose petals.](https://i.etsystatic.com/22375113/r/il/987512/2349362132/il_300x300.2349362132_fivt.jpg)
- ![May include: A clear glass jar candle with a white label that reads 'Red Barn Candle Company Eucalyptus Spearmint Handmade in the U.S.A.' The candle is lit and the flame is visible. There are green leaves on the table next to the candle.](https://i.etsystatic.com/22375113/r/il/3fc6c5/2405440820/il_300x300.2405440820_i234.jpg)
- ![May include: Five glass candle jars with gold lids and labels. The labels are brown with white text and a black and white illustration of a farmhouse. The candles are arranged in a row from left to right: Flower Shop, Sage & Citrus, Lavender, Vanilla Latte, Cedarwood. The candles are surrounded by dried flower petals, lavender, and wood shavings.](https://i.etsystatic.com/22375113/r/il/5765cd/2577710689/il_300x300.2577710689_f3ku.jpg)
- ![May include: Three glass jars with white candle wax inside. Each jar has a brown paper label with a red barn and fall foliage design. The labels read 'Pumpkin Spice', 'Apple Cinnamon', and 'Mulled Cider'. The jars are surrounded by cinnamon sticks, apples, and fall-colored berries.](https://i.etsystatic.com/22375113/r/il/13d002/2530056720/il_300x300.2530056720_hc6n.jpg)
- ![May include: Three glass jars with gold lids and white labels. The labels have a red barn illustration and text that reads 'Red Barn Candle Company.' The jars are filled with white candle wax. The jars are arranged from left to right: 'Frankincense & Myrrh', 'Christmas Tree', and 'Gingerbread'. The jars are surrounded by pine cones, holly berries, and other Christmas decorations.](https://i.etsystatic.com/22375113/r/il/92026f/2577710969/il_300x300.2577710969_f7jj.jpg)
- ![May include: Three glass jars with white candles and dried flowers inside. The jars have labels with the words 'Sacred Smudge', 'Tranquility', and 'Positive Energy'.](https://i.etsystatic.com/22375113/r/il/d26cc8/2952115486/il_300x300.2952115486_5wp1.jpg)