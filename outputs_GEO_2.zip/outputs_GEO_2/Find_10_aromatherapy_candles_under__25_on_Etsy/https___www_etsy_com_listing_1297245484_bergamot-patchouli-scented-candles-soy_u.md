[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1297245484/bergamot-patchouli-soy-candle?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?utm_source=openai&explicit=1&ref=catnav_breadcrumb-3)
- [Container Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/container-candles?utm_source=openai&explicit=1&ref=catnav_breadcrumb-4)

This shop is taking a short break.

![](https://i.etsystatic.com/10787172/c/1652/1652/79/347/il/7bf69c/7171256245/il_680x540.7171256245_sk11.jpg)

This shop is taking a short break.

[LCCandleCottage](https://www.etsy.com/shop/LCCandleCottage?ref=nla_listing_details)5 out of 5 stars(2,346)2,346 reviews

Bergamot Patchouli Soy Candle: Aromatherapy Essential Oil Candle, 60 Hour Burn


$18.00

[Email me when they're back](https://www.etsy.com/shop/LCCandleCottage?ref=nla_vacation_cta) [See item details](https://www.etsy.com/listing/1297245484/bergamot-patchouli-soy-candle?show_sold_out_detail=1&ref=nla_listing_details)

[Email me when they're back](https://www.etsy.com/shop/LCCandleCottage?ref=nla_vacation_cta) [See item details](https://www.etsy.com/listing/1297245484/bergamot-patchouli-soy-candle?show_sold_out_detail=1&ref=nla_listing_details)

### Similar items on Etsy

(Results include adsLearn more
Sellers looking to grow their business and reach more interested buyers can use Etsy’s advertising platform to promote their items. You’ll see ad results based on factors like relevancy, and the amount sellers pay per click. [Learn more](https://www.etsy.com/legal/policy/search-advertisement-ranking-disclosures/899478564529).
)

- [![Patchouli Soy Candle - Candle Gift - Scented Candle - Farmhouse Decor](https://i.etsystatic.com/21704500/c/1904/1514/40/1123/il/ffd6f8/2473846090/il_340x270.2473846090_kygg.jpg)\\
\\
**Patchouli Soy Candle - Candle Gift - Scented Candle - Farmhouse Decor**\\
\\
ad vertisement by 3SistersCandleCo\\
Advertisement from shop 3SistersCandleCo\\
3SistersCandleCo\\
From shop 3SistersCandleCo\\
\\
$5.99\\
\\
Free shipping eligible](https://www.etsy.com/listing/856415175/patchouli-soy-candle-candle-gift-scented?click_key=LT1eb47986a205b335c7792d053239efbb962bd0a8%3A856415175&click_sum=e18f509f&ls=a&ref=sold_out_ad-1&frs=1 "Patchouli Soy Candle - Candle Gift - Scented Candle - Farmhouse Decor")





Add to Favorites


- [![Cedarwood Rosemary Soy Candle: Aromatherapy Essential Oil, Dried Flowers](https://i.etsystatic.com/22361469/r/il/f4ebef/4105036121/il_340x270.4105036121_t8sn.jpg)\\
\\
**Cedarwood Rosemary Soy Candle: Aromatherapy Essential Oil, Dried Flowers**\\
\\
ad vertisement by MadgeCandleStore\\
Advertisement from shop MadgeCandleStore\\
MadgeCandleStore\\
From shop MadgeCandleStore\\
\\
$18.00](https://www.etsy.com/listing/828107872/cedarwood-rosemary-soy-candle?click_key=LT11e1260e4a13b2507bd168906ee149c4e4ef384f%3A828107872&click_sum=93a3509a&ls=a&ref=sold_out_ad-2 "Cedarwood Rosemary Soy Candle: Aromatherapy Essential Oil, Dried Flowers")





Add to Favorites


- [![Patchouli Soy Candle - 13.6 oz](https://i.etsystatic.com/24163907/r/il/3f164d/5234311529/il_340x270.5234311529_cgi8.jpg)\\
\\
**Patchouli Soy Candle - 13.6 oz**\\
\\
ad vertisement by EssentialMasonCandle\\
Advertisement from shop EssentialMasonCandle\\
EssentialMasonCandle\\
From shop EssentialMasonCandle\\
\\
Sale Price $15.40\\
$15.40\\
\\
$22.00\\
Original Price $22.00\\
\\
\\
(30% off)\\
\\
\\
\\
Free shipping eligible](https://www.etsy.com/listing/1042333830/patchouli-soy-candle-136-oz?click_key=LT9561f2c3834788ba7c996bab30e8bd6ce04f48f7%3A1042333830&click_sum=c4f0a4f8&ls=a&ref=sold_out_ad-3&pro=1&frs=1&sts=1 "Patchouli Soy Candle - 13.6 oz")





Add to Favorites


- [![Palo Santo Patchouli: Masculine Scented Soy Wax Candle](https://i.etsystatic.com/27721615/r/il/a69978/6889007531/il_340x270.6889007531_9eic.jpg)\\
\\
**Palo Santo Patchouli: Masculine Scented Soy Wax Candle**\\
\\
ad vertisement by CherishedCandleCo\\
Advertisement from shop CherishedCandleCo\\
CherishedCandleCo\\
From shop CherishedCandleCo\\
\\
Sale Price $12.60\\
$12.60\\
\\
$14.00\\
Original Price $14.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/4301199301/palo-santo-patchouli-masculine-scented?click_key=LT406bebdf729eff2523e31e664d56c5a6fa014d49%3A4301199301&click_sum=e00a6643&ls=a&ref=sold_out_ad-4&pro=1&sts=1 "Palo Santo Patchouli: Masculine Scented Soy Wax Candle")





Add to Favorites


- [![Soy Candle, 9 oz: Clean Burning Cotton Wick, Phthalate-Free Scents](https://i.etsystatic.com/26819582/r/il/039eba/4150693291/il_340x270.4150693291_2lv1.jpg)\\
\\
**Soy Candle, 9 oz: Clean Burning Cotton Wick, Phthalate-Free Scents**\\
\\
ad vertisement by MillerFarmCandleCo\\
Advertisement from shop MillerFarmCandleCo\\
MillerFarmCandleCo\\
From shop MillerFarmCandleCo\\
\\
Sale Price $12.75\\
$12.75\\
\\
$15.00\\
Original Price $15.00\\
\\
\\
(15% off)\\
\\
\\
\\
Free shipping eligible](https://www.etsy.com/listing/1043843780/soy-candle-9-oz-clean-burning-cotton?click_key=LTd987faf5bb8858754872b28b312b5768c70939cb%3A1043843780&click_sum=8fe87f91&ls=a&ref=sold_out_ad-5&pro=1&frs=1&sts=1 "Soy Candle, 9 oz: Clean Burning Cotton Wick, Phthalate-Free Scents")





Add to Favorites


- [![Palo Santo Patchouli Candle - Aromatherapy Candle, Scented Candle for Home Decor - Gift for Her - Spa Candle Relaxing Candle - Housewarming](https://i.etsystatic.com/10385964/c/1503/1503/241/113/il/da585f/6996588981/il_340x270.6996588981_srd8.jpg)\\
\\
**Palo Santo Patchouli Candle - Aromatherapy Candle, Scented Candle for Home Decor - Gift for Her - Spa Candle Relaxing Candle - Housewarming**\\
\\
ad vertisement by sweetwaterdecor\\
Advertisement from shop sweetwaterdecor\\
sweetwaterdecor\\
From shop sweetwaterdecor\\
\\
Sale Price $22.80\\
$22.80\\
\\
$24.00\\
Original Price $24.00\\
\\
\\
(5% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1456598297/palo-santo-patchouli-candle-aromatherapy?click_key=LT86e1e850c254fab9b11113a6ee962a5c7c0d7b45%3A1456598297&click_sum=7383b13f&ls=a&ref=sold_out_ad-6&pro=1&frs=1&sts=1 "Palo Santo Patchouli Candle - Aromatherapy Candle, Scented Candle for Home Decor - Gift for Her - Spa Candle Relaxing Candle - Housewarming")





Add to Favorites


- [![Essential Oil Beeswax Candles: Amber Jar, Hand-Poured on Cape Cod, MA](https://i.etsystatic.com/24951730/c/2108/2108/370/0/il/65fb79/7262447602/il_340x270.7262447602_rev7.jpg)\\
\\
**Essential Oil Beeswax Candles: Amber Jar, Hand-Poured on Cape Cod, MA**\\
\\
ad vertisement by AireCandleCo\\
Advertisement from shop AireCandleCo\\
AireCandleCo\\
From shop AireCandleCo\\
\\
$25.00\\
\\
Free shipping eligible](https://www.etsy.com/listing/1266945839/essential-oil-beeswax-candles-amber-jar?click_key=686b4823448910dd7ea9c8691d802e3b%3ALTd0b704c1e1b1f7a61048200da12047615ad03250&click_sum=9f19a66b&ls=r&ref=sold_out-1&frs=1&sts=1&content_source=686b4823448910dd7ea9c8691d802e3b%253ALTd0b704c1e1b1f7a61048200da12047615ad03250 "Essential Oil Beeswax Candles: Amber Jar, Hand-Poured on Cape Cod, MA")





Add to Favorites


- [![Lavender Essential Oil Candle | Scented Soy Candle |Soy Candle | Essential Oil | Wax Melts](https://i.etsystatic.com/14701240/r/il/36028f/3734243683/il_340x270.3734243683_1w5g.jpg)\\
\\
**Lavender Essential Oil Candle \| Scented Soy Candle \|Soy Candle \| Essential Oil \| Wax Melts**\\
\\
ad vertisement by MasonJarCandlesCo\\
Advertisement from shop MasonJarCandlesCo\\
MasonJarCandlesCo\\
From shop MasonJarCandlesCo\\
\\
$3.50\\
\\
Free shipping eligible](https://www.etsy.com/listing/588409347/lavender-essential-oil-candle-scented?click_key=686b4823448910dd7ea9c8691d802e3b%3ALTff17f00ec259a4e56fba9fafb845cbcd0625d7c5&click_sum=2e172c8f&ls=r&ref=sold_out-2&frs=1&content_source=686b4823448910dd7ea9c8691d802e3b%253ALTff17f00ec259a4e56fba9fafb845cbcd0625d7c5 "Lavender Essential Oil Candle | Scented Soy Candle |Soy Candle | Essential Oil | Wax Melts")





Add to Favorites


- [![Lilac Candle in Recycled Glass | 8oz Hand-Poured Coco-Soy Wax | Wooden Wick Floral Scented Gift](https://i.etsystatic.com/5552603/r/il/516489/7423589723/il_340x270.7423589723_2kps.jpg)\\
\\
**Lilac Candle in Recycled Glass \| 8oz Hand-Poured Coco-Soy Wax \| Wooden Wick Floral Scented Gift**\\
\\
ad vertisement by ChasingRelicsLLC\\
Advertisement from shop ChasingRelicsLLC\\
ChasingRelicsLLC\\
From shop ChasingRelicsLLC\\
\\
$32.00\\
\\
Eligible orders get 25% off\\
\\
Spend $75.00 to get 25% off your order\\
\\
\\
\\
Free shipping eligible](https://www.etsy.com/listing/4304287829/lilac-candle-in-recycled-glass-8oz-hand?click_key=686b4823448910dd7ea9c8691d802e3b%3ALT692de0a4c3843747d5133e076ea7b57611e8d847&click_sum=49771895&ls=r&ref=sold_out-3&pro=1&frs=1&content_source=686b4823448910dd7ea9c8691d802e3b%253ALT692de0a4c3843747d5133e076ea7b57611e8d847 "Lilac Candle in Recycled Glass | 8oz Hand-Poured Coco-Soy Wax | Wooden Wick Floral Scented Gift")





Add to Favorites


- [![100% Soy Candles](https://i.etsystatic.com/27982526/r/il/7543c8/3094371995/il_340x270.3094371995_jxuc.jpg)\\
\\
**100% Soy Candles**\\
\\
ad vertisement by 906CandleCo\\
Advertisement from shop 906CandleCo\\
906CandleCo\\
From shop 906CandleCo\\
\\
$10.50\\
\\
FREE shipping](https://www.etsy.com/listing/957473340/100-soy-candles?click_key=686b4823448910dd7ea9c8691d802e3b%3ALT2cf91d026b752a1f8ec993e74d9d8f833d98826f&click_sum=d46caed8&ls=r&ref=sold_out-4&frs=1&content_source=686b4823448910dd7ea9c8691d802e3b%253ALT2cf91d026b752a1f8ec993e74d9d8f833d98826f "100% Soy Candles")





Add to Favorites


- [![Soy Wax Candle: Essential Oils, Aromatherapy, Non-Toxic Burn, 6oz, Over 50 Scents](https://i.etsystatic.com/58356002/r/il/80e7e9/6891616367/il_340x270.6891616367_9gqb.jpg)\\
\\
**Soy Wax Candle: Essential Oils, Aromatherapy, Non-Toxic Burn, 6oz, Over 50 Scents**\\
\\
ad vertisement by Awakenedaroma\\
Advertisement from shop Awakenedaroma\\
Awakenedaroma\\
From shop Awakenedaroma\\
\\
$12.00\\
\\
Free shipping eligible](https://www.etsy.com/listing/4301725321/soy-wax-candle-essential-oils?click_key=686b4823448910dd7ea9c8691d802e3b%3ALT09fe616f71524227d389c63ac71847d42fe06a49&click_sum=6b30502d&ls=r&ref=sold_out-5&frs=1&sts=1&content_source=686b4823448910dd7ea9c8691d802e3b%253ALT09fe616f71524227d389c63ac71847d42fe06a49 "Soy Wax Candle: Essential Oils, Aromatherapy, Non-Toxic Burn, 6oz, Over 50 Scents")





Add to Favorites


- [![Essential Oil Soy Candles | Aromatherapy Candles | Lavender, Eucalyptus, Peppermint, Frankincense Myrrh, Patchouli | Natural Soy Wax Candles](https://i.etsystatic.com/8065711/r/il/10a55b/6237784327/il_340x270.6237784327_zj7i.jpg)\\
\\
**Essential Oil Soy Candles \| Aromatherapy Candles \| Lavender, Eucalyptus, Peppermint, Frankincense Myrrh, Patchouli \| Natural Soy Wax Candles**\\
\\
ad vertisement by NaturesQuestShop\\
Advertisement from shop NaturesQuestShop\\
NaturesQuestShop\\
From shop NaturesQuestShop\\
\\
$16.99](https://www.etsy.com/listing/733084610/essential-oil-soy-candles-aromatherapy?click_key=686b4823448910dd7ea9c8691d802e3b%3ALT434ec2bb231a66d3ed12dfc5fd3b4979422247c1&click_sum=77a2d14e&ls=r&ref=sold_out-6&content_source=686b4823448910dd7ea9c8691d802e3b%253ALT434ec2bb231a66d3ed12dfc5fd3b4979422247c1 "Essential Oil Soy Candles | Aromatherapy Candles | Lavender, Eucalyptus, Peppermint, Frankincense Myrrh, Patchouli | Natural Soy Wax Candles")





Add to Favorites


- [![Desert Drift  Linen Spray](https://i.etsystatic.com/32729499/r/il/04751a/7275718559/il_340x270.7275718559_ry7g.jpg)\\
\\
**Desert Drift Linen Spray**\\
\\
ad vertisement by naturellivingco\\
Advertisement from shop naturellivingco\\
naturellivingco\\
From shop naturellivingco\\
\\
$30.00\\
\\
FREE shipping](https://www.etsy.com/listing/1417698973/desert-drift-linen-spray?click_key=686b4823448910dd7ea9c8691d802e3b%3ALT98033933a1a6c8484bd4dfa81995c650001e16f7&click_sum=a206f585&ls=r&ref=sold_out-7&frs=1&content_source=686b4823448910dd7ea9c8691d802e3b%253ALT98033933a1a6c8484bd4dfa81995c650001e16f7 "Desert Drift  Linen Spray")





Add to Favorites


- [![Vegan Candied Citrus Peels: Gourmet Lemon, Orange, Grapefruit (6oz)](https://i.etsystatic.com/6043915/r/il/24ebea/2260890158/il_340x270.2260890158_2mrk.jpg)\\
\\
**Vegan Candied Citrus Peels: Gourmet Lemon, Orange, Grapefruit (6oz)**\\
\\
ad vertisement by TouteDouceurCandy\\
Advertisement from shop TouteDouceurCandy\\
TouteDouceurCandy\\
From shop TouteDouceurCandy\\
\\
$16.50\\
\\
Free shipping eligible](https://www.etsy.com/listing/617581805/vegan-candied-citrus-peels-gourmet-lemon?click_key=686b4823448910dd7ea9c8691d802e3b%3ALT130b338781a128a1e5bae0b9376c90ccc7a503ef&click_sum=77cd3359&ls=r&ref=sold_out-8&frs=1&content_source=686b4823448910dd7ea9c8691d802e3b%253ALT130b338781a128a1e5bae0b9376c90ccc7a503ef "Vegan Candied Citrus Peels: Gourmet Lemon, Orange, Grapefruit (6oz)")





Add to Favorites


- [![Botanical Beeswax Wood Bowl Candle: Crackling Wood Wick, Essential Oil Infusion](https://i.etsystatic.com/14950143/r/il/e4d8be/5972393799/il_340x270.5972393799_d845.jpg)\\
\\
**Botanical Beeswax Wood Bowl Candle: Crackling Wood Wick, Essential Oil Infusion**\\
\\
ad vertisement by SloanFamilyFarms\\
Advertisement from shop SloanFamilyFarms\\
SloanFamilyFarms\\
From shop SloanFamilyFarms\\
\\
$31.00\\
\\
FREE shipping](https://www.etsy.com/listing/1435934812/botanical-beeswax-wood-bowl-candle?click_key=686b4823448910dd7ea9c8691d802e3b%3ALT19b68f52f12d6d32a19173d69a3bcfda89350fdb&click_sum=a4f26907&ls=r&ref=sold_out-9&frs=1&sts=1&content_source=686b4823448910dd7ea9c8691d802e3b%253ALT19b68f52f12d6d32a19173d69a3bcfda89350fdb "Botanical Beeswax Wood Bowl Candle: Crackling Wood Wick, Essential Oil Infusion")





Add to Favorites


- [![Handcrafted Lemon Lavender Candle: Organic Beeswax Aromatherapy](https://i.etsystatic.com/23148087/r/il/8a2f0e/6774354620/il_340x270.6774354620_qnct.jpg)\\
\\
**Handcrafted Lemon Lavender Candle: Organic Beeswax Aromatherapy**\\
\\
ad vertisement by NewDawnElements\\
Advertisement from shop NewDawnElements\\
NewDawnElements\\
From shop NewDawnElements\\
\\
Sale Price $13.50\\
$13.50\\
\\
$18.00\\
Original Price $18.00\\
\\
\\
(25% off)\\
\\
\\
\\
Free shipping eligible](https://www.etsy.com/listing/996710794/handcrafted-lemon-lavender-candle?click_key=686b4823448910dd7ea9c8691d802e3b%3ALT1b8b1ac98e6e4756f70ea31964ed4804b2964485&click_sum=38c9ca04&ls=r&ref=sold_out-10&pro=1&frs=1&sts=1&content_source=686b4823448910dd7ea9c8691d802e3b%253ALT1b8b1ac98e6e4756f70ea31964ed4804b2964485 "Handcrafted Lemon Lavender Candle: Organic Beeswax Aromatherapy")





Add to Favorites


- [![Winter Spice Soy Candle, Organic Essential Oils, Handmade Bowl Candle](https://i.etsystatic.com/23090474/r/il/ee75d6/6415296443/il_340x270.6415296443_ei51.jpg)\\
\\
**Winter Spice Soy Candle, Organic Essential Oils, Handmade Bowl Candle**\\
\\
ad vertisement by MyZeroWasteFamStore\\
Advertisement from shop MyZeroWasteFamStore\\
MyZeroWasteFamStore\\
From shop MyZeroWasteFamStore\\
\\
Sale Price $17.99\\
$17.99\\
\\
$19.99\\
Original Price $19.99\\
\\
\\
(10% off)\\
\\
\\
\\
Free shipping eligible](https://www.etsy.com/listing/1812995807/winter-spice-soy-candle-organic?click_key=686b4823448910dd7ea9c8691d802e3b%3ALT84a0575e60b08133cc5881c34aa4ff245f1018a0&click_sum=353fadac&ls=r&ref=sold_out-11&pro=1&frs=1&content_source=686b4823448910dd7ea9c8691d802e3b%253ALT84a0575e60b08133cc5881c34aa4ff245f1018a0 "Winter Spice Soy Candle, Organic Essential Oils, Handmade Bowl Candle")





Add to Favorites


- [![Eucalyptus Soy Container Candle made with Essential Oil (9oz. Jar or 6oz. Tin)](https://i.etsystatic.com/56585878/r/il/b72de7/6674958917/il_340x270.6674958917_s2a3.jpg)\\
\\
**Eucalyptus Soy Container Candle made with Essential Oil (9oz. Jar or 6oz. Tin)**\\
\\
ad vertisement by CandleCadabraCom\\
Advertisement from shop CandleCadabraCom\\
CandleCadabraCom\\
From shop CandleCadabraCom\\
\\
$22.00](https://www.etsy.com/listing/1856564730/eucalyptus-soy-container-candle-made?click_key=686b4823448910dd7ea9c8691d802e3b%3ALT39e9005b6066e10919f80d56a5412e2f766dd63d&click_sum=4e8b1495&ls=r&ref=sold_out-12&content_source=686b4823448910dd7ea9c8691d802e3b%253ALT39e9005b6066e10919f80d56a5412e2f766dd63d "Eucalyptus Soy Container Candle made with Essential Oil (9oz. Jar or 6oz. Tin)")





Add to Favorites


- [![Fall Candle Sampler Pack: Autumn Scented Soy Candle Gift Set](https://i.etsystatic.com/18428417/r/il/ae88c7/6114221055/il_340x270.6114221055_84wk.jpg)\\
\\
**Fall Candle Sampler Pack: Autumn Scented Soy Candle Gift Set**\\
\\
ad vertisement by MLTDCandleCompany\\
Advertisement from shop MLTDCandleCompany\\
MLTDCandleCompany\\
From shop MLTDCandleCompany\\
\\
$35.00\\
\\
FREE shipping](https://www.etsy.com/listing/1277472803/fall-candle-sampler-pack-autumn-scented?click_key=686b4823448910dd7ea9c8691d802e3b%3ALTc6c68b5fdfebd02b93c5dfba4a43855dbb4e23fe&click_sum=8c30ae98&ls=r&ref=sold_out-13&frs=1&sts=1&content_source=686b4823448910dd7ea9c8691d802e3b%253ALTc6c68b5fdfebd02b93c5dfba4a43855dbb4e23fe "Fall Candle Sampler Pack: Autumn Scented Soy Candle Gift Set")





Add to Favorites


- [![Natural Soy Wax Jar Candle Hand Poured in VT Clean Burning Cotton Wick 12 oz Jar Made by Making Scents Organics](https://i.etsystatic.com/11899299/r/il/502897/7369645264/il_340x270.7369645264_f44h.jpg)\\
\\
**Natural Soy Wax Jar Candle Hand Poured in VT Clean Burning Cotton Wick 12 oz Jar Made by Making Scents Organics**\\
\\
ad vertisement by MakingScentsOrganic\\
Advertisement from shop MakingScentsOrganic\\
MakingScentsOrganic\\
From shop MakingScentsOrganic\\
\\
$21.99](https://www.etsy.com/listing/651704033/natural-soy-wax-jar-candle-hand-poured?click_key=686b4823448910dd7ea9c8691d802e3b%3ALT04e163ec68692775f2a367c68cc26c375a2795df&click_sum=e97f8f5d&ls=r&ref=sold_out-14&bes=1&sts=1&content_source=686b4823448910dd7ea9c8691d802e3b%253ALT04e163ec68692775f2a367c68cc26c375a2795df "Natural Soy Wax Jar Candle Hand Poured in VT Clean Burning Cotton Wick 12 oz Jar Made by Making Scents Organics")





Add to Favorites


- [![Crystals & Herbs Tealight Candles - Soy Candles - Aromatherapy Candles - Scented Soy Tealights - Crystal Candles - Handmade Candle Gift!](https://i.etsystatic.com/9859922/r/il/353af2/4044686790/il_340x270.4044686790_9ymr.jpg)\\
\\
**Crystals & Herbs Tealight Candles - Soy Candles - Aromatherapy Candles - Scented Soy Tealights - Crystal Candles - Handmade Candle Gift!**\\
\\
ad vertisement by NewMoonBeginnings\\
Advertisement from shop NewMoonBeginnings\\
NewMoonBeginnings\\
From shop NewMoonBeginnings\\
\\
$9.99\\
\\
Free shipping eligible](https://www.etsy.com/listing/538018885/crystals-herbs-tealight-candles-soy?click_key=686b4823448910dd7ea9c8691d802e3b%3ALT8ebcbd913377029b38feb7d60bde63275d01ffa8&click_sum=c4e0f47a&ls=r&ref=sold_out-15&frs=1&sts=1&content_source=686b4823448910dd7ea9c8691d802e3b%253ALT8ebcbd913377029b38feb7d60bde63275d01ffa8 "Crystals & Herbs Tealight Candles - Soy Candles - Aromatherapy Candles - Scented Soy Tealights - Crystal Candles - Handmade Candle Gift!")





Add to Favorites


- [![Bourbon Candied Pecans: Fireside Colorado Gourmet Nuts](https://i.etsystatic.com/6043915/r/il/d381d8/3519725031/il_340x270.3519725031_7zvz.jpg)\\
\\
**Bourbon Candied Pecans: Fireside Colorado Gourmet Nuts**\\
\\
ad vertisement by TouteDouceurCandy\\
Advertisement from shop TouteDouceurCandy\\
TouteDouceurCandy\\
From shop TouteDouceurCandy\\
\\
$9.00\\
\\
Free shipping eligible](https://www.etsy.com/listing/758018088/bourbon-candied-pecans-fireside-colorado?click_key=686b4823448910dd7ea9c8691d802e3b%3ALT5a381effffe27ce71010a3f12ee8d56b0a02cc79&click_sum=48369171&ls=r&ref=sold_out-16&frs=1&content_source=686b4823448910dd7ea9c8691d802e3b%253ALT5a381effffe27ce71010a3f12ee8d56b0a02cc79 "Bourbon Candied Pecans: Fireside Colorado Gourmet Nuts")





Add to Favorites


- [![Lavender & Rosewood scented two-wick scented with soy candle 100% essential oils](https://i.etsystatic.com/33603250/r/il/2ead78/3606681446/il_340x270.3606681446_ny1a.jpg)\\
\\
**Lavender & Rosewood scented two-wick scented with soy candle 100% essential oils**\\
\\
ad vertisement by SoyCuteCandle\\
Advertisement from shop SoyCuteCandle\\
SoyCuteCandle\\
From shop SoyCuteCandle\\
\\
$20.00](https://www.etsy.com/listing/1162845667/lavender-rosewood-scented-two-wick?click_key=686b4823448910dd7ea9c8691d802e3b%3ALT9bf57a4c9c997713762dcb16d5672d9916c34b00&click_sum=c8b3bcdb&ls=r&ref=sold_out-17&content_source=686b4823448910dd7ea9c8691d802e3b%253ALT9bf57a4c9c997713762dcb16d5672d9916c34b00 "Lavender & Rosewood scented two-wick scented with soy candle 100% essential oils")





Add to Favorites


- [![Saffron & Cedarwood || 100% Soy Wax Candle](https://i.etsystatic.com/12271464/r/il/99533a/6159180494/il_340x270.6159180494_j8xi.jpg)\\
\\
**Saffron & Cedarwood \|\| 100% Soy Wax Candle**\\
\\
ad vertisement by TheEvergreensCo\\
Advertisement from shop TheEvergreensCo\\
TheEvergreensCo\\
From shop TheEvergreensCo\\
\\
$22.00](https://www.etsy.com/listing/1755800680/saffron-cedarwood-100-soy-wax-candle?click_key=686b4823448910dd7ea9c8691d802e3b%3ALT0e39cafa67055dd584eebfdea0b6120cd40962e7&click_sum=65c00373&ls=r&ref=sold_out-18&content_source=686b4823448910dd7ea9c8691d802e3b%253ALT0e39cafa67055dd584eebfdea0b6120cd40962e7 "Saffron & Cedarwood || 100% Soy Wax Candle")





Add to Favorites


- [![Lavender Haze Relaxation Essential Oil Soy Candle, Lily & Hibiscus Sparkle Wood Wick Candle, Odor Eliminate,  Aromatherapy Gift for Her](https://i.etsystatic.com/16745835/c/1630/1295/306/668/il/1ca94a/5379032189/il_340x270.5379032189_3g0i.jpg)\\
\\
**Lavender Haze Relaxation Essential Oil Soy Candle, Lily & Hibiscus Sparkle Wood Wick Candle, Odor Eliminate, Aromatherapy Gift for Her**\\
\\
ad vertisement by JustEnoughCharm\\
Advertisement from shop JustEnoughCharm\\
JustEnoughCharm\\
From shop JustEnoughCharm\\
\\
$26.99\\
\\
Free shipping eligible](https://www.etsy.com/listing/1574757389/lavender-haze-relaxation-essential-oil?click_key=LT4c3dc24e0e1bb50e98e0543a189127aef2b5d2d6%3A1574757389&click_sum=c0c30e21&ls=a&ref=sold_out_ad-7&frs=1 "Lavender Haze Relaxation Essential Oil Soy Candle, Lily & Hibiscus Sparkle Wood Wick Candle, Odor Eliminate,  Aromatherapy Gift for Her")





Add to Favorites


- [![Orange Clove Botanical Aromatherapy Soy Candle, All Natural-100% Essential Oil](https://i.etsystatic.com/25465169/r/il/96d335/2571453764/il_340x270.2571453764_2jc5.jpg)\\
\\
**Orange Clove Botanical Aromatherapy Soy Candle, All Natural-100% Essential Oil**\\
\\
ad vertisement by MateriaBotanica\\
Advertisement from shop MateriaBotanica\\
MateriaBotanica\\
From shop MateriaBotanica\\
\\
$32.00\\
\\
Free shipping eligible](https://www.etsy.com/listing/882124379/orange-clove-botanical-aromatherapy-soy?click_key=LT9a538a23a2b69b7b81accbfaa19bed886c134c8e%3A882124379&click_sum=5cc7e8ae&ls=a&ref=sold_out_ad-8&frs=1&sts=1 "Orange Clove Botanical Aromatherapy Soy Candle, All Natural-100% Essential Oil")





Add to Favorites


- [![Patchouli Soy Candle: Handcrafted Aromatherapy, Non-Toxic](https://i.etsystatic.com/19407548/r/il/0f2184/5953685690/il_340x270.5953685690_5ypo.jpg)\\
\\
**Patchouli Soy Candle: Handcrafted Aromatherapy, Non-Toxic**\\
\\
ad vertisement by MooresCandleKitchen\\
Advertisement from shop MooresCandleKitchen\\
MooresCandleKitchen\\
From shop MooresCandleKitchen\\
\\
$13.00\\
\\
Free shipping eligible](https://www.etsy.com/listing/1666871740/patchouli-soy-candle-handcrafted?click_key=LT0c9b8f41d7cb057a592e3b43005cbfe8da211063%3A1666871740&click_sum=d6a97cb1&ls=a&ref=sold_out_ad-9&frs=1 "Patchouli Soy Candle: Handcrafted Aromatherapy, Non-Toxic")





Add to Favorites


- [![Patchouli Beeswax Candle | Patchouli Essential Oil | 100% Beeswax Candle with Essential Oils | Cotton Wick | Nontoxic and clean burning](https://i.etsystatic.com/29804820/r/il/ac6f45/6840871746/il_340x270.6840871746_7x68.jpg)\\
\\
**Patchouli Beeswax Candle \| Patchouli Essential Oil \| 100% Beeswax Candle with Essential Oils \| Cotton Wick \| Nontoxic and clean burning**\\
\\
ad vertisement by HeatherKayCandles\\
Advertisement from shop HeatherKayCandles\\
HeatherKayCandles\\
From shop HeatherKayCandles\\
\\
$30.00\\
\\
Free shipping eligible](https://www.etsy.com/listing/1516581188/patchouli-beeswax-candle-patchouli?click_key=LT481bccf0f4f1125832771f7ff57e59193b5c8791%3A1516581188&click_sum=01b5f497&ls=a&ref=sold_out_ad-10&frs=1 "Patchouli Beeswax Candle | Patchouli Essential Oil | 100% Beeswax Candle with Essential Oils | Cotton Wick | Nontoxic and clean burning")





Add to Favorites


- [![Bergamot Soy Wax Candle: Bitter Orange & Coriander](https://i.etsystatic.com/18169741/r/il/c0ccd4/6144190833/il_340x270.6144190833_jywk.jpg)\\
\\
**Bergamot Soy Wax Candle: Bitter Orange & Coriander**\\
\\
ad vertisement by WashAndWik\\
Advertisement from shop WashAndWik\\
WashAndWik\\
From shop WashAndWik\\
\\
$24.00\\
\\
Free shipping eligible](https://www.etsy.com/listing/1017060673/bergamot-soy-wax-candle-bitter-orange?click_key=LTe4a43b781c589833bde3f7700d551118507a40a2%3A1017060673&click_sum=1179bfe1&ls=a&ref=sold_out_ad-11&frs=1 "Bergamot Soy Wax Candle: Bitter Orange & Coriander")





Add to Favorites


- [![Essential Oil Soy Wax Candle: Aromatherapy, Non-Toxic Burn, 6oz New Fall scents!](https://i.etsystatic.com/58356002/r/il/abe65f/7032358141/il_340x270.7032358141_7qw5.jpg)\\
\\
**Essential Oil Soy Wax Candle: Aromatherapy, Non-Toxic Burn, 6oz New Fall scents!**\\
\\
ad vertisement by Awakenedaroma\\
Advertisement from shop Awakenedaroma\\
Awakenedaroma\\
From shop Awakenedaroma\\
\\
$12.00\\
\\
Free shipping eligible](https://www.etsy.com/listing/4328820195/essential-oil-soy-wax-candle?click_key=LTb66d82b749937a6ccdf1d13ec0c77563b247fbd1%3A4328820195&click_sum=3a86692b&ls=a&ref=sold_out_ad-12&frs=1&sts=1 "Essential Oil Soy Wax Candle: Aromatherapy, Non-Toxic Burn, 6oz New Fall scents!")





Add to Favorites


- [![Fresh Squeeze Wax Melts – Citrus Orange Scent in 3 oz Tin | Highly Scented Wax for Warmers](https://i.etsystatic.com/31552208/r/il/aaa184/6447796647/il_340x270.6447796647_e7dz.jpg)\\
\\
**Fresh Squeeze Wax Melts – Citrus Orange Scent in 3 oz Tin \| Highly Scented Wax for Warmers**\\
\\
ad vertisement by BettyBluScents\\
Advertisement from shop BettyBluScents\\
BettyBluScents\\
From shop BettyBluScents\\
\\
$14.99\\
\\
Free shipping eligible](https://www.etsy.com/listing/1200696893/fresh-squeeze-wax-melts-citrus-orange?click_key=686b4823448910dd7ea9c8691d802e3b%3ALT7b93f6ac669f1589c14500bd0409d16b50d0fa5b&click_sum=b7fbcc8b&ls=r&ref=sold_out-19&frs=1&sts=1&content_source=686b4823448910dd7ea9c8691d802e3b%253ALT7b93f6ac669f1589c14500bd0409d16b50d0fa5b "Fresh Squeeze Wax Melts – Citrus Orange Scent in 3 oz Tin | Highly Scented Wax for Warmers")





Add to Favorites


- [![Eucalyptus Aromatherapy Soy Candle: Organic Botanicals & Essential Oils](https://i.etsystatic.com/22361469/r/il/b1d425/4104952335/il_340x270.4104952335_5nr1.jpg)\\
\\
**Eucalyptus Aromatherapy Soy Candle: Organic Botanicals & Essential Oils**\\
\\
ad vertisement by MadgeCandleStore\\
Advertisement from shop MadgeCandleStore\\
MadgeCandleStore\\
From shop MadgeCandleStore\\
\\
$16.50](https://www.etsy.com/listing/1280014453/eucalyptus-aromatherapy-soy-candle?click_key=686b4823448910dd7ea9c8691d802e3b%3ALT893ca7ef964366bb8cc547c95d44e22ee7a440a2&click_sum=dd3d4963&ls=r&ref=sold_out-20&content_source=686b4823448910dd7ea9c8691d802e3b%253ALT893ca7ef964366bb8cc547c95d44e22ee7a440a2 "Eucalyptus Aromatherapy Soy Candle: Organic Botanicals & Essential Oils")





Add to Favorites


- [![MILK CONCH,  Sailors Valentines,  Craft Supplies, Vase Fillers, Bath Decor, Florist Supply, Large Natural Seashells, Wreath Supply, SS-437](https://i.etsystatic.com/45864717/r/il/7c2af5/6487941492/il_340x270.6487941492_d21n.jpg)\\
\\
**MILK CONCH, Sailors Valentines, Craft Supplies, Vase Fillers, Bath Decor, Florist Supply, Large Natural Seashells, Wreath Supply, SS-437**\\
\\
ad vertisement by FromPortToPort\\
Advertisement from shop FromPortToPort\\
FromPortToPort\\
From shop FromPortToPort\\
\\
Sale Price $19.67\\
$19.67\\
\\
$28.10\\
Original Price $28.10\\
\\
\\
(30% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1838878891/milk-conch-sailors-valentines-craft?click_key=686b4823448910dd7ea9c8691d802e3b%3ALT1667a4daf2328181882eafcfdf5c2c05f7fde901&click_sum=bc5fb8ec&ls=r&ref=sold_out-21&pro=1&frs=1&content_source=686b4823448910dd7ea9c8691d802e3b%253ALT1667a4daf2328181882eafcfdf5c2c05f7fde901 "MILK CONCH,  Sailors Valentines,  Craft Supplies, Vase Fillers, Bath Decor, Florist Supply, Large Natural Seashells, Wreath Supply, SS-437")





Add to Favorites


- [![Peppermint | Single-Note Aromatherapy Candle | Pure, Therapeutic-Grade Essential Oil | Soy Wax Candle in Ceramic Jar](https://i.etsystatic.com/27666227/r/il/d7fe58/4249124290/il_340x270.4249124290_gpx3.jpg)\\
\\
**Peppermint \| Single-Note Aromatherapy Candle \| Pure, Therapeutic-Grade Essential Oil \| Soy Wax Candle in Ceramic Jar**\\
\\
ad vertisement by ValiantCandle\\
Advertisement from shop ValiantCandle\\
ValiantCandle\\
From shop ValiantCandle\\
\\
$30.00\\
\\
Free shipping eligible](https://www.etsy.com/listing/1324603047/peppermint-single-note-aromatherapy?click_key=686b4823448910dd7ea9c8691d802e3b%3ALTdde1710d5330b79c6469d98431c01d374051d2c4&click_sum=406b0d67&ls=r&ref=sold_out-22&frs=1&sts=1&content_source=686b4823448910dd7ea9c8691d802e3b%253ALTdde1710d5330b79c6469d98431c01d374051d2c4 "Peppermint | Single-Note Aromatherapy Candle | Pure, Therapeutic-Grade Essential Oil | Soy Wax Candle in Ceramic Jar")





Add to Favorites


- [![Psychic Candle, Peppermint Candle, Psychic Abilities, Visionary Dreams, Intention Candle, Soy Candle, Fragrance Candle.](https://i.etsystatic.com/12281288/r/il/1b406d/2508082040/il_340x270.2508082040_85xh.jpg)\\
\\
**Psychic Candle, Peppermint Candle, Psychic Abilities, Visionary Dreams, Intention Candle, Soy Candle, Fragrance Candle.**\\
\\
ad vertisement by witchshopgypsyheaven\\
Advertisement from shop witchshopgypsyheaven\\
witchshopgypsyheaven\\
From shop witchshopgypsyheaven\\
\\
$9.95\\
\\
Only 2 available and it's in 1 person's cart](https://www.etsy.com/listing/851851264/psychic-candle-peppermint-candle-psychic?click_key=686b4823448910dd7ea9c8691d802e3b%3ALT1adfed2057cc3ecc8c03dadc7944f85ea1981ae9&click_sum=858b0b24&ls=r&ref=sold_out-23&cns=1&sts=1&content_source=686b4823448910dd7ea9c8691d802e3b%253ALT1adfed2057cc3ecc8c03dadc7944f85ea1981ae9 "Psychic Candle, Peppermint Candle, Psychic Abilities, Visionary Dreams, Intention Candle, Soy Candle, Fragrance Candle.")





Add to Favorites


- [![Custom Personalized CIGAR CUTTER Cigars Accessories Groomsmen Birthday Gift for Him Dad Men Bachelor Best Man Son Grandpa Handmade Christmas](https://i.etsystatic.com/25778130/c/1021/811/583/451/il/422acd/3871083592/il_340x270.3871083592_4t76.jpg)\\
\\
**Custom Personalized CIGAR CUTTER Cigars Accessories Groomsmen Birthday Gift for Him Dad Men Bachelor Best Man Son Grandpa Handmade Christmas**\\
\\
ad vertisement by PrecisionMemory\\
Advertisement from shop PrecisionMemory\\
PrecisionMemory\\
From shop PrecisionMemory\\
\\
Sale Price $29.99\\
$29.99\\
\\
$39.99\\
Original Price $39.99\\
\\
\\
(25% off)\\
\\
\\
\\
Free shipping eligible](https://www.etsy.com/listing/1040784367/custom-personalized-cigar-cutter-cigars?click_key=686b4823448910dd7ea9c8691d802e3b%3ALT495b7344d8ef9ee673a935a78e47fb1ed626251f&click_sum=1866f2ca&ls=r&ref=sold_out-24&pro=1&frs=1&sts=1&content_source=686b4823448910dd7ea9c8691d802e3b%253ALT495b7344d8ef9ee673a935a78e47fb1ed626251f "Custom Personalized CIGAR CUTTER Cigars Accessories Groomsmen Birthday Gift for Him Dad Men Bachelor Best Man Son Grandpa Handmade Christmas")





Add to Favorites



[Shop more similar items](https://www.etsy.com/listing/1297245484/similar?page=2&ref=sold_out_more_like_this)

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1297245484%2Fbergamot-patchouli-soy-candle%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc4NjQ4OTo4MDNiYWM0N2E4NzU5NTcxM2M0YTg4MDYwNzAxNDYwZA==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1297245484%2Fbergamot-patchouli-soy-candle%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1297245484/bergamot-patchouli-soy-candle?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1297245484%2Fbergamot-patchouli-soy-candle%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done