[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Kitchen & Dining](https://www.etsy.com/c/home-and-living/kitchen-and-dining?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Drink & Barware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)
- [Drinkware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware?utm_source=openai&explicit=1&ref=catnav_breadcrumb-3)
- [Mugs](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/mugs?utm_source=openai&explicit=1&ref=catnav_breadcrumb-4)


Add to Favorites


- ![May include: A ceramic mug with a light brown handle and a blue, green, and brown glaze. The mug has a textured surface and a slightly rounded shape.](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_794xN.2129499943_4b8s.jpg)
- ![May include: A ceramic mug with a blue, green, and brown glaze. The mug has a large handle and a tag that reads 'Constant Comment' and 'BIGELOW'.](https://i.etsystatic.com/5919069/r/il/081207/2081936320/il_794xN.2081936320_86tz.jpg)
- ![May include: A ceramic mug with a handle. The mug is decorated with a blue, green, and brown glaze that creates a marbled effect.](https://i.etsystatic.com/5919069/r/il/162d61/877487645/il_794xN.877487645_jnd5.jpg)
- ![May include: A close-up of a blue and orange textured surface with a fine layer of gold glitter.](https://i.etsystatic.com/5919069/r/il/8a937d/877720140/il_794xN.877720140_t7ap.jpg)
- ![May include: Close-up of a ceramic mug handle with a blue, brown, and green glaze. The handle has a textured, rounded shape with a raised bump.](https://i.etsystatic.com/5919069/r/il/a2d4ef/2129500215/il_794xN.2129500215_hcc1.jpg)
- ![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP image 6](https://i.etsystatic.com/5919069/r/il/adadb9/2129500333/il_794xN.2129500333_7aku.jpg)

- ![May include: A ceramic mug with a light brown handle and a blue, green, and brown glaze. The mug has a textured surface and a slightly rounded shape.](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_75x75.2129499943_4b8s.jpg)
- ![May include: A ceramic mug with a blue, green, and brown glaze. The mug has a large handle and a tag that reads 'Constant Comment' and 'BIGELOW'.](https://i.etsystatic.com/5919069/r/il/081207/2081936320/il_75x75.2081936320_86tz.jpg)
- ![May include: A ceramic mug with a handle. The mug is decorated with a blue, green, and brown glaze that creates a marbled effect.](https://i.etsystatic.com/5919069/r/il/162d61/877487645/il_75x75.877487645_jnd5.jpg)
- ![May include: A close-up of a blue and orange textured surface with a fine layer of gold glitter.](https://i.etsystatic.com/5919069/r/il/8a937d/877720140/il_75x75.877720140_t7ap.jpg)
- ![May include: Close-up of a ceramic mug handle with a blue, brown, and green glaze. The handle has a textured, rounded shape with a raised bump.](https://i.etsystatic.com/5919069/r/il/a2d4ef/2129500215/il_75x75.2129500215_hcc1.jpg)
- ![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP image 6](https://i.etsystatic.com/5919069/r/il/adadb9/2129500333/il_75x75.2129500333_7aku.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F258176922%2Flarge-16-ounce-stoneware-coffee-mug-in%23report-overlay-trigger)

Price:$32.00


Loading


# Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP

[HertzPottery](https://www.etsy.com/shop/HertzPottery?ref=shop-header-name&listing_id=258176922&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?utm_source=openai#reviews)

Arrives soon! Get it by

Nov 13-18


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Item details

### Highlights

Made by [HertzPottery](https://www.etsy.com/shop/HertzPottery)

- Materials: Ceramic


Our 16-ounce mug is perfect for a hot cup of coffee or tea on a chilly, fall day. Each mug is handmade and wheel-thrown using a white stoneware clay. They measure approximately 3" across and 5" tall. After a handle is attached to the mug, the entire piece is placed into the kiln to undergo its first firing. The mug is then glazed and enters the kiln for its second firing. After it comes out of the final firing, it's ready to find a new home with you!

All Hertz Pottery functional ware is oven, microwave, and dishwasher safe and intended for everyday use.

Please take a look at our other 16-ounce mug glaze colors including Tricolor, Turquoise, White, Copper, Brown and Opal. And if you're looking for smaller mug, we also offer small, 10-ounce mugs in various glaze colors.

While we strive to create pieces that are representative of the images above, please understand that each piece of pottery is handmade and will contain small variations in form, size, and color.

Thank you for considering Hertz Pottery.


## Shipping and return policies

Loading


- Order today to get by

**Nov 13-18**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 30 days


- Ships from: **Melbourne Beach, FL**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## Reviews for this item (399)

5.0/5

item average

5.0Item quality

4.9Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Beautiful

Love it

Fast shipping

Well packaged

Gift-worthy

Gorgeous

Would recommend


Filter by category


Appearance (150)


Quality (144)


Shipping & Packaging (119)


Description accuracy (36)


Sizing & Fit (28)


Seller service (28)


Comfort (26)


Ease of use (15)


Value (9)


Condition (4)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Susan](https://www.etsy.com/people/ntchfvzt4pu45r38?ref=l_review)
Oct 30, 2025


Gorgeous-like the colors of a beach! Thank you!



[Susan](https://www.etsy.com/people/ntchfvzt4pu45r38?ref=l_review)
Oct 30, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/1c8827/112921056/iusa_75x75.112921056_tleq.jpg?version=0)

[Anne Marie](https://www.etsy.com/people/8vtpbpag4vgd84rv?ref=l_review)
Oct 24, 2025


bought as a gift for my mom she loved it



![](https://i.etsystatic.com/iusa/1c8827/112921056/iusa_75x75.112921056_tleq.jpg?version=0)

[Anne Marie](https://www.etsy.com/people/8vtpbpag4vgd84rv?ref=l_review)
Oct 24, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/68eb57/22628844/iusa_75x75.22628844_ibnu.jpg?version=0)

[Regina Daizei](https://www.etsy.com/people/ReginaDaizei?ref=l_review)
Oct 4, 2025


Thank you for your artistry in making this wonderful mug. It fits perfectly in her hand. I got it as a gift for my friend for her birthday. She loves it.



![](https://i.etsystatic.com/iusa/68eb57/22628844/iusa_75x75.22628844_ibnu.jpg?version=0)

[Regina Daizei](https://www.etsy.com/people/ReginaDaizei?ref=l_review)
Oct 4, 2025


5 out of 5 stars
5

This item

[Hilda](https://www.etsy.com/people/gxhkszodpaxygp86?ref=l_review)
Sep 2, 2025


I bought this mug for my Sister. She will love it. You do beautiful pottery. Thank you for the fast delivery and answering my lame question.



[Hilda](https://www.etsy.com/people/gxhkszodpaxygp86?ref=l_review)
Sep 2, 2025


View all reviews for this item

### Photos from reviews

![Mariana added a photo of their purchase](https://i.etsystatic.com/iap/bc8a4f/5695890760/iap_300x300.5695890760_bc83czez.jpg?version=0)

![Sandi added a photo of their purchase](https://i.etsystatic.com/iap/40bade/6788743848/iap_300x300.6788743848_6j30c91p.jpg?version=0)

![Babsy added a photo of their purchase](https://i.etsystatic.com/iap/0a0619/4764247190/iap_300x300.4764247190_5n2jvd1w.jpg?version=0)

![Sonia added a photo of their purchase](https://i.etsystatic.com/iap/6e7f24/5562438862/iap_300x300.5562438862_6l160n6q.jpg?version=0)

![Jennifer added a photo of their purchase](https://i.etsystatic.com/iap/3652cb/4463322738/iap_300x300.4463322738_4d3u6ysm.jpg?version=0)

![Lupe added a photo of their purchase](https://i.etsystatic.com/iap/4b5c24/5712569869/iap_300x300.5712569869_hsh143l3.jpg?version=0)

![Angie added a photo of their purchase](https://i.etsystatic.com/iap/74148f/6758442656/iap_300x300.6758442656_715owums.jpg?version=0)

![Mariah added a photo of their purchase](https://i.etsystatic.com/iap/e58b32/4957022347/iap_300x300.4957022347_i53ztr35.jpg?version=0)

![Donna added a photo of their purchase](https://i.etsystatic.com/iap/03d848/5045411687/iap_300x300.5045411687_6wr3qv18.jpg?version=0)

![CHERYL added a photo of their purchase](https://i.etsystatic.com/iap/2cd47e/6010552150/iap_300x300.6010552150_dgi45qqt.jpg?version=0)

![Selina added a photo of their purchase](https://i.etsystatic.com/iap/0ee1d6/6054969678/iap_300x300.6054969678_jcfxkiey.jpg?version=0)

![Photography added a photo of their purchase](https://i.etsystatic.com/iap/a016fb/4698797554/iap_300x300.4698797554_lr0qzlpm.jpg?version=0)

![Jackee added a photo of their purchase](https://i.etsystatic.com/iap/8b3810/5538308957/iap_300x300.5538308957_3eo3yvkn.jpg?version=0)

![Sandra added a photo of their purchase](https://i.etsystatic.com/iap/93ab31/7180230753/iap_300x300.7180230753_fmmj8zf8.jpg?version=0)

![Kitsie added a photo of their purchase](https://i.etsystatic.com/iap/df473f/7201025375/iap_300x300.7201025375_3a5toe4j.jpg?version=0)

![Jerry added a photo of their purchase](https://i.etsystatic.com/iap/54f4d7/6559398072/iap_300x300.6559398072_61f8yp3f.jpg?version=0)

![Judy added a photo of their purchase](https://i.etsystatic.com/iap/2030ec/6135181428/iap_300x300.6135181428_5if9wha8.jpg?version=0)

![Jazmin added a photo of their purchase](https://i.etsystatic.com/iap/dd145f/5202558692/iap_300x300.5202558692_o72gyqvr.jpg?version=0)

![Georgina added a photo of their purchase](https://i.etsystatic.com/iap/d72178/5184774198/iap_300x300.5184774198_ex7yajxn.jpg?version=0)

![Crystal added a photo of their purchase](https://i.etsystatic.com/iap/a4d7fd/4407061057/iap_300x300.4407061057_3hibsvyc.jpg?version=0)

[![HertzPottery](https://i.etsystatic.com/iusa/9348dd/68800026/iusa_75x75.68800026_f6pf.jpg?version=0)](https://www.etsy.com/shop/HertzPottery?ref=shop_profile&listing_id=258176922)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[HertzPottery](https://www.etsy.com/shop/HertzPottery?ref=shop_profile&listing_id=258176922)

[Owned by Erik Hertz](https://www.etsy.com/shop/HertzPottery?ref=shop_profile&listing_id=258176922) \|

Melbourne, Florida

5.0
(6.1k)


21.3k sales

15 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=7584860&referring_id=258176922&referring_type=listing&recipient_id=7584860&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo3NTg0ODYwOjE3NjI3NjcxOTM6ZWFkYzczMzQ4MWIzMDY1OTUwMGRmMjE1OGI4Nzk5ZGE%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F258176922%2Flarge-16-ounce-stoneware-coffee-mug-in%3Futm_source%3Dopenai)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/HertzPottery?ref=lp_mys_mfts)

- [![Large (16-ounce) Stoneware Mug for Coffee or Tea in Opal**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/c4f864/2129496825/il_340x270.2129496825_a2k5.jpg)\\
\\
**Large (16-ounce) Stoneware Mug for Coffee or Tea in Opal\*\*READY TO SHIP**\\
\\
$32.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/246414183/large-16-ounce-stoneware-mug-for-coffee?click_key=d3ee27e47079b007422f5c1b2fd3a8df%3ALT37468e5072b150821342b99badc5660d19afd3f8&click_sum=934e4064&ls=r&ref=related-1&sts=1&content_source=d3ee27e47079b007422f5c1b2fd3a8df%253ALT37468e5072b150821342b99badc5660d19afd3f8 "Large (16-ounce) Stoneware Mug for Coffee or Tea in Opal**READY TO SHIP")




Add to Favorites


- [![Large (16 ounce) Stoneware Coffee Mug in in Deep Blue Glaze  **READY TO SHIP](https://i.etsystatic.com/5919069/c/2850/2265/0/292/il/23c478/2081939738/il_340x270.2081939738_4egv.jpg)\\
\\
**Large (16 ounce) Stoneware Coffee Mug in in Deep Blue Glaze \*\*READY TO SHIP**\\
\\
$32.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/258072213/large-16-ounce-stoneware-coffee-mug-in?click_key=d3ee27e47079b007422f5c1b2fd3a8df%3ALT77e2da7860c865e0b66861d6df3f8ba262a19ad4&click_sum=9bd0006d&ls=r&ref=related-2&sts=1&content_source=d3ee27e47079b007422f5c1b2fd3a8df%253ALT77e2da7860c865e0b66861d6df3f8ba262a19ad4 "Large (16 ounce) Stoneware Coffee Mug in in Deep Blue Glaze  **READY TO SHIP")




Add to Favorites


- [![Large (16 ounce) Stoneware Coffee Mug in Turquoise **READY TO SHIP](https://i.etsystatic.com/5919069/r/il/696d8a/861808774/il_340x270.861808774_q6ri.jpg)\\
\\
**Large (16 ounce) Stoneware Coffee Mug in Turquoise \*\*READY TO SHIP**\\
\\
$32.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/254530403/large-16-ounce-stoneware-coffee-mug-in?click_key=d3ee27e47079b007422f5c1b2fd3a8df%3ALT8eecb3c7eba41c75fbc8d67eb1cede02a2e271e0&click_sum=a37da97e&ls=r&ref=related-3&sts=1&content_source=d3ee27e47079b007422f5c1b2fd3a8df%253ALT8eecb3c7eba41c75fbc8d67eb1cede02a2e271e0 "Large (16 ounce) Stoneware Coffee Mug in Turquoise **READY TO SHIP")




Add to Favorites


- [![Soup and Cracker Bowl in Golden Brown Glaze with Pastel Ribbons**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/4f7741/7216814672/il_340x270.7216814672_kfub.jpg)\\
\\
**Soup and Cracker Bowl in Golden Brown Glaze with Pastel Ribbons\*\*READY TO SHIP**\\
\\
$42.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4372824688/soup-and-cracker-bowl-in-golden-brown?click_key=011a2a51641ba06040354eeadf851bfc153285bf%3A4372824688&click_sum=2e1b15b4&ref=related-4&sts=1 "Soup and Cracker Bowl in Golden Brown Glaze with Pastel Ribbons**READY TO SHIP")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 9, 2025


[4160 favorites](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Kitchen & Dining](https://www.etsy.com/c/home-and-living/kitchen-and-dining?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Drink & Barware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Drinkware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Mugs](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/mugs?utm_source=openai&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Prints

[Buy Heidi Klum Poster Online](https://www.etsy.com/market/heidi_klum_poster)

Kitchen & Dining

[Shop Best Mom Ever Glass](https://www.etsy.com/market/best_mom_ever_glass) [Witty Women Coffee Mug - Retro Housewife Humor - Gift For Friends - Funny Coworker Gift - Vintage Charm](https://www.etsy.com/listing/759724275/witty-women-coffee-mug-retro-housewife) [Novelty Cat Tea Cup - Kitchen & Dining](https://www.etsy.com/listing/1825068326/funny-tall-black-cat-coffee-mug-cute) [Shop Spring Fondue](https://www.etsy.com/market/spring_fondue) [Ceramic Bubble Mug by CeramicByEbruli](https://www.etsy.com/listing/1705985455/ceramic-bubble-mug-a-unique-taste) [Antique Chinese Famille Rose Serving Bowl. Hand Painted China Export Porcelain Dinnerware.](https://www.etsy.com/listing/1342688893/antique-chinese-famille-rose-serving) [1950s Half Apron - US](https://www.etsy.com/market/1950s_half_apron) [Heart shaped Talavera Mug](https://www.etsy.com/listing/4332894799/heart-shaped-talavera-mug) [Unplug Coasters! 4 pack. Aromatic Engraved Cedar. Subliminal messaging goes along way for those guests that can't put down their phone! - Kitchen & Dining](https://www.etsy.com/listing/1650837875/unplug-coasters-4-pack-aromatic-engraved)

Gender Neutral Adult Clothing

[Shop Southern Bell Shirt](https://www.etsy.com/market/southern_bell_shirt) [Disney Birthday Girl Disney Birthday Boy - Gender-Neutral Adult Clothing](https://www.etsy.com/listing/1864985668/birthday-squad-mommy-daddy-cousin)

Raw Materials

[Walnut Wood Slab - US](https://www.etsy.com/market/walnut_wood_slab)

Jewelry

[Punjabi Jewel - US](https://www.etsy.com/market/punjabi_jewel)

Home Improvement

[Buddhism Theme Durji Door Puller Collection - Home Improvement](https://www.etsy.com/listing/1293846892/vajra-door-handle-spiritual-praying)

Outdoor & Garden

[Shop Basset Wind Chime](https://www.etsy.com/market/basset_wind_chime)

Hats & Caps

[Blank Hat Outdoor](https://www.etsy.com/listing/1899725879/blank-hat-outdoor-adjustable-velcro-back)

Rings

[Couples Custom Engraved Pipe Cut Tungsten Fingerprint Rings His and Hers Matching Wedding Bands Personalized Flat Style - Rings](https://www.etsy.com/listing/191285044/couples-custom-engraved-pipe-cut)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F258176922%2Flarge-16-ounce-stoneware-coffee-mug-in%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc2NzE5MzpjOWEzYjYyYzNiMzIxNGQxNmRjN2ExMDFmMWUxZjJjZg==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F258176922%2Flarge-16-ounce-stoneware-coffee-mug-in%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F258176922%2Flarge-16-ounce-stoneware-coffee-mug-in%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for HertzPottery

### Returns & exchanges

See item details for return and exchange eligibility.


### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: A ceramic mug with a light brown handle and a blue, green, and brown glaze. The mug has a textured surface and a slightly rounded shape.](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_300x300.2129499943_4b8s.jpg)
- ![May include: A ceramic mug with a blue, green, and brown glaze. The mug has a large handle and a tag that reads 'Constant Comment' and 'BIGELOW'.](https://i.etsystatic.com/5919069/r/il/081207/2081936320/il_300x300.2081936320_86tz.jpg)
- ![May include: A ceramic mug with a handle. The mug is decorated with a blue, green, and brown glaze that creates a marbled effect.](https://i.etsystatic.com/5919069/r/il/162d61/877487645/il_300x300.877487645_jnd5.jpg)
- ![May include: A close-up of a blue and orange textured surface with a fine layer of gold glitter.](https://i.etsystatic.com/5919069/r/il/8a937d/877720140/il_300x300.877720140_t7ap.jpg)
- ![May include: Close-up of a ceramic mug handle with a blue, brown, and green glaze. The handle has a textured, rounded shape with a raised bump.](https://i.etsystatic.com/5919069/r/il/a2d4ef/2129500215/il_300x300.2129500215_hcc1.jpg)
- ![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP image 6](https://i.etsystatic.com/5919069/r/il/adadb9/2129500333/il_300x300.2129500333_7aku.jpg)

- ![](https://i.etsystatic.com/iap/bc8a4f/5695890760/iap_640x640.5695890760_bc83czez.jpg?version=0)

5 out of 5 stars

Beautiful and gorgeous pieces. Highly recommend

![](https://i.etsystatic.com/iusa/bd8473/100992646/iusa_75x75.100992646_c9il.jpg?version=0)

Jan 22, 2024


[Mariana](https://www.etsy.com/people/dmohm3gz)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/40bade/6788743848/iap_640x640.6788743848_6j30c91p.jpg?version=0)

5 out of 5 stars

This mug is gorgeous! I had one previously and broke it. It was my favorite. I was thrilled when I found this one on Erik’s page.

![](https://i.etsystatic.com/iusa/f8e212/75940030/iusa_75x75.75940030_218f.jpg?version=0)

Apr 13, 2025


[Sandi Graham](https://www.etsy.com/people/sandigraham3)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/0a0619/4764247190/iap_640x640.4764247190_5n2jvd1w.jpg?version=0)

5 out of 5 stars

Wonderful mug! Packed securely and the shipping was so quick.

Mar 28, 2023


[Babsy L](https://www.etsy.com/people/babsyl)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/6e7f24/5562438862/iap_640x640.5562438862_6l160n6q.jpg?version=0)

5 out of 5 stars

Even more beautiful in person. This is exactly what I’ve been looking for for a couple years now. Thank you so much 😊

Dec 2, 2023


[Sonia Vigen](https://www.etsy.com/people/slpv)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/3652cb/4463322738/iap_640x640.4463322738_4d3u6ysm.jpg?version=0)

5 out of 5 stars

Beautifully crafted. Color and quality just as described. Given as a Christmas gift, my sister really loves it.

Dec 26, 2022


[Jennifer Jo](https://www.etsy.com/people/x850nhds2pcbv8jm)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/4b5c24/5712569869/iap_640x640.5712569869_hsh143l3.jpg?version=0)

5 out of 5 stars

It’s beautiful. Absolutely love it😊

![](https://i.etsystatic.com/iusa/4318d9/104325645/iusa_75x75.104325645_44b0.jpg?version=0)

Jan 11, 2024


[Lupe](https://www.etsy.com/people/qlf7h8lcrxb74pbh)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/74148f/6758442656/iap_640x640.6758442656_715owums.jpg?version=0)

5 out of 5 stars

It is beautiful and I am so excited to use it! The packaging was great and it arrived in great time.

![](https://i.etsystatic.com/iusa/9117ea/78450075/iusa_75x75.78450075_y30w.jpg?version=0)

Mar 31, 2025


[Angie Murphy](https://www.etsy.com/people/phd4a18u)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/e58b32/4957022347/iap_640x640.4957022347_i53ztr35.jpg?version=0)

5 out of 5 stars

The seller went above and beyond to gift wrap this mug and provide great service. My mother loved her Mother's Day gift and told me the mug was "Beautiful, a great size, and comfortable to hold" Thanks much!

![](https://i.etsystatic.com/iusa/3054bb/56949818/iusa_75x75.56949818_8b88.jpg?version=0)

May 15, 2023


[Mariah Williams](https://www.etsy.com/people/MariahWilliams)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/03d848/5045411687/iap_640x640.5045411687_6wr3qv18.jpg?version=0)

5 out of 5 stars

Jun 13, 2023


[Donna Short](https://www.etsy.com/people/donnakshome)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/2cd47e/6010552150/iap_640x640.6010552150_dgi45qqt.jpg?version=0)

5 out of 5 stars

Sent to a friend. She loves her new mug. These items are beautiful.

May 23, 2024


[CHERYL MEEKER](https://www.etsy.com/people/cherylmeeker1)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/0ee1d6/6054969678/iap_640x640.6054969678_jcfxkiey.jpg?version=0)

5 out of 5 stars

These mugs are absolutely beautiful. The quality is top notch, and I am certain these will be well loved in our house.

Jun 12, 2024


[Selina Joseph](https://www.etsy.com/people/Selinas)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/a016fb/4698797554/iap_640x640.4698797554_lr0qzlpm.jpg?version=0)

5 out of 5 stars

I love this mug!! The glaze is so pretty!

![](https://i.etsystatic.com/iusa/6c7b0e/114816049/iusa_75x75.114816049_8ds5.jpg?version=0)

Mar 7, 2023


[Photography by Michiale](https://www.etsy.com/people/Michiale)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/8b3810/5538308957/iap_640x640.5538308957_3eo3yvkn.jpg?version=0)

5 out of 5 stars

I am really weird about the right mug- I was looking for the right size to have some room for a splash of cream and this is the perfect size! The colors are amazing the texture is great- and the shipping was out of this world speedy. Will be ordering again

![](https://i.etsystatic.com/iusa/ec4bce/111488075/iusa_75x75.111488075_gzrf.jpg?version=0)

Nov 10, 2023


[Jackee A](https://www.etsy.com/people/pieduckee)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/93ab31/7180230753/iap_640x640.7180230753_fmmj8zf8.jpg?version=0)

5 out of 5 stars

Beautiful mug, the seller was very accommodating and responded fast when I reached out!! :) thanks so much, can’t wait to get my soup/cracker bowl 💛

![](https://i.etsystatic.com/iusa/1a50ea/99362057/iusa_75x75.99362057_qqt5.jpg?version=0)

Aug 22, 2025


[Sandra Crowley](https://www.etsy.com/people/sandracrowley1)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/df473f/7201025375/iap_640x640.7201025375_3a5toe4j.jpg?version=0)

5 out of 5 stars

The mug fit my hand perfectly. The handle is so comfortable. I got this mug to replace a mug I had for years that saw wrong end of a tile floor. The glazing effects are so beautiful. Much care was taken in the packaging of this mug. Arrived in perfect condition. Thank you for your beautiful work.

Aug 29, 2025


[Kitsie King](https://www.etsy.com/people/hqbw4e7o1w1fr9ab)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/54f4d7/6559398072/iap_640x640.6559398072_61f8yp3f.jpg?version=0)

5 out of 5 stars

Very nice mug, fits well in the hands. Nice colors against the base color . Fast shipping and communication. A+

Jan 10, 2025


[Jerry](https://www.etsy.com/people/g6uyvdti)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/2030ec/6135181428/iap_640x640.6135181428_5if9wha8.jpg?version=0)

5 out of 5 stars

Love this cup! Everything about it is as described. Perfect fit for your hand. I am about to order more! Got one for my husband - now want a set!

Jul 18, 2024


[Judy Blotcky](https://www.etsy.com/people/zo5r2nk5zt3ks24z)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/dd145f/5202558692/iap_640x640.5202558692_o72gyqvr.jpg?version=0)

5 out of 5 stars

I absolutely love this mug. I had first received a mug from this artist a few years back as a gift. Sadly, it broke . I immediately set out to find a replacement, and I'm thrilled with what I got it's almost identical to my original mug ! The shipping was extremely fast, which was amazing because I literally had not gone a day without using my mug until it broke. Definitely worth every penny!

Aug 19, 2023


[Jazmin](https://www.etsy.com/people/9ywxocwj)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/d72178/5184774198/iap_640x640.5184774198_ex7yajxn.jpg?version=0)

5 out of 5 stars

Mug is done perfectly just the right amount of weight. The color is exquisite along with the workmanship. There's another mug I want to get from this shop

Aug 13, 2023


[Georgina Glenn](https://www.etsy.com/people/georginaaglenn)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/a4d7fd/4407061057/iap_640x640.4407061057_3hibsvyc.jpg?version=0)

5 out of 5 stars

Beautiful mug that holds the perfect amount of liquid! Great quality, fast shipping. Kind of regretting not ordering two!

![](https://i.etsystatic.com/iusa/adfc3d/85044948/iusa_75x75.85044948_mqs1.jpg?version=0)

Nov 18, 2022


[Crystal Presby](https://www.etsy.com/people/sunkissedlou)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)

Purchased item:

[![Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/f325fe/2129499943/il_170x135.2129499943_4b8s.jpg)\\
\\
Large (16 ounce) Stoneware Coffee Mug in Tri-Color Glaze\*\*READY TO SHIP\\
\\
$32.00](https://www.etsy.com/listing/258176922/large-16-ounce-stoneware-coffee-mug-in?ref=ap-listing)