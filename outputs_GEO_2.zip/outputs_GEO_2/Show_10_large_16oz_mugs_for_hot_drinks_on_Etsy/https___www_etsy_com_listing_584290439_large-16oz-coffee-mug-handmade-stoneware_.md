[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/584290439/large-16oz-coffee-mug-handmade-stoneware?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Kitchen & Dining](https://www.etsy.com/c/home-and-living/kitchen-and-dining?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Drink & Barware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)
- [Drinkware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware?utm_source=openai&explicit=1&ref=catnav_breadcrumb-3)
- [Mugs](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/mugs?utm_source=openai&explicit=1&ref=catnav_breadcrumb-4)

Sorry, this item is sold out

![](https://i.etsystatic.com/10443818/r/il/b52a70/1616219734/il_680x540.1616219734_kk5x.jpg)

Sorry, this item is sold out

[PaschalPottery](https://www.etsy.com/shop/PaschalPottery?ref=nla_listing_details)5 out of 5 stars(370)370 reviews

LARGE 16oz COFFEE MUG. Handmade Stoneware Coffee Cup in Blue/White Glaze. Dishwasher and Microwave Safe.


Sold

[See item details](https://www.etsy.com/listing/584290439/large-16oz-coffee-mug-handmade-stoneware?show_sold_out_detail=1&ref=nla_listing_details)

[See item details](https://www.etsy.com/listing/584290439/large-16oz-coffee-mug-handmade-stoneware?show_sold_out_detail=1&ref=nla_listing_details)

### Similar items on Etsy

(Results include adsLearn more
Sellers looking to grow their business and reach more interested buyers can use Etsy’s advertising platform to promote their items. You’ll see ad results based on factors like relevancy, and the amount sellers pay per click. [Learn more](https://www.etsy.com/legal/policy/search-advertisement-ranking-disclosures/899478564529).
)

- [![Stoneware Angular Coffee Mug: &#39;Alberta Dawn&#39; Glaze Design, Large Handle, Big 16 oz Mug](https://i.etsystatic.com/11902728/c/2213/1757/635/213/il/03e544/5806490348/il_340x270.5806490348_oi7c.jpg)\\
\\
**Stoneware Angular Coffee Mug: 'Alberta Dawn' Glaze Design, Large Handle, Big 16 oz Mug**\\
\\
ad vertisement by TheLongGrassStudio\\
Advertisement from shop TheLongGrassStudio\\
TheLongGrassStudio\\
From shop TheLongGrassStudio\\
\\
$52.73](https://www.etsy.com/listing/1688268035/stoneware-angular-coffee-mug-alberta?click_key=LTf81655242549771ff8f7a34aa0ab644f9d438541%3A1688268035&click_sum=e9cf72e0&ls=a&ref=sold_out_ad-1&sts=1 "Stoneware Angular Coffee Mug: 'Alberta Dawn' Glaze Design, Large Handle, Big 16 oz Mug")





Add to Favorites


- [![Handmade Stoneware Mug: 20 Oz Pottery Coffee or Beer Mug](https://i.etsystatic.com/19233406/r/il/78542e/6294462353/il_340x270.6294462353_6gt2.jpg)\\
\\
**Handmade Stoneware Mug: 20 Oz Pottery Coffee or Beer Mug**\\
\\
ad vertisement by EarthenFirePottery\\
Advertisement from shop EarthenFirePottery\\
EarthenFirePottery\\
From shop EarthenFirePottery\\
\\
$29.95](https://www.etsy.com/listing/674370311/handmade-stoneware-mug-20-oz-pottery?click_key=LTc3f16df08fd9aa481104a84c042d77577fbc830d%3A674370311&click_sum=3d65ace6&ls=a&ref=sold_out_ad-2&bes=1&sts=1 "Handmade Stoneware Mug: 20 Oz Pottery Coffee or Beer Mug")





Add to Favorites


- [![Handmade Porcelain Mug Watercolor Ceramic Cup Dishwasher Safe Pottery Tumbler Artistic Kitchen Decor Modern Minimalist Coffee Vessel Large](https://i.etsystatic.com/25134559/r/il/0d1e92/7091619424/il_340x270.7091619424_6ms1.jpg)\\
\\
**Handmade Porcelain Mug Watercolor Ceramic Cup Dishwasher Safe Pottery Tumbler Artistic Kitchen Decor Modern Minimalist Coffee Vessel Large**\\
\\
ad vertisement by JasminsClayWorks\\
Advertisement from shop JasminsClayWorks\\
JasminsClayWorks\\
From shop JasminsClayWorks\\
\\
Sale Price $67.49\\
$67.49\\
\\
$89.99\\
Original Price $89.99\\
\\
\\
(25% off)](https://www.etsy.com/listing/4378583666/handmade-porcelain-mug-watercolor?click_key=LT108994f4c33f9fdb24ef9354f16564d1f847bfa6%3A4378583666&click_sum=9a5864a9&ls=a&ref=sold_out_ad-3&pro=1 "Handmade Porcelain Mug Watercolor Ceramic Cup Dishwasher Safe Pottery Tumbler Artistic Kitchen Decor Modern Minimalist Coffee Vessel Large")





Add to Favorites


- [![pottery mugs, ceramic mug, mugs, handmade mugs, cups, cup, coffee mugs, coffee cup, tea cups,](https://i.etsystatic.com/6690299/r/il/9efbf5/6531768792/il_340x270.6531768792_2vyp.jpg)\\
\\
**pottery mugs, ceramic mug, mugs, handmade mugs, cups, cup, coffee mugs, coffee cup, tea cups,**\\
\\
ad vertisement by Goblinpottery\\
Advertisement from shop Goblinpottery\\
Goblinpottery\\
From shop Goblinpottery\\
\\
$45.00](https://www.etsy.com/listing/1850821241/pottery-mugs-ceramic-mug-mugs-handmade?click_key=LT97619fec2c761470150964a9474536efe307ec08%3A1850821241&click_sum=7df6d415&ls=a&ref=sold_out_ad-4&sts=1 "pottery mugs, ceramic mug, mugs, handmade mugs, cups, cup, coffee mugs, coffee cup, tea cups,")





Add to Favorites


- [![Handmade Stoneware Pottery Mug - 16 oz Unique Ceramic Design](https://i.etsystatic.com/5986665/r/il/eae6ae/7213820020/il_340x270.7213820020_4hpc.jpg)\\
\\
**Handmade Stoneware Pottery Mug - 16 oz Unique Ceramic Design**\\
\\
ad vertisement by ocpottery\\
Advertisement from shop ocpottery\\
ocpottery\\
From shop ocpottery\\
\\
$79.00\\
\\
Eligible orders get 15% off\\
\\
\\
Buy 2 items and get 15% off your order\\
\\
\\
FREE shipping](https://www.etsy.com/listing/95854021/handmade-stoneware-pottery-mug-16-oz?click_key=LT85b9298ca335806ee78371749cae8f0282f1eeca%3A95854021&click_sum=3d340663&ls=a&ref=sold_out_ad-5&pro=1&frs=1&sts=1 "Handmade Stoneware Pottery Mug - 16 oz Unique Ceramic Design")





Add to Favorites


- [![Handmade Comfort Mugs: Earth Tone Coffee Mug Set of Six](https://i.etsystatic.com/5822865/r/il/1999d1/734689043/il_340x270.734689043_8aa2.jpg)\\
\\
**Handmade Comfort Mugs: Earth Tone Coffee Mug Set of Six**\\
\\
ad vertisement by Lesliefreemandesigns\\
Advertisement from shop Lesliefreemandesigns\\
Lesliefreemandesigns\\
From shop Lesliefreemandesigns\\
\\
$270.00](https://www.etsy.com/listing/224408588/handmade-comfort-mugs-earth-tone-coffee?click_key=LT23705cee85c1da1d85c244dd54d8743aa8d7baa2%3A224408588&click_sum=df5d2075&ls=a&ref=sold_out_ad-6 "Handmade Comfort Mugs: Earth Tone Coffee Mug Set of Six")





Add to Favorites


- [![Artisan Pottery Mug](https://i.etsystatic.com/9585645/r/il/1aa9e4/4812425905/il_340x270.4812425905_3y37.jpg)\\
\\
**Artisan Pottery Mug**\\
\\
ad vertisement by FernStreetPottery\\
Advertisement from shop FernStreetPottery\\
FernStreetPottery\\
From shop FernStreetPottery\\
\\
$55.00](https://www.etsy.com/listing/498120312/artisan-pottery-mug?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALT3b349fdde7d5fdc7f6d6c6266a28b7368fb1d2aa&click_sum=ab63bf2e&ls=r&ref=sold_out-1&sts=1&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALT3b349fdde7d5fdc7f6d6c6266a28b7368fb1d2aa "Artisan Pottery Mug")





Add to Favorites


- [![Handmade Ceramic Mug - Large Size](https://i.etsystatic.com/5855415/r/il/27d5bf/4535708269/il_340x270.4535708269_49vd.jpg)\\
\\
**Handmade Ceramic Mug - Large Size**\\
\\
ad vertisement by Neherpottery\\
Advertisement from shop Neherpottery\\
Neherpottery\\
From shop Neherpottery\\
\\
$26.00](https://www.etsy.com/listing/1371848548/handmade-ceramic-mug-large-size?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALT1838163d9365f1e6155e907edf479a46c2bf5cee&click_sum=0295f4c1&ls=r&ref=sold_out-2&bes=1&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALT1838163d9365f1e6155e907edf479a46c2bf5cee "Handmade Ceramic Mug - Large Size")





Add to Favorites


- [![Huge coffee mug, Stoneware tea mug, Glazed pottery mug, Hand thrown cup, Black brown dinnerware, Rustic drinkware, Hand made](https://i.etsystatic.com/11226095/r/il/4c227d/4682242021/il_340x270.4682242021_kh57.jpg)\\
\\
**Huge coffee mug, Stoneware tea mug, Glazed pottery mug, Hand thrown cup, Black brown dinnerware, Rustic drinkware, Hand made**\\
\\
ad vertisement by GISceramics\\
Advertisement from shop GISceramics\\
GISceramics\\
From shop GISceramics\\
\\
Sale Price $34.71\\
$34.71\\
\\
$40.83\\
Original Price $40.83\\
\\
\\
(15% off)](https://www.etsy.com/listing/1404756846/huge-coffee-mug-stoneware-tea-mug-glazed?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALT02d176318463eaba993633b39a1024de8b671c11&click_sum=c29fcf5e&ls=r&ref=sold_out-3&pro=1&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALT02d176318463eaba993633b39a1024de8b671c11 "Huge coffee mug, Stoneware tea mug, Glazed pottery mug, Hand thrown cup, Black brown dinnerware, Rustic drinkware, Hand made")





Add to Favorites


- [![Handmade Stoneware Coffee Mug: Large Ceramic Pottery](https://i.etsystatic.com/21308349/c/2564/2038/0/383/il/ed520f/4360783444/il_340x270.4360783444_fuz1.jpg)\\
\\
**Handmade Stoneware Coffee Mug: Large Ceramic Pottery**\\
\\
ad vertisement by LacyBPotteryandGifts\\
Advertisement from shop LacyBPotteryandGifts\\
LacyBPotteryandGifts\\
From shop LacyBPotteryandGifts\\
\\
$28.00\\
\\
Free shipping eligible](https://www.etsy.com/listing/1253885951/handmade-stoneware-coffee-mug-large?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALT0a3a6034d6177e8eaf9df90da48af6f36e0cd020&click_sum=943a75f2&ls=r&ref=sold_out-4&frs=1&sts=1&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALT0a3a6034d6177e8eaf9df90da48af6f36e0cd020 "Handmade Stoneware Coffee Mug: Large Ceramic Pottery")





Add to Favorites


- [![Big Mug Energy – Large 24 oz Rustic Green Ceramic Mug – Microwave & Dishwasher Safe – Gift for Coffee Lovers](https://i.etsystatic.com/49560111/r/il/bb076b/6882154305/il_340x270.6882154305_3gjr.jpg)\\
\\
**Big Mug Energy – Large 24 oz Rustic Green Ceramic Mug – Microwave & Dishwasher Safe – Gift for Coffee Lovers**\\
\\
ad vertisement by HOOTEART\\
Advertisement from shop HOOTEART\\
HOOTEART\\
From shop HOOTEART\\
\\
$23.99\\
\\
FREE shipping](https://www.etsy.com/listing/4299849631/big-mug-energy-large-24-oz-rustic-green?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALT11415bde3ebc04c3e58f0c87adb11ed584e0d592&click_sum=9abc69a1&ls=r&ref=sold_out-5&frs=1&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALT11415bde3ebc04c3e58f0c87adb11ed584e0d592 "Big Mug Energy – Large 24 oz Rustic Green Ceramic Mug – Microwave & Dishwasher Safe – Gift for Coffee Lovers")





Add to Favorites


- [![Handmade Stoneware Mug - Coffee/Tea/Hot Chocolate](https://i.etsystatic.com/56738713/r/il/4dd5a7/6540410590/il_340x270.6540410590_rk0g.jpg)\\
\\
**Handmade Stoneware Mug - Coffee/Tea/Hot Chocolate**\\
\\
ad vertisement by HandmadeInHeckfield\\
Advertisement from shop HandmadeInHeckfield\\
HandmadeInHeckfield\\
From shop HandmadeInHeckfield\\
\\
$27.45](https://www.etsy.com/listing/1852829545/handmade-stoneware-mug-coffeeteahot?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALT16c7910a3cb8ba8ca79c619eef139697afcf474d&click_sum=da58cab9&ls=r&ref=sold_out-6&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALT16c7910a3cb8ba8ca79c619eef139697afcf474d "Handmade Stoneware Mug - Coffee/Tea/Hot Chocolate")





Add to Favorites


- [![Personalized Glazed Ceramic Mug: Laser Engraved Stoneware, 360ml](https://i.etsystatic.com/31902124/c/1365/1083/0/522/il/3eefb9/6207905812/il_340x270.6207905812_nxy1.jpg)\\
\\
**Personalized Glazed Ceramic Mug: Laser Engraved Stoneware, 360ml**\\
\\
ad vertisement by TheGreatLabelCompany\\
Advertisement from shop TheGreatLabelCompany\\
TheGreatLabelCompany\\
From shop TheGreatLabelCompany\\
\\
Sale Price $28.81\\
$28.81\\
\\
$48.03\\
Original Price $48.03\\
\\
\\
(40% off)](https://www.etsy.com/listing/1776951013/personalized-glazed-ceramic-mug-laser?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALTcb6874210396137f3460b86d5ea26585c03e4b57&click_sum=9b2e9e4c&ls=r&ref=sold_out-7&pro=1&sts=1&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALTcb6874210396137f3460b86d5ea26585c03e4b57 "Personalized Glazed Ceramic Mug: Laser Engraved Stoneware, 360ml")





Add to Favorites


- [![Large (16-ounce) Stoneware Mug for Coffee or Tea in Opal**READY TO SHIP](https://i.etsystatic.com/5919069/r/il/c4f864/2129496825/il_340x270.2129496825_a2k5.jpg)\\
\\
**Large (16-ounce) Stoneware Mug for Coffee or Tea in Opal\*\*READY TO SHIP**\\
\\
ad vertisement by HertzPottery\\
Advertisement from shop HertzPottery\\
HertzPottery\\
From shop HertzPottery\\
\\
$32.00](https://www.etsy.com/listing/246414183/large-16-ounce-stoneware-mug-for-coffee?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALT340e6351787542dba0a5f958590e246ce7c173d3&click_sum=718586eb&ls=r&ref=sold_out-8&sts=1&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALT340e6351787542dba0a5f958590e246ce7c173d3 "Large (16-ounce) Stoneware Mug for Coffee or Tea in Opal**READY TO SHIP")





Add to Favorites


- [![Unique Ceramic Large Coffee Mug: Dragon Scale Effect, Multi Coloured](https://i.etsystatic.com/56645641/r/il/d51b38/6603230026/il_340x270.6603230026_hnwv.jpg)\\
\\
**Unique Ceramic Large Coffee Mug: Dragon Scale Effect, Multi Coloured**\\
\\
ad vertisement by Creekraft\\
Advertisement from shop Creekraft\\
Creekraft\\
From shop Creekraft\\
\\
Sale Price $27.43\\
$27.43\\
\\
$39.19\\
Original Price $39.19\\
\\
\\
(30% off)](https://www.etsy.com/listing/1851695622/unique-ceramic-large-coffee-mug-dragon?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALTc93757b21270408dc73e45f401c5bcc055cb2c95&click_sum=1a402085&ls=r&ref=sold_out-9&pro=1&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALTc93757b21270408dc73e45f401c5bcc055cb2c95 "Unique Ceramic Large Coffee Mug: Dragon Scale Effect, Multi Coloured")





Add to Favorites


- [![Handmade Pottery mug / large ceramic coffee cup / gift / nature decor / stoneware mug / maple leaves / leaf mug / organic / Christmas / fall](https://i.etsystatic.com/6199097/r/il/7a867e/6391384749/il_340x270.6391384749_6s55.jpg)\\
\\
**Handmade Pottery mug / large ceramic coffee cup / gift / nature decor / stoneware mug / maple leaves / leaf mug / organic / Christmas / fall**\\
\\
ad vertisement by abbylingle\\
Advertisement from shop abbylingle\\
abbylingle\\
From shop abbylingle\\
\\
$66.00\\
\\
FREE shipping](https://www.etsy.com/listing/1807067778/handmade-pottery-mug-large-ceramic?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALT4f577927347812f5056834f40c573ff9189e9544&click_sum=2933015a&ls=r&ref=sold_out-10&frs=1&sts=1&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALT4f577927347812f5056834f40c573ff9189e9544 "Handmade Pottery mug / large ceramic coffee cup / gift / nature decor / stoneware mug / maple leaves / leaf mug / organic / Christmas / fall")





Add to Favorites


- [![Sand stoneware ceramic mug cup](https://i.etsystatic.com/18755906/r/il/7bce5c/6513228415/il_340x270.6513228415_5ent.jpg)\\
\\
**Sand stoneware ceramic mug cup**\\
\\
ad vertisement by ErenArmitage\\
Advertisement from shop ErenArmitage\\
ErenArmitage\\
From shop ErenArmitage\\
\\
$48.04\\
\\
Only 1 left](https://www.etsy.com/listing/1833507257/sand-stoneware-ceramic-mug-cup?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALT4904d3c76d7a2b614f2761d4a593b1eddd9caedc&click_sum=01c6b6eb&ls=r&ref=sold_out-11&sca=1&sts=1&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALT4904d3c76d7a2b614f2761d4a593b1eddd9caedc "Sand stoneware ceramic mug cup")





Add to Favorites


- [![Free bird - handmade stoneware pottery mug](https://i.etsystatic.com/22925910/r/il/a6cab3/7276477539/il_340x270.7276477539_3r0r.jpg)\\
\\
**Free bird - handmade stoneware pottery mug**\\
\\
ad vertisement by dirtydogpottery\\
Advertisement from shop dirtydogpottery\\
dirtydogpottery\\
From shop dirtydogpottery\\
\\
$55.00\\
\\
FREE shipping](https://www.etsy.com/listing/1399639063/free-bird-handmade-stoneware-pottery-mug?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALT3b97e190ed8ab60f09c199e7aa5b1a7f6f895418&click_sum=936908b3&ls=r&ref=sold_out-12&frs=1&sts=1&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALT3b97e190ed8ab60f09c199e7aa5b1a7f6f895418 "Free bird - handmade stoneware pottery mug")





Add to Favorites


- [![French Large Pitcher / Beige Brown Honey Stoneware / Ustensil Holder / Rustic Vase](https://i.etsystatic.com/36484529/r/il/256a77/6755696391/il_340x270.6755696391_btuq.jpg)\\
\\
**French Large Pitcher / Beige Brown Honey Stoneware / Ustensil Holder / Rustic Vase**\\
\\
ad vertisement by FrenchFindsGallery\\
Advertisement from shop FrenchFindsGallery\\
FrenchFindsGallery\\
From shop FrenchFindsGallery\\
\\
$70.03](https://www.etsy.com/listing/1890116367/french-large-pitcher-beige-brown-honey?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALT85f8540a51a9c6cbad33ab03c7dbf76d43489ada&click_sum=91f40fd2&ls=r&ref=sold_out-13&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALT85f8540a51a9c6cbad33ab03c7dbf76d43489ada "French Large Pitcher / Beige Brown Honey Stoneware / Ustensil Holder / Rustic Vase")





Add to Favorites


- [![Handmade Stoneware Mug, Wheel Thrown Denim Blue Pottery (12 oz) Microwave and Dishwasher Safe](https://i.etsystatic.com/44101853/r/il/c2e6e0/7138275051/il_340x270.7138275051_pxq5.jpg)\\
\\
**Handmade Stoneware Mug, Wheel Thrown Denim Blue Pottery (12 oz) Microwave and Dishwasher Safe**\\
\\
ad vertisement by SStoneCeramics\\
Advertisement from shop SStoneCeramics\\
SStoneCeramics\\
From shop SStoneCeramics\\
\\
$30.00\\
\\
Only 3 left](https://www.etsy.com/listing/1870377135/handmade-stoneware-mug-wheel-thrown?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALT3daf54bf0ef3e0a063faf4eedccb6ed897bb0823&click_sum=ecfd7abc&ls=r&ref=sold_out-14&sca=1&sts=1&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALT3daf54bf0ef3e0a063faf4eedccb6ed897bb0823 "Handmade Stoneware Mug, Wheel Thrown Denim Blue Pottery (12 oz) Microwave and Dishwasher Safe")





Add to Favorites


- [![Forest Green Glazed Mojave stoneware ceramic Mug, Tea coffee Mug Cup Scandi design Kitchen Drinkware Gift Boho Stone Present](https://i.etsystatic.com/51558661/r/il/bbadbe/5949906785/il_340x270.5949906785_98nd.jpg)\\
\\
**Forest Green Glazed Mojave stoneware ceramic Mug, Tea coffee Mug Cup Scandi design Kitchen Drinkware Gift Boho Stone Present**\\
\\
ad vertisement by TheGiftwareCompany\\
Advertisement from shop TheGiftwareCompany\\
TheGiftwareCompany\\
From shop TheGiftwareCompany\\
\\
$14.95](https://www.etsy.com/listing/1710530285/forest-green-glazed-mojave-stoneware?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALTa5587f9b07cf5c85d3fc82fa297ad94277227146&click_sum=24d6c686&ls=r&ref=sold_out-15&sts=1&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALTa5587f9b07cf5c85d3fc82fa297ad94277227146 "Forest Green Glazed Mojave stoneware ceramic Mug, Tea coffee Mug Cup Scandi design Kitchen Drinkware Gift Boho Stone Present")





Add to Favorites


- [![Deep Ocean Stoneware Mug – 500ml Capacity, Rich Layered Blue Glaze](https://i.etsystatic.com/19047866/r/il/f63551/7340793623/il_340x270.7340793623_js40.jpg)\\
\\
**Deep Ocean Stoneware Mug – 500ml Capacity, Rich Layered Blue Glaze**\\
\\
ad vertisement by Onearmedpotter\\
Advertisement from shop Onearmedpotter\\
Onearmedpotter\\
From shop Onearmedpotter\\
\\
$43.93\\
\\
FREE shipping](https://www.etsy.com/listing/4388009510/deep-ocean-stoneware-mug-500ml-capacity?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALT8e3af295cf8e3e114f27b9cd45828a92275d483e&click_sum=31c54ad0&ls=r&ref=sold_out-16&frs=1&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALT8e3af295cf8e3e114f27b9cd45828a92275d483e "Deep Ocean Stoneware Mug – 500ml Capacity, Rich Layered Blue Glaze")





Add to Favorites


- [![Dragon mug by Hester Salt Ceramic](https://i.etsystatic.com/18605405/r/il/1434cc/5647394770/il_340x270.5647394770_p58y.jpg)\\
\\
**Dragon mug by Hester Salt Ceramic**\\
\\
ad vertisement by HesterSaltCeramic\\
Advertisement from shop HesterSaltCeramic\\
HesterSaltCeramic\\
From shop HesterSaltCeramic\\
\\
$54.91](https://www.etsy.com/listing/1651547179/dragon-mug-by-hester-salt-ceramic?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALT66992dedd1e2985f821c3942827ebdf508eb2bc0&click_sum=b1bae33f&ls=r&ref=sold_out-17&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALT66992dedd1e2985f821c3942827ebdf508eb2bc0 "Dragon mug by Hester Salt Ceramic")





Add to Favorites


- [![Huge handmade ceramic mug, Night Moth, Large pottery approx 450ml mug, Large pottery coffee mug, Large ceramic tea mug, Coffee lovers gift,](https://i.etsystatic.com/24051516/r/il/376b0c/6917421973/il_340x270.6917421973_bnzn.jpg)\\
\\
**Huge handmade ceramic mug, Night Moth, Large pottery approx 450ml mug, Large pottery coffee mug, Large ceramic tea mug, Coffee lovers gift,**\\
\\
ad vertisement by BlueBirdPotteryJPS\\
Advertisement from shop BlueBirdPotteryJPS\\
BlueBirdPotteryJPS\\
From shop BlueBirdPotteryJPS\\
\\
$57.65](https://www.etsy.com/listing/4306897504/huge-handmade-ceramic-mug-night-moth?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALT384f64e3b7cec202300e897ac535d0a3351561e0&click_sum=07270de7&ls=r&ref=sold_out-18&sts=1&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALT384f64e3b7cec202300e897ac535d0a3351561e0 "Huge handmade ceramic mug, Night Moth, Large pottery approx 450ml mug, Large pottery coffee mug, Large ceramic tea mug, Coffee lovers gift,")





Add to Favorites


- [![16 oz. Bay Mug, Functional Pottery Handmade in USA - Sunrise](https://i.etsystatic.com/19973088/r/il/d7824c/4877370556/il_340x270.4877370556_8v4o.jpg)\\
\\
**16 oz. Bay Mug, Functional Pottery Handmade in USA - Sunrise**\\
\\
ad vertisement by UniqueNorth\\
Advertisement from shop UniqueNorth\\
UniqueNorth\\
From shop UniqueNorth\\
\\
$58.99\\
\\
FREE shipping](https://www.etsy.com/listing/1475364561/16-oz-bay-mug-functional-pottery?click_key=LTe5c588a1f4cda51909de61375ed7c4cb2de05122%3A1475364561&click_sum=5e6043c5&ls=a&ref=sold_out_ad-7&frs=1&sts=1 "16 oz. Bay Mug, Functional Pottery Handmade in USA - Sunrise")





Add to Favorites


- [![Blue Wheel-Thrown Ceramic Mug – Handmade Pottery Coffee Mug, 14-16oz, Rustic Drinkware, Microwave & Dishwasher Safe](https://i.etsystatic.com/41414666/r/il/c7f68d/6864650858/il_340x270.6864650858_p6tp.jpg)\\
\\
**Blue Wheel-Thrown Ceramic Mug – Handmade Pottery Coffee Mug, 14-16oz, Rustic Drinkware, Microwave & Dishwasher Safe**\\
\\
ad vertisement by CrisanthemumStudios\\
Advertisement from shop CrisanthemumStudios\\
CrisanthemumStudios\\
From shop CrisanthemumStudios\\
\\
$50.00\\
\\
FREE shipping](https://www.etsy.com/listing/1541991833/blue-wheel-thrown-ceramic-mug-handmade?click_key=LT7d7412a2e695014dae218152fa2f1adb2e953c91%3A1541991833&click_sum=fa722e00&ls=a&ref=sold_out_ad-8&frs=1&sts=1 "Blue Wheel-Thrown Ceramic Mug – Handmade Pottery Coffee Mug, 14-16oz, Rustic Drinkware, Microwave & Dishwasher Safe")





Add to Favorites


- [![Large Pottery Mug Stoneware Ceramic Coffee Cup Handmade Mug](https://i.etsystatic.com/5934335/r/il/1f09ca/6981895036/il_340x270.6981895036_sa0j.jpg)\\
\\
**Large Pottery Mug Stoneware Ceramic Coffee Cup Handmade Mug**\\
\\
ad vertisement by darshanpottery\\
Advertisement from shop darshanpottery\\
darshanpottery\\
From shop darshanpottery\\
\\
Sale Price $54.00\\
$54.00\\
\\
$60.00\\
Original Price $60.00\\
\\
\\
(10% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/4328353088/large-pottery-mug-stoneware-ceramic?click_key=LT0f64c603b6a3d3fab677f2d71151ec1bf50eabf3%3A4328353088&click_sum=16f2866f&ls=a&ref=sold_out_ad-9&pro=1&frs=1 "Large Pottery Mug Stoneware Ceramic Coffee Cup Handmade Mug")





Add to Favorites


- [![Geschirr Handgemacht/Big mug/Large mug/Large ceramic mug/Ceramic mug handmade pottery/Ceramic coffee mug handmade pottery/Ceramic teacup](https://i.etsystatic.com/40689618/c/1666/1666/373/958/il/5fa98a/7074025398/il_340x270.7074025398_iepq.jpg)\\
\\
**Geschirr Handgemacht/Big mug/Large mug/Large ceramic mug/Ceramic mug handmade pottery/Ceramic coffee mug handmade pottery/Ceramic teacup**\\
\\
ad vertisement by HanpantsurovCeramic\\
Advertisement from shop HanpantsurovCeramic\\
HanpantsurovCeramic\\
From shop HanpantsurovCeramic\\
\\
$80.90\\
\\
Only 2 available and it's in 4 people's carts](https://www.etsy.com/listing/1816069728/geschirr-handgemachtbig-muglarge?click_key=LT8ceadc8205d2b4c1438139f63b6a1c16c1f2d152%3A1816069728&click_sum=970aff5d&ls=a&ref=sold_out_ad-10&cns=1&sts=1 "Geschirr Handgemacht/Big mug/Large mug/Large ceramic mug/Ceramic mug handmade pottery/Ceramic coffee mug handmade pottery/Ceramic teacup")





Add to Favorites


- [![Birch Motif Mug 16Oz Seven](https://i.etsystatic.com/5429970/r/il/64b3b0/7200617524/il_340x270.7200617524_hujf.jpg)\\
\\
**Birch Motif Mug 16Oz Seven**\\
\\
ad vertisement by LenoreLampi\\
Advertisement from shop LenoreLampi\\
LenoreLampi\\
From shop LenoreLampi\\
\\
$64.00\\
\\
FREE shipping](https://www.etsy.com/listing/4369924950/birch-motif-mug-16oz-seven?click_key=LT730922e871172d6935b5267ea3d374a9b7526fbb%3A4369924950&click_sum=a937b352&ls=a&ref=sold_out_ad-11&frs=1 "Birch Motif Mug 16Oz Seven")





Add to Favorites


- [![Handmade pottery mug: ceramic coffee mug, stoneware tea cup, approx. 16 oz. (8296)](https://i.etsystatic.com/5801908/r/il/f291de/6940874430/il_340x270.6940874430_puwt.jpg)\\
\\
**Handmade pottery mug: ceramic coffee mug, stoneware tea cup, approx. 16 oz. (8296)**\\
\\
ad vertisement by BlueParrotPots\\
Advertisement from shop BlueParrotPots\\
BlueParrotPots\\
From shop BlueParrotPots\\
\\
$37.00\\
\\
Eligible orders get 15% off\\
\\
\\
Buy 2 items and get 15% off your order](https://www.etsy.com/listing/4320649169/handmade-pottery-mug-ceramic-coffee-mug?click_key=LT961c358fc711b17b5e44a20770e436658fc91aba%3A4320649169&click_sum=33ad0eed&ls=a&ref=sold_out_ad-12&pro=1&sts=1 "Handmade pottery mug: ceramic coffee mug, stoneware tea cup, approx. 16 oz. (8296)")





Add to Favorites


- [![Handmade Coffee Mug, 16oz, Large Wheel Thrown Stoneware Cup, Blue Green Flowing Glaze, Microwave and Dishwasher Safe! Coffee and Tea](https://i.etsystatic.com/32022567/r/il/82c0cc/6581269213/il_340x270.6581269213_buxt.jpg)\\
\\
**Handmade Coffee Mug, 16oz, Large Wheel Thrown Stoneware Cup, Blue Green Flowing Glaze, Microwave and Dishwasher Safe! Coffee and Tea**\\
\\
ad vertisement by FireHideAndSilver\\
Advertisement from shop FireHideAndSilver\\
FireHideAndSilver\\
From shop FireHideAndSilver\\
\\
$68.00\\
\\
FREE shipping](https://www.etsy.com/listing/1836939490/handmade-coffee-mug-16oz-large-wheel?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALTe7c0bfb3e6e600221e64d878878ef67b6ec7561b&click_sum=a9bf3df2&ls=r&ref=sold_out-19&frs=1&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALTe7c0bfb3e6e600221e64d878878ef67b6ec7561b "Handmade Coffee Mug, 16oz, Large Wheel Thrown Stoneware Cup, Blue Green Flowing Glaze, Microwave and Dishwasher Safe! Coffee and Tea")





Add to Favorites


- [![Handmade Modern Porcelain Coffee Bowl: 300ml, Various Glazes (height 9.5cm width 8cm approx)](https://i.etsystatic.com/19156832/r/il/53a06c/6936429798/il_340x270.6936429798_2mw2.jpg)\\
\\
**Handmade Modern Porcelain Coffee Bowl: 300ml, Various Glazes (height 9.5cm width 8cm approx)**\\
\\
ad vertisement by EstudioDelDiablo\\
Advertisement from shop EstudioDelDiablo\\
EstudioDelDiablo\\
From shop EstudioDelDiablo\\
\\
$27.39](https://www.etsy.com/listing/1696089681/handmade-modern-porcelain-coffee-bowl?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALTfa81ccdce1cb87bfea70266d9adb6a1382f419c9&click_sum=813849da&ls=r&ref=sold_out-20&sts=1&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALTfa81ccdce1cb87bfea70266d9adb6a1382f419c9 "Handmade Modern Porcelain Coffee Bowl: 300ml, Various Glazes (height 9.5cm width 8cm approx)")





Add to Favorites


- [![Hand Thrown Stoneware Beer Stein Cobalt Blue Ceramic Mug](https://i.etsystatic.com/5598733/r/il/9b87ed/7286086514/il_340x270.7286086514_md52.jpg)\\
\\
**Hand Thrown Stoneware Beer Stein Cobalt Blue Ceramic Mug**\\
\\
ad vertisement by CaractacusPots\\
Advertisement from shop CaractacusPots\\
CaractacusPots\\
From shop CaractacusPots\\
\\
$45.28\\
\\
Only 1 left](https://www.etsy.com/listing/4361890099/hand-thrown-stoneware-beer-stein-cobalt?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALTac464049b81d0119e71c4d1c4ba15eb9a133f1ce&click_sum=5fb46bbc&ls=r&ref=sold_out-21&sca=1&sts=1&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALTac464049b81d0119e71c4d1c4ba15eb9a133f1ce "Hand Thrown Stoneware Beer Stein Cobalt Blue Ceramic Mug")





Add to Favorites


- [![Large Ceramic Speckle Mug](https://i.etsystatic.com/15126398/r/il/2c6cb1/4146779287/il_340x270.4146779287_k41c.jpg)\\
\\
**Large Ceramic Speckle Mug**\\
\\
ad vertisement by JordanBCeramics\\
Advertisement from shop JordanBCeramics\\
JordanBCeramics\\
From shop JordanBCeramics\\
\\
$37.00\\
\\
Only 1 available and it's in 8 people's carts](https://www.etsy.com/listing/829858022/large-ceramic-speckle-mug?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALT2e4f29b7f47850e423a46d031e54f4e1f67d014c&click_sum=88eea762&ls=r&ref=sold_out-22&cns=1&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALT2e4f29b7f47850e423a46d031e54f4e1f67d014c "Large Ceramic Speckle Mug")





Add to Favorites


- [![Solstice Mug: Large Handmade Pottery Mug with Sun Design - 20-24 Ounces in Variety of Colors](https://i.etsystatic.com/19096197/r/il/9318bb/6480417033/il_340x270.6480417033_6wa7.jpg)\\
\\
**Solstice Mug: Large Handmade Pottery Mug with Sun Design - 20-24 Ounces in Variety of Colors**\\
\\
ad vertisement by ShorProducts\\
Advertisement from shop ShorProducts\\
ShorProducts\\
From shop ShorProducts\\
\\
Sale Price $48.60\\
$48.60\\
\\
$54.00\\
Original Price $54.00\\
\\
\\
(10% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1812276902/solstice-mug-large-handmade-pottery-mug?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALTdd1b0789b6ea74ae6876b93603c78e98227ac387&click_sum=33381796&ls=r&ref=sold_out-23&pro=1&frs=1&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALTdd1b0789b6ea74ae6876b93603c78e98227ac387 "Solstice Mug: Large Handmade Pottery Mug with Sun Design - 20-24 Ounces in Variety of Colors")





Add to Favorites


- [![Extra large coffee mug - Pottery 750ml cone-shaped beer mug, Jumbo mug, Tankard, Stein, Pint, Ceramic, Stoneware, Handmade, Wheel thrown](https://i.etsystatic.com/16232362/c/1600/1272/191/143/il/37d898/5722967491/il_340x270.5722967491_akv4.jpg)\\
\\
**Extra large coffee mug - Pottery 750ml cone-shaped beer mug, Jumbo mug, Tankard, Stein, Pint, Ceramic, Stoneware, Handmade, Wheel thrown**\\
\\
ad vertisement by BleuMariePottery\\
Advertisement from shop BleuMariePottery\\
BleuMariePottery\\
From shop BleuMariePottery\\
\\
Sale Price $80.21\\
$80.21\\
\\
$89.13\\
Original Price $89.13\\
\\
\\
(10% off)](https://www.etsy.com/listing/1239174715/extra-large-coffee-mug-pottery-750ml?click_key=d6d96bbfaceff5108f465f1185a904f9%3ALT93192f1f8bc0ad89ec02bd28e50a50f3b6a587f1&click_sum=bdb5d940&ls=r&ref=sold_out-24&pro=1&sts=1&content_source=d6d96bbfaceff5108f465f1185a904f9%253ALT93192f1f8bc0ad89ec02bd28e50a50f3b6a587f1 "Extra large coffee mug - Pottery 750ml cone-shaped beer mug, Jumbo mug, Tankard, Stein, Pint, Ceramic, Stoneware, Handmade, Wheel thrown")





Add to Favorites



[Shop more similar items](https://www.etsy.com/listing/584290439/similar?page=2&ref=sold_out_more_like_this)

### More from this shop

[See shop](https://www.etsy.com/shop/PaschalPottery?ref=related)

[![VINTAGE KEMP POTTERY Pitcher 1 Quart.](https://i.etsystatic.com/10443818/c/2250/2250/0/375/il/e5cd23/6613888721/il_340x270.6613888721_7sx6.jpg)\\
\\
**VINTAGE KEMP POTTERY Pitcher 1 Quart.**\\
\\
ad vertisement by PaschalPottery\\
Advertisement from shop PaschalPottery\\
PaschalPottery\\
From shop PaschalPottery\\
\\
$60.00](https://www.etsy.com/listing/1843708348/vintage-kemp-pottery-pitcher-1-quart?click_key=7cc9105cde4a141eb72edd1e685a4ceccd0184b6%3A1843708348&click_sum=ec4e1249&ref=related-1 "VINTAGE KEMP POTTERY Pitcher 1 Quart.")


Add to Favorites


[![HANDTHROWN SOAP DISPENSER, for Liquid Dish & Bath Soap. High Fired Pottery in Green/ Blue/Black Glazes](https://i.etsystatic.com/10443818/r/il/2f230d/5475155341/il_340x270.5475155341_ljmn.jpg)\\
\\
**HANDTHROWN SOAP DISPENSER, for Liquid Dish & Bath Soap. High Fired Pottery in Green/ Blue/Black Glazes**\\
\\
ad vertisement by PaschalPottery\\
Advertisement from shop PaschalPottery\\
PaschalPottery\\
From shop PaschalPottery\\
\\
$50.00](https://www.etsy.com/listing/866019738/handthrown-soap-dispenser-for-liquid?click_key=31cfc2d130ed71f988a09ba645d369ddab689eea%3A866019738&click_sum=a160a269&ref=related-2 "HANDTHROWN SOAP DISPENSER, for Liquid Dish & Bath Soap. High Fired Pottery in Green/ Blue/Black Glazes")


Add to Favorites


[![HANDMADE PIE PLATE, Stoneware Pie Dish in Blue and White Glaze Finish - Dishwasher, Oven & Microwave Safe Pottery](https://i.etsystatic.com/10443818/r/il/0a71c8/1966839413/il_340x270.1966839413_coqc.jpg)\\
\\
**HANDMADE PIE PLATE, Stoneware Pie Dish in Blue and White Glaze Finish - Dishwasher, Oven & Microwave Safe Pottery**\\
\\
ad vertisement by PaschalPottery\\
Advertisement from shop PaschalPottery\\
PaschalPottery\\
From shop PaschalPottery\\
\\
$60.00\\
\\
Only 2 available and it's in 1 person's cart](https://www.etsy.com/listing/265903619/handmade-pie-plate-stoneware-pie-dish-in?click_key=7886c68df34468907ac2c596504d7b06ca7dcec4%3A265903619&click_sum=49b183db&ref=related-3&cns=1 "HANDMADE PIE PLATE, Stoneware Pie Dish in Blue and White Glaze Finish - Dishwasher, Oven & Microwave Safe Pottery")


Add to Favorites


[![HANDTHROWN SOAP DISPENSER , for Liquid Dish & Bath  Soap.  High Fired Pottery in a &quot;Mystery Glaze&quot;](https://i.etsystatic.com/10443818/c/2250/1786/0/608/il/554ec9/5638380453/il_340x270.5638380453_dg56.jpg)\\
\\
**HANDTHROWN SOAP DISPENSER , for Liquid Dish & Bath Soap. High Fired Pottery in a "Mystery Glaze"**\\
\\
ad vertisement by PaschalPottery\\
Advertisement from shop PaschalPottery\\
PaschalPottery\\
From shop PaschalPottery\\
\\
$50.00](https://www.etsy.com/listing/808006694/handthrown-soap-dispenser-for-liquid?click_key=f5df084b3e3033cf5813b52728abde11ed633ff0%3A808006694&click_sum=8d4a4474&ref=related-4 "HANDTHROWN SOAP DISPENSER , for Liquid Dish & Bath  Soap.  High Fired Pottery in a \"Mystery Glaze\"")


Add to Favorites


[![HANDMADE COFFEE MUG,  Stoneware Coffee Cup in Blue and White Glaze - Dishwasher, Oven & Microwave Safe Pottery](https://i.etsystatic.com/10443818/r/il/9cd5b4/5638878621/il_340x270.5638878621_24k5.jpg)\\
\\
**HANDMADE COFFEE MUG, Stoneware Coffee Cup in Blue and White Glaze - Dishwasher, Oven & Microwave Safe Pottery**\\
\\
ad vertisement by PaschalPottery\\
Advertisement from shop PaschalPottery\\
PaschalPottery\\
From shop PaschalPottery\\
\\
$42.00](https://www.etsy.com/listing/507030396/handmade-coffee-mug-stoneware-coffee-cup?click_key=9238781c84f0256cd4f6be6a689d6ed6874ccc71%3A507030396&click_sum=75653e3a&ref=related-5 "HANDMADE COFFEE MUG,  Stoneware Coffee Cup in Blue and White Glaze - Dishwasher, Oven & Microwave Safe Pottery")


Add to Favorites


[![HANDMADE COFFEE MUG, Stoneware Coffee Cup in Floating Green and Black  Glaze - Dishwasher, Oven & Microwave Safe Pottery](https://i.etsystatic.com/10443818/r/il/8d376b/1138226956/il_340x270.1138226956_qna5.jpg)\\
\\
**HANDMADE COFFEE MUG, Stoneware Coffee Cup in Floating Green and Black Glaze - Dishwasher, Oven & Microwave Safe Pottery**\\
\\
ad vertisement by PaschalPottery\\
Advertisement from shop PaschalPottery\\
PaschalPottery\\
From shop PaschalPottery\\
\\
$42.00](https://www.etsy.com/listing/265887703/handmade-coffee-mug-stoneware-coffee-cup?click_key=b596e7d14948e8e0b6af4a4d504168be5d63a303%3A265887703&click_sum=71edafda&ref=related-6 "HANDMADE COFFEE MUG, Stoneware Coffee Cup in Floating Green and Black  Glaze - Dishwasher, Oven & Microwave Safe Pottery")


Add to Favorites


Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F584290439%2Flarge-16oz-coffee-mug-handmade-stoneware%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc2NzM1NTphNDM2ZjM3Mzk3MTQ5OGJmOTlmNmY3MDMxNGQ0OTNiMA==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F584290439%2Flarge-16oz-coffee-mug-handmade-stoneware%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/584290439/large-16oz-coffee-mug-handmade-stoneware?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F584290439%2Flarge-16oz-coffee-mug-handmade-stoneware%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done