[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/market/vintage_pottery_mugs#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

# Vintage Pottery Mugs

5,000+ items
with ads
Learn more
Sellers looking to grow their business and reach more interested buyers can use Etsy’s advertising platform to promote their items. You’ll see ad results based on factors like relevancy, and the amount sellers pay per click. [Learn more](https://www.etsy.com/legal/policy/search-advertisement-ranking-disclosures/899478564529).


[Exclude digital items](https://www.etsy.com/market/vintage_pottery_mugs?instant_download=0&explicit=1) [Personalizable](https://www.etsy.com/market/vintage_pottery_mugs?is_personalizable=1&explicit=1) [Star Seller](https://www.etsy.com/market/vintage_pottery_mugs?is_star_seller=1&explicit=1) [Under $25](https://www.etsy.com/market/vintage_pottery_mugs?max=25&explicit=1) [Free shipping](https://www.etsy.com/market/vintage_pottery_mugs?free_shipping=1&explicit=1) [Ships from United States](https://www.etsy.com/market/vintage_pottery_mugs?locationQuery=6252001&explicit=1)

Sort by:

Relevancy
Sort by: Relevancy

- [Relevancy](https://www.etsy.com/market/vintage_pottery_mugs?order=most_relevant)
- [Lowest Price](https://www.etsy.com/market/vintage_pottery_mugs?order=price_asc)
- [Highest Price](https://www.etsy.com/market/vintage_pottery_mugs?order=price_desc)
- [Top Customer Reviews](https://www.etsy.com/market/vintage_pottery_mugs?order=highest_reviews)
- [Most Recent](https://www.etsy.com/market/vintage_pottery_mugs?order=date_desc)

- [![May include: A ceramic mug with a speckled gray glaze and a brown glaze with a thin orange stripe. The mug has a wide, rounded handle.](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_300x300.6863380545_2ae7.jpg)\\
\\
**Coffee Mug - KJ Pottery**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
KJPottery\\
From shop KJPottery\\
\\
(3.2k)\\
\\
\\
$47.00\\
\\
FREE shipping](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?click_key=LT9e5e876f58780df3cce190e1404d65acc41c55c7%3A4296141840&click_sum=284ea027&ls=a&ga_order=most_relevant&ga_search_type=all&ga_view_type=gallery&ga_search_query=vintage+pottery+mugs&ref=search_grid-252587-1-1&frs=1&etp=1&sts=1 "Coffee Mug - KJ Pottery")

- [![Beautiful Set of Seven Hand-Thrown Stoneware Studio 3 Quart Pottery Pitcher and Six Mug Cups Matching Set - Elegant Multi Colored Tan Brown](https://i.etsystatic.com/49580753/r/il/9eeb5e/7275472261/il_300x300.7275472261_9ihy.jpg)\\
\\
**Beautiful Set of Seven Hand-Thrown Stoneware Studio 3 Quart Pottery Pitcher and Six Mug Cups Matching Set - Elegant Multi Colored Tan Brown**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
Musicalmagpies\\
From shop Musicalmagpies\\
\\
(755)\\
\\
\\
Sale Price $48.99\\
$48.99\\
\\
$69.99\\
Original Price $69.99\\
\\
(30% off)](https://www.etsy.com/listing/4375351222/beautiful-set-of-seven-hand-thrown?click_key=LT31cf1c7df37c42721b9e615a4c7421eb77ce0e5e%3A4375351222&click_sum=a8ac3c90&ls=a&ga_order=most_relevant&ga_search_type=all&ga_view_type=gallery&ga_search_query=vintage+pottery+mugs&ref=search_grid-252587-1-2&pro=1&sts=1 "Beautiful Set of Seven Hand-Thrown Stoneware Studio 3 Quart Pottery Pitcher and Six Mug Cups Matching Set - Elegant Multi Colored Tan Brown")

- [![May include: A ceramic mug with a brown, green, and orange glaze. The mug has a rounded handle and a wide base. The mug is decorated with a band of orange circles.](https://i.etsystatic.com/54633448/r/il/607381/6747105442/il_300x300.6747105442_58d2.jpg)\\
\\
**Japanese Vintage Cerami Mug: 'Taiyo'**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
SayumiIroIro\\
From shop SayumiIroIro\\
\\
(39)\\
\\
\\
$29.99](https://www.etsy.com/listing/1880097742/japanese-vintage-cerami-mug-taiyo?click_key=LTcc85c3a1ab87fa00b7a1f0306825318495bfa06e%3A1880097742&click_sum=03457846&ls=a&ga_order=most_relevant&ga_search_type=all&ga_view_type=gallery&ga_search_query=vintage+pottery+mugs&ref=search_grid-252587-1-3&sts=1 "Japanese Vintage Cerami Mug: 'Taiyo'")

- [![May include: A teal ceramic mug with a brown rim and a unique handle that wraps around the side. The mug has a speckled glaze.](https://i.etsystatic.com/5855415/r/il/86bd88/4488978752/il_300x300.4488978752_2ssd.jpg)\\
\\
**Tea/Coffee Handwarmer Ceramic Mug - Right Hand**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
Neherpottery\\
From shop Neherpottery\\
\\
(2.8k)\\
\\
\\
$24.00](https://www.etsy.com/listing/1385996853/teacoffee-handwarmer-ceramic-mug-right?click_key=LT3c12f2e237e80f89e9330a5ae95ebd0977fbc5bf%3A1385996853&click_sum=50b98734&ls=a&ga_order=most_relevant&ga_search_type=all&ga_view_type=gallery&ga_search_query=vintage+pottery+mugs&ref=search_grid-252587-1-4 "Tea/Coffee Handwarmer Ceramic Mug - Right Hand")

- [![Vintage Otagiri Style Mugs: MCM Handmade Ceramics](https://i.etsystatic.com/36412564/r/il/0fa91a/7327915393/il_300x300.7327915393_ahuu.jpg)\\
\\
**Vintage Otagiri Style Mugs: MCM Handmade Ceramics**\\
\\
(349)\\
\\
\\
$15.00](https://www.etsy.com/listing/4385787978/vintage-otagiri-style-mugs-mcm-handmade?click_key=cf13c9f7-0a67-40be-880e-ef0f29efeddc%3ALT017fa4363a791bb401ea7338fffa78eecec67c29&click_sum=d94be7fa&ls=s&ga_order=most_relevant&ga_search_type=all&ga_view_type=gallery&ga_search_query=vintage+pottery+mugs&ref=search_grid-252588-1-1&sts=1&content_source=cf13c9f7-0a67-40be-880e-ef0f29efeddc%253ALT017fa4363a791bb401ea7338fffa78eecec67c29 "Vintage Otagiri Style Mugs: MCM Handmade Ceramics")

- [![Perfectly Mismatched Pair of Vintage Otagiri Style MCM Floral Coffee Mugs/Tea Cups](https://i.etsystatic.com/54526995/r/il/252a5d/7369487129/il_300x300.7369487129_mm1h.jpg)\\
\\
**Perfectly Mismatched Pair of Vintage Otagiri Style MCM Floral Coffee Mugs/Tea Cups**\\
\\
(237)\\
\\
\\
$18.00](https://www.etsy.com/listing/4392722398/perfectly-mismatched-pair-of-vintage?click_key=cf13c9f7-0a67-40be-880e-ef0f29efeddc%3ALT8885393b923f1219c27ec76731ddfbde06fc10f0&click_sum=135b331f&ls=s&ga_order=most_relevant&ga_search_type=all&ga_view_type=gallery&ga_search_query=vintage+pottery+mugs&ref=search_grid-252588-1-2&sts=1&content_source=cf13c9f7-0a67-40be-880e-ef0f29efeddc%253ALT8885393b923f1219c27ec76731ddfbde06fc10f0 "Perfectly Mismatched Pair of Vintage Otagiri Style MCM Floral Coffee Mugs/Tea Cups")

- [![Two Stoneware Floral Coffee Mugs](https://i.etsystatic.com/56442734/r/il/04cb70/7381939117/il_300x300.7381939117_dvpn.jpg)\\
\\
**Two Stoneware Floral Coffee Mugs**\\
\\
(69)\\
\\
\\
$12.00](https://www.etsy.com/listing/4394801803/two-stoneware-floral-coffee-mugs?click_key=cf13c9f7-0a67-40be-880e-ef0f29efeddc%3ALTa6b34c2eebe94d117fd1d86debd100cd60e3ff40&click_sum=ae75dba5&ls=s&ga_order=most_relevant&ga_search_type=all&ga_view_type=gallery&ga_search_query=vintage+pottery+mugs&ref=search_grid-252588-1-3&sts=1&content_source=cf13c9f7-0a67-40be-880e-ef0f29efeddc%253ALTa6b34c2eebe94d117fd1d86debd100cd60e3ff40 "Two Stoneware Floral Coffee Mugs")

- [![Vintage Handmade Speckled Pottery Mug - Brown and Off White](https://i.etsystatic.com/13892923/c/2250/2250/0/750/il/09ceba/7350780814/il_300x300.7350780814_4wt1.jpg)\\
\\
**Vintage Handmade Speckled Pottery Mug - Brown and Off White**\\
\\
(636)\\
\\
\\
$12.00](https://www.etsy.com/listing/4397544402/vintage-handmade-speckled-pottery-mug?click_key=cf13c9f7-0a67-40be-880e-ef0f29efeddc%3ALT1c81f148afaeb75628f454f25762bff3b52b7e9f&click_sum=959754d8&ls=s&ga_order=most_relevant&ga_search_type=all&ga_view_type=gallery&ga_search_query=vintage+pottery+mugs&ref=search_grid-252588-1-4&sts=1&content_source=cf13c9f7-0a67-40be-880e-ef0f29efeddc%253ALT1c81f148afaeb75628f454f25762bff3b52b7e9f "Vintage Handmade Speckled Pottery Mug - Brown and Off White")

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...


- Previous page

- Pagination

1

- [Pagination\\
\\
2](https://www.etsy.com/market/vintage_pottery_mugs?ref=pagination&page=2)
- [Pagination\\
\\
3](https://www.etsy.com/market/vintage_pottery_mugs?ref=pagination&page=3)
- [Next page](https://www.etsy.com/market/vintage_pottery_mugs?ref=pagination&page=2)

- Previous page

- Pagination

1

- [Pagination\\
\\
2](https://www.etsy.com/market/vintage_pottery_mugs?ref=pagination&page=2)
- [Pagination\\
\\
3](https://www.etsy.com/market/vintage_pottery_mugs?ref=pagination&page=3)
- [Pagination\\
\\
4](https://www.etsy.com/market/vintage_pottery_mugs?ref=pagination&page=4)
- [Pagination\\
\\
5](https://www.etsy.com/market/vintage_pottery_mugs?ref=pagination&page=5)
- [Next page](https://www.etsy.com/market/vintage_pottery_mugs?ref=pagination&page=2)

Smart Summary created by AI using similar shopper trends.

Explore unique vintage pottery mugs, from earthy drip glaze to charming animal designs. Find handmade ceramic coffee mugs and rustic stoneware cups.



![](https://i.etsystatic.com/18570320/c/2400/1907/0/851/il/bf20f5/3425857125/il_340x270.3425857125_lheo.jpg)

[Mugs\\
\\
\\
Shop now](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/mugs?ref=market_guides_carousel_category)

![](https://i.etsystatic.com/33379415/r/il/fd2cd0/6655535708/il_340x270.6655535708_aeek.jpg)

[Fine Art Ceramics\\
\\
\\
Shop now](https://www.etsy.com/c/art-and-collectibles/fine-art-ceramics?ref=market_guides_carousel_category)

![](https://i.etsystatic.com/22605194/r/il/c158b1/5039519764/il_340x270.5039519764_i4d7.jpg)

[Dining & Serving\\
\\
\\
Shop now](https://www.etsy.com/c/home-and-living/kitchen-and-dining/dining-and-serving?ref=market_guides_carousel_category)

![](https://i.etsystatic.com/5122618/r/il/d5c6fd/4312931196/il_340x270.4312931196_e3y5.jpg)

[Vases\\
\\
\\
Shop now](https://www.etsy.com/c/home-and-living/home-decor/home-accents/vases?ref=market_guides_carousel_category)

![](https://i.etsystatic.com/34824866/c/2244/2469/0/0/il/48c537/5730903969/il_340x270.5730903969_nz0o.jpg)

[Plates\\
\\
\\
Shop now](https://www.etsy.com/c/home-and-living/kitchen-and-dining/dining-and-serving/plates?ref=market_guides_carousel_category)

![](https://i.etsystatic.com/15485413/r/il/5a567c/4855864264/il_340x270.4855864264_bu96.jpg)

[Travel Mugs\\
\\
\\
Shop now](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/mugs/travel-mugs?ref=market_guides_carousel_category)

![](https://i.etsystatic.com/11907845/r/il/0bb90b/5537950255/il_340x270.5537950255_5zri.jpg)

[Christmas Ornaments\\
\\
\\
Shop now](https://www.etsy.com/c/home-and-living/home-decor/seasonal-decor/ornaments?ref=market_guides_carousel_category)

![](https://i.etsystatic.com/10385964/r/il/f1433e/6671264787/il_340x270.6671264787_snyj.jpg)

[Drinkware\\
\\
\\
Shop now](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware?ref=market_guides_carousel_category)

![](https://i.etsystatic.com/5776611/r/il/aa9cd1/2262018904/il_340x270.2262018904_ez89.jpg)

[Jars & Containers\\
\\
\\
Shop now](https://www.etsy.com/c/home-and-living/kitchen-and-dining/kitchen-storage/jars-and-containers?ref=market_guides_carousel_category)

Review spotlight

These 4 or 5-star reviews represent the opinions of the individuals who posted them and do not reflect the views of Etsy. The
ratings/reviews displayed here may not be representative of every listing on this page, or of every review for these listings. Please click
on a specific listing for more information about its average rating and to see more customer reviews.


Here is a selection of four-star and five-star reviews from customers who were delighted with the products they found in this category.

- [![Buyer Avatar](https://i.etsystatic.com/site-assets/images/avatars/default_avatar.png?width=75)\\
\\
Kelly Osborn\\
\\
5 out of 5 stars\\
\\
"These mugs are great!! Well made and love the size"\\
\\
\\
![Listing Image](https://i.etsystatic.com/17913950/r/il/193234/6404920545/il_25x25.6404920545_6zim.jpg)\\
\\
Handmade Ceramic Coffee Mug \| Rustic Farmhouse Pottery \| Handmade \| Logo Customization \| 16-18 oz \| Brew Cup](https://www.etsy.com/listing/621980272/handmade-ceramic-coffee-mug-rustic?ref=market_abr)

- [![Buyer Avatar](https://i.etsystatic.com/iusa/93cf8f/27463798/iusa_75x75.27463798_cips.jpg?version=0)\\
\\
cceccola\\
\\
5 out of 5 stars\\
\\
"My mom loves the mug so much. It turned out perfectly thank you!"\\
\\
\\
![Listing Image](https://i.etsystatic.com/8740835/r/il/66eaf7/7239129776/il_25x25.7239129776_e0jg.jpg)\\
\\
Blue and rust red hand thrown stoneware mug Clay Coffee cup thumb rest](https://www.etsy.com/listing/697551762/blue-and-rust-red-hand-thrown-stoneware?ref=market_abr)

- [![Buyer Avatar](https://i.etsystatic.com/site-assets/images/avatars/default_avatar.png?width=75)\\
\\
ciderjo\\
\\
5 out of 5 stars\\
\\
"Mug arrived in a timely manner and is just as described! A great mug and I really love it. Great transaction!"\\
\\
\\
![Listing Image](https://i.etsystatic.com/13901440/r/il/6a2ca2/7354600134/il_25x25.7354600134_sx6c.jpg)\\
\\
Retro Vintage Coffee Mug: Mid-Century Ceramic Drinkware](https://www.etsy.com/listing/1449556824/retro-vintage-coffee-mug-mid-century?ref=market_abr)

- [![Buyer Avatar](https://i.etsystatic.com/site-assets/images/avatars/default_avatar.png?width=75)\\
\\
Denise\\
\\
5 out of 5 stars\\
\\
"I bought these mugs as a Christmas gift. They are more beautiful in person than in the pictures and they were packed really well! I would order from them again."\\
\\
\\
![Listing Image](https://i.etsystatic.com/7351966/r/il/06d740/2028876585/il_25x25.2028876585_r7ug.jpg)\\
\\
Rustic mug, handmade turquoise mug, set of stoneware mugs](https://www.etsy.com/listing/730334883/rustic-mug-handmade-turquoise-mug-set-of?ref=market_abr)

- [![Buyer Avatar](https://i.etsystatic.com/site-assets/images/avatars/default_avatar.png?width=75)\\
\\
Karina\\
\\
5 out of 5 stars\\
\\
"Ordered two vintage mugs from this seller. Arrived well packaged and in like new condition."\\
\\
\\
![Listing Image](https://i.etsystatic.com/25888227/r/il/76c383/6801370861/il_25x25.6801370861_ggvi.jpg)\\
\\
Vintage Studio Pottery Mug: Hand Thrown Ceramic Stoneware, Drip Glaze](https://www.etsy.com/listing/1895265909/vintage-studio-pottery-mug-hand-thrown?ref=market_abr)

- [![Buyer Avatar](https://i.etsystatic.com/site-assets/images/avatars/default_avatar.png?width=75)\\
\\
Ed Frost\\
\\
5 out of 5 stars\\
\\
"Perfect!!! Needed a large mug for my triple shot latte, this is the perfect size."\\
\\
\\
![Listing Image](https://i.etsystatic.com/19233406/r/il/d1c175/6276580928/il_25x25.6276580928_muhi.jpg)\\
\\
Handmade Stoneware Civil War Mug: Large Pottery Coffee Cup](https://www.etsy.com/listing/673775031/handmade-stoneware-civil-war-mug-large?ref=market_abr)


## Common Questions

Do Etsy sellers include shipping on vintage pottery mugs?

Yes! Many of the vintage pottery mugs, sold by the shops on Etsy, qualify for included shipping, such as:

1. [Vintage 1995 Hand Thrown Kitty Cat Pottery Coffee Mug Signed By Nancy Koski](https://www.etsy.com/listing/1690697171/vintage-1995-hand-thrown-kitty-cat?ref=faq_free_shipping_listings&utm_campaign=faq_free_shipping_listings)
2. [Set of Two Mushroom Mugs with Butterflies and Flowers / vintage ceramic mugs / retro kitchen decor / 1970s /](https://www.etsy.com/listing/4378689951/set-of-two-mushroom-mugs-with?ref=faq_free_shipping_listings&utm_campaign=faq_free_shipping_listings)
3. [Vintage Beige and Brown Glazed Pottery/Stoneware Wheat Mugs with Hanging Display Shelf](https://www.etsy.com/listing/4374010262/vintage-beige-and-brown-glazed?ref=faq_free_shipping_listings&utm_campaign=faq_free_shipping_listings)
4. [Vintage Margie Weinstein pottery 2 geese mug](https://www.etsy.com/listing/4378022571/vintage-margie-weinstein-pottery-2-geese?ref=faq_free_shipping_listings&utm_campaign=faq_free_shipping_listings)
5. [Rare Vintage OTAGIRI Speckled Stoneware Hand Painted 8 oz Coffee/Tea Mug NOS](https://www.etsy.com/listing/4361276540/rare-vintage-otagiri-speckled-stoneware?ref=faq_free_shipping_listings&utm_campaign=faq_free_shipping_listings)

See each listing for more details. Click here to see more [vintage pottery mugs](https://www.etsy.com/market/vintage_pottery_mugs?ref=market_content&utm_campaign=faq_link&free_shipping=1) with free shipping included.

What are the bestselling vintage pottery mugs available on Etsy?

Some of the bestselling vintage pottery mugs available on Etsy are:

1. [Boho Floral Handmade Pottery Mugs Wheel Thrown. Speckled clay and bees!](https://www.etsy.com/listing/4342313479/boho-floral-handmade-pottery-mugs-wheel?ref=faq_popular_listings&utm_campaign=faq_popular_listings)
2. [Blue and rust red hand thrown stoneware mug Clay Coffee cup thumb rest](https://www.etsy.com/listing/697551762/blue-and-rust-red-hand-thrown-stoneware?ref=faq_popular_listings&utm_campaign=faq_popular_listings)
3. [Handmade Blue Pottery Mug: Bird & Floral Design, Optional Lid](https://www.etsy.com/listing/616971762/handmade-blue-pottery-mug-bird-floral?ref=faq_popular_listings&utm_campaign=faq_popular_listings)
4. [Handcrafted Ceramic Coffee Cup & Saucer Set – Rustic Kiln-Glazed Mug, Vintage Pottery Espresso Cup, Wabi Sabi Tea Mug Gift](https://www.etsy.com/listing/4386633927/handcrafted-ceramic-coffee-cup-saucer?ref=faq_popular_listings&utm_campaign=faq_popular_listings)
5. [Handmade Turquoise Pottery Mug: Rustic Floral Print, 16 oz, lid available](https://www.etsy.com/listing/614766345/handmade-turquoise-pottery-mug-rustic?ref=faq_popular_listings&utm_campaign=faq_popular_listings)

Click on each listing for more details.

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Kitchen & Dining

[Zig Zag Mugs - US](https://www.etsy.com/market/zig_zag_mugs) [Custom Hennessy Bling Bottle (750ml) (EMPTY) by ArtsyAddictz](https://www.etsy.com/listing/1578231784/custom-hennessy-bling-bottle-750ml-empty) [Shop Glass Flask Leather](https://www.etsy.com/market/glass_flask_leather) [Buy Large Coffee Mug Made In Usa Online](https://www.etsy.com/market/large_coffee_mug_made_in_usa) [Satoru Gojo Cup for Sale](https://www.etsy.com/market/satoru_gojo_cup) [Pomegranate Placemat - US](https://www.etsy.com/market/pomegranate_placemat) [Crosley Refrigerator - US](https://www.etsy.com/market/crosley_refrigerator) [Buy Punch Bowls Online](https://www.etsy.com/market/punch_bowls) [Signed Wood Bowls for Sale](https://www.etsy.com/market/signed_wood_bowls) [Square Waterproof Table Cloths for Sale](https://www.etsy.com/market/square_waterproof_table_cloths) [Shop Dalek Kitchen](https://www.etsy.com/market/dalek_kitchen)

Prints

[Shop Gin Posters](https://www.etsy.com/market/gin_posters)

Skin Care

[Shark Tattoos for Sale](https://www.etsy.com/market/shark_tattoos)

Paper

[Serena Love Island - US](https://www.etsy.com/market/serena_love_island) [Threesome Stickers for Sale](https://www.etsy.com/market/threesome_stickers)

Storage & Organization

[MAGNETIC Shelves - Handmade Clear Acrylic MAGNETIC Shelves - Magnetic Plant Shelves - Magnetic Office Shelves by WindowWonderz](https://www.etsy.com/listing/1202924735/magnetic-shelves-handmade-clear-acrylic)

Necklaces

[shinybitsjewelry - US](https://www.etsy.com/shop/shinybitsjewelry)

Beads Gems & Cabochons

[20mm Jade Beads - US](https://www.etsy.com/market/20mm_jade_beads)

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Fmarket%2Fvintage_pottery_mugs&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc2NjUyMTo3MGQ2ZjU2YTM2YTE4NDRlMDFjNDY2MTlhMzUyNTNlOA==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Fmarket%2Fvintage_pottery_mugs) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/market/vintage_pottery_mugs#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Fmarket%2Fvintage_pottery_mugs)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done