[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/market/vintage_porcelain_coffee_cups#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

# Vintage Porcelain Coffee Cups

5,000+ items
with ads
Learn more
Sellers looking to grow their business and reach more interested buyers can use Etsy’s advertising platform to promote their items. You’ll see ad results based on factors like relevancy, and the amount sellers pay per click. [Learn more](https://www.etsy.com/legal/policy/search-advertisement-ranking-disclosures/899478564529).


[Exclude digital items](https://www.etsy.com/market/vintage_porcelain_coffee_cups?instant_download=0&explicit=1) [Personalizable](https://www.etsy.com/market/vintage_porcelain_coffee_cups?is_personalizable=1&explicit=1) [Star Seller](https://www.etsy.com/market/vintage_porcelain_coffee_cups?is_star_seller=1&explicit=1) [Under $25](https://www.etsy.com/market/vintage_porcelain_coffee_cups?max=25&explicit=1) [Free shipping](https://www.etsy.com/market/vintage_porcelain_coffee_cups?free_shipping=1&explicit=1) [Ships from United States](https://www.etsy.com/market/vintage_porcelain_coffee_cups?locationQuery=6252001&explicit=1)

Sort by:

Relevancy
Sort by: Relevancy

- [Relevancy](https://www.etsy.com/market/vintage_porcelain_coffee_cups?order=most_relevant)
- [Lowest Price](https://www.etsy.com/market/vintage_porcelain_coffee_cups?order=price_asc)
- [Highest Price](https://www.etsy.com/market/vintage_porcelain_coffee_cups?order=price_desc)
- [Top Customer Reviews](https://www.etsy.com/market/vintage_porcelain_coffee_cups?order=highest_reviews)
- [Most Recent](https://www.etsy.com/market/vintage_porcelain_coffee_cups?order=date_desc)

- [![Set of Two Vintage French Cafe au Lait cups, Set of French Cafe au Lait cups, Vintage Coffee Cups](https://i.etsystatic.com/5839816/c/1884/1884/0/234/il/8507e4/7170905869/il_300x300.7170905869_ezc7.jpg)\\
\\
**Set of Two Vintage French Cafe au Lait cups, Set of French Cafe au Lait cups, Vintage Coffee Cups**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
ChaseVintage\\
From shop ChaseVintage\\
\\
(3.8k)\\
\\
\\
$65.00\\
\\
FREE shipping](https://www.etsy.com/listing/4358745877/set-of-two-vintage-french-cafe-au-lait?click_key=LT6be5d5f7a746c5cc2f54530e5cb09770cbba94f0%3A4358745877&click_sum=5cf7d38b&ls=a&ga_order=most_relevant&ga_search_type=all&ga_view_type=gallery&ga_search_query=vintage+porcelain+coffee+cups&ref=search_grid-308840-1-1&frs=1&sts=1 "Set of Two Vintage French Cafe au Lait cups, Set of French Cafe au Lait cups, Vintage Coffee Cups")

- [![May include: A white porcelain tea set with gold floral accents. The set includes a teapot, creamer, sugar bowl, six cups, and six saucers.](https://i.etsystatic.com/35960587/c/2385/2385/172/271/il/9a9189/5766227781/il_300x300.5766227781_4wuc.jpg)\\
\\
**Rosenthal Studio Linie Romance Maggiore Porcelain Coffee Set - Local Pick Up Only**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
TreasuresbyCleo\\
From shop TreasuresbyCleo\\
\\
(373)\\
\\
\\
$677.00\\
\\
FREE shipping](https://www.etsy.com/listing/1654395626/rosenthal-studio-linie-romance-maggiore?click_key=LTa89c4fbaddcbb8b0c5668cbdced99efe976bfbdb%3A1654395626&click_sum=755dfbda&ls=a&ga_order=most_relevant&ga_search_type=all&ga_view_type=gallery&ga_search_query=vintage+porcelain+coffee+cups&ref=search_grid-308840-1-2&frs=1 "Rosenthal Studio Linie Romance Maggiore Porcelain Coffee Set - Local Pick Up Only")

- [![May include: A set of eight porcelain teacups and saucers with gold trim and a floral pattern. The cups and saucers are arranged in a box, with the cups facing up.](https://i.etsystatic.com/28429099/r/il/424933/5658632122/il_300x300.5658632122_n1r1.jpg)\\
\\
**Vintage, Service for 6, MCM JSK Czechoslovakia Porcelain Tea/Coffee Cups and Saucers**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
FigandFernVintage\\
From shop FigandFernVintage\\
\\
(875)\\
\\
\\
Sale Price $131.25\\
$131.25\\
\\
$175.00\\
Original Price $175.00\\
\\
(25% off)\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1640100188/vintage-service-for-6-mcm-jsk?click_key=LTea228d3df6944d5d928d65054a9e7d348bd0f87a%3A1640100188&click_sum=cb585f0f&ls=a&ga_order=most_relevant&ga_search_type=all&ga_view_type=gallery&ga_search_query=vintage+porcelain+coffee+cups&ref=search_grid-308840-1-3&pro=1&frs=1&sts=1 "Vintage, Service for 6, MCM JSK Czechoslovakia Porcelain Tea/Coffee Cups and Saucers")

- [![Vintage Georges Briard Somerset Cups and Saucers, Yellow Gold Accent, Set of 6](https://i.etsystatic.com/50236960/r/il/3c92f6/7362420567/il_300x300.7362420567_79xq.jpg)\\
\\
**Vintage Georges Briard Somerset Cups and Saucers, Yellow Gold Accent, Set of 6**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
SydneyCashHome\\
From shop SydneyCashHome\\
\\
(17)\\
\\
\\
$95.00\\
\\
FREE shipping\\
\\
Ships from GA](https://www.etsy.com/listing/4391398230/vintage-georges-briard-somerset-cups-and?click_key=LT223a43b36fac07e87999bf8803b098a9f67d11b2%3A4391398230&click_sum=a7e23ab8&ls=a&ga_order=most_relevant&ga_search_type=all&ga_view_type=gallery&ga_search_query=vintage+porcelain+coffee+cups&ref=search_grid-308840-1-4&frs=1&loc=1&local_signal_search=1 "Vintage Georges Briard Somerset Cups and Saucers, Yellow Gold Accent, Set of 6")

- [![Porcelain Cup and Saucer Duo, 4 Pairs, Krautheim Germany](https://i.etsystatic.com/58967536/c/761/761/99/259/il/f44faf/7308810135/il_300x300.7308810135_kmh7.jpg)\\
\\
**Porcelain Cup and Saucer Duo, 4 Pairs, Krautheim Germany**\\
\\
(12)\\
\\
\\
Sale Price $14.09\\
$14.09\\
\\
$15.66\\
Original Price $15.66\\
\\
(10% off)](https://www.etsy.com/listing/4382060890/porcelain-cup-and-saucer-duo-4-pairs?click_key=4fe94281-979a-4e8f-b924-c9f93a230d86%3ALTbafcc00c1c113f0578768f6e0cd1f2c63ece4d04&click_sum=0c7ef4d3&ls=s&ga_order=most_relevant&ga_search_type=all&ga_view_type=gallery&ga_search_query=vintage+porcelain+coffee+cups&ref=search_grid-308841-1-1&pro=1&content_source=4fe94281-979a-4e8f-b924-c9f93a230d86%253ALTbafcc00c1c113f0578768f6e0cd1f2c63ece4d04 "Porcelain Cup and Saucer Duo, 4 Pairs, Krautheim Germany")

- [![vintage pair of porcelain white indent cups made in Germany](https://i.etsystatic.com/6454182/r/il/397b4f/7372893536/il_300x300.7372893536_3ehv.jpg)\\
\\
**vintage pair of porcelain white indent cups made in Germany**\\
\\
(2k)\\
\\
\\
$10.00](https://www.etsy.com/listing/1889120449/vintage-pair-of-porcelain-white-indent?click_key=4fe94281-979a-4e8f-b924-c9f93a230d86%3ALT2a35b6bc9850b4eb2556b892dd2dcebe63604293&click_sum=8dda74cd&ls=s&ga_order=most_relevant&ga_search_type=all&ga_view_type=gallery&ga_search_query=vintage+porcelain+coffee+cups&ref=search_grid-308841-1-2&sts=1&content_source=4fe94281-979a-4e8f-b924-c9f93a230d86%253ALT2a35b6bc9850b4eb2556b892dd2dcebe63604293 "vintage pair of porcelain white indent cups made in Germany")

- [![Vintage Porcelain Holiday Pedestal Mugs, Holly Berry Gold Trim, Set of 4](https://i.etsystatic.com/14344980/r/il/d3e048/7407587519/il_300x300.7407587519_m12k.jpg)\\
\\
**Vintage Porcelain Holiday Pedestal Mugs, Holly Berry Gold Trim, Set of 4**\\
\\
(1.4k)\\
\\
\\
Sale Price $24.70\\
$24.70\\
\\
$38.00\\
Original Price $38.00\\
\\
(35% off)](https://www.etsy.com/listing/4399119551/vintage-porcelain-holiday-pedestal-mugs?click_key=4fe94281-979a-4e8f-b924-c9f93a230d86%3ALTa3c66b61e1ae834e1d74f775abc85ae53a82e1e4&click_sum=68fecddf&ls=s&ga_order=most_relevant&ga_search_type=all&ga_view_type=gallery&ga_search_query=vintage+porcelain+coffee+cups&ref=search_grid-308841-1-3&pro=1&sts=1&content_source=4fe94281-979a-4e8f-b924-c9f93a230d86%253ALTa3c66b61e1ae834e1d74f775abc85ae53a82e1e4 "Vintage Porcelain Holiday Pedestal Mugs, Holly Berry Gold Trim, Set of 4")

- [![Vintage 1982 Norman Rockwell Museum Porcelain Gold-Rimmed Artwork Coffee Tea Mug in Box](https://i.etsystatic.com/37183421/r/il/aadea6/7175162240/il_300x300.7175162240_kxfn.jpg)\\
\\
**Vintage 1982 Norman Rockwell Museum Porcelain Gold-Rimmed Artwork Coffee Tea Mug in Box**\\
\\
(597)\\
\\
\\
Sale Price $7.50\\
$7.50\\
\\
$10.00\\
Original Price $10.00\\
\\
(25% off)](https://www.etsy.com/listing/4364710935/vintage-1982-norman-rockwell-museum?click_key=4fe94281-979a-4e8f-b924-c9f93a230d86%3ALTd65a5a5ae56af0c9de00364c4141d576aae59bd7&click_sum=8668c607&ls=s&ga_order=most_relevant&ga_search_type=all&ga_view_type=gallery&ga_search_query=vintage+porcelain+coffee+cups&ref=search_grid-308841-1-4&pro=1&content_source=4fe94281-979a-4e8f-b924-c9f93a230d86%253ALTd65a5a5ae56af0c9de00364c4141d576aae59bd7 "Vintage 1982 Norman Rockwell Museum Porcelain Gold-Rimmed Artwork Coffee Tea Mug in Box")

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...

- Loading...


- Previous page

- Pagination

1

- [Pagination\\
\\
2](https://www.etsy.com/market/vintage_porcelain_coffee_cups?ref=pagination&page=2)
- [Pagination\\
\\
3](https://www.etsy.com/market/vintage_porcelain_coffee_cups?ref=pagination&page=3)
- [Next page](https://www.etsy.com/market/vintage_porcelain_coffee_cups?ref=pagination&page=2)

- Previous page

- Pagination

1

- [Pagination\\
\\
2](https://www.etsy.com/market/vintage_porcelain_coffee_cups?ref=pagination&page=2)
- [Pagination\\
\\
3](https://www.etsy.com/market/vintage_porcelain_coffee_cups?ref=pagination&page=3)
- [Pagination\\
\\
4](https://www.etsy.com/market/vintage_porcelain_coffee_cups?ref=pagination&page=4)
- [Pagination\\
\\
5](https://www.etsy.com/market/vintage_porcelain_coffee_cups?ref=pagination&page=5)
- [Next page](https://www.etsy.com/market/vintage_porcelain_coffee_cups?ref=pagination&page=2)

![](https://i.etsystatic.com/18570320/c/2400/1907/0/851/il/bf20f5/3425857125/il_340x270.3425857125_lheo.jpg)

[Mugs\\
\\
\\
Shop now](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/mugs?ref=market_guides_carousel_category)

![](https://i.etsystatic.com/6184335/r/il/389180/7053328905/il_340x270.7053328905_copi.jpg)

[Tea Cups\\
\\
\\
Shop now](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/tea-cups-and-sets/tea-cups?ref=market_guides_carousel_category)

![](https://i.etsystatic.com/33379415/r/il/fd2cd0/6655535708/il_340x270.6655535708_aeek.jpg)

[Fine Art Ceramics\\
\\
\\
Shop now](https://www.etsy.com/c/art-and-collectibles/fine-art-ceramics?ref=market_guides_carousel_category)

![](https://i.etsystatic.com/5407182/r/il/541d06/2830336657/il_340x270.2830336657_cr2h.jpg)

[Tea Cups & Sets\\
\\
\\
Shop now](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/tea-cups-and-sets?ref=market_guides_carousel_category)

![](https://i.etsystatic.com/22605194/r/il/c158b1/5039519764/il_340x270.5039519764_i4d7.jpg)

[Dining & Serving\\
\\
\\
Shop now](https://www.etsy.com/c/home-and-living/kitchen-and-dining/dining-and-serving?ref=market_guides_carousel_category)

![](https://i.etsystatic.com/5195896/r/il/088085/397051653/il_340x270.397051653_osov.jpg)

[Tea Sets\\
\\
\\
Shop now](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/tea-cups-and-sets/tea-sets?ref=market_guides_carousel_category)

![](https://i.etsystatic.com/21530289/r/il/eb1ce2/2997658090/il_340x270.2997658090_jfuc.jpg)

[Figurines & Knick Knacks\\
\\
\\
Shop now](https://www.etsy.com/c/art-and-collectibles/collectibles/figurines?ref=market_guides_carousel_category)

![](https://i.etsystatic.com/15485413/r/il/5a567c/4855864264/il_340x270.4855864264_bu96.jpg)

[Travel Mugs\\
\\
\\
Shop now](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/mugs/travel-mugs?ref=market_guides_carousel_category)

![](https://i.etsystatic.com/10385964/r/il/f1433e/6671264787/il_340x270.6671264787_snyj.jpg)

[Drinkware\\
\\
\\
Shop now](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware?ref=market_guides_carousel_category)

Review spotlight

These 4 or 5-star reviews represent the opinions of the individuals who posted them and do not reflect the views of Etsy. The
ratings/reviews displayed here may not be representative of every listing on this page, or of every review for these listings. Please click
on a specific listing for more information about its average rating and to see more customer reviews.


Here is a selection of four-star and five-star reviews from customers who were delighted with the products they found in this category.

- [![Buyer Avatar](https://i.etsystatic.com/iusa/65f80b/34965766/iusa_75x75.34965766_i1tm.jpg?version=0)\\
\\
Nicola Solomon\\
\\
5 out of 5 stars\\
\\
"These espresso cups are lovely and just what I asked for. The seller was very helpful and personalised the item just as I asked for.\\
\\
The only downside is that they took a while to arrive, and didn't quite make it for Father's Day as I had hoped. I ordered on 26th May and they arrived today 21st June. I could track their journey across China and Europe to get here (Manchester, UK) so that was interesting!\\
\\
I would still recommend this\\
seller but make sure you order in plenty of time"\\
\\
\\
![Listing Image](https://i.etsystatic.com/18091935/r/il/30d75c/5237911091/il_25x25.5237911091_my5g.jpg)\\
\\
Custom Handmade Ceramic Espresso Cup: Personalized Coffee Gift (2.55oz)](https://www.etsy.com/listing/1316869667/custom-handmade-ceramic-espresso-cup?ref=market_abr)

- [![Buyer Avatar](https://i.etsystatic.com/site-assets/images/avatars/default_avatar.png?width=75)\\
\\
Bernadette Ronner\\
\\
5 out of 5 stars\\
\\
"I give you 6 stars. Notting has broken that the packing was very good and they a very nice cups. It would be nice if you have more of this cups and very happy about it."\\
\\
\\
![Listing Image](https://i.etsystatic.com/23979488/r/il/ef4a3e/5801402346/il_25x25.5801402346_f3ie.jpg)\\
\\
Set of 2 Coffee Cups with Saucers, Blue Chinese Porcelain coffee Set, Oriental Porcelain coffee Set, Asian dishes](https://www.etsy.com/listing/965917148/set-of-2-coffee-cups-with-saucers-blue?ref=market_abr)

- [![Buyer Avatar](https://i.etsystatic.com/site-assets/images/avatars/default_avatar.png?width=75)\\
\\
Angela\\
\\
5 out of 5 stars\\
\\
"Very lovely coffee cups and saucers. The quality is very good. Looks lovely in display cabinet."\\
\\
\\
![Listing Image](https://i.etsystatic.com/25870995/r/il/d2ba28/3289561718/il_25x25.3289561718_evir.jpg)\\
\\
Pair of Vintage Chelson China Porcelain Coffee Cups and Saucers](https://www.etsy.com/listing/1060428982/pair-of-vintage-chelson-china-porcelain?ref=market_abr)

- [![Buyer Avatar](https://i.etsystatic.com/iusa/0577b3/82553779/iusa_75x75.82553779_eyhd.jpg?version=0)\\
\\
Tommy Young\\
\\
5 out of 5 stars\\
\\
"Great quality cups. Exactly what I was wanting. Now my go to cup in the morning."\\
\\
\\
![Listing Image](https://i.etsystatic.com/19156832/r/il/d37e0b/6984441949/il_25x25.6984441949_1tj2.jpg)\\
\\
Handmade Porcelain Espresso Cups: Modern Glazed Espresso/Cortado Cups various glazes -various glazes (90ml) (height 6.5cm width 5cm approx)](https://www.etsy.com/listing/697751955/handmade-porcelain-espresso-cups-modern?ref=market_abr)

- [![Buyer Avatar](https://i.etsystatic.com/site-assets/images/avatars/default_avatar.png?width=75)\\
\\
Emma Mcbride\\
\\
5 out of 5 stars\\
\\
"Beautiful wee coffee mugs! Excellent seller, would highly recommend"\\
\\
\\
![Listing Image](https://i.etsystatic.com/19035017/r/il/0908b4/6945910640/il_25x25.6945910640_4rx9.jpg)\\
\\
BLUT Stoneware Ceramic Espresso Mug, Sake Cup](https://www.etsy.com/listing/914333077/blut-stoneware-ceramic-espresso-mug-sake?ref=market_abr)

- [![Buyer Avatar](https://i.etsystatic.com/site-assets/images/avatars/default_avatar.png?width=75)\\
\\
Louise May\\
\\
5 out of 5 stars\\
\\
"Fast delivery, super friendly comms, superb quality & beautiful mugs - they look amazing displayed on my coffee machine! Thank you!"\\
\\
\\
![Listing Image](https://i.etsystatic.com/19156832/r/il/d09b58/6740163539/il_25x25.6740163539_s309.jpg)\\
\\
Handmade Porcelain Espresso Cups: Modern Glazed Espresso/Cortado Cups, various glazes (90ml) (height 6.5cm width 5cm approx)](https://www.etsy.com/listing/957074749/handmade-porcelain-espresso-cups-modern?ref=market_abr)

- [![Buyer Avatar](https://i.etsystatic.com/site-assets/images/avatars/default_avatar.png?width=75)\\
\\
Ashley\\
\\
5 out of 5 stars\\
\\
"These cups are great quality, the print is also very well done. The seller was fantastic, made sure I was happy with the design and helped me get the product in plenty of time at short notice for a wedding this weekend 11/10!"\\
\\
\\
![Listing Image](https://i.etsystatic.com/19444362/r/il/6490c9/5884220311/il_25x25.5884220311_q9z8.jpg)\\
\\
Personalised Espresso Enamel Cup](https://www.etsy.com/listing/870140567/personalised-espresso-enamel-cup?ref=market_abr)

- [![Buyer Avatar](https://i.etsystatic.com/site-assets/images/avatars/default_avatar.png?width=75)\\
\\
J\\
\\
5 out of 5 stars\\
\\
"This is a beautiful cup and saucer, It was so well packed, I would have no problems in buying from this seller again."\\
\\
\\
![Listing Image](https://i.etsystatic.com/8859167/r/il/848bf6/3634354441/il_25x25.3634354441_bp3r.jpg)\\
\\
Dainty vintage gold and white porcelain flower Espresso cup and saucer](https://www.etsy.com/listing/1157632179/dainty-vintage-gold-and-white-porcelain?ref=market_abr)

- [![Buyer Avatar](https://i.etsystatic.com/site-assets/images/avatars/default_avatar.png?width=75)\\
\\
Jane Buckley\\
\\
5 out of 5 stars\\
\\
"Beautifully wrapped and lovely cup and saucer"\\
\\
\\
![Listing Image](https://i.etsystatic.com/31620786/r/il/6e6c08/3930839178/il_25x25.3930839178_t8ri.jpg)\\
\\
London Boutique Coffee Tea cup and Saucer set Vintage Flora Rose Porcelain Gift Box (1 pc set)](https://www.etsy.com/listing/1234155070/london-boutique-coffee-tea-cup-and?ref=market_abr)


Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Womens Clothing

[Suede Fringe Top for Sale](https://www.etsy.com/market/suede_fringe_top) [Narnia Costumes - US](https://www.etsy.com/market/narnia_costumes)

Gifts & Mementos

[California Marriage License - US](https://www.etsy.com/market/california_marriage_license)

Kitchen & Dining

[Shop German Pie Plate](https://www.etsy.com/market/german_pie_plate) [Science Geek Gadget - US](https://www.etsy.com/market/science_geek_gadget) [Hydrophobic Wooden Cups Handmade for Sale](https://www.etsy.com/market/hydrophobic_wooden_cups_handmade) [Jack Daniels Furniture - US](https://www.etsy.com/market/jack_daniels_furniture) [New Hall Porcelain - US](https://www.etsy.com/market/new_hall_porcelain) [German Bread Basket for Sale](https://www.etsy.com/market/german_bread_basket) [Shop Rare Yellowware](https://www.etsy.com/market/rare_yellowware) [Buy Pre Law Gift Online](https://www.etsy.com/market/pre_law_gift) [Gold Ruby Red Decanter for Sale](https://www.etsy.com/market/gold_ruby_red_decanter)

Books

[Shamrock Notebook for Sale](https://www.etsy.com/market/shamrock_notebook)

Spirituality & Religion

[Pokemons Crystal Ball - US](https://www.etsy.com/market/pokemons_crystal_ball)

Hats & Caps

[Boston Fire Department Hat for Sale](https://www.etsy.com/market/boston_fire_department_hat)

Canvas & Surfaces

[Shop Flower Graduation Cap Clipart](https://www.etsy.com/market/flower_graduation_cap_clipart)

Tools & Equipment

[Buy Potter Hydraulic Press Online](https://www.etsy.com/market/potter_hydraulic_press)

Prints

[La Piscine Print for Sale](https://www.etsy.com/market/la_piscine_print)

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Fmarket%2Fvintage_porcelain_coffee_cups&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc2NjY4MTpmZDE4MzE2Mzk5ZDg5NWVjMGVlNGVmZjc3MDY5MzlhMg==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Fmarket%2Fvintage_porcelain_coffee_cups) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/market/vintage_porcelain_coffee_cups#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Fmarket%2Fvintage_porcelain_coffee_cups)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done