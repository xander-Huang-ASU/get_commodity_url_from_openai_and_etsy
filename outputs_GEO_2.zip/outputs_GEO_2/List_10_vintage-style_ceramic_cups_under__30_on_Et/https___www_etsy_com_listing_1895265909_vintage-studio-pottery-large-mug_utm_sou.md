[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1895265909/vintage-studio-pottery-mug-hand-thrown?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Kitchen & Dining](https://www.etsy.com/c/home-and-living/kitchen-and-dining?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Drink & Barware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)
- [Drinkware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware?utm_source=openai&explicit=1&ref=catnav_breadcrumb-3)
- [Mugs](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/mugs?utm_source=openai&explicit=1&ref=catnav_breadcrumb-4)


Add to Favorites


- ![May include: Nine ceramic mugs with various colors and designs. The mugs are arranged in three rows of three. The mugs are all handmade and have a unique look. The mugs are all different colors, including blue, green, purple, and brown. The mugs are all different shapes and sizes, and some have a handle on the side. The mugs are all made of clay and have a rustic look.](https://i.etsystatic.com/25888227/r/il/76c383/6801370861/il_794xN.6801370861_ggvi.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![May include: A blue ceramic mug with a speckled glaze. The mug has a rounded body and a handle. The mug is shown from four different angles: the front, the side, the inside, and the bottom. The bottom of the mug has a light brown glaze and a small mark that reads 'Mug B'.](https://i.etsystatic.com/25888227/r/il/620c5b/6801412219/il_794xN.6801412219_die6.jpg)
- ![May include: A handmade ceramic mug with a blue, brown, and white glaze. The mug has a rounded body and a handle. The mug is shown from different angles, including the inside and the bottom. The bottom of the mug has a brown stamp that reads 'Daphne's 1133'. Mug F](https://i.etsystatic.com/25888227/r/il/d60c36/6753398692/il_794xN.6753398692_dtfa.jpg)
- ![Vintage Studio Pottery Mug: Hand Thrown Ceramic Stoneware, Drip Glaze J) Blue Purple FP](https://i.etsystatic.com/25888227/r/il/1094b1/7007769339/il_794xN.7007769339_q86e.jpg)
- ![Vintage Studio Pottery Mug: Hand Thrown Ceramic Stoneware, Drip Glaze K) Blue Green FP](https://i.etsystatic.com/25888227/r/il/43a4e2/7007769341/il_794xN.7007769341_ap9l.jpg)
- ![Vintage Studio Pottery Mug: Hand Thrown Ceramic Stoneware, Drip Glaze L) Green blue FP](https://i.etsystatic.com/25888227/r/il/634041/7007769345/il_794xN.7007769345_ns48.jpg)

- ![May include: Nine ceramic mugs with various colors and designs. The mugs are arranged in three rows of three. The mugs are all handmade and have a unique look. The mugs are all different colors, including blue, green, purple, and brown. The mugs are all different shapes and sizes, and some have a handle on the side. The mugs are all made of clay and have a rustic look.](https://i.etsystatic.com/25888227/r/il/76c383/6801370861/il_75x75.6801370861_ggvi.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/file_yvtijh.jpg)

- ![May include: A blue ceramic mug with a speckled glaze. The mug has a rounded body and a handle. The mug is shown from four different angles: the front, the side, the inside, and the bottom. The bottom of the mug has a light brown glaze and a small mark that reads 'Mug B'.](https://i.etsystatic.com/25888227/r/il/620c5b/6801412219/il_75x75.6801412219_die6.jpg)
- ![May include: A handmade ceramic mug with a blue, brown, and white glaze. The mug has a rounded body and a handle. The mug is shown from different angles, including the inside and the bottom. The bottom of the mug has a brown stamp that reads 'Daphne's 1133'. Mug F](https://i.etsystatic.com/25888227/r/il/d60c36/6753398692/il_75x75.6753398692_dtfa.jpg)
- ![Vintage Studio Pottery Mug: Hand Thrown Ceramic Stoneware, Drip Glaze J) Blue Purple FP](https://i.etsystatic.com/25888227/r/il/1094b1/7007769339/il_75x75.7007769339_q86e.jpg)
- ![Vintage Studio Pottery Mug: Hand Thrown Ceramic Stoneware, Drip Glaze K) Blue Green FP](https://i.etsystatic.com/25888227/r/il/43a4e2/7007769341/il_75x75.7007769341_ap9l.jpg)
- ![Vintage Studio Pottery Mug: Hand Thrown Ceramic Stoneware, Drip Glaze L) Green blue FP](https://i.etsystatic.com/25888227/r/il/634041/7007769345/il_75x75.7007769345_ns48.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1895265909%2Fvintage-studio-pottery-mug-hand-thrown%23report-overlay-trigger)

20+ views in the last 24 hours

Price:$24.00+


Loading


# Vintage Studio Pottery Mug: Hand Thrown Ceramic Stoneware, Drip Glaze

[GrandmaGeorgiesHouse](https://www.etsy.com/shop/GrandmaGeorgiesHouse?ref=shop-header-name&listing_id=1895265909&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1895265909/vintage-studio-pottery-mug-hand-thrown?utm_source=openai#reviews)

Arrives soon! Get it by

Nov 15-21


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns accepted

Style


Select an option

B) Blue Speckled ($24.00)

F) Blue Brown ($26.00)

J) Blue Purple FP ($36.00)

K) Blue Green FP \[Sold out\]

L) Green blue FP ($29.00)

Please select an option


You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Item details

### Highlights

Handpicked by [GrandmaGeorgiesHouse](https://www.etsy.com/shop/GrandmaGeorgiesHouse)

- Vintage from the 1990s


- Materials: Ceramic, stone


Beautiful collection of hand thrown studio pottery, all items are vintage circa 1980s-1990s. Fun large handles, large mugs, color fading, stamping, speckles, glazes, etc. There is something for everyone in this collection.

Available, Sold Individually, please choose from the following:

B) Blue speckled stoneware glazed vintage studio pottery mug. Features a nice round shape and thick handle. Bottom is signed by the artist, measures 4" tall x 3.5" diameter, no flaws to note.

F) Blue and brown toned glazed stoneware vintage studio pottery mug. Features a rounded shape and nice thickness throughout. The bottom is signed by the artist, measures 4" Tall x 3" Diameter, no flaws to note.

J) Blue, Purple and Brown stoneware vintage glazed studio pottery mug, marked on the bottom with artist signature "FoxPass", measures 6.25" Tall x 3.5" diameter, no flaws to note.

K) Blue, Green, Purple, and brown undertones stoneware vintage studio pottery. Featuring nice round shape and small thumb holder. The bottom is signed by the artist, FP, probably FoxPass, and measures 5" Tall x 3.25" Diameter, no flaws to note.

L) Sea-foam Green, Blue and Purple with Brown stoneware vintage studio pottery. Featuring round shape and signed by the artist, and studio "FoxPass". Measures 4.5" Tall x 3" Diameter, no flaws to note.

More available in our other listing here: [https://grandmageorgieshouse.etsy.com/listing/1895265745](https://grandmageorgieshouse.etsy.com/listing/1895265745/vintage-studio-pottery-mug-hand-thrown)

Sold out:

A) Green, purple and blue striped glaze ceramic vintage studio pottery mug. Features a ribbed design and large artistic handle. The glaze has a dark undertone with a layered effect. No artist signature on bottom, measures 5" Tall x 3.75" Diameter, no flaws to note.

C) Turquoise Green and blue speckled glazed large vintage stoneware studio pottery mug. Features a nice shape and large handle with very pretty colors. Bottom is signed by the artist, measuring 5.25" Tall x 3.25" Diameter, no flaws to note.

D) Purple and Blue multi colored speckled drip glaze stoneware vintage studio pottery mug. Features a large size, ribbed pattern and large handle in beautiful colors. Bottom is signed by the artist, measures 5" Tall x 4" Diameter, no flaws to note.

E) Two tone blue & brown colored speckled glaze stoneware vintage studio pottery mug. Features a large handle with thumb holder and nice round shape. Bottom is signed by the artist, measures 4.5" Tall x 3.5" Diameter, no flaws to note.

G) Red, Purple & Brown speckled glazed stoneware vintage studio pottery mug. Features a tapered shape and ribbed sizes with a small ribbon handle. No artist signature on the bottom, measures 3.75" Tall x 3" Diameter, no flaws to note.

H) Brown/Purple speckled drip glaze stoneware vintage studio pottery mug. Features a unique imprinted design with large handle. The bottom is signed by the artist and measures 5" Tall x 3.25" Diameter at the top with no flaws to note.

I) Purple, brown and white glazed ceramic vintage studio pottery mug. Features a unique thumbprint imprinted design with great unique glaze. The bottom is signed by the artist and measures 4" Tall x 3.5" Diameter, no flaws to note.

Mugs are in great vintage condition and show light signs of wear/use. Please review all photos and the listing video provided for complete condition details and descriptions.

Thank you for visiting our shop! Want to see more vintage finds from GrandmaGeorgiesHouse? Follow the link below:

[https://grandmageorgieshouse.etsy.com](https://grandmageorgieshouse.etsy.com/)

All of our items are hand picked and curated for your vintage home decor! We love seeing them in their new homes, please share your photos in the Etsy review, or tag us on instagram @grandmageorgies

Please Note: vintage is never perfect! We try our best to point out anything beyond ordinary vintage wear. Please review the entire listing, photos and the listing video carefully. We have put a lot of time into these listings so you can know exactly what you are purchasing. Feel free to reach out with any additional questions, we are happy to help!

Want to see more Coffee Mugs? We have more, follow the link below:

[https://www.etsy.com/shop/GrandmaGeorgiesHouse?ref=seller-platform-mcnav§ion\_id=36503227](https://www.etsy.com/shop/GrandmaGeorgiesHouse?ref=seller-platform-mcnav%C2%A7ion_id=36503227)

## Shipping and return policies

Loading


- Order today to get by

**Nov 15-21**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 21 days


- Ships from: **Denver, CO**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBrazilBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaGabonGambiaGeorgiaGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuineaGuinea-BissauGuyanaHaitiHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth KoreaSpainSri LankaSudanSurinameSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (4)

4.0/5

item average

5.0Item quality

4.3Shipping

4.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Perfect condition

Well packaged

Love it


Filter by category


Ease of use (1)


Seller service (1)


Value (1)


Condition (1)


Shipping & Packaging (1)

4 out of 5 stars
4

This item

[Gail](https://www.etsy.com/people/ljhvhrhg?ref=l_review)
Oct 18, 2025


The item was good. I have
problems with Etsy web site not easy to find info on orders admnd total cost of items.



[Gail](https://www.etsy.com/people/ljhvhrhg?ref=l_review)
Oct 18, 2025


5 out of 5 stars
5

This item

[Karina](https://www.etsy.com/people/pik682yhbpd456hk?ref=l_review)
Jul 22, 2025


Ordered two vintage mugs from this seller. Arrived well packaged and in like new condition.



[Karina](https://www.etsy.com/people/pik682yhbpd456hk?ref=l_review)
Jul 22, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/6009ed/72433039/iusa_75x75.72433039_3nsf.jpg?version=0)

[Susan Williams](https://www.etsy.com/people/yiaxrhjp?ref=l_review)
Apr 29, 2025


Thank you very very much!



![](https://i.etsystatic.com/iusa/6009ed/72433039/iusa_75x75.72433039_3nsf.jpg?version=0)

[Susan Williams](https://www.etsy.com/people/yiaxrhjp?ref=l_review)
Apr 29, 2025


2 out of 5 stars
2

This item

[Kim](https://www.etsy.com/people/hed2cfoa?ref=l_review)
Aug 19, 2025


Sales rep could not tell me if the mug is microwave safe She was professional. However, I would not use this company again because I had to pay over 1/2 the price of the product for return shipping on an item I could not use. So now I'm out money without a product.



[Kim](https://www.etsy.com/people/hed2cfoa?ref=l_review)
Aug 19, 2025


![](https://i.etsystatic.com/iusa/66e89a/83322205/iusa_75x75.83322205_34qk.jpg?version=0)

Response from Ashley Tulare

I’m truly sorry this experience felt disappointing. Because this mug is a vintage piece, I couldn’t guarantee if it was microwave safe, and I did my best to be upfront about that. When you decided to return it, I immediately approved the request and sent instructions. Return shipping is handled by the buyer, and while an expedited method was chosen at the post office, less costly options were available.
I always want my customers to feel confident in their purchases, which is why I provide detailed descriptions and honest communication. I regret that this order didn’t work out, and I appreciate the chance to keep improving the experience for future buyers.



[![GrandmaGeorgiesHouse](https://i.etsystatic.com/iusa/66e89a/83322205/iusa_75x75.83322205_34qk.jpg?version=0)](https://www.etsy.com/shop/GrandmaGeorgiesHouse?ref=shop_profile&listing_id=1895265909)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[GrandmaGeorgiesHouse](https://www.etsy.com/shop/GrandmaGeorgiesHouse?ref=shop_profile&listing_id=1895265909)

[Owned by Ashley Tulare](https://www.etsy.com/shop/GrandmaGeorgiesHouse?ref=shop_profile&listing_id=1895265909) \|

Denver, Colorado

4.9
(1.3k)


3.8k sales

5 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=41464831&referring_id=1895265909&referring_type=listing&recipient_id=41464831&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo0MTQ2NDgzMToxNzYyNzY2NjI3Ojk2ZjkyYjE3ZGEwZThlYjI5MTc5MTVmNzQ1YTQwNWFh&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1895265909%2Fvintage-studio-pottery-mug-hand-thrown%3Futm_source%3Dopenai)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/GrandmaGeorgiesHouse?ref=lp_mys_mfts)

- [![Vintage Studio Pottery Mug: Hand Thrown Ceramic Stoneware, Earth Tones](https://i.etsystatic.com/25888227/r/il/62eeb5/6801372963/il_340x270.6801372963_ohww.jpg)\\
\\
**Vintage Studio Pottery Mug: Hand Thrown Ceramic Stoneware, Earth Tones**\\
\\
$24.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1895265745/vintage-studio-pottery-mug-hand-thrown?click_key=ebadf5c86efe2d33bb4c3a33fc49b0e8%3ALT64a53196fe889aff0efdd78cd644e3bb0e085bd5&click_sum=13f379a0&ls=r&ref=related-1&sts=1&content_source=ebadf5c86efe2d33bb4c3a33fc49b0e8%253ALT64a53196fe889aff0efdd78cd644e3bb0e085bd5 "Vintage Studio Pottery Mug: Hand Thrown Ceramic Stoneware, Earth Tones")




Add to Favorites


- [![Vintage Otagiri Stoneware Mug: Hand-Painted Floral, Nature, Hot Air Balloon](https://i.etsystatic.com/25888227/r/il/a3b210/6852014223/il_340x270.6852014223_ik5r.jpg)\\
\\
**Vintage Otagiri Stoneware Mug: Hand-Painted Floral, Nature, Hot Air Balloon**\\
\\
$18.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1891290626/vintage-otagiri-stoneware-mug-hand?click_key=ebadf5c86efe2d33bb4c3a33fc49b0e8%3ALTf1b9314820d3d9c1447b867ef799c0396f749fcc&click_sum=ec2150ef&ls=r&ref=related-2&sts=1&content_source=ebadf5c86efe2d33bb4c3a33fc49b0e8%253ALTf1b9314820d3d9c1447b867ef799c0396f749fcc "Vintage Otagiri Stoneware Mug: Hand-Painted Floral, Nature, Hot Air Balloon")




Add to Favorites


- [![Vintage Otagiri Stoneware Mug: Hand-Painted Penguin, Owl, Duck](https://i.etsystatic.com/25888227/r/il/8625c5/6804004608/il_340x270.6804004608_h0hv.jpg)\\
\\
**Vintage Otagiri Stoneware Mug: Hand-Painted Penguin, Owl, Duck**\\
\\
$16.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1891290722/vintage-otagiri-stoneware-mug-hand?click_key=ebadf5c86efe2d33bb4c3a33fc49b0e8%3ALT13e20d9ec21e98238bf7afa87b86a29e24180a45&click_sum=5e90f102&ls=r&ref=related-3&sts=1&content_source=ebadf5c86efe2d33bb4c3a33fc49b0e8%253ALT13e20d9ec21e98238bf7afa87b86a29e24180a45 "Vintage Otagiri Stoneware Mug: Hand-Painted Penguin, Owl, Duck")




Add to Favorites


- [![Vintage Decoupage Recipe Card Box: Dovetailed Wood, Filled with Recipes](https://i.etsystatic.com/25888227/r/il/7db73c/7036037761/il_340x270.7036037761_4kvj.jpg)\\
\\
**Vintage Decoupage Recipe Card Box: Dovetailed Wood, Filled with Recipes**\\
\\
$59.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4329488171/vintage-decoupage-recipe-card-box?click_key=81149b729b00b4924a20851760a861b530d6396e%3A4329488171&click_sum=fddc4a46&ref=related-4&sts=1 "Vintage Decoupage Recipe Card Box: Dovetailed Wood, Filled with Recipes")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Oct 7, 2025


[110 favorites](https://www.etsy.com/listing/1895265909/vintage-studio-pottery-mug-hand-thrown/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Kitchen & Dining](https://www.etsy.com/c/home-and-living/kitchen-and-dining?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Drink & Barware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Drinkware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Mugs](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/mugs?utm_source=openai&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Kitchen & Dining

[Sunflower #MyLife travel mug. Custom stainless steel 20oz or 30oz tumbler with sunglasses](https://www.etsy.com/listing/1179951022/sunflower-mylife-travel-mug-custom) [Patriot Glassware for Sale](https://www.etsy.com/market/patriot_glassware) [Buy Farm Truck Magnet Online](https://www.etsy.com/market/farm_truck_magnet) [Personalised Birthday Mug - Year - Name - Birthday Gift by ChasingStarsUK](https://www.etsy.com/listing/1317642003/personalised-birthday-mug-year-name) [Shop Royal Worcester Doughty](https://www.etsy.com/market/royal_worcester_doughty) [Valentines Mug - Kitchen & Dining](https://www.etsy.com/listing/1853635367/valentines-mug-boyfriend-gifts-gift-for) [Buy Alice In Wonderland Apron Online](https://www.etsy.com/market/alice_in_wonderland_apron) [Set Of 4 - Kitchen & Dining](https://www.etsy.com/listing/1537471181/gorgeous-vintage-collectible-novelty) [Summer vibes swimming float Disney Cruise Line magnet](https://www.etsy.com/listing/4306175040/summer-vibes-swimming-float-disney) [Not Today Heifer Black Glitter Tumbler by BDODesigns](https://www.etsy.com/listing/1004720100/not-today-heifer-black-glitter-tumbler)

Earrings

[Tropical fish dangle earrings - Earrings](https://www.etsy.com/listing/684175626/tropical-fish-dangle-earrings)

Womens Clothing

[Lovely RED Oscar De La Renta Bra Slightly Padded w/Underwire size 36B](https://www.etsy.com/listing/1675437580/lovely-red-oscar-de-la-renta-bra)

Toys

[Fungal Dragon by NerdyMinis](https://www.etsy.com/listing/4307246427/fungal-dragon-30mm-32mm-dnd-5e-fateless)

Gender Neutral Adult Clothing

[Buy Women Spiderman Sweatshirt Online](https://www.etsy.com/market/women_spiderman_sweatshirt) [Creedmoor Psychedelic Baseball Tee](https://www.etsy.com/listing/1770201759/creedmoor-psychedelic-baseball-tee)

Findings

[2pc gold large bead caps by EastVillageSupply](https://www.etsy.com/listing/527023885/2pc-gold-large-bead-caps-tassel-caps)

Car Parts & Accessories

[Punk Rock Steering Wheel Cover - US](https://www.etsy.com/market/punk_rock_steering_wheel_cover)

Prints

[Buy Line Drawing Glass Online](https://www.etsy.com/market/line_drawing_glass)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1895265909%2Fvintage-studio-pottery-mug-hand-thrown%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc2NjYyNzpjMzMxMTEyYzM2MTg3YmI5ZDFlMmU5ZjNmZmNjNDM0YQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1895265909%2Fvintage-studio-pottery-mug-hand-thrown%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1895265909/vintage-studio-pottery-mug-hand-thrown?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1895265909%2Fvintage-studio-pottery-mug-hand-thrown%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for GrandmaGeorgiesHouse

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: not accepted

Please contact the seller if you have any problems with your order.

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## Seller details

### Business registration number

### Location

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=41464831&referring_id=25888227&referring_type=shop&recipient_id=41464831&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading


- Item in the photo is in **Style: B) Blue Speckled**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Style: F) Blue Brown**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Style: J) Blue Purple FP**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Style: K) Blue Green FP**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Style: L) Green blue FP**




Select this option








Option selected!













This option is sold out.



Click to zoom

- ![May include: Nine ceramic mugs with various colors and designs. The mugs are arranged in three rows of three. The mugs are all handmade and have a unique look. The mugs are all different colors, including blue, green, purple, and brown. The mugs are all different shapes and sizes, and some have a handle on the side. The mugs are all made of clay and have a rustic look.](https://i.etsystatic.com/25888227/r/il/76c383/6801370861/il_300x300.6801370861_ggvi.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/file_yvtijh.jpg)

- ![May include: A blue ceramic mug with a speckled glaze. The mug has a rounded body and a handle. The mug is shown from four different angles: the front, the side, the inside, and the bottom. The bottom of the mug has a light brown glaze and a small mark that reads 'Mug B'.](https://i.etsystatic.com/25888227/r/il/620c5b/6801412219/il_300x300.6801412219_die6.jpg)
- ![May include: A handmade ceramic mug with a blue, brown, and white glaze. The mug has a rounded body and a handle. The mug is shown from different angles, including the inside and the bottom. The bottom of the mug has a brown stamp that reads 'Daphne's 1133'. Mug F](https://i.etsystatic.com/25888227/r/il/d60c36/6753398692/il_300x300.6753398692_dtfa.jpg)
- ![Vintage Studio Pottery Mug: Hand Thrown Ceramic Stoneware, Drip Glaze J) Blue Purple FP](https://i.etsystatic.com/25888227/r/il/1094b1/7007769339/il_300x300.7007769339_q86e.jpg)
- ![Vintage Studio Pottery Mug: Hand Thrown Ceramic Stoneware, Drip Glaze K) Blue Green FP](https://i.etsystatic.com/25888227/r/il/43a4e2/7007769341/il_300x300.7007769341_ap9l.jpg)
- ![Vintage Studio Pottery Mug: Hand Thrown Ceramic Stoneware, Drip Glaze L) Green blue FP](https://i.etsystatic.com/25888227/r/il/634041/7007769345/il_300x300.7007769345_ns48.jpg)