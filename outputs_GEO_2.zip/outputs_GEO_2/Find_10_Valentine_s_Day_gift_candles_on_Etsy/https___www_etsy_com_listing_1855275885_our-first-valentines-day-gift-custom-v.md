[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1855275885/our-first-valentines-day-gift-custom-v#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?explicit=1&ref=catnav_breadcrumb-3)


Add to Favorites


- ![May include: A white candle in a can with a photo of a couple on the front. The text on the candle reads 'Smells Like Our First Valentine's Day Katie & Michael 2025'.](https://i.etsystatic.com/41052641/r/il/b8a44d/6599693585/il_794xN.6599693585_achp.jpg)
- ![May include: A clear glass candle with a white candle inside. The candle has a label that reads 'Smells Like Our First Valentine's Day Katie & Michael 2023' and a photo of a couple.](https://i.etsystatic.com/41052641/r/il/502b97/6599694203/il_794xN.6599694203_n3ui.jpg)
- ![May include: A white candle with a clear glass jar. The candle has a label that says 'Smells Like Our First Valentine's Day' with the names 'Katie & Michael' and the year '2023' printed in red. The label also has a photo of a couple embracing.](https://i.etsystatic.com/41052641/r/il/6f3fe7/6599694199/il_794xN.6599694199_alzl.jpg)
- ![May include: A white candle with a photo of a couple on the front. The text on the candle reads 'Smells Like Our First Valentine's Day Katie & Michael 2025'. The candle is on a wooden surface. The text 'Love it Guarantee' is in the upper right corner of the image. The text below reads 'We are committed to making you happy! If your candle arrives broken or melted, please let us know and send a photo, and we will be happy to either send out a replacement or a full refund! Innovative Klassies'.](https://i.etsystatic.com/41052641/r/il/ee2cd3/6551575802/il_794xN.6551575802_5eb8.jpg)
- ![May include: A white background with black text and five-star ratings. The text reads 'Our Reviews' and 'Over 2k+ positive reviews across our shop!'  The text also includes customer reviews about the shop's products and services.  The reviews highlight the shop's quick response times, meaningful gifts, personalization options, and excellent quality.](https://i.etsystatic.com/41052641/r/il/b8bd9c/6599662701/il_794xN.6599662701_1xj2.jpg)
- ![May include: A brown cardboard box with a white candle inside. The candle is in a clear glass jar with a white label. The text on the label reads 'Item Specifics'. The text below the label reads 'Eco-friendly and non-toxic. This scented candle is completely natural and non-toxic. It contains no lead, plastics, parabens, synthetic dyes, or phthalates. All candles have a permanent adhesive label. Choose from three scents: Vanilla Bean, Comfort Spice, & Sea Breeze. Materials: 100% natural soy wax blend, 100% cotton wick, and a reusable glass vessel - the vessel can be cleaned after burning the candle and reused as decor. One size: 5' height x 3' diameter - 13.75 oz Burning time: 70-80 hours All scents have the same wax color Packed in a brown cardboard box for presentation and then set in packing paper within an appropriately sized box. Care Instructions - keep burning candle within sight, and keep away from children and pets. Never burn the candle near flammable items. For best results, burn candle 3 to 4 hours of each lighting and trim wick to 1/4'. Discontinue use with 1/2' of wax remaining. The quality of the product is checked in several stages throughout the process. First, we print your label, and then the quality control check is performed. Then we apply the label to your candle and do an inspection of the label image and application. Finally, the order is moved to packaging and shipping upon completion of the quality control checks.'](https://i.etsystatic.com/41052641/r/il/6d46fc/6043258067/il_794xN.6043258067_qvpu.jpg)
- ![May include: A pink and white text graphic with the words 'Returns & Exchanges' in a handwritten font. The text below reads: 'Returns and exchanges are not accepted, as our products are made to order.' The text continues: 'If you run into an issue with your purchase, please reach out ASAP and we will make things right!' The text continues: 'Custom requests are accepted! Please message me if you would like a custom product or design made for you!' The text continues: '**PLEASE NOTE ANY AND ALL ORDER CANCELLATIONS MUST BE REQUESTED WITHIN 2 HOURS - CANCELLATION CANNOT BE GUARANTEED AFTER 2 HOURS SINCE YOUR ORDER HAS BEEN PLACED.**' The text continues: 'Thank You For Supporting My Small Business!' with a series of hearts.](https://i.etsystatic.com/41052641/r/il/c9ddf0/5983164382/il_794xN.5983164382_lb7e.jpg)

- ![May include: A white candle in a can with a photo of a couple on the front. The text on the candle reads 'Smells Like Our First Valentine's Day Katie & Michael 2025'.](https://i.etsystatic.com/41052641/c/2027/2027/469/808/il/b8a44d/6599693585/il_75x75.6599693585_achp.jpg)
- ![May include: A clear glass candle with a white candle inside. The candle has a label that reads 'Smells Like Our First Valentine's Day Katie & Michael 2023' and a photo of a couple.](https://i.etsystatic.com/41052641/r/il/502b97/6599694203/il_75x75.6599694203_n3ui.jpg)
- ![May include: A white candle with a clear glass jar. The candle has a label that says 'Smells Like Our First Valentine's Day' with the names 'Katie & Michael' and the year '2023' printed in red. The label also has a photo of a couple embracing.](https://i.etsystatic.com/41052641/r/il/6f3fe7/6599694199/il_75x75.6599694199_alzl.jpg)
- ![May include: A white candle with a photo of a couple on the front. The text on the candle reads 'Smells Like Our First Valentine's Day Katie & Michael 2025'. The candle is on a wooden surface. The text 'Love it Guarantee' is in the upper right corner of the image. The text below reads 'We are committed to making you happy! If your candle arrives broken or melted, please let us know and send a photo, and we will be happy to either send out a replacement or a full refund! Innovative Klassies'.](https://i.etsystatic.com/41052641/r/il/ee2cd3/6551575802/il_75x75.6551575802_5eb8.jpg)
- ![May include: A white background with black text and five-star ratings. The text reads 'Our Reviews' and 'Over 2k+ positive reviews across our shop!'  The text also includes customer reviews about the shop's products and services.  The reviews highlight the shop's quick response times, meaningful gifts, personalization options, and excellent quality.](https://i.etsystatic.com/41052641/r/il/b8bd9c/6599662701/il_75x75.6599662701_1xj2.jpg)
- ![May include: A brown cardboard box with a white candle inside. The candle is in a clear glass jar with a white label. The text on the label reads 'Item Specifics'. The text below the label reads 'Eco-friendly and non-toxic. This scented candle is completely natural and non-toxic. It contains no lead, plastics, parabens, synthetic dyes, or phthalates. All candles have a permanent adhesive label. Choose from three scents: Vanilla Bean, Comfort Spice, & Sea Breeze. Materials: 100% natural soy wax blend, 100% cotton wick, and a reusable glass vessel - the vessel can be cleaned after burning the candle and reused as decor. One size: 5' height x 3' diameter - 13.75 oz Burning time: 70-80 hours All scents have the same wax color Packed in a brown cardboard box for presentation and then set in packing paper within an appropriately sized box. Care Instructions - keep burning candle within sight, and keep away from children and pets. Never burn the candle near flammable items. For best results, burn candle 3 to 4 hours of each lighting and trim wick to 1/4'. Discontinue use with 1/2' of wax remaining. The quality of the product is checked in several stages throughout the process. First, we print your label, and then the quality control check is performed. Then we apply the label to your candle and do an inspection of the label image and application. Finally, the order is moved to packaging and shipping upon completion of the quality control checks.'](https://i.etsystatic.com/41052641/r/il/6d46fc/6043258067/il_75x75.6043258067_qvpu.jpg)
- ![May include: A pink and white text graphic with the words 'Returns & Exchanges' in a handwritten font. The text below reads: 'Returns and exchanges are not accepted, as our products are made to order.' The text continues: 'If you run into an issue with your purchase, please reach out ASAP and we will make things right!' The text continues: 'Custom requests are accepted! Please message me if you would like a custom product or design made for you!' The text continues: '**PLEASE NOTE ANY AND ALL ORDER CANCELLATIONS MUST BE REQUESTED WITHIN 2 HOURS - CANCELLATION CANNOT BE GUARANTEED AFTER 2 HOURS SINCE YOUR ORDER HAS BEEN PLACED.**' The text continues: 'Thank You For Supporting My Small Business!' with a series of hearts.](https://i.etsystatic.com/41052641/r/il/c9ddf0/5983164382/il_75x75.5983164382_lb7e.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1855275885%2Four-first-valentines-day-gift-custom-v%23report-overlay-trigger)

Price:$29.99+


Loading


# Our First Valentine's Day Gift Custom V-Day Photo Candle for Couple Personalized 1st Vday Gift Him Her Boyfriend Girlfriend New Relationship

Designed by [InnovativeKlassics](https://www.etsy.com/shop/InnovativeKlassics)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1855275885/our-first-valentines-day-gift-custom-v#reviews)

Arrives soon! Get it by

Nov 14-19


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Scents


Select an option

Comfort Spice ($29.99)

Sea Breeze ($30.74)

Vanilla Bean ($30.74)

Please select an option


Photo Style


Select an option

Color

Black & White

Please select an option


Add personalization


- Personalization





Please enter:

1\. Names, separated by either an "&" or "+" symbol

2\. Year

\*\*If no year is entered, the current year will be added by default.



Example:

1\. Kate & Sam

2\. 2025

After check out, please send a high quality photo via Etsy messages, not email :)


















0/200


4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Designed by [InnovativeKlassics](https://www.etsy.com/shop/InnovativeKlassics)

- Materials: Wax type: Soy


- Width: 3 inches

Height: 5 inches

FREE SHIPPING ON ORDERS $75+ WITH CODE "FREESHIP75"

Celebrate your first Valentine’s Day together with this personalized candle, crafted to capture the essence of love. The candle reads “Smells like our first Valentine’s Day together” with your names and the year below in elegant black text, finished off with a custom photo of you and your partner. This custom design makes a perfect, meaningful gift for a new couple or for your boyfriend or girlfriend, adding a personal touch to your Valentine's Day celebration. Whether it’s your first or a special milestone, this candle is a heartfelt way to mark the occasion and create lasting memories!

Our First Valentine's Day Gift Custom V-Day Candle Personalized Gifts for Couple 1st Vday Gift Him Her Boyfriend Girlfriend New Relationship

Add a touch of character to your me-time with these scented candles. Made with a 100% natural soy wax blend, these scented candles feature a 100% cotton wick and deliver 70-80 hours of blissful relaxation.

► One size (3″ × 5") (7.6cm × 12.7cm) - 13.75oz

► Choose from three scents: Vanilla Bean, Comfort Spice, & Sea Breeze.

► 100% natural soy wax blend

► 100% cotton wick

► Average burn time: 70-80 hours

► Permanent adhesive label

► All scents have the same color

► Assembled in the USA from globally sourced parts

Keep the burning candle within sight, and keep away from children and pets. Never burn the candle near flammable items. For best results, burn candle 3 to 4 hours of each lighting and trim wick to 1/4". Discontinue use with 1/2" of wax remaining.

►SHIPPING & PRODUCTION TIME:

Orders will ship in 3-7 business days.

►RETURNS, EXCHANGES, & QUESTIONS:

Please note we do NOT accept any returns/exchanges on our products, as all products are made to order.

If you encounter an issue with your order, please reach out to us right away before leaving a negative review, so we can make things right.

Any and all questions are welcome! We will do our best to get back to you as soon as possible.

Thank you for supporting our small business and we hope you love your product(s)!

Be sure to check out our Etsy page for more products you may love!


### Production partners

InnovativeKlassics makes this item with help from


Printing Assistance, Wilmington, DE


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-19**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges not accepted




But please contact me if you have problems with your order


- Ships from: **Woburn, MA**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## FAQs

Do you offer gift messages or gift wrap?


Unfortunately, we are unable to provide gift wrap, packaging, or gift messages with our orders at this time. We hope to be able to add this feature in the future!


How soon will my order ship and arrive?


The shipping times will vary per item(s). Please look at the estimated arrival date Etsy provides when you are on a listing page for the most accurate arrival time.

Please note, there may be slight delays during the Holiday season due to the large volume of orders that are received around this time.

We do our best to get things shipped to you ASAP, but sometimes, there are issues with the shipping carriers. Thank you!


I only received one item in my order, where is the other item?


If you purchase several different item types, for example, a candle and an ornament, these will ship separately.

Please message me if you have any concerns about the status of an item, and I will get back to you ASAP!


I need to make a change to my order, is it too late?


Any and all orders revisions or cancellation requests should be sent within 2 hours of the purchase. We do our best to get orders out to you ASAP, so they are typically processed within 2 hours.

This would include: changing an address, a candle scent, a personalized item, etc.

While it MAY be possible to still change your order after the 2 hours, please note it is not guaranteed. Thank you!


I have a question about something else.


Please send me a quick message! I typically respond within an hour or a few hours, unless it's the middle of the night or I'm super busy 😊

If you have a custom order request, I'd be more than happy to try to bring your idea to life!


Do you offer discounts for bulk orders?


Please message me directly about this and let me know the quantity you are looking to purchase, and for which item.

Typically, I am able to work something out in terms of a deal 😊


## Reviews for this item (2)

5.0/5

item average

5.0Item quality

5.0Shipping

100%
Buyers recommend

Loading


5 out of 5 stars
5

This item

[justatownit32](https://www.etsy.com/people/justatownit32?ref=l_review)
Mar 9, 2025


Really great product. The candle looked amazing and smelled just as good



[justatownit32](https://www.etsy.com/people/justatownit32?ref=l_review)
Mar 9, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/50f0b3/25589064/iusa_75x75.25589064_lrdm.jpg?version=0)

[Lrager100](https://www.etsy.com/people/Lrager100?ref=l_review)
Jan 24, 2025


Celebrating our first valentines together :)



![](https://i.etsystatic.com/iusa/50f0b3/25589064/iusa_75x75.25589064_lrdm.jpg?version=0)

[Lrager100](https://www.etsy.com/people/Lrager100?ref=l_review)
Jan 24, 2025


[![InnovativeKlassics](https://i.etsystatic.com/iusa/0ed10e/102927424/iusa_75x75.102927424_c61v.jpg?version=0)](https://www.etsy.com/shop/InnovativeKlassics?ref=shop_profile&listing_id=1855275885)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[InnovativeKlassics](https://www.etsy.com/shop/InnovativeKlassics?ref=shop_profile&listing_id=1855275885)

[Owned by Margy](https://www.etsy.com/shop/InnovativeKlassics?ref=shop_profile&listing_id=1855275885) \|

United States

4.9
(4.4k)


27.8k sales

2.5 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=749575314&referring_id=1855275885&referring_type=listing&recipient_id=749575314&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo3NDk1NzUzMTQ6MTc2Mjc4NzIzMzplYjY1OTlkODkwY2E2YWJiYjk4NDlmNjU4Y2YzMWY0ZQ%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1855275885%2Four-first-valentines-day-gift-custom-v)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## All reviews from this shop (4.4k)

Show all

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

## More from this shop

[Visit shop](https://www.etsy.com/shop/InnovativeKlassics?ref=lp_mys_mfts)

- [![Our First Valentine&#39;s Day Gift Custom V-Day Candle Personalized Gifts for Couple 1st Vday Gift Him Her Boyfriend Girlfriend New Relationship](https://i.etsystatic.com/41052641/c/1402/1402/326/358/il/fd3307/6551487572/il_340x270.6551487572_ah02.jpg)\\
\\
**Our First Valentine's Day Gift Custom V-Day Candle Personalized Gifts for Couple 1st Vday Gift Him Her Boyfriend Girlfriend New Relationship**\\
\\
Sale Price $17.74\\
$17.74\\
\\
$23.66\\
Original Price $23.66\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1841054130/our-first-valentines-day-gift-custom-v?click_key=fa1f1fe3b6958bc0a4e70597b917ddf5%3ALTf9f87bd5d87537eb02cace5dc8612fb80ea263b2&click_sum=f213d7ec&ls=r&ref=related-1&pro=1&sts=1&content_source=fa1f1fe3b6958bc0a4e70597b917ddf5%253ALTf9f87bd5d87537eb02cace5dc8612fb80ea263b2 "Our First Valentine's Day Gift Custom V-Day Candle Personalized Gifts for Couple 1st Vday Gift Him Her Boyfriend Girlfriend New Relationship")




Add to Favorites


- [![Funny Trump Valentine&#39;s Day Gift for Husband Boyfriend Trump Gifts for Him Her Men Women Trump Mug Cute Anniversary Coffee Cup for Wife Gift](https://i.etsystatic.com/41052641/c/2777/2777/111/111/il/f7564f/6602173087/il_340x270.6602173087_i9x1.jpg)\\
\\
**Funny Trump Valentine's Day Gift for Husband Boyfriend Trump Gifts for Him Her Men Women Trump Mug Cute Anniversary Coffee Cup for Wife Gift**\\
\\
Sale Price $11.99\\
$11.99\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1841626000/funny-trump-valentines-day-gift-for?click_key=fa1f1fe3b6958bc0a4e70597b917ddf5%3ALT5125d0f859314820bad184667796615caa505c09&click_sum=e5d860bb&ls=r&ref=related-2&pro=1&sts=1&content_source=fa1f1fe3b6958bc0a4e70597b917ddf5%253ALT5125d0f859314820bad184667796615caa505c09 "Funny Trump Valentine's Day Gift for Husband Boyfriend Trump Gifts for Him Her Men Women Trump Mug Cute Anniversary Coffee Cup for Wife Gift")




Add to Favorites


- [![Our First Valentine&#39;s Day Gift Custom V-Day Candle Personalized Gifts for Couple 1st Vday Gift Him Her Boyfriend Girlfriend New Relationship](https://i.etsystatic.com/41052641/c/1264/1264/406/481/il/a294a0/6551491122/il_340x270.6551491122_lx23.jpg)\\
\\
**Our First Valentine's Day Gift Custom V-Day Candle Personalized Gifts for Couple 1st Vday Gift Him Her Boyfriend Girlfriend New Relationship**\\
\\
Sale Price $17.74\\
$17.74\\
\\
$23.66\\
Original Price $23.66\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1855254241/our-first-valentines-day-gift-custom-v?click_key=fa1f1fe3b6958bc0a4e70597b917ddf5%3ALTfe8e670488e17b4349a1665351d3a13bbdcb84b6&click_sum=73e5ecb1&ls=r&ref=related-3&pro=1&sts=1&content_source=fa1f1fe3b6958bc0a4e70597b917ddf5%253ALTfe8e670488e17b4349a1665351d3a13bbdcb84b6 "Our First Valentine's Day Gift Custom V-Day Candle Personalized Gifts for Couple 1st Vday Gift Him Her Boyfriend Girlfriend New Relationship")




Add to Favorites


- [![Funny Wrestling Gifts for Men Women Wrestling Coach Candle for Birthday Christmas Wrestling Team Athlete Sports Present Wrestling Lover Gift](https://i.etsystatic.com/41052641/c/2500/2500/250/500/il/195adf/7427447439/il_340x270.7427447439_rizb.jpg)\\
\\
**Funny Wrestling Gifts for Men Women Wrestling Coach Candle for Birthday Christmas Wrestling Team Athlete Sports Present Wrestling Lover Gift**\\
\\
Sale Price $13.49\\
$13.49\\
\\
$17.99\\
Original Price $17.99\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4402260502/funny-wrestling-gifts-for-men-women?click_key=e4d9d42abb3fafe859b1e99ee8580857882a341b%3A4402260502&click_sum=65d1e6cd&ref=related-4&pro=1&sts=1 "Funny Wrestling Gifts for Men Women Wrestling Coach Candle for Birthday Christmas Wrestling Team Athlete Sports Present Wrestling Lover Gift")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Oct 11, 2025


[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Home Decor

[Beautiful Artist Signed Hand painted Wood Plate - Loon on Lake with Cat Tails- Sharon Grinager - Painters Pride by LynniesVintageFav](https://www.etsy.com/listing/4349635674/beautiful-artist-signed-hand-painted) [RosesAndButterflies](https://www.etsy.com/shop/RosesAndButterflies) [Shop 17 In X 17 In Mirror](https://www.etsy.com/market/17_in_x_17_in_mirror) [Birkin Ornament for Sale](https://www.etsy.com/market/birkin_ornament) [Crochet Flowers Ready Made - US](https://www.etsy.com/market/crochet_flowers_ready_made) [Killer Whales Stone - MADE TO ORDER by PaperPineTree](https://www.etsy.com/listing/647529087/killer-whales-stone-made-to-order) [Ahwaz Old Map for Sale](https://www.etsy.com/market/ahwaz_old_map) [Tashkent - Tashkent Sign - Uzbekistan City - Tashkent Native - Tashkent Gift - Custom Style Sign - Premium Quality Rustic Metal Sign by LiztonVintage](https://www.etsy.com/listing/1298900010/tashkent-tashkent-sign-uzbekistan-city) [Buy Forest Gnome Online](https://www.etsy.com/market/forest_gnome) [Mouse Ears Display by SweetPennyCreations](https://www.etsy.com/listing/728707209/illuminations-display-mouse-ears-display) [18"x24"Whimsical Cat Canvas Art Print by LillybelleBotanicals](https://www.etsy.com/listing/4297589718/18x24whimsical-cat-canvas-art-print) [Wooden Ghost To Paint - US](https://www.etsy.com/market/wooden_ghost_to_paint)

Scarves & Wraps

[Mint green Kaahni woven scarf with delicate floral and paisley patterns–lightweight artisan wrap for gifts - Scarves & Wraps](https://www.etsy.com/listing/4327299365/mint-green-kaahni-woven-scarf-with) [Shop Emerald Shawl](https://www.etsy.com/market/emerald_shawl)

Books

[9th birthday girl - Books](https://www.etsy.com/listing/769288118/9th-birthday-gift-for-9-year-old-girl)

Electronics Cases

[Ipad Accessories For Reading for Sale](https://www.etsy.com/market/ipad_accessories_for_reading)

Prints

[Buy Floral Wall Art Navy Green Online](https://www.etsy.com/market/floral_wall_art_navy_green)

Patterns & How To

[Crochet Pattern](https://www.etsy.com/listing/1469391462/crochet-pattern-granny-square-bag-tote)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1855275885%2Four-first-valentines-day-gift-custom-v&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc4NzIzMzo1NDEyMjM2NjhiZDYyNDgyNGRmYWViNTYyZDcxNzg1Zg==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1855275885%2Four-first-valentines-day-gift-custom-v) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1855275885/our-first-valentines-day-gift-custom-v#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1855275885%2Four-first-valentines-day-gift-custom-v)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for InnovativeKlassics

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 2 hours of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: A white candle in a can with a photo of a couple on the front. The text on the candle reads 'Smells Like Our First Valentine's Day Katie & Michael 2025'.](https://i.etsystatic.com/41052641/c/2027/2027/469/808/il/b8a44d/6599693585/il_300x300.6599693585_achp.jpg)
- ![May include: A clear glass candle with a white candle inside. The candle has a label that reads 'Smells Like Our First Valentine's Day Katie & Michael 2023' and a photo of a couple.](https://i.etsystatic.com/41052641/r/il/502b97/6599694203/il_300x300.6599694203_n3ui.jpg)
- ![May include: A white candle with a clear glass jar. The candle has a label that says 'Smells Like Our First Valentine's Day' with the names 'Katie & Michael' and the year '2023' printed in red. The label also has a photo of a couple embracing.](https://i.etsystatic.com/41052641/r/il/6f3fe7/6599694199/il_300x300.6599694199_alzl.jpg)
- ![May include: A white candle with a photo of a couple on the front. The text on the candle reads 'Smells Like Our First Valentine's Day Katie & Michael 2025'. The candle is on a wooden surface. The text 'Love it Guarantee' is in the upper right corner of the image. The text below reads 'We are committed to making you happy! If your candle arrives broken or melted, please let us know and send a photo, and we will be happy to either send out a replacement or a full refund! Innovative Klassies'.](https://i.etsystatic.com/41052641/r/il/ee2cd3/6551575802/il_300x300.6551575802_5eb8.jpg)
- ![May include: A white background with black text and five-star ratings. The text reads 'Our Reviews' and 'Over 2k+ positive reviews across our shop!'  The text also includes customer reviews about the shop's products and services.  The reviews highlight the shop's quick response times, meaningful gifts, personalization options, and excellent quality.](https://i.etsystatic.com/41052641/r/il/b8bd9c/6599662701/il_300x300.6599662701_1xj2.jpg)
- ![May include: A brown cardboard box with a white candle inside. The candle is in a clear glass jar with a white label. The text on the label reads 'Item Specifics'. The text below the label reads 'Eco-friendly and non-toxic. This scented candle is completely natural and non-toxic. It contains no lead, plastics, parabens, synthetic dyes, or phthalates. All candles have a permanent adhesive label. Choose from three scents: Vanilla Bean, Comfort Spice, & Sea Breeze. Materials: 100% natural soy wax blend, 100% cotton wick, and a reusable glass vessel - the vessel can be cleaned after burning the candle and reused as decor. One size: 5' height x 3' diameter - 13.75 oz Burning time: 70-80 hours All scents have the same wax color Packed in a brown cardboard box for presentation and then set in packing paper within an appropriately sized box. Care Instructions - keep burning candle within sight, and keep away from children and pets. Never burn the candle near flammable items. For best results, burn candle 3 to 4 hours of each lighting and trim wick to 1/4'. Discontinue use with 1/2' of wax remaining. The quality of the product is checked in several stages throughout the process. First, we print your label, and then the quality control check is performed. Then we apply the label to your candle and do an inspection of the label image and application. Finally, the order is moved to packaging and shipping upon completion of the quality control checks.'](https://i.etsystatic.com/41052641/r/il/6d46fc/6043258067/il_300x300.6043258067_qvpu.jpg)
- ![May include: A pink and white text graphic with the words 'Returns & Exchanges' in a handwritten font. The text below reads: 'Returns and exchanges are not accepted, as our products are made to order.' The text continues: 'If you run into an issue with your purchase, please reach out ASAP and we will make things right!' The text continues: 'Custom requests are accepted! Please message me if you would like a custom product or design made for you!' The text continues: '**PLEASE NOTE ANY AND ALL ORDER CANCELLATIONS MUST BE REQUESTED WITHIN 2 HOURS - CANCELLATION CANNOT BE GUARANTEED AFTER 2 HOURS SINCE YOUR ORDER HAS BEEN PLACED.**' The text continues: 'Thank You For Supporting My Small Business!' with a series of hearts.](https://i.etsystatic.com/41052641/r/il/c9ddf0/5983164382/il_300x300.5983164382_lb7e.jpg)

Scroll previousScroll next