[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/573834726/i-love-us-personalized-candle-valentines#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?explicit=1&ref=catnav_breadcrumb-3)
- [Container Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/container-candles?explicit=1&ref=catnav_breadcrumb-4)

Etsy’s Pick

Etsy’s Picks are hand selected by our style experts to highlight items from shops that have shown quality, reliability and style.

[Discover More](https://www.etsy.com/featured/hub/etsy-picks?ref=listing_etsys_pick_signal)


Add to Favorites


- ![May include: Two glass candle jars with silver lids and brown paper labels. The label on the left jar reads 'Brian & Laura' with a small heart and arrow. The label on the right jar reads 'i love us' with a small heart and arrow. Both jars are tied with twine.](https://i.etsystatic.com/6503413/r/il/275d80/1405766374/il_794xN.1405766374_hspq.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![May include: A clear glass jar candle with a silver lid and a brown paper label that says 'i love us' with an arrow and heart design. The candle is tied with twine and is sitting on a white surface.  A brown paper gift bag with a white ribbon is in the background. The gift bag has a label that says 'Dear Brian, Your special note to the one you love. It can say anything you would like. Love, Laura' with an arrow and heart design.](https://i.etsystatic.com/6503413/r/il/5e3121/1452054291/il_794xN.1452054291_dhv7.jpg)
- ![May include: A brown paper gift bag with a white satin ribbon tied around the top. A white label is attached to the front of the bag with the text 'DEAR BRIAN, YOUR SPECIAL NOTE TO THE ONE YOU LOVE. IT CAN SAY ANYTHING YOU WOULD LIKE. LOVE, LAURA' and a simple arrow with a heart design.](https://i.etsystatic.com/6503413/r/il/f65362/1452055131/il_794xN.1452055131_1wz6.jpg)
- ![May include: Two glass candle jars with silver lids and twine bows. The larger jar is labeled '16 oz candle' and the smaller jar is labeled '8 oz candle'.](https://i.etsystatic.com/6503413/r/il/ce476e/1805674471/il_794xN.1805674471_rvow.jpg)
- ![May include: A white candle jar with a white label that reads 'www.thedancingwick.com', 'WARNING!', 'To prevent fire and serious injury burn candle within sight. Keep away from drafts & vibrations. Keep out of reach of children & pets. Never burn candle on or near anything that can catch fire.', 'Burning Instructions:', 'Trim wick to 1/4 inch before lighting. Keep candle free of foreign materials including matches & wick trimmings. Only burn candle on a level surface. Do not burn more than 4 hours at a time.', and 'Apple Pumpkin'.](https://i.etsystatic.com/6503413/r/il/1c389a/1608213552/il_794xN.1608213552_67vx.jpg)
- ![May include: Two glass jars with silver lids and brown paper labels. The jar on the left has a label that says 'Brian & Laura' with a small heart and arrows. The jar on the right has a label that says 'i love us' with a small heart and arrows.](https://i.etsystatic.com/6503413/r/il/15dacc/1452055337/il_794xN.1452055337_ainz.jpg)
- ![May include: A clear glass jar candle with a white label that says 'i love us' with a small heart and arrow. The jar is tied with twine and has a silver lid. The candle is sitting on a white surface.](https://i.etsystatic.com/6503413/r/il/108931/1452054905/il_794xN.1452054905_husr.jpg)
- ![May include: Two glass candle jars with silver lids and brown paper labels. The label on the left jar reads 'Brian & Laura' with an arrow and heart. The label on the right jar reads 'i love us' with an arrow and heart.](https://i.etsystatic.com/6503413/r/il/f7692e/1452064571/il_794xN.1452064571_qjrb.jpg)

- ![May include: Two glass candle jars with silver lids and brown paper labels. The label on the left jar reads 'Brian & Laura' with a small heart and arrow. The label on the right jar reads 'i love us' with a small heart and arrow. Both jars are tied with twine.](https://i.etsystatic.com/6503413/r/il/275d80/1405766374/il_75x75.1405766374_hspq.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/Candle_Product_Description_No_Music_MP4_atgsbi.jpg)

- ![May include: A clear glass jar candle with a silver lid and a brown paper label that says 'i love us' with an arrow and heart design. The candle is tied with twine and is sitting on a white surface.  A brown paper gift bag with a white ribbon is in the background. The gift bag has a label that says 'Dear Brian, Your special note to the one you love. It can say anything you would like. Love, Laura' with an arrow and heart design.](https://i.etsystatic.com/6503413/r/il/5e3121/1452054291/il_75x75.1452054291_dhv7.jpg)
- ![May include: A brown paper gift bag with a white satin ribbon tied around the top. A white label is attached to the front of the bag with the text 'DEAR BRIAN, YOUR SPECIAL NOTE TO THE ONE YOU LOVE. IT CAN SAY ANYTHING YOU WOULD LIKE. LOVE, LAURA' and a simple arrow with a heart design.](https://i.etsystatic.com/6503413/r/il/f65362/1452055131/il_75x75.1452055131_1wz6.jpg)
- ![May include: Two glass candle jars with silver lids and twine bows. The larger jar is labeled '16 oz candle' and the smaller jar is labeled '8 oz candle'.](https://i.etsystatic.com/6503413/r/il/ce476e/1805674471/il_75x75.1805674471_rvow.jpg)
- ![May include: A white candle jar with a white label that reads 'www.thedancingwick.com', 'WARNING!', 'To prevent fire and serious injury burn candle within sight. Keep away from drafts & vibrations. Keep out of reach of children & pets. Never burn candle on or near anything that can catch fire.', 'Burning Instructions:', 'Trim wick to 1/4 inch before lighting. Keep candle free of foreign materials including matches & wick trimmings. Only burn candle on a level surface. Do not burn more than 4 hours at a time.', and 'Apple Pumpkin'.](https://i.etsystatic.com/6503413/r/il/1c389a/1608213552/il_75x75.1608213552_67vx.jpg)
- ![May include: Two glass jars with silver lids and brown paper labels. The jar on the left has a label that says 'Brian & Laura' with a small heart and arrows. The jar on the right has a label that says 'i love us' with a small heart and arrows.](https://i.etsystatic.com/6503413/r/il/15dacc/1452055337/il_75x75.1452055337_ainz.jpg)
- ![May include: A clear glass jar candle with a white label that says 'i love us' with a small heart and arrow. The jar is tied with twine and has a silver lid. The candle is sitting on a white surface.](https://i.etsystatic.com/6503413/r/il/108931/1452054905/il_75x75.1452054905_husr.jpg)
- ![May include: Two glass candle jars with silver lids and brown paper labels. The label on the left jar reads 'Brian & Laura' with an arrow and heart. The label on the right jar reads 'i love us' with an arrow and heart.](https://i.etsystatic.com/6503413/r/il/f7692e/1452064571/il_75x75.1452064571_qjrb.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F573834726%2Fi-love-us-personalized-candle-valentines%23report-overlay-trigger)

Price:$11.52+


Original Price:
$12.80+


Loading


**New markdown!**

10% off


•

Limited time sale


# I love us Personalized Candle / Valentines Day Gift For Him / 16 oz Soy Candle / Anniversary gift / Gift for Her /Gift for Girlfriend

[TheDancingWick](https://www.etsy.com/shop/TheDancingWick?ref=shop-header-name&listing_id=573834726&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/573834726/i-love-us-personalized-candle-valentines#reviews)

Arrives soon! Get it by

Nov 17-24


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Material


Select an option

8oz Candle Only ($11.52 - $14.85)

8oz Candle & Box ($15.57 - $18.45)

16oz Candle Only ($18.00 - $22.50)

16oz Candle & Box ($22.95 - $26.10)

Please select an option


Scent


Select an option

Uncented ($11.52 - $22.95)

Almond Pastries ($14.85 - $26.10)

Apple Cider ($14.85 - $26.10)

Apple Pumpkin ($14.85 - $26.10)

Aruba Coconut ($14.85 - $26.10)

Autumn Walk ($14.85 - $26.10)

Blue Spruce ($14.85 - $26.10)

Blood Orange ($14.85 - $26.10)

Bora Bora ($14.85 - $26.10)

Brown Sugar & Fig ($14.85 - $26.10)

Campfire ($14.85 - $26.10)

Clean Cotton ($14.85 - $26.10)

Coconut Lime Verbena ($14.85 - $26.10)

CocoaButter&Cashmere ($14.85 - $26.10)

Cran Orange Scone ($14.85 - $26.10)

Creme Brulee ($14.85 - $26.10)

Cypress & Bayberry ($14.85 - $26.10)

Earl Grey & Apple ($14.85 - $26.10)

Eucalyptus & Tea ($14.85 - $26.10)

Fraser Fir ($14.85 - $26.10)

Freckled Lemonade ($14.85 - $26.10)

French Vanilla ($14.85 - $26.10)

Fresh Brewed Coffee ($14.85 - $26.10)

Fresh Cut Roses ($14.85 - $26.10)

Frosted Winterberry ($14.85 - $26.10)

Gardenia ($14.85 - $26.10)

Golden Hour ($14.85 - $26.10)

Harvest Chai ($14.85 - $26.10)

Hearthside ($14.85 - $26.10)

Lavender & Seasalt ($14.85 - $26.10)

Lavender Vanilla ($14.85 - $26.10)

Mango & Papaya ($14.85 - $26.10)

Morning Delight ($14.85 - $26.10)

Ocean Breeze ($14.85 - $26.10)

Pumpkin Creme Brulee ($14.85 - $26.10)

Pumpkin Patch ($14.85 - $26.10)

Pumpkin Spice ($14.85 - $26.10)

Sage & Lemongrass ($14.85 - $26.10)

Strawberries & Champ ($14.85 - $26.10)

Sweater Season ($14.85 - $26.10)

Toasted Marshmallow ($14.85 - $26.10)

Vanilla Cake ($14.85 - $26.10)

Vanilla Champagne ($14.85 - $26.10)

Warm Wishes ($14.85 - $26.10)

Wedding Cake ($14.85 - $26.10)

Winter Sparkle ($14.85 - $26.10)

Winter Wonderland ($14.85 - $26.10)

Please select an option


Add personalization


- Personalization





Enter the name you would like on the lid and if purchasing this with the box, your box label instructions. Thank you!! Monika


















0/256


Quantity



123456789101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899100101102103104105106107108109110111112113114115116117118119120121122123124125126127128129130131132133134135136137138139140141142143144145146147148149150151152153154155156157158159160161162163164165166167168169170171172173174175176177178179180181182183184185186187188189190191192193194195196197198199200201202203204205206207208209210211212213214215216217218219220221222223224225226227228229230231232233234235236237238239240241242243244245246247248249250251252253254255256257258259260261262263264265266267268269270271272273274275276277278279280281282283284285286287288289290291292293294295296297298299300301302303304305306307308309310311312313314315316317318319320321322323324325326327328329330331332333334335336337338339340341342343344345346347348349350351352353354355356357358359360361362363364365366367368369370371372373374375376377378379380381382383384385386387388389390391392393394395396397398399400401402403404405406407408409410411412413414415416417418419

4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Item details

### Highlights

Made by [TheDancingWick](https://www.etsy.com/shop/TheDancingWick)

- Materials: Wax type: Soy


- Gift wrapping available

See details

Gift wrapping by TheDancingWick

We will wrap your gift inside a cute custom box (depending on the size of your order) and add a little note from you!!

Looking for the perfect way to say I love you to that special someone? These candles are a wonderful way to tell someone special they are and how much you love them. They come customized with your names on the lid. Be sure to leave your names in the notes section at checkout.

HOW TO ORDER:

1\. Choose your desired material. These come with or without the gable box. If choosing the gable box option, please leave your message for the gable box in the notes section at checkout. If you neglect to leave your message instructions, the label will read I love us, just like the candle.

2\. Choose your desired scent from the drop down box.

3\. In the NOTES SECTION AT CHECKOUT please leave your names and note for the gable box (if choosing the box option).

If you choose to order the gable box please leave your message for the gable box in the notes section at checkout. If you neglect to leave your message instructions, the label will read Love you more, just like the candle. If you are ordering 1 candle, MARKED as a gift, with the gable box, these will be shipped inside the gable box, with label and ribbon attached. If ordering more than 1 candle the gable boxes will be shipped flat with sticker and ribbon NOT attached, this will need to be done by you :-) They are very quick and easy to assemble.

Would you like help choosing a scent? Here's my scent description list, or feel free to message me! :-):

[https://www.etsy.com/listing/622329608/scent-description-list-not-intended-for?ref=shop\_home\_active\_1&frs=1](https://www.etsy.com/listing/622329608/scent-description-list-not-intended-for?ref=shop_home_active_1&frs=1)

Each candle burns 90+ hours, and being 100% soy wax with a 100% cotton wick, you can get maximum enjoyment out of this scent without polluting your home or air. Not only is this a natural burning product it's highly scented (using the maximum amount of scent that the soy wax will allow) it also burns evenly and cleanly so that you get the most for your money. There is barely a trace of wax when your done with your candle. I use only cosmetic grade fragrance oils or pure essential oils. I've been making candles for the past 5 yrs. and have tried 100's of scents and picked only the best smelling ones (I kind of have a fragrance addiction!!!).

For all my local clients, if we have arranged to have me drop the candles off to you at church, school, ballet etc. type in the coupon code REGIONALSHIP and it will delete all shipping costs. Please only apply this coupon if you have first contacted me. Thanks :)

Burning Instructions:

The first time you light the candle, allow it to burn until the liquid wax covers the entire top of the candle. This breaking in process insures that it will perform better and more evenly throughout the life of the candle. This will insure a clean and efficient burning cycle for the life of the candle.

Never leave a burning candle unattended. Keep wicks trimmed to 1/4 inch. If you notice a large flame during burning, blow out the candle & trim the wick before re-lighting. Place burning candle on heat resistant surface. Never move a candle while hot or burning. Blow out the candle if jar becomes excessively hot. Keep out of drafts. Keep out of reach of children.

To prevent candles from boring a hole down the middle, burn candles at a minimum of at least one hour for each inch in diameter. For example burn a 3 inch diameter candle for a minimum of at least 3 hours each time. Burn long enough to achieve a melt pool that can be seen all the way around the glass.

I do customize orders for your personal needs/wants. Just convo me with any changes and we'll do our best to meet your needs.

Thank you so much for shopping handmade. You are making a difference in our lives and we appreciate you more than words can say!!


## Shipping and return policies

Loading


- Order today to get by

**Nov 17-24**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges not accepted




But please contact me if you have problems with your order


- Ships from: **Bixby, OK**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## FAQs

Broken item in shipping


Less than 1% of our packages receive damage during transit. This is due to the high level of care in our packaging of your items. While our goal is to have zero damaged shipments, Breakage does happen time to time due to the nature of glass items & shipping . In the rare event that 1 or more of your items break; Good news. Your package has shipping insurance!! Please take a picture of your broken item inside the box with packaging and a picture of the shipping label on the outside of the box. Send us your pictures along with which of your items were damaged and we will send a replacement out to you within 3 business days or sooner. PLEASE USE CARE WHEN OPENING YOUR PACKAGE. A BROKEN GLASS CANDLE WILL BE SHARP AND COULD CAUSE INJURY.


Frosting or wet spots on candle


When temperatures fluctuate during shipping, it is possible for some candles to develop a light flakey appearance. This is called "frosting" and is very common with candles made from soy wax. Some candles may also develop clear "wet spots" due to the colder temperatures / temperature fluctuations during shipping. This will not effect the candle burn or scent throw of your candle. We do not issue refunds for this as this is a normal trait of soy candles.


Most popular scents


Most popular scents

Here's my top 10 best selling scents. While these come and go with the seasons, these are consistently my top sellers -

1\. Wedding Cake (otherwise known as vanilla cake or birthday cake)

2\. Lavender & Lemongrass

3\. Lavender Vanilla

4\. Strawberries & Champagne

5\. Bora Bora

6\. Clean Cotton

7\. Fresh Cut Roses

8\. Creme Brulee

9\. Ocean Breeze

10\. Eucalyptus & Mint


Wrong Shipping Address


It is your responsibility to make sure you enter the shipping address correctly. Please double check your addresses to make sure they are correct. Especially if you are sending these as a gift. Unfortunately I cannot be held responsible if you incorrectly enter the wrong shipping address. I have absolutely no way of knowing if a shipping address is correct or incorrect. If an item cannot be delivered and is returned to me, it is your responsibility to pay for the item to be re-shipped. If you happen to catch that the shipping address is wrong BEFORE the item ships, please send me a message and I'm more than happy to enter the correct shipping address for you. Thank you for your understanding!!


How do you ship your items?


Most of my items are shipped either UPS or USPS ground


What ingredients do you use to make your candles?


All of my candles are made out of only the finest ingredients. My mom passed away from lung cancer when I was only 28 years old so it is a huge passion of mine!! We use 100% pure soy wax, gmo-free and grown in the USA, 100% pure cotton wicks and phthalate/carcinogen free fragrance oils. I do not add any chemicals to my candle wax to make them "throw" a stronger scent.


Summer Time Shipping


Due to the fact that candle wax can melt, please be sure in the hot summer months to have someone there to receive your packages when delivered or have them held at the Post Office for pick up.


I am purchasing several gift sets can I send them to multiple addresses?


Yes, If you can please purchase them separately per ship to address that works perfect!!


## Meet your sellers

![Monika MacDonald](https://i.etsystatic.com/6503413/r/isla/98b922/69915723/isla_75x75.69915723_i3dr63qc.jpg)

Monika MacDonald

Owner of [TheDancingWick](https://www.etsy.com/shop/TheDancingWick?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoxNjQyNTk4NToxNzYyNzg3MTgwOjRjMGVlZTVmOWFlNWNhMDNmNDQxYzhkOTMzNThjZDZk&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F573834726%2Fi-love-us-personalized-candle-valentines)

[Message Monika](https://www.etsy.com/messages/new?with_id=16425985&referring_id=573834726&referring_type=listing&recipient_id=16425985&from_action=contact-seller)

This seller usually responds **within a few hours.**

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (32)

5.0/5

item average

5.0Item quality

5.0Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Love it

Smells amazing

Gift-worthy

Would recommend

Fast shipping

Great quality

Cute


Filter by category


Quality (12)


Appearance (9)


Seller service (6)


Shipping & Packaging (5)


Comfort (2)


Description accuracy (2)


Value (1)


Ease of use (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Belinda Daniel](https://www.etsy.com/people/bmdaniel72?ref=l_review)
Apr 15, 2025


Great gift idea! Arrived on time



[Belinda Daniel](https://www.etsy.com/people/bmdaniel72?ref=l_review)
Apr 15, 2025


5 out of 5 stars
5

This item

[Benna Millrood](https://www.etsy.com/people/millrood?ref=l_review)
Apr 14, 2025


My husband loved this gift. I will definitely purchase again !



[Benna Millrood](https://www.etsy.com/people/millrood?ref=l_review)
Apr 14, 2025


5 out of 5 stars
5

This item

[Kimberly Leskovar](https://www.etsy.com/people/41d61icgy3xmuuvm?ref=l_review)
Mar 23, 2025


My boyfriend loved!
Would purchase this item again.



[Kimberly Leskovar](https://www.etsy.com/people/41d61icgy3xmuuvm?ref=l_review)
Mar 23, 2025


5 out of 5 stars
5

This item

[Eric Stiefvater](https://www.etsy.com/people/6w2b64gfasxtefsy?ref=l_review)
Mar 7, 2025


High quality and looks great



[Eric Stiefvater](https://www.etsy.com/people/6w2b64gfasxtefsy?ref=l_review)
Mar 7, 2025


View all reviews for this item

### Photos from reviews

![Jessica added a photo of their purchase](https://i.etsystatic.com/iap/2aaaa7/5692969354/iap_300x300.5692969354_432x2jzz.jpg?version=0)

![Pam added a photo of their purchase](https://i.etsystatic.com/iap/1291a2/2173418730/iap_300x300.2173418730_79ydkpm9.jpg?version=0)

![Mary added a photo of their purchase](https://i.etsystatic.com/iap/4dc085/2025906931/iap_300x300.2025906931_dc70g3ns.jpg?version=0)

![Rachel added a photo of their purchase](https://i.etsystatic.com/iap/85d71f/1611696934/iap_300x300.1611696934_60phbuxi.jpg?version=0)

[![TheDancingWick](https://i.etsystatic.com/iusa/9788d1/44510259/iusa_75x75.44510259_jfyt.jpg?version=0)](https://www.etsy.com/shop/TheDancingWick?ref=shop_profile&listing_id=573834726)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[TheDancingWick](https://www.etsy.com/shop/TheDancingWick?ref=shop_profile&listing_id=573834726)

[Owned by Monika MacDonald](https://www.etsy.com/shop/TheDancingWick?ref=shop_profile&listing_id=573834726) \|

Bixby, Oklahoma

4.9
(42.9k)


216.4k sales

14 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=16425985&referring_id=573834726&referring_type=listing&recipient_id=16425985&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoxNjQyNTk4NToxNzYyNzg3MTgwOjRjMGVlZTVmOWFlNWNhMDNmNDQxYzhkOTMzNThjZDZk&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F573834726%2Fi-love-us-personalized-candle-valentines)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/TheDancingWick?ref=lp_mys_mfts)

- [![Light when you want me naked / Personalized, Scented Soy Candle, Anniversary gift, Gift for Him, Boyfriend Gift, valentines gifts for him](https://i.etsystatic.com/6503413/r/il/30d164/6619201693/il_340x270.6619201693_r2p6.jpg)\\
\\
**Light when you want me naked / Personalized, Scented Soy Candle, Anniversary gift, Gift for Him, Boyfriend Gift, valentines gifts for him**\\
\\
Sale Price $7.92\\
$7.92\\
\\
$8.80\\
Original Price $8.80\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1845162570/light-when-you-want-me-naked?click_key=5daccebce05d97d0e5678ca769e8f57e%3ALT0551dbf4b9a19483c54879d5ce406aacc782e475&click_sum=6a920660&ls=r&ref=related-1&pro=1&sts=1&content_source=5daccebce05d97d0e5678ca769e8f57e%253ALT0551dbf4b9a19483c54879d5ce406aacc782e475 "Light when you want me naked / Personalized, Scented Soy Candle, Anniversary gift, Gift for Him, Boyfriend Gift, valentines gifts for him")




Add to Favorites


- [![Smells like you&#39;re stuck with me Personalized Candle / Boyfriend Gift, Gifts For Him, Anniversary, Gifts For Girlfriend, best friend gift](https://i.etsystatic.com/6503413/r/il/b9116b/6591562930/il_340x270.6591562930_slgj.jpg)\\
\\
**Smells like you're stuck with me Personalized Candle / Boyfriend Gift, Gifts For Him, Anniversary, Gifts For Girlfriend, best friend gift**\\
\\
Sale Price $7.92\\
$7.92\\
\\
$8.80\\
Original Price $8.80\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1863525555/smells-like-youre-stuck-with-me?click_key=5daccebce05d97d0e5678ca769e8f57e%3ALTc9da2b520ddd2a4ffcbdc9ea72c17e705e65029c&click_sum=9466784a&ls=r&ref=related-2&pro=1&sts=1&content_source=5daccebce05d97d0e5678ca769e8f57e%253ALTc9da2b520ddd2a4ffcbdc9ea72c17e705e65029c "Smells like you're stuck with me Personalized Candle / Boyfriend Gift, Gifts For Him, Anniversary, Gifts For Girlfriend, best friend gift")




Add to Favorites


- [![Smells like Custom Candle / Scented Candle / Gift For her / Gift For Him / Christmas, Bridesmaid, Funny, Birthday, Retirement, Friendship](https://i.etsystatic.com/6503413/r/il/37a362/6334345798/il_340x270.6334345798_lbjc.jpg)\\
\\
**Smells like Custom Candle / Scented Candle / Gift For her / Gift For Him / Christmas, Bridesmaid, Funny, Birthday, Retirement, Friendship**\\
\\
Sale Price $7.92\\
$7.92\\
\\
$8.80\\
Original Price $8.80\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1736679390/smells-like-custom-candle-scented-candle?click_key=5daccebce05d97d0e5678ca769e8f57e%3ALT9ade5cece28a6047b8772ab2cd908ec4ef5f9350&click_sum=a523dd0d&ls=r&ref=related-3&pro=1&sts=1&content_source=5daccebce05d97d0e5678ca769e8f57e%253ALT9ade5cece28a6047b8772ab2cd908ec4ef5f9350 "Smells like Custom Candle / Scented Candle / Gift For her / Gift For Him / Christmas, Bridesmaid, Funny, Birthday, Retirement, Friendship")




Add to Favorites


- [![Personalized New Parent Candle – Custom Soy Wax Pregnancy Congrats Gift](https://i.etsystatic.com/6503413/r/il/98490c/6954735180/il_340x270.6954735180_kp7c.jpg)\\
\\
**Personalized New Parent Candle – Custom Soy Wax Pregnancy Congrats Gift**\\
\\
Sale Price $7.92\\
$7.92\\
\\
$8.80\\
Original Price $8.80\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4323236864/personalized-new-parent-candle-custom?click_key=2810c763ed9f4237120644d16538a86221386d04%3A4323236864&click_sum=3f1bafae&ref=related-4&pro=1&sts=1 "Personalized New Parent Candle – Custom Soy Wax Pregnancy Congrats Gift")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Oct 25, 2025


[279 favorites](https://www.etsy.com/listing/573834726/i-love-us-personalized-candle-valentines/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?explicit=1&ref=breadcrumb_listing) [Container Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/container-candles?explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Home Decor

[Purple Flowers Wall Painting by metalarct](https://www.etsy.com/listing/1578126717/pink-peonies-floral-printed-metal-canvas) [Natural Green Aventurine Stone Carved Polished by DesertSageCrystals](https://www.etsy.com/listing/941270277/green-aventurine-tower-point-natural) [Buy Inexpensive Art Canvas Online](https://www.etsy.com/market/inexpensive_art_canvas) [Angel Wings Wire Wreath Form by dottiedot05](https://www.etsy.com/listing/278456760/angel-wings-wire-wreath-form) [Union Oil Sign - US](https://www.etsy.com/market/union_oil_sign) [Football Run Through Signs - US](https://www.etsy.com/market/football_run_through_signs) [Shop Paulo Franchi](https://www.etsy.com/market/paulo_franchi) [Coconut Soy Wax Blend](https://www.etsy.com/listing/1428507532/hand-poured-6oz-candle-in-glass-rosemary) [Shop Table Decor](https://www.etsy.com/market/table_decor) [Party Lite Bronze Color Plaster Dolphin Sculpture Votive Candleholder - Home Decor](https://www.etsy.com/listing/4342988134/party-lite-bronze-color-plaster-dolphin) [Buy Lnm Primitives Online](https://www.etsy.com/market/lnm_primitives) [Large Golf Art for Sale](https://www.etsy.com/market/large_golf_art) [Shop Black Lanterns](https://www.etsy.com/market/black_lanterns)

Painting

[Thoroughbred - Painting](https://www.etsy.com/listing/1250530214/thoroughbred)

Beads Gems & Cabochons

[10pcs Clear Crystal Glass Pendant Charm](https://www.etsy.com/listing/734499837/10pcs-clear-crystal-glass-pendant)

Photography

[babyblueprint](https://www.etsy.com/shop/babyblueprint)

Necklaces

[Genuine Turquoise Picture Jasper Pendant Chain Necklace Semiprecious Gemstone Matte 3 Round Beads Sterling Silver Tan Brown Natural - Necklaces](https://www.etsy.com/listing/817130573/genuine-turquoise-picture-jasper-pendant)

Books

[Buy Alfred Lord Tennyson Online](https://www.etsy.com/market/alfred_lord_tennyson)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F573834726%2Fi-love-us-personalized-candle-valentines&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc4NzE4MDpkY2JkMWVlMmE5M2E2ZjU3NDJlYzUyMWVkMDBlYTMzMA==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F573834726%2Fi-love-us-personalized-candle-valentines) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/573834726/i-love-us-personalized-candle-valentines#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F573834726%2Fi-love-us-personalized-candle-valentines)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for TheDancingWick

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: not accepted

Please contact the seller if you have any problems with your order.

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## Seller details

### Business registration number

### Location

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=16425985&referring_id=6503413&referring_type=shop&recipient_id=16425985&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![May include: Two glass candle jars with silver lids and brown paper labels. The label on the left jar reads 'Brian & Laura' with a small heart and arrow. The label on the right jar reads 'i love us' with a small heart and arrow. Both jars are tied with twine.](https://i.etsystatic.com/6503413/r/il/275d80/1405766374/il_300x300.1405766374_hspq.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/Candle_Product_Description_No_Music_MP4_atgsbi.jpg)

- ![May include: A clear glass jar candle with a silver lid and a brown paper label that says 'i love us' with an arrow and heart design. The candle is tied with twine and is sitting on a white surface.  A brown paper gift bag with a white ribbon is in the background. The gift bag has a label that says 'Dear Brian, Your special note to the one you love. It can say anything you would like. Love, Laura' with an arrow and heart design.](https://i.etsystatic.com/6503413/r/il/5e3121/1452054291/il_300x300.1452054291_dhv7.jpg)
- ![May include: A brown paper gift bag with a white satin ribbon tied around the top. A white label is attached to the front of the bag with the text 'DEAR BRIAN, YOUR SPECIAL NOTE TO THE ONE YOU LOVE. IT CAN SAY ANYTHING YOU WOULD LIKE. LOVE, LAURA' and a simple arrow with a heart design.](https://i.etsystatic.com/6503413/r/il/f65362/1452055131/il_300x300.1452055131_1wz6.jpg)
- ![May include: Two glass candle jars with silver lids and twine bows. The larger jar is labeled '16 oz candle' and the smaller jar is labeled '8 oz candle'.](https://i.etsystatic.com/6503413/r/il/ce476e/1805674471/il_300x300.1805674471_rvow.jpg)
- ![May include: A white candle jar with a white label that reads 'www.thedancingwick.com', 'WARNING!', 'To prevent fire and serious injury burn candle within sight. Keep away from drafts & vibrations. Keep out of reach of children & pets. Never burn candle on or near anything that can catch fire.', 'Burning Instructions:', 'Trim wick to 1/4 inch before lighting. Keep candle free of foreign materials including matches & wick trimmings. Only burn candle on a level surface. Do not burn more than 4 hours at a time.', and 'Apple Pumpkin'.](https://i.etsystatic.com/6503413/r/il/1c389a/1608213552/il_300x300.1608213552_67vx.jpg)
- ![May include: Two glass jars with silver lids and brown paper labels. The jar on the left has a label that says 'Brian & Laura' with a small heart and arrows. The jar on the right has a label that says 'i love us' with a small heart and arrows.](https://i.etsystatic.com/6503413/r/il/15dacc/1452055337/il_300x300.1452055337_ainz.jpg)
- ![May include: A clear glass jar candle with a white label that says 'i love us' with a small heart and arrow. The jar is tied with twine and has a silver lid. The candle is sitting on a white surface.](https://i.etsystatic.com/6503413/r/il/108931/1452054905/il_300x300.1452054905_husr.jpg)
- ![May include: Two glass candle jars with silver lids and brown paper labels. The label on the left jar reads 'Brian & Laura' with an arrow and heart. The label on the right jar reads 'i love us' with an arrow and heart.](https://i.etsystatic.com/6503413/r/il/f7692e/1452064571/il_300x300.1452064571_qjrb.jpg)

- ![](https://i.etsystatic.com/iap/2aaaa7/5692969354/iap_640x640.5692969354_432x2jzz.jpg?version=0)

5 out of 5 stars

- Material:

8oz Candle Only

- Scent:

Ocean Breeze


Amazing work , just as I ordered

Jan 21, 2024


[Jessica Gardenhire](https://www.etsy.com/people/caoadoutqtq2gvd9)

Purchased item:

[![I love us Personalized Candle  / Valentines Day Gift For Him  / 16 oz Soy Candle / Anniversary gift / Gift for Her /Gift for Girlfriend](https://i.etsystatic.com/6503413/r/il/275d80/1405766374/il_170x135.1405766374_hspq.jpg)\\
\\
I love us Personalized Candle / Valentines Day Gift For Him / 16 oz Soy Candle / Anniversary gift / Gift for Her /Gift for Girlfriend\\
\\
Sale Price $11.52\\
$11.52\\
\\
$12.80\\
Original Price $12.80\\
\\
\\
(10% off)](https://www.etsy.com/listing/573834726/i-love-us-personalized-candle-valentines?ref=ap-listing)

Purchased item:

[![I love us Personalized Candle  / Valentines Day Gift For Him  / 16 oz Soy Candle / Anniversary gift / Gift for Her /Gift for Girlfriend](https://i.etsystatic.com/6503413/r/il/275d80/1405766374/il_170x135.1405766374_hspq.jpg)\\
\\
I love us Personalized Candle / Valentines Day Gift For Him / 16 oz Soy Candle / Anniversary gift / Gift for Her /Gift for Girlfriend\\
\\
Sale Price $11.52\\
$11.52\\
\\
$12.80\\
Original Price $12.80\\
\\
\\
(10% off)](https://www.etsy.com/listing/573834726/i-love-us-personalized-candle-valentines?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/1291a2/2173418730/iap_640x640.2173418730_79ydkpm9.jpg?version=0)

5 out of 5 stars

- Material:

8oz Candle Only

- Scent:

Aruba Coconut


I love my new candle, it is beautiful and it smells awesome

Jan 31, 2020


[Pam Couch](https://www.etsy.com/people/pamcouch)

Purchased item:

[![I love us Personalized Candle  / Valentines Day Gift For Him  / 16 oz Soy Candle / Anniversary gift / Gift for Her /Gift for Girlfriend](https://i.etsystatic.com/6503413/r/il/275d80/1405766374/il_170x135.1405766374_hspq.jpg)\\
\\
I love us Personalized Candle / Valentines Day Gift For Him / 16 oz Soy Candle / Anniversary gift / Gift for Her /Gift for Girlfriend\\
\\
Sale Price $11.52\\
$11.52\\
\\
$12.80\\
Original Price $12.80\\
\\
\\
(10% off)](https://www.etsy.com/listing/573834726/i-love-us-personalized-candle-valentines?ref=ap-listing)

Purchased item:

[![I love us Personalized Candle  / Valentines Day Gift For Him  / 16 oz Soy Candle / Anniversary gift / Gift for Her /Gift for Girlfriend](https://i.etsystatic.com/6503413/r/il/275d80/1405766374/il_170x135.1405766374_hspq.jpg)\\
\\
I love us Personalized Candle / Valentines Day Gift For Him / 16 oz Soy Candle / Anniversary gift / Gift for Her /Gift for Girlfriend\\
\\
Sale Price $11.52\\
$11.52\\
\\
$12.80\\
Original Price $12.80\\
\\
\\
(10% off)](https://www.etsy.com/listing/573834726/i-love-us-personalized-candle-valentines?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/4dc085/2025906931/iap_640x640.2025906931_dc70g3ns.jpg?version=0)

5 out of 5 stars

- Material:

8oz Candle Only

- Scent:

French Vanilla


The labels are perfect. My mom is gonna love this! So cute Thankyou! Smells great too!!!

![](https://i.etsystatic.com/iusa/3a18ff/105739948/iusa_75x75.105739948_hspi.jpg?version=0)

Aug 17, 2019


[Mary Hopp](https://www.etsy.com/people/maryrq24)

Purchased item:

[![I love us Personalized Candle  / Valentines Day Gift For Him  / 16 oz Soy Candle / Anniversary gift / Gift for Her /Gift for Girlfriend](https://i.etsystatic.com/6503413/r/il/275d80/1405766374/il_170x135.1405766374_hspq.jpg)\\
\\
I love us Personalized Candle / Valentines Day Gift For Him / 16 oz Soy Candle / Anniversary gift / Gift for Her /Gift for Girlfriend\\
\\
Sale Price $11.52\\
$11.52\\
\\
$12.80\\
Original Price $12.80\\
\\
\\
(10% off)](https://www.etsy.com/listing/573834726/i-love-us-personalized-candle-valentines?ref=ap-listing)

Purchased item:

[![I love us Personalized Candle  / Valentines Day Gift For Him  / 16 oz Soy Candle / Anniversary gift / Gift for Her /Gift for Girlfriend](https://i.etsystatic.com/6503413/r/il/275d80/1405766374/il_170x135.1405766374_hspq.jpg)\\
\\
I love us Personalized Candle / Valentines Day Gift For Him / 16 oz Soy Candle / Anniversary gift / Gift for Her /Gift for Girlfriend\\
\\
Sale Price $11.52\\
$11.52\\
\\
$12.80\\
Original Price $12.80\\
\\
\\
(10% off)](https://www.etsy.com/listing/573834726/i-love-us-personalized-candle-valentines?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/85d71f/1611696934/iap_640x640.1611696934_60phbuxi.jpg?version=0)

5 out of 5 stars

- Material:

Candle Only

- Scent:

Autumn Walk


I had a custom order made and it turned out exactly as I asked for!!! And the scent was AMAZING! Love ordering from here- shop owner is super accommodating and ordering is quick and easy. Can’t wait to give it to the newly engaged couple.

![](https://i.etsystatic.com/iusa/a7ddd9/76780098/iusa_75x75.76780098_l2kj.jpg?version=0)

Sep 6, 2018


[Rachel Richard](https://www.etsy.com/people/rerich05)

Purchased item:

[![I love us Personalized Candle  / Valentines Day Gift For Him  / 16 oz Soy Candle / Anniversary gift / Gift for Her /Gift for Girlfriend](https://i.etsystatic.com/6503413/r/il/275d80/1405766374/il_170x135.1405766374_hspq.jpg)\\
\\
I love us Personalized Candle / Valentines Day Gift For Him / 16 oz Soy Candle / Anniversary gift / Gift for Her /Gift for Girlfriend\\
\\
Sale Price $11.52\\
$11.52\\
\\
$12.80\\
Original Price $12.80\\
\\
\\
(10% off)](https://www.etsy.com/listing/573834726/i-love-us-personalized-candle-valentines?ref=ap-listing)

Purchased item:

[![I love us Personalized Candle  / Valentines Day Gift For Him  / 16 oz Soy Candle / Anniversary gift / Gift for Her /Gift for Girlfriend](https://i.etsystatic.com/6503413/r/il/275d80/1405766374/il_170x135.1405766374_hspq.jpg)\\
\\
I love us Personalized Candle / Valentines Day Gift For Him / 16 oz Soy Candle / Anniversary gift / Gift for Her /Gift for Girlfriend\\
\\
Sale Price $11.52\\
$11.52\\
\\
$12.80\\
Original Price $12.80\\
\\
\\
(10% off)](https://www.etsy.com/listing/573834726/i-love-us-personalized-candle-valentines?ref=ap-listing)