[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/702856833/handmade-ceramic-cat-espresso-cup-cat?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Kitchen & Dining](https://www.etsy.com/c/home-and-living/kitchen-and-dining?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Drink & Barware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)
- [Drinkware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware?utm_source=openai&explicit=1&ref=catnav_breadcrumb-3)

Etsy’s Pick

Etsy’s Picks are hand selected by our style experts to highlight items from shops that have shown quality, reliability and style.

[Discover More](https://www.etsy.com/featured/hub/etsy-picks?ref=listing_etsys_pick_signal)


Add to Favorites


- ![May include: A white ceramic mug with a brown cat design. The cat's tail is the handle of the mug.](https://i.etsystatic.com/18091935/r/il/3235af/5189719752/il_794xN.5189719752_ihos.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![May include: A white ceramic mug with a brown cat design. The cat's tail is the handle of the mug.](https://i.etsystatic.com/18091935/r/il/56eb8c/1961874605/il_794xN.1961874605_dbjm.jpg)
- ![Handmade Ceramic Cat Espresso Cup: Cat Lover Coffee Gift (5oz) image 3](https://i.etsystatic.com/18091935/r/il/e2e20a/7109913126/il_794xN.7109913126_q7bg.jpg)
- ![Handmade Ceramic Cat Espresso Cup: Cat Lover Coffee Gift (5oz) image 4](https://i.etsystatic.com/18091935/r/il/453b87/7109913124/il_794xN.7109913124_abxd.jpg)
- ![Handmade Ceramic Cat Espresso Cup: Cat Lover Coffee Gift (5oz) image 5](https://i.etsystatic.com/18091935/r/il/f5d530/7109913128/il_794xN.7109913128_9j0o.jpg)
- ![Handmade Ceramic Cat Espresso Cup: Cat Lover Coffee Gift (5oz) image 6](https://i.etsystatic.com/18091935/r/il/d2c960/7155718603/il_794xN.7155718603_1kny.jpg)
- ![May include: A floral patterned gift wrap with the text 'EACH ORDER IS WRAPPED WITHOUT INVOICE, PERFECT TO SEND RIGHT TO THE RECIPIENT!!'.](https://i.etsystatic.com/18091935/r/il/c657ae/4348910756/il_794xN.4348910756_2djl.jpg)

- ![May include: A white ceramic mug with a brown cat design. The cat's tail is the handle of the mug.](https://i.etsystatic.com/18091935/r/il/3235af/5189719752/il_75x75.5189719752_ihos.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/lv_0_20250814190915_zafkwa.jpg)

- ![May include: A white ceramic mug with a brown cat design. The cat's tail is the handle of the mug.](https://i.etsystatic.com/18091935/r/il/56eb8c/1961874605/il_75x75.1961874605_dbjm.jpg)
- ![Handmade Ceramic Cat Espresso Cup: Cat Lover Coffee Gift (5oz) image 3](https://i.etsystatic.com/18091935/r/il/e2e20a/7109913126/il_75x75.7109913126_q7bg.jpg)
- ![Handmade Ceramic Cat Espresso Cup: Cat Lover Coffee Gift (5oz) image 4](https://i.etsystatic.com/18091935/r/il/453b87/7109913124/il_75x75.7109913124_abxd.jpg)
- ![Handmade Ceramic Cat Espresso Cup: Cat Lover Coffee Gift (5oz) image 5](https://i.etsystatic.com/18091935/r/il/f5d530/7109913128/il_75x75.7109913128_9j0o.jpg)
- ![Handmade Ceramic Cat Espresso Cup: Cat Lover Coffee Gift (5oz) image 6](https://i.etsystatic.com/18091935/r/il/d2c960/7155718603/il_75x75.7155718603_1kny.jpg)
- ![May include: A floral patterned gift wrap with the text 'EACH ORDER IS WRAPPED WITHOUT INVOICE, PERFECT TO SEND RIGHT TO THE RECIPIENT!!'.](https://i.etsystatic.com/18091935/r/il/c657ae/4348910756/il_75x75.4348910756_2djl.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F702856833%2Fhandmade-ceramic-cat-espresso-cup-cat%23report-overlay-trigger)

In 10 carts

NowPrice:$25.20


Original Price:
$28.00


Loading


10% off


•

Sale ends on November 18


# Handmade Ceramic Cat Espresso Cup: Cat Lover Coffee Gift (5oz)

[FireClayArt](https://www.etsy.com/shop/FireClayArt?ref=shop-header-name&listing_id=702856833&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[4.5 out of 5 stars](https://www.etsy.com/listing/702856833/handmade-ceramic-cat-espresso-cup-cat?utm_source=openai#reviews)

Returns & exchanges accepted

Add personalization
(optional)

- Personalization





Want it more special for personalized gift ?



Enter the name you want on the side.(Add engraving)



Max 12 characters, no special characters, Thank you!


















0/12


You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Item details

### Highlights

Made by [FireClayArt](https://www.etsy.com/shop/FireClayArt)

- Materials: Ceramic


- Gift wrapping available

See details![](https://i.etsystatic.com/igwp/7ba827/2012027641/igwp_300xN.2012027641_3fn2bon3.jpg?version=0)

Gift wrapping by FireClayArt

Provide message included and gift packing.

Handmade espresso cups perfect for daily use is finally here!

♥The list is for One Coffee Cup, hold almost 5oz. Dia :2.8’’ Hgt :2.1’’

♥100% handmade item, Each one is slightly different.

♥Food, Dishwasher, Microwave SAFE.

♥FREE STANDARD SHIPPING WORLDWIDE

♥If you LOVE it, it's mean to be yours!

Handmade Ceramic Cat Espresso Cup: Cat Lover Coffee Gift For Cat Mom (5oz)


## Shipping and return policies

Loading


- Order today to get by

**Nov 20-Dec 2**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 30 days


- Free shipping


- Ships from: **China**


Deliver to United States

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## FAQs

Custom and personalized orders


Yes, I love it, just convo me with your requests.


Care instructions


All ceramic are Microwave,Food and Dishwasher Safe


Gift wrapping and packaging


Yes, we provide gift wrapping, refer to related pictures.


Shipping


Processing time

Usually 1-3 days i can send the order out, except custom-made.

Estimated shipping times.

US: 7 -14 days.

Australia: 7-14 day

Europe:2-3 weeks.

Asia Pacific: 2-3 weeks.


## Meet your seller

![Danny](https://i.etsystatic.com/18091935/r/isla/28a85a/43224562/isla_75x75.43224562_1kiskn9g.jpg)

Danny

Owner of [FireClayArt](https://www.etsy.com/shop/FireClayArt?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoxNjE3MjEwOTY6MTc2Mjc2Njg2ODozNTUzZDgzM2I1OGQxZmU4N2IwODY3NDQzNTNmNjViNQ%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F702856833%2Fhandmade-ceramic-cat-espresso-cup-cat%3Futm_source%3Dopenai)

[Message Danny](https://www.etsy.com/messages/new?with_id=161721096&referring_id=702856833&referring_type=listing&recipient_id=161721096&from_action=contact-seller)

This seller usually responds **within a few hours.**

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (38)

4.7/5

item average

4.9Item quality

4.7Shipping

5.0Customer service

86%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Love it

Cute

Gift-worthy

Beautiful

Very well made

Great quality

Great product


Filter by category


Quality (8)


Shipping & Packaging (7)


Description accuracy (6)


Sizing & Fit (4)


Appearance (3)


Value (2)


Condition (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[jill dyck](https://www.etsy.com/people/jillybean6482?ref=l_review)
Oct 6, 2025


I absolutely love it!! Wrapped very well so arrived in perfect condition. Thank you so much!!



![jill dyck added a photo of their purchase](https://i.etsystatic.com/iap/c0537b/7262482080/iap_300x300.7262482080_14snioo1.jpg?version=0)

[jill dyck](https://www.etsy.com/people/jillybean6482?ref=l_review)
Oct 6, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/d8ce73/86046341/iusa_75x75.86046341_oe51.jpg?version=0)

[Nicole Gazzo](https://www.etsy.com/people/gazzo1?ref=l_review)
Oct 3, 2025


This is my new fave espresso cup! Perfect for any murder muffin maker lover! 🖤🐾



![](https://i.etsystatic.com/iusa/d8ce73/86046341/iusa_75x75.86046341_oe51.jpg?version=0)

[Nicole Gazzo](https://www.etsy.com/people/gazzo1?ref=l_review)
Oct 3, 2025


5 out of 5 stars
5

This item

[jill dyck](https://www.etsy.com/people/jillybean6482?ref=l_review)
Aug 24, 2025


It’s beautiful!! My friend will love it! I can’t wait to give it to her! Thank you!!💕



[jill dyck](https://www.etsy.com/people/jillybean6482?ref=l_review)
Aug 24, 2025


5 out of 5 stars
5

This item

[Alexi Galica-Cohen](https://www.etsy.com/people/mhhm0zvmgg3o70eb?ref=l_review)
Mar 22, 2025


Arrived on time and as described!



[Alexi Galica-Cohen](https://www.etsy.com/people/mhhm0zvmgg3o70eb?ref=l_review)
Mar 22, 2025


View all reviews for this item

### Photos from reviews

![jill added a photo of their purchase](https://i.etsystatic.com/iap/c0537b/7262482080/iap_300x300.7262482080_14snioo1.jpg?version=0)

![Z added a photo of their purchase](https://i.etsystatic.com/iap/01928f/4457932184/iap_300x300.4457932184_il6gfdk6.jpg?version=0)

[![FireClayArt](https://i.etsystatic.com/iusa/40fc4b/113362757/iusa_75x75.113362757_9dxy.jpg?version=0)](https://www.etsy.com/shop/FireClayArt?ref=shop_profile&listing_id=702856833)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[FireClayArt](https://www.etsy.com/shop/FireClayArt?ref=shop_profile&listing_id=702856833)

[Owned by Danny](https://www.etsy.com/shop/FireClayArt?ref=shop_profile&listing_id=702856833) \|

Quanzhou, China

4.7
(2.4k)


15k sales

7 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=161721096&referring_id=702856833&referring_type=listing&recipient_id=161721096&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoxNjE3MjEwOTY6MTc2Mjc2Njg2ODozNTUzZDgzM2I1OGQxZmU4N2IwODY3NDQzNTNmNjViNQ%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F702856833%2Fhandmade-ceramic-cat-espresso-cup-cat%3Futm_source%3Dopenai)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

Loading recommendations

Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 7, 2025


[6655 favorites](https://www.etsy.com/listing/702856833/handmade-ceramic-cat-espresso-cup-cat/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Kitchen & Dining](https://www.etsy.com/c/home-and-living/kitchen-and-dining?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Drink & Barware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Drinkware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware?utm_source=openai&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Kitchen & Dining

[Buy Hanging Bat Salt And Pepper Shakers Online](https://www.etsy.com/market/hanging_bat_salt_and_pepper_shakers) [Shop Pantella](https://www.etsy.com/market/pantella) [Vintage Cereal Bowl by Century in the Fannie's Farm Pattern by PipofWhimzy](https://www.etsy.com/listing/4343013404/vintage-cereal-bowl-by-century-in-the) [Chelle Plaque Cookie Cutter - Kitchen & Dining](https://www.etsy.com/listing/241447834/chelle-plaque-cookie-cutter) [Naples Mug for Sale](https://www.etsy.com/market/naples_mug) [Mardi Gras Skinny Tumblers by KBHgifts](https://www.etsy.com/listing/1371791954/mardi-gras-skinny-tumblers) [Shop Fridge Magnets Polymer Clay](https://www.etsy.com/market/fridge_magnets_polymer_clay) [Pink Floral Teapot - US](https://www.etsy.com/market/pink_floral_teapot) [Pie Crust Support for Sale](https://www.etsy.com/market/pie_crust_support) [Personalized Insulated Water Bottle - US](https://www.etsy.com/market/personalized_insulated_water_bottle)

Patterns & How To

[Buy Aa Embroidery Online](https://www.etsy.com/market/aa_embroidery) [Maggie B - US](https://www.etsy.com/market/maggie_b)

Shopping

[1950's Dinette for Sale](https://www.etsy.com/market/1950%27s_dinette) [Media Kit Template Powerpoint for Sale](https://www.etsy.com/market/media_kit_template_powerpoint)

Prints

[Modern Asian Art Print by Yearofthecatart](https://www.etsy.com/listing/1339022114/modern-asian-art-print-contemporary)

Furniture

[Small Indian Wood Cabinet for Sale](https://www.etsy.com/market/small_indian_wood_cabinet)

Painting

[Elemer Kovacs Oil Painting on Canvas of Plowing the Fields by BeckerArtGallery](https://www.etsy.com/listing/665839159/elemer-kovacs-oil-painting-on-canvas-of)

Storage & Organization

[Rice sack laundry bag - 8 variations - Storage & Organization](https://www.etsy.com/listing/1269913659/rice-sack-laundry-bag-8-variations)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F702856833%2Fhandmade-ceramic-cat-espresso-cup-cat%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc2Njg2ODoxNDcyNjI0YTk0ZmY3NGY0YmI0MGU0MzU2NDNkOGFjYg==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F702856833%2Fhandmade-ceramic-cat-espresso-cup-cat%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/702856833/handmade-ceramic-cat-espresso-cup-cat?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F702856833%2Fhandmade-ceramic-cat-espresso-cup-cat%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for FireClayArt

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 6 hours of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


Customs and import taxes

Buyers are responsible for any customs and import taxes that may apply. I'm not responsible for delays due to customs.


## Seller details

### Other details

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=161721096&referring_id=18091935&referring_type=shop&recipient_id=161721096&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![May include: A white ceramic mug with a brown cat design. The cat's tail is the handle of the mug.](https://i.etsystatic.com/18091935/r/il/3235af/5189719752/il_300x300.5189719752_ihos.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/lv_0_20250814190915_zafkwa.jpg)

- ![May include: A white ceramic mug with a brown cat design. The cat's tail is the handle of the mug.](https://i.etsystatic.com/18091935/r/il/56eb8c/1961874605/il_300x300.1961874605_dbjm.jpg)
- ![Handmade Ceramic Cat Espresso Cup: Cat Lover Coffee Gift (5oz) image 3](https://i.etsystatic.com/18091935/r/il/e2e20a/7109913126/il_300x300.7109913126_q7bg.jpg)
- ![Handmade Ceramic Cat Espresso Cup: Cat Lover Coffee Gift (5oz) image 4](https://i.etsystatic.com/18091935/r/il/453b87/7109913124/il_300x300.7109913124_abxd.jpg)
- ![Handmade Ceramic Cat Espresso Cup: Cat Lover Coffee Gift (5oz) image 5](https://i.etsystatic.com/18091935/r/il/f5d530/7109913128/il_300x300.7109913128_9j0o.jpg)
- ![Handmade Ceramic Cat Espresso Cup: Cat Lover Coffee Gift (5oz) image 6](https://i.etsystatic.com/18091935/r/il/d2c960/7155718603/il_300x300.7155718603_1kny.jpg)
- ![May include: A floral patterned gift wrap with the text 'EACH ORDER IS WRAPPED WITHOUT INVOICE, PERFECT TO SEND RIGHT TO THE RECIPIENT!!'.](https://i.etsystatic.com/18091935/r/il/c657ae/4348910756/il_300x300.4348910756_2djl.jpg)

- ![](https://i.etsystatic.com/iap/c0537b/7262482080/iap_640x640.7262482080_14snioo1.jpg?version=0)

5 out of 5 stars

I absolutely love it!! Wrapped very well so arrived in perfect condition. Thank you so much!!

Oct 6, 2025


[jill dyck](https://www.etsy.com/people/jillybean6482)

Purchased item:

[![Handmade Ceramic Cat Espresso Cup: Cat Lover Coffee Gift (5oz)](https://i.etsystatic.com/18091935/r/il/3235af/5189719752/il_170x135.5189719752_ihos.jpg)\\
\\
Handmade Ceramic Cat Espresso Cup: Cat Lover Coffee Gift (5oz)\\
\\
Sale Price $25.20\\
$25.20\\
\\
$28.00\\
Original Price $28.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/702856833/handmade-ceramic-cat-espresso-cup-cat?ref=ap-listing)

Purchased item:

[![Handmade Ceramic Cat Espresso Cup: Cat Lover Coffee Gift (5oz)](https://i.etsystatic.com/18091935/r/il/3235af/5189719752/il_170x135.5189719752_ihos.jpg)\\
\\
Handmade Ceramic Cat Espresso Cup: Cat Lover Coffee Gift (5oz)\\
\\
Sale Price $25.20\\
$25.20\\
\\
$28.00\\
Original Price $28.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/702856833/handmade-ceramic-cat-espresso-cup-cat?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/01928f/4457932184/iap_640x640.4457932184_il6gfdk6.jpg?version=0)

5 out of 5 stars

My mom says it's adorable but she's worried the tail will snap off. Hoping that doesn't happen!

![](https://i.etsystatic.com/iusa/ff7f7d/95779436/iusa_75x75.95779436_qmlu.jpg?version=0)

Dec 23, 2022


[Z](https://www.etsy.com/people/5sr5626z2vpyhfca)

Purchased item:

[![Handmade Ceramic Cat Espresso Cup: Cat Lover Coffee Gift (5oz)](https://i.etsystatic.com/18091935/r/il/3235af/5189719752/il_170x135.5189719752_ihos.jpg)\\
\\
Handmade Ceramic Cat Espresso Cup: Cat Lover Coffee Gift (5oz)\\
\\
Sale Price $25.20\\
$25.20\\
\\
$28.00\\
Original Price $28.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/702856833/handmade-ceramic-cat-espresso-cup-cat?ref=ap-listing)

Purchased item:

[![Handmade Ceramic Cat Espresso Cup: Cat Lover Coffee Gift (5oz)](https://i.etsystatic.com/18091935/r/il/3235af/5189719752/il_170x135.5189719752_ihos.jpg)\\
\\
Handmade Ceramic Cat Espresso Cup: Cat Lover Coffee Gift (5oz)\\
\\
Sale Price $25.20\\
$25.20\\
\\
$28.00\\
Original Price $28.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/702856833/handmade-ceramic-cat-espresso-cup-cat?ref=ap-listing)