[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1587398001/handmade-soy-candle-8-oz-amber-jar?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?utm_source=openai&explicit=1&ref=catnav_breadcrumb-3)
- [Container Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/container-candles?utm_source=openai&explicit=1&ref=catnav_breadcrumb-4)


Add to Favorites


- ![May include: A brown glass candle jar with a white label. The label has the text 'Sunt Basil', 'SEA SALT + ORCHID', 'The candle is infused with essential oils, including sweet orange peel, lemon, eucalyptus and clove leaf.', 'made with love', and 'Soy Wax Candle | 8 oz'. The candle is lit and the flame is visible.](https://i.etsystatic.com/20774660/r/il/bbd1e9/5451522565/il_794xN.5451522565_c8ub.jpg)
- ![May include: A brown glass candle with a lit wick and a white box tied with a black ribbon.](https://i.etsystatic.com/20774660/r/il/58866d/5845666980/il_794xN.5845666980_nmh0.jpg)

- ![May include: A brown glass candle jar with a white label. The label has the text 'Sunt Basil', 'SEA SALT + ORCHID', 'The candle is infused with essential oils, including sweet orange peel, lemon, eucalyptus and clove leaf.', 'made with love', and 'Soy Wax Candle | 8 oz'. The candle is lit and the flame is visible.](https://i.etsystatic.com/20774660/r/il/bbd1e9/5451522565/il_75x75.5451522565_c8ub.jpg)
- ![May include: A brown glass candle with a lit wick and a white box tied with a black ribbon.](https://i.etsystatic.com/20774660/r/il/58866d/5845666980/il_75x75.5845666980_nmh0.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1587398001%2Fhandmade-soy-candle-8-oz-amber-jar%23report-overlay-trigger)

Price:$15.75


Original Price:
$21.00


Loading


25% off


•

Limited time sale


# Handmade Soy Candle: 8 oz Amber Jar, Cotton or Wooden Wick

[SweetBasilCo](https://www.etsy.com/shop/SweetBasilCo?ref=shop-header-name&listing_id=1587398001&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1587398001/handmade-soy-candle-8-oz-amber-jar?utm_source=openai#reviews)

Arrives soon! Get it by

Nov 14-18


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

Scent


Select an option

Baby Powder

Caribbean Teakwood

Cactus Flower & Jade

Lavender

Coffee Shop

Mango and Coconut

Rose Petals

Sea Salt and Orchid

Very Vanilla

White Sage&Lavender

White Tea

White Birch

Other (message me)

Please select an option


Quantity



123456789101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899100101102103104105106107108109110111112113114115116117118119120121122123124125126127128129130131132133134135136137138139140141142143144145146147148149150151152153154155156157158159160161162163164165166167168169170171172173174175176177178179180181182183184185186187188189190191192193194195196197198199200201202203204205206207208209210211212213214215216217218219220221222223224225226227228229230231232233234235236237238239240241242243244245246247248249250251252253254255256257258259260261262263264265266267268269270271272273274275276277278279280281282283284285286287288289290291292293294295296297298299300301302303304305306307308309310311312313314315316317318319320321322323324325326327328329330331332333334335336337338339340341342343344345346347348349350351352353354355356357358359360361362363364365366367368369370371372373374375376377378379380381382383384385386387388389390391392393394395396397398399400401402403404405406407408409410411412413414415416417418419420421422423424425426427428429430431432433434435436437438439440441442443444445446447448449450451452453454455456457458459460461462463464465466467468469470471472473474475476477478479480481482483484485486487488489490491492493494495496497498499500501502503504505506507508509510511512513514515516517518519520521522523524525526527528529530531532533534535536537538539540541542543544545546547548549550551552553554555556557558559560561562563564565566567568569570571572573574575576577578579580581582583584585586587588589590591592593594595596597598599600601602603604605606607608609610611612613614615616617618619620621622623624625626627628629630631632633634635636637638639640641642643644645646647648649650651652653654655656657658659660661662663664665666667668669670671672673674675676677678679680681682683684685686687688689690691692693694695696697698699700701702703704705706707708709710711712713714715716717718719720721722723724725726727728729730731732733734735736737738739740741742743744745746747748749750751752753754755756757758759760761762763764765766767768769770771772773774775776777778779780781782783784785786787788789790791792793794795796797798799800801802803804805806807808809810811812813814815816817818819820821822823824825826827828829830831832833834835836837838839840841842843844845846847848849850851852853854855856857858859860861862863864

You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Item details

### Highlights

Made by [SweetBasilCo](https://www.etsy.com/shop/SweetBasilCo)

- Materials: Wax type: Soy


- Width: 3 inches

Height: 3 inches

Introducing our soy wax candles in amber glass jars made with clean fragrance infused with essential oils. Our candles are hand-poured with 100% soy wax available in cotton braided wicks, creating a clean, environmentally friendly burn or wooden wick providing crackling sound, extended burn time, and a more natural modern look. Choose from 10+ scents to set the mood for any occasion.

\*\*Matches are included but will not be packaged together with the candle to prevent breakage.\*\*

O R D E R I N G:

✦ Select wick

✦ Select scent

C A N D L E D E T A I L S:

✦ 100% soy wax

✦ 8 oz amber glass jar

✦ 40 hours burn time

✦ Cotton braided or wood wick

✦ Clean scents infused with essential oils

✦ Dimensions: 2.9"W x 3.5"H

✦ Hand-poured in Murrieta, CA

S H I P P I N G

✦ All orders will ship out within 2-3 business days plus 2-4 days transit time.

✦ All candles are made by hand. Due to the nature of handmade items, there may be small imperfections.

Thanks For Supporting Small Business! If You're Dissatisfied in Any Way, Please Reach Out So We Can Make It Right.

We don’t guarantee delivery by a specific date and are not responsible for delays. Please upgrade your shipping and allow 2–3 extra days. Refunds won’t be given for late deliveries.


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-18**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 30 days


- Ships from: **Murrieta, CA**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

## Meet your sellers

![Mary](https://i.etsystatic.com/20774660/r/isla/b5a687/76221522/isla_75x75.76221522_owa58ei5.jpg)

Mary

Owner of [SweetBasilCo](https://www.etsy.com/shop/SweetBasilCo?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyMzQ4Mzg3Mzc6MTc2Mjc4NjM0MTo3OGU5Y2QwNGM0NDdkZTRkYzU0ZjgwN2Q2NzQ3Njk5MQ%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1587398001%2Fhandmade-soy-candle-8-oz-amber-jar%3Futm_source%3Dopenai)

[Message Mary](https://www.etsy.com/messages/new?with_id=234838737&referring_id=1587398001&referring_type=listing&recipient_id=234838737&from_action=contact-seller)

This seller usually responds **within a few hours.**

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (19)

4.9/5

item average

4.9Item quality

4.9Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Smells amazing

Love it

Gift-worthy

Would recommend

Beautiful

Well packaged

Cute


Filter by category


Quality (5)


Shipping & Packaging (1)


Appearance (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/c65917/113102729/iusa_75x75.113102729_rujc.jpg?version=0)

[Teagan Lee](https://www.etsy.com/people/baht9jg5?ref=l_review)
May 25, 2025


Smells fantastic! Can't wait to light it!



![](https://i.etsystatic.com/iusa/c65917/113102729/iusa_75x75.113102729_rujc.jpg?version=0)

[Teagan Lee](https://www.etsy.com/people/baht9jg5?ref=l_review)
May 25, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/c65917/113102729/iusa_75x75.113102729_rujc.jpg?version=0)

[Teagan Lee](https://www.etsy.com/people/baht9jg5?ref=l_review)
May 25, 2025


Smells fantastic! Can't wait to light it!



![](https://i.etsystatic.com/iusa/c65917/113102729/iusa_75x75.113102729_rujc.jpg?version=0)

[Teagan Lee](https://www.etsy.com/people/baht9jg5?ref=l_review)
May 25, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/c65917/113102729/iusa_75x75.113102729_rujc.jpg?version=0)

[Teagan Lee](https://www.etsy.com/people/baht9jg5?ref=l_review)
Mar 12, 2025


Smells fantastic! Can't wait to light it!



![](https://i.etsystatic.com/iusa/c65917/113102729/iusa_75x75.113102729_rujc.jpg?version=0)

[Teagan Lee](https://www.etsy.com/people/baht9jg5?ref=l_review)
Mar 12, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/c65917/113102729/iusa_75x75.113102729_rujc.jpg?version=0)

[Teagan Lee](https://www.etsy.com/people/baht9jg5?ref=l_review)
Mar 12, 2025


Smells fantastic! Can't wait to light it!



![](https://i.etsystatic.com/iusa/c65917/113102729/iusa_75x75.113102729_rujc.jpg?version=0)

[Teagan Lee](https://www.etsy.com/people/baht9jg5?ref=l_review)
Mar 12, 2025


View all reviews for this item

### Photos from reviews

![Melanie added a photo of their purchase](https://i.etsystatic.com/iap/674380/6088440659/iap_300x300.6088440659_3hen006t.jpg?version=0)

![Mahogany added a photo of their purchase](https://i.etsystatic.com/iap/fdedb2/5951400717/iap_300x300.5951400717_qevpyjqx.jpg?version=0)

[![SweetBasilCo](https://i.etsystatic.com/iusa/664e5a/89990879/iusa_75x75.89990879_922c.jpg?version=0)](https://www.etsy.com/shop/SweetBasilCo?ref=shop_profile&listing_id=1587398001)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[SweetBasilCo](https://www.etsy.com/shop/SweetBasilCo?ref=shop_profile&listing_id=1587398001)

[Owned by Mary](https://www.etsy.com/shop/SweetBasilCo?ref=shop_profile&listing_id=1587398001) \|

Murrieta, California

4.9
(28.2k)


156.3k sales

6 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=234838737&referring_id=1587398001&referring_type=listing&recipient_id=234838737&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyMzQ4Mzg3Mzc6MTc2Mjc4NjM0MTo3OGU5Y2QwNGM0NDdkZTRkYzU0ZjgwN2Q2NzQ3Njk5MQ%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1587398001%2Fhandmade-soy-candle-8-oz-amber-jar%3Futm_source%3Dopenai)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

Loading recommendations

Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Sep 27, 2025


[62 favorites](https://www.etsy.com/listing/1587398001/handmade-soy-candle-8-oz-amber-jar/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Container Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/container-candles?utm_source=openai&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Home Decor

[Shop Shop The Look Bedroom](https://www.etsy.com/market/shop_the_look_bedroom) [Pastel Polychrome Jasper Chunky Heart Carving - Gray - Home Decor](https://www.etsy.com/listing/1897874067/pastel-polychrome-jasper-chunky-heart) [Clean- Wax Melts/ Flameless/ Michigan/ Themed Scents/ Wax Warmer/ Fragrance/ Hand Crafted/ Camper/ Home/ Gifts/ Scents](https://www.etsy.com/listing/1785972857/clean-wax-melts-flameless-michigan) [Designed by Aimo Nietosvuori](https://www.etsy.com/listing/1884205053/vintage-jie-gantofta-ceramic-wall-plaque) [Buy Puakenikeni Vase Online](https://www.etsy.com/market/puakenikeni_vase) [Buy Dce Curtis Online](https://www.etsy.com/market/dce_curtis) [Fairy Mirrors by BasicCraftsByBecca](https://www.etsy.com/listing/1326106157/fairy-mirrors) [24 inch Tree Chainsaw Carving](https://www.etsy.com/listing/1332957209/24-inch-tree-chainsaw-carving)

Shopping

[Tropical Christmas Font - US](https://www.etsy.com/market/tropical_christmas_font)

Beads Gems & Cabochons

[Multi Tourmaline Beads Gemstone Multi Tourmaline Faceted Pear Shape Beads 5x6 mm to 5x11 mm Size Approx. 9 inch Strand SA No.- 829 by BeadsForJewels](https://www.etsy.com/listing/851630176/multi-tourmaline-beads-gemstone-multi)

Painting

[Steve](https://www.etsy.com/listing/554482256/steve-the-tiger-wih-social-anxiety)

Toys

[Buy Preemie Silicone Pacifiers Online](https://www.etsy.com/market/preemie_silicone_pacifiers) [Ford Explorer Sport Trac 1/18 Scale Model Truck Diecast by Maisto Dark Blue - Toys](https://www.etsy.com/listing/1873390767/maisto-ford-explorer-sport-trac-118)

Patches & Pins

[Slow Down Pin - US](https://www.etsy.com/market/slow_down_pin)

Accessories

[Decal Set Stickers For BMW E39 5 SERIES All Models Best Quality by MrClassicshop](https://www.etsy.com/listing/4340532956/decal-set-stickers-for-bmw-e39-5-series)

Gender Neutral Adult Clothing

[Wake Up with a PACU Nurse Shirt - Gender-Neutral Adult Clothing](https://www.etsy.com/listing/1341356567/wake-up-with-a-pacu-nurse-shirt-retro)

Drawing & Illustration

[Butterfly Confetti PNG for Sublimation - Butterfly Sublimation](https://www.etsy.com/listing/1009838920/butterfly-confetti-png-for-sublimation)

Fabric & Notions

[100% Cotton Quilting Fabric. Fat Quarter Bundle - Fabric & Notions](https://www.etsy.com/listing/956221161/fat-quarters-set-of-ten-blue-fat)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1587398001%2Fhandmade-soy-candle-8-oz-amber-jar%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc4NjM0MTpiMjNmYjVjNDkzMGQxMWY5YzdmYjhlZDhlNWY2YzU0ZQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1587398001%2Fhandmade-soy-candle-8-oz-amber-jar%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1587398001/handmade-soy-candle-8-oz-amber-jar?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1587398001%2Fhandmade-soy-candle-8-oz-amber-jar%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Seller details

### Business registration number

### Location

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=234838737&referring_id=20774660&referring_type=shop&recipient_id=234838737&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: A brown glass candle jar with a white label. The label has the text 'Sunt Basil', 'SEA SALT + ORCHID', 'The candle is infused with essential oils, including sweet orange peel, lemon, eucalyptus and clove leaf.', 'made with love', and 'Soy Wax Candle | 8 oz'. The candle is lit and the flame is visible.](https://i.etsystatic.com/20774660/r/il/bbd1e9/5451522565/il_300x300.5451522565_c8ub.jpg)
- ![May include: A brown glass candle with a lit wick and a white box tied with a black ribbon.](https://i.etsystatic.com/20774660/r/il/58866d/5845666980/il_300x300.5845666980_nmh0.jpg)

- ![](https://i.etsystatic.com/iap/674380/6088440659/iap_640x640.6088440659_3hen006t.jpg?version=0)

5 out of 5 stars

- Select Wick:

Cotton Braided Wick

- Scent:

White Sage&Lavender


It’s always a gamble buying candles you can’t smell first, but I was pleased with this fragrance! Smells a little high-end in my opinion, like something from a fancy hotel. I love the modern aesthetic and the small glass vial of matches it came with was so cute and stylish! The presentation would make a great gift.

Jun 5, 2024


[Melanie Cruff](https://www.etsy.com/people/PaisleyDazey)

Purchased item:

[![Handmade Soy Candle: 8 oz Amber Jar, Cotton or Wooden Wick](https://i.etsystatic.com/20774660/r/il/bbd1e9/5451522565/il_170x135.5451522565_c8ub.jpg)\\
\\
Handmade Soy Candle: 8 oz Amber Jar, Cotton or Wooden Wick\\
\\
Sale Price $15.75\\
$15.75\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(25% off)](https://www.etsy.com/listing/1587398001/handmade-soy-candle-8-oz-amber-jar?ref=ap-listing)

Purchased item:

[![Handmade Soy Candle: 8 oz Amber Jar, Cotton or Wooden Wick](https://i.etsystatic.com/20774660/r/il/bbd1e9/5451522565/il_170x135.5451522565_c8ub.jpg)\\
\\
Handmade Soy Candle: 8 oz Amber Jar, Cotton or Wooden Wick\\
\\
Sale Price $15.75\\
$15.75\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(25% off)](https://www.etsy.com/listing/1587398001/handmade-soy-candle-8-oz-amber-jar?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/fdedb2/5951400717/iap_640x640.5951400717_qevpyjqx.jpg?version=0)

5 out of 5 stars

- Select Wick:

Cotton Braided Wick

- Scent:

Sea Salt and Orchid


Got this candle as a part of a gift box, and fell in love with the scent. I had to purchase in a bigger size. Love love love. And they added matches, so cute.

![](https://i.etsystatic.com/iusa/d2c65c/50177027/iusa_75x75.50177027_2r86.jpg?version=0)

Apr 8, 2024


[Mahogany Kincaid](https://www.etsy.com/people/kincaidmahogany)

Purchased item:

[![Handmade Soy Candle: 8 oz Amber Jar, Cotton or Wooden Wick](https://i.etsystatic.com/20774660/r/il/bbd1e9/5451522565/il_170x135.5451522565_c8ub.jpg)\\
\\
Handmade Soy Candle: 8 oz Amber Jar, Cotton or Wooden Wick\\
\\
Sale Price $15.75\\
$15.75\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(25% off)](https://www.etsy.com/listing/1587398001/handmade-soy-candle-8-oz-amber-jar?ref=ap-listing)

Purchased item:

[![Handmade Soy Candle: 8 oz Amber Jar, Cotton or Wooden Wick](https://i.etsystatic.com/20774660/r/il/bbd1e9/5451522565/il_170x135.5451522565_c8ub.jpg)\\
\\
Handmade Soy Candle: 8 oz Amber Jar, Cotton or Wooden Wick\\
\\
Sale Price $15.75\\
$15.75\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(25% off)](https://www.etsy.com/listing/1587398001/handmade-soy-candle-8-oz-amber-jar?ref=ap-listing)