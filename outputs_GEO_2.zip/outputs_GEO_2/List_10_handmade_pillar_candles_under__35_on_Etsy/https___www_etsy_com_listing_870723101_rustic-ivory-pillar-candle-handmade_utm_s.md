[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?utm_source=openai&explicit=1&ref=catnav_breadcrumb-3)
- [Pillar Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/pillar-candles?utm_source=openai&explicit=1&ref=catnav_breadcrumb-4)


Add to Favorites


- ![May include: A cylindrical, light beige candle with a slightly textured surface sits in front of a blurred green background. The candle is unlit, showing a short, off-white wick.  The color is a pale, creamy beige with subtle variations in tone. The candle appears to be made of a wax-like material, giving it a slightly rough texture. The overall impression is one of serenity and relaxation, suitable for spa or home decor.](https://i.etsystatic.com/6635959/r/il/a8fb5f/1223793356/il_794xN.1223793356_hlg9.jpg)
- ![May include: A cylindrical, light beige candle with a slightly textured surface sits on a dark surface. The candle has a single visible wick in the center.  The color is a pale, creamy yellow-beige. The candle is solid and unlit. It appears to be made of wax. The overall style is simple and elegant, suitable for home décor or gifting.](https://i.etsystatic.com/6635959/r/il/52cba5/1271012665/il_794xN.1271012665_2jw0.jpg)
- ![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle image 3](https://i.etsystatic.com/6635959/r/il/3bac38/7321958854/il_794xN.7321958854_npvg.jpg)
- ![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle image 4](https://i.etsystatic.com/6635959/r/il/df3e09/7369906831/il_794xN.7369906831_td1m.jpg)

- ![May include: A cylindrical, light beige candle with a slightly textured surface sits in front of a blurred green background. The candle is unlit, showing a short, off-white wick.  The color is a pale, creamy beige with subtle variations in tone. The candle appears to be made of a wax-like material, giving it a slightly rough texture. The overall impression is one of serenity and relaxation, suitable for spa or home decor.](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_75x75.1223793356_hlg9.jpg)
- ![May include: A cylindrical, light beige candle with a slightly textured surface sits on a dark surface. The candle has a single visible wick in the center.  The color is a pale, creamy yellow-beige. The candle is solid and unlit. It appears to be made of wax. The overall style is simple and elegant, suitable for home décor or gifting.](https://i.etsystatic.com/6635959/r/il/52cba5/1271012665/il_75x75.1271012665_2jw0.jpg)
- ![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle image 3](https://i.etsystatic.com/6635959/r/il/3bac38/7321958854/il_75x75.7321958854_npvg.jpg)
- ![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle image 4](https://i.etsystatic.com/6635959/r/il/df3e09/7369906831/il_75x75.7369906831_td1m.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F870723101%2Frustic-ivory-pillar-candle-handmade%23report-overlay-trigger)

In 16 carts

NowPrice:$14.40+


Original Price:
$16.00+


Loading


**New markdown!**

10% off


•

Sale ends in 14:44:29

# Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle

Made by [StillWaterCandles](https://www.etsy.com/shop/StillWaterCandles)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?utm_source=openai#reviews)

Arrives soon! Get it by

Nov 14-20


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

SIZE


Select an option

3" WIDE x 4" tall ($14.40)

3" WIDE x 6" tall ($16.20)

3" WIDE x 9" tall ($19.80)

3.5" WIDE x 4" tall ($16.20)

4" WIDE x 4" tall ($18.00)

4" WIDE x 6" tall ($22.50)

4" WIDE x 9" tall ($26.10)

6" WIDE x 4" tall ($27.00)

6" WIDE x 6" tall ($41.40)

6" WIDE x 9" tall ($60.30)

6" WIDE x 12" tall ($76.50)

6" WIDE x 15" tall ($95.40)

7" WIDE x 4" tall ($39.60)

7" WIDE x 6" tall ($54.90)

7" WIDE x 9" tall ($78.30)

7" WIDE x 12" tall ($103.50)

Please select an option


Quantity



1234567891011121314151617181920212223242526272829303132333435363738394041424344454647484950515253545556575859

You can only make an offer when buying a single item


Add to cart



Loading


## Buy together, get free shipping

## Buy together, get free shipping

Add 3 items to cart



Loading


[See more items](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?utm_source=openai#recs_ribbon_container)

![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_340x270.1223793356_hlg9.jpg)
This listing

### Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle

Sale Price $14.40
$14.40

$16.00
Original Price $16.00


(10% off)




Add to Favorites


[![Rustic Light Brown Unscented Pillar Candle: Handmade Textured Farmhouse Decor](https://i.etsystatic.com/6635959/c/1291/1025/0/189/il/2a1e8a/1270825149/il_340x270.1270825149_e0ux.jpg)\\
\\
**Rustic Light Brown Unscented Pillar Candle: Handmade Textured Farmhouse Decor**\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/100713924/rustic-light-brown-unscented-pillar?click_key=1e1b539a31ff148e5e938e677f53ffa7%3ALT16fee6c4fcd237725f34374dbe786d7bcd466ffb&click_sum=f2fb5124&ls=r&ref=listing-free-shipping-bundle-1&pro=1&sts=1&content_source=1e1b539a31ff148e5e938e677f53ffa7%253ALT16fee6c4fcd237725f34374dbe786d7bcd466ffb "Rustic Light Brown Unscented Pillar Candle: Handmade Textured Farmhouse Decor")


Add to Favorites


[![Dark Brown Textured Pillar Candle: Handmade Rustic Farmhouse Decor](https://i.etsystatic.com/6635959/c/2122/2122/450/113/il/1324d6/7371184336/il_340x270.7371184336_8mw2.jpg)\\
\\
**Dark Brown Textured Pillar Candle: Handmade Rustic Farmhouse Decor**\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/582246002/dark-brown-textured-pillar-candle?click_key=1e1b539a31ff148e5e938e677f53ffa7%3ALT1666dac9001f03e2939aeaff99097034956e41c7&click_sum=0c18cb78&ls=r&ref=listing-free-shipping-bundle-2&pro=1&sts=1&content_source=1e1b539a31ff148e5e938e677f53ffa7%253ALT1666dac9001f03e2939aeaff99097034956e41c7 "Dark Brown Textured Pillar Candle: Handmade Rustic Farmhouse Decor")


Add to Favorites


![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_340x270.1223793356_hlg9.jpg)
This listing

### Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle

Sale Price $14.40
$14.40

$16.00
Original Price $16.00


(10% off)




Add to Favorites


[![Rustic Light Brown Unscented Pillar Candle: Handmade Textured Farmhouse Decor](https://i.etsystatic.com/6635959/c/1291/1025/0/189/il/2a1e8a/1270825149/il_340x270.1270825149_e0ux.jpg)\\
\\
**Rustic Light Brown Unscented Pillar Candle: Handmade Textured Farmhouse Decor**\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/100713924/rustic-light-brown-unscented-pillar?click_key=1e1b539a31ff148e5e938e677f53ffa7%3ALT16fee6c4fcd237725f34374dbe786d7bcd466ffb&click_sum=f2fb5124&ls=r&ref=listing-free-shipping-bundle-1&pro=1&sts=1&content_source=1e1b539a31ff148e5e938e677f53ffa7%253ALT16fee6c4fcd237725f34374dbe786d7bcd466ffb "Rustic Light Brown Unscented Pillar Candle: Handmade Textured Farmhouse Decor")


Add to Favorites


[![Dark Brown Textured Pillar Candle: Handmade Rustic Farmhouse Decor](https://i.etsystatic.com/6635959/c/2122/2122/450/113/il/1324d6/7371184336/il_340x270.7371184336_8mw2.jpg)\\
\\
**Dark Brown Textured Pillar Candle: Handmade Rustic Farmhouse Decor**\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/582246002/dark-brown-textured-pillar-candle?click_key=1e1b539a31ff148e5e938e677f53ffa7%3ALT1666dac9001f03e2939aeaff99097034956e41c7&click_sum=0c18cb78&ls=r&ref=listing-free-shipping-bundle-2&pro=1&sts=1&content_source=1e1b539a31ff148e5e938e677f53ffa7%253ALT1666dac9001f03e2939aeaff99097034956e41c7 "Dark Brown Textured Pillar Candle: Handmade Rustic Farmhouse Decor")


Add to Favorites


![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_340x270.1223793356_hlg9.jpg)
This listing

### Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle

Sale Price $14.40
$14.40

$16.00
Original Price $16.00


(10% off)




Add to Favorites


[![Rustic Light Brown Unscented Pillar Candle: Handmade Textured Farmhouse Decor](https://i.etsystatic.com/6635959/c/1291/1025/0/189/il/2a1e8a/1270825149/il_340x270.1270825149_e0ux.jpg)\\
\\
**Rustic Light Brown Unscented Pillar Candle: Handmade Textured Farmhouse Decor**\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/100713924/rustic-light-brown-unscented-pillar?click_key=1e1b539a31ff148e5e938e677f53ffa7%3ALT16fee6c4fcd237725f34374dbe786d7bcd466ffb&click_sum=f2fb5124&ls=r&ref=listing-free-shipping-bundle-1&pro=1&sts=1&content_source=1e1b539a31ff148e5e938e677f53ffa7%253ALT16fee6c4fcd237725f34374dbe786d7bcd466ffb "Rustic Light Brown Unscented Pillar Candle: Handmade Textured Farmhouse Decor")


Add to Favorites


[![Dark Brown Textured Pillar Candle: Handmade Rustic Farmhouse Decor](https://i.etsystatic.com/6635959/c/2122/2122/450/113/il/1324d6/7371184336/il_340x270.7371184336_8mw2.jpg)\\
\\
**Dark Brown Textured Pillar Candle: Handmade Rustic Farmhouse Decor**\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/582246002/dark-brown-textured-pillar-candle?click_key=1e1b539a31ff148e5e938e677f53ffa7%3ALT1666dac9001f03e2939aeaff99097034956e41c7&click_sum=0c18cb78&ls=r&ref=listing-free-shipping-bundle-2&pro=1&sts=1&content_source=1e1b539a31ff148e5e938e677f53ffa7%253ALT1666dac9001f03e2939aeaff99097034956e41c7 "Dark Brown Textured Pillar Candle: Handmade Rustic Farmhouse Decor")


Add to Favorites


## Item details

### Highlights

Made by [StillWaterCandles](https://www.etsy.com/shop/StillWaterCandles)

This decorative IVORY CREAM unscented rustic pillar candle is hand-poured at cool temperatures to create its textured surface.

\*STILL WATER CANDLES\*

Handmade in Missouri, USA. Crafted with clean burning paraffin wax, a natural cotton wick, and color dye, these unscented pillar candles are perfect for home decor and anyone with fragrance sensitivities.

\*SHIPPING\*

FREE SHIPPING on orders over $35 from Still Water Candles. All other orders ship for $5 flat rate.

Orders usually ship in 2-3 business days via USPS Ground and arrive 3-5 days after shipment. Large orders may ship via UPS.

\*SPECIFICS\*

• Unscented: Scent free

• Wax: Clean burning paraffin wax

• Wick: Natural cotton wick

• Tab: No wick tab on bottom

• Size: Choose from small to extra large pillar options

• Handcrafted: Handmade in small batches in Missouri

\*FIND YOUR PERFECT SIZE\*

We offer a variety of widths and heights to suit any space:

• 3 inch wide pillar candles (1 wick): 3x4, 3x6, 3x9

• 4 inch wide pillar candles (1 wick): 4x4, 4x6, 4x9

• 6 inch wide pillar candles (3 wicks): 6x4, 6x6, 6x9, 6x12, 6x15

• 7 inch wide pillar candles (3 wicks): 7x4, 7x6, 7x9, 7x12

\*CUSTOM SIZES\*

Looking for a specific size not shown above? Custom sizes may be available! Click "Message Janelle" and let me know what you're looking for.


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-20**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 14 days


- Ships from: **Cosby, MO**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## FAQs

Custom Orders


Please contact me with any questions for customization of my candles. I can usually change the size or color.


## Reviews for this item (170)

5.0/5

item average

5.0Item quality

4.8Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Beautiful

Fast shipping

Well packaged

Great quality

Love it

As described

Would recommend


Filter by category


Quality (51)


Appearance (45)


Shipping & Packaging (41)


Description accuracy (18)


Seller service (12)


Value (8)


Ease of use (3)


Condition (2)


Sizing & Fit (2)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Sandra](https://www.etsy.com/people/6gmio0wze132xgqo?ref=l_review)
Oct 3, 2025


Just as described. Looks great.



![Sandra added a photo of their purchase](https://i.etsystatic.com/iap/309767/7252809788/iap_300x300.7252809788_n8cmpw1l.jpg?version=0)

[Sandra](https://www.etsy.com/people/6gmio0wze132xgqo?ref=l_review)
Oct 3, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/5da20e/98844610/iusa_75x75.98844610_apri.jpg?version=0)

[hokiekate](https://www.etsy.com/people/hokiekate?ref=l_review)
Sep 23, 2025


Always beautiful candles. Cannot go wrong with these.



![](https://i.etsystatic.com/iusa/5da20e/98844610/iusa_75x75.98844610_apri.jpg?version=0)

[hokiekate](https://www.etsy.com/people/hokiekate?ref=l_review)
Sep 23, 2025


5 out of 5 stars
5

This item

[Carolyn Bakken](https://www.etsy.com/people/cjbbab?ref=l_review)
Aug 2, 2025


Candle was just what I was looking for!



[Carolyn Bakken](https://www.etsy.com/people/cjbbab?ref=l_review)
Aug 2, 2025


5 out of 5 stars
5

This item

[jlonis75](https://www.etsy.com/people/jlonis75?ref=l_review)
Jul 30, 2025


Thank you for excellent quality and customer service



[jlonis75](https://www.etsy.com/people/jlonis75?ref=l_review)
Jul 30, 2025


View all reviews for this item

### Photos from reviews

![Sandra added a photo of their purchase](https://i.etsystatic.com/iap/309767/7252809788/iap_300x300.7252809788_n8cmpw1l.jpg?version=0)

![Renee added a photo of their purchase](https://i.etsystatic.com/iap/a0030e/6245479440/iap_300x300.6245479440_foevz6na.jpg?version=0)

![Sylvia added a photo of their purchase](https://i.etsystatic.com/iap/46cec7/6218727477/iap_300x300.6218727477_962q2eam.jpg?version=0)

![Debbie added a photo of their purchase](https://i.etsystatic.com/iap/a2715a/6748699833/iap_300x300.6748699833_dh12sb5g.jpg?version=0)

![Jaime added a photo of their purchase](https://i.etsystatic.com/iap/2d254a/6175804476/iap_300x300.6175804476_h8zfgzg8.jpg?version=0)

![Patricia added a photo of their purchase](https://i.etsystatic.com/iap/79c42e/5697680925/iap_300x300.5697680925_8yskgb3c.jpg?version=0)

![tracy added a photo of their purchase](https://i.etsystatic.com/iap/bb78d2/5504862617/iap_300x300.5504862617_my792750.jpg?version=0)

![gilahatches added a photo of their purchase](https://i.etsystatic.com/iap/abb69f/4689995674/iap_300x300.4689995674_ihlmwsl2.jpg?version=0)

![Janet added a photo of their purchase](https://i.etsystatic.com/iap/6a976e/4405814874/iap_300x300.4405814874_s6ro00w5.jpg?version=0)

![Patricia added a photo of their purchase](https://i.etsystatic.com/iap/1583eb/4547012899/iap_300x300.4547012899_69k3at4w.jpg?version=0)

![Jeffrey added a photo of their purchase](https://i.etsystatic.com/iap/d800a7/4344603316/iap_300x300.4344603316_oo98jnst.jpg?version=0)

![Linda added a photo of their purchase](https://i.etsystatic.com/iap/03bb4c/4413975051/iap_300x300.4413975051_k57eb9wu.jpg?version=0)

![angela added a photo of their purchase](https://i.etsystatic.com/iap/e4a07f/4280384636/iap_300x300.4280384636_gxhhdc2b.jpg?version=0)

![V. added a photo of their purchase](https://i.etsystatic.com/iap/60ab47/4121786195/iap_300x300.4121786195_d142iuib.jpg?version=0)

![J. added a photo of their purchase](https://i.etsystatic.com/iap/b5714e/3919854417/iap_300x300.3919854417_xk3h14vq.jpg?version=0)

![Tiffany added a photo of their purchase](https://i.etsystatic.com/iap/e1c0b6/3293889188/iap_300x300.3293889188_svb8ujyd.jpg?version=0)

![Cindi added a photo of their purchase](https://i.etsystatic.com/iap/55e4ef/3180203812/iap_300x300.3180203812_2g0ph0hy.jpg?version=0)

![nancysmariposa added a photo of their purchase](https://i.etsystatic.com/iap/bef8ed/3043870749/iap_300x300.3043870749_ekoa55xu.jpg?version=0)

[![StillWaterCandles](https://i.etsystatic.com/iusa/dd4117/49586180/iusa_75x75.49586180_jpd8.jpg?version=0)](https://www.etsy.com/shop/StillWaterCandles?ref=shop_profile&listing_id=870723101)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[StillWaterCandles](https://www.etsy.com/shop/StillWaterCandles?ref=shop_profile&listing_id=870723101)

[Owned by Janelle](https://www.etsy.com/shop/StillWaterCandles?ref=shop_profile&listing_id=870723101) \|

Missouri, United States

4.9
(4.7k)


24.4k sales

13 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=17976084&referring_id=870723101&referring_type=listing&recipient_id=17976084&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoxNzk3NjA4NDoxNzYyNzg4MzI2OjM5YjMzMzBiMTg2MDRkOTU1ZmRmNWZmNDA0ZDgyN2Fh&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F870723101%2Frustic-ivory-pillar-candle-handmade%3Futm_source%3Dopenai)

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/StillWaterCandles?ref=lp_mys_mfts)

- [![Rustic Light Brown Unscented Pillar Candle: Handmade Textured Farmhouse Decor](https://i.etsystatic.com/6635959/c/1291/1025/0/189/il/2a1e8a/1270825149/il_340x270.1270825149_e0ux.jpg)\\
\\
**Rustic Light Brown Unscented Pillar Candle: Handmade Textured Farmhouse Decor**\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/100713924/rustic-light-brown-unscented-pillar?click_key=b692815abe0d019c5f3491a94867422e%3ALT47b0988b4d339085287c156a9883d0aa0774fc95&click_sum=5848da0a&ls=r&ref=related-1&pro=1&sts=1&content_source=b692815abe0d019c5f3491a94867422e%253ALT47b0988b4d339085287c156a9883d0aa0774fc95 "Rustic Light Brown Unscented Pillar Candle: Handmade Textured Farmhouse Decor")




Add to Favorites


- [![Dark Brown Textured Pillar Candle: Handmade Rustic Farmhouse Decor](https://i.etsystatic.com/6635959/c/2122/2122/450/113/il/1324d6/7371184336/il_340x270.7371184336_8mw2.jpg)\\
\\
**Dark Brown Textured Pillar Candle: Handmade Rustic Farmhouse Decor**\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/582246002/dark-brown-textured-pillar-candle?click_key=b692815abe0d019c5f3491a94867422e%3ALT50e3eb1432dc75c9de14a235767ed859486027f5&click_sum=144000f9&ls=r&ref=related-2&pro=1&sts=1&content_source=b692815abe0d019c5f3491a94867422e%253ALT50e3eb1432dc75c9de14a235767ed859486027f5 "Dark Brown Textured Pillar Candle: Handmade Rustic Farmhouse Decor")




Add to Favorites


- [![Handmade Dark Terracotta Unscented Rustic Pillar Candle: Reddish-Brown Farmhouse Decor](https://i.etsystatic.com/6635959/r/il/8e4498/6820711072/il_340x270.6820711072_mydi.jpg)\\
\\
**Handmade Dark Terracotta Unscented Rustic Pillar Candle: Reddish-Brown Farmhouse Decor**\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4297195196/handmade-dark-terracotta-unscented?click_key=b692815abe0d019c5f3491a94867422e%3ALT3447382d34499ca83af81618802d6df2b0cb1334&click_sum=b5d22872&ls=r&ref=related-3&pro=1&sts=1&content_source=b692815abe0d019c5f3491a94867422e%253ALT3447382d34499ca83af81618802d6df2b0cb1334 "Handmade Dark Terracotta Unscented Rustic Pillar Candle: Reddish-Brown Farmhouse Decor")




Add to Favorites


- [![Pear Green Unscented Pillar Candle: Rustic Textured Handmade Decor](https://i.etsystatic.com/6635959/c/1902/1511/71/368/il/5d7e6f/6243532739/il_340x270.6243532739_k7q7.jpg)\\
\\
**Pear Green Unscented Pillar Candle: Rustic Textured Handmade Decor**\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/98864574/pear-green-unscented-pillar-candle?click_key=2a4b228849d57bfbdd81e30618399f2009ea244a%3A98864574&click_sum=d575c0da&ref=related-4&pro=1&sts=1 "Pear Green Unscented Pillar Candle: Rustic Textured Handmade Decor")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading wedding form

Loading


## Top wedding searches to shop

[![](https://i.etsystatic.com/19757930/c/1333/1333/0/301/il/cfe72f/3482678762/il_300x300.3482678762_pxw3.jpg)\\
Bridesmaid gifts](https://www.etsy.com/search?q=bridesmaid+gifts&mosv=sese&moci=635510339037&mosi=618520640322&featured_listing=1110003408&ref=wedding_recs_lp_bridesmaid_gifts)

[![](https://i.etsystatic.com/19483987/r/il/42cd8d/2512481731/il_300x300.2512481731_8gz7.jpg)\\
Groomsmen gifts](https://www.etsy.com/search?q=groomsmen+gifts&mosv=sese&moci=635510339037&mosi=635510910189&featured_listing=761677858&ref=wedding_recs_lp_groomsmen_gifts)

[![](https://i.etsystatic.com/6748817/c/2000/2000/0/828/il/b140dc/3394740672/il_300x300.3394740672_mong.jpg)\\
Wedding gifts](https://www.etsy.com/search?q=wedding+gifts&mosv=sese&moci=635510339037&mosi=618520762754&featured_listing=1087712798&ref=wedding_recs_lp_wedding_gifts)

[![](https://i.etsystatic.com/5354512/r/il/35af5c/5783958379/il_300x300.5783958379_pio7.jpg)\\
Engagement gifts](https://www.etsy.com/search?q=engagement+gifts&mosv=sese&moci=635510339037&mosi=635511121285&featured_listing=190344599&ref=wedding_recs_lp_engagement_gifts)

Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 9, 2025


[349 favorites](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Pillar Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/pillar-candles?utm_source=openai&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Womens Clothing

[Vintage 80's Ladies Pykettes V-Neck Sweater - Women's Clothing](https://www.etsy.com/listing/747514020/vintage-80s-ladies-pykettes-v-neck)

Home Decor

[Bedroom wall decor - Home Decor](https://www.etsy.com/listing/1865368739/orca-killer-whale-dream-catcher-wall) [French Cafe Wall Art Paris Artwork Paris Nursery Art Paris Nursery Print Paris Print Nursery Paris Theme Decor Paris Inspired Decor Paris by AmorandDecor](https://www.etsy.com/listing/1802687166/french-cafe-wall-art-paris-artwork-paris) [Farmhouse Number Plaque - US](https://www.etsy.com/market/farmhouse_number_plaque) [Buy Koi Fish With Lotus Online](https://www.etsy.com/market/koi_fish_with_lotus) [Antique Tile Mission - US](https://www.etsy.com/market/antique_tile_mission) [Buy Oar Blade Online](https://www.etsy.com/market/oar_blade) [Noble Houses Sigil for Sale](https://www.etsy.com/market/noble_houses_sigil) [Shop Wedding Initial Sign](https://www.etsy.com/market/wedding_initial_sign) [Kurt Geiger Wallpaper - US](https://www.etsy.com/market/kurt_geiger_wallpaper) [Early 20th Century ( Possibly Older) Antique Bronze Statute of Egyptian Pharaoh Ramesses II - Home Decor](https://www.etsy.com/listing/1200581921/late-19th-century-early-20th-century)

Paper

[Groundhog Day Printable Stickers for ERIN CONDREN Life Planner Weekly Kit 7X9 Groundhog Day EC February Weekly Kit by LilliansHandmade](https://www.etsy.com/listing/1861431603/groundhog-day-printable-stickers-for)

Findings

[Bail with Cup & Peg Pearl Mounting in Sterling Silver 12.1x5mm by SilviaFindings](https://www.etsy.com/listing/1050238164/bail-with-cup-peg-pearl-mounting-in)

Canvas & Surfaces

[Buy Dance Wine Quote Online](https://www.etsy.com/market/dance_wine_quote)

Home & Living

[Difference Maker Definition - Home & Living](https://www.etsy.com/listing/1735906527/personalized-different-maker-plaque)

Computers & Peripherals

[Buy Wholesale Mouse Pads Online](https://www.etsy.com/market/wholesale_mouse_pads)

Fabric & Notions

[Nfl Spandex Fabric - US](https://www.etsy.com/market/nfl_spandex_fabric)

Bedding

[Lavender milestone blanket - Bedding](https://www.etsy.com/listing/1561643937/lavender-milestone-blanket-personalized)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F870723101%2Frustic-ivory-pillar-candle-handmade%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc4ODMyNjowMTE3MDcxNTIwNTY5NGI1NTdmMzkzZmZkOWVhNWQwNw==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F870723101%2Frustic-ivory-pillar-candle-handmade%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F870723101%2Frustic-ivory-pillar-candle-handmade%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for StillWaterCandles

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 24 hours of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## Seller details

### Other details

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=17976084&referring_id=6635959&referring_type=shop&recipient_id=17976084&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: A cylindrical, light beige candle with a slightly textured surface sits in front of a blurred green background. The candle is unlit, showing a short, off-white wick.  The color is a pale, creamy beige with subtle variations in tone. The candle appears to be made of a wax-like material, giving it a slightly rough texture. The overall impression is one of serenity and relaxation, suitable for spa or home decor.](https://i.etsystatic.com/6635959/c/1446/1446/0/4/il/a8fb5f/1223793356/il_300x300.1223793356_hlg9.jpg)
- ![May include: A cylindrical, light beige candle with a slightly textured surface sits on a dark surface. The candle has a single visible wick in the center.  The color is a pale, creamy yellow-beige. The candle is solid and unlit. It appears to be made of wax. The overall style is simple and elegant, suitable for home décor or gifting.](https://i.etsystatic.com/6635959/r/il/52cba5/1271012665/il_300x300.1271012665_2jw0.jpg)
- ![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle image 3](https://i.etsystatic.com/6635959/r/il/3bac38/7321958854/il_300x300.7321958854_npvg.jpg)
- ![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle image 4](https://i.etsystatic.com/6635959/r/il/df3e09/7369906831/il_300x300.7369906831_td1m.jpg)

- ![](https://i.etsystatic.com/iap/309767/7252809788/iap_640x640.7252809788_n8cmpw1l.jpg?version=0)

5 out of 5 stars

- SIZE:

3.5" WIDE x 4" tall


Just as described. Looks great.

Oct 3, 2025


[Sandra](https://www.etsy.com/people/6gmio0wze132xgqo)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/a0030e/6245479440/iap_640x640.6245479440_foevz6na.jpg?version=0)

5 out of 5 stars

- Width:

3 Inches

- Height:

6 Inches


Beautiful candle! A little high priced, but it has a really nice texture.

![](https://i.etsystatic.com/iusa/523688/34119328/iusa_75x75.34119328_2ag2.jpg?version=0)

Sep 3, 2024


[Renee Lazzareschi](https://www.etsy.com/people/lovelyprincessrenee)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/46cec7/6218727477/iap_640x640.6218727477_962q2eam.jpg?version=0)

5 out of 5 stars

- Width:

3 Inches

- Height:

4 Inches


Love Love my candles seller did an amazing job. Highly recommend this shop. Very happy with my purchase.

Aug 3, 2024


[Sylvia Wilson](https://www.etsy.com/people/sylviawilson1058)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/a2715a/6748699833/iap_640x640.6748699833_dh12sb5g.jpg?version=0)

5 out of 5 stars

- Width:

4 Inches

- Height:

9 Inches


Beautiful candles and fast shipping. Seller’s communication was excellent. Will definitely shop with this seller again.

Mar 8, 2025


[Debbie](https://www.etsy.com/people/z5c4i5zi)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/2d254a/6175804476/iap_640x640.6175804476_h8zfgzg8.jpg?version=0)

5 out of 5 stars

- Width:

3 Inches

- Height:

4 Inches


These are the exact candles I was looking for! I need Pilar candles that didn’t have that metal disc on the bottom, preventing them from working with holders that have a central mounting spike. The seller answered my question about this quickly and clearly and the candles arrived in a timely manner. They’re beautiful in quality, color (a nice soft ivory), and texture. I’ll definitely buy again. Thank you!! 🕯️🕯️🕯️

![](https://i.etsystatic.com/iusa/b310d6/71073114/iusa_75x75.71073114_4b29.jpg?version=0)

Aug 5, 2024


[Jaime](https://www.etsy.com/people/sfujwiop)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/79c42e/5697680925/iap_640x640.5697680925_8yskgb3c.jpg?version=0)

5 out of 5 stars

- Width:

3 Inches

- Height:

6 Inches


Very well packaged. No wax dents.
The color is more white than ivory, but it will work out. Thank you.

Jan 6, 2024


[Patricia](https://www.etsy.com/people/patty15)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/bb78d2/5504862617/iap_640x640.5504862617_my792750.jpg?version=0)

4 out of 5 stars

- Width:

3 Inches

- Height:

9 Inches


Outstanding candles & customer service! I wanted to make a centerpiece with her candles and an oversized bread bowl. Help, I bought 10 candles:
Four candles 3 wide x 4 tall
One candle 3 wide x 9 tall
One candle 4 wide x 4 tall
One candle 4 wide x 6 tall
One candle 4 wide x 9 tall
One candle 6 wide x 4 tall
One candle 6 wide x 6 tall

![](https://i.etsystatic.com/iusa/006f81/79533839/iusa_75x75.79533839_hfow.jpg?version=0)

Oct 31, 2023


[tracy ogw](https://www.etsy.com/people/tracyogw)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/abb69f/4689995674/iap_640x640.4689995674_ihlmwsl2.jpg?version=0)

5 out of 5 stars

- Width:

3 Inches

- Height:

9 Inches


I’ve order three batches of candles and they are all gorgeous. Seller also helped me get the color I was looking for!

Mar 4, 2023


[gilahatches](https://www.etsy.com/people/gilahatches)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/6a976e/4405814874/iap_640x640.4405814874_s6ro00w5.jpg?version=0)

5 out of 5 stars

- Width:

3 Inches

- Height:

6 Inches


These are the only candles I will buy now! Beautiful when they're new and beautiful as they burn down. Totally worth the price. Please don't ever go away.

Dec 3, 2022


[Janet](https://www.etsy.com/people/c1un4boj)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/1583eb/4547012899/iap_640x640.4547012899_69k3at4w.jpg?version=0)

5 out of 5 stars

- Width:

4 Inches

- Height:

4 Inches


Jan 7, 2023


[Patricia Muoio](https://www.etsy.com/people/trishnmuoio)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/d800a7/4344603316/iap_640x640.4344603316_oo98jnst.jpg?version=0)

5 out of 5 stars

- Width:

4 Inches

- Height:

6 Inches


I wanted a candle that would fit a candle holder that I turned. This one from StillWater Candles is exactly what I wanted. It is well made and looks fantastic. Fast shipping, too!

Nov 13, 2022


[Jeffrey](https://www.etsy.com/people/nmxqwlba)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/03bb4c/4413975051/iap_640x640.4413975051_k57eb9wu.jpg?version=0)

5 out of 5 stars

- Width:

4 Inches

- Height:

9 Inches


/Users/lindaknechtel/Desktop/IMG\_0182.jpeg/Users/lindaknechtel/Desktop/IMG\_0190.jpeg

I believe I submitted review!
I believe I submitted review, but will do so, again. The candles are lovely! They were well packed, and shipped quickly.

![](https://i.etsystatic.com/iusa/167e41/50998239/iusa_75x75.50998239_t9n9.jpg?version=0)

Nov 20, 2022


[Linda Knechtel](https://www.etsy.com/people/lindaknechtel)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/e4a07f/4280384636/iap_640x640.4280384636_gxhhdc2b.jpg?version=0)

5 out of 5 stars

- Width:

6 Inches

- Height:

4 Inches


Well made candle that burns evenly. I will order again!

Oct 23, 2022


[angela arnold](https://www.etsy.com/people/jainlv)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/60ab47/4121786195/iap_640x640.4121786195_d142iuib.jpg?version=0)

5 out of 5 stars

- Width:

6 Inches

- Height:

6 Inches


This is my second order and your candles are perfect!

Aug 11, 2022


[V. Klipstein](https://www.etsy.com/people/dakota0319)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/b5714e/3919854417/iap_640x640.3919854417_xk3h14vq.jpg?version=0)

5 out of 5 stars

- Width:

3 Inches

- Height:

6 Inches


Great candles and great burn time. Peel back is really nice as well. Good burn time.

![](https://i.etsystatic.com/iusa/46c5b5/114585320/iusa_75x75.114585320_mm97.jpg?version=0)

May 13, 2022


[J. H. L.](https://www.etsy.com/people/swine24)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/e1c0b6/3293889188/iap_640x640.3293889188_svb8ujyd.jpg?version=0)

5 out of 5 stars

- Width:

6 Inches

- Height:

6 Inches


Just beautiful!

![](https://i.etsystatic.com/iusa/b55a98/53329921/iusa_75x75.53329921_m6ot.jpg?version=0)

Aug 28, 2021


[Tiffany Davis](https://www.etsy.com/people/tiffanydavis128)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/55e4ef/3180203812/iap_640x640.3180203812_2g0ph0hy.jpg?version=0)

5 out of 5 stars

- Width:

3 Inches

- Height:

6 Inches


Love them - got the cream and the rustic which is really fall-ish but still beautiful on this dreary day thank you!!! Will be back!

See in original language


Translated by [Microsoft](http://aka.ms/MicrosoftTranslatorAttribution)

Love them - got the cream and the rustic which is really fall-ish but still beautiful on this dreary day thank you!!! Will be back!


Jul 1, 2021


[Cindi Wallace](https://www.etsy.com/people/gcwallace)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/bef8ed/3043870749/iap_640x640.3043870749_ekoa55xu.jpg?version=0)

5 out of 5 stars

- Width:

3 Inches

- Height:

4 Inches


Apr 6, 2021


[nancysmariposa](https://www.etsy.com/people/nancysmariposa)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)

Purchased item:

[![Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle](https://i.etsystatic.com/6635959/c/1446/1148/0/224/il/a8fb5f/1223793356/il_170x135.1223793356_hlg9.jpg)\\
\\
Rustic Ivory Pillar Candle: Handmade Unscented Decorative Candle\\
\\
Sale Price $14.40\\
$14.40\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(10% off)](https://www.etsy.com/listing/870723101/rustic-ivory-pillar-candle-handmade?ref=ap-listing)