[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/4305867607/handmade-soy-wax-pillar-candle-with?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?utm_source=openai&explicit=1&ref=catnav_breadcrumb-3)
- [Pillar Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/pillar-candles?utm_source=openai&explicit=1&ref=catnav_breadcrumb-4)


Add to Favorites


- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/b8f476/6864336160/il_794xN.6864336160_3s5n.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/73f3bc/6864336390/il_794xN.6864336390_dt9l.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/e73834/6864336794/il_794xN.6864336794_aakm.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/07f82a/6912315339/il_794xN.6912315339_aabv.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/a63634/6912316471/il_794xN.6912316471_je6a.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/8c13e3/6864338266/il_794xN.6864338266_pw0n.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/68e7d8/6864338204/il_794xN.6864338204_jfbc.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/06ddd9/6864335950/il_794xN.6864335950_gbhz.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/21931c/6912318217/il_794xN.6912318217_e8kr.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/c32d31/6912318035/il_794xN.6912318035_c54w.jpg)

- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/b8f476/6864336160/il_75x75.6864336160_3s5n.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/1000093303_xwywil.jpg)

- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/73f3bc/6864336390/il_75x75.6864336390_dt9l.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/e73834/6864336794/il_75x75.6864336794_aakm.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/07f82a/6912315339/il_75x75.6912315339_aabv.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/a63634/6912316471/il_75x75.6912316471_je6a.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/8c13e3/6864338266/il_75x75.6864338266_pw0n.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/68e7d8/6864338204/il_75x75.6864338204_jfbc.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/06ddd9/6864335950/il_75x75.6864335950_gbhz.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/21931c/6912318217/il_75x75.6912318217_e8kr.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/c32d31/6912318035/il_75x75.6912318035_c54w.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F4305867607%2Fhandmade-soy-wax-pillar-candle-with%23report-overlay-trigger)

Price:$19.90+


Loading


# Handmade Soy Wax Pillar Candle with Cement Base: Minimalist Decor

Made by [AttaliaStudio](https://www.etsy.com/shop/AttaliaStudio)

[5 out of 5 stars](https://www.etsy.com/listing/4305867607/handmade-soy-wax-pillar-candle-with?utm_source=openai#reviews)

Returns accepted

Sizes


Select an option

10 Cm ($19.90)

15 Cm ($24.90)

20 Cm ($29.90)

All 3 Bundle ($59.90)

Please select an option


Add personalization


- Personalization





Please enter your desired color and scent in the personalization box. Need a custom combination? Message us — we're happy to create something just for you!


















0/1000


Quantity



1234567891011121314151617181920

4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Made by [AttaliaStudio](https://www.etsy.com/shop/AttaliaStudio)

- Materials: Wax type: Soy


- Sustainable features: vegan. Items may include additional materials or use methods that aren't considered sustainable features on our site. [Learn more](https://help.etsy.com/hc/articles/15532793357847)

- Width: 7 centimeters

Height: 10 centimeters

- Gift wrapping available


Simplicity meets structure.

Our handmade soy wax pillar candles feature a modern cement base, offering a clean, architectural look for lovers of minimalist, Japandi, and neutral home aesthetics. Whether styled solo or as a curated set, these candles bring sculptural elegance to your living space.

Crafted with 100% natural soy wax and left unscented for clean, smoke-free burning — they’re perfect for calm interiors, shelf styling, or gifting.

🪵 Why You’ll Love Them:

• Minimalist pillar design with solid cement base

• 100% soy wax – vegan, non-toxic, eco-conscious

• Unscented – safe for sensitive environments

• Beautiful as decor even when unlit

• Handmade in small batches with attention to detail

• Available individually or as a bundle

📏 Available Sizes (all 7 cm diameter):

• Small: 10 cm height

• Medium: 15 cm height

• Large: 20 cm height

• Full Set: Includes all 3 sizes for a balanced display

🕯️ Burn Time:

• Small: ~25 hours

• Medium: ~35 hours

• Large: ~45+ hours

🎁 Perfect For:

• Japandi, rustic, and modern home decor

• Shelf styling, coffee tables, console trays

• Minimalist weddings, housewarming gifts

• Visual layering in interior design setups

• Everyday ambiance and decor that lasts

📦 Shipping & Customs Info

• Fast worldwide shipping via UPS / FedEx

• 🇺🇸 USA: 2–3 business days

• 🇪🇺 Europe: 1–3 business days

• 🇨🇦 Canada: 2–4 business days

✅ We pay all customs duties, VAT, and import fees. You won't be charged anything extra upon delivery.

📌 Important Shipping Note:

To ensure smooth and timely delivery, please include your phone number at checkout or in the personalization box. Couriers require this for international shipments.


## Shipping and return policies

Loading


- Order today to get by

**Nov 13-Dec 1**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 14 days


- Ships from: **Türkiye**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## FAQs

Do you accept custom color or scent requests?


Yes, we accept custom orders! You can request personalized candle colors or choose your favorite scent from our fragrance options. Whether it’s a custom bridesmaid gift or a specific home décor theme, we’re happy to tailor your handmade soy candle to your needs. Just message us before ordering!


How long is shipping time?


Our handmade candles ship within 2–3 business days.

📍 Domestic (Türkiye): 2–5 business days

🌍 International: 5-7 days depending on your location

Each candle is carefully packaged and shipped with tracking for peace of mind.


Can I send this as a gift with a note?


Yes! We offer gift packaging and can include a handwritten note with your order. Perfect for birthdays, weddings, anniversaries, or Mother’s Day. Just leave your message at checkout!


Are your candles vegan and eco-friendly?


Yes! All our soy candles are vegan, cruelty-free, and made with natural soy wax and premium fragrance oils. We avoid toxins and paraffin for a clean, long-lasting burn.


## Meet your seller

![çağrı](https://i.etsystatic.com/56489387/r/isla/f8851e/75054511/isla_75x75.75054511_7p8g7y5l.jpg)

çağrı

Owner of [AttaliaStudio](https://www.etsy.com/shop/AttaliaStudio?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoxMDIyNjg4NDQyOjE3NjI3ODc3Mjk6Yzc4NjkzYzE0ZmRjZTZkODg2YjViYjg1MjMwYjEwMTE%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F4305867607%2Fhandmade-soy-wax-pillar-candle-with%3Futm_source%3Dopenai)

[Message çağrı](https://www.etsy.com/messages/new?with_id=1022688442&referring_id=4305867607&referring_type=listing&recipient_id=1022688442&from_action=contact-seller)

This seller usually responds **within a few hours.**

## Be the first to review this item

Help this shop grow by ordering this personalizable item and sharing your feedback. See what customers say about other items from this shop.


Read reviews for other items


[![AttaliaStudio](https://i.etsystatic.com/iusa/652d8e/112125766/iusa_75x75.112125766_cuvl.jpg?version=0)](https://www.etsy.com/shop/AttaliaStudio?ref=shop_profile&listing_id=4305867607)

[AttaliaStudio](https://www.etsy.com/shop/AttaliaStudio?ref=shop_profile&listing_id=4305867607)

[Owned by çağrı](https://www.etsy.com/shop/AttaliaStudio?ref=shop_profile&listing_id=4305867607) \|

Antalya, Türkiye

5.0
(2)


7 sales

10 months on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=1022688442&referring_id=4305867607&referring_type=listing&recipient_id=1022688442&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoxMDIyNjg4NDQyOjE3NjI3ODc3Mjk6Yzc4NjkzYzE0ZmRjZTZkODg2YjViYjg1MjMwYjEwMTE%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F4305867607%2Fhandmade-soy-wax-pillar-candle-with%3Futm_source%3Dopenai)

This seller usually responds **within a few hours.**

## All reviews from this shop (2)

Show all

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Why are these reviews shown?

All reviews are from verified buyers. Reviews are shown automatically based on factors like recency, whether they include comments, your chosen language, and whether the rating reflects the typical experience with the shop.

## More from this shop

[Visit shop](https://www.etsy.com/shop/AttaliaStudio?ref=lp_mys_mfts)

- [![Ribbed Soy Pillar Candle – Minimalist Home Décor, Vegan & Eco-Friendly Handmade](https://i.etsystatic.com/56489387/r/il/651334/6769456542/il_340x270.6769456542_9bqp.jpg)\\
\\
**Ribbed Soy Pillar Candle – Minimalist Home Décor, Vegan & Eco-Friendly Handmade**\\
\\
$12.90\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4366452739/ribbed-soy-pillar-candle-minimalist-home?click_key=d8f44e5410edd928581f8308c981ed05%3ALTf410b1f3d8bca1e4d34d7695a0fb93385fcd7f02&click_sum=06e08dff&ls=r&ref=related-1&content_source=d8f44e5410edd928581f8308c981ed05%253ALTf410b1f3d8bca1e4d34d7695a0fb93385fcd7f02 "Ribbed Soy Pillar Candle – Minimalist Home Décor, Vegan & Eco-Friendly Handmade")




Add to Favorites


- [![Pillar Candle – Soy Wax Hand-Carved Gift, Wedding Favor, Boho Home Decor](https://i.etsystatic.com/56489387/r/il/023711/6755793290/il_340x270.6755793290_3sph.jpg)\\
\\
**Pillar Candle – Soy Wax Hand-Carved Gift, Wedding Favor, Boho Home Decor**\\
\\
$19.90\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1895946795/pillar-candle-soy-wax-hand-carved-gift?click_key=d8f44e5410edd928581f8308c981ed05%3ALT1aa2117258e75e6b337227a418d2feddeaa8c1b3&click_sum=1ed51c17&ls=r&ref=related-2&content_source=d8f44e5410edd928581f8308c981ed05%253ALT1aa2117258e75e6b337227a418d2feddeaa8c1b3 "Pillar Candle – Soy Wax Hand-Carved Gift, Wedding Favor, Boho Home Decor")




Add to Favorites


- [![Mini Beeswax Candle Wedding Favor: Personalized Jar with Thank You Tag](https://i.etsystatic.com/56489387/r/il/91da3f/6951209572/il_340x270.6951209572_i5wl.jpg)\\
\\
**Mini Beeswax Candle Wedding Favor: Personalized Jar with Thank You Tag**\\
\\
$9.90\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4322620816/mini-beeswax-candle-wedding-favor?click_key=d8f44e5410edd928581f8308c981ed05%3ALTa998c747dbd970a93119eaadddd1552445830d5b&click_sum=bf88b93a&ls=r&ref=related-3&content_source=d8f44e5410edd928581f8308c981ed05%253ALTa998c747dbd970a93119eaadddd1552445830d5b "Mini Beeswax Candle Wedding Favor: Personalized Jar with Thank You Tag")




Add to Favorites


- [![Baptism Favors Candle Set: Handmade Soy Wax Angel Statue](https://i.etsystatic.com/56489387/r/il/a53d2d/6700142126/il_340x270.6700142126_hpld.jpg)\\
\\
**Baptism Favors Candle Set: Handmade Soy Wax Angel Statue**\\
\\
$44.90\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1885188489/baptism-favors-candle-set-handmade-soy?click_key=fb2d13f2237305fa6da3a531ef4406347c319664%3A1885188489&click_sum=9f1a1d74&ref=related-4 "Baptism Favors Candle Set: Handmade Soy Wax Angel Statue")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Sep 16, 2025


[4 favorites](https://www.etsy.com/listing/4305867607/handmade-soy-wax-pillar-candle-with/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Pillar Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/pillar-candles?utm_source=openai&explicit=1&ref=breadcrumb_listing)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F4305867607%2Fhandmade-soy-wax-pillar-candle-with%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc4NzcyOTo0NmU5YTgxOThjYmZhNmI5YmU4YTNiMDE4OWY5OWUyNw==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F4305867607%2Fhandmade-soy-wax-pillar-candle-with%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/4305867607/handmade-soy-wax-pillar-candle-with?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F4305867607%2Fhandmade-soy-wax-pillar-candle-with%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

On


Saved

Done

## Shop policies for AttaliaStudio

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 2 hours of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


Customs and import taxes

Buyers are responsible for any customs and import taxes that may apply. I'm not responsible for delays due to customs.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/b8f476/6864336160/il_300x300.6864336160_3s5n.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/1000093303_xwywil.jpg)

- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/73f3bc/6864336390/il_300x300.6864336390_dt9l.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/e73834/6864336794/il_300x300.6864336794_aakm.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/07f82a/6912315339/il_300x300.6912315339_aabv.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/a63634/6912316471/il_300x300.6912316471_je6a.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/8c13e3/6864338266/il_300x300.6864338266_pw0n.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/68e7d8/6864338204/il_300x300.6864338204_jfbc.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/06ddd9/6864335950/il_300x300.6864335950_gbhz.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/21931c/6912318217/il_300x300.6912318217_e8kr.jpg)
- ![Handmade Soy Wax Pillar Candle with Cement Base – 10cm, 15cm, 20cm or Full Set | Minimalist Home Decor | Japandi Candle Gift](https://i.etsystatic.com/56489387/r/il/c32d31/6912318035/il_300x300.6912318035_c54w.jpg)

Scroll previousScroll next