[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/833151267/handmade-pillar-candle-pillar-candles?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?utm_source=openai&explicit=1&ref=catnav_breadcrumb-3)


Add to Favorites


- ![May include: Three white pillar candles with gray and brown marbled designs. The candles are arranged on a white marble surface with a wooden background. The candles are handmade and have a rustic look. The text 'Ligare Design Handmade' is visible at the bottom of the image.](https://i.etsystatic.com/14669466/r/il/e57f19/2335341041/il_794xN.2335341041_j9hs.jpg)
- ![May include: Five concrete candles with a white and gray marbled design. The candles are arranged on a white marble surface. The candles are handmade and have a logo that reads 'Ligare Design Handmade'.](https://i.etsystatic.com/14669466/r/il/d31fdd/2287729516/il_794xN.2287729516_s9do.jpg)
- ![May include: Four concrete candles with a white wax finish and gold flecks. The candles are different sizes and are arranged in a row on a gray surface.](https://i.etsystatic.com/14669466/r/il/15f218/2581079629/il_794xN.2581079629_noj2.jpg)
- ![May include: Two white pillar candles with a light gray and gold design. The candles are handmade and have the words 'Ligare Design' and 'Handmade' on the bottom of the candle.](https://i.etsystatic.com/14669466/r/il/a0f40e/2287729520/il_794xN.2287729520_q9fg.jpg)
- ![May include: Two concrete candle holders with a marbled design and a white concrete candle. The candle holders are labeled 'Tealight Candle Holders' and the candle is labeled 'Concrete Candle'. The text 'Ligare Design Handmade' is also visible in the image.](https://i.etsystatic.com/14669466/r/il/a9b037/2335340449/il_794xN.2335340449_3qau.jpg)
- ![May include: Two white pillar candles with a textured, gray and gold finish. The candles are on a gray surface.](https://i.etsystatic.com/14669466/r/il/31b566/2533431824/il_794xN.2533431824_3tx2.jpg)
- ![May include: Two white pillar candles with a grey and gold marbled design. The candles have a white top layer and a grey and gold marbled bottom layer. The candles are handmade and have the text 'Ligare Design Handmade' on the bottom of the candle.](https://i.etsystatic.com/14669466/r/il/9163e8/3509717489/il_794xN.3509717489_ttto.jpg)
- ![May include: Five concrete candles with a marbleized and speckled design. The candles are arranged on a white marble surface. The candles are all different sizes and shapes. The text 'LIGARE DESIGN HANDMADE' is on the surface.](https://i.etsystatic.com/14669466/r/il/ca8241/3462052188/il_794xN.3462052188_m8y3.jpg)
- ![May include: Four white pillar candles with a gray and gold concrete design. The candles are arranged in a row on a gray surface.](https://i.etsystatic.com/14669466/r/il/49a2d5/3462052280/il_794xN.3462052280_v9ev.jpg)
- ![May include: Three white pillar candles with a grey and brown textured design. The candles are arranged on a marble surface with a wooden surface in the background. The candles are handmade and have the words 'Ligare Design' and 'Handmade' printed on the surface.](https://i.etsystatic.com/14669466/r/il/6670f0/3462052454/il_794xN.3462052454_n1ca.jpg)

- ![May include: Three white pillar candles with gray and brown marbled designs. The candles are arranged on a white marble surface with a wooden background. The candles are handmade and have a rustic look. The text 'Ligare Design Handmade' is visible at the bottom of the image.](https://i.etsystatic.com/14669466/c/3000/2384/0/307/il/e57f19/2335341041/il_75x75.2335341041_j9hs.jpg)
- ![May include: Five concrete candles with a white and gray marbled design. The candles are arranged on a white marble surface. The candles are handmade and have a logo that reads 'Ligare Design Handmade'.](https://i.etsystatic.com/14669466/r/il/d31fdd/2287729516/il_75x75.2287729516_s9do.jpg)
- ![May include: Four concrete candles with a white wax finish and gold flecks. The candles are different sizes and are arranged in a row on a gray surface.](https://i.etsystatic.com/14669466/r/il/15f218/2581079629/il_75x75.2581079629_noj2.jpg)
- ![May include: Two white pillar candles with a light gray and gold design. The candles are handmade and have the words 'Ligare Design' and 'Handmade' on the bottom of the candle.](https://i.etsystatic.com/14669466/r/il/a0f40e/2287729520/il_75x75.2287729520_q9fg.jpg)
- ![May include: Two concrete candle holders with a marbled design and a white concrete candle. The candle holders are labeled 'Tealight Candle Holders' and the candle is labeled 'Concrete Candle'. The text 'Ligare Design Handmade' is also visible in the image.](https://i.etsystatic.com/14669466/r/il/a9b037/2335340449/il_75x75.2335340449_3qau.jpg)
- ![May include: Two white pillar candles with a textured, gray and gold finish. The candles are on a gray surface.](https://i.etsystatic.com/14669466/r/il/31b566/2533431824/il_75x75.2533431824_3tx2.jpg)
- ![May include: Two white pillar candles with a grey and gold marbled design. The candles have a white top layer and a grey and gold marbled bottom layer. The candles are handmade and have the text 'Ligare Design Handmade' on the bottom of the candle.](https://i.etsystatic.com/14669466/r/il/9163e8/3509717489/il_75x75.3509717489_ttto.jpg)
- ![May include: Five concrete candles with a marbleized and speckled design. The candles are arranged on a white marble surface. The candles are all different sizes and shapes. The text 'LIGARE DESIGN HANDMADE' is on the surface.](https://i.etsystatic.com/14669466/r/il/ca8241/3462052188/il_75x75.3462052188_m8y3.jpg)
- ![May include: Four white pillar candles with a gray and gold concrete design. The candles are arranged in a row on a gray surface.](https://i.etsystatic.com/14669466/r/il/49a2d5/3462052280/il_75x75.3462052280_v9ev.jpg)
- ![May include: Three white pillar candles with a grey and brown textured design. The candles are arranged on a marble surface with a wooden surface in the background. The candles are handmade and have the words 'Ligare Design' and 'Handmade' printed on the surface.](https://i.etsystatic.com/14669466/r/il/6670f0/3462052454/il_75x75.3462052454_n1ca.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F833151267%2Fhandmade-pillar-candle-pillar-candles%23report-overlay-trigger)

11 views in the last 24 hours

Price:$23.34+


Loading


# Handmade Pillar Candle - Pillar Candles Set for Home Decor - Pillar Candles Soy - Personalized Pillar Candle Set - White Candles

Designed by [martaARTwork](https://www.etsy.com/shop/martaARTwork)

[5 out of 5 stars](https://www.etsy.com/listing/833151267/handmade-pillar-candle-pillar-candles?utm_source=openai#reviews)

Returns & exchanges accepted

Size


Select an option

8 cm ($23.34)

15 cm ($27.45)

Set of two ($54.91)

extra large candle ($68.63)

set of 3 ($116.68)

Please select an option


4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Designed by [martaARTwork](https://www.etsy.com/shop/martaARTwork)

- Materials: Wax type: Soy


- Width: 4.5 centimeters

Height: 18 centimeters

- Gift wrapping available

See details

Gift wrapping by martaARTwork

WRAPEND IN CHRISTMAST OR BIRTHDAY PEPAER OPTION TO DISCUSSS DEPEND ON GIFT

\*\*\*\*\*The Personalized Handmade Concrete Pillar Candle and Soy Candle Wax

are created in Our Studio in Blackpool\*\*\*\*\*

-----About Product:

Raw Concrete and Gold Details adding to this Design Trendy and Minimalistic look. Modern, Sleek Candle are the perfect contemporary decoration hey will perfectly blend in with any kind of interior decoration.

\*\*\*\*\*They will look as great in the Bedroom, Living Room, Office, and even in the Bathroom\*\*\*\*\*

Buy it for Yourself or Gift it, an inexpensive but Modern Decoration makes a great gift for so many Occasions, Birthday, Christmas, Newlywed, Housewarming, Teacher, Mother’s Day, etc. They can be used indoors or outdoors. We can also create large quantities so they make a great party or wedding favor, and even corporate gift.

-----Available in two different sizes:

Small: 8cm tall

Large: 15cm tall

Extra Large Candle: 18cm tall, 08 cm Wide

<<<<< All items are made to order and have a 3- 5 days turnaround time so please bear this in

mind when ordering>>>>

\*\*\*\*\*Custom and Wholesale Orders Available\*\*\*\*\*

PLEASE NOTE!!!!!!

Please be aware that these products are Handmade and therefore each has Small Unique Irregularities (Bubbles and imperfections are part of the product's charm and individuality).

Kindly visit my shop to see more of my Photography or Handmade Designs and bemsure to favorite them as I add new items every day. Thank you for your time and consideration!

I

f you have any questions, please Contact Me

----------------We are very easy to rich by Etsy chat, email (martakorzekwa86@yahoo.com) or

phone number 00447531830197-------


## Shipping and return policies

Loading


- Order today to get by

**Nov 20-Dec 1**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 14 days


- Free shipping


- Ships from: **United Kingdom**


Deliver to United States

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## FAQs

Custom and personalized orders


Please contact with my for any custom order we are open for any personalised orders.


Custom and personalized orders


We are open for any custom order, we always trying to make some form of project for customers, so they can imagine hoe final product will look like. All custom vinyl records and other frame order will be process after mock-up is confirmed by customer


Sizing details


If any sizes are unclear for you please ask us via chat with seller :)


Care instructions


You can find all care instruction in item description or simply ask us via email or chat woth seller.


Gift wrapping and packaging


We are offering gift wrap or extra card for extra charge :)


Wholesale availability


Regarding wholesale price please ask about each product we are offering discount for bundle orders :)


All out items are design by us and created by us, if you like to change anything please contact us, there is no need for extra charges if you like to change anything :)


All out items are design by us and created by us, if you like to change anything please contact us, there is no need for extra charges if you like to change anything :)


Do we offering discount on bulk orders and wholesale


yes! Please contact us via Etsy chat!


Do we offer free delivery ?


Yes we do USA order over 35$ , UK order over 50£.


## Reviews for this item (14)

Loading


Buyer highlights, summarized by AI

Beautiful

Fast shipping

Love it

Lovely

Well packaged

Helpful seller

Great quality


Filter by category


Appearance (5)


Shipping & Packaging (4)


Seller service (3)


Quality (2)


Condition (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Catherine Lindsay](https://www.etsy.com/people/6rmujghdrvfewpl8?ref=l_review)
Dec 9, 2023


Lovely candles came quicker than expected and well packaged. Brilliant!



[Catherine Lindsay](https://www.etsy.com/people/6rmujghdrvfewpl8?ref=l_review)
Dec 9, 2023


5 out of 5 stars
5

This item

[Catherine Lindsay](https://www.etsy.com/people/6rmujghdrvfewpl8?ref=l_review)
Dec 9, 2023


Beautiful unusual candles. Love them, quick delivery also



[Catherine Lindsay](https://www.etsy.com/people/6rmujghdrvfewpl8?ref=l_review)
Dec 9, 2023


5 out of 5 stars
5

This item

[Helen](https://www.etsy.com/people/rw1pe5ft5oqid3i9?ref=l_review)
May 25, 2022


Absolutely beautiful candle. It arrived a little cracked but not bothered as I think that adds to the effect! Seller was extremely helpful and quick at responding. I’d order from here again most definitely.



[Helen](https://www.etsy.com/people/rw1pe5ft5oqid3i9?ref=l_review)
May 25, 2022


5 out of 5 stars
5

This item

[jgelenter1](https://www.etsy.com/people/jgelenter1?ref=l_review)
Dec 24, 2021


this seller is extremely fair and has beautiful products



[jgelenter1](https://www.etsy.com/people/jgelenter1?ref=l_review)
Dec 24, 2021


View all reviews for this item

### Photos from reviews

![Tracy added a photo of their purchase](https://i.etsystatic.com/iap/ac2257/2778407698/iap_300x300.2778407698_ljirw7n9.jpg?version=0)

![Lauren added a photo of their purchase](https://i.etsystatic.com/iap/5fd486/2500667218/iap_300x300.2500667218_9rxyfix8.jpg?version=0)

[![martaARTwork](https://i.etsystatic.com/iusa/b61540/84814576/iusa_75x75.84814576_lgbb.jpg?version=0)](https://www.etsy.com/shop/martaARTwork?ref=shop_profile&listing_id=833151267)

[martaARTwork](https://www.etsy.com/shop/martaARTwork?ref=shop_profile&listing_id=833151267)

[Owned by MARTA martaARTwork](https://www.etsy.com/shop/martaARTwork?ref=shop_profile&listing_id=833151267) \|

Blackpool, United Kingdom

4.8
(1.5k)


9.9k sales

8 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=94942058&referring_id=833151267&referring_type=listing&recipient_id=94942058&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo5NDk0MjA1ODoxNzYyNzg4MzYxOjFiZWI4NjlhZTIxNDc0ODhjZWYwMTMxMjMwNDJhOTEx&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F833151267%2Fhandmade-pillar-candle-pillar-candles%3Futm_source%3Dopenai)

This seller usually responds **within a few hours.**

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/martaARTwork?ref=lp_mys_mfts)

- [![Stained Glass Flower Bouquet for Table Decor - Handmade Glass Flower with Vase - Personalized Stained Glass Art Suncatcher -Mothers Day Gift](https://i.etsystatic.com/14669466/c/2884/2292/49/147/il/ccc080/3700624006/il_340x270.3700624006_u9bo.jpg)\\
\\
**Stained Glass Flower Bouquet for Table Decor - Handmade Glass Flower with Vase - Personalized Stained Glass Art Suncatcher -Mothers Day Gift**\\
\\
$20.59\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1184844693/stained-glass-flower-bouquet-for-table?click_key=ffa384d8d49527e0e78bb3d3f7c59310%3ALTee97e51312921d7ea26a581b6711bc74bd01a2c6&click_sum=1315a2c9&ls=r&ref=related-1&content_source=ffa384d8d49527e0e78bb3d3f7c59310%253ALTee97e51312921d7ea26a581b6711bc74bd01a2c6 "Stained Glass Flower Bouquet for Table Decor - Handmade Glass Flower with Vase - Personalized Stained Glass Art Suncatcher -Mothers Day Gift")




Add to Favorites


- [![Stained Glass Flowers for Vase - Glass Flowers with a Spiral Stem - California Poppy Flower for Table Decor - Stained Glass Poppy Flower](https://i.etsystatic.com/14669466/r/il/be7295/4395795610/il_340x270.4395795610_5fzo.jpg)\\
\\
**Stained Glass Flowers for Vase - Glass Flowers with a Spiral Stem - California Poppy Flower for Table Decor - Stained Glass Poppy Flower**\\
\\
$21.96\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1345017294/stained-glass-flowers-for-vase-glass?click_key=ffa384d8d49527e0e78bb3d3f7c59310%3ALT121998e101ed7df7fba43d3372386edaba8afb50&click_sum=362acc31&ls=r&ref=related-2&content_source=ffa384d8d49527e0e78bb3d3f7c59310%253ALT121998e101ed7df7fba43d3372386edaba8afb50 "Stained Glass Flowers for Vase - Glass Flowers with a Spiral Stem - California Poppy Flower for Table Decor - Stained Glass Poppy Flower")




Add to Favorites


- [![Leaves Stained Glass Succulent for Pot Nature Home Decor - Plant Suncatcher Table Plant - Glass Suncatcher Leaves - Stained Glass Plants](https://i.etsystatic.com/14669466/r/il/3a2d08/5103860628/il_340x270.5103860628_s7gf.jpg)\\
\\
**Leaves Stained Glass Succulent for Pot Nature Home Decor - Plant Suncatcher Table Plant - Glass Suncatcher Leaves - Stained Glass Plants**\\
\\
$61.77\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1526455925/leaves-stained-glass-succulent-for-pot?click_key=ffa384d8d49527e0e78bb3d3f7c59310%3ALTe1248ae42783e4a4ba474870a20e7eb7b85ff466&click_sum=b1460a85&ls=r&ref=related-3&content_source=ffa384d8d49527e0e78bb3d3f7c59310%253ALTe1248ae42783e4a4ba474870a20e7eb7b85ff466 "Leaves Stained Glass Succulent for Pot Nature Home Decor - Plant Suncatcher Table Plant - Glass Suncatcher Leaves - Stained Glass Plants")




Add to Favorites


- [![Platinum Vinyl Record Custom Music Plaque - Engraved Wedding Song Gift Plaque for Wall Decor - Custom Vinyl Records for 1st Anniversary Gif](https://i.etsystatic.com/14669466/r/il/0a95a0/6670645435/il_340x270.6670645435_ir5a.jpg)\\
\\
**Platinum Vinyl Record Custom Music Plaque - Engraved Wedding Song Gift Plaque for Wall Decor - Custom Vinyl Records for 1st Anniversary Gif**\\
\\
$80.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1276020093/platinum-vinyl-record-custom-music?click_key=692dbbb85ee741922d44257d708909f1697aaadf%3A1276020093&click_sum=7dcfbbfc&ref=related-4 "Platinum Vinyl Record Custom Music Plaque - Engraved Wedding Song Gift Plaque for Wall Decor - Custom Vinyl Records for 1st Anniversary Gif")




Add to Favorites



Loading...

Loading


**Disclaimer:** Button/coin batteries may cause serious injury and even death if swallowed. Items containing button/coin batteries should not be easily accessible without the use of a tool. Sellers are responsible for complying with all applicable labeling, design, testing, packaging, and other safety requirements. Etsy assumes no responsibility for the accuracy or contents of a seller’s listing. If you have questions about button/coin batteries, contact the seller by sending a Message. See Etsy's [Terms of Use](https://www.etsy.com/legal/terms-of-use/?ref=product_safety_banner_info_button_batteries_risk#warranties) for more information.

Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 9, 2025


[1193 favorites](https://www.etsy.com/listing/833151267/handmade-pillar-candle-pillar-candles/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?utm_source=openai&explicit=1&ref=breadcrumb_listing)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F833151267%2Fhandmade-pillar-candle-pillar-candles%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc4ODM2MTozMDljZDFkMmZkMTg1YzQwM2JlMTg3YTJjNjdjZWIyYQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F833151267%2Fhandmade-pillar-candle-pillar-candles%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/833151267/handmade-pillar-candle-pillar-candles?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F833151267%2Fhandmade-pillar-candle-pillar-candles%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for martaARTwork

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 2 days of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


Customs and import taxes

Buyers are responsible for any customs and import taxes that may apply. I'm not responsible for delays due to customs.


## Seller details

### Other details

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=94942058&referring_id=14669466&referring_type=shop&recipient_id=94942058&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: Three white pillar candles with gray and brown marbled designs. The candles are arranged on a white marble surface with a wooden background. The candles are handmade and have a rustic look. The text 'Ligare Design Handmade' is visible at the bottom of the image.](https://i.etsystatic.com/14669466/c/3000/3000/0/0/il/e57f19/2335341041/il_300x300.2335341041_j9hs.jpg)
- ![May include: Five concrete candles with a white and gray marbled design. The candles are arranged on a white marble surface. The candles are handmade and have a logo that reads 'Ligare Design Handmade'.](https://i.etsystatic.com/14669466/r/il/d31fdd/2287729516/il_300x300.2287729516_s9do.jpg)
- ![May include: Four concrete candles with a white wax finish and gold flecks. The candles are different sizes and are arranged in a row on a gray surface.](https://i.etsystatic.com/14669466/r/il/15f218/2581079629/il_300x300.2581079629_noj2.jpg)
- ![May include: Two white pillar candles with a light gray and gold design. The candles are handmade and have the words 'Ligare Design' and 'Handmade' on the bottom of the candle.](https://i.etsystatic.com/14669466/r/il/a0f40e/2287729520/il_300x300.2287729520_q9fg.jpg)
- ![May include: Two concrete candle holders with a marbled design and a white concrete candle. The candle holders are labeled 'Tealight Candle Holders' and the candle is labeled 'Concrete Candle'. The text 'Ligare Design Handmade' is also visible in the image.](https://i.etsystatic.com/14669466/r/il/a9b037/2335340449/il_300x300.2335340449_3qau.jpg)
- ![May include: Two white pillar candles with a textured, gray and gold finish. The candles are on a gray surface.](https://i.etsystatic.com/14669466/r/il/31b566/2533431824/il_300x300.2533431824_3tx2.jpg)
- ![May include: Two white pillar candles with a grey and gold marbled design. The candles have a white top layer and a grey and gold marbled bottom layer. The candles are handmade and have the text 'Ligare Design Handmade' on the bottom of the candle.](https://i.etsystatic.com/14669466/r/il/9163e8/3509717489/il_300x300.3509717489_ttto.jpg)
- ![May include: Five concrete candles with a marbleized and speckled design. The candles are arranged on a white marble surface. The candles are all different sizes and shapes. The text 'LIGARE DESIGN HANDMADE' is on the surface.](https://i.etsystatic.com/14669466/r/il/ca8241/3462052188/il_300x300.3462052188_m8y3.jpg)
- ![May include: Four white pillar candles with a gray and gold concrete design. The candles are arranged in a row on a gray surface.](https://i.etsystatic.com/14669466/r/il/49a2d5/3462052280/il_300x300.3462052280_v9ev.jpg)
- ![May include: Three white pillar candles with a grey and brown textured design. The candles are arranged on a marble surface with a wooden surface in the background. The candles are handmade and have the words 'Ligare Design' and 'Handmade' printed on the surface.](https://i.etsystatic.com/14669466/r/il/6670f0/3462052454/il_300x300.3462052454_n1ca.jpg)

- ![](https://i.etsystatic.com/iap/ac2257/2778407698/iap_640x640.2778407698_ljirw7n9.jpg?version=0)

4 out of 5 stars

- Size:

Set of two


Unfortunately the candle came cracked during shipping. The box it came in had beaten up during transit. But the candle was beautiful.

Jan 7, 2021


[Tracy Potter](https://www.etsy.com/people/tpotter03)

Purchased item:

[![Handmade Pillar Candle - Pillar Candles Set for Home Decor - Pillar Candles Soy - Personalized Pillar Candle Set - White Candles](https://i.etsystatic.com/14669466/c/3000/2384/0/307/il/e57f19/2335341041/il_170x135.2335341041_j9hs.jpg)\\
\\
Handmade Pillar Candle - Pillar Candles Set for Home Decor - Pillar Candles Soy - Personalized Pillar Candle Set - White Candles\\
\\
$23.34](https://www.etsy.com/listing/833151267/handmade-pillar-candle-pillar-candles?ref=ap-listing)

Purchased item:

[![Handmade Pillar Candle - Pillar Candles Set for Home Decor - Pillar Candles Soy - Personalized Pillar Candle Set - White Candles](https://i.etsystatic.com/14669466/c/3000/2384/0/307/il/e57f19/2335341041/il_170x135.2335341041_j9hs.jpg)\\
\\
Handmade Pillar Candle - Pillar Candles Set for Home Decor - Pillar Candles Soy - Personalized Pillar Candle Set - White Candles\\
\\
$23.34](https://www.etsy.com/listing/833151267/handmade-pillar-candle-pillar-candles?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/5fd486/2500667218/iap_640x640.2500667218_9rxyfix8.jpg?version=0)

4 out of 5 stars

- Size:

Set of two


Aug 31, 2020


[Lauren Shannon](https://www.etsy.com/people/lulshannon)

Purchased item:

[![Handmade Pillar Candle - Pillar Candles Set for Home Decor - Pillar Candles Soy - Personalized Pillar Candle Set - White Candles](https://i.etsystatic.com/14669466/c/3000/2384/0/307/il/e57f19/2335341041/il_170x135.2335341041_j9hs.jpg)\\
\\
Handmade Pillar Candle - Pillar Candles Set for Home Decor - Pillar Candles Soy - Personalized Pillar Candle Set - White Candles\\
\\
$23.34](https://www.etsy.com/listing/833151267/handmade-pillar-candle-pillar-candles?ref=ap-listing)

Purchased item:

[![Handmade Pillar Candle - Pillar Candles Set for Home Decor - Pillar Candles Soy - Personalized Pillar Candle Set - White Candles](https://i.etsystatic.com/14669466/c/3000/2384/0/307/il/e57f19/2335341041/il_170x135.2335341041_j9hs.jpg)\\
\\
Handmade Pillar Candle - Pillar Candles Set for Home Decor - Pillar Candles Soy - Personalized Pillar Candle Set - White Candles\\
\\
$23.34](https://www.etsy.com/listing/833151267/handmade-pillar-candle-pillar-candles?ref=ap-listing)