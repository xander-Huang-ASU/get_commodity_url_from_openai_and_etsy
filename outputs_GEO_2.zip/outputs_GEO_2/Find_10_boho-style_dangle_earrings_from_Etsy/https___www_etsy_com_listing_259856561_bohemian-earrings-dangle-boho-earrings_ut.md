[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Jewelry](https://www.etsy.com/c/jewelry?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Earrings](https://www.etsy.com/c/jewelry/earrings?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Dangle & Drop Earrings](https://www.etsy.com/c/jewelry/earrings/dangle-earrings?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)

Etsy’s Pick

Etsy’s Picks are hand selected by our style experts to highlight items from shops that have shown quality, reliability and style.

[Discover More](https://www.etsy.com/featured/hub/etsy-picks?ref=listing_etsys_pick_signal)


Add to Favorites


- ![boho brass dangle drop earrings. Ethnic inspired brass coin earrings](https://i.etsystatic.com/5855353/r/il/47b644/1482205257/il_794xN.1482205257_rpxt.jpg)
- ![boho brass dangle drop earrings. Ethnic inspired brass coin earrings](https://i.etsystatic.com/5855353/r/il/9bc5cf/885881710/il_794xN.885881710_k2pd.jpg)
- ![boho brass dangle drop earrings. Ethnic inspired brass coin earrings](https://i.etsystatic.com/5855353/r/il/85ecb4/1482205027/il_794xN.1482205027_hkod.jpg)
- ![boho brass dangle drop earrings. Ethnic inspired brass coin earrings](https://i.etsystatic.com/5855353/r/il/decf2f/885881708/il_794xN.885881708_ak8z.jpg)
- ![boho brass dangle drop earrings. Ethnic inspired brass coin earrings](https://i.etsystatic.com/5855353/r/il/b123b7/2688732705/il_794xN.2688732705_n39m.jpg)
- ![May include: Three brown gift boxes with brown ribbon and brown organza bags. The boxes are all the same size and have a white label with the text 'Rustica Jewelry' on them. The boxes are sitting on a wooden surface.](https://i.etsystatic.com/5855353/r/il/e3f372/2746651911/il_794xN.2746651911_9xo7.jpg)

- ![boho brass dangle drop earrings. Ethnic inspired brass coin earrings](https://i.etsystatic.com/5855353/c/2282/1812/0/278/il/47b644/1482205257/il_75x75.1482205257_rpxt.jpg)
- ![boho brass dangle drop earrings. Ethnic inspired brass coin earrings](https://i.etsystatic.com/5855353/r/il/9bc5cf/885881710/il_75x75.885881710_k2pd.jpg)
- ![boho brass dangle drop earrings. Ethnic inspired brass coin earrings](https://i.etsystatic.com/5855353/r/il/85ecb4/1482205027/il_75x75.1482205027_hkod.jpg)
- ![boho brass dangle drop earrings. Ethnic inspired brass coin earrings](https://i.etsystatic.com/5855353/r/il/decf2f/885881708/il_75x75.885881708_ak8z.jpg)
- ![boho brass dangle drop earrings. Ethnic inspired brass coin earrings](https://i.etsystatic.com/5855353/r/il/b123b7/2688732705/il_75x75.2688732705_n39m.jpg)
- ![May include: Three brown gift boxes with brown ribbon and brown organza bags. The boxes are all the same size and have a white label with the text 'Rustica Jewelry' on them. The boxes are sitting on a wooden surface.](https://i.etsystatic.com/5855353/r/il/e3f372/2746651911/il_75x75.2746651911_9xo7.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F259856561%2Fbohemian-earrings-dangle-boho-earrings%23report-overlay-trigger)

In 18 carts

NowPrice:$30.00


Loading


# Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry

Made by [RusticaJewelry](https://www.etsy.com/shop/RusticaJewelry)

[5 out of 5 stars](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?utm_source=openai#reviews)

Returns & exchanges accepted

Save 25% when you spend $40+ at this shop

**Shop the sale**

Ear wire


Select an option

Hook (as shown)

Lever back

Please select an option


4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Made by [RusticaJewelry](https://www.etsy.com/shop/RusticaJewelry)

- Materials: Brass

- Location: Earlobe

- Closure: Ear wire

- Style: Boho & hippie

- Drop length: 1.5 Inches; Length: 1.75 Inches; Width: 1 Inches


- Gift wrapping available

See details

Gift wrapping by RusticaJewelry

Packaged in a recycled paper jewelry box and small gift bag with a personalized note.

Boho brass dangle earrings with filigree teardrop and brass accents.

\*\*\*Please note, this is the original listing for these earrings, if you see my photos elsewhere they have been copied! Thank you for supporting the original artist\*\*\*

Perfect light-weight, medium sized everyday earrings made with layered, antiqued brass. These earrings will add a beautiful rustic, bohemian vibe to any outfit.

\\*\\*\\* Please scroll through each of the photos, these are not large earrings. The largest disc is 1" in diameter which is about the size of quarter. Each layered piece is separate\*\*\*

Product overview:

\- Made with various antiqued brass discs and teardrop

\- Approximately 1.75" in total hanging length including the ear wire, the largest disc is about the size of a quarter

\- Light-weight and versatile

\- Hypoallergenic ear wires (nickel and lead free)

\\*\\*\\* Please scroll through each of the photos, these are not large earrings. The largest disc is 1" in diameter which is about the size of quarter. \*\*\*

Want a discount on your first order? Join the Rustica Jewelry newsletter!

Visit: http://eepurl.com/hmEwun

\- In an effort to reduce waste through excess packaging, I ship multiple item orders in bulk, this is several items in one box. If you need individual gift boxes for each item please leave me a note during checkout.


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-25**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 14 days


- Free shipping


- Ships from: **United States**


Deliver to United States

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## FAQs

How do I return my item?


If you wish to return or exchange an item please contact me through Etsy within 7 days of receiving the order. Returns must be shipped within 14 days of receiving the order. Please note that custom orders are not eligible for return. Any item being returned for a refund or exchange must be packaged in the original packaging (jewelry box with cotton and bubble envelope). Items must be received back to me in original condition. I am not responsible for damage that occurs during return shipping and damaged items will not be eligible for the full refund/exchange amount.

As I offer free shipping on all orders, the customer is responsible for any return shipping charges. I will only cover shipping charges if the item arrives broken or defective.


Can I request expedited shipping?


Yes, I offer expedited shipping at the customers expense. Please send me a message to discuss expedited shipping options and costs.

Please note that I ship all orders within the time frame shown on the item listing page. If you need your order to ship before that time frame please send me a message through the Etsy Message tab at bottom of listing. This ensures that I see your request and respond to your request. If I cannot fulfill your request I will send a message within 24 hrs.


I purchased my order with the wrong address, can this be corrected?


If you placed your order under an incorrect address please contact me through the message button ASAP. I can change the address for you before the order is shipped.

\\*\\*\\*\\* If the package has already shipped and/or arrives at an incorrect address the customer will be responsible for the new shipping. I will only offer free shipping on the initial purchase\*\*\*


I ordered the wrong length/size?


If the item you purchased is not the correct size or you need a different size than what was ordered please contact me. I will adjust the length/size for no additional charge in most cases (some necklace lengths will require an additional material fee).

The customer will be responsible for the return shipping to me and the shipping to be redelivered.


Sale items and discounts


\- Sale pricing will only be honored during the days/hours of the ACTIVE sale. Orders placed outside of the active sale time frame will not be price adjusted to reflect sale, regardless of the shipping status.

\- Additionally, if an item price becomes reduced, previous orders at the original price will not be adjusted or refunded.

NO EXCEPTIONS

\- Only ONE sale can be honored at a time. Newsletter discounts cannot be combined with sale items, newsletter discounts can only be applied to regular priced items.


Will I get the exact item in the photo?


For any item specifically marked as OOAK (one of a kind) or otherwise stated in the description, you will receive the exact pair in the photo. For many other items I use my own stock photos, as these items can be replicated, and you will receive an item very similar with possible slight variations (such as stone coloration or metal finish). Rest assured you will receive a quality handcrafted item that will be unique to you!

As always, if you are unhappy with your item you are welcome to return for a refund or exchange.


Custom and personalized orders


I do accept requests for custom orders, please contact me for further details.


Wholesale availability


I currently offer wholesale through my other website, please email me at rusticajewelry@gmail for the site and password.


## Meet your seller

![Linda Blume](https://i.etsystatic.com/5855353/r/isla/68035d/54079658/isla_75x75.54079658_17t7std8.jpg)

Linda Blume

Owner of [RusticaJewelry](https://www.etsy.com/shop/RusticaJewelry?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo5Njk4OTQwOjE3NjI3Nzg1OTY6ZGZhMDFmZjFhZWY4NDcyMDM5ZGY3N2NmNzc2MjZmY2E%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F259856561%2Fbohemian-earrings-dangle-boho-earrings%3Futm_source%3Dopenai)

[Message Linda](https://www.etsy.com/messages/new?with_id=9698940&referring_id=259856561&referring_type=listing&recipient_id=9698940&from_action=contact-seller)

## Reviews for this item (345)

4.8/5

item average

4.9Item quality

4.8Shipping

4.9Customer service

98%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Love it

Beautiful

As described

Very pretty

Fast shipping

Lightweight

Great quality


Filter by category


Appearance (142)


Quality (72)


Description accuracy (64)


Shipping & Packaging (37)


Comfort (34)


Sizing & Fit (25)


Seller service (13)


Value (10)


Ease of use (1)


Condition (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Monica](https://www.etsy.com/people/mfmwuxcc?ref=l_review)
Nov 6, 2025


They are pretty, a little smaller than I thought, but I love them. I love Rustica's jewelry



[Monica](https://www.etsy.com/people/mfmwuxcc?ref=l_review)
Nov 6, 2025


5 out of 5 stars
5

This item

[Kristylee Collins](https://www.etsy.com/people/kriskristy5?ref=l_review)
Nov 4, 2025


Love!!! Quick & easy ordering.



[Kristylee Collins](https://www.etsy.com/people/kriskristy5?ref=l_review)
Nov 4, 2025


5 out of 5 stars
5

This item

[Khalilah Johnson](https://www.etsy.com/people/khalilahjohnson?ref=l_review)
Oct 26, 2025


Smaller than expected, but really nice and lightweight



[Khalilah Johnson](https://www.etsy.com/people/khalilahjohnson?ref=l_review)
Oct 26, 2025


4 out of 5 stars
4

This item

[Marybeth](https://www.etsy.com/people/v49ts3udmyrdwloq?ref=l_review)
Oct 18, 2025


I didn’t expect for the material to be so light. Hopefully they’ll last a while.



[Marybeth](https://www.etsy.com/people/v49ts3udmyrdwloq?ref=l_review)
Oct 18, 2025


View all reviews for this item

### Photos from reviews

![Cherie added a photo of their purchase](https://i.etsystatic.com/iap/4ce319/6896335160/iap_300x300.6896335160_le8axhd8.jpg?version=0)

![Kayla added a photo of their purchase](https://i.etsystatic.com/iap/8e2098/6774539060/iap_300x300.6774539060_7xzv41um.jpg?version=0)

![Suzanne added a photo of their purchase](https://i.etsystatic.com/iap/c1483c/6488011161/iap_300x300.6488011161_5zsvq8wu.jpg?version=0)

![Mrs. added a photo of their purchase](https://i.etsystatic.com/iap/7a8f95/4830319908/iap_300x300.4830319908_kxoy1s8q.jpg?version=0)

![Sam added a photo of their purchase](https://i.etsystatic.com/iap/328a94/4591661263/iap_300x300.4591661263_nruqv1u7.jpg?version=0)

![S added a photo of their purchase](https://i.etsystatic.com/iap/2dc1d9/4840157323/iap_300x300.4840157323_dor6p4zp.jpg?version=0)

![Sandy added a photo of their purchase](https://i.etsystatic.com/iap/06b02a/4153663727/iap_300x300.4153663727_66396nx0.jpg?version=0)

![teaflower3 added a photo of their purchase](https://i.etsystatic.com/iap/469efa/3843550579/iap_300x300.3843550579_6r2pcdf6.jpg?version=0)

![Deb added a photo of their purchase](https://i.etsystatic.com/iap/add9ab/3612910060/iap_300x300.3612910060_ex69zbw3.jpg?version=0)

![Amy added a photo of their purchase](https://i.etsystatic.com/iap/924c17/3591818371/iap_300x300.3591818371_3dfdd3g5.jpg?version=0)

[![RusticaJewelry](https://i.etsystatic.com/iusa/2018fa/23201984/iusa_75x75.23201984_ip3r.jpg?version=0)](https://www.etsy.com/shop/RusticaJewelry?ref=shop_profile&listing_id=259856561)

[RusticaJewelry](https://www.etsy.com/shop/RusticaJewelry?ref=shop_profile&listing_id=259856561)

[Owned by Linda Blume](https://www.etsy.com/shop/RusticaJewelry?ref=shop_profile&listing_id=259856561) \|

Eatontown, New Jersey

4.9
(9k)


33.8k sales

15 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=9698940&referring_id=259856561&referring_type=listing&recipient_id=9698940&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo5Njk4OTQwOjE3NjI3Nzg1OTY6ZGZhMDFmZjFhZWY4NDcyMDM5ZGY3N2NmNzc2MjZmY2E%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F259856561%2Fbohemian-earrings-dangle-boho-earrings%3Futm_source%3Dopenai)

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/RusticaJewelry?ref=lp_mys_mfts)

Get 25% off your order when you spend $40 at this shop. Discount shown at checkout.


- [![Mixed metal earrings, boho dangle earrings, geometric earrings, geometric jewelry, boho jewelry, bohemian earrings, mixed metal jewelry](https://i.etsystatic.com/5855353/r/il/6bcd8b/843836464/il_340x270.843836464_llu0.jpg)\\
\\
**Mixed metal earrings, boho dangle earrings, geometric earrings, geometric jewelry, boho jewelry, bohemian earrings, mixed metal jewelry**\\
\\
$30.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/250450514/mixed-metal-earrings-boho-dangle?click_key=75d179d5f8de60105789fa0ce8c666f1%3ALT89f5ce2448ab00d6d73bf9304e6e33f9bd5e35f5&click_sum=31c03a67&ls=r&ref=related-1&content_source=75d179d5f8de60105789fa0ce8c666f1%253ALT89f5ce2448ab00d6d73bf9304e6e33f9bd5e35f5 "Mixed metal earrings, boho dangle earrings, geometric earrings, geometric jewelry, boho jewelry, bohemian earrings, mixed metal jewelry")




Add to Favorites


- [![Brass Boho Earrings, Brass Silver Long Earrings, Long Bohemian Dangle Earrings, Boho Jewelry, Brass Jewelry, Long Dangle Earrings](https://i.etsystatic.com/5855353/c/1950/1548/0/172/il/c510d5/1572413757/il_340x270.1572413757_5leu.jpg)\\
\\
**Brass Boho Earrings, Brass Silver Long Earrings, Long Bohemian Dangle Earrings, Boho Jewelry, Brass Jewelry, Long Dangle Earrings**\\
\\
$29.85\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/619737785/brass-boho-earrings-brass-silver-long?click_key=75d179d5f8de60105789fa0ce8c666f1%3ALTbd19b4b6a844f55ba4913589eede81783b9b2396&click_sum=65c01a3a&ls=r&ref=related-2&content_source=75d179d5f8de60105789fa0ce8c666f1%253ALTbd19b4b6a844f55ba4913589eede81783b9b2396 "Brass Boho Earrings, Brass Silver Long Earrings, Long Bohemian Dangle Earrings, Boho Jewelry, Brass Jewelry, Long Dangle Earrings")




Add to Favorites


- [![Red Creek Jasper Earrings, Boho Dangle Teardrop Earrings, Earthy Stone Earrings, Brass Drop Earrings, Bohemian Jewelry, Jasper Jewelry](https://i.etsystatic.com/5855353/c/1862/1478/0/281/il/2d8833/2896129769/il_340x270.2896129769_elll.jpg)\\
\\
**Red Creek Jasper Earrings, Boho Dangle Teardrop Earrings, Earthy Stone Earrings, Brass Drop Earrings, Bohemian Jewelry, Jasper Jewelry**\\
\\
$32.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/956786877/red-creek-jasper-earrings-boho-dangle?click_key=75d179d5f8de60105789fa0ce8c666f1%3ALT48de920dff96832013a1b4fe99dd69c37f425b56&click_sum=6fbab8fb&ls=r&ref=related-3&content_source=75d179d5f8de60105789fa0ce8c666f1%253ALT48de920dff96832013a1b4fe99dd69c37f425b56 "Red Creek Jasper Earrings, Boho Dangle Teardrop Earrings, Earthy Stone Earrings, Brass Drop Earrings, Bohemian Jewelry, Jasper Jewelry")




Add to Favorites


- [![Turquoise Statement Necklace, American Blue Green Turquoise with Antiqued Silver Accents, December Birthstone Jewelry](https://i.etsystatic.com/5855353/c/1831/1831/91/91/il/a77a53/7395812707/il_340x270.7395812707_h6xr.jpg)\\
\\
**Turquoise Statement Necklace, American Blue Green Turquoise with Antiqued Silver Accents, December Birthstone Jewelry**\\
\\
$188.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4353385986/turquoise-statement-necklace-american?click_key=956e7283e9649ce890dae02e9be59d6140ddf9ae%3A4353385986&click_sum=c2ccefd0&ref=related-4 "Turquoise Statement Necklace, American Blue Green Turquoise with Antiqued Silver Accents, December Birthstone Jewelry")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 9, 2025


[6170 favorites](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Jewelry](https://www.etsy.com/c/jewelry?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Earrings](https://www.etsy.com/c/jewelry/earrings?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Dangle & Drop Earrings](https://www.etsy.com/c/jewelry/earrings/dangle-earrings?utm_source=openai&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Womens Clothing

[LGBTQ Rainbow Striped Women One Piece Swimsuit by UnhiddenSun](https://www.etsy.com/listing/4324200296/lgbtq-rainbow-striped-women-one-piece)

Beads Gems & Cabochons

[Sky Blue Topaz Hexagon Step Cut Gemstone (4.0X4.0X2.5 mm) by Harekrishnagems](https://www.etsy.com/listing/1275623176/sky-blue-topaz-hexagon-step-cut-natural)

Pet Collars & Leashes

[Ho Ho Ho Dog Collar - Pet Collars & Leashes](https://www.etsy.com/listing/1113296590/ho-ho-ho-dog-collar)

Party Supplies

[Shop 60 And Fabulous Tiara](https://www.etsy.com/market/60_and_fabulous_tiara)

Earrings

[Club America Earrings - US](https://www.etsy.com/market/club_america_earrings) [Infinity Knot Hoop Earrings by GemSelectvip](https://www.etsy.com/listing/1795396616/infinity-knot-hoop-earringsearrings-for) [Pearl Heart Dangle Earrings - US](https://www.etsy.com/market/pearl_heart_dangle_earrings) [HUMMINGBIRD Stainless Steel Lever Back Earrings Heavy Duty Earwires by BusyBeeBumbleBeads](https://www.etsy.com/listing/1707187982/hummingbird-stainless-steel-lever-back) [Buy Miraculous Ladybug Earrings Gold Online](https://www.etsy.com/market/miraculous_ladybug_earrings_gold)

Keychains & Lanyards

[Buy Ursula Badge Reel Online](https://www.etsy.com/market/ursula_badge_reel)

Prints

[Sage Green Wall Art - Prints](https://www.etsy.com/listing/1802960194/how-lucky-are-we-poster-sage-green-wall)

Necklaces

[Green turquoise and jade beads necklace](https://www.etsy.com/listing/1557050039/green-turquoise-and-jade-beads)

Docking & Stands

[Phone / Ipad / Kindle Stand by TheDancingGoats](https://www.etsy.com/listing/1437467595/phone-ipad-kindle-stand-heimdallr-the)

Patterns & How To

[Witch 3 - SVG PNG JPG files \*for Spooky Scary Creepy Witch Monster Broomstick Cauldron Black Cat Pointy Hat Scrapbook Cricut Silhouette](https://www.etsy.com/listing/1315478322/witch-3-svg-png-jpg-files-for-spooky)

Fragrances

[Trees of the High Desert - a roll on herbal perfume - Fragrances](https://www.etsy.com/listing/817926214/trees-of-the-high-desert-a-roll-on)

Drawing & Illustration

[Happy Tea Cup PNG for Discord by OverlayHaven](https://www.etsy.com/listing/4353651216/cute-kawaii-mate-drink-animated-twitch)

Decorations & Embellishments

[Iron on hot fix by JackMing2011](https://www.etsy.com/listing/1191541036/flower-rhinestone-transfer-iron-on-hot)

Collectibles

[Shop Collectibles from Lenashop75](https://www.etsy.com/shop/Lenashop75)

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F259856561%2Fbohemian-earrings-dangle-boho-earrings%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc3ODU5NjoyMjdmMzY4NWI1MzA4OGU5MTU1MGMzYWJhYzJlZGE1NA==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F259856561%2Fbohemian-earrings-dangle-boho-earrings%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F259856561%2Fbohemian-earrings-dangle-boho-earrings%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

Loading


There was a problem loading the content


Try again

## Shop policies for RusticaJewelry

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 2 days of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![boho brass dangle drop earrings. Ethnic inspired brass coin earrings](https://i.etsystatic.com/5855353/c/2282/2282/0/43/il/47b644/1482205257/il_300x300.1482205257_rpxt.jpg)
- ![boho brass dangle drop earrings. Ethnic inspired brass coin earrings](https://i.etsystatic.com/5855353/r/il/9bc5cf/885881710/il_300x300.885881710_k2pd.jpg)
- ![boho brass dangle drop earrings. Ethnic inspired brass coin earrings](https://i.etsystatic.com/5855353/r/il/85ecb4/1482205027/il_300x300.1482205027_hkod.jpg)
- ![boho brass dangle drop earrings. Ethnic inspired brass coin earrings](https://i.etsystatic.com/5855353/r/il/decf2f/885881708/il_300x300.885881708_ak8z.jpg)
- ![boho brass dangle drop earrings. Ethnic inspired brass coin earrings](https://i.etsystatic.com/5855353/r/il/b123b7/2688732705/il_300x300.2688732705_n39m.jpg)
- ![May include: Three brown gift boxes with brown ribbon and brown organza bags. The boxes are all the same size and have a white label with the text 'Rustica Jewelry' on them. The boxes are sitting on a wooden surface.](https://i.etsystatic.com/5855353/r/il/e3f372/2746651911/il_300x300.2746651911_9xo7.jpg)

- ![](https://i.etsystatic.com/iap/4ce319/6896335160/iap_640x640.6896335160_le8axhd8.jpg?version=0)

3 out of 5 stars

- Ear wire:

Hook (as shown)


Quality was average. I thought shipping was slow but the two pairs of earrings I ordered were for me so not needed as gift. Nice box and pretty bag included, nice touch!

May 28, 2025


[Cherie](https://www.etsy.com/people/lsqw5dt0f0uom26a)

Purchased item:

[![Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry](https://i.etsystatic.com/5855353/c/2282/1812/0/278/il/47b644/1482205257/il_170x135.1482205257_rpxt.jpg)\\
\\
Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry\\
\\
$30.00\\
\\
\\
Eligible orders get 25% off](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?ref=ap-listing)

Purchased item:

[![Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry](https://i.etsystatic.com/5855353/c/2282/1812/0/278/il/47b644/1482205257/il_170x135.1482205257_rpxt.jpg)\\
\\
Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry\\
\\
$30.00\\
\\
\\
Eligible orders get 25% off](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/8e2098/6774539060/iap_640x640.6774539060_7xzv41um.jpg?version=0)

5 out of 5 stars

- Ear wire:

Hook (as shown)


Love love love! I will be ordering from this store again. :)

Apr 7, 2025


[Kayla](https://www.etsy.com/people/mb9v85vvrw06rvgd)

Purchased item:

[![Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry](https://i.etsystatic.com/5855353/c/2282/1812/0/278/il/47b644/1482205257/il_170x135.1482205257_rpxt.jpg)\\
\\
Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry\\
\\
$30.00\\
\\
\\
Eligible orders get 25% off](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?ref=ap-listing)

Purchased item:

[![Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry](https://i.etsystatic.com/5855353/c/2282/1812/0/278/il/47b644/1482205257/il_170x135.1482205257_rpxt.jpg)\\
\\
Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry\\
\\
$30.00\\
\\
\\
Eligible orders get 25% off](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/c1483c/6488011161/iap_640x640.6488011161_5zsvq8wu.jpg?version=0)

5 out of 5 stars

- Ear wire:

Hook (as shown)


Beautiful earrings! Expedited shipping! I love them! Thank you!

![](https://i.etsystatic.com/iusa/e92ec2/102828576/iusa_75x75.102828576_4h16.jpg?version=0)

Nov 18, 2024


[Suzanne DuBois](https://www.etsy.com/people/suzannedubois3)

Purchased item:

[![Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry](https://i.etsystatic.com/5855353/c/2282/1812/0/278/il/47b644/1482205257/il_170x135.1482205257_rpxt.jpg)\\
\\
Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry\\
\\
$30.00\\
\\
\\
Eligible orders get 25% off](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?ref=ap-listing)

Purchased item:

[![Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry](https://i.etsystatic.com/5855353/c/2282/1812/0/278/il/47b644/1482205257/il_170x135.1482205257_rpxt.jpg)\\
\\
Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry\\
\\
$30.00\\
\\
\\
Eligible orders get 25% off](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/7a8f95/4830319908/iap_640x640.4830319908_kxoy1s8q.jpg?version=0)

5 out of 5 stars

- Ear wire:

Lever back


This earrings are so beautiful!!! They are my favorite ones right now. They are not to big or too little. Perfect size for me. 🌸✌🏼😊

Apr 18, 2023


[Mrs. Hyde](https://www.etsy.com/people/hthvnecw)

Purchased item:

[![Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry](https://i.etsystatic.com/5855353/c/2282/1812/0/278/il/47b644/1482205257/il_170x135.1482205257_rpxt.jpg)\\
\\
Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry\\
\\
$30.00\\
\\
\\
Eligible orders get 25% off](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?ref=ap-listing)

Purchased item:

[![Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry](https://i.etsystatic.com/5855353/c/2282/1812/0/278/il/47b644/1482205257/il_170x135.1482205257_rpxt.jpg)\\
\\
Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry\\
\\
$30.00\\
\\
\\
Eligible orders get 25% off](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/328a94/4591661263/iap_640x640.4591661263_nruqv1u7.jpg?version=0)

3 out of 5 stars

- Ear wire:

Hook (as shown)


I was disappointed with this product and ended up returning the earrings. The layers aren't different colors as shown in the listing, and there isn't any texture to them. They seem well made but are just a flat brass color.

![](https://i.etsystatic.com/iusa/d2bd38/61249440/iusa_75x75.61249440_s3rf.jpg?version=0)

Jan 20, 2023


[Sam](https://www.etsy.com/people/sputos)

Purchased item:

[![Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry](https://i.etsystatic.com/5855353/c/2282/1812/0/278/il/47b644/1482205257/il_170x135.1482205257_rpxt.jpg)\\
\\
Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry\\
\\
$30.00\\
\\
\\
Eligible orders get 25% off](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?ref=ap-listing)

Purchased item:

[![Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry](https://i.etsystatic.com/5855353/c/2282/1812/0/278/il/47b644/1482205257/il_170x135.1482205257_rpxt.jpg)\\
\\
Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry\\
\\
$30.00\\
\\
\\
Eligible orders get 25% off](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/2dc1d9/4840157323/iap_640x640.4840157323_dor6p4zp.jpg?version=0)

3 out of 5 stars

- Ear wire:

Lever back


Disappointed. Color was not like in the photo. They’re a drab, different color. Not at all what I was expecting. Won’t buy from this seller again.

Apr 5, 2023


[S](https://www.etsy.com/people/zxt1gvyn)

Purchased item:

[![Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry](https://i.etsystatic.com/5855353/c/2282/1812/0/278/il/47b644/1482205257/il_170x135.1482205257_rpxt.jpg)\\
\\
Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry\\
\\
$30.00\\
\\
\\
Eligible orders get 25% off](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?ref=ap-listing)

Purchased item:

[![Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry](https://i.etsystatic.com/5855353/c/2282/1812/0/278/il/47b644/1482205257/il_170x135.1482205257_rpxt.jpg)\\
\\
Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry\\
\\
$30.00\\
\\
\\
Eligible orders get 25% off](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/06b02a/4153663727/iap_640x640.4153663727_66396nx0.jpg?version=0)

3 out of 5 stars

- Ear wire:

Hook (as shown)


I’m sadly disappointed with these. The picture depicts nicely different colors.
The real deal doesn’t match my expectations from the pictured item. They “stand out” in the picture.
The real item is all the same color and consistency?! Nothing stands out.
My bad on not seeing the dimensions. These are also smaller than I expected.
I added a photo to explain.

![](https://i.etsystatic.com/iusa/230c8a/50970508/iusa_75x75.50970508_tun5.jpg?version=0)

Aug 24, 2022


[Sandy Wheeler](https://www.etsy.com/people/sandywheeler411)

Purchased item:

[![Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry](https://i.etsystatic.com/5855353/c/2282/1812/0/278/il/47b644/1482205257/il_170x135.1482205257_rpxt.jpg)\\
\\
Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry\\
\\
$30.00\\
\\
\\
Eligible orders get 25% off](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?ref=ap-listing)

Purchased item:

[![Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry](https://i.etsystatic.com/5855353/c/2282/1812/0/278/il/47b644/1482205257/il_170x135.1482205257_rpxt.jpg)\\
\\
Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry\\
\\
$30.00\\
\\
\\
Eligible orders get 25% off](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/469efa/3843550579/iap_640x640.3843550579_6r2pcdf6.jpg?version=0)

5 out of 5 stars

- Ear wire:

Lever back


I never want to take these off!!!

![](https://i.etsystatic.com/iusa/49fcb2/27885996/iusa_75x75.27885996_p4yn.jpg?version=0)

Apr 8, 2022


[teaflower3](https://www.etsy.com/people/teaflower3)

Purchased item:

[![Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry](https://i.etsystatic.com/5855353/c/2282/1812/0/278/il/47b644/1482205257/il_170x135.1482205257_rpxt.jpg)\\
\\
Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry\\
\\
$30.00\\
\\
\\
Eligible orders get 25% off](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?ref=ap-listing)

Purchased item:

[![Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry](https://i.etsystatic.com/5855353/c/2282/1812/0/278/il/47b644/1482205257/il_170x135.1482205257_rpxt.jpg)\\
\\
Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry\\
\\
$30.00\\
\\
\\
Eligible orders get 25% off](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/add9ab/3612910060/iap_640x640.3612910060_ex69zbw3.jpg?version=0)

5 out of 5 stars

- Ear wire:

Hook (as shown)


These are exquisitely detailed, very unique earrings. Great craftsmanship and creative use of materials. Instant favorites!

![](https://i.etsystatic.com/iusa/a21b2d/22323786/iusa_75x75.22323786_b2q2.jpg?version=0)

Jan 21, 2022


[Deb Burdick](https://www.etsy.com/people/deborahburdick1)

Purchased item:

[![Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry](https://i.etsystatic.com/5855353/c/2282/1812/0/278/il/47b644/1482205257/il_170x135.1482205257_rpxt.jpg)\\
\\
Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry\\
\\
$30.00\\
\\
\\
Eligible orders get 25% off](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?ref=ap-listing)

Purchased item:

[![Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry](https://i.etsystatic.com/5855353/c/2282/1812/0/278/il/47b644/1482205257/il_170x135.1482205257_rpxt.jpg)\\
\\
Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry\\
\\
$30.00\\
\\
\\
Eligible orders get 25% off](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/924c17/3591818371/iap_640x640.3591818371_3dfdd3g5.jpg?version=0)

5 out of 5 stars

- Ear wire:

Hook (as shown)


These are absolutely perfect! They are smaller than I thought they would be, I think the size is perfect. (I put them on my plugs made for earrings) I will 100% be ordering more. I love them.

![](https://i.etsystatic.com/iusa/f43c51/74674808/iusa_75x75.74674808_kjkq.jpg?version=0)

Dec 18, 2021


[Amy McDonald](https://www.etsy.com/people/amyrm12)

Purchased item:

[![Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry](https://i.etsystatic.com/5855353/c/2282/1812/0/278/il/47b644/1482205257/il_170x135.1482205257_rpxt.jpg)\\
\\
Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry\\
\\
$30.00\\
\\
\\
Eligible orders get 25% off](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?ref=ap-listing)

Purchased item:

[![Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry](https://i.etsystatic.com/5855353/c/2282/1812/0/278/il/47b644/1482205257/il_170x135.1482205257_rpxt.jpg)\\
\\
Bohemian Earrings - Dangle Boho Earrings - Brass Dangle Earrings - Boho Jewelry - Bohemian Jewelry - Ethnic Earrings - Ethnic Jewelry\\
\\
$30.00\\
\\
\\
Eligible orders get 25% off](https://www.etsy.com/listing/259856561/bohemian-earrings-dangle-boho-earrings?ref=ap-listing)