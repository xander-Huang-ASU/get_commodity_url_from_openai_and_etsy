[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/871634617/fimo-polymer-clay-plumeria-flower?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Jewelry](https://www.etsy.com/c/jewelry?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Earrings](https://www.etsy.com/c/jewelry/earrings?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Stud Earrings](https://www.etsy.com/c/jewelry/earrings/stud-earrings?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)

This shop is taking a short break.

![](https://i.etsystatic.com/6486069/r/il/680966/2679869057/il_680x540.2679869057_ggkf.jpg)

This shop is taking a short break.

[LauhalaTradingHawaii](https://www.etsy.com/shop/LauhalaTradingHawaii?ref=nla_listing_details)5 out of 5 stars(1,381)1,381 reviews

Fimo Polymer Clay Plumeria Flower Earrings, Hand Crafted in Hawaii by Lauhala Trading


$18.00

[Email me when they're back](https://www.etsy.com/shop/LauhalaTradingHawaii?ref=nla_vacation_cta) [See item details](https://www.etsy.com/listing/871634617/fimo-polymer-clay-plumeria-flower?show_sold_out_detail=1&ref=nla_listing_details)

[Email me when they're back](https://www.etsy.com/shop/LauhalaTradingHawaii?ref=nla_vacation_cta) [See item details](https://www.etsy.com/listing/871634617/fimo-polymer-clay-plumeria-flower?show_sold_out_detail=1&ref=nla_listing_details)

### Similar items on Etsy

(Results include adsLearn more
Sellers looking to grow their business and reach more interested buyers can use Etsy’s advertising platform to promote their items. You’ll see ad results based on factors like relevancy, and the amount sellers pay per click. [Learn more](https://www.etsy.com/legal/policy/search-advertisement-ranking-disclosures/899478564529).
)

- [![Handmade Red Flower Earrings: Lightweight Polymer Clay Jewelry](https://i.etsystatic.com/39421400/r/il/385f15/6459641175/il_340x270.6459641175_eh81.jpg)\\
\\
**Handmade Red Flower Earrings: Lightweight Polymer Clay Jewelry**\\
\\
ad vertisement by GizyStore\\
Advertisement from shop GizyStore\\
GizyStore\\
From shop GizyStore\\
\\
Sale Price $41.25\\
$41.25\\
\\
$55.00\\
Original Price $55.00\\
\\
\\
(25% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1808041356/handmade-red-flower-earrings-lightweight?click_key=LT20eb37500f16832781322e6eb9937de360de84ce%3A1808041356&click_sum=989d3fa3&ls=a&ref=sold_out_ad-1&pro=1&frs=1&sts=1 "Handmade Red Flower Earrings: Lightweight Polymer Clay Jewelry")





Add to Favorites


- [![Big Polymer Clay Flower Stud Earrings: Funky Abstract Jewelry](https://i.etsystatic.com/45247121/r/il/7a3e26/6405947809/il_340x270.6405947809_i5io.jpg)\\
\\
**Big Polymer Clay Flower Stud Earrings: Funky Abstract Jewelry**\\
\\
ad vertisement by RubyxIvyJewelry\\
Advertisement from shop RubyxIvyJewelry\\
RubyxIvyJewelry\\
From shop RubyxIvyJewelry\\
\\
$32.00\\
\\
FREE shipping](https://www.etsy.com/listing/1797245058/big-polymer-clay-flower-stud-earrings?click_key=LT580aa63c73fe63ad1238c77159600b36b2ea7002%3A1797245058&click_sum=b4238523&ls=a&ref=sold_out_ad-2&frs=1 "Big Polymer Clay Flower Stud Earrings: Funky Abstract Jewelry")





Add to Favorites


- [![Pastel Floral Polymer Clay Earrings: Lightweight Stainless Steel Studs](https://i.etsystatic.com/49820847/c/1222/1222/525/1085/il/b5d717/7071716757/il_340x270.7071716757_by9c.jpg)\\
\\
**Pastel Floral Polymer Clay Earrings: Lightweight Stainless Steel Studs**\\
\\
ad vertisement by Oncedesign11\\
Advertisement from shop Oncedesign11\\
Oncedesign11\\
From shop Oncedesign11\\
\\
$24.30](https://www.etsy.com/listing/4337125221/pastel-floral-polymer-clay-earrings?click_key=LTa46c374c365589f80e7818f56f1b98e7452fcbf7%3A4337125221&click_sum=d20a3dfb&ls=a&ref=sold_out_ad-3 "Pastel Floral Polymer Clay Earrings: Lightweight Stainless Steel Studs")





Add to Favorites


- [![14k Gold Plumeria Stud Earrings: Hawaiian Flower Jewelry](https://i.etsystatic.com/49267464/r/il/95fecf/6490593313/il_340x270.6490593313_9spq.jpg)\\
\\
**14k Gold Plumeria Stud Earrings: Hawaiian Flower Jewelry**\\
\\
ad vertisement by NoxJewelryArt\\
Advertisement from shop NoxJewelryArt\\
NoxJewelryArt\\
From shop NoxJewelryArt\\
\\
Sale Price $52.00\\
$52.00\\
\\
$65.00\\
Original Price $65.00\\
\\
\\
(20% off)](https://www.etsy.com/listing/1828628499/14k-gold-plumeria-stud-earrings-hawaiian?click_key=LTeb963248322bf42e4756925af9eb73d59d5b0c87%3A1828628499&click_sum=4a0d8a77&ls=a&ref=sold_out_ad-4&pro=1 "14k Gold Plumeria Stud Earrings: Hawaiian Flower Jewelry")





Add to Favorites


- [![Red Bow Stud Earrings: Christmas Earrings, Holiday Bow Studs, Polymer Clay Romantic Jewelry, Gift for Her](https://i.etsystatic.com/47458861/r/il/fe5e3b/6463772034/il_340x270.6463772034_dqvq.jpg)\\
\\
**Red Bow Stud Earrings: Christmas Earrings, Holiday Bow Studs, Polymer Clay Romantic Jewelry, Gift for Her**\\
\\
ad vertisement by TettyArt\\
Advertisement from shop TettyArt\\
TettyArt\\
From shop TettyArt\\
\\
$34.00\\
\\
FREE shipping](https://www.etsy.com/listing/1833192315/red-bow-stud-earrings-christmas-earrings?click_key=LTdae4f23e9c0729632a494a52a3a5cf92e3aa683c%3A1833192315&click_sum=0ac4e87a&ls=a&ref=sold_out_ad-5&frs=1&sts=1 "Red Bow Stud Earrings: Christmas Earrings, Holiday Bow Studs, Polymer Clay Romantic Jewelry, Gift for Her")





Add to Favorites


- [![Quadrant Polymer Clay Stud Earrings: Bold Geometric Suede Fringe](https://i.etsystatic.com/53261789/c/1418/1418/479/270/il/9b26c6/7348709048/il_340x270.7348709048_ao1x.jpg)\\
\\
**Quadrant Polymer Clay Stud Earrings: Bold Geometric Suede Fringe**\\
\\
ad vertisement by MoomooClayGR\\
Advertisement from shop MoomooClayGR\\
MoomooClayGR\\
From shop MoomooClayGR\\
\\
Sale Price $33.69\\
$33.69\\
\\
$37.43\\
Original Price $37.43\\
\\
\\
(10% off)](https://www.etsy.com/listing/1776587885/quadrant-polymer-clay-stud-earrings-bold?click_key=LTb04c8f143467e8c9f5d29b2df15a1ad46371bfc3%3A1776587885&click_sum=e9ca6f38&ls=a&ref=sold_out_ad-6&pro=1&sts=1 "Quadrant Polymer Clay Stud Earrings: Bold Geometric Suede Fringe")





Add to Favorites


- [![White Gardenia Hard Enamel Pin- 1.25 inches, White Flower, Botanical, Garden, Plant Lover Gift](https://i.etsystatic.com/55739608/r/il/155aa8/6786609394/il_340x270.6786609394_lquu.jpg)\\
\\
**White Gardenia Hard Enamel Pin- 1.25 inches, White Flower, Botanical, Garden, Plant Lover Gift**\\
\\
ad vertisement by JunipersForge\\
Advertisement from shop JunipersForge\\
JunipersForge\\
From shop JunipersForge\\
\\
$9.00\\
\\
Free shipping eligible](https://www.etsy.com/listing/1871432289/white-gardenia-hard-enamel-pin-125?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALT78d2cb236c5414b63b80c44d6b637d41aea6bbe8&click_sum=38ecde37&ls=r&ref=sold_out-1&frs=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALT78d2cb236c5414b63b80c44d6b637d41aea6bbe8 "White Gardenia Hard Enamel Pin- 1.25 inches, White Flower, Botanical, Garden, Plant Lover Gift")





Add to Favorites


- [![Colorful Plumeria Flower Stud Earrings | Plastic & Stainless Steel Available](https://i.etsystatic.com/8495275/r/il/0af07c/7314507634/il_340x270.7314507634_4jqi.jpg)\\
\\
**Colorful Plumeria Flower Stud Earrings \| Plastic & Stainless Steel Available**\\
\\
ad vertisement by NotoriousNikkiArt\\
Advertisement from shop NotoriousNikkiArt\\
NotoriousNikkiArt\\
From shop NotoriousNikkiArt\\
\\
$12.00\\
\\
Free shipping eligible](https://www.etsy.com/listing/904812686/colorful-plumeria-flower-stud-earrings?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALTa60e8ad16d1f2641ff5ba44bce5c14c3a77d724a&click_sum=0d33304a&ls=r&ref=sold_out-2&frs=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALTa60e8ad16d1f2641ff5ba44bce5c14c3a77d724a "Colorful Plumeria Flower Stud Earrings | Plastic & Stainless Steel Available")





Add to Favorites


- [![White Gardenia Earrings, White Flower Earrings, White Bridal Earrings, White Wedding Jewelry, Gardenia Jewelry](https://i.etsystatic.com/6610822/r/il/74abaa/556836867/il_340x270.556836867_oovd.jpg)\\
\\
**White Gardenia Earrings, White Flower Earrings, White Bridal Earrings, White Wedding Jewelry, Gardenia Jewelry**\\
\\
ad vertisement by MorningHeirloom\\
Advertisement from shop MorningHeirloom\\
MorningHeirloom\\
From shop MorningHeirloom\\
\\
$25.00\\
\\
Free shipping eligible](https://www.etsy.com/listing/98510684/white-gardenia-earrings-white-flower?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALT4b880accae129216d2cea0e529d6089aa4f69607&click_sum=cc01ffc7&ls=r&ref=sold_out-3&frs=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALT4b880accae129216d2cea0e529d6089aa4f69607 "White Gardenia Earrings, White Flower Earrings, White Bridal Earrings, White Wedding Jewelry, Gardenia Jewelry")





Add to Favorites


- [![Handmade Gardenia Stud Earrings: Polymer Clay Flower, Hypoallergenic Titanium](https://i.etsystatic.com/5240903/r/il/437b62/6624009853/il_340x270.6624009853_s6x8.jpg)\\
\\
**Handmade Gardenia Stud Earrings: Polymer Clay Flower, Hypoallergenic Titanium**\\
\\
ad vertisement by StrandedTreasures\\
Advertisement from shop StrandedTreasures\\
StrandedTreasures\\
From shop StrandedTreasures\\
\\
$26.00\\
\\
Free shipping eligible](https://www.etsy.com/listing/159900996/handmade-gardenia-stud-earrings-polymer?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALT055c371e46b93b928ba93651a1acb8c2f0bb0369&click_sum=308eecdc&ls=r&ref=sold_out-4&frs=1&sts=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALT055c371e46b93b928ba93651a1acb8c2f0bb0369 "Handmade Gardenia Stud Earrings: Polymer Clay Flower, Hypoallergenic Titanium")





Add to Favorites


- [![Gardenia Flower Stud Earrings: White Cold Porcelain Floral Jewelry](https://i.etsystatic.com/35014948/r/il/62d611/5586112572/il_340x270.5586112572_j9wg.jpg)\\
\\
**Gardenia Flower Stud Earrings: White Cold Porcelain Floral Jewelry**\\
\\
ad vertisement by MaPetiteFeeGift\\
Advertisement from shop MaPetiteFeeGift\\
MaPetiteFeeGift\\
From shop MaPetiteFeeGift\\
\\
Sale Price $36.07\\
$36.07\\
\\
$43.99\\
Original Price $43.99\\
\\
\\
(18% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1606419336/gardenia-flower-stud-earrings-white-cold?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALTa8d82d999f12fb3f37662fcd77b4baa05ca9d3a0&click_sum=ce0e85c5&ls=r&ref=sold_out-5&pro=1&frs=1&sts=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALTa8d82d999f12fb3f37662fcd77b4baa05ca9d3a0 "Gardenia Flower Stud Earrings: White Cold Porcelain Floral Jewelry")





Add to Favorites


- [![50 Hand-Painted Clay Pakalana Flowers: Yellow-Green Lei Making Supplies](https://i.etsystatic.com/47584387/r/il/cc0566/7076316729/il_340x270.7076316729_fow8.jpg)\\
\\
**50 Hand-Painted Clay Pakalana Flowers: Yellow-Green Lei Making Supplies**\\
\\
ad vertisement by Moon11atelier\\
Advertisement from shop Moon11atelier\\
Moon11atelier\\
From shop Moon11atelier\\
\\
Sale Price $40.50\\
$40.50\\
\\
$45.00\\
Original Price $45.00\\
\\
\\
(10% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/4337069567/50-hand-painted-clay-pakalana-flowers?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALT642dd9636136b7b8a447ed2d749b8dbad8870828&click_sum=66eee5f2&ls=r&ref=sold_out-6&pro=1&frs=1&sts=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALT642dd9636136b7b8a447ed2d749b8dbad8870828 "50 Hand-Painted Clay Pakalana Flowers: Yellow-Green Lei Making Supplies")





Add to Favorites


- [![Plumeria Earrings, Hawaiian Earrings, Flower Earrings, Plumeria jewelry, Hawaiian jewelry, Frangipani Earrings, Made In Hawaii, Plumeria](https://i.etsystatic.com/17594697/r/il/37c534/3021832842/il_340x270.3021832842_8ktj.jpg)\\
\\
**Plumeria Earrings, Hawaiian Earrings, Flower Earrings, Plumeria jewelry, Hawaiian jewelry, Frangipani Earrings, Made In Hawaii, Plumeria**\\
\\
ad vertisement by MauiJewelryDesign\\
Advertisement from shop MauiJewelryDesign\\
MauiJewelryDesign\\
From shop MauiJewelryDesign\\
\\
$29.99\\
\\
Free shipping eligible](https://www.etsy.com/listing/791072172/plumeria-earrings-hawaiian-earrings?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALT5d8412d46f041ee087e7b01c3f3b28003af5e7e1&click_sum=f39178b1&ls=r&ref=sold_out-7&frs=1&sts=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALT5d8412d46f041ee087e7b01c3f3b28003af5e7e1 "Plumeria Earrings, Hawaiian Earrings, Flower Earrings, Plumeria jewelry, Hawaiian jewelry, Frangipani Earrings, Made In Hawaii, Plumeria")





Add to Favorites


- [![50PCS 3Size 10Color Foam Artificial Plumeria Frangipani Flower For DIY Beach Wedding Party Hirclip Hairpin Ear Flower Hawaiian Wreath Making](https://i.etsystatic.com/17907123/r/il/068d5d/5075572016/il_340x270.5075572016_39kh.jpg)\\
\\
**50PCS 3Size 10Color Foam Artificial Plumeria Frangipani Flower For DIY Beach Wedding Party Hirclip Hairpin Ear Flower Hawaiian Wreath Making**\\
\\
ad vertisement by inpasture\\
Advertisement from shop inpasture\\
inpasture\\
From shop inpasture\\
\\
Sale Price $14.84\\
$14.84\\
\\
$19.79\\
Original Price $19.79\\
\\
\\
(25% off)\\
\\
\\
\\
Free shipping eligible](https://www.etsy.com/listing/1520343379/50pcs-3size-10color-foam-artificial?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALTa0f08a689c30995956fb2deb423eb9f6b09e1209&click_sum=8daaa282&ls=r&ref=sold_out-8&pro=1&frs=1&sts=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALTa0f08a689c30995956fb2deb423eb9f6b09e1209 "50PCS 3Size 10Color Foam Artificial Plumeria Frangipani Flower For DIY Beach Wedding Party Hirclip Hairpin Ear Flower Hawaiian Wreath Making")





Add to Favorites


- [![Dainty Plumeria Flower Earrings: Oxidized Sterling Silver Studs](https://i.etsystatic.com/32096895/c/2171/1725/463/0/il/cf4a81/5944700212/il_340x270.5944700212_wna0.jpg)\\
\\
**Dainty Plumeria Flower Earrings: Oxidized Sterling Silver Studs**\\
\\
ad vertisement by ZOOWELAND\\
Advertisement from shop ZOOWELAND\\
ZOOWELAND\\
From shop ZOOWELAND\\
\\
Sale Price $17.76\\
$17.76\\
\\
$20.89\\
Original Price $20.89\\
\\
\\
(15% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1706580312/dainty-plumeria-flower-earrings-oxidized?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALT8f7259a33dc49c9e621e5892e75f3172251df4c3&click_sum=c160b057&ls=r&ref=sold_out-9&pro=1&frs=1&sts=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALT8f7259a33dc49c9e621e5892e75f3172251df4c3 "Dainty Plumeria Flower Earrings: Oxidized Sterling Silver Studs")





Add to Favorites


- [![Monstera Leaf Polymer Clay Hoop Earrings: Tropical Boho Jewelry](https://i.etsystatic.com/34883736/r/il/133527/6077977395/il_340x270.6077977395_gnxc.jpg)\\
\\
**Monstera Leaf Polymer Clay Hoop Earrings: Tropical Boho Jewelry**\\
\\
ad vertisement by MeRelleClayDesigns\\
Advertisement from shop MeRelleClayDesigns\\
MeRelleClayDesigns\\
From shop MeRelleClayDesigns\\
\\
Sale Price $9.00\\
$9.00\\
\\
$15.00\\
Original Price $15.00\\
\\
\\
(40% off)\\
\\
\\
\\
Free shipping eligible](https://www.etsy.com/listing/1726357234/monstera-leaf-polymer-clay-hoop-earrings?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALTc77fc628409039b3630c3aaea837ed3d29111694&click_sum=80e76adc&ls=r&ref=sold_out-10&pro=1&frs=1&sts=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALTc77fc628409039b3630c3aaea837ed3d29111694 "Monstera Leaf Polymer Clay Hoop Earrings: Tropical Boho Jewelry")





Add to Favorites


- [![Medium Pink Hibiscus Hoops- Tropical Flower -Artisan Crafted Earrings. Statement Earrings. Handmade gift. Lightweight. Hypoallergenic.](https://i.etsystatic.com/8109261/c/2250/1790/0/813/il/5a42cc/4780621151/il_340x270.4780621151_rusp.jpg)\\
\\
**Medium Pink Hibiscus Hoops- Tropical Flower -Artisan Crafted Earrings. Statement Earrings. Handmade gift. Lightweight. Hypoallergenic.**\\
\\
ad vertisement by BrownPina\\
Advertisement from shop BrownPina\\
BrownPina\\
From shop BrownPina\\
\\
$15.00\\
\\
Free shipping eligible](https://www.etsy.com/listing/1426449948/medium-pink-hibiscus-hoops-tropical?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALT7f5426fee7b9c2325c2ffcf56e024c29aa201cd5&click_sum=b0a762a0&ls=r&ref=sold_out-11&frs=1&sts=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALT7f5426fee7b9c2325c2ffcf56e024c29aa201cd5 "Medium Pink Hibiscus Hoops- Tropical Flower -Artisan Crafted Earrings. Statement Earrings. Handmade gift. Lightweight. Hypoallergenic.")





Add to Favorites


- [![Bridal Earrings with White Flowers, Flowers Wedding Earrings, Boho Bridal Earrings, Boho Chic Accessories,Statement Earrings](https://i.etsystatic.com/12974720/c/2453/1947/0/733/il/288282/6252110801/il_340x270.6252110801_m0jp.jpg)\\
\\
**Bridal Earrings with White Flowers, Flowers Wedding Earrings, Boho Bridal Earrings, Boho Chic Accessories,Statement Earrings**\\
\\
ad vertisement by VsFilipchenko\\
Advertisement from shop VsFilipchenko\\
VsFilipchenko\\
From shop VsFilipchenko\\
\\
Sale Price $29.25\\
$29.25\\
\\
$39.00\\
Original Price $39.00\\
\\
\\
(25% off)](https://www.etsy.com/listing/1698872022/bridal-earrings-with-white-flowers?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALT0ae6b0305435b1ecf65c488de47ae3daea38f957&click_sum=609dc709&ls=r&ref=sold_out-12&pro=1&sts=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALT0ae6b0305435b1ecf65c488de47ae3daea38f957 "Bridal Earrings with White Flowers, Flowers Wedding Earrings, Boho Bridal Earrings, Boho Chic Accessories,Statement Earrings")





Add to Favorites


- [![Crochet Frangipani: Handmade Tropical Plumeria Flower, Home Decor](https://i.etsystatic.com/50423785/r/il/4310df/6803867403/il_340x270.6803867403_lxqy.jpg)\\
\\
**Crochet Frangipani: Handmade Tropical Plumeria Flower, Home Decor**\\
\\
ad vertisement by LittleForestCityArts\\
Advertisement from shop LittleForestCityArts\\
LittleForestCityArts\\
From shop LittleForestCityArts\\
\\
Sale Price $18.65\\
$18.65\\
\\
$20.72\\
Original Price $20.72\\
\\
\\
(10% off)\\
\\
\\
\\
Free shipping eligible](https://www.etsy.com/listing/1878076560/crochet-frangipani-handmade-tropical?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALTb699a9f8216f68c128980281c705b0f243cdf66f&click_sum=2d18f6d0&ls=r&ref=sold_out-13&pro=1&frs=1&sts=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALTb699a9f8216f68c128980281c705b0f243cdf66f "Crochet Frangipani: Handmade Tropical Plumeria Flower, Home Decor")





Add to Favorites


- [![Hawaiian Plumeria Flowers Small Hoop Hamilton Gold Earring](https://i.etsystatic.com/7313971/c/772/772/325/162/il/e87f24/6587568441/il_340x270.6587568441_95vi.jpg)\\
\\
**Hawaiian Plumeria Flowers Small Hoop Hamilton Gold Earring**\\
\\
ad vertisement by AnelasJewerly\\
Advertisement from shop AnelasJewerly\\
AnelasJewerly\\
From shop AnelasJewerly\\
\\
$10.00\\
\\
Free shipping eligible](https://www.etsy.com/listing/1838372998/hawaiian-plumeria-flowers-small-hoop?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALT847b223458c3b4961861af66f5c0d81310f25d37&click_sum=458d0259&ls=r&ref=sold_out-14&frs=1&sts=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALT847b223458c3b4961861af66f5c0d81310f25d37 "Hawaiian Plumeria Flowers Small Hoop Hamilton Gold Earring")





Add to Favorites


- [![WESTERN GERMANY White Hibiscus Earrings - Floral Earrings](https://i.etsystatic.com/23039038/c/2884/2302/98/346/il/32f6b5/3668368233/il_340x270.3668368233_l9h2.jpg)\\
\\
**WESTERN GERMANY White Hibiscus Earrings - Floral Earrings**\\
\\
ad vertisement by PalomaAndBianca\\
Advertisement from shop PalomaAndBianca\\
PalomaAndBianca\\
From shop PalomaAndBianca\\
\\
$39.00\\
\\
FREE shipping](https://www.etsy.com/listing/1150151500/western-germany-white-hibiscus-earrings?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALT60a651d1309ddb46a01850816141e91dcd0134f4&click_sum=1e9318e6&ls=r&ref=sold_out-15&frs=1&sts=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALT60a651d1309ddb46a01850816141e91dcd0134f4 "WESTERN GERMANY White Hibiscus Earrings - Floral Earrings")





Add to Favorites


- [![Ohia Lehua Clear Matte Waterproof Sticker Decal Transparent](https://i.etsystatic.com/33071826/r/il/bc72de/6141551034/il_340x270.6141551034_de9a.jpg)\\
\\
**Ohia Lehua Clear Matte Waterproof Sticker Decal Transparent**\\
\\
ad vertisement by NiksNaksHI\\
Advertisement from shop NiksNaksHI\\
NiksNaksHI\\
From shop NiksNaksHI\\
\\
$4.99\\
\\
FREE shipping](https://www.etsy.com/listing/1765692081/ohia-lehua-clear-matte-waterproof?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALTb9b27366c1c5cfdda3b18e53cb6d0c7b582dbb5c&click_sum=200d3032&ls=r&ref=sold_out-16&frs=1&sts=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALTb9b27366c1c5cfdda3b18e53cb6d0c7b582dbb5c "Ohia Lehua Clear Matte Waterproof Sticker Decal Transparent")





Add to Favorites


- [![Hawaii Earring, Shell Flower Earring, Shell Earring, Shell Stud, Shell Earring, Flower Stud, Shell Stud, Shell Flower Stud, Delicate Stud](https://i.etsystatic.com/10691624/r/il/58e4e5/2399902778/il_340x270.2399902778_d7ew.jpg)\\
\\
**Hawaii Earring, Shell Flower Earring, Shell Earring, Shell Stud, Shell Earring, Flower Stud, Shell Stud, Shell Flower Stud, Delicate Stud**\\
\\
ad vertisement by FabFinds42\\
Advertisement from shop FabFinds42\\
FabFinds42\\
From shop FabFinds42\\
\\
$20.00\\
\\
Free shipping eligible](https://www.etsy.com/listing/796102633/hawaii-earring-shell-flower-earring?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALTfcee655577b249cbd314fd74a17a284f7a6508e2&click_sum=f0e7b8d5&ls=r&ref=sold_out-17&frs=1&sts=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALTfcee655577b249cbd314fd74a17a284f7a6508e2 "Hawaii Earring, Shell Flower Earring, Shell Earring, Shell Stud, Shell Earring, Flower Stud, Shell Stud, Shell Flower Stud, Delicate Stud")





Add to Favorites


- [![925 Sterling Silver, 14K Gold Plated Plumeria Stud Earrings For Women. Hawaiian Island Heritage, Tropical Flower Jewelry. Gift For Her.](https://i.etsystatic.com/23756823/c/2383/1894/254/539/il/dc0976/4115644626/il_340x270.4115644626_8gzs.jpg)\\
\\
**925 Sterling Silver, 14K Gold Plated Plumeria Stud Earrings For Women. Hawaiian Island Heritage, Tropical Flower Jewelry. Gift For Her.**\\
\\
ad vertisement by CreationsOfHawaii\\
Advertisement from shop CreationsOfHawaii\\
CreationsOfHawaii\\
From shop CreationsOfHawaii\\
\\
$26.39\\
\\
Eligible orders get 15% off\\
\\
\\
Buy 2 items and get 15% off your order\\
\\
\\
Free shipping eligible](https://www.etsy.com/listing/870919246/925-sterling-silver-14k-gold-plated?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALT10ae4bb64c5bae63432e111ea95f0db98212188c&click_sum=342d5c55&ls=r&ref=sold_out-18&pro=1&frs=1&sts=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALT10ae4bb64c5bae63432e111ea95f0db98212188c "925 Sterling Silver, 14K Gold Plated Plumeria Stud Earrings For Women. Hawaiian Island Heritage, Tropical Flower Jewelry. Gift For Her.")





Add to Favorites


- [![Miniature Marigold Stud Earrings: Orange Polymer Clay Flower](https://i.etsystatic.com/47494688/r/il/585508/6667809175/il_340x270.6667809175_9dou.jpg)\\
\\
**Miniature Marigold Stud Earrings: Orange Polymer Clay Flower**\\
\\
ad vertisement by JewelryByAntonya\\
Advertisement from shop JewelryByAntonya\\
JewelryByAntonya\\
From shop JewelryByAntonya\\
\\
$31.00](https://www.etsy.com/listing/1869271019/miniature-marigold-stud-earrings-orange?click_key=LTdabf8a9504def0e32cd74e2fba9bfc7c6757b115%3A1869271019&click_sum=641a32ae&ls=a&ref=sold_out_ad-7 "Miniature Marigold Stud Earrings: Orange Polymer Clay Flower")





Add to Favorites


- [![Red poinsettia studs Christmas earrings polymer clay stud, holiday earrings xmas flower studs, small red earrings festive gifts](https://i.etsystatic.com/45059318/r/il/35677e/6479818645/il_340x270.6479818645_a9yb.jpg)\\
\\
**Red poinsettia studs Christmas earrings polymer clay stud, holiday earrings xmas flower studs, small red earrings festive gifts**\\
\\
ad vertisement by NadiaBloomJewellery\\
Advertisement from shop NadiaBloomJewellery\\
NadiaBloomJewellery\\
From shop NadiaBloomJewellery\\
\\
$28.83](https://www.etsy.com/listing/1821700985/red-poinsettia-studs-christmas-earrings?click_key=LT0b40b2650286256f04f9a98576701f55c7aa77f9%3A1821700985&click_sum=d8755cb4&ls=a&ref=sold_out_ad-8&sts=1 "Red poinsettia studs Christmas earrings polymer clay stud, holiday earrings xmas flower studs, small red earrings festive gifts")





Add to Favorites


- [![Florecitas: Tiny Flower Stud Earrings- Polymer Clay | Handmade Jewelry | Gifts for her](https://i.etsystatic.com/9464453/r/il/984906/6849005289/il_340x270.6849005289_q78y.jpg)\\
\\
**Florecitas: Tiny Flower Stud Earrings- Polymer Clay \| Handmade Jewelry \| Gifts for her**\\
\\
ad vertisement by Cositashtx\\
Advertisement from shop Cositashtx\\
Cositashtx\\
From shop Cositashtx\\
\\
$20.00\\
\\
Free shipping eligible](https://www.etsy.com/listing/1447424052/florecitas-tiny-flower-stud-earrings?click_key=LT9b929e648d6b33a0dfe90b6266052db2756f3bb2%3A1447424052&click_sum=5d662fc7&ls=a&ref=sold_out_ad-9&frs=1&sts=1 "Florecitas: Tiny Flower Stud Earrings- Polymer Clay | Handmade Jewelry | Gifts for her")





Add to Favorites


- [![Handmade Poinsettia Stud Earrings – Polymer Clay Christmas Flower Jewelry](https://i.etsystatic.com/40652167/r/il/143449/7402411613/il_340x270.7402411613_em2w.jpg)\\
\\
**Handmade Poinsettia Stud Earrings – Polymer Clay Christmas Flower Jewelry**\\
\\
ad vertisement by LeonasStudio7\\
Advertisement from shop LeonasStudio7\\
LeonasStudio7\\
From shop LeonasStudio7\\
\\
$34.09](https://www.etsy.com/listing/4398192449/handmade-poinsettia-stud-earrings?click_key=LTe6eb295db8cc30ce959c92899583c8ecc4dcd910%3A4398192449&click_sum=ea784d9d&ls=a&ref=sold_out_ad-10 "Handmade Poinsettia Stud Earrings – Polymer Clay Christmas Flower Jewelry")





Add to Favorites


- [![Blush Peony Stud Earrings, Polymer Clay Flower, Titanium](https://i.etsystatic.com/12579132/c/1991/1991/463/158/il/bcf286/7414487437/il_340x270.7414487437_zji8.jpg)\\
\\
**Blush Peony Stud Earrings, Polymer Clay Flower, Titanium**\\
\\
ad vertisement by Brlogarka\\
Advertisement from shop Brlogarka\\
Brlogarka\\
From shop Brlogarka\\
\\
Sale Price $22.45\\
$22.45\\
\\
$24.95\\
Original Price $24.95\\
\\
\\
(10% off)](https://www.etsy.com/listing/1249792394/blush-peony-stud-earrings-polymer-clay?click_key=LT496ecf7700d4d1d48d65232bc1063e18b0ab3dc5%3A1249792394&click_sum=fc0c8ee4&ls=a&ref=sold_out_ad-11&pro=1&sts=1 "Blush Peony Stud Earrings, Polymer Clay Flower, Titanium")





Add to Favorites


- [![Handmade Christmas Stud Earrings: Polymer Clay Holly Berries](https://i.etsystatic.com/25841578/c/1553/1553/454/46/il/2ed070/7324742577/il_340x270.7324742577_ojlb.jpg)\\
\\
**Handmade Christmas Stud Earrings: Polymer Clay Holly Berries**\\
\\
ad vertisement by KarmelArt\\
Advertisement from shop KarmelArt\\
KarmelArt\\
From shop KarmelArt\\
\\
$24.51\\
\\
Free shipping eligible](https://www.etsy.com/listing/4385204067/handmade-christmas-stud-earrings-polymer?click_key=LT779bead276eb8cc88c26f4c194977257b7090ee9%3A4385204067&click_sum=3ae29e07&ls=a&ref=sold_out_ad-12&frs=1 "Handmade Christmas Stud Earrings: Polymer Clay Holly Berries")





Add to Favorites


- [![Life-Like Green Pakalana Clay Flowers for Jewelry Making, Gradient Light Green Flowers / DIY Flowers, Handcrafted Clay Beads](https://i.etsystatic.com/20241747/r/il/764761/6490271257/il_340x270.6490271257_tqn3.jpg)\\
\\
**Life-Like Green Pakalana Clay Flowers for Jewelry Making, Gradient Light Green Flowers / DIY Flowers, Handcrafted Clay Beads**\\
\\
ad vertisement by SeasideAveCo\\
Advertisement from shop SeasideAveCo\\
SeasideAveCo\\
From shop SeasideAveCo\\
\\
Sale Price $14.98\\
$14.98\\
\\
$18.72\\
Original Price $18.72\\
\\
\\
(20% off)\\
\\
\\
\\
Free shipping eligible](https://www.etsy.com/listing/1828552331/life-like-green-pakalana-clay-flowers?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALT944220c1b3fecd766708a144f602f9c9270710c9&click_sum=a92f4686&ls=r&ref=sold_out-19&pro=1&frs=1&sts=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALT944220c1b3fecd766708a144f602f9c9270710c9 "Life-Like Green Pakalana Clay Flowers for Jewelry Making, Gradient Light Green Flowers / DIY Flowers, Handcrafted Clay Beads")





Add to Favorites


- [![Plumeria Earrings, White Floral Stud Earrings, Cute Hawaii Nature Fashion Accessory, Kawaii Flower Lover Gift, Tiny Travel Vacation Present](https://i.etsystatic.com/24136210/r/il/347cba/7065965483/il_340x270.7065965483_s2ii.jpg)\\
\\
**Plumeria Earrings, White Floral Stud Earrings, Cute Hawaii Nature Fashion Accessory, Kawaii Flower Lover Gift, Tiny Travel Vacation Present**\\
\\
ad vertisement by suncharmstudio\\
Advertisement from shop suncharmstudio\\
suncharmstudio\\
From shop suncharmstudio\\
\\
$9.90\\
\\
Free shipping eligible](https://www.etsy.com/listing/1670288045/plumeria-earrings-white-floral-stud?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALT18b78eb6b0759c9321caa035ff533ca420b41ea5&click_sum=c4b7286a&ls=r&ref=sold_out-20&frs=1&sts=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALT18b78eb6b0759c9321caa035ff533ca420b41ea5 "Plumeria Earrings, White Floral Stud Earrings, Cute Hawaii Nature Fashion Accessory, Kawaii Flower Lover Gift, Tiny Travel Vacation Present")





Add to Favorites


- [![Plumeria flower clay earrings, Hawaiian flower earrings, floral stud earrings, minimalist earrings, pink flower earrings,  hypoallergenic](https://i.etsystatic.com/29457760/r/il/b92770/7067128766/il_340x270.7067128766_5v3q.jpg)\\
\\
**Plumeria flower clay earrings, Hawaiian flower earrings, floral stud earrings, minimalist earrings, pink flower earrings, hypoallergenic**\\
\\
ad vertisement by ClaySymphony\\
Advertisement from shop ClaySymphony\\
ClaySymphony\\
From shop ClaySymphony\\
\\
$22.00\\
\\
FREE shipping](https://www.etsy.com/listing/4343462821/plumeria-flower-clay-earrings-hawaiian?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALTe67f2781a432c99aeab37b517004d5394aa4ae0f&click_sum=bb33358a&ls=r&ref=sold_out-21&frs=1&sts=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALTe67f2781a432c99aeab37b517004d5394aa4ae0f "Plumeria flower clay earrings, Hawaiian flower earrings, floral stud earrings, minimalist earrings, pink flower earrings,  hypoallergenic")





Add to Favorites


- [![Gift for her White gardenia flower Gold hoops Hawaiian Bridal floral jewelry Bridesmaids Tropical flower wedding Birthday Mothers Day gift](https://i.etsystatic.com/9713477/r/il/1dda08/5815136527/il_340x270.5815136527_6r95.jpg)\\
\\
**Gift for her White gardenia flower Gold hoops Hawaiian Bridal floral jewelry Bridesmaids Tropical flower wedding Birthday Mothers Day gift**\\
\\
ad vertisement by morecolors\\
Advertisement from shop morecolors\\
morecolors\\
From shop morecolors\\
\\
$25.00\\
\\
FREE shipping](https://www.etsy.com/listing/1665521972/gift-for-her-white-gardenia-flower-gold?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALT378697bc9ad0cde0b071973b5ca14d9df71480bc&click_sum=0a9e73c0&ls=r&ref=sold_out-22&frs=1&sts=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALT378697bc9ad0cde0b071973b5ca14d9df71480bc "Gift for her White gardenia flower Gold hoops Hawaiian Bridal floral jewelry Bridesmaids Tropical flower wedding Birthday Mothers Day gift")





Add to Favorites


- [![Porcelain Blue Forget Me Not Earrings, Sterling Silver Hooks, Swarovski Crystal](https://i.etsystatic.com/13146546/r/il/8c52cd/4890743906/il_340x270.4890743906_nkwf.jpg)\\
\\
**Porcelain Blue Forget Me Not Earrings, Sterling Silver Hooks, Swarovski Crystal**\\
\\
ad vertisement by HopSkipAndFlutter\\
Advertisement from shop HopSkipAndFlutter\\
HopSkipAndFlutter\\
From shop HopSkipAndFlutter\\
\\
$39.81](https://www.etsy.com/listing/594700450/porcelain-blue-forget-me-not-earrings?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALT97ca6f390d880280c4e70d464d96f5244882aef5&click_sum=5f667c10&ls=r&ref=sold_out-23&sts=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALT97ca6f390d880280c4e70d464d96f5244882aef5 "Porcelain Blue Forget Me Not Earrings, Sterling Silver Hooks, Swarovski Crystal")





Add to Favorites


- [![Gardenia Earrings, Dainty Earrings,  Zircon Earrings, Bridal Earrings](https://i.etsystatic.com/5415062/r/il/e74da1/3683368350/il_340x270.3683368350_kqfz.jpg)\\
\\
**Gardenia Earrings, Dainty Earrings, Zircon Earrings, Bridal Earrings**\\
\\
ad vertisement by ShlomitOfir\\
Advertisement from shop ShlomitOfir\\
ShlomitOfir\\
From shop ShlomitOfir\\
\\
$47.00\\
\\
FREE shipping](https://www.etsy.com/listing/1168841986/gardenia-earrings-dainty-earrings-zircon?click_key=8d1d95ee80e1a747f194b3090d35997c%3ALT636cf3ea99c12ad5b4acdcf59547924c5d676bcb&click_sum=9b0df0b3&ls=r&ref=sold_out-24&frs=1&content_source=8d1d95ee80e1a747f194b3090d35997c%253ALT636cf3ea99c12ad5b4acdcf59547924c5d676bcb "Gardenia Earrings, Dainty Earrings,  Zircon Earrings, Bridal Earrings")





Add to Favorites



[Shop more similar items](https://www.etsy.com/listing/871634617/similar?page=2&ref=sold_out_more_like_this)

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F871634617%2Ffimo-polymer-clay-plumeria-flower%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc4MDkyODphYTE3NmJmNGIxYWEyYzcxZDVkOTFkMTdkY2Q2MmY5Mw==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F871634617%2Ffimo-polymer-clay-plumeria-flower%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/871634617/fimo-polymer-clay-plumeria-flower?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F871634617%2Ffimo-polymer-clay-plumeria-flower%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done