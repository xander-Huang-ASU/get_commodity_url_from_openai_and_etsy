[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1766863531/black-and-white-polymer-clay-dangle?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Jewelry](https://www.etsy.com/c/jewelry?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Earrings](https://www.etsy.com/c/jewelry/earrings?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Dangle & Drop Earrings](https://www.etsy.com/c/jewelry/earrings/dangle-earrings?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)


Add to Favorites


- ![May include: A pair of black and white marble arch shaped earrings with silver hooks and beads.](https://i.etsystatic.com/49504253/r/il/066929/6193395489/il_794xN.6193395489_mnfn.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1766863531%2Fblack-and-white-polymer-clay-dangle%23report-overlay-trigger)

Low in stock, only 1 left

Price:$15.00


Loading


# Black and White - polymer clay dangle earrings

Made by [TheClaySmithShop](https://www.etsy.com/shop/TheClaySmithShop)

Returns & exchanges accepted

4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Made by [TheClaySmithShop](https://www.etsy.com/shop/TheClaySmithShop)

- Materials: polymer clay, clay

These unique earrings are meticulously crafted to add a touch of color to any outfit. With their lightweight and comfortable design, these earrings are perfect for everyday wear or special occasions.

All earring findings are hypoallergenic!!

The earrings are handmade with polymer clay, which is durable, but still need care to make sure they stay in the best shape.

\- Store earrings in a non-humid area, away from bathrooms.

\- Keep away from creams, perfumes, or other harmful chemicals.

\- If you do need to clean the jewelry, wipe with a damp cloth or use a Q-tip dipped in rubbing alcohol.

\- Avoid items that can scratch the surface of the clay.

\- Store them hanging to avoid damage from other sharp items.

\- Remove earrings before swimming, showering, or being in water for a long period


## Shipping and return policies

Loading


- Order today to get by

**Nov 13-25**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 30 days


- Ships from: **Madison Heights, VA**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

## Be the first to review this item

This is a unique item, and there are no reviews yet. See what customers say about other items from this shop.


Read reviews for other items


[TheClaySmithShop](https://www.etsy.com/shop/TheClaySmithShop?ref=shop_profile&listing_id=1766863531)

[Owned by Jennifer](https://www.etsy.com/shop/TheClaySmithShop?ref=shop_profile&listing_id=1766863531) \|

United States

[12 reviews](https://www.etsy.com/listing/1766863531/black-and-white-polymer-clay-dangle?utm_source=openai#reviews)

31 sales

1.5 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=887410001&referring_id=1766863531&referring_type=listing&recipient_id=887410001&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo4ODc0MTAwMDE6MTc2Mjc3OTcwOToxNGI5Y2ZmM2ZmOTE2NDE4NjcwMzdmYzZkNTdkYjIxZA%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1766863531%2Fblack-and-white-polymer-clay-dangle%3Futm_source%3Dopenai)

This seller usually responds **within a few hours.**

## All reviews from this shop (12)

Show all

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Why are these reviews shown?

All reviews are from verified buyers. Reviews are shown automatically based on factors like recency, whether they include comments, your chosen language, and whether the rating reflects the typical experience with the shop.

## More from this shop

[Visit shop](https://www.etsy.com/shop/TheClaySmithShop?ref=lp_mys_mfts)

- [![Spooky Ghost Dangles - polymer clay dangle earrings](https://i.etsystatic.com/49504253/r/il/8b8dcd/6257009574/il_340x270.6257009574_og34.jpg)\\
\\
**Spooky Ghost Dangles - polymer clay dangle earrings**\\
\\
$15.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1776614466/spooky-ghost-dangles-polymer-clay-dangle?click_key=94522b54fc404e2109f39695fe15e41a%3ALTdf9dad1f068c2879290d11fea02c164eaa7256bc&click_sum=b1b4dd92&ls=r&ref=related-1&content_source=94522b54fc404e2109f39695fe15e41a%253ALTdf9dad1f068c2879290d11fea02c164eaa7256bc "Spooky Ghost Dangles - polymer clay dangle earrings")




Add to Favorites


- [![Dangle Pencils  - polymer clay dangle earrings](https://i.etsystatic.com/49504253/r/il/c76ac5/6145262624/il_340x270.6145262624_n7s8.jpg)\\
\\
**Dangle Pencils - polymer clay dangle earrings**\\
\\
$10.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1752656052/dangle-pencils-polymer-clay-dangle?click_key=94522b54fc404e2109f39695fe15e41a%3ALT0294949447b36c6fdab36a9581586ec58aeffb73&click_sum=af4d396d&ls=r&ref=related-2&content_source=94522b54fc404e2109f39695fe15e41a%253ALT0294949447b36c6fdab36a9581586ec58aeffb73 "Dangle Pencils  - polymer clay dangle earrings")




Add to Favorites


- [![Bendy Pencils  - polymer clay dangle earrings](https://i.etsystatic.com/49504253/r/il/019716/6145266610/il_340x270.6145266610_qvvo.jpg)\\
\\
**Bendy Pencils - polymer clay dangle earrings**\\
\\
$12.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1766854419/bendy-pencils-polymer-clay-dangle?click_key=94522b54fc404e2109f39695fe15e41a%3ALT0e44ee82a688329450f91c0bc7518ab07e6ee2af&click_sum=7b112dcf&ls=r&ref=related-3&content_source=94522b54fc404e2109f39695fe15e41a%253ALT0e44ee82a688329450f91c0bc7518ab07e6ee2af "Bendy Pencils  - polymer clay dangle earrings")




Add to Favorites


- [![Red Polymer Clay Puffy Heart Dangle Earrings](https://i.etsystatic.com/49504253/r/il/0a3554/5750908409/il_340x270.5750908409_49q8.jpg)\\
\\
**Red Polymer Clay Puffy Heart Dangle Earrings**\\
\\
$10.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1650692564/red-polymer-clay-puffy-heart-dangle?click_key=ffdb74862560b85c078e760bac89ba3dba521d8e%3A1650692564&click_sum=5402303e&ref=related-4 "Red Polymer Clay Puffy Heart Dangle Earrings")




Add to Favorites



Loading...

Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Aug 20, 2025


[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Jewelry](https://www.etsy.com/c/jewelry?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Earrings](https://www.etsy.com/c/jewelry/earrings?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Dangle & Drop Earrings](https://www.etsy.com/c/jewelry/earrings/dangle-earrings?utm_source=openai&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Shopping

[Shop Christian Art, Praise](https://www.etsy.com/market/christian_art%2C_praise) [Shop Earl Daniels Art](https://www.etsy.com/market/earl_daniels_art)

Books

[The Etude Music Magazine March 1937 Johann Strauss Jr by Papergoy](https://www.etsy.com/listing/1372422440/the-etude-music-magazine-march-1937)

Rings

[Shop Lovely Rings](https://www.etsy.com/market/lovely_rings)

Earrings

[649b# - Earrings](https://www.etsy.com/listing/517060117/649b-boho-earrings-boho-victorian) [Mid-Century10 Octagon Drop Earrings - Earrings](https://www.etsy.com/listing/1869601817/mid-century10-octagon-drop-earrings) [Shop Jwk Sterling](https://www.etsy.com/market/jwk_sterling) [Buy Genuine Salmon Coral Earrings Online](https://www.etsy.com/market/genuine_salmon_coral_earrings)

Prints

[Graduation Gift for Son](https://www.etsy.com/listing/1211503877/graduation-gift-for-son-graduation-gift) [Shop Con Air Poster](https://www.etsy.com/market/con_air_poster)

Electronics Cases

[Pink Cute Clip Art Phone Case for iPhone 16 15 14 13 12 Pro Max](https://www.etsy.com/listing/1903293411/pink-cute-clip-art-phone-case-for-iphone)

Furniture

[Buy Arch Cabinet Online](https://www.etsy.com/market/arch_cabinet)

Gender Neutral Adult Clothing

[Fuck fentanyl Dealers T-shirt - Gender-Neutral Adult Clothing](https://www.etsy.com/listing/958158775/fuck-fentanyl-dealers-t-shirt)

Hats & Caps

[Chunky viral beanie by Blissfulloops](https://www.etsy.com/listing/1647834442/chunky-viral-beanie-pom-pom-beanie)

Kitchen & Dining

[Apple Knife Handle - US](https://www.etsy.com/market/apple_knife_handle)

Body Jewelry

[Handmade Pink Dream Mojave & Sterling Silver Triangle Dangle Earrings Signed Nizhoni - Body Jewelry](https://www.etsy.com/listing/1805974105/handmade-pink-dream-mojave-sterling)

Games & Puzzles

[Shop Ballerina Card Deck](https://www.etsy.com/market/ballerina_card_deck)

Paper

[Buy Playboy Decal Stickers Online](https://www.etsy.com/market/playboy_decal_stickers)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1766863531%2Fblack-and-white-polymer-clay-dangle%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc3OTcwOTo1YTU5Zjg4ZGU2YWIxNDE2OGMyZjViMTM3MTA3OWUxOQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1766863531%2Fblack-and-white-polymer-clay-dangle%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1766863531/black-and-white-polymer-clay-dangle?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1766863531%2Fblack-and-white-polymer-clay-dangle%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


Regions Etsy does business in:

[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)

[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)

[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)

[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)

[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)

[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)

[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)

[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)

[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)

[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)

[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)

[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)

[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)

[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)

[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)

[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)

[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)

[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)

[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)

[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)

[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)

[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)

[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)

[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)

[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)

[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)

[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)

Got it

Scroll previousScroll next