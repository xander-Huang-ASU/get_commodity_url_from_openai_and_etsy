[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1779603496/polymer-clay-20mm-circle-drop-earrings?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Jewelry](https://www.etsy.com/c/jewelry?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Earrings](https://www.etsy.com/c/jewelry/earrings?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Dangle & Drop Earrings](https://www.etsy.com/c/jewelry/earrings/dangle-earrings?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)


Add to Favorites


- ![May include: Five pairs of gold and colored dangle earrings. The earrings have two circles, one gold and one colored. The colors are purple, red, blue, green, and yellow.](https://i.etsystatic.com/35504385/r/il/956355/6270519176/il_794xN.6270519176_d9tj.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![May include: Five pairs of gold dangle earrings with different colored round discs. The discs are purple, burgundy, navy blue, green, and light green. The earrings are displayed on a wooden surface.](https://i.etsystatic.com/35504385/r/il/dc3932/6318572459/il_794xN.6318572459_smkk.jpg)
- ![May include: Gold and green dangle earrings with a round shape. The earrings have a gold circle on top of a larger green circle.](https://i.etsystatic.com/35504385/r/il/5e9d7e/6318593251/il_794xN.6318593251_jqhd.jpg)
- ![May include: A pair of gold and light purple dangle earrings. Each earring has a small gold circle on top of a larger light purple circle.](https://i.etsystatic.com/35504385/r/il/edd1a5/6270520020/il_794xN.6270520020_biva.jpg)
- ![May include: Gold and burgundy dangle earrings with two round discs on each earring. The top disc is gold and the bottom disc is burgundy.](https://i.etsystatic.com/35504385/r/il/acd45d/6270519362/il_794xN.6270519362_p81i.jpg)
- ![May include: A pair of gold and blue earrings. Each earring has a gold circle on top of a blue circle. The earrings are on a wooden surface.](https://i.etsystatic.com/35504385/r/il/d863d8/6318573197/il_794xN.6318573197_foak.jpg)
- ![May include: Gold and green dangle earrings with two round discs on each earring. The top disc is gold and the bottom disc is green.](https://i.etsystatic.com/35504385/r/il/2e1872/6270519820/il_794xN.6270519820_boak.jpg)
- ![May include: A pair of gold and teal dangle earrings. Each earring has a smaller teal circle and a larger gold circle. The circles are connected by a gold wire.](https://i.etsystatic.com/35504385/r/il/2d919f/6270519524/il_794xN.6270519524_gqyq.jpg)
- ![May include: A pair of gold and green dangle earrings. Each earring has a small gold circle followed by a larger green circle.](https://i.etsystatic.com/35504385/r/il/12c193/6318572925/il_794xN.6318572925_2yq0.jpg)
- ![May include: A pair of gold and green dangle earrings. Each earring has a round gold disc and a round green disc. The green discs are larger than the gold discs.](https://i.etsystatic.com/35504385/r/il/b87f4f/6318573387/il_794xN.6318573387_2ad8.jpg)

- ![May include: Five pairs of gold and colored dangle earrings. The earrings have two circles, one gold and one colored. The colors are purple, red, blue, green, and yellow.](https://i.etsystatic.com/35504385/r/il/956355/6270519176/il_75x75.6270519176_d9tj.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/file_enj6fi.jpg)

- ![May include: Five pairs of gold dangle earrings with different colored round discs. The discs are purple, burgundy, navy blue, green, and light green. The earrings are displayed on a wooden surface.](https://i.etsystatic.com/35504385/r/il/dc3932/6318572459/il_75x75.6318572459_smkk.jpg)
- ![May include: Gold and green dangle earrings with a round shape. The earrings have a gold circle on top of a larger green circle.](https://i.etsystatic.com/35504385/r/il/5e9d7e/6318593251/il_75x75.6318593251_jqhd.jpg)
- ![May include: A pair of gold and light purple dangle earrings. Each earring has a small gold circle on top of a larger light purple circle.](https://i.etsystatic.com/35504385/r/il/edd1a5/6270520020/il_75x75.6270520020_biva.jpg)
- ![May include: Gold and burgundy dangle earrings with two round discs on each earring. The top disc is gold and the bottom disc is burgundy.](https://i.etsystatic.com/35504385/r/il/acd45d/6270519362/il_75x75.6270519362_p81i.jpg)
- ![May include: A pair of gold and blue earrings. Each earring has a gold circle on top of a blue circle. The earrings are on a wooden surface.](https://i.etsystatic.com/35504385/r/il/d863d8/6318573197/il_75x75.6318573197_foak.jpg)
- ![May include: Gold and green dangle earrings with two round discs on each earring. The top disc is gold and the bottom disc is green.](https://i.etsystatic.com/35504385/r/il/2e1872/6270519820/il_75x75.6270519820_boak.jpg)
- ![May include: A pair of gold and teal dangle earrings. Each earring has a smaller teal circle and a larger gold circle. The circles are connected by a gold wire.](https://i.etsystatic.com/35504385/r/il/2d919f/6270519524/il_75x75.6270519524_gqyq.jpg)
- ![May include: A pair of gold and green dangle earrings. Each earring has a small gold circle followed by a larger green circle.](https://i.etsystatic.com/35504385/r/il/12c193/6318572925/il_75x75.6318572925_2yq0.jpg)
- ![May include: A pair of gold and green dangle earrings. Each earring has a round gold disc and a round green disc. The green discs are larger than the gold discs.](https://i.etsystatic.com/35504385/r/il/b87f4f/6318573387/il_75x75.6318573387_2ad8.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1779603496%2Fpolymer-clay-20mm-circle-drop-earrings%23report-overlay-trigger)

Low in stock, only 6 left

Price:$19.22


Loading


# Polymer Clay 20mm Circle Drop Earrings: Gold Plated Studs, Brass Charm

Made by [ClaybyClaireMcKay](https://www.etsy.com/shop/ClaybyClaireMcKay)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1779603496/polymer-clay-20mm-circle-drop-earrings?utm_source=openai#reviews)

Returns accepted

Save 20% when you buy 4 items at this shop

**Shop the sale**

Primary color


Select a color

Mauve

Berry

Purple

Chartreuse

Teal

Green

Please select a color


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Made by [ClaybyClaireMcKay](https://www.etsy.com/shop/ClaybyClaireMcKay)

- Materials: Brass, Plastic, Stainless steel

- Location: Earlobe

- Closure: Butterfly

- Style: Minimalist

- Drop length: 45 Millimeters; Width: 20 Millimeters


- Gift wrapping available

See details![](https://i.etsystatic.com/igwp/a79267/4637876299/igwp_300xN.4637876299_oz9vbni5.jpg?version=0)

Gift wrapping by ClaybyClaireMcKay

Handwritten note on handprinted mini card.

10cm x 15cm Organza Bag.

Colourful understated contemporary earrings handmade from Polymer Clay. Finished with hypoallergenic gold-plated ear posts and jump rings with solid brass textured circle charms. They are lead and nickel free.

Dimensions:

The clay circles are approximately 20mm round

The total drop including the ear hook is a total of 44mm

They are all between 2-3mm thick.

This is the large version, a smaller size is available. See last photo for comparison. I also sell versions with ear hooks instead of studs.

Handcrafted:

I handmake all of my polymer clay jewellery. I mix the colours, cut and bake the clay, sand and finish it by attaching good quality hypoallergenic findings that are lead and nickel free. I try to take accurate photographs, however please note that colours may appear different depending on your device. If you like my designs but would prefer a different colour then please drop me a message and I'll see what I can do for you.

Care and Storage:

Please care for your jewellery by storing in a clean, dry place out of direct sunlight. These items are robust, but may scratch if not handled gently. Do not submerge in water or bend the pieces as they may break. Please note that over a period of time it is possible that perfume or body lotion may affect the surface. Brass charms can tarnish over time, if this happens then a standard brass cleaner i.e. Brasso can be used to brighten and restore shine.

Packaging:

All of my jewellery is gift wrapped in my custom tissue paper and carefully packaged in letterbox friendly packaging to keep them from being damaged in transit. All packaging is recycled or recyclable.

Delivery:

Orders are sent by Royal Mail 2nd Class post in the UK and Standard International Post overseas. I always try to send within 3-5 working days, but if this is not possible then I will let you know. If you require your order urgently, then please drop me a message and, if in the UK, select the upgraded option of 1st Class Tracked. International orders can be tracked if you would like increased visibility of your order.

For my full range of earrings please go to my shop: [https://claybyclairemckay.etsy.com](https://claybyclairemckay.etsy.com/)

For my full range of original linocut prints, hand printed accessories and loads of unique gift ideas, please do take a look at my other shop [https://ClaireMcKayDesigns.etsy.com](https://clairemckaydesigns.etsy.com/)

To see new products, behind the scenes and upcoming markets, follow me on Facebook and Instagram @ClaireMcKayDesigns


## Shipping and return policies

Loading


- Ships out within 3–5 business days


- Returns accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 30 days


- Ships from: **United Kingdom**


Sorry, this item doesn’t ship to United States. Contact the shop to find out about available shipping options.


Change shipping country

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaNew ZealandUnited Kingdom\-\-\--------AlbaniaAndorraAustraliaBosnia and HerzegovinaCanadaGibraltarHoly See (Vatican City State)IcelandKosovoLiechtensteinMacedoniaMoldovaMonacoMontenegroNew ZealandNorwaySan MarinoSerbiaSwitzerlandTürkiyeUkraineUnited KingdomUnited States

Zip code


- Please enter a valid zip code.


Submit



Loading


Shipping upgrades available in the cart


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## Meet your seller

![Claire](https://i.etsystatic.com/35504385/r/isla/583cc5/69715556/isla_75x75.69715556_467mf2du.jpg)

Claire

Owner of [ClaybyClaireMcKay](https://www.etsy.com/shop/ClaybyClaireMcKay?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo2MzcxMjg2MDU6MTc2Mjc3OTY0MjpjNTI0M2ExZDgzNDIwMTBhMTQ3M2UwNjE0MzdhYzhmZQ%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1779603496%2Fpolymer-clay-20mm-circle-drop-earrings%3Futm_source%3Dopenai)

[Message Claire](https://www.etsy.com/messages/new?with_id=637128605&referring_id=1779603496&referring_type=listing&recipient_id=637128605&from_action=contact-seller)

This seller usually responds **within a few hours.**

## Be the first to review this item

No reviews yet. See what customers say about other items from this shop.


Read reviews for other items


[![ClaybyClaireMcKay](https://i.etsystatic.com/iusa/14a0b3/93892867/iusa_75x75.93892867_fsc2.jpg?version=0)](https://www.etsy.com/shop/ClaybyClaireMcKay?ref=shop_profile&listing_id=1779603496)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[ClaybyClaireMcKay](https://www.etsy.com/shop/ClaybyClaireMcKay?ref=shop_profile&listing_id=1779603496)

[Owned by Claire](https://www.etsy.com/shop/ClaybyClaireMcKay?ref=shop_profile&listing_id=1779603496) \|

Guildford, United Kingdom

5.0
(221)


939 sales

3 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=637128605&referring_id=1779603496&referring_type=listing&recipient_id=637128605&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo2MzcxMjg2MDU6MTc2Mjc3OTY0MjpjNTI0M2ExZDgzNDIwMTBhMTQ3M2UwNjE0MzdhYzhmZQ%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1779603496%2Fpolymer-clay-20mm-circle-drop-earrings%3Futm_source%3Dopenai)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/ClaybyClaireMcKay?ref=lp_mys_mfts)

Get 20% off your order when you buy 4 items at this shop. Discount shown at checkout.


- [![4mm Micro Polymer Clay Stud Earrings: Colourful Unisex Minimalist Lobe Helix](https://i.etsystatic.com/35504385/c/1782/1782/231/175/il/b16c8a/7006883983/il_340x270.7006883983_nznr.jpg)\\
\\
**4mm Micro Polymer Clay Stud Earrings: Colourful Unisex Minimalist Lobe Helix**\\
\\
$6.86\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4323999896/4mm-micro-polymer-clay-stud-earrings?click_key=85b6a2867dad5921816f0e2a17366158a901a607%3A4323999896&click_sum=0e2f11f6&ref=related-1&sts=1 "4mm Micro Polymer Clay Stud Earrings: Colourful Unisex Minimalist Lobe Helix")




Add to Favorites


- [![6mm Polymer Clay Stud Earrings: Bright Domed Circle, Silicone Post Option](https://i.etsystatic.com/35504385/c/1966/1966/186/186/il/208ad9/7240736213/il_340x270.7240736213_tktj.jpg)\\
\\
**6mm Polymer Clay Stud Earrings: Bright Domed Circle, Silicone Post Option**\\
\\
$8.24\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4368261911/6mm-polymer-clay-stud-earrings-bright?click_key=b8b7768521050ad0a2effee5234ae19e64846cba%3A4368261911&click_sum=11ddc414&ref=related-2&sts=1 "6mm Polymer Clay Stud Earrings: Bright Domed Circle, Silicone Post Option")




Add to Favorites


- [![Embossed Square Polymer Clay Earrings: Lightweight Diamond Bar Studs](https://i.etsystatic.com/35504385/r/il/4d1c92/6318668013/il_340x270.6318668013_ftc3.jpg)\\
\\
**Embossed Square Polymer Clay Earrings: Lightweight Diamond Bar Studs**\\
\\
$19.22\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1793820639/embossed-square-polymer-clay-earrings?click_key=6967fb7d22b45643d572404ac195a0f0a57b1f33%3A1793820639&click_sum=898a7aa5&ref=related-3&sts=1 "Embossed Square Polymer Clay Earrings: Lightweight Diamond Bar Studs")




Add to Favorites


- [![20mm Polymer Clay Hoop Earrings: Gold Plated Hoop, Brass Charm, Modern Jewellery](https://i.etsystatic.com/35504385/r/il/bee982/6310952773/il_340x270.6310952773_r8pn.jpg)\\
\\
**20mm Polymer Clay Hoop Earrings: Gold Plated Hoop, Brass Charm, Modern Jewellery**\\
\\
$19.22\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1727971669/20mm-polymer-clay-hoop-earrings-gold?click_key=c06425be58990bd688d78a907c032030a440325e%3A1727971669&click_sum=53f277ee&ref=related-4&sts=1 "20mm Polymer Clay Hoop Earrings: Gold Plated Hoop, Brass Charm, Modern Jewellery")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Aug 6, 2025


[One favorite](https://www.etsy.com/listing/1779603496/polymer-clay-20mm-circle-drop-earrings/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Jewelry](https://www.etsy.com/c/jewelry?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Earrings](https://www.etsy.com/c/jewelry/earrings?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Dangle & Drop Earrings](https://www.etsy.com/c/jewelry/earrings/dangle-earrings?utm_source=openai&explicit=1&ref=breadcrumb_listing)

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1779603496%2Fpolymer-clay-20mm-circle-drop-earrings%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc3OTY0MjplNThhZDk1ZWM1ZmNiNzQ3NDZiMTczYmI5MWY1OTQ3Yw==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1779603496%2Fpolymer-clay-20mm-circle-drop-earrings%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1779603496/polymer-clay-20mm-circle-drop-earrings?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1779603496%2Fpolymer-clay-20mm-circle-drop-earrings%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

Loading


There was a problem loading the content


Try again

## Shop policies for ClaybyClaireMcKay

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 24 hours of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


Customs and import taxes

Buyers are responsible for any customs and import taxes that may apply. I'm not responsible for delays due to customs.


For extrajudicial settlements of consumer disputes, the European Union has launched an online platform ("ODR platform"): [https://ec.europa.eu/consumers/odr](https://ec.europa.eu/consumers/odr)

## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![May include: Five pairs of gold and colored dangle earrings. The earrings have two circles, one gold and one colored. The colors are purple, red, blue, green, and yellow.](https://i.etsystatic.com/35504385/r/il/956355/6270519176/il_300x300.6270519176_d9tj.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/file_enj6fi.jpg)

- ![May include: Five pairs of gold dangle earrings with different colored round discs. The discs are purple, burgundy, navy blue, green, and light green. The earrings are displayed on a wooden surface.](https://i.etsystatic.com/35504385/r/il/dc3932/6318572459/il_300x300.6318572459_smkk.jpg)
- ![May include: Gold and green dangle earrings with a round shape. The earrings have a gold circle on top of a larger green circle.](https://i.etsystatic.com/35504385/r/il/5e9d7e/6318593251/il_300x300.6318593251_jqhd.jpg)
- ![May include: A pair of gold and light purple dangle earrings. Each earring has a small gold circle on top of a larger light purple circle.](https://i.etsystatic.com/35504385/r/il/edd1a5/6270520020/il_300x300.6270520020_biva.jpg)
- ![May include: Gold and burgundy dangle earrings with two round discs on each earring. The top disc is gold and the bottom disc is burgundy.](https://i.etsystatic.com/35504385/r/il/acd45d/6270519362/il_300x300.6270519362_p81i.jpg)
- ![May include: A pair of gold and blue earrings. Each earring has a gold circle on top of a blue circle. The earrings are on a wooden surface.](https://i.etsystatic.com/35504385/r/il/d863d8/6318573197/il_300x300.6318573197_foak.jpg)
- ![May include: Gold and green dangle earrings with two round discs on each earring. The top disc is gold and the bottom disc is green.](https://i.etsystatic.com/35504385/r/il/2e1872/6270519820/il_300x300.6270519820_boak.jpg)
- ![May include: A pair of gold and teal dangle earrings. Each earring has a smaller teal circle and a larger gold circle. The circles are connected by a gold wire.](https://i.etsystatic.com/35504385/r/il/2d919f/6270519524/il_300x300.6270519524_gqyq.jpg)
- ![May include: A pair of gold and green dangle earrings. Each earring has a small gold circle followed by a larger green circle.](https://i.etsystatic.com/35504385/r/il/12c193/6318572925/il_300x300.6318572925_2yq0.jpg)
- ![May include: A pair of gold and green dangle earrings. Each earring has a round gold disc and a round green disc. The green discs are larger than the gold discs.](https://i.etsystatic.com/35504385/r/il/b87f4f/6318573387/il_300x300.6318573387_2ad8.jpg)