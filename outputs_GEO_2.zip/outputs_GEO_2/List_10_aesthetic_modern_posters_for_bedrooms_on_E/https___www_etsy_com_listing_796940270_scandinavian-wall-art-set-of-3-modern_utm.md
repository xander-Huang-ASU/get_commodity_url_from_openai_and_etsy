[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/796940270/scandinavian-wall-art-set-of-3-modern?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Prints](https://www.etsy.com/c/art-and-collectibles/prints?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Digital Prints](https://www.etsy.com/c/art-and-collectibles/prints/digital-prints?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)

This shop is taking a short break.

### Similar items on Etsy

(Results include adsLearn more
Sellers looking to grow their business and reach more interested buyers can use Etsy’s advertising platform to promote their items. You’ll see ad results based on factors like relevancy, and the amount sellers pay per click. [Learn more](https://www.etsy.com/legal/policy/search-advertisement-ranking-disclosures/899478564529).
)

- [![Blue Abstract Wall Art Prints - Set of 3 - Modern Home Decor](https://i.etsystatic.com/34323199/r/il/e25e6c/5279580408/il_340x270.5279580408_re46.jpg)\\
\\
**Blue Abstract Wall Art Prints - Set of 3 - Modern Home Decor**\\
\\
ad vertisement by GigglingGooseDesigns\\
Advertisement from shop GigglingGooseDesigns\\
GigglingGooseDesigns\\
From shop GigglingGooseDesigns\\
\\
$39.19\\
\\
FREE shipping](https://www.etsy.com/listing/1549915316/blue-abstract-wall-art-prints-set-of-3?click_key=LTc59e5a903839797a47b23c18e66d0bcea839c61a%3A1549915316&click_sum=d77f240e&ls=a&ref=sold_out_ad-1&frs=1&sts=1 "Blue Abstract Wall Art Prints - Set of 3 - Modern Home Decor")





Add to Favorites


- [![Set of 3 Prints, Modern Wall Art, Scandinavian Art, Abstract Art, 24x36 Art Prints, Printable Art, Geometric Print, 3 Piece Wall Art](https://i.etsystatic.com/14140716/c/2343/1862/200/150/il/227956/1972161313/il_340x270.1972161313_ouou.jpg)\\
\\
**Set of 3 Prints, Modern Wall Art, Scandinavian Art, Abstract Art, 24x36 Art Prints, Printable Art, Geometric Print, 3 Piece Wall Art**\\
\\
ad vertisement by InspirationAbstracts\\
Advertisement from shop InspirationAbstracts\\
InspirationAbstracts\\
From shop InspirationAbstracts\\
\\
$20.59\\
\\
Digital Download](https://www.etsy.com/listing/717317083/set-of-3-prints-modern-wall-art?click_key=LT81ab36fa6cbe98a46f0a63b600a19453d679df68%3A717317083&click_sum=bb4dfda3&ls=a&ref=sold_out_ad-2&sts=1&dd=1 "Set of 3 Prints, Modern Wall Art, Scandinavian Art, Abstract Art, 24x36 Art Prints, Printable Art, Geometric Print, 3 Piece Wall Art")





Add to Favorites


- [![DustinWay Framed Canvas Print Wall Art Set of 3 Pastel Abstract Landscape Modern Art Minimalist Decor](https://i.etsystatic.com/34335965/r/il/7f392f/5944697408/il_340x270.5944697408_lwau.jpg)\\
\\
**DustinWay Framed Canvas Print Wall Art Set of 3 Pastel Abstract Landscape Modern Art Minimalist Decor**\\
\\
ad vertisement by DustinWay\\
Advertisement from shop DustinWay\\
DustinWay\\
From shop DustinWay\\
\\
Sale Price $103.68\\
$103.68\\
\\
$109.14\\
Original Price $109.14\\
\\
\\
(5% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1254423879/dustinway-framed-canvas-print-wall-art?click_key=LTd096a0eb351ceb67fb27033c48e6a09ad604d167%3A1254423879&click_sum=75df12a3&ls=a&ref=sold_out_ad-3&pro=1&frs=1&sts=1 "DustinWay Framed Canvas Print Wall Art Set of 3 Pastel Abstract Landscape Modern Art Minimalist Decor")





Add to Favorites


- [![Framed Canvas Wall Art Set of 3 Pastel Clouds and Terrain Abstract Landscape Nature Wilderness Illustrations Modern Art Nature Wall Decor](https://i.etsystatic.com/39707537/c/1140/905/0/97/il/730be2/5942167176/il_340x270.5942167176_llqw.jpg)\\
\\
**Framed Canvas Wall Art Set of 3 Pastel Clouds and Terrain Abstract Landscape Nature Wilderness Illustrations Modern Art Nature Wall Decor**\\
\\
ad vertisement by Inkmakers\\
Advertisement from shop Inkmakers\\
Inkmakers\\
From shop Inkmakers\\
\\
Sale Price $104.74\\
$104.74\\
\\
$110.25\\
Original Price $110.25\\
\\
\\
(5% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1658865885/framed-canvas-wall-art-set-of-3-pastel?click_key=LTf0bbdc36aabf810057784e9f41cab055f6fe7973%3A1658865885&click_sum=02a62177&ls=a&ref=sold_out_ad-4&pro=1&frs=1&sts=1 "Framed Canvas Wall Art Set of 3 Pastel Clouds and Terrain Abstract Landscape Nature Wilderness Illustrations Modern Art Nature Wall Decor")





Add to Favorites


- [![Oversized Landscape Gallery Wall Set of 6 | Designer Digital Wall Art Prints](https://i.etsystatic.com/28447038/r/il/4c810e/7361813988/il_340x270.7361813988_dt25.jpg)\\
\\
**Oversized Landscape Gallery Wall Set of 6 \| Designer Digital Wall Art Prints**\\
\\
ad vertisement by Urbanblanc\\
Advertisement from shop Urbanblanc\\
Urbanblanc\\
From shop Urbanblanc\\
\\
$49.89\\
\\
Digital Download](https://www.etsy.com/listing/4391740506/oversized-landscape-gallery-wall-set-of?click_key=LT0940c2e39eaa2820cec8f28007ac8e3792018b27%3A4391740506&click_sum=f1aea0a0&ls=a&ref=sold_out_ad-5&dd=1 "Oversized Landscape Gallery Wall Set of 6 | Designer Digital Wall Art Prints")





Add to Favorites


- [![Neutral Minimalist Art, Farmhouse floral print, Above the bed art Flowers Print, Scandinavian Wall Art set of (3) UNFRAMED Prints OR Canvas](https://i.etsystatic.com/6897384/c/1419/1128/72/175/il/3e8027/2250629007/il_340x270.2250629007_cgh4.jpg)\\
\\
**Neutral Minimalist Art, Farmhouse floral print, Above the bed art Flowers Print, Scandinavian Wall Art set of (3) UNFRAMED Prints OR Canvas**\\
\\
ad vertisement by 7WondersDesign\\
Advertisement from shop 7WondersDesign\\
7WondersDesign\\
From shop 7WondersDesign\\
\\
$26.00\\
\\
Free shipping eligible](https://www.etsy.com/listing/767843302/neutral-minimalist-art-farmhouse-floral?click_key=LTb2fbc7ed11c204ffee6c43758c5a7dac4181c7a7%3A767843302&click_sum=93a421b3&ls=a&ref=sold_out_ad-6&frs=1&sts=1 "Neutral Minimalist Art, Farmhouse floral print, Above the bed art Flowers Print, Scandinavian Wall Art set of (3) UNFRAMED Prints OR Canvas")





Add to Favorites


- [![DIY Himmeli Star Kit: Modern Straw Ornament (7 inch).Hanging 3D Model.  Christmas Decor.](https://i.etsystatic.com/28615297/r/il/b8d7bc/4107542545/il_340x270.4107542545_ogww.jpg)\\
\\
**DIY Himmeli Star Kit: Modern Straw Ornament (7 inch).Hanging 3D Model. Christmas Decor.**\\
\\
ad vertisement by CraftsouvenirsArt\\
Advertisement from shop CraftsouvenirsArt\\
CraftsouvenirsArt\\
From shop CraftsouvenirsArt\\
\\
$25.22](https://www.etsy.com/listing/1200594303/diy-himmeli-star-kit-modern-straw?click_key=e7be78a3db11a6f6530988b0e144101c%3ALT1c22ba7ba1af3b80d6f995e9f9cb8777b7e3f78b&click_sum=b103e7a3&ls=r&ref=sold_out-1&sts=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALT1c22ba7ba1af3b80d6f995e9f9cb8777b7e3f78b "DIY Himmeli Star Kit: Modern Straw Ornament (7 inch).Hanging 3D Model.  Christmas Decor.")





Add to Favorites


- [![Scandi Wall Art Scandinavian Village Print Swedish Wall Art Modern Nordic Decor New England Village Housewarming Gift Scandinavian Art](https://i.etsystatic.com/49965764/c/934/934/102/102/il/3695fd/6828777746/il_340x270.6828777746_t40w.jpg)\\
\\
**Scandi Wall Art Scandinavian Village Print Swedish Wall Art Modern Nordic Decor New England Village Housewarming Gift Scandinavian Art**\\
\\
ad vertisement by WildKanvas\\
Advertisement from shop WildKanvas\\
WildKanvas\\
From shop WildKanvas\\
\\
Sale Price $3.34\\
$3.34\\
\\
$6.68\\
Original Price $6.68\\
\\
\\
(50% off)\\
\\
\\
\\
Digital Download](https://www.etsy.com/listing/4298770399/scandi-wall-art-scandinavian-village?click_key=e7be78a3db11a6f6530988b0e144101c%3ALT055e1dc0caccd012acd2b8a313909428b57df828&click_sum=22fb0707&ls=r&ref=sold_out-2&pro=1&sts=1&dd=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALT055e1dc0caccd012acd2b8a313909428b57df828 "Scandi Wall Art Scandinavian Village Print Swedish Wall Art Modern Nordic Decor New England Village Housewarming Gift Scandinavian Art")





Add to Favorites


- [![Matisse print Set of 3, Gallery wall set, Matisse Exhibition, Pastel Colors, Abstract art, Beige Black Art, Modern Set Neutral colors 02](https://i.etsystatic.com/23204678/r/il/bca7c1/6298590274/il_340x270.6298590274_33na.jpg)\\
\\
**Matisse print Set of 3, Gallery wall set, Matisse Exhibition, Pastel Colors, Abstract art, Beige Black Art, Modern Set Neutral colors 02**\\
\\
ad vertisement by HomePosterDecor\\
Advertisement from shop HomePosterDecor\\
HomePosterDecor\\
From shop HomePosterDecor\\
\\
Sale Price $32.37\\
$32.37\\
\\
$35.96\\
Original Price $35.96\\
\\
\\
(10% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1099895618/matisse-print-set-of-3-gallery-wall-set?click_key=e7be78a3db11a6f6530988b0e144101c%3ALT891a01237fa6f25979d425c231c90e9f042317aa&click_sum=1ae27c59&ls=r&ref=sold_out-3&pro=1&frs=1&sts=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALT891a01237fa6f25979d425c231c90e9f042317aa "Matisse print Set of 3, Gallery wall set, Matisse Exhibition, Pastel Colors, Abstract art, Beige Black Art, Modern Set Neutral colors 02")





Add to Favorites


- [![Pandora Set Necklace and Bracelet - Quality Material - Steel Necklace - Birthstone Jewelry - Pride Month Gift - Gif For Her - Gift For Mom](https://i.etsystatic.com/49799326/r/il/fbda92/5740541812/il_340x270.5740541812_7jep.jpg)\\
\\
**Pandora Set Necklace and Bracelet - Quality Material - Steel Necklace - Birthstone Jewelry - Pride Month Gift - Gif For Her - Gift For Mom**\\
\\
ad vertisement by ZanaJewelryDesign\\
Advertisement from shop ZanaJewelryDesign\\
ZanaJewelryDesign\\
From shop ZanaJewelryDesign\\
\\
$50.85\\
\\
FREE shipping](https://www.etsy.com/listing/1659460580/pandora-set-necklace-and-bracelet?click_key=e7be78a3db11a6f6530988b0e144101c%3ALTfd93993787ce0c8769bedefedcb476ffb5449f68&click_sum=78b8b9ea&ls=r&ref=sold_out-4&frs=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALTfd93993787ce0c8769bedefedcb476ffb5449f68 "Pandora Set Necklace and Bracelet - Quality Material - Steel Necklace - Birthstone Jewelry - Pride Month Gift - Gif For Her - Gift For Mom")





Add to Favorites


- [![Sage Green wall art Abstract Misty Landscape Art On Canvas Art abstract river art Large Wall Art landscape Wall Art  green Nature decor](https://i.etsystatic.com/22649442/c/1342/1065/322/270/il/eac4d8/5489755618/il_340x270.5489755618_fy1y.jpg)\\
\\
**Sage Green wall art Abstract Misty Landscape Art On Canvas Art abstract river art Large Wall Art landscape Wall Art green Nature decor**\\
\\
ad vertisement by BausArt\\
Advertisement from shop BausArt\\
BausArt\\
From shop BausArt\\
\\
Sale Price $99.00\\
$99.00\\
\\
$165.00\\
Original Price $165.00\\
\\
\\
(40% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1340298354/sage-green-wall-art-abstract-misty?click_key=e7be78a3db11a6f6530988b0e144101c%3ALT584a04601deadf872cf9be5ae08d2bc4a884e241&click_sum=953e8587&ls=r&ref=sold_out-5&pro=1&frs=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALT584a04601deadf872cf9be5ae08d2bc4a884e241 "Sage Green wall art Abstract Misty Landscape Art On Canvas Art abstract river art Large Wall Art landscape Wall Art  green Nature decor")





Add to Favorites


- [![Mama Mini, Mommy and me Modern Teal Set, Kids Flip Cup, 15oz SKinny Tumbler, 20 Oz Skinny Tumbler Design, PNG, Instant Download, Sublimation](https://i.etsystatic.com/25674873/r/il/eb19c9/2877195386/il_340x270.2877195386_kuou.jpg)\\
\\
**Mama Mini, Mommy and me Modern Teal Set, Kids Flip Cup, 15oz SKinny Tumbler, 20 Oz Skinny Tumbler Design, PNG, Instant Download, Sublimation**\\
\\
ad vertisement by michellerayesubs\\
Advertisement from shop michellerayesubs\\
michellerayesubs\\
From shop michellerayesubs\\
\\
$9.00\\
\\
Digital Download](https://www.etsy.com/listing/963865743/mama-mini-mommy-and-me-modern-teal-set?click_key=e7be78a3db11a6f6530988b0e144101c%3ALT45a89abbbbbbd4596bc57c26992d8e7e09265cb3&click_sum=470c7482&ls=r&ref=sold_out-6&sts=1&dd=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALT45a89abbbbbbd4596bc57c26992d8e7e09265cb3 "Mama Mini, Mommy and me Modern Teal Set, Kids Flip Cup, 15oz SKinny Tumbler, 20 Oz Skinny Tumbler Design, PNG, Instant Download, Sublimation")





Add to Favorites


- [![Rustic Industrial Handmade Modern Bathroom Set, Towel Holder, TP Holder, Hook, Pipe Bathroom, Workshop, Office, Pipe Set, Unique Set Gift](https://i.etsystatic.com/11740767/r/il/9e6be9/5209223060/il_340x270.5209223060_e3s8.jpg)\\
\\
**Rustic Industrial Handmade Modern Bathroom Set, Towel Holder, TP Holder, Hook, Pipe Bathroom, Workshop, Office, Pipe Set, Unique Set Gift**\\
\\
ad vertisement by Lightrooom\\
Advertisement from shop Lightrooom\\
Lightrooom\\
From shop Lightrooom\\
\\
$105.00\\
\\
FREE shipping](https://www.etsy.com/listing/274200492/rustic-industrial-handmade-modern?click_key=e7be78a3db11a6f6530988b0e144101c%3ALTe6e6b080c8d530e096f47e9b8e2605b9c10f56e6&click_sum=663cde60&ls=r&ref=sold_out-7&frs=1&sts=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALTe6e6b080c8d530e096f47e9b8e2605b9c10f56e6 "Rustic Industrial Handmade Modern Bathroom Set, Towel Holder, TP Holder, Hook, Pipe Bathroom, Workshop, Office, Pipe Set, Unique Set Gift")





Add to Favorites


- [![Tromsø Travel Print, Wall Art Tromsø, Tromsø Poster, Norway Travel Print, Travel Lovers Home Decor Wall Art City Travel Poster Gifts](https://i.etsystatic.com/50776317/r/il/e816a7/6656975841/il_340x270.6656975841_3k15.jpg)\\
\\
**Tromsø Travel Print, Wall Art Tromsø, Tromsø Poster, Norway Travel Print, Travel Lovers Home Decor Wall Art City Travel Poster Gifts**\\
\\
ad vertisement by PetesRetroPrints\\
Advertisement from shop PetesRetroPrints\\
PetesRetroPrints\\
From shop PetesRetroPrints\\
\\
Sale Price $16.46\\
$16.46\\
\\
$20.58\\
Original Price $20.58\\
\\
\\
(20% off)](https://www.etsy.com/listing/1812484395/tromso-travel-print-wall-art-tromso?click_key=e7be78a3db11a6f6530988b0e144101c%3ALTe451dc2e4a75732ff5f7ff9c6a83003a29f8d9de&click_sum=8c5e6f92&ls=r&ref=sold_out-8&pro=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALTe451dc2e4a75732ff5f7ff9c6a83003a29f8d9de "Tromsø Travel Print, Wall Art Tromsø, Tromsø Poster, Norway Travel Print, Travel Lovers Home Decor Wall Art City Travel Poster Gifts")





Add to Favorites


- [![Elderberry Plant PNG, Medicinal Plant Scientific Sketch, Herbal Tea Vintage Artwork, Fall Leaves SVG Botanical Print, Autumn Clipart](https://i.etsystatic.com/32268660/r/il/89aae7/6045044207/il_340x270.6045044207_k1p6.jpg)\\
\\
**Elderberry Plant PNG, Medicinal Plant Scientific Sketch, Herbal Tea Vintage Artwork, Fall Leaves SVG Botanical Print, Autumn Clipart**\\
\\
ad vertisement by SketchedGraphics\\
Advertisement from shop SketchedGraphics\\
SketchedGraphics\\
From shop SketchedGraphics\\
\\
$3.62\\
\\
Digital Download](https://www.etsy.com/listing/1227357420/elderberry-plant-png-medicinal-plant?click_key=e7be78a3db11a6f6530988b0e144101c%3ALT13e63dc58dc5905c3f6063371f5c31ef81489097&click_sum=98f261cc&ls=r&ref=sold_out-9&sts=1&dd=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALT13e63dc58dc5905c3f6063371f5c31ef81489097 "Elderberry Plant PNG, Medicinal Plant Scientific Sketch, Herbal Tea Vintage Artwork, Fall Leaves SVG Botanical Print, Autumn Clipart")





Add to Favorites


- [![Pandora Set Necklace and Bracelet - Quality Steel Material - Stainless Necklace - Birthstone Jewelry - Pride Month Gift - Gift For Her](https://i.etsystatic.com/49799326/r/il/c79bf8/5740463096/il_340x270.5740463096_t5ej.jpg)\\
\\
**Pandora Set Necklace and Bracelet - Quality Steel Material - Stainless Necklace - Birthstone Jewelry - Pride Month Gift - Gift For Her**\\
\\
ad vertisement by ZanaJewelryDesign\\
Advertisement from shop ZanaJewelryDesign\\
ZanaJewelryDesign\\
From shop ZanaJewelryDesign\\
\\
$50.85\\
\\
FREE shipping](https://www.etsy.com/listing/1659444490/pandora-set-necklace-and-bracelet?click_key=e7be78a3db11a6f6530988b0e144101c%3ALT182281f805cf5adc566dbcc4640eadbbd1c24e81&click_sum=cf698d17&ls=r&ref=sold_out-10&frs=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALT182281f805cf5adc566dbcc4640eadbbd1c24e81 "Pandora Set Necklace and Bracelet - Quality Steel Material - Stainless Necklace - Birthstone Jewelry - Pride Month Gift - Gift For Her")





Add to Favorites


- [![Handmade Agate 5-Piece Bathroom Accessory Set](https://i.etsystatic.com/25405075/r/il/3078de/6487294321/il_340x270.6487294321_m6d6.jpg)\\
\\
**Handmade Agate 5-Piece Bathroom Accessory Set**\\
\\
ad vertisement by CraftStoneHouse\\
Advertisement from shop CraftStoneHouse\\
CraftStoneHouse\\
From shop CraftStoneHouse\\
\\
Sale Price $634.91\\
$634.91\\
\\
$907.01\\
Original Price $907.01\\
\\
\\
(30% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1827929101/handmade-agate-5-piece-bathroom?click_key=e7be78a3db11a6f6530988b0e144101c%3ALT1083dd693eec2785bab1fee1ee083bffcdc348e1&click_sum=ac79904f&ls=r&ref=sold_out-11&pro=1&frs=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALT1083dd693eec2785bab1fee1ee083bffcdc348e1 "Handmade Agate 5-Piece Bathroom Accessory Set")





Add to Favorites


- [![Vintage Bavarian Porcelain Tea Trio: Gold Modern Motif Collectible Set](https://i.etsystatic.com/7965881/r/il/1bf2df/5566627839/il_340x270.5566627839_qt2o.jpg)\\
\\
**Vintage Bavarian Porcelain Tea Trio: Gold Modern Motif Collectible Set**\\
\\
ad vertisement by AnythingDiscovered\\
Advertisement from shop AnythingDiscovered\\
AnythingDiscovered\\
From shop AnythingDiscovered\\
\\
$115.00](https://www.etsy.com/listing/1614366367/vintage-bavarian-porcelain-tea-trio-gold?click_key=e7be78a3db11a6f6530988b0e144101c%3ALT75bbb8d21d91840cde3115aa5a409ae3a8ef16ff&click_sum=480645b1&ls=r&ref=sold_out-12&sts=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALT75bbb8d21d91840cde3115aa5a409ae3a8ef16ff "Vintage Bavarian Porcelain Tea Trio: Gold Modern Motif Collectible Set")





Add to Favorites


- [![Beige Mandala Canvas Wall Art Set: Boho Living Room Decor, Giclee Prints](https://i.etsystatic.com/14624241/c/1626/1626/201/201/il/c35a0a/6383934743/il_340x270.6383934743_41m0.jpg)\\
\\
**Beige Mandala Canvas Wall Art Set: Boho Living Room Decor, Giclee Prints**\\
\\
ad vertisement by AgaSzafranskaStudio\\
Advertisement from shop AgaSzafranskaStudio\\
AgaSzafranskaStudio\\
From shop AgaSzafranskaStudio\\
\\
Sale Price $82.59\\
$82.59\\
\\
$91.77\\
Original Price $91.77\\
\\
\\
(10% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1807225403/beige-mandala-canvas-wall-art-set-boho?click_key=e7be78a3db11a6f6530988b0e144101c%3ALT074f76840f0e3c86e84be10cc0ebfa79831d08ac&click_sum=5a547c9b&ls=r&ref=sold_out-13&pro=1&frs=1&sts=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALT074f76840f0e3c86e84be10cc0ebfa79831d08ac "Beige Mandala Canvas Wall Art Set: Boho Living Room Decor, Giclee Prints")





Add to Favorites


- [![Agate Bathroom Accessories Set: Handmade Crystal Vanity Decor, 7-Piece](https://i.etsystatic.com/42105268/r/il/09ef57/6889604926/il_340x270.6889604926_gusl.jpg)\\
\\
**Agate Bathroom Accessories Set: Handmade Crystal Vanity Decor, 7-Piece**\\
\\
ad vertisement by EpoxyAgateShop\\
Advertisement from shop EpoxyAgateShop\\
EpoxyAgateShop\\
From shop EpoxyAgateShop\\
\\
Sale Price $957.60\\
$957.60\\
\\
$1,368.00\\
Original Price $1,368.00\\
\\
\\
(30% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/4310847846/agate-bathroom-accessories-set-handmade?click_key=e7be78a3db11a6f6530988b0e144101c%3ALTd5a7cec57e8d73cc75d0ba2cb91915805dccb038&click_sum=6d708c1f&ls=r&ref=sold_out-14&pro=1&frs=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALTd5a7cec57e8d73cc75d0ba2cb91915805dccb038 "Agate Bathroom Accessories Set: Handmade Crystal Vanity Decor, 7-Piece")





Add to Favorites


- [![Set of Jewelry Made of Natural Mint Green Chalcedony Stone Beads.](https://i.etsystatic.com/48253955/r/il/6094e4/6064359916/il_340x270.6064359916_875w.jpg)\\
\\
**Set of Jewelry Made of Natural Mint Green Chalcedony Stone Beads.**\\
\\
ad vertisement by ByzinaUA\\
Advertisement from shop ByzinaUA\\
ByzinaUA\\
From shop ByzinaUA\\
\\
$32.00](https://www.etsy.com/listing/1734312800/set-of-jewelry-made-of-natural-mint?click_key=e7be78a3db11a6f6530988b0e144101c%3ALTb7ceb2e297581b6baaa16c63c147d5b43825a54d&click_sum=8f7f9047&ls=r&ref=sold_out-15&sts=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALTb7ceb2e297581b6baaa16c63c147d5b43825a54d "Set of Jewelry Made of Natural Mint Green Chalcedony Stone Beads.")





Add to Favorites


- [![Botanical Flower Wall Art Set of 3, Modern Floral Poster Prints, Green and Pink Nature Decor, Contemporary Botanical Art Set](https://i.etsystatic.com/24426965/r/il/16c896/7333905841/il_340x270.7333905841_6lm7.jpg)\\
\\
**Botanical Flower Wall Art Set of 3, Modern Floral Poster Prints, Green and Pink Nature Decor, Contemporary Botanical Art Set**\\
\\
ad vertisement by TheWorldGallery\\
Advertisement from shop TheWorldGallery\\
TheWorldGallery\\
From shop TheWorldGallery\\
\\
$31.56\\
\\
Eligible orders get 10% off\\
\\
\\
Buy 2 items and get 10% off your order\\
\\
\\
Free shipping eligible](https://www.etsy.com/listing/4386814348/botanical-flower-wall-art-set-of-3?click_key=e7be78a3db11a6f6530988b0e144101c%3ALT7ee394464e6c1bb53c128470cd640ea6c1565560&click_sum=b0a1e6cc&ls=r&ref=sold_out-16&pro=1&frs=1&sts=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALT7ee394464e6c1bb53c128470cd640ea6c1565560 "Botanical Flower Wall Art Set of 3, Modern Floral Poster Prints, Green and Pink Nature Decor, Contemporary Botanical Art Set")





Add to Favorites


- [![Passport Holder, Floral Paisley Passport Holder, Bright Preppy Cover for Passport, Passport Cover, Gift for Student, Summer Travel, Preppy](https://i.etsystatic.com/35540550/r/il/c92b69/5082556244/il_340x270.5082556244_c71s.jpg)\\
\\
**Passport Holder, Floral Paisley Passport Holder, Bright Preppy Cover for Passport, Passport Cover, Gift for Student, Summer Travel, Preppy**\\
\\
ad vertisement by BekahJCreates\\
Advertisement from shop BekahJCreates\\
BekahJCreates\\
From shop BekahJCreates\\
\\
$29.00\\
\\
FREE shipping](https://www.etsy.com/listing/1507588010/passport-holder-floral-paisley-passport?click_key=e7be78a3db11a6f6530988b0e144101c%3ALT26a7e927a7c5b60ea8785ac0a010d967bb735471&click_sum=3fbbfafb&ls=r&ref=sold_out-17&frs=1&sts=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALT26a7e927a7c5b60ea8785ac0a010d967bb735471 "Passport Holder, Floral Paisley Passport Holder, Bright Preppy Cover for Passport, Passport Cover, Gift for Student, Summer Travel, Preppy")





Add to Favorites


- [![Black Bandeau Top & Wide Leg Pants Set: Formal Women&#39;s Suit](https://i.etsystatic.com/24285858/r/il/6a0f4b/7069089748/il_340x270.7069089748_6ewc.jpg)\\
\\
**Black Bandeau Top & Wide Leg Pants Set: Formal Women's Suit**\\
\\
ad vertisement by ElenaKosminskaya\\
Advertisement from shop ElenaKosminskaya\\
ElenaKosminskaya\\
From shop ElenaKosminskaya\\
\\
$155.00\\
\\
FREE shipping](https://www.etsy.com/listing/4344335904/black-bandeau-top-wide-leg-pants-set?click_key=e7be78a3db11a6f6530988b0e144101c%3ALTfe759b87013637c4fbb77f9a648e14ea4e92cdf3&click_sum=adf58607&ls=r&ref=sold_out-18&frs=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALTfe759b87013637c4fbb77f9a648e14ea4e92cdf3 "Black Bandeau Top & Wide Leg Pants Set: Formal Women's Suit")





Add to Favorites


- [![3x Islam Poster Set - Hub Sabr Ayat Al Kursi - Islamic Wall Art - Art Prints - Wall Decoration - Pictures Living Room](https://i.etsystatic.com/38915754/c/2821/2240/0/0/il/85b9d7/6018396459/il_340x270.6018396459_8atg.jpg)\\
\\
**3x Islam Poster Set - Hub Sabr Ayat Al Kursi - Islamic Wall Art - Art Prints - Wall Decoration - Pictures Living Room**\\
\\
ad vertisement by Perlamerla\\
Advertisement from shop Perlamerla\\
Perlamerla\\
From shop Perlamerla\\
\\
$44.55\\
\\
FREE shipping](https://www.etsy.com/listing/1726668591/3x-islam-poster-set-hub-sabr-ayat-al?click_key=LTd25cb20d735135f5e156468429ecedcf7036200f%3A1726668591&click_sum=5921a4b5&ls=a&ref=sold_out_ad-7&frs=1 "3x Islam Poster Set - Hub Sabr Ayat Al Kursi - Islamic Wall Art - Art Prints - Wall Decoration - Pictures Living Room")





Add to Favorites


- [![Neutral Christmas Print Set: Scandinavian Winter Wall Art (Digital Download)](https://i.etsystatic.com/59783829/r/il/bad315/7318115883/il_340x270.7318115883_tf14.jpg)\\
\\
**Neutral Christmas Print Set: Scandinavian Winter Wall Art (Digital Download)**\\
\\
ad vertisement by VidaDigitalAtelier\\
Advertisement from shop VidaDigitalAtelier\\
VidaDigitalAtelier\\
From shop VidaDigitalAtelier\\
\\
Sale Price $9.65\\
$9.65\\
\\
$19.31\\
Original Price $19.31\\
\\
\\
(50% off)\\
\\
\\
\\
Digital Download](https://www.etsy.com/listing/4383985076/neutral-christmas-print-set-scandinavian?click_key=LT4b124922e78b4160cf88f749d2572810902d9fa9%3A4383985076&click_sum=273be559&ls=a&ref=sold_out_ad-8&pro=1&dd=1 "Neutral Christmas Print Set: Scandinavian Winter Wall Art (Digital Download)")





Add to Favorites


- [![Henri 3 Piece Canvas Wall Art Set, Framed Canvas Oil Painting Landscape Wall Art,Large Wall Art Print,Wall Decor Minimalist Vintage Art,Gift](https://i.etsystatic.com/32444416/r/il/7698e6/5622290187/il_340x270.5622290187_21bj.jpg)\\
\\
**Henri 3 Piece Canvas Wall Art Set, Framed Canvas Oil Painting Landscape Wall Art,Large Wall Art Print,Wall Decor Minimalist Vintage Art,Gift**\\
\\
ad vertisement by ZLinSigns\\
Advertisement from shop ZLinSigns\\
ZLinSigns\\
From shop ZLinSigns\\
\\
Sale Price $68.42\\
$68.42\\
\\
$80.50\\
Original Price $80.50\\
\\
\\
(15% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1614547394/henri-3-piece-canvas-wall-art-set-framed?click_key=LTf263f9f5216f21702516f98989ee335a976ebe74%3A1614547394&click_sum=6c5a5847&ls=a&ref=sold_out_ad-9&pro=1&frs=1&sts=1 "Henri 3 Piece Canvas Wall Art Set, Framed Canvas Oil Painting Landscape Wall Art,Large Wall Art Print,Wall Decor Minimalist Vintage Art,Gift")





Add to Favorites


- [![Set of 3 minimalist wall art posters, abstract shapes & lines, premium matte photo paper, neutral tones, boho design for the living room](https://i.etsystatic.com/27380698/c/2419/2419/301/0/il/2424fc/6970276805/il_340x270.6970276805_8q15.jpg)\\
\\
**Set of 3 minimalist wall art posters, abstract shapes & lines, premium matte photo paper, neutral tones, boho design for the living room**\\
\\
ad vertisement by DesignAt9pm\\
Advertisement from shop DesignAt9pm\\
DesignAt9pm\\
From shop DesignAt9pm\\
\\
$83.31\\
\\
FREE shipping](https://www.etsy.com/listing/4317122682/set-of-3-minimalist-wall-art-posters?click_key=LT21742852383ddea42df3edbe561bc344ba0d571b%3A4317122682&click_sum=61b07189&ls=a&ref=sold_out_ad-10&frs=1 "Set of 3 minimalist wall art posters, abstract shapes & lines, premium matte photo paper, neutral tones, boho design for the living room")





Add to Favorites


- [![Abstract Paintings Set of 3 Canvas Prints Burnt Orange Blue Art, Extra Large Wall Art, 3 Canvas Panels Wall Art, Abstract Living Room Decor](https://i.etsystatic.com/8335791/c/2525/2007/32/0/il/844c43/3855898720/il_340x270.3855898720_3o5p.jpg)\\
\\
**Abstract Paintings Set of 3 Canvas Prints Burnt Orange Blue Art, Extra Large Wall Art, 3 Canvas Panels Wall Art, Abstract Living Room Decor**\\
\\
ad vertisement by CanotStop\\
Advertisement from shop CanotStop\\
CanotStop\\
From shop CanotStop\\
\\
Sale Price $92.00\\
$92.00\\
\\
$115.00\\
Original Price $115.00\\
\\
\\
(20% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1213859738/abstract-paintings-set-of-3-canvas?click_key=LT9d751ce69f58a1bb402ad94ba97b2a35911aa2f4%3A1213859738&click_sum=e74b210d&ls=a&ref=sold_out_ad-11&pro=1&frs=1&sts=1 "Abstract Paintings Set of 3 Canvas Prints Burnt Orange Blue Art, Extra Large Wall Art, 3 Canvas Panels Wall Art, Abstract Living Room Decor")





Add to Favorites


- [![Abstract Coast Wave Print Set: Gallery Wall ART, Home Decor (PDF Digital Download)](https://i.etsystatic.com/47706603/r/il/5f3add/6756514063/il_340x270.6756514063_e3f3.jpg)\\
\\
**Abstract Coast Wave Print Set: Gallery Wall ART, Home Decor (PDF Digital Download)**\\
\\
ad vertisement by AtuArtDesign\\
Advertisement from shop AtuArtDesign\\
AtuArtDesign\\
From shop AtuArtDesign\\
\\
$8.00\\
\\
Digital Download](https://www.etsy.com/listing/1872650028/abstract-coast-wave-print-set-gallery?click_key=LT8fc702e1fbd32534ed8170ae9c55be5441c11962%3A1872650028&click_sum=741b64c3&ls=a&ref=sold_out_ad-12&dd=1 "Abstract Coast Wave Print Set: Gallery Wall ART, Home Decor (PDF Digital Download)")





Add to Favorites


- [![White or Blue Ceramic Salt and Pepper Set with Matching Plate, Salt and Pepper Table Set.](https://i.etsystatic.com/16575267/r/il/f23e3e/7238343908/il_340x270.7238343908_senv.jpg)\\
\\
**White or Blue Ceramic Salt and Pepper Set with Matching Plate, Salt and Pepper Table Set.**\\
\\
ad vertisement by YvonneSCreativCrafts\\
Advertisement from shop YvonneSCreativCrafts\\
YvonneSCreativCrafts\\
From shop YvonneSCreativCrafts\\
\\
$99.77\\
\\
FREE shipping](https://www.etsy.com/listing/1883214133/white-or-blue-ceramic-salt-and-pepper?click_key=e7be78a3db11a6f6530988b0e144101c%3ALTf2419e4ae763164dbff972a031eb9f38c530e495&click_sum=526de0f1&ls=r&ref=sold_out-19&frs=1&sts=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALTf2419e4ae763164dbff972a031eb9f38c530e495 "White or Blue Ceramic Salt and Pepper Set with Matching Plate, Salt and Pepper Table Set.")





Add to Favorites


- [![Fontana Arte Brass and Glass Modernist Fireplace Tools Mid Century Modern Italy](https://i.etsystatic.com/10790595/r/il/634a19/6833781456/il_340x270.6833781456_qc7c.jpg)\\
\\
**Fontana Arte Brass and Glass Modernist Fireplace Tools Mid Century Modern Italy**\\
\\
ad vertisement by FloridaModern\\
Advertisement from shop FloridaModern\\
FloridaModern\\
From shop FloridaModern\\
\\
$3,400.00](https://www.etsy.com/listing/4363126710/fontana-arte-brass-and-glass-modernist?click_key=e7be78a3db11a6f6530988b0e144101c%3ALTf8e1e3406bd0157f3fa6a512d4bdf942c520ac88&click_sum=feb21486&ls=r&ref=sold_out-20&content_source=e7be78a3db11a6f6530988b0e144101c%253ALTf8e1e3406bd0157f3fa6a512d4bdf942c520ac88 "Fontana Arte Brass and Glass Modernist Fireplace Tools Mid Century Modern Italy")





Add to Favorites


- [![Set of 2 Prints, Mountains Landscape Art Print, Boho Printable Wall Art, Modern Printable Set, Bedroom Wall Art Decor, INSTANT DOWNLOAD ART](https://i.etsystatic.com/34929045/r/il/c07046/3865213403/il_340x270.3865213403_h3gd.jpg)\\
\\
**Set of 2 Prints, Mountains Landscape Art Print, Boho Printable Wall Art, Modern Printable Set, Bedroom Wall Art Decor, INSTANT DOWNLOAD ART**\\
\\
ad vertisement by mangolilydesignco\\
Advertisement from shop mangolilydesignco\\
mangolilydesignco\\
From shop mangolilydesignco\\
\\
$8.91\\
\\
Digital Download](https://www.etsy.com/listing/1203638208/set-of-2-prints-mountains-landscape-art?click_key=e7be78a3db11a6f6530988b0e144101c%3ALTf81a4edac573efa77f9d73da8ad08a4037c9296d&click_sum=62bf2e54&ls=r&ref=sold_out-21&dd=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALTf81a4edac573efa77f9d73da8ad08a4037c9296d "Set of 2 Prints, Mountains Landscape Art Print, Boho Printable Wall Art, Modern Printable Set, Bedroom Wall Art Decor, INSTANT DOWNLOAD ART")





Add to Favorites


- [![White Ceramic Salt and Pepper Set, Salt and Pepper Table or Cooking Set](https://i.etsystatic.com/16575267/r/il/64d6d6/7120092843/il_340x270.7120092843_74za.jpg)\\
\\
**White Ceramic Salt and Pepper Set, Salt and Pepper Table or Cooking Set**\\
\\
ad vertisement by YvonneSCreativCrafts\\
Advertisement from shop YvonneSCreativCrafts\\
YvonneSCreativCrafts\\
From shop YvonneSCreativCrafts\\
\\
$96.56\\
\\
FREE shipping](https://www.etsy.com/listing/1759318770/white-ceramic-salt-and-pepper-set-salt?click_key=e7be78a3db11a6f6530988b0e144101c%3ALT1518d2c6d3fd86d8eb7e3718f5f12b28501d88d5&click_sum=dfcdf2bd&ls=r&ref=sold_out-22&frs=1&sts=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALT1518d2c6d3fd86d8eb7e3718f5f12b28501d88d5 "White Ceramic Salt and Pepper Set, Salt and Pepper Table or Cooking Set")





Add to Favorites


- [![Moissanite With Doublet Necklace/Indian Bridle Jewelry](https://i.etsystatic.com/61117181/r/il/a2f994/7318573237/il_340x270.7318573237_s48h.jpg)\\
\\
**Moissanite With Doublet Necklace/Indian Bridle Jewelry**\\
\\
ad vertisement by NVCOLLECTIONIndia\\
Advertisement from shop NVCOLLECTIONIndia\\
NVCOLLECTIONIndia\\
From shop NVCOLLECTIONIndia\\
\\
Sale Price $53.15\\
$53.15\\
\\
$106.30\\
Original Price $106.30\\
\\
\\
(50% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/4384077237/moissanite-with-doublet-necklaceindian?click_key=e7be78a3db11a6f6530988b0e144101c%3ALT959985e6e9be70f5b5e56287f53a7d477e18d66f&click_sum=16bbb81a&ls=r&ref=sold_out-23&pro=1&frs=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALT959985e6e9be70f5b5e56287f53a7d477e18d66f "Moissanite With Doublet Necklace/Indian Bridle Jewelry")





Add to Favorites


- [![Freshwater Pearl Jewelry Set – Minimalist Necklace and Earrings](https://i.etsystatic.com/9711917/r/il/c11166/6407061174/il_340x270.6407061174_9qh2.jpg)\\
\\
**Freshwater Pearl Jewelry Set – Minimalist Necklace and Earrings**\\
\\
ad vertisement by Estibela\\
Advertisement from shop Estibela\\
Estibela\\
From shop Estibela\\
\\
Sale Price $20.28\\
$20.28\\
\\
$25.36\\
Original Price $25.36\\
\\
\\
(20% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1821355485/freshwater-pearl-jewelry-set-minimalist?click_key=e7be78a3db11a6f6530988b0e144101c%3ALT903729562aefb3e698b7ba2948269865f0374db7&click_sum=f2dac41f&ls=r&ref=sold_out-24&pro=1&frs=1&sts=1&content_source=e7be78a3db11a6f6530988b0e144101c%253ALT903729562aefb3e698b7ba2948269865f0374db7 "Freshwater Pearl Jewelry Set – Minimalist Necklace and Earrings")





Add to Favorites



[Shop more similar items](https://www.etsy.com/listing/796940270/similar?page=2&ref=sold_out_more_like_this)

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F796940270%2Fscandinavian-wall-art-set-of-3-modern%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc3NDI1NzpkYzA3ODA0ZDg3NDA1ZTMzNDhmYjI4MjBmNmY5ZDkzNw==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F796940270%2Fscandinavian-wall-art-set-of-3-modern%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/796940270/scandinavian-wall-art-set-of-3-modern?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F796940270%2Fscandinavian-wall-art-set-of-3-modern%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done