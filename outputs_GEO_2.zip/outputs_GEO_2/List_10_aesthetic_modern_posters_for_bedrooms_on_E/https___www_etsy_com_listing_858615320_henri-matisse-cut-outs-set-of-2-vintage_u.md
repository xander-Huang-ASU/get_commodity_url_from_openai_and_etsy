[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/858615320/henri-matisse-cut-outs-set-of-2-vintage?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Prints](https://www.etsy.com/c/art-and-collectibles/prints?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Giclée](https://www.etsy.com/c/art-and-collectibles/prints/giclee?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)


Add to Favorites


- ![Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints | Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art, Gallery Wall, Berggruen Cie, Papiers Decoupes](https://i.etsystatic.com/24006786/r/il/d4bcbd/3249106649/il_794xN.3249106649_9fsq.jpg)
- ![Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints | Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art, Gallery Wall, Berggruen Cie, Papiers Decoupes](https://i.etsystatic.com/24006786/r/il/ae94cb/3201404816/il_794xN.3201404816_p822.jpg)
- ![Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints | Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art, Gallery Wall, Berggruen Cie, Papiers Decoupes](https://i.etsystatic.com/24006786/r/il/4f49a5/3249107233/il_794xN.3249107233_2563.jpg)
- ![Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints | Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art, Gallery Wall, Berggruen Cie, Papiers Decoupes](https://i.etsystatic.com/24006786/r/il/79111f/3249106651/il_794xN.3249106651_kne0.jpg)
- ![Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints | Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art, Gallery Wall, Berggruen Cie, Papiers Decoupes](https://i.etsystatic.com/24006786/r/il/a4b063/3249106653/il_794xN.3249106653_pvn4.jpg)
- ![Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints | Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art, Gallery Wall, Berggruen Cie, Papiers Decoupes](https://i.etsystatic.com/24006786/r/il/78d2a8/3201404534/il_794xN.3201404534_qrow.jpg)
- ![Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints | Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art, Gallery Wall, Berggruen Cie, Papiers Decoupes](https://i.etsystatic.com/24006786/r/il/b6ab80/3201404554/il_794xN.3201404554_bsg3.jpg)

- ![Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints | Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art, Gallery Wall, Berggruen Cie, Papiers Decoupes](https://i.etsystatic.com/24006786/r/il/d4bcbd/3249106649/il_75x75.3249106649_9fsq.jpg)
- ![Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints | Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art, Gallery Wall, Berggruen Cie, Papiers Decoupes](https://i.etsystatic.com/24006786/r/il/ae94cb/3201404816/il_75x75.3201404816_p822.jpg)
- ![Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints | Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art, Gallery Wall, Berggruen Cie, Papiers Decoupes](https://i.etsystatic.com/24006786/r/il/4f49a5/3249107233/il_75x75.3249107233_2563.jpg)
- ![Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints | Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art, Gallery Wall, Berggruen Cie, Papiers Decoupes](https://i.etsystatic.com/24006786/r/il/79111f/3249106651/il_75x75.3249106651_kne0.jpg)
- ![Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints | Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art, Gallery Wall, Berggruen Cie, Papiers Decoupes](https://i.etsystatic.com/24006786/r/il/a4b063/3249106653/il_75x75.3249106653_pvn4.jpg)
- ![Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints | Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art, Gallery Wall, Berggruen Cie, Papiers Decoupes](https://i.etsystatic.com/24006786/r/il/78d2a8/3201404534/il_75x75.3201404534_qrow.jpg)
- ![Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints | Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art, Gallery Wall, Berggruen Cie, Papiers Decoupes](https://i.etsystatic.com/24006786/r/il/b6ab80/3201404554/il_75x75.3201404554_bsg3.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F858615320%2Fhenri-matisse-cut-outs-set-of-2-vintage%23report-overlay-trigger)

Price:$22.39+


Loading


# Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints \| Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art

Designed by [SugarnCanvas](https://www.etsy.com/shop/SugarnCanvas)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/858615320/henri-matisse-cut-outs-set-of-2-vintage?utm_source=openai#reviews)

Returns & exchanges accepted

Size (2-7 Day Worldwide Shipping)


Select an option

5x7 inches/13x18cm ($22.39)

6x8 inches/15x20cm ($35.56)

8x10 inches/20x25cm ($47.10)

8x12 inches/21x30cm ($54.11)

11x14 inches/27x35cm ($61.50)

11x17 inches/28x43cm ($66.84)

A3 (29.7x42cm) ($66.84)

12x16 inches/30x40cm ($66.84)

12x18 inches/30x45cm ($70.86)

16x20 inches/40x50cm ($76.57)

16x24 inches/40x60cm ($86.90)

A2 (42x59.4cm) ($90.61)

18x24 inches/45x60cm ($90.61)

20x28 inches/50x70cm ($97.63)

24x32 inches/60x80cm ($122.90)

A1 (59.4x84.1cm) ($122.90)

24x36 inches/60x90cm ($131.32)

28x40inches/70x100cm ($147.46)

30x40inches/75x100cm ($153.74)

A0 (84.1x118.9cm) ($167.11)

Please select an option


Fine Art Paper Type


Select an option

Premium Matte Paper (Less Reflective)

Premium Satin Paper (More Vibrant)

Please select an option


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Designed by [SugarnCanvas](https://www.etsy.com/shop/SugarnCanvas)

- Materials: High Quality Printing, Giclee Print, Fine Art Print, Premium Matte Paper, Museum Quality, 200 gsm, FSC certified Paper, Ethically Sourced, Sugar Canvas Home, SugarnCanvas Prints, Large Sizes, Shipped Prints



NOTE: Not impacted by the U.S. import tariffs (Duty-free to USA)

Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints \| Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art, Gallery Wall, Berggruen Cie, Papiers Decoupes

IMPORTANT NOTE ON ORDERING: FRAMES ARE SOLD SEPARATELY. For US/Canada, please refer to the IMPERIAL SIZE when ordering (In inches). For all other markets, please refer to the METRIC SIZE when ordering (in CM). For example, if a print size is listed as "20x28 inches/50x70cm", you will receive a 20x28 inches print if you are in Canada/US, and you will receive a 50x70cm print if you are located in any other region. This is very important to keep note when picking a matching frame for your print.

►WORLDWIDE SHIPPING◄

\- Printed+shipped locally from CA/US/EU/UK/AU. 2-7 business day fast shipping to most countries without customs fees.

\- For urgent orders, overnight shipping upgrades are available. Please message me for a quote.

► PRODUCT DETAILS◄

\- This is a physical product. You will receive the fully printed + shipped art print.

\- Frames are sold separately.

\- Choose from 200gsm premium matte fine art paper or 200gsm silk fine art paper. Both are museum quality, FSC certified, and ethically sourced.

\- Premium matte paper reduces glare and fingerprint, which is great for hanging in bright areas. Premium silk paper has a slight sheen and is great for bringing out vibrancy in the artwork.

\- High-quality printing which produces fade-proof colors that last a lifetime.

► PLEASE NOTE◄

\- By default, the art goes all the way to the edge of the print, unless specifically shown framed by a border in the mockup photos. If you would like to add custom white borders, please message us ♥.

\- The colors may vary slightly from how they appear in person or how they display from one viewing device to another due to the color calibration of your device or monitor.

\- For vintage artworks, there may be textures on the artwork which are true to the original copy of work. These are not production errors. Texture is especially prominent on vintage oil painting or Japanese woodblock artwork.

\- This purchase is for personal use only. Not for resale or distribution.

\- Sugar&Canvas ©. All rights reserved.

► REFUND POLICY◄

For PHYSICAL ART PRINTS:

\- We accept returns within 30 days of receipt of your shipment for products that are damaged/incorrect. If either of these rare occurrences happens to you, please take a clear photo of the item(s) and send it to us. The shipping costs for returning the items will be fully covered by us in case of damaged/incorrect orders. In other scenarios, you will be responsible for paying for your own shipping costs for returning your item. Shipping costs are non-refundable. Please also note custom/personalized items are not eligible for returns.

\- If a package is returned due to an incorrect address/inaccessible delivery location/unpicked up items from the post office, additional shipping fees will incur for us to post the package back to you. A tracking number is provided with every order, please ensure to track your package closely.

► SIZES ◄

Our prints are available in the following sizes: 5x7 inches/13x18cm, 6x8 inches/15x20cm, 8x10 inches/20x25cm, 8x12 inches/21x30cm, 11x14 inches/27x35cm, 11x17 inches/28x43cm, 12x16 inches/30x40cm, 12x18 inches/30x45cm, 16x20 inches/40x50cm, 16x24 inches/40x60cm, 18x24 inches/45x60cm, 20x28 inches/50x70cm, 24x32 inches/60x80cm, 24x36 inches/60x90cm, 28x40 inches/70x100cm, 30x40 inches/75x100cm, A4 (21x29.7cm), A3 (29.7x42cm), A2 (42x59.4cm), A1 (59.4x84.1cm), A0 (84.1x118.9cm). (Please message me if you do not see the desired size listed in the individual listing).

Please visit our shop for more art prints:

[https://www.etsy.com/shop/sugarncanvas](https://www.etsy.com/shop/sugarncanvas)

Feel free to contact us if you have any questions! Thank you for stopping by! ♥

#M08, #M09


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-26**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 30 days


- Ships from: **Canada**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## FAQs

How will my art be packaged?


Premium matte paper prints are shipped flat for sizes up to A4. Larger prints are rolled inside a thick, high-strength tube or box to protect them against dust and moist during transit.


When will my order be processed and printed?


We normally process, print, and ship out your orders within 1-3 business days.


Where do you ship to and how long does it take?


We ship worldwide and the shipping time is 2-7 days for most countries. We ship domestically for CA/US/UK/EU/AU/NZ orders.

Sometimes we do experience further delays due to circumstances that are out of our control (natural disasters, holidays, customs delays, etc) that may cause shipping postponements. While most packages will arrive on time, there may be circumstances and delays that our carriers may experience.

If your item has not arrived within 30 days after you placed your order, please contact us and we will promptly take care of you.


How do I track my order?


We provide tracking for every order. We will provide tracking information in the shipping confirmation as soon as your order has shipped. However, please note that the tracking information sometimes may not update until your local post office receives our package. This is out of our control as to how frequently the shipping information is updated in the carrier's system.


Returns & Refund Policy


We allow returns/refunds within 30 days upon receiving your package.

1\. Damaged Prints: Please contact us immediately if you received a print that is incorrect or damaged. Please send us photos of the item and packaging upon receiving your package. In case of damaged/incorrect orders, the shipping costs for returning/replacing the items will be fully covered by us (or a full refund issued).

2\. Other scenarios: In other scenarios, you will be responsible for paying for your own shipping costs for returning your item. Shipping costs are non-refundable. Please ensure the item is returned in its original condition or you will be responsible for any loss in value.

3\. Custom / personalized items are not eligible for returns.


Can you do custom gift messaging or custom designs?


Our shop can do custom gift messaging for US/CA/UK/EU. Please message me directly for other custom requests such as custom design or printing, and we will assess the scope of the work and get back to you with a quote. Please do not include any custom requests or messaging in the checkout notes which we have not discussed prior, I cannot guarantee that they can be fulfilled. Thank you!


Sizing details


Our listing photos showcase artwork in their default aspect ratio of 3:4 which is applicable to print sizes such as 30x40cm/12x16 inches, 45x60cm/18x24 inches etc. We also offer various sizes in other aspect ratios such as 2:3, 4:5 or 5:7, and the image cropping may be slightly different than what is shown in the listing photos for these sizes. Border resizing and image cropping are necessary so we do not distort the artwork itself. Please also note there's a small +- 0.4cm trim area around the artwork that may be trimmed off during the production process. Rest assured, we professionally optimize every single image/artwork so they have the ideal cropping/trimming for every size and every aspect ratio.


There are textures and fades on my vintage artwork?


Please note for vintage artworks, there may be textures or "imperfections" on the artwork itself which are true to the original copy of work. We do not alter these as they are a part of the charm. These textures can range from paint splatters, canvas textures, or fades, and they are not due to production errors on our end. Texture is especially prominent on vintage oil painting or Japanese woodblock artwork. Please examine the product photos closely on zoom before ordering to see the textures up close.


Are there imported duty fees/tariffs?


We are not impacted by tariffs for US orders. Our prints are made and shipped locally from Canada/US/EU/UK/AU. 2-7 business day shipping to most countries without customs fees. If you are located outside of these regions, custom fees may incur depending on your country's regulations. Your order will be sent from the location closest to you.


## Be the first to review this item

No reviews yet. See what customers say about other items from this shop.


Read reviews for other items


[![SugarnCanvas](https://i.etsystatic.com/iusa/7007ec/83458823/iusa_75x75.83458823_tr83.jpg?version=0)](https://www.etsy.com/shop/SugarnCanvas?ref=shop_profile&listing_id=858615320)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[SugarnCanvas](https://www.etsy.com/shop/SugarnCanvas?ref=shop_profile&listing_id=858615320)

[Owned by Jen at sugarandcanvas.com](https://www.etsy.com/shop/SugarnCanvas?ref=shop_profile&listing_id=858615320) \|

Calgary, Canada

4.9
(3k)


17.7k sales

5 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=29542844&referring_id=858615320&referring_type=listing&recipient_id=29542844&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyOTU0Mjg0NDoxNzYyNzc0MzY0OmQxYjEwMDk2NTU0NWI5YmViYjNmYzVmZThmY2U5OWJl&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F858615320%2Fhenri-matisse-cut-outs-set-of-2-vintage%3Futm_source%3Dopenai)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

Loading recommendations

Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Aug 6, 2025


[65 favorites](https://www.etsy.com/listing/858615320/henri-matisse-cut-outs-set-of-2-vintage/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Prints](https://www.etsy.com/c/art-and-collectibles/prints?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Giclée](https://www.etsy.com/c/art-and-collectibles/prints/giclee?utm_source=openai&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Prints

[Classic Porsche 911 Framed Black & White Car Print Vintage Car Framed Art Rare Sports Car Wall Decor Porsche Car Poster](https://www.etsy.com/listing/1516095117/classic-porsche-911-framed-black-white) [Camp Site Battle Map](https://www.etsy.com/listing/1262545203/camp-site-battle-map-dnd-battle-map-dd) [Buy Wall Art Collection Online](https://www.etsy.com/market/wall_art_collection) [1964 Abstract Nativity Print by LionandLambVintage](https://www.etsy.com/listing/1736193375/1964-abstract-nativity-print-framed-and) [Galloping Horse Canvas Painting - Bold Animal Wall Art - Majestic Horse Decor Gift - Modern Equine Artwork by VIPCanvasBoutique](https://www.etsy.com/listing/1840998116/galloping-horse-canvas-painting-bold) [Minutemen Camo mascot PNG school spirit pride - Prints](https://www.etsy.com/listing/1791096197/minutemen-camo-mascot-png-school-spirit) [Abstract Ocean Digital Print Set of 2 by NouveauPrints](https://www.etsy.com/listing/4333832908/abstract-ocean-digital-print-set-of-2) [garretizumi](https://www.etsy.com/shop/garretizumi) [Shop Vintage Yacht Decor](https://www.etsy.com/market/vintage_yacht_decor) [Caroline Williams Art - US](https://www.etsy.com/market/caroline_williams_art) [Classroom Days in School Ten Frames Printable Display - Prints](https://www.etsy.com/listing/4328381341/classroom-days-in-school-ten-frames)

Drawing & Illustration

[Salt Life Sublimation for Sale](https://www.etsy.com/market/salt_life_sublimation)

Books

[Of the Garden - Books](https://www.etsy.com/listing/4336274814/vintage-cecily-mary-barker-childrens)

Car Parts & Accessories

[Buy Custom 3d License Plate Frame Online](https://www.etsy.com/market/custom_3d_license_plate_frame)

Womens Clothing

[Buy Us40 Jeans Online](https://www.etsy.com/market/us40_jeans)

Canvas & Surfaces

[The Homebody Club SVG PNG - Canvas & Surfaces](https://www.etsy.com/listing/1874616351/the-homebody-club-svg-png-homebody-png)

Party Supplies

[Shop 80th Birthday Water Bottle](https://www.etsy.com/market/80th_birthday_water_bottle)

Patterns & How To

[Harry Barnett for Sale](https://www.etsy.com/market/harry_barnett)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F858615320%2Fhenri-matisse-cut-outs-set-of-2-vintage%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc3NDM2NDowNzY3OWZhOGZiNjM0MDk2MDAyN2I1YjI0MWFjYTMyNg==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F858615320%2Fhenri-matisse-cut-outs-set-of-2-vintage%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/858615320/henri-matisse-cut-outs-set-of-2-vintage?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F858615320%2Fhenri-matisse-cut-outs-set-of-2-vintage%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for SugarnCanvas

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 1 hour of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


Customs and import taxes

Buyers are responsible for any customs and import taxes that may apply. I'm not responsible for delays due to customs.


## Seller details

### Business registration number

### Location

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=29542844&referring_id=24006786&referring_type=shop&recipient_id=29542844&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints | Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art, Gallery Wall, Berggruen Cie, Papiers Decoupes](https://i.etsystatic.com/24006786/r/il/d4bcbd/3249106649/il_300x300.3249106649_9fsq.jpg)
- ![Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints | Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art, Gallery Wall, Berggruen Cie, Papiers Decoupes](https://i.etsystatic.com/24006786/r/il/ae94cb/3201404816/il_300x300.3201404816_p822.jpg)
- ![Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints | Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art, Gallery Wall, Berggruen Cie, Papiers Decoupes](https://i.etsystatic.com/24006786/r/il/4f49a5/3249107233/il_300x300.3249107233_2563.jpg)
- ![Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints | Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art, Gallery Wall, Berggruen Cie, Papiers Decoupes](https://i.etsystatic.com/24006786/r/il/79111f/3249106651/il_300x300.3249106651_kne0.jpg)
- ![Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints | Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art, Gallery Wall, Berggruen Cie, Papiers Decoupes](https://i.etsystatic.com/24006786/r/il/a4b063/3249106653/il_300x300.3249106653_pvn4.jpg)
- ![Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints | Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art, Gallery Wall, Berggruen Cie, Papiers Decoupes](https://i.etsystatic.com/24006786/r/il/78d2a8/3201404534/il_300x300.3201404534_qrow.jpg)
- ![Henri Matisse Cut Outs Set of 2 Vintage Poster Beige Yellow Art Prints | Mid Century Modern, Minimalist Coral Abstract Neutral Wall Art, Gallery Wall, Berggruen Cie, Papiers Decoupes](https://i.etsystatic.com/24006786/r/il/b6ab80/3201404554/il_300x300.3201404554_bsg3.jpg)