[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/954731838/8-oz-soy-candle?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?utm_source=openai&explicit=1&ref=catnav_breadcrumb-3)

Etsy’s Pick

Etsy’s Picks are hand selected by our style experts to highlight items from shops that have shown quality, reliability and style.

[Discover More](https://www.etsy.com/featured/hub/etsy-picks?ref=listing_etsys_pick_signal)


Add to Favorites


- ![8 oz. Soy Candle image 1](https://i.etsystatic.com/24634047/r/il/abd227/3751531938/il_794xN.3751531938_9mhr.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![8 oz. Soy Candle image 2](https://i.etsystatic.com/24634047/r/il/46e3ff/3799124483/il_794xN.3799124483_fsms.jpg)
- ![8 oz. Soy Candle image 3](https://i.etsystatic.com/24634047/r/il/6323a7/3055095119/il_794xN.3055095119_hdnp.jpg)
- ![8 oz. Soy Candle image 4](https://i.etsystatic.com/24634047/r/il/94b1b2/4331087627/il_794xN.4331087627_1kf6.jpg)
- ![8 oz. Soy Candle image 5](https://i.etsystatic.com/24634047/r/il/039ba7/4331087631/il_794xN.4331087631_jlzv.jpg)
- ![8 oz. Soy Candle image 6](https://i.etsystatic.com/24634047/r/il/b55086/4331087635/il_794xN.4331087635_pin0.jpg)
- ![8 oz. Soy Candle image 7](https://i.etsystatic.com/24634047/r/il/d81eb4/4283697888/il_794xN.4283697888_nnod.jpg)
- ![8 oz. Soy Candle image 8](https://i.etsystatic.com/24634047/r/il/3db3e0/4283697892/il_794xN.4283697892_ivy2.jpg)
- ![8 oz. Soy Candle image 9](https://i.etsystatic.com/24634047/r/il/db78cb/4283698106/il_794xN.4283698106_ok7q.jpg)
- ![8 oz. Soy Candle image 10](https://i.etsystatic.com/24634047/r/il/cf2ee5/4331088549/il_794xN.4331088549_a324.jpg)

- ![8 oz. Soy Candle image 1](https://i.etsystatic.com/24634047/r/il/abd227/3751531938/il_75x75.3751531938_9mhr.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/6035706bf047438fa08d06ad6bdae1b1_tv0uup.jpg)

- ![8 oz. Soy Candle image 2](https://i.etsystatic.com/24634047/r/il/46e3ff/3799124483/il_75x75.3799124483_fsms.jpg)
- ![8 oz. Soy Candle image 3](https://i.etsystatic.com/24634047/r/il/6323a7/3055095119/il_75x75.3055095119_hdnp.jpg)
- ![8 oz. Soy Candle image 4](https://i.etsystatic.com/24634047/r/il/94b1b2/4331087627/il_75x75.4331087627_1kf6.jpg)
- ![8 oz. Soy Candle image 5](https://i.etsystatic.com/24634047/r/il/039ba7/4331087631/il_75x75.4331087631_jlzv.jpg)
- ![8 oz. Soy Candle image 6](https://i.etsystatic.com/24634047/r/il/b55086/4331087635/il_75x75.4331087635_pin0.jpg)
- ![8 oz. Soy Candle image 7](https://i.etsystatic.com/24634047/r/il/d81eb4/4283697888/il_75x75.4283697888_nnod.jpg)
- ![8 oz. Soy Candle image 8](https://i.etsystatic.com/24634047/r/il/3db3e0/4283697892/il_75x75.4283697892_ivy2.jpg)
- ![8 oz. Soy Candle image 9](https://i.etsystatic.com/24634047/r/il/db78cb/4283698106/il_75x75.4283698106_ok7q.jpg)
- ![8 oz. Soy Candle image 10](https://i.etsystatic.com/24634047/r/il/cf2ee5/4331088549/il_75x75.4331088549_a324.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F954731838%2F8-oz-soy-candle%23report-overlay-trigger)

Price:$14.00


Loading


# 8 oz. Soy Candle

Made by [HumbleHavenShop](https://www.etsy.com/shop/HumbleHavenShop)

Scent


Select an option

Vanilla

Pumpkin Pie

Christmas Tree

Cranberry Apple

Apple Maple Bourbon

Hot Apple Pie

Gingerbread

Mimosa

Hazelnut Coffee

Margarita

Fresh Coffee

Lemon Pound Cake

Brown Sugar & Fig

Dulce De Leche

Apple Cider Donut

Birthday Cake

Gummy Bear

Crème Brûlée

Snickerdoodle

Mango & Coconut Milk

Sea Salt

Lavender

Citrus Agave

Beach Linen

Georgia Peach

Citronella

Apricot Grove

Rose Petal Gelato

Magnolia & Peony

French Lilac

Coastal Plumeria

Autumn

Fallen Leaves

Please select an option


Quantity



12345678910111213

You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Made by [HumbleHavenShop](https://www.etsy.com/shop/HumbleHavenShop)

- Materials: Wax type: Soy


- Width: 3 inches

Height: 3.5 inches

All of our candles are hand-poured and made to order in Bozeman, MT! This candle is perfect for travel, gifts or for you to enjoy for yourself!

All candles are made with 100% natural soy wax.

Update: in an effort to not raise prices, candles will no longer come with a striking sticker under their lids.

Humble Haven candles are free from carcinogens, reproductive toxins, and other potentially hazardous chemicals often found in fragrance. We choose “Clean Scents” to create safer home candles that you and your family can enjoy with confidence.

To View Our Candle Menu & Scent Descriptions, click here: https://humblehavenblog.com/shop-my-haven/shop-hand-poured-candles/


## Shipping and return policies

Loading


- Order today to get by

**Nov 17-26**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges not accepted




But please contact me if you have problems with your order


- Ships from: **Bozeman, MT**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

## FAQs

How Often Should I Trim My Wick?


Every time you burn your candle. Trim the wick about 1/4" inch. Trimming the wick makes for a clean burn and the flame will look clean and bright. When wick trimming, ALWAYS extinguish the flame, allow the candle to come to room temperature, and trim the wick before relighting.


How Long Should I Let My Candle Burn Before Blowing It Out?


We recommend burning your candle for about two hours to get a full melt pool and no longer than four hours at a time. Exceeding this could cause safety issues.

If you don't let it burn long enough to form a full melt pool, you can cause issues with the candle tunneling in future burns.


## Reviews for this item (3)

Loading


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/950444/37200845/iusa_75x75.37200845_lzs3.jpg?version=0)

[cbrazil37](https://www.etsy.com/people/cbrazil37?ref=l_review)
Mar 26, 2021


The best smelling birthday cake candle I have ever smelled!



![](https://i.etsystatic.com/iusa/950444/37200845/iusa_75x75.37200845_lzs3.jpg?version=0)

[cbrazil37](https://www.etsy.com/people/cbrazil37?ref=l_review)
Mar 26, 2021


5 out of 5 stars
5

This item

[Shane Gerhardt](https://www.etsy.com/people/phxgugki?ref=l_review)
Mar 19, 2021


[Shane Gerhardt](https://www.etsy.com/people/phxgugki?ref=l_review)
Mar 19, 2021


5 out of 5 stars
5

This item

[Shane Gerhardt](https://www.etsy.com/people/phxgugki?ref=l_review)
Mar 19, 2021


[Shane Gerhardt](https://www.etsy.com/people/phxgugki?ref=l_review)
Mar 19, 2021


[![HumbleHavenShop](https://i.etsystatic.com/iusa/848f32/91131397/iusa_75x75.91131397_pgv7.jpg?version=0)](https://www.etsy.com/shop/HumbleHavenShop?ref=shop_profile&listing_id=954731838)

[HumbleHavenShop](https://www.etsy.com/shop/HumbleHavenShop?ref=shop_profile&listing_id=954731838)

[Owned by Ashley Rogina](https://www.etsy.com/shop/HumbleHavenShop?ref=shop_profile&listing_id=954731838) \|

Bozeman, Montana

[95 reviews](https://www.etsy.com/listing/954731838/8-oz-soy-candle?utm_source=openai#reviews)

301 sales

4 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=24467910&referring_id=954731838&referring_type=listing&recipient_id=24467910&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyNDQ2NzkxMDoxNzYyNzg1NjY0OmI0M2I3MjU0MTVhOTcxMzliNzE5YTY0OTUwMjZjM2I0&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F954731838%2F8-oz-soy-candle%3Futm_source%3Dopenai)

This seller usually responds **within a few hours.**

Loading recommendations

Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Oct 17, 2025


[3 favorites](https://www.etsy.com/listing/954731838/8-oz-soy-candle/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?utm_source=openai&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Home Decor

[Bigfoot Aquarium for Sale](https://www.etsy.com/market/bigfoot_aquarium) [Genuine Amethyst Crystal Cluster from Uruguay (1.5 lbs) by AstroGalleryOfGems](https://www.etsy.com/listing/997997215/genuine-amethyst-crystal-cluster-from) [Botanical Wall Decor for Home by HomeofEveCollection](https://www.etsy.com/listing/4295818401/pastel-pink-flower-garden-canvas-wall) [Keychain Bag Charm Gold Tone Plants Shelf Enamel Plant Lover](https://www.etsy.com/listing/4345637341/keychain-bag-charm-gold-tone-plants) [Bismuth Crystal Seahorse Carving 2.5 inches - Home Decor](https://www.etsy.com/listing/1832105660/bismuth-crystal-seahorse-carving-25) [Moroccan Style Kilim Throw Pillow Couch Cushion Cover for Vintage Style Rustic Boho Chic Living Room Home Decor - Home Decor](https://www.etsy.com/listing/1047202878/moroccan-style-kilim-throw-pillow-couch) [Volleyball Picture Frames - US](https://www.etsy.com/market/volleyball_picture_frames) [Natural Soy Wax Candle by TheWickAndBean](https://www.etsy.com/listing/1442513666/sugar-cookie-scented-soy-candle-natural) [Vintage Round Floral Tin Tray / Made in England Daher Tin / Floral Tray by TinaTreasureTrinkets](https://www.etsy.com/listing/1311970939/vintage-round-floral-tin-tray-made-in) [Buy Street Tiles Online](https://www.etsy.com/market/street_tiles) [Mary Willumsen for Sale](https://www.etsy.com/market/mary_willumsen) [Apples and Maple BOURBON Reserve Hand Poured Soy Wax Melts - Home Decor](https://www.etsy.com/listing/1697199493/apples-and-maple-bourbon-reserve-hand) [Shop Goddaughters Wedding Gift](https://www.etsy.com/market/goddaughters_wedding_gift) [Kilim Pillow Cases by KilimPillowOriental](https://www.etsy.com/listing/1254055774/kilim-pillow-cases-body-pillow-kilim)

Necklaces

[Buy Large Cross Pendants For Women Online](https://www.etsy.com/market/large_cross_pendants_for_women)

Kitchen & Dining

[Officially Debt Free Mug Finance Gift Mortgage Pay Off Loan Student Loan Paid in Full Coffee Mug Gift for Friend Housewarming Gift 004 by TheSummerCozy](https://www.etsy.com/listing/1887455083/officially-debt-free-mug-finance-gift)

Drawing & Illustration

[It's Ok To Not Be Ok PNG Unicorn Mental Health Awareness - Drawing & Illustration](https://www.etsy.com/listing/1826097736/its-ok-to-not-be-ok-png-unicorn-mental)

Fabric & Notions

[DELIGHTFUL DREAMS Teal Swirls by LvngdrmqltshpShop](https://www.etsy.com/listing/1805205864/delightful-dreams-teal-swirls)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F954731838%2F8-oz-soy-candle%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc4NTY2NDo0M2I3OTM2OWZjNWFiZTlhNDNmMWY4YTNhMmU3M2IwYw==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F954731838%2F8-oz-soy-candle%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/954731838/8-oz-soy-candle?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F954731838%2F8-oz-soy-candle%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![8 oz. Soy Candle image 1](https://i.etsystatic.com/24634047/r/il/abd227/3751531938/il_300x300.3751531938_9mhr.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/6035706bf047438fa08d06ad6bdae1b1_tv0uup.jpg)

- ![8 oz. Soy Candle image 2](https://i.etsystatic.com/24634047/r/il/46e3ff/3799124483/il_300x300.3799124483_fsms.jpg)
- ![8 oz. Soy Candle image 3](https://i.etsystatic.com/24634047/r/il/6323a7/3055095119/il_300x300.3055095119_hdnp.jpg)
- ![8 oz. Soy Candle image 4](https://i.etsystatic.com/24634047/r/il/94b1b2/4331087627/il_300x300.4331087627_1kf6.jpg)
- ![8 oz. Soy Candle image 5](https://i.etsystatic.com/24634047/r/il/039ba7/4331087631/il_300x300.4331087631_jlzv.jpg)
- ![8 oz. Soy Candle image 6](https://i.etsystatic.com/24634047/r/il/b55086/4331087635/il_300x300.4331087635_pin0.jpg)
- ![8 oz. Soy Candle image 7](https://i.etsystatic.com/24634047/r/il/d81eb4/4283697888/il_300x300.4283697888_nnod.jpg)
- ![8 oz. Soy Candle image 8](https://i.etsystatic.com/24634047/r/il/3db3e0/4283697892/il_300x300.4283697892_ivy2.jpg)
- ![8 oz. Soy Candle image 9](https://i.etsystatic.com/24634047/r/il/db78cb/4283698106/il_300x300.4283698106_ok7q.jpg)
- ![8 oz. Soy Candle image 10](https://i.etsystatic.com/24634047/r/il/cf2ee5/4331088549/il_300x300.4331088549_a324.jpg)