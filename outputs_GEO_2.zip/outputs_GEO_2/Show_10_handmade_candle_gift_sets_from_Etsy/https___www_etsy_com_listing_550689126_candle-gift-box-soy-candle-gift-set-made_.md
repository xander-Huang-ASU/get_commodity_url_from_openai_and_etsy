[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/550689126/candle-gift-box-soy-candle-gift-set-made?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?utm_source=openai&explicit=1&ref=catnav_breadcrumb-3)
- [Container Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/container-candles?utm_source=openai&explicit=1&ref=catnav_breadcrumb-4)

Etsy’s Pick

Etsy’s Picks are hand selected by our style experts to highlight items from shops that have shown quality, reliability and style.

[Discover More](https://www.etsy.com/featured/hub/etsy-picks?ref=listing_etsys_pick_signal)


Add to Favorites


- ![May include: Two soy candles in glass jars with gold lids. The larger jar is labeled 'HOPSCOTCH SOY CANDLE HAND POURED IN LONDON CEDAR PINE 280G'. The smaller jar is labeled 'HOPSCOTCH SOY CANDLE HAND POURED IN LONDON FIG MELON 100G'. Both jars are sitting on a white surface. The smaller jar is in a white box with a black ribbon and the words 'HOPSCOTCH' printed on the ribbon.](https://i.etsystatic.com/9637459/r/il/9e7885/1322630048/il_794xN.1322630048_mqab.jpg)
- ![May include: A glass jar candle with a gold lid. The label reads 'HOPSCOTCH', 'SOY CANDLE', 'HAND POURED IN LONDON', 'CEDAR + PINE', and '260g'.](https://i.etsystatic.com/9637459/r/il/f240c2/1369902107/il_794xN.1369902107_qe46.jpg)
- ![May include: A silver candle tin with a white label that reads 'HOPSCOTCH', 'SOY CANDLE', 'HAND POURED IN LONDON', 'FIG + MELON', and '100g'. The lid is off and sitting next to the tin.](https://i.etsystatic.com/9637459/r/il/376652/1322629990/il_794xN.1322629990_1r3f.jpg)
- ![May include: A white square box with a black ribbon tied in a bow on top. The ribbon has the text 'HOPSCOTCH.' printed on it.](https://i.etsystatic.com/9637459/r/il/f0a532/1757254315/il_794xN.1757254315_tph5.jpg)
- ![May include: A close-up of multiple white candles in clear glass jars with wooden clothespins holding the wicks in place. The candles are arranged in rows on a white surface.](https://i.etsystatic.com/9637459/r/il/7c5d28/1659844533/il_794xN.1659844533_igjp.jpg)
- ![May include: A white gift box with a black ribbon tied in a bow. The ribbon has the text 'HOPSCOTCH' printed on it.](https://i.etsystatic.com/9637459/r/il/fd5b23/1369904265/il_794xN.1369904265_gtyw.jpg)

- ![May include: Two soy candles in glass jars with gold lids. The larger jar is labeled 'HOPSCOTCH SOY CANDLE HAND POURED IN LONDON CEDAR PINE 280G'. The smaller jar is labeled 'HOPSCOTCH SOY CANDLE HAND POURED IN LONDON FIG MELON 100G'. Both jars are sitting on a white surface. The smaller jar is in a white box with a black ribbon and the words 'HOPSCOTCH' printed on the ribbon.](https://i.etsystatic.com/9637459/r/il/9e7885/1322630048/il_75x75.1322630048_mqab.jpg)
- ![May include: A glass jar candle with a gold lid. The label reads 'HOPSCOTCH', 'SOY CANDLE', 'HAND POURED IN LONDON', 'CEDAR + PINE', and '260g'.](https://i.etsystatic.com/9637459/r/il/f240c2/1369902107/il_75x75.1369902107_qe46.jpg)
- ![May include: A silver candle tin with a white label that reads 'HOPSCOTCH', 'SOY CANDLE', 'HAND POURED IN LONDON', 'FIG + MELON', and '100g'. The lid is off and sitting next to the tin.](https://i.etsystatic.com/9637459/r/il/376652/1322629990/il_75x75.1322629990_1r3f.jpg)
- ![May include: A white square box with a black ribbon tied in a bow on top. The ribbon has the text 'HOPSCOTCH.' printed on it.](https://i.etsystatic.com/9637459/r/il/f0a532/1757254315/il_75x75.1757254315_tph5.jpg)
- ![May include: A close-up of multiple white candles in clear glass jars with wooden clothespins holding the wicks in place. The candles are arranged in rows on a white surface.](https://i.etsystatic.com/9637459/r/il/7c5d28/1659844533/il_75x75.1659844533_igjp.jpg)
- ![May include: A white gift box with a black ribbon tied in a bow. The ribbon has the text 'HOPSCOTCH' printed on it.](https://i.etsystatic.com/9637459/r/il/fd5b23/1369904265/il_75x75.1369904265_gtyw.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F550689126%2Fcandle-gift-box-soy-candle-gift-set-made%23report-overlay-trigger)

Price:$49.42


Loading


# Candle Gift Box — Soy Candle Gift Set Made in the UK — perfect present for her, gift for sister, gift for mum, thank you gift

Designed by [HopscotchLondon](https://www.etsy.com/shop/HopscotchLondon)

[5 out of 5 stars](https://www.etsy.com/listing/550689126/candle-gift-box-soy-candle-gift-set-made?utm_source=openai#reviews)

Returns & exchanges accepted

Scent Combination


Select an option

Bestsellers

Festive

Zesty

Please select an option


From **$17/month**, or 4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Designed by [HopscotchLondon](https://www.etsy.com/shop/HopscotchLondon)

Our Candle Gift Box includes a duo of our signature candles.

Hand-poured in London, our large candle comes in a beautiful glass jar topped with a gold metal screw top lid. Our mini tin candles are perfect for travelling with, so you can take your candle with you wherever you go.

All of our candles are made from the finest soy wax, which burns cleaner and longer than standard paraffin wax. We use cotton wicks and high quality fragrance oils.

Our large candles contain 260g of soy wax, which have a burn time of around 60 hours. Our mini tin candles contain 100g of wax and have a burn time of around 25 hours.

Our Candle Gift Box is available in 3 scent combinations

Bestsellers: Large Cedar + Pine and Mini Fig + Melon

Festive: Large Spiced Apple and Mini Cedar + Pine

Zesty: Large Bergamot and Mini Citrus + Sandalwood

Both candles are presented in a luxury white gift box, hand tied with a branded black ribbon — ready for gift giving.

\-\-\-------------------------------------------------------------------------------------------

For more information visit us at hopscotchlondon.com

Hopscotch is a design led lifestyle store based in London.


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-29**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 30 days


- Ships from: **United Kingdom**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (2)

Loading


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/5f6050/69509950/iusa_75x75.69509950_gb5h.jpg?version=0)

[Sara Ani](https://www.etsy.com/people/sara2uloh?ref=l_review)
Dec 16, 2019


shipped on time : )



![](https://i.etsystatic.com/iusa/5f6050/69509950/iusa_75x75.69509950_gb5h.jpg?version=0)

[Sara Ani](https://www.etsy.com/people/sara2uloh?ref=l_review)
Dec 16, 2019


5 out of 5 stars
5

This item

[Nicole Morello](https://www.etsy.com/people/nikkimorello?ref=l_review)
Dec 14, 2020


[Nicole Morello](https://www.etsy.com/people/nikkimorello?ref=l_review)
Dec 14, 2020


[![HopscotchLondon](https://i.etsystatic.com/iusa/02fb9f/40263075/iusa_75x75.40263075_fr4u.jpg?version=0)](https://www.etsy.com/shop/HopscotchLondon?ref=shop_profile&listing_id=550689126)

[HopscotchLondon](https://www.etsy.com/shop/HopscotchLondon?ref=shop_profile&listing_id=550689126)

[Owned by hopscotchlondon](https://www.etsy.com/shop/HopscotchLondon?ref=shop_profile&listing_id=550689126) \|

London, United Kingdom

5.0
(922)


7.1k sales

11 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=47638046&referring_id=550689126&referring_type=listing&recipient_id=47638046&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo0NzYzODA0NjoxNzYyNzg1NzU0OjVjMjdjMjE4ODBiNGRkZDVlZjA4YjhkNDFlMjRlYzJm&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F550689126%2Fcandle-gift-box-soy-candle-gift-set-made%3Futm_source%3Dopenai)

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## All reviews from this shop (922)

Show all

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

## More from this shop

[Visit shop](https://www.etsy.com/shop/HopscotchLondon?ref=lp_mys_mfts)

- [![Lavender Scented Candle — Hopscotch Candle — Home Decor Soy Candle — Perfect Gift for Her, Wedding Gift, Gift for Mum or Thank You Gift](https://i.etsystatic.com/9637459/c/530/421/33/98/il/ae8b17/722354132/il_340x270.722354132_hkpn.jpg)\\
\\
**Lavender Scented Candle — Hopscotch Candle — Home Decor Soy Candle — Perfect Gift for Her, Wedding Gift, Gift for Mum or Thank You Gift**\\
\\
$24.71\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/221310955/lavender-scented-candle-hopscotch-candle?click_key=4ae0e7440c6ebeb9abc924134b2b5727%3ALT14eecfc13dae9dbfc7711c1805c022a81af36038&click_sum=65837da2&ls=r&ref=related-1&content_source=4ae0e7440c6ebeb9abc924134b2b5727%253ALT14eecfc13dae9dbfc7711c1805c022a81af36038 "Lavender Scented Candle — Hopscotch Candle — Home Decor Soy Candle — Perfect Gift for Her, Wedding Gift, Gift for Mum or Thank You Gift")




Add to Favorites


- [![Bergamot Scented Candle — Hopscotch Candle — Home Decor Soy Candle — Perfect Gift for Her, Wedding Gift, Gift for Mum or Thank You Gift](https://i.etsystatic.com/9637459/r/il/1c6adc/923474493/il_340x270.923474493_szdd.jpg)\\
\\
**Bergamot Scented Candle — Hopscotch Candle — Home Decor Soy Candle — Perfect Gift for Her, Wedding Gift, Gift for Mum or Thank You Gift**\\
\\
$24.71\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/268580110/bergamot-scented-candle-hopscotch-candle?click_key=4ae0e7440c6ebeb9abc924134b2b5727%3ALT1630fe714f2a0c416125bdd61e2c2c3061f90dc5&click_sum=26b479cf&ls=r&ref=related-2&content_source=4ae0e7440c6ebeb9abc924134b2b5727%253ALT1630fe714f2a0c416125bdd61e2c2c3061f90dc5 "Bergamot Scented Candle — Hopscotch Candle — Home Decor Soy Candle — Perfect Gift for Her, Wedding Gift, Gift for Mum or Thank You Gift")




Add to Favorites


- [![Lavender Scented Vegan Candle — Hopscotch Candle Mini — Hand-poured 100% Soy Wax Container Candle](https://i.etsystatic.com/9637459/r/il/0ea82a/882535458/il_340x270.882535458_jddn.jpg)\\
\\
**Lavender Scented Vegan Candle — Hopscotch Candle Mini — Hand-poured 100% Soy Wax Container Candle**\\
\\
$19.22\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/221310531/lavender-scented-vegan-candle-hopscotch?click_key=4ae0e7440c6ebeb9abc924134b2b5727%3ALT3804aa11fadbb91c8ec17f1bab41823edb3bdab3&click_sum=56f559d3&ls=r&ref=related-3&content_source=4ae0e7440c6ebeb9abc924134b2b5727%253ALT3804aa11fadbb91c8ec17f1bab41823edb3bdab3 "Lavender Scented Vegan Candle — Hopscotch Candle Mini — Hand-poured 100% Soy Wax Container Candle")




Add to Favorites


- [![Nourish Body Oil — Cruelty Free, Vegan Skincare, Made in the UK — Perfect Gift for Her, Gift for Mum, Wedding Gift or Thank You Gift](https://i.etsystatic.com/9637459/r/il/b032ba/1266782221/il_340x270.1266782221_l1rd.jpg)\\
\\
**Nourish Body Oil — Cruelty Free, Vegan Skincare, Made in the UK — Perfect Gift for Her, Gift for Mum, Wedding Gift or Thank You Gift**\\
\\
$30.20\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/494434687/nourish-body-oil-cruelty-free-vegan?click_key=3a805225f5582c6b9b6b939f2fe04179831465ae%3A494434687&click_sum=29fece7d&ref=related-4 "Nourish Body Oil — Cruelty Free, Vegan Skincare, Made in the UK — Perfect Gift for Her, Gift for Mum, Wedding Gift or Thank You Gift")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Oct 11, 2025


[82 favorites](https://www.etsy.com/listing/550689126/candle-gift-box-soy-candle-gift-set-made/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Container Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/container-candles?utm_source=openai&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Home Decor

[Hourglass Anniversary Gift - US](https://www.etsy.com/market/hourglass_anniversary_gift) [Shop Elk Metal Wall Decor](https://www.etsy.com/market/elk_metal_wall_decor) [Coffee is a good idea - Home Decor](https://www.etsy.com/listing/4340147078/coffee-is-a-good-idea-sign-framed-diy) [Buy Family Roots Picture Frame Online](https://www.etsy.com/market/family_roots_picture_frame) [Nursery Decor](https://www.etsy.com/listing/1593236549/nursery-decor-throw-pillow-for-nursery) [Buy Wooden Dad Son Hunting Ornament Online](https://www.etsy.com/market/wooden_dad_son_hunting_ornament) [Buy Large Outdoor Letter K Online](https://www.etsy.com/market/large_outdoor_letter_k) [Cute Farmhouse Decor by HappyPigStore](https://www.etsy.com/listing/4342066951/whimsical-pig-soy-candle-cute-farmhouse) [Smoky Mountains (Smoked Hickory - Home Decor](https://www.etsy.com/listing/1836314501/smoky-mountains-smoked-hickory-fraser) [Steampunk/Christmas Sponge Coral Spider - Home Decor](https://www.etsy.com/listing/1397792729/steampunkchristmas-sponge-coral-spider) [Shop Nowell Tree Base](https://www.etsy.com/market/nowell_tree_base) [Expansive Night Sky Over Mountain Range Wall Art Canvas Print](https://www.etsy.com/listing/1854781279/expansive-night-sky-over-mountain-range)

Prints

[Vintage Downtown Los Angeles Map : 1940s Down Town Los Angeles Map - Archival DTLA Map Print - Giclee Print](https://www.etsy.com/listing/716865964/vintage-downtown-los-angeles-map-1940s)

Canvas & Surfaces

[MintyMarshmallows - US](https://www.etsy.com/shop/MintyMarshmallows)

Womens Shoes

[Shop Ukrainian Red Boots](https://www.etsy.com/market/ukrainian_red_boots)

Womens Clothing

[Vintage Karen Scott Velvet Holiday Snowman Womens Petite Medium Vest](https://www.etsy.com/listing/1884297812/vintage-karen-scott-velvet-holiday) [Banarasi katan by tussar silk by BholiByVartika](https://www.etsy.com/listing/4304574767/banarasi-katan-by-tussar-silk)

Necklaces

[Aromatherapy Charm for Sale](https://www.etsy.com/market/aromatherapy_charm)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F550689126%2Fcandle-gift-box-soy-candle-gift-set-made%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc4NTc1NDo4MmQxNjM1ZDlkMzQ5MDAzNWVmMDgxY2IyMzQyNDZmNg==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F550689126%2Fcandle-gift-box-soy-candle-gift-set-made%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/550689126/candle-gift-box-soy-candle-gift-set-made?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F550689126%2Fcandle-gift-box-soy-candle-gift-set-made%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for HopscotchLondon

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 1 hour of purchase

### Shipping policies

All orders are gift wrapped in white tissue, and we can add a gift note for you too.

—

Most order are posted using Royal Mail, and you can choose an expedited delivery upgrade at checkout. We aim to dispatch orders within 1–3 working days.

Delivery aims after dispatch:

• UK Standard (free): 2–3 working days

• UK Express: 1–2 working days

• Europe: 5–7 working days

• USA: Around 10 working days, but this could be slightly longer with current USPS service delays

• Rest of the World: 7–10 working days

Please note these are estimates given by the Royal Mail and are not guaranteed. If you require an item urgently, please get in touch with us before ordering. Working days for the Royal Mail Monday–Friday exc public holidays. Please bare in mind that COVID-19 is still causing some extra delays in some areas where Royal Mail are stretched, so delivery times may be longer than expected. Thanks for your patience.

Ordering a gift? You can get your order sent to any address, and we can add a gift note inside the parcel too — just let us know at checkout. Gifts will be wrapped in tissue.

Less

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


You can pay via Etsy's direct checkout using your debit or credit card, PayPal or an Etsy gift card.

More

### Additional policies

You can contact us directly by emailing: info \[at\] hopscotchlondon.com

Please remember that colours may vary from what you see on your screen as all monitors and screens are different.

Less

## Seller details

### Other details

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=47638046&referring_id=9637459&referring_type=shop&recipient_id=47638046&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: Two soy candles in glass jars with gold lids. The larger jar is labeled 'HOPSCOTCH SOY CANDLE HAND POURED IN LONDON CEDAR PINE 280G'. The smaller jar is labeled 'HOPSCOTCH SOY CANDLE HAND POURED IN LONDON FIG MELON 100G'. Both jars are sitting on a white surface. The smaller jar is in a white box with a black ribbon and the words 'HOPSCOTCH' printed on the ribbon.](https://i.etsystatic.com/9637459/r/il/9e7885/1322630048/il_300x300.1322630048_mqab.jpg)
- ![May include: A glass jar candle with a gold lid. The label reads 'HOPSCOTCH', 'SOY CANDLE', 'HAND POURED IN LONDON', 'CEDAR + PINE', and '260g'.](https://i.etsystatic.com/9637459/r/il/f240c2/1369902107/il_300x300.1369902107_qe46.jpg)
- ![May include: A silver candle tin with a white label that reads 'HOPSCOTCH', 'SOY CANDLE', 'HAND POURED IN LONDON', 'FIG + MELON', and '100g'. The lid is off and sitting next to the tin.](https://i.etsystatic.com/9637459/r/il/376652/1322629990/il_300x300.1322629990_1r3f.jpg)
- ![May include: A white square box with a black ribbon tied in a bow on top. The ribbon has the text 'HOPSCOTCH.' printed on it.](https://i.etsystatic.com/9637459/r/il/f0a532/1757254315/il_300x300.1757254315_tph5.jpg)
- ![May include: A close-up of multiple white candles in clear glass jars with wooden clothespins holding the wicks in place. The candles are arranged in rows on a white surface.](https://i.etsystatic.com/9637459/r/il/7c5d28/1659844533/il_300x300.1659844533_igjp.jpg)
- ![May include: A white gift box with a black ribbon tied in a bow. The ribbon has the text 'HOPSCOTCH' printed on it.](https://i.etsystatic.com/9637459/r/il/fd5b23/1369904265/il_300x300.1369904265_gtyw.jpg)

Scroll previousScroll next