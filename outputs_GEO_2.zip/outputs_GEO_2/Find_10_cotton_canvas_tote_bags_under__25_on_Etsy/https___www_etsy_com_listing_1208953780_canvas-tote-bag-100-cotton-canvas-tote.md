[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1208953780/canvas-tote-bag-100-cotton-canvas-tote#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Bags & Purses](https://www.etsy.com/c/bags-and-purses?explicit=1&ref=catnav_breadcrumb-0)
- [Totes](https://www.etsy.com/c/bags-and-purses/totes?explicit=1&ref=catnav_breadcrumb-1)


Add to Favorites


- ![May include: A set of six blank tote bags hanging on a rack. The bags are made of canvas and are available in a variety of colors, including pink, purple, blue, white, black, and red.](https://i.etsystatic.com/7907929/r/il/c58f06/3885994665/il_794xN.3885994665_o41t.jpg)
- ![May include: Four tote bags hanging on hooks. The bags are made of canvas and are in different colors: purple, light blue, white, and black. The bags have long handles and are empty.](https://i.etsystatic.com/7907929/r/il/6bc639/3838519708/il_794xN.3838519708_m555.jpg)
- ![May include: A white canvas tote bag filled with craft supplies including a pink cutting mat, fabric scraps, embroidery floss, a measuring tape, and a wooden embroidery hoop.](https://i.etsystatic.com/7907929/r/il/b6248e/3838519822/il_794xN.3838519822_i4r7.jpg)
- ![May include: A beige canvas tote bag with a vintage travel poster design featuring a beach scene with a yellow, orange, and red surfboard. The poster text reads 'Malibu, California'.](https://i.etsystatic.com/7907929/r/il/32f380/3886032431/il_794xN.3886032431_ie87.jpg)
- ![May include: A white canvas tote bag with the words 'THREADART CANVAS TOTE SIZING' in black text at the top of the image. The bag is 17 inches tall, 14.5 inches wide, and 3 inches deep.](https://i.etsystatic.com/7907929/r/il/1e4834/3838531724/il_794xN.3838531724_grmx.jpg)
- ![May include: A white canvas tote bag with a natural cotton texture. The bag has two long handles and is shown against a white background. The bag is surrounded by green icons that highlight its features: eco-friendly reusable, strong handles, ideal length handles for max carry capacity, and strong stitching for durability.](https://i.etsystatic.com/7907929/r/il/5fd3a6/3838532078/il_794xN.3838532078_3e05.jpg)
- ![May include: A light blue canvas tote bag with the word 'BEACH' in pink letters with gold glitter. The bag is filled with a pink blanket and two stuffed animals.](https://i.etsystatic.com/7907929/r/il/756559/3838519928/il_794xN.3838519928_8irr.jpg)
- ![May include: A purple tote bag made of canvas with two handles. The bag is empty and has a plain design.](https://i.etsystatic.com/7907929/r/il/f265ab/3838522750/il_794xN.3838522750_akmd.jpg)
- ![May include: A light pink canvas tote bag with two handles.](https://i.etsystatic.com/7907929/r/il/d3697a/3886025611/il_794xN.3886025611_3tnw.jpg)
- ![May include: A light blue tote bag with two handles. The bag is made of canvas and has a simple design.](https://i.etsystatic.com/7907929/r/il/0a0d41/3886028967/il_794xN.3886028967_mf6k.jpg)

- ![May include: A set of six blank tote bags hanging on a rack. The bags are made of canvas and are available in a variety of colors, including pink, purple, blue, white, black, and red.](https://i.etsystatic.com/7907929/r/il/c58f06/3885994665/il_75x75.3885994665_o41t.jpg)
- ![May include: Four tote bags hanging on hooks. The bags are made of canvas and are in different colors: purple, light blue, white, and black. The bags have long handles and are empty.](https://i.etsystatic.com/7907929/r/il/6bc639/3838519708/il_75x75.3838519708_m555.jpg)
- ![May include: A white canvas tote bag filled with craft supplies including a pink cutting mat, fabric scraps, embroidery floss, a measuring tape, and a wooden embroidery hoop.](https://i.etsystatic.com/7907929/r/il/b6248e/3838519822/il_75x75.3838519822_i4r7.jpg)
- ![May include: A beige canvas tote bag with a vintage travel poster design featuring a beach scene with a yellow, orange, and red surfboard. The poster text reads 'Malibu, California'.](https://i.etsystatic.com/7907929/r/il/32f380/3886032431/il_75x75.3886032431_ie87.jpg)
- ![May include: A white canvas tote bag with the words 'THREADART CANVAS TOTE SIZING' in black text at the top of the image. The bag is 17 inches tall, 14.5 inches wide, and 3 inches deep.](https://i.etsystatic.com/7907929/r/il/1e4834/3838531724/il_75x75.3838531724_grmx.jpg)
- ![May include: A white canvas tote bag with a natural cotton texture. The bag has two long handles and is shown against a white background. The bag is surrounded by green icons that highlight its features: eco-friendly reusable, strong handles, ideal length handles for max carry capacity, and strong stitching for durability.](https://i.etsystatic.com/7907929/r/il/5fd3a6/3838532078/il_75x75.3838532078_3e05.jpg)
- ![May include: A light blue canvas tote bag with the word 'BEACH' in pink letters with gold glitter. The bag is filled with a pink blanket and two stuffed animals.](https://i.etsystatic.com/7907929/r/il/756559/3838519928/il_75x75.3838519928_8irr.jpg)
- ![May include: A purple tote bag made of canvas with two handles. The bag is empty and has a plain design.](https://i.etsystatic.com/7907929/r/il/f265ab/3838522750/il_75x75.3838522750_akmd.jpg)
- ![May include: A light pink canvas tote bag with two handles.](https://i.etsystatic.com/7907929/r/il/d3697a/3886025611/il_75x75.3886025611_3tnw.jpg)
- ![May include: A light blue tote bag with two handles. The bag is made of canvas and has a simple design.](https://i.etsystatic.com/7907929/r/il/0a0d41/3886028967/il_75x75.3886028967_mf6k.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1208953780%2Fcanvas-tote-bag-100-cotton-canvas-tote%23report-overlay-trigger)

Price:$8.99


Loading


# Canvas Tote Bag, 100% Cotton Canvas Tote Bags, Screen Printing Bags, HTV Bags, DTF Bags, DIY Bag, Blank Canvas Bag

Designed by [ThreadArt1](https://www.etsy.com/shop/ThreadArt1)

[5 out of 5 stars](https://www.etsy.com/listing/1208953780/canvas-tote-bag-100-cotton-canvas-tote#reviews)

Arrives soon! Get it by

Nov 14-19


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

Primary color


Select a color

White

Black

Periwinkle

Red

Coral

Navy

Light Aqua

Natural

Please select a color


Quantity



123456789101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899100

You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Designed by [ThreadArt1](https://www.etsy.com/shop/ThreadArt1)

- Materials: Canvas



- Gift wrapping available

See details![](https://i.etsystatic.com/igwp/2193f5/3973381767/igwp_300xN.3973381767_l0jwgqgi.jpg?version=0)

Gift wrapping by ThreadArt1

ThreadArt beautifully packages gifts in reusable metallic gift bags. Oversized items (20" or more) will decorated with a large bow instead of bag.

Premium 100% cotton canvas totes for durability and long life. Perfect for books. Not an inferior poly cotton blend like competitors. Strong 10oz fabric and with plenty of space for stuffing this bag with all your items at the store or books. Super strong handles can hold up to a 50lb load. Large sized 14.5"x17"x3"

We use a premium and thick 10 ounce fabric with precise heavyweight stitching throughout, including cross-stitching at the handles for maximum strength and durability

Easy to decorate using hot fix rhinestones, fabric markers, acrylic fabric paint, iron-on transfers, stencils, or Heat Transfer Vinyl (HTV). Make your tote your own with a creative customized design or name! Our canvas is very easy to make great embroidery designs. They are so easy to hoop and the strong fabric results in really perfect stitch outs.

Machine washable and durable. Don't worry about those stains. Just toss your tote in the laundry and it will look good as new. Reusable hundreds of times and years of use. Eco friendly 100% natural cotton is biodegradable.

Heavy duty stitching is used throughout the bag. Cross stitching at the handles provides exceptional strength and durability. Our foldable shopping bags are compact and take up minimal space in your home when not using them. Perfect size for grocery trips but you can also use these for all your carrying needs


### Production partners

ThreadArt1 makes this item with help from


ThreadArt, Tomball, TX


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-19**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 30 days


- Ships from: **Tomball, TX**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (2)

5.0/5

item average

5.0Item quality

5.0Shipping

100%
Buyers recommend

Loading


5 out of 5 stars
5

This item

[Jamie](https://www.etsy.com/people/tim1123?ref=l_review)
Jan 25, 2025


Seemed sturdy but a bit small for what I was going to them for. Good material used. Thanks



[Jamie](https://www.etsy.com/people/tim1123?ref=l_review)
Jan 25, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/b7536a/99143709/iusa_75x75.99143709_6g4x.jpg?version=0)

[Sarah Bush](https://www.etsy.com/people/z5o95oa5y8lbn4vw?ref=l_review)
Jun 13, 2024


Great quality and arrived on time! Can’t wait to bedazzle it with pins and buttons ☺️



![](https://i.etsystatic.com/iusa/b7536a/99143709/iusa_75x75.99143709_6g4x.jpg?version=0)

[Sarah Bush](https://www.etsy.com/people/z5o95oa5y8lbn4vw?ref=l_review)
Jun 13, 2024


[![ThreadArt1](https://i.etsystatic.com/iusa/099a28/112209377/iusa_75x75.112209377_9x2p.jpg?version=0)](https://www.etsy.com/shop/ThreadArt1?ref=shop_profile&listing_id=1208953780)

[ThreadArt1](https://www.etsy.com/shop/ThreadArt1?ref=shop_profile&listing_id=1208953780)

[Owned by ThreadArt Shop](https://www.etsy.com/shop/ThreadArt1?ref=shop_profile&listing_id=1208953780) \|

Cypress, Texas

4.8
(3.3k)


22k sales

10 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=31226432&referring_id=1208953780&referring_type=listing&recipient_id=31226432&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDozMTIyNjQzMjoxNzYyNzgyMDAxOjk2NzAxNzlhNjY0MzBjNmY2NWE5MmZlZTRjYjg4ZDU3&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1208953780%2Fcanvas-tote-bag-100-cotton-canvas-tote)

This seller usually responds **within 24 hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

## More from this shop

[Visit shop](https://www.etsy.com/shop/ThreadArt1?ref=lp_mys_mfts)

- [![Blank Canvas Tote Bags, Women Bag, Women Shoulder Bag, Canvas Cotton Handbag, Natural Tote Bag, 100% Cotton Canvas Tote Bags](https://i.etsystatic.com/7907929/r/il/dc7b8a/5926881060/il_340x270.5926881060_1wds.jpg)\\
\\
**Blank Canvas Tote Bags, Women Bag, Women Shoulder Bag, Canvas Cotton Handbag, Natural Tote Bag, 100% Cotton Canvas Tote Bags**\\
\\
$8.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/861020918/blank-canvas-tote-bags-women-bag-women?click_key=ec9cae368290f227074c3597ed6314c5%3ALT742111ce69073ecf85edffcab04c3a0d7465eb16&click_sum=31972b66&ls=r&ref=related-1&content_source=ec9cae368290f227074c3597ed6314c5%253ALT742111ce69073ecf85edffcab04c3a0d7465eb16 "Blank Canvas Tote Bags, Women Bag, Women Shoulder Bag, Canvas Cotton Handbag, Natural Tote Bag, 100% Cotton Canvas Tote Bags")




Add to Favorites


- [![Blank Cotton Canvas MakeUp Bags - Plain, For DIY, Make Your Own](https://i.etsystatic.com/7907929/r/il/1fd82e/3838554822/il_340x270.3838554822_ntbm.jpg)\\
\\
**Blank Cotton Canvas MakeUp Bags - Plain, For DIY, Make Your Own**\\
\\
$6.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1208963104/blank-cotton-canvas-makeup-bags-plain?click_key=ec9cae368290f227074c3597ed6314c5%3ALT0d75f2d50310eb41368a5f2205c0109d33a5fd66&click_sum=5fa9f224&ls=r&ref=related-2&content_source=ec9cae368290f227074c3597ed6314c5%253ALT0d75f2d50310eb41368a5f2205c0109d33a5fd66 "Blank Cotton Canvas MakeUp Bags - Plain, For DIY, Make Your Own")




Add to Favorites


- [![Color Your Own Tote Bag - Flower Design - With Fabric Markers](https://i.etsystatic.com/7907929/r/il/e79bb1/5167172624/il_340x270.5167172624_5ygi.jpg)\\
\\
**Color Your Own Tote Bag - Flower Design - With Fabric Markers**\\
\\
$15.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1459543026/color-your-own-tote-bag-flower-design?click_key=ec9cae368290f227074c3597ed6314c5%3ALT99d4d61a540a43fba99f5a255ae8bd86d18c07e6&click_sum=2c27d974&ls=r&ref=related-3&content_source=ec9cae368290f227074c3597ed6314c5%253ALT99d4d61a540a43fba99f5a255ae8bd86d18c07e6 "Color Your Own Tote Bag - Flower Design - With Fabric Markers")




Add to Favorites


- [![Personalized Pouch Bag: Colorful RicRac With Multicolor Embroidery - Zipper Closure](https://i.etsystatic.com/7907929/r/il/bd794e/7327132802/il_340x270.7327132802_8a1u.jpg)\\
\\
**Personalized Pouch Bag: Colorful RicRac With Multicolor Embroidery - Zipper Closure**\\
\\
$18.98\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4393292049/personalized-pouch-bag-colorful-ricrac?click_key=5e336116233a95f2814035510ae6f6870d81e4ea%3A4393292049&click_sum=a5906e14&ref=related-4 "Personalized Pouch Bag: Colorful RicRac With Multicolor Embroidery - Zipper Closure")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Jul 15, 2025


[12 favorites](https://www.etsy.com/listing/1208953780/canvas-tote-bag-100-cotton-canvas-tote/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?explicit=1&ref=breadcrumb_listing) [Totes](https://www.etsy.com/c/bags-and-purses/totes?explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Home Decor

[Mashaallah Wall Art - US](https://www.etsy.com/market/mashaallah_wall_art)

Shopping

[Shop Womens Pink Reading Glasses](https://www.etsy.com/market/womens_pink_reading_glasses)

Drawing & Illustration

[Gardening Life 20oz Skinny Tumbler Wrap - Drawing & Illustration](https://www.etsy.com/listing/1838415337/gardening-life-20oz-skinny-tumbler-wrap) [Orange and Gold Abstract Stripes Backgrounds](https://www.etsy.com/listing/1489065988/orange-and-gold-abstract-stripes)

Paper

[Buy Goalie Greeting Card Online](https://www.etsy.com/market/goalie_greeting_card) [Shop Kiss Cut Stickers](https://www.etsy.com/market/kiss_cut_stickers)

Gender Neutral Adult Clothing

[Custom Name Drip Halloween Baseball Jersey](https://www.etsy.com/listing/4338803898/custom-name-drip-halloween-baseball) [Underwater Superhero Muscle Tattoos Costume Shirt Cosplay Tight Fitting Easy Halloween Purim Triton Merman Tribal](https://www.etsy.com/listing/880585871/underwater-superhero-muscle-tattoos) [Book Club Sweatshirt](https://www.etsy.com/listing/1881135322/book-club-sweatshirt-bibliophile-bookish)

Spirituality & Religion

[Skinwalker Spell - US](https://www.etsy.com/market/skinwalker_spell)

Accessories

[Lavender pocket boutonniere Dried lavender boutonniere Purple corsage Floral bow ties for men Groomsmen gifts set Rustic wedding boutonniere](https://www.etsy.com/listing/4305713717/lavender-pocket-boutonniere-dried)

Kitchen & Dining

[Vintage 70’s Tablecloth with crocheted accents](https://www.etsy.com/listing/4345113989/vintage-70s-tablecloth-with-crocheted)

Canvas & Surfaces

[Buy Megalodon Monster Truck Svg Online](https://www.etsy.com/market/megalodon_monster_truck_svg)

Collectibles

[WinCraft San Francisco 49ers The Golden Connection Pennant](https://www.etsy.com/listing/4317534188/wincraft-san-francisco-49ers-the-golden)

Invitations & Paper

[Funny Wedding RSVP Template](https://www.etsy.com/listing/1387768950/funny-wedding-rsvp-template-printable)

Patterns & How To

[Horse applique embroidery design](https://www.etsy.com/listing/1503511949/horse-applique-embroidery-design-derby)

Rings

[Bicolor Art Deco Baguette Ring by rockstiffart](https://www.etsy.com/listing/4304568153/unique-watermelon-tourmaline-engagement)

Fabric & Notions

[Shop Gym Wear Lycra](https://www.etsy.com/market/gym_wear_lycra)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1208953780%2Fcanvas-tote-bag-100-cotton-canvas-tote&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc4MjAwMTphMjViNGI0ZWMzOTAyZWVmYTBjM2JiMGFiMzlkZjBlOQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1208953780%2Fcanvas-tote-bag-100-cotton-canvas-tote) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1208953780/canvas-tote-bag-100-cotton-canvas-tote#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1208953780%2Fcanvas-tote-bag-100-cotton-canvas-tote)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for ThreadArt1

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: not accepted

Please contact the seller if you have any problems with your order.

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## Seller details

### Business registration number

### Location

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=31226432&referring_id=7907929&referring_type=shop&recipient_id=31226432&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: A set of six blank tote bags hanging on a rack. The bags are made of canvas and are available in a variety of colors, including pink, purple, blue, white, black, and red.](https://i.etsystatic.com/7907929/r/il/c58f06/3885994665/il_300x300.3885994665_o41t.jpg)
- ![May include: Four tote bags hanging on hooks. The bags are made of canvas and are in different colors: purple, light blue, white, and black. The bags have long handles and are empty.](https://i.etsystatic.com/7907929/r/il/6bc639/3838519708/il_300x300.3838519708_m555.jpg)
- ![May include: A white canvas tote bag filled with craft supplies including a pink cutting mat, fabric scraps, embroidery floss, a measuring tape, and a wooden embroidery hoop.](https://i.etsystatic.com/7907929/r/il/b6248e/3838519822/il_300x300.3838519822_i4r7.jpg)
- ![May include: A beige canvas tote bag with a vintage travel poster design featuring a beach scene with a yellow, orange, and red surfboard. The poster text reads 'Malibu, California'.](https://i.etsystatic.com/7907929/r/il/32f380/3886032431/il_300x300.3886032431_ie87.jpg)
- ![May include: A white canvas tote bag with the words 'THREADART CANVAS TOTE SIZING' in black text at the top of the image. The bag is 17 inches tall, 14.5 inches wide, and 3 inches deep.](https://i.etsystatic.com/7907929/r/il/1e4834/3838531724/il_300x300.3838531724_grmx.jpg)
- ![May include: A white canvas tote bag with a natural cotton texture. The bag has two long handles and is shown against a white background. The bag is surrounded by green icons that highlight its features: eco-friendly reusable, strong handles, ideal length handles for max carry capacity, and strong stitching for durability.](https://i.etsystatic.com/7907929/r/il/5fd3a6/3838532078/il_300x300.3838532078_3e05.jpg)
- ![May include: A light blue canvas tote bag with the word 'BEACH' in pink letters with gold glitter. The bag is filled with a pink blanket and two stuffed animals.](https://i.etsystatic.com/7907929/r/il/756559/3838519928/il_300x300.3838519928_8irr.jpg)
- ![May include: A purple tote bag made of canvas with two handles. The bag is empty and has a plain design.](https://i.etsystatic.com/7907929/r/il/f265ab/3838522750/il_300x300.3838522750_akmd.jpg)
- ![May include: A light pink canvas tote bag with two handles.](https://i.etsystatic.com/7907929/r/il/d3697a/3886025611/il_300x300.3886025611_3tnw.jpg)
- ![May include: A light blue tote bag with two handles. The bag is made of canvas and has a simple design.](https://i.etsystatic.com/7907929/r/il/0a0d41/3886028967/il_300x300.3886028967_mf6k.jpg)