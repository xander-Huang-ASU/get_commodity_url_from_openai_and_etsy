[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/497503010/tiny-niobium-stud-earrings-perfect-for?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Jewelry](https://www.etsy.com/c/jewelry?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Earrings](https://www.etsy.com/c/jewelry/earrings?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Stud Earrings](https://www.etsy.com/c/jewelry/earrings/stud-earrings?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)


Add to Favorites


- ![May include: Five small round studs in different colors are arranged in a line on a fleshy earlobe. The studs are pink, blue, blue, gold, and brown.](https://i.etsystatic.com/9169319/r/il/23ce5c/1139694682/il_794xN.1139694682_kiik.jpg)
- ![May include: Six small metal tacks with rounded heads in different colors: pink, blue, light blue, brown, gold, and yellow. The tacks are arranged in a row on a white textured surface.](https://i.etsystatic.com/9169319/r/il/fdd610/1185939299/il_794xN.1185939299_kna9.jpg)
- ![May include: Three small metal pins with colored tops. One pin has a pink top, one has a blue top, and one has a light blue top.](https://i.etsystatic.com/9169319/r/il/b4dfb0/1186435481/il_794xN.1186435481_4hla.jpg)
- ![May include: Six pairs of small, round, metal earrings in various colors: blue, purple, gold, brown, and two shades of blue. The earrings are displayed on a light brown wooden surface.](https://i.etsystatic.com/9169319/r/il/573f39/1139812538/il_794xN.1139812538_ictr.jpg)

- ![May include: Five small round studs in different colors are arranged in a line on a fleshy earlobe. The studs are pink, blue, blue, gold, and brown.](https://i.etsystatic.com/9169319/c/921/732/0/314/il/23ce5c/1139694682/il_75x75.1139694682_kiik.jpg)
- ![May include: Six small metal tacks with rounded heads in different colors: pink, blue, light blue, brown, gold, and yellow. The tacks are arranged in a row on a white textured surface.](https://i.etsystatic.com/9169319/r/il/fdd610/1185939299/il_75x75.1185939299_kna9.jpg)
- ![May include: Three small metal pins with colored tops. One pin has a pink top, one has a blue top, and one has a light blue top.](https://i.etsystatic.com/9169319/r/il/b4dfb0/1186435481/il_75x75.1186435481_4hla.jpg)
- ![May include: Six pairs of small, round, metal earrings in various colors: blue, purple, gold, brown, and two shades of blue. The earrings are displayed on a light brown wooden surface.](https://i.etsystatic.com/9169319/r/il/573f39/1139812538/il_75x75.1139812538_ictr.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F497503010%2Ftiny-niobium-stud-earrings-perfect-for%23report-overlay-trigger)

Only 8 left and in 3 carts

Price:$19.99+


Loading


# Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!

[SweetLobes](https://www.etsy.com/shop/SweetLobes?ref=shop-header-name&listing_id=497503010&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/497503010/tiny-niobium-stud-earrings-perfect-for?utm_source=openai#reviews)

Arrives soon! Get it by

Nov 14-19


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Single or Pair?


Select an option

SINGLE (one earring) ($19.99)

PAIR (two earrings) ($36.99)

Please select an option


Color


Select an option

Rose

Dark Blue

Light Blue

Bronze

Gold

Please select an option


Quantity



12345678

You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Buy together, get free shipping

## Buy together, get free shipping

Add both to cart



Loading


[See more items](https://www.etsy.com/listing/497503010/tiny-niobium-stud-earrings-perfect-for?utm_source=openai#recs_ribbon_container)

![Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!](https://i.etsystatic.com/9169319/c/921/732/0/314/il/23ce5c/1139694682/il_340x270.1139694682_kiik.jpg)
This listing

### Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!

$19.99


Add to Favorites


[![Tiny Stud Post Earrings, Niobium Relief Studs in Green, Purple, or Teal; Single or Pair, 2mm Nickel Free Studs - Lobes, Cartilage](https://i.etsystatic.com/9169319/c/1009/801/0/250/il/185b30/1570339790/il_340x270.1570339790_n3ct.jpg)\\
\\
**Tiny Stud Post Earrings, Niobium Relief Studs in Green, Purple, or Teal; Single or Pair, 2mm Nickel Free Studs - Lobes, Cartilage**\\
\\
$19.99](https://www.etsy.com/listing/239777823/tiny-stud-post-earrings-niobium-relief?click_key=5beba2e499b8194d7a3057d9135718e8%3ALT93395468517e2f73b95db7c74ad031d54fb24f81&click_sum=524cc90d&ls=r&ref=listing-free-shipping-bundle-1&sts=1&content_source=5beba2e499b8194d7a3057d9135718e8%253ALT93395468517e2f73b95db7c74ad031d54fb24f81 "Tiny Stud Post Earrings, Niobium Relief Studs in Green, Purple, or Teal; Single or Pair, 2mm Nickel Free Studs - Lobes, Cartilage")


Add to Favorites


![Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!](https://i.etsystatic.com/9169319/c/921/732/0/314/il/23ce5c/1139694682/il_340x270.1139694682_kiik.jpg)
This listing

### Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!

$19.99


Add to Favorites


[![Tiny Stud Post Earrings, Niobium Relief Studs in Green, Purple, or Teal; Single or Pair, 2mm Nickel Free Studs - Lobes, Cartilage](https://i.etsystatic.com/9169319/c/1009/801/0/250/il/185b30/1570339790/il_340x270.1570339790_n3ct.jpg)\\
\\
**Tiny Stud Post Earrings, Niobium Relief Studs in Green, Purple, or Teal; Single or Pair, 2mm Nickel Free Studs - Lobes, Cartilage**\\
\\
$19.99](https://www.etsy.com/listing/239777823/tiny-stud-post-earrings-niobium-relief?click_key=5beba2e499b8194d7a3057d9135718e8%3ALT93395468517e2f73b95db7c74ad031d54fb24f81&click_sum=524cc90d&ls=r&ref=listing-free-shipping-bundle-1&sts=1&content_source=5beba2e499b8194d7a3057d9135718e8%253ALT93395468517e2f73b95db7c74ad031d54fb24f81 "Tiny Stud Post Earrings, Niobium Relief Studs in Green, Purple, or Teal; Single or Pair, 2mm Nickel Free Studs - Lobes, Cartilage")


Add to Favorites


![Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!](https://i.etsystatic.com/9169319/c/921/732/0/314/il/23ce5c/1139694682/il_340x270.1139694682_kiik.jpg)
This listing

### Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!

$19.99


Add to Favorites


[![Tiny Stud Post Earrings, Niobium Relief Studs in Green, Purple, or Teal; Single or Pair, 2mm Nickel Free Studs - Lobes, Cartilage](https://i.etsystatic.com/9169319/c/1009/801/0/250/il/185b30/1570339790/il_340x270.1570339790_n3ct.jpg)\\
\\
**Tiny Stud Post Earrings, Niobium Relief Studs in Green, Purple, or Teal; Single or Pair, 2mm Nickel Free Studs - Lobes, Cartilage**\\
\\
$19.99](https://www.etsy.com/listing/239777823/tiny-stud-post-earrings-niobium-relief?click_key=5beba2e499b8194d7a3057d9135718e8%3ALT93395468517e2f73b95db7c74ad031d54fb24f81&click_sum=524cc90d&ls=r&ref=listing-free-shipping-bundle-1&sts=1&content_source=5beba2e499b8194d7a3057d9135718e8%253ALT93395468517e2f73b95db7c74ad031d54fb24f81 "Tiny Stud Post Earrings, Niobium Relief Studs in Green, Purple, or Teal; Single or Pair, 2mm Nickel Free Studs - Lobes, Cartilage")


Add to Favorites


## Item details

### Highlights

Made by [SweetLobes](https://www.etsy.com/shop/SweetLobes)

- Materials: USA Anodized Niobium, Silicone Ear Nuts

- Location: Earlobe

- Closure: Push back

- Style: Minimalist

- Made to Order


Practically EVERYone can wear Niobium...even people with sensitivities to gold, silver, or even titanium. Niobium is the least likely metal to cause an allergic reaction and is the best option for even the most sensitive ears. And these little studs are so CUTE!

~Hypoallergenic, 100% lead-, latex-, and nickel-free niobium posts

~Includes snug-fitting silicone backs

~Tiny, flat, 2 mm heads (photos are extreme closeups)

~21 gauge posts

~Posts are approx. 10 mm long (Need a different length? Just let me know!)

~Handcrafted in the USA

~Sweetly packaged for gift giving

~All sales are final on pierced items (click "view shop policies" for details), so please ensure that you understand the post gauge (thickness) and head size of this stud and ask questions before your purchase if you aren't certain. I'm happy to help if I can!

The colors of anodized niobium are essentially a patina - chemically stable and won't fade over time, always a good thing. ;)

Matching hoops available here: [https://www.etsy.com/listing/616996767/niobium-nose-ring-in-8-colors-your?ref=shop\_home\_active\_1](https://www.etsy.com/listing/616996767/niobium-nose-hoop-or-cartilage-hoop?ref=shop_home_active_1)

Available in gunmetal (natural color of niobium) here: [https://www.etsy.com/listing/237233183/single-or-pair-tiny-stud-post-earrings?ref=shop\_home\_active\_1](https://www.etsy.com/listing/237233183/niobium-tiny-stud-post-earrings-grey?ref=shop_home_active_1)

Green, Purple, and Teal too...click here! [https://www.etsy.com/listing/239777823/tiny-stud-post-earrings-niobium-relief?ref=shop\_home\_active\_14](https://www.etsy.com/listing/239777823/tiny-stud-post-earrings-niobium-relief?ref=shop_home_active_14)

QUESTIONS?

Just click the "Message Bobbie" button, and I'll get back to you ASAP.

Thank you for shopping at Sweet Lobes!

©2021 Sweet Lobes. All rights reserved. All content and photos in this shop are the property of and copyrighted by Sweet Lobes and may not be copied, altered, or otherwise used in any form without written permission from Sweet Lobes.


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-19**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges not accepted




But please contact me if you have problems with your order


- Ships from: **Hagerstown, IN**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## FAQs

Jewelry Storage Tips


1\. Always remove the cotton padding from any gift box before using it for jewelry storage, as it can cause even fine jewelry to oxidize/tarnish over time.

2\. Ensure your jewelry is clean and dry before storing.

3\. Protect your clean jewelry from chemicals and oxidation by storing it inside a plastic baggie when not in use.

4\. Do not store or lay your jewelry in the bathroom for extended periods, as moisture, humidity, and chemicals can tarnish or corrode any metal.


Returns and Exchanges?


For health/sanitary reasons, Sweet Lobes accepts returns on non-pierced items only. Pierced items (nose, ear, body jewelry) cannot be returned or exchanged. This is a matter of integrity as a business owner to protect my customers and is a common practice among reputable sellers in the body jewelry industry.

Personally, I do not purchase pierced items from retailers who do accept returns, as I don't want to risk receiving an item that was someone else's returned item. Every item from Sweet Lobes is guaranteed to be brand new, never worn or previously inserted.

Please read the item description carefully before purchasing, as buying pierced jewelry can be tricky. I'm happy to answer all questions to ensure your experience is perfect!


## Reviews for this item (91)

5.0/5

item average

5.0Item quality

5.0Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Fast shipping

Cute

Love it

Well packaged

As described

Comfortable

Perfect size


Filter by category


Shipping & Packaging (30)


Comfort (25)


Appearance (15)


Description accuracy (13)


Seller service (13)


Quality (10)


Sizing & Fit (2)


Ease of use (1)


Condition (1)


Value (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/d396a2/106786156/iusa_75x75.106786156_n535.jpg?version=0)

[Dez Fortin](https://www.etsy.com/people/dezfortin?ref=l_review)
Oct 13, 2025


They came earlier than expected! I needed these for my little one because she was experiencing a pretty bad reaction to the usual piercing jewelry!



![Dez Fortin added a photo of their purchase](https://i.etsystatic.com/iap/a65639/7282778962/iap_300x300.7282778962_s4zu7131.jpg?version=0)

![](https://i.etsystatic.com/iusa/d396a2/106786156/iusa_75x75.106786156_n535.jpg?version=0)

[Dez Fortin](https://www.etsy.com/people/dezfortin?ref=l_review)
Oct 13, 2025


![](https://i.etsystatic.com/iusa/4f1a26/32845063/iusa_75x75.32845063_r5ke.jpg?version=0)

Response from Bobbie

Thank you, Dez! The niobium will calm her sore ears down better than anything you can buy, so you made a great choice!



5 out of 5 stars
5

This item

[Stephanie](https://www.etsy.com/people/to395txv?ref=l_review)
May 7, 2025


Beautiful earrings!



[Stephanie](https://www.etsy.com/people/to395txv?ref=l_review)
May 7, 2025


![](https://i.etsystatic.com/iusa/4f1a26/32845063/iusa_75x75.32845063_r5ke.jpg?version=0)

Response from Bobbie

I'm glad you like them, Stephanie, thank you! I've worn niobium for years, and I LOVE it! Never loses it's color, and so comfortable. :)



5 out of 5 stars
5

This item

[Mary](https://www.etsy.com/people/bravemary?ref=l_review)
Mar 3, 2025


Wonderful as always. Cute packaging.



[Mary](https://www.etsy.com/people/bravemary?ref=l_review)
Mar 3, 2025


![](https://i.etsystatic.com/iusa/4f1a26/32845063/iusa_75x75.32845063_r5ke.jpg?version=0)

Response from Bobbie

Thank you, Mary! Enjoy those pretty little studs! :)



5 out of 5 stars
5

This item

[Cynthia Chew](https://www.etsy.com/people/flooper626?ref=l_review)
Jan 3, 2025


Perfect for sensitive ears. I may buy a backup pair.



[Cynthia Chew](https://www.etsy.com/people/flooper626?ref=l_review)
Jan 3, 2025


![](https://i.etsystatic.com/iusa/4f1a26/32845063/iusa_75x75.32845063_r5ke.jpg?version=0)

Response from Bobbie

I agree, Cynthia! Can't do better than niobium for sore, sensitive, or healing ears! My personal favorite. :) Thank you for your feedback!



View all reviews for this item

### Photos from reviews

![Dez added a photo of their purchase](https://i.etsystatic.com/iap/a65639/7282778962/iap_300x300.7282778962_s4zu7131.jpg?version=0)

![kukisan1 added a photo of their purchase](https://i.etsystatic.com/iap/323419/6212655109/iap_300x300.6212655109_ksv208lr.jpg?version=0)

![Veronica added a photo of their purchase](https://i.etsystatic.com/iap/1fba2d/5115037011/iap_300x300.5115037011_seglr5zc.jpg?version=0)

![Dalya added a photo of their purchase](https://i.etsystatic.com/iap/7ee7dc/4266721705/iap_300x300.4266721705_o7c6r8rd.jpg?version=0)

![Dafna added a photo of their purchase](https://i.etsystatic.com/iap/2f9704/3015840034/iap_300x300.3015840034_qjefan6f.jpg?version=0)

![Dafna added a photo of their purchase](https://i.etsystatic.com/iap/273362/3033149533/iap_300x300.3033149533_ttiicy17.jpg?version=0)

[![SweetLobes](https://i.etsystatic.com/iusa/4f1a26/32845063/iusa_75x75.32845063_r5ke.jpg?version=0)](https://www.etsy.com/shop/SweetLobes?ref=shop_profile&listing_id=497503010)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[SweetLobes](https://www.etsy.com/shop/SweetLobes?ref=shop_profile&listing_id=497503010)

[Owned by Bobbie](https://www.etsy.com/shop/SweetLobes?ref=shop_profile&listing_id=497503010) \|

Indiana, United States

4.9
(6.8k)


36.4k sales

11 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=44394053&referring_id=497503010&referring_type=listing&recipient_id=44394053&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo0NDM5NDA1MzoxNzYyNzgwNTM3OjM4OTRhYWNjOGVlMmZjMDIwNWFiM2IxZTE2YzVhZTQ0&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F497503010%2Ftiny-niobium-stud-earrings-perfect-for%3Futm_source%3Dopenai)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/SweetLobes?ref=lp_mys_mfts)

- [![Tiny Stud Post Earrings, Niobium Relief Studs in Green, Purple, or Teal; Single or Pair, 2mm Nickel Free Studs - Lobes, Cartilage](https://i.etsystatic.com/9169319/c/1009/801/0/250/il/185b30/1570339790/il_340x270.1570339790_n3ct.jpg)\\
\\
**Tiny Stud Post Earrings, Niobium Relief Studs in Green, Purple, or Teal; Single or Pair, 2mm Nickel Free Studs - Lobes, Cartilage**\\
\\
$19.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/239777823/tiny-stud-post-earrings-niobium-relief?click_key=0915e9d0f02ab11c6034d848f8ba2fc1%3ALTaf34101ec1db9d8d431ae5708a0d28131a6298ff&click_sum=7ce784b1&ls=r&ref=related-1&sts=1&content_source=0915e9d0f02ab11c6034d848f8ba2fc1%253ALTaf34101ec1db9d8d431ae5708a0d28131a6298ff "Tiny Stud Post Earrings, Niobium Relief Studs in Green, Purple, or Teal; Single or Pair, 2mm Nickel Free Studs - Lobes, Cartilage")




Add to Favorites


- [![Niobium Tiny Stud Post Earrings, Grey Niobium Relief Studs, Womens or Mens Earrings - Hypoallergenic Lobe or Cartilage Stud Earrings](https://i.etsystatic.com/9169319/c/1000/794/0/399/il/cebab0/1624874755/il_340x270.1624874755_jgym.jpg)\\
\\
**Niobium Tiny Stud Post Earrings, Grey Niobium Relief Studs, Womens or Mens Earrings - Hypoallergenic Lobe or Cartilage Stud Earrings**\\
\\
$19.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/237233183/niobium-tiny-stud-post-earrings-grey?click_key=0915e9d0f02ab11c6034d848f8ba2fc1%3ALTd45aefadb81009eb9160db05798c8bc04e9d462c&click_sum=9c15a9a8&ls=r&ref=related-2&sts=1&content_source=0915e9d0f02ab11c6034d848f8ba2fc1%253ALTd45aefadb81009eb9160db05798c8bc04e9d462c "Niobium Tiny Stud Post Earrings, Grey Niobium Relief Studs, Womens or Mens Earrings - Hypoallergenic Lobe or Cartilage Stud Earrings")




Add to Favorites


- [![Titanium Earring Backs; Nickel-Free, Hypoallergenic Ear Nuts for Standard Posts, Small but Sturdy - Buy More Save More, Made in USA!](https://i.etsystatic.com/9169319/c/859/682/194/110/il/becd92/2096289390/il_340x270.2096289390_5g2y.jpg)\\
\\
**Titanium Earring Backs; Nickel-Free, Hypoallergenic Ear Nuts for Standard Posts, Small but Sturdy - Buy More Save More, Made in USA!**\\
\\
$5.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/487357622/titanium-earring-backs-nickel-free?click_key=0915e9d0f02ab11c6034d848f8ba2fc1%3ALT2b3bdf5a49262e7795448d3307398e33a7409069&click_sum=1eeb59b4&ls=r&ref=related-3&sts=1&content_source=0915e9d0f02ab11c6034d848f8ba2fc1%253ALT2b3bdf5a49262e7795448d3307398e33a7409069 "Titanium Earring Backs; Nickel-Free, Hypoallergenic Ear Nuts for Standard Posts, Small but Sturdy - Buy More Save More, Made in USA!")




Add to Favorites


- [![Gold Nose Stud - Small, 14k Gold Filled Nose Ring, 22g Gold Nose Screw, L-Bend, Straight, or Fishtail -  Made in the USA](https://i.etsystatic.com/9169319/c/1518/1205/0/146/il/d27b49/1558351654/il_340x270.1558351654_5a8d.jpg)\\
\\
**Gold Nose Stud - Small, 14k Gold Filled Nose Ring, 22g Gold Nose Screw, L-Bend, Straight, or Fishtail - Made in the USA**\\
\\
$24.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/627215489/gold-nose-stud-small-14k-gold-filled?click_key=3cd16a9bef83fafcbab8422cd286dd16d39359f7%3A627215489&click_sum=11de0022&ref=related-4&sts=1 "Gold Nose Stud - Small, 14k Gold Filled Nose Ring, 22g Gold Nose Screw, L-Bend, Straight, or Fishtail -  Made in the USA")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Oct 13, 2025


[569 favorites](https://www.etsy.com/listing/497503010/tiny-niobium-stud-earrings-perfect-for/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Jewelry](https://www.etsy.com/c/jewelry?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Earrings](https://www.etsy.com/c/jewelry/earrings?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Stud Earrings](https://www.etsy.com/c/jewelry/earrings/stud-earrings?utm_source=openai&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Mens Clothing

[Shop Gold Plaid Shirts](https://www.etsy.com/market/gold_plaid_shirts)

Books

[Adult Joi Scripts for Sale](https://www.etsy.com/market/adult_joi_scripts)

Girls Clothing

[Shop Cruella Kids Costume](https://www.etsy.com/market/cruella_kids_costume)

Gender Neutral Adult Shoes

[Soccer Slip On Shoes - US](https://www.etsy.com/market/soccer_slip_on_shoes)

Gender Neutral Adult Clothing

[Mtv Sweater for Sale](https://www.etsy.com/market/mtv_sweater)

Blanks

[Ring Setting For Ashes for Sale](https://www.etsy.com/market/ring_setting_for_ashes)

Earrings

[14K Solid Gold Solitaire Diamond Internally Threaded Earring Moissanite Bezel Cartilage Helix Tragus Stud Screw Back Flat Back Earring 18g](https://www.etsy.com/listing/1601012826/14k-solid-gold-solitaire-diamond) [Geometric Sunburst Design](https://www.etsy.com/listing/4316473982/gold-fan-burst-stud-earrings-bold-retro) [Resin Crescent Moon Starburst Charm Crystal Gemstone by MysticEmpressDesigns](https://www.etsy.com/listing/1688424055/resin-crescent-moon-starburst-charm) [Blue Mirror Football Earrings - Earrings](https://www.etsy.com/listing/1786530312/blue-mirror-football-earrings-football) [Handmade Southwestern Round Turtle Multicolor Inlay & Sterling Silver Dangle Earrings/ Ocean Beach Earrings/Made in USA by Lovelyturquoise](https://www.etsy.com/listing/810647098/handmade-southwestern-round-turtle)

Paper

[Buy Love My Aussiedoodle Online](https://www.etsy.com/market/love_my_aussiedoodle)

Home Decor

[Kaiser Bell - US](https://www.etsy.com/market/kaiser_bell) [Wooden name sign](https://www.etsy.com/listing/1509452621/wooden-name-sign-wooden-letters-name)

Home Improvement

[Shop Mcm Drawer Pulls Furniture](https://www.etsy.com/market/mcm_drawer_pulls_furniture)

Spirituality & Religion

[Joan Of Arc Tenner - Saint Michael - Bronze and leather - Pocket Rosary - Spirituality & Religion](https://www.etsy.com/listing/1399143645/joan-of-arc-tenner-saint-michael-bronze)

Shopping

[Buy Lenox J Cup Online](https://www.etsy.com/market/lenox_j_cup)

Glass Art

[Stain Glass Crab Window Hangings for Sale](https://www.etsy.com/market/stain_glass_crab_window_hangings)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F497503010%2Ftiny-niobium-stud-earrings-perfect-for%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc4MDUzNzo1MjhiZDJmMTIxNjU1NzllMDQ4NzM3ZDY1ODFkZTRjZA==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F497503010%2Ftiny-niobium-stud-earrings-perfect-for%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/497503010/tiny-niobium-stud-earrings-perfect-for?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F497503010%2Ftiny-niobium-stud-earrings-perfect-for%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for SweetLobes

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: before item has shipped

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: Five small round studs in different colors are arranged in a line on a fleshy earlobe. The studs are pink, blue, blue, gold, and brown.](https://i.etsystatic.com/9169319/c/921/921/0/220/il/23ce5c/1139694682/il_300x300.1139694682_kiik.jpg)
- ![May include: Six small metal tacks with rounded heads in different colors: pink, blue, light blue, brown, gold, and yellow. The tacks are arranged in a row on a white textured surface.](https://i.etsystatic.com/9169319/r/il/fdd610/1185939299/il_300x300.1185939299_kna9.jpg)
- ![May include: Three small metal pins with colored tops. One pin has a pink top, one has a blue top, and one has a light blue top.](https://i.etsystatic.com/9169319/r/il/b4dfb0/1186435481/il_300x300.1186435481_4hla.jpg)
- ![May include: Six pairs of small, round, metal earrings in various colors: blue, purple, gold, brown, and two shades of blue. The earrings are displayed on a light brown wooden surface.](https://i.etsystatic.com/9169319/r/il/573f39/1139812538/il_300x300.1139812538_ictr.jpg)

- ![](https://i.etsystatic.com/iap/a65639/7282778962/iap_640x640.7282778962_s4zu7131.jpg?version=0)

5 out of 5 stars

- Single or Pair?:

PAIR (two earrings)

- Color:

Light Blue


They came earlier than expected! I needed these for my little one because she was experiencing a pretty bad reaction to the usual piercing jewelry!

![](https://i.etsystatic.com/iusa/d396a2/106786156/iusa_75x75.106786156_n535.jpg?version=0)

Oct 13, 2025


[Dez Fortin](https://www.etsy.com/people/dezfortin)

Purchased item:

[![Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!](https://i.etsystatic.com/9169319/c/921/732/0/314/il/23ce5c/1139694682/il_170x135.1139694682_kiik.jpg)\\
\\
Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!\\
\\
$19.99](https://www.etsy.com/listing/497503010/tiny-niobium-stud-earrings-perfect-for?ref=ap-listing)

Purchased item:

[![Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!](https://i.etsystatic.com/9169319/c/921/732/0/314/il/23ce5c/1139694682/il_170x135.1139694682_kiik.jpg)\\
\\
Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!\\
\\
$19.99](https://www.etsy.com/listing/497503010/tiny-niobium-stud-earrings-perfect-for?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/323419/6212655109/iap_640x640.6212655109_ksv208lr.jpg?version=0)

5 out of 5 stars

- Single or Pair?:

SINGLE (one earring)

- Color:

Gold


This earring is exactly as described but the feeling of relief I experienced the next morning, when I slept with this in was immense. Thank you so much for offering quality materials that still allow me to decorate my ears as I want. Will definitely be back!!

![](https://i.etsystatic.com/iusa/61913c/38033392/iusa_75x75.38033392_5o96.jpg?version=0)

Jul 31, 2024


[kukisan1](https://www.etsy.com/people/kukisan1)

Purchased item:

[![Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!](https://i.etsystatic.com/9169319/c/921/732/0/314/il/23ce5c/1139694682/il_170x135.1139694682_kiik.jpg)\\
\\
Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!\\
\\
$19.99](https://www.etsy.com/listing/497503010/tiny-niobium-stud-earrings-perfect-for?ref=ap-listing)

Purchased item:

[![Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!](https://i.etsystatic.com/9169319/c/921/732/0/314/il/23ce5c/1139694682/il_170x135.1139694682_kiik.jpg)\\
\\
Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!\\
\\
$19.99](https://www.etsy.com/listing/497503010/tiny-niobium-stud-earrings-perfect-for?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/1fba2d/5115037011/iap_640x640.5115037011_seglr5zc.jpg?version=0)

5 out of 5 stars

- Single or Pair?:

PAIR (two earrings)

- Color:

Rose


Super cute and I love the rose color. I (perhaps unwisely) pierced my own lobes and wanted a biocompatible metal to help them heal up. So far the earrings are great and haven’t faded despite the 2x/day cleaning that goes along with new piercings. I appreciate all the extra backs as well!

![](https://i.etsystatic.com/iusa/bcf8be/84455325/iusa_75x75.84455325_2107.jpg?version=0)

Jul 6, 2023


[Veronica](https://www.etsy.com/people/vdanhof)

Purchased item:

[![Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!](https://i.etsystatic.com/9169319/c/921/732/0/314/il/23ce5c/1139694682/il_170x135.1139694682_kiik.jpg)\\
\\
Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!\\
\\
$19.99](https://www.etsy.com/listing/497503010/tiny-niobium-stud-earrings-perfect-for?ref=ap-listing)

Purchased item:

[![Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!](https://i.etsystatic.com/9169319/c/921/732/0/314/il/23ce5c/1139694682/il_170x135.1139694682_kiik.jpg)\\
\\
Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!\\
\\
$19.99](https://www.etsy.com/listing/497503010/tiny-niobium-stud-earrings-perfect-for?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/7ee7dc/4266721705/iap_640x640.4266721705_o7c6r8rd.jpg?version=0)

5 out of 5 stars

- Single or Pair?:

PAIR (two earrings)

- Color:

Gold


Super cute tiny studs! Shipped fast and the packaging is so sweet. Hopefully these will help my 2nd lobe piercing heal! So far very comfortable and lightweight. Great variety of products and will definitely return. Thank you!

![](https://i.etsystatic.com/iusa/5b7616/23064931/iusa_75x75.23064931_eyhr.jpg?version=0)

Oct 3, 2022


[Dalya](https://www.etsy.com/people/thatpinksack)

Purchased item:

[![Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!](https://i.etsystatic.com/9169319/c/921/732/0/314/il/23ce5c/1139694682/il_170x135.1139694682_kiik.jpg)\\
\\
Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!\\
\\
$19.99](https://www.etsy.com/listing/497503010/tiny-niobium-stud-earrings-perfect-for?ref=ap-listing)

Purchased item:

[![Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!](https://i.etsystatic.com/9169319/c/921/732/0/314/il/23ce5c/1139694682/il_170x135.1139694682_kiik.jpg)\\
\\
Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!\\
\\
$19.99](https://www.etsy.com/listing/497503010/tiny-niobium-stud-earrings-perfect-for?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/2f9704/3015840034/iap_640x640.3015840034_qjefan6f.jpg?version=0)

5 out of 5 stars

- Single or Pair?:

PAIR (two earrings)

- Color:

Light Blue


These are SO perfect and SO lovely! I got a pair for my daughter and then had to get them for myself! We match now. It’s cute.
The studs are great and I don’t even feel like l have anything in. Even comfortable to sleep in.
With the hoops and the studs in my ears the off placement of my first piercings is very emphasized but I still love the look. And of course, most importantly, my ears are happy. Zero irritation. 10/10

See in original language


Translated by [Microsoft](http://aka.ms/MicrosoftTranslatorAttribution)

These are SO perfect and SO lovely! I got a pair for my daughter and then had to get them for myself! We match now. It’s cute.
The studs are great and I don’t even feel like l have anything in. Even comfortable to sleep in.
With the hoops and the studs in my ears the off placement of my first piercings is very emphasized but I still love the look. And of course, most importantly, my ears are happy. Zero irritation. 10/10


![](https://i.etsystatic.com/iusa/517fb1/84019685/iusa_75x75.84019685_6303.jpg?version=0)

Apr 15, 2021


[Dafna](https://www.etsy.com/people/dafnag)

Purchased item:

[![Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!](https://i.etsystatic.com/9169319/c/921/732/0/314/il/23ce5c/1139694682/il_170x135.1139694682_kiik.jpg)\\
\\
Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!\\
\\
$19.99](https://www.etsy.com/listing/497503010/tiny-niobium-stud-earrings-perfect-for?ref=ap-listing)

Purchased item:

[![Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!](https://i.etsystatic.com/9169319/c/921/732/0/314/il/23ce5c/1139694682/il_170x135.1139694682_kiik.jpg)\\
\\
Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!\\
\\
$19.99](https://www.etsy.com/listing/497503010/tiny-niobium-stud-earrings-perfect-for?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/273362/3033149533/iap_640x640.3033149533_ttiicy17.jpg?version=0)

5 out of 5 stars

- Single or Pair?:

PAIR (two earrings)

- Color:

Rose


I’ve been wearing niobium earrings exclusively for years so I knew what to look for when one of my 5 year old’s newly pierced ears got infected. Bobbie is lovely to communicate with, was super helpful and quickly sent out the earrings since she knew my girl was in pain.
Earrings arrived beautifully packaged, are even more pretty in person, and fit her little ears beautifully. They are just SO pretty! And I can already see a significant improvement in her problem ear!
I will absolutely be purchasing more for myself as well. Highly recommend!

Update - infection completely cleared in a few days. My daughter still loves the earrings and says they don’t bother her at all when she’s sleeping. 10/10!

![](https://i.etsystatic.com/iusa/517fb1/84019685/iusa_75x75.84019685_6303.jpg?version=0)

Apr 2, 2021


[Dafna](https://www.etsy.com/people/dafnag)

Purchased item:

[![Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!](https://i.etsystatic.com/9169319/c/921/732/0/314/il/23ce5c/1139694682/il_170x135.1139694682_kiik.jpg)\\
\\
Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!\\
\\
$19.99](https://www.etsy.com/listing/497503010/tiny-niobium-stud-earrings-perfect-for?ref=ap-listing)

Purchased item:

[![Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!](https://i.etsystatic.com/9169319/c/921/732/0/314/il/23ce5c/1139694682/il_170x135.1139694682_kiik.jpg)\\
\\
Tiny Niobium Stud Earrings, Perfect for Super Sensitive Ears, Nickel Free Studs for Earlobes or Cartilage - Made in USA, Choose Your Color!\\
\\
$19.99](https://www.etsy.com/listing/497503010/tiny-niobium-stud-earrings-perfect-for?ref=ap-listing)