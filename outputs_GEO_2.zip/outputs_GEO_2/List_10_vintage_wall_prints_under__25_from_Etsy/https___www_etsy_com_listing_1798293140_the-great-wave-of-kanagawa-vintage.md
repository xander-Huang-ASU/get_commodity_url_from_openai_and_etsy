[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1798293140/the-great-wave-of-kanagawa-vintage#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?explicit=1&ref=catnav_breadcrumb-0)
- [Prints](https://www.etsy.com/c/art-and-collectibles/prints?explicit=1&ref=catnav_breadcrumb-1)
- [Giclée](https://www.etsy.com/c/art-and-collectibles/prints/giclee?explicit=1&ref=catnav_breadcrumb-2)


Add to Favorites


- ![Katsushika Hokusai](https://i.etsystatic.com/23204678/r/il/7aa49b/6411210601/il_794xN.6411210601_otts.jpg)
- ![Katsushika Hokusai](https://i.etsystatic.com/23204678/r/il/05db77/6363127894/il_794xN.6363127894_gsiq.jpg)
- ![Hokusai The great wave](https://i.etsystatic.com/23204678/r/il/55740c/6411211293/il_794xN.6411211293_3lgw.jpg)
- ![Katsushika Hokusai,](https://i.etsystatic.com/23204678/r/il/03dfb0/6411210595/il_794xN.6411210595_l59q.jpg)
- ![Katsushika Hokusai,](https://i.etsystatic.com/23204678/r/il/1afccb/6411210589/il_794xN.6411210589_si4e.jpg)
- ![Katsushika Hokusai](https://i.etsystatic.com/23204678/r/il/d66ebf/6411210615/il_794xN.6411210615_p1ts.jpg)
- ![Katsushika Hokusai](https://i.etsystatic.com/23204678/r/il/fdf07b/6411210617/il_794xN.6411210617_oxtn.jpg)
- ![May include: A black framed canvas print of The Great Wave off Kanagawa by Katsushika Hokusai hangs above a dark wood and black dining table.  The wave is depicted in shades of blue and teal against a beige background.  The table features a black pedestal base and is set with two chairs with woven cane seats.  Small bowls of fruit and glasses sit on the table.](https://i.etsystatic.com/23204678/r/il/d72f02/6363127892/il_794xN.6363127892_7b8z.jpg)
- ![May include: Customer reviews showcasing high-quality prints.  Quotes highlight vivid colors, excellent service, and fast delivery.  The text mentions Matisse art posters, bright prints, and exceptional quality.  Positive feedback emphasizes the shop's attention to detail and overall value.  The overall theme is customer satisfaction and product quality.](https://i.etsystatic.com/23204678/r/il/3c6d4f/3153091812/il_794xN.3153091812_kbo2.jpg)

- ![Katsushika Hokusai](https://i.etsystatic.com/23204678/r/il/7aa49b/6411210601/il_75x75.6411210601_otts.jpg)
- ![Katsushika Hokusai](https://i.etsystatic.com/23204678/r/il/05db77/6363127894/il_75x75.6363127894_gsiq.jpg)
- ![Hokusai The great wave](https://i.etsystatic.com/23204678/c/1747/1747/26/26/il/55740c/6411211293/il_75x75.6411211293_3lgw.jpg)
- ![Katsushika Hokusai,](https://i.etsystatic.com/23204678/r/il/03dfb0/6411210595/il_75x75.6411210595_l59q.jpg)
- ![Katsushika Hokusai,](https://i.etsystatic.com/23204678/r/il/1afccb/6411210589/il_75x75.6411210589_si4e.jpg)
- ![Katsushika Hokusai](https://i.etsystatic.com/23204678/r/il/d66ebf/6411210615/il_75x75.6411210615_p1ts.jpg)
- ![Katsushika Hokusai](https://i.etsystatic.com/23204678/r/il/fdf07b/6411210617/il_75x75.6411210617_oxtn.jpg)
- ![May include: A black framed canvas print of The Great Wave off Kanagawa by Katsushika Hokusai hangs above a dark wood and black dining table.  The wave is depicted in shades of blue and teal against a beige background.  The table features a black pedestal base and is set with two chairs with woven cane seats.  Small bowls of fruit and glasses sit on the table.](https://i.etsystatic.com/23204678/r/il/d72f02/6363127892/il_75x75.6363127892_7b8z.jpg)
- ![May include: Customer reviews showcasing high-quality prints.  Quotes highlight vivid colors, excellent service, and fast delivery.  The text mentions Matisse art posters, bright prints, and exceptional quality.  Positive feedback emphasizes the shop's attention to detail and overall value.  The overall theme is customer satisfaction and product quality.](https://i.etsystatic.com/23204678/r/il/3c6d4f/3153091812/il_75x75.3153091812_kbo2.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1798293140%2Fthe-great-wave-of-kanagawa-vintage%23report-overlay-trigger)

Low in stock, only 9 left

Price:$22.59+


Original Price:
$25.10+


Loading


**New markdown!**

10% off


•

Limited time sale


# The Great Wave of Kanagawa, Vintage Poster, Ocean Print, Japanese wall art, Katsushika Hokusai, ukiyo-e artist, Landscape format Gift idea 4

Made by [HomePosterDecor](https://www.etsy.com/shop/HomePosterDecor)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1798293140/the-great-wave-of-kanagawa-vintage#reviews)

Returns & exchanges accepted

Size


Select an option

8x10 inches ($22.59 - $27.67)

8x12 inches ($25.71 - $31.01)

9x12 inches ($26.63 - $32.42)

10x14 inches ($31.80 - $38.78)

11x14 inches ($33.84 - $42.89)

12x16 inches ($35.80 - $46.54)

12x18 inches ($37.66 - $49.36)

16x20 inches ($40.34 - $55.55)

16x24 inches ($41.51 - $57.20)

18x24 inches ($42.53 - $60.17)

20x28 inches ($51.17 - $77.81)

20x30 inches ($53.46 - $82.05)

24x30 inches ($55.01 - $83.46)

24x32 inches ($57.31 - $86.28)

24x36 inches ($59.77 - $91.93)

27x40 inches ($69.67 - $117.77)

30x40 inches ($74.90 - $125.53)

36x48 inches ($88.03 - $150.94)

36x54 inches ($93.40 - $163.65)

30x40 cm ($35.80 - $46.54)

40x50 cm ($40.34 - $55.55)

40x60 cm ($41.51 - $57.20)

45x60 cm ($42.53 - $60.17)

50x70 cm ($51.17 - $77.81)

60x90 cm ($59.77 - $91.93)

70x100 cm ($69.67 - $117.77)

A4 - 21 x 29.7 cm ($27.61 - $33.30)

A3 - 29.7x42 cm ($38.41 - $51.46)

A2 - 42 x 59.4 cm ($44.69 - $63.70)

A1 - 59.4 x 84 cm ($63.06 - $97.31)

A0 - 84 x 119 cm ($97.46 - $167.58)

Please select an option


Choose Paper


Select an option

Premium Matte Paper ($22.59 - $97.46)

100% Cotton Matte Paper ($27.67 - $167.58)

Please select an option


4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Made by [HomePosterDecor](https://www.etsy.com/shop/HomePosterDecor)

- Materials: Matte premium paper 220gsm, Cotton Matte paper 340gsm



- Gift wrapping available

See details

Gift wrapping by HomePosterDecor

Wrapped in gorgeous champagne gold foil sealed with a sticker in the format of heart-written “A Gift For You”. A cute red ribbon gives a final touch.

The Great Wave of Kanagawa, Vintage Poster, Ocean Print, Japanese wall art, Katsushika Hokusai, ukiyo-e artist, Landscape format, Gift idea

Perfect for gifting. Perfect to add to a blank space or gallery wall.

Please note: Frame is not included.

➤ PRODUCT INFORMATION

100% COTTON MATTE PAPER:

260 gsm with an elegant light texture.

Cotton for long term durability. + 100 years.

PREMIUM MATTE PAPER:

200 gsm flat smooth surface.

Both Papers are:

\- Matte finish.

\- Museum quality.

\- Digitally Printed in professional printers with 2880dpi.

\- 10 colors process to reproduce the wide colour gamut.

➤ SIZES

\- Sizes in inches = 44 x 66, 36 x 54, 36 x 48, 30 x 40, 27 x 40, 24 x 40, 24 x 36, 24 x 32, 20 x 30, 20 x 28, 18 x 24, 17 x 22, 16 x 24, 16 x 20, 12 x 18, 11 x 14, 9 x 12, 8 x 10, 5 x 7.

\- Sizes in centimeters = A0, A1, A2, A3, A4, A5, 70x100 cm, 60x90 cm, 50x70 cm, 40x50 cm, 30x40 cm.

\- Please, choose the best size for your frame. Not all sizes are standard in your country.

\- Need a different size? please contact us.

➤ SHIPPING INFORMATION

\- Fast dispatch. 1-2 business days.

\- FREE Shipping to the USA, CANADA, The UK, Germany, The Netherlands, and France

\- Shipping upgrade available at checkout.

OUR STORE:

Explore a diverse range of wall art, from trending Contemporary and Minimalist styles to rich Vintage, Mid Century, and bold Maximalist pieces, all perfect for creating a stunning Gallery Wall. Our extensive inventory features reproductions of masterpieces by the world's most iconic artists, Exclusive Modern Designs, motivating Inspirational Sayings. These art prints make an instant impact in your Living Room, Bedroom, Dining Room, Bathroom, Home Office, Kitchen or Entrance/Foyer. Plus, enjoy FREE SHIPPING on all orders to the USA, Canada, The UK, Germany, France, and The Netherlands!

🚀 Quality You Can Trust, Fast

We are committed to providing an exceptional shopping experience from click to delivery:

Premium Quality: We ensure every print meets the highest standards, promising you a piece of art that lasts.

Super-Fast Shipping: We know you're excited! We work hard to ship your prints super fast, getting your new decor to your door quickly.

Trusted by More Than 36,000 Buyers: Our quality speaks for itself! We have a high number of return buyers on Etsy. Check our reviews to see how happy our customers are with the stunning quality of our products and our service.

Thank you for visiting!

Home Poster Decor


## Shipping and return policies

Loading


- Order today to get by

**Nov 13-25**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 14 days


- Free shipping


- Ships from: **Canada**


Deliver to United States

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------BelgiumCanadaFranceGermanySwedenSwitzerlandThe NetherlandsUnited KingdomUnited States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## FAQs

Sizing details


The size informed is for each print.


Custom and personalized orders


Please contact me if you need a different size, style or colors.


## Meet your seller

![Simone](https://i.etsystatic.com/23204678/r/isla/ff8c70/67574245/isla_75x75.67574245_lopz51qu.jpg)

Simone

Owner of [HomePosterDecor](https://www.etsy.com/shop/HomePosterDecor?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDozMDYyOTQ0ODU6MTc2Mjc3NjE1NjpmNmQ1ZjRjYzM1ODA1MjE1NWNiYjU5ZGU0NjViM2I1Zg%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1798293140%2Fthe-great-wave-of-kanagawa-vintage)

[Message Simone](https://www.etsy.com/messages/new?with_id=306294485&referring_id=1798293140&referring_type=listing&recipient_id=306294485&from_action=contact-seller)

This seller usually responds **within a few hours.**

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (1)

5.0/5

item average

Loading


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/3f6ded/89908384/iusa_75x75.89908384_tq5g.jpg?version=0)

[Victor Salomon](https://www.etsy.com/people/p3nvqreu?ref=l_review)
Nov 30, 2024


A+ Etsyseller✅✅✅. As described, fast shipping 🚚 🚚🚚and well packed 📦📦📦



![](https://i.etsystatic.com/iusa/3f6ded/89908384/iusa_75x75.89908384_tq5g.jpg?version=0)

[Victor Salomon](https://www.etsy.com/people/p3nvqreu?ref=l_review)
Nov 30, 2024


[![HomePosterDecor](https://i.etsystatic.com/iusa/65589f/75300677/iusa_75x75.75300677_i61j.jpg?version=0)](https://www.etsy.com/shop/HomePosterDecor?ref=shop_profile&listing_id=1798293140)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[HomePosterDecor](https://www.etsy.com/shop/HomePosterDecor?ref=shop_profile&listing_id=1798293140)

[Owned by Simone](https://www.etsy.com/shop/HomePosterDecor?ref=shop_profile&listing_id=1798293140) \|

Toronto, Canada

4.9
(6.1k)


36.4k sales

5 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=306294485&referring_id=1798293140&referring_type=listing&recipient_id=306294485&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDozMDYyOTQ0ODU6MTc2Mjc3NjE1NjpmNmQ1ZjRjYzM1ODA1MjE1NWNiYjU5ZGU0NjViM2I1Zg%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1798293140%2Fthe-great-wave-of-kanagawa-vintage)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## All reviews from this shop (6.1k)

Show all

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

## More from this shop

[Visit shop](https://www.etsy.com/shop/HomePosterDecor?ref=lp_mys_mfts)

- [![The Great Wave off Kanagawa Print, Japanese Wall Art by Hokusai, Retro Wall Art, Traditional Ukiyo-e Style, Coastal Home Decor](https://i.etsystatic.com/23204678/r/il/caf58b/7424143939/il_340x270.7424143939_tqmz.jpg)\\
\\
**The Great Wave off Kanagawa Print, Japanese Wall Art by Hokusai, Retro Wall Art, Traditional Ukiyo-e Style, Coastal Home Decor**\\
\\
Sale Price $18.18\\
$18.18\\
\\
$20.20\\
Original Price $20.20\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/815841501/the-great-wave-off-kanagawa-print?click_key=94bdf914bd9b4382adc724e424083af6%3ALT74d259a72c44d9a39cc5305b01b037dd371ce4bb&click_sum=6949520e&ls=r&ref=related-1&pro=1&sts=1&content_source=94bdf914bd9b4382adc724e424083af6%253ALT74d259a72c44d9a39cc5305b01b037dd371ce4bb "The Great Wave off Kanagawa Print, Japanese Wall Art by Hokusai, Retro Wall Art, Traditional Ukiyo-e Style, Coastal Home Decor")




Add to Favorites


- [![The Great Wave off Kanagawa, Blue Gallery Wall, Rothko Poster, Soulages Art, Gift for Him, Office Decor, Modern Prints, Exhibition Art 14](https://i.etsystatic.com/23204678/r/il/6c7666/5219568841/il_340x270.5219568841_rg0t.jpg)\\
\\
**The Great Wave off Kanagawa, Blue Gallery Wall, Rothko Poster, Soulages Art, Gift for Him, Office Decor, Modern Prints, Exhibition Art 14**\\
\\
Sale Price $32.37\\
$32.37\\
\\
$35.96\\
Original Price $35.96\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1312374826/the-great-wave-off-kanagawa-blue-gallery?click_key=94bdf914bd9b4382adc724e424083af6%3ALTbf21ed7048c16582921dc9e3951f7b2d28be734a&click_sum=06830183&ls=r&ref=related-2&pro=1&sts=1&content_source=94bdf914bd9b4382adc724e424083af6%253ALTbf21ed7048c16582921dc9e3951f7b2d28be734a "The Great Wave off Kanagawa, Blue Gallery Wall, Rothko Poster, Soulages Art, Gift for Him, Office Decor, Modern Prints, Exhibition Art 14")




Add to Favorites


- [![Henri Matisse Print, Matisse Exhibition, Japanese Garden, Floral Art Print, Nature Wall Art, Mid Century Modern La Japonaise 17](https://i.etsystatic.com/23204678/c/1801/1801/432/99/il/816f9e/6962187739/il_340x270.6962187739_a23f.jpg)\\
\\
**Henri Matisse Print, Matisse Exhibition, Japanese Garden, Floral Art Print, Nature Wall Art, Mid Century Modern La Japonaise 17**\\
\\
Sale Price $18.18\\
$18.18\\
\\
$20.20\\
Original Price $20.20\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/876101687/henri-matisse-print-matisse-exhibition?click_key=94bdf914bd9b4382adc724e424083af6%3ALT6e042a23e1d0d4d6648998c47f01133457b70462&click_sum=00beb5f3&ls=r&ref=related-3&pro=1&sts=1&content_source=94bdf914bd9b4382adc724e424083af6%253ALT6e042a23e1d0d4d6648998c47f01133457b70462 "Henri Matisse Print, Matisse Exhibition, Japanese Garden, Floral Art Print, Nature Wall Art, Mid Century Modern La Japonaise 17")




Add to Favorites


- [![Leopard Namaste Print: Tropical Jungle Animal Art](https://i.etsystatic.com/23204678/c/1818/1818/424/90/il/69307d/6920940488/il_340x270.6920940488_536s.jpg)\\
\\
**Leopard Namaste Print: Tropical Jungle Animal Art**\\
\\
Sale Price $22.59\\
$22.59\\
\\
$25.10\\
Original Price $25.10\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1819169392/leopard-namaste-print-tropical-jungle?click_key=bc7a5a1e3c962bc15bce2414c3790b5f8b1dc230%3A1819169392&click_sum=20b21bb3&ref=related-4&pro=1&sts=1 "Leopard Namaste Print: Tropical Jungle Animal Art")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Jul 30, 2025


[11 favorites](https://www.etsy.com/listing/1798293140/the-great-wave-of-kanagawa-vintage/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?explicit=1&ref=breadcrumb_listing) [Prints](https://www.etsy.com/c/art-and-collectibles/prints?explicit=1&ref=breadcrumb_listing) [Giclée](https://www.etsy.com/c/art-and-collectibles/prints/giclee?explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Prints

[Funny Bathroom Decor Wall Art](https://www.etsy.com/listing/1787407302/cute-duck-drawing-wall-art-funny) [The Bard Fine Art Print - Prints](https://www.etsy.com/listing/1049959255/the-bard-fine-art-print) [Minimalist Winter Landscape Canvas Wall Art](https://www.etsy.com/listing/1078598820/minimalist-winter-landscape-canvas-wall) [Sage Green Ombre for Sale](https://www.etsy.com/market/sage_green_ombre)

Toys

[Shop Troll Doll Wigs](https://www.etsy.com/market/troll_doll_wigs)

Spirituality & Religion

[Emerald Tumbled Stone - Gemstone Emerald - Heart Chakra Crystal - Natural Emerald - Wholesale Bulk - TU1280 - Spirituality & Religion](https://www.etsy.com/listing/1601805218/emerald-tumbled-stone-gemstone-emerald)

Party Supplies

[Cards and Gifts by BlueBunnyPrintables](https://www.etsy.com/listing/1023084830/cards-and-gifts-hot-air-balloon-baby)

Womens Clothing

[Shop African Dirndl](https://www.etsy.com/market/african_dirndl) [Bridesmaid Pantsuit - US](https://www.etsy.com/market/bridesmaid_pantsuit)

Patterns & How To

[Shop Settlers Stl](https://www.etsy.com/market/settlers_stl)

Hats & Caps

[Holy Roller Trucker Hat by JentryandCompany](https://www.etsy.com/listing/4333185038/holy-roller-trucker-hat-christian)

Audio

[Bose Wave Iii for Sale](https://www.etsy.com/market/bose_wave_iii)

Shopping

[Eczema Card for Sale](https://www.etsy.com/market/eczema_card) [Buddy Coffee Mugs for Sale](https://www.etsy.com/market/buddy_coffee_mugs) [Shop Rust Linen Fabric For Upholstery](https://www.etsy.com/market/rust_linen_fabric_for_upholstery)

Home Decor

[Black Cat & Pumpkin Halloween Ornament – Full Moon Fall Decoration - Home Decor](https://www.etsy.com/listing/1771846283/black-cat-pumpkin-halloween-ornament)

Dolls & Miniatures

[Teacup fairy house Miniature house Tiny house Mug house Unique gift - Dolls & Miniatures](https://www.etsy.com/listing/1502648018/teacup-fairy-house-miniature-house-tiny)

Rings

[925 Sterling Artisan Handmade Filigree Jewelry Statement Ring by FiligranSilver](https://www.etsy.com/listing/1315376581/cherry-quartz-silver-art-deco-floral)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1798293140%2Fthe-great-wave-of-kanagawa-vintage&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc3NjE1NjpiMDM3MzQwYzJhMDRkOWRlNTkyNGY5OTZhOGUxYmYyNQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1798293140%2Fthe-great-wave-of-kanagawa-vintage) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1798293140/the-great-wave-of-kanagawa-vintage#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1798293140%2Fthe-great-wave-of-kanagawa-vintage)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for HomePosterDecor

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 4 hours of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


Customs and import taxes

Buyers are responsible for any customs and import taxes that may apply. I'm not responsible for delays due to customs.


## Seller details

### Other details

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=306294485&referring_id=23204678&referring_type=shop&recipient_id=306294485&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![Katsushika Hokusai](https://i.etsystatic.com/23204678/r/il/7aa49b/6411210601/il_300x300.6411210601_otts.jpg)
- ![Katsushika Hokusai](https://i.etsystatic.com/23204678/r/il/05db77/6363127894/il_300x300.6363127894_gsiq.jpg)
- ![Hokusai The great wave](https://i.etsystatic.com/23204678/c/1747/1747/26/26/il/55740c/6411211293/il_300x300.6411211293_3lgw.jpg)
- ![Katsushika Hokusai,](https://i.etsystatic.com/23204678/r/il/03dfb0/6411210595/il_300x300.6411210595_l59q.jpg)
- ![Katsushika Hokusai,](https://i.etsystatic.com/23204678/r/il/1afccb/6411210589/il_300x300.6411210589_si4e.jpg)
- ![Katsushika Hokusai](https://i.etsystatic.com/23204678/r/il/d66ebf/6411210615/il_300x300.6411210615_p1ts.jpg)
- ![Katsushika Hokusai](https://i.etsystatic.com/23204678/r/il/fdf07b/6411210617/il_300x300.6411210617_oxtn.jpg)
- ![May include: A black framed canvas print of The Great Wave off Kanagawa by Katsushika Hokusai hangs above a dark wood and black dining table.  The wave is depicted in shades of blue and teal against a beige background.  The table features a black pedestal base and is set with two chairs with woven cane seats.  Small bowls of fruit and glasses sit on the table.](https://i.etsystatic.com/23204678/r/il/d72f02/6363127892/il_300x300.6363127892_7b8z.jpg)
- ![May include: Customer reviews showcasing high-quality prints.  Quotes highlight vivid colors, excellent service, and fast delivery.  The text mentions Matisse art posters, bright prints, and exceptional quality.  Positive feedback emphasizes the shop's attention to detail and overall value.  The overall theme is customer satisfaction and product quality.](https://i.etsystatic.com/23204678/r/il/3c6d4f/3153091812/il_300x300.3153091812_kbo2.jpg)

Scroll previousScroll next