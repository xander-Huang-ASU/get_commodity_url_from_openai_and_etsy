[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?amp;click_sum=23f8e04d&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=23f8e04d&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=23f8e04d&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=23f8e04d&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=23f8e04d&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=catnav_breadcrumb-3)

Etsy’s Pick

Etsy’s Picks are hand selected by our style experts to highlight items from shops that have shown quality, reliability and style.

[Discover More](https://www.etsy.com/featured/hub/etsy-picks?ref=listing_etsys_pick_signal)


Add to Favorites


- ![May include: A box of 100% beeswax taper candles in a cardboard box with the words 'The Light' printed on the box. The candles are a light yellow color and are arranged in the box with the wicks facing up.](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_794xN.6147225037_4iga.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![May include: A cardboard box with the words 'the light' and a bee logo printed on the side. The box is open and contains a variety of colored candles, including green, purple, orange, and red. A single yellow candle is standing upright outside of the box.](https://i.etsystatic.com/19902072/r/il/02860e/6147227513/il_794xN.6147227513_ldyv.jpg)
- ![May include: A box of 10 orange taper candles. The box is brown cardboard with a bee and honeycomb logo that says 'the light'. The candles are arranged in the box with one candle standing upright outside the box.](https://i.etsystatic.com/19902072/r/il/e452a4/6147227535/il_794xN.6147227535_q1hi.jpg)
- ![May include: A box of blue taper candles. The box is brown cardboard with a bee and honeycomb logo that reads 'be the light'. The candles are arranged in the box with one candle standing upright outside the box.](https://i.etsystatic.com/19902072/r/il/0435fa/6099138748/il_794xN.6099138748_ak6h.jpg)
- ![May include: A box of purple taper candles. The box is made of cardboard and has a logo that says 'Be the Light' with a bee and honeycomb design. The candles are arranged in the box and one candle is standing upright outside of the box.](https://i.etsystatic.com/19902072/r/il/97fad6/6099138756/il_794xN.6099138756_gthv.jpg)
- ![May include: A box of red taper candles. The box is made of brown cardboard and has a logo that says 'The Light' with a bee and honeycomb design. The candles are arranged in the box and one candle is sticking out of the box.](https://i.etsystatic.com/19902072/r/il/fc18b3/6099138768/il_794xN.6099138768_mkpv.jpg)
- ![May include: A box of white taper candles with a brown cardboard box. The box has a hexagonal logo with a bee and the text 'The Light'.](https://i.etsystatic.com/19902072/r/il/d2c155/6099138780/il_794xN.6099138780_79eh.jpg)
- ![May include: A box of green taper candles. The box is made of cardboard and has a logo that says 'The Light' with a bee and honeycomb design. The candles are arranged in the box and one candle is standing upright next to the box.](https://i.etsystatic.com/19902072/r/il/a4496a/6147228763/il_794xN.6147228763_1e75.jpg)
- ![May include: A cardboard box with the words 'The Light' printed on it. The box is open and contains several pink taper candles. The candles are arranged in a row and are partially visible. The box is sitting on a white surface.](https://i.etsystatic.com/19902072/r/il/70d4c2/6147230249/il_794xN.6147230249_1syv.jpg)
- ![May include: A set of six taper candles, three are purple, two are cream, and one is pink. The candles are arranged in a stack with the purple candles on top, the cream candles in the middle, and the pink candle on the bottom.](https://i.etsystatic.com/19902072/r/il/e2c210/4172477845/il_794xN.4172477845_dqcc.jpg)

- ![May include: A box of 100% beeswax taper candles in a cardboard box with the words 'The Light' printed on the box. The candles are a light yellow color and are arranged in the box with the wicks facing up.](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_75x75.6147225037_4iga.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/BeeTheLightVid1_ubtqj1.jpg)

- ![May include: A cardboard box with the words 'the light' and a bee logo printed on the side. The box is open and contains a variety of colored candles, including green, purple, orange, and red. A single yellow candle is standing upright outside of the box.](https://i.etsystatic.com/19902072/r/il/02860e/6147227513/il_75x75.6147227513_ldyv.jpg)
- ![May include: A box of 10 orange taper candles. The box is brown cardboard with a bee and honeycomb logo that says 'the light'. The candles are arranged in the box with one candle standing upright outside the box.](https://i.etsystatic.com/19902072/r/il/e452a4/6147227535/il_75x75.6147227535_q1hi.jpg)
- ![May include: A box of blue taper candles. The box is brown cardboard with a bee and honeycomb logo that reads 'be the light'. The candles are arranged in the box with one candle standing upright outside the box.](https://i.etsystatic.com/19902072/r/il/0435fa/6099138748/il_75x75.6099138748_ak6h.jpg)
- ![May include: A box of purple taper candles. The box is made of cardboard and has a logo that says 'Be the Light' with a bee and honeycomb design. The candles are arranged in the box and one candle is standing upright outside of the box.](https://i.etsystatic.com/19902072/r/il/97fad6/6099138756/il_75x75.6099138756_gthv.jpg)
- ![May include: A box of red taper candles. The box is made of brown cardboard and has a logo that says 'The Light' with a bee and honeycomb design. The candles are arranged in the box and one candle is sticking out of the box.](https://i.etsystatic.com/19902072/r/il/fc18b3/6099138768/il_75x75.6099138768_mkpv.jpg)
- ![May include: A box of white taper candles with a brown cardboard box. The box has a hexagonal logo with a bee and the text 'The Light'.](https://i.etsystatic.com/19902072/r/il/d2c155/6099138780/il_75x75.6099138780_79eh.jpg)
- ![May include: A box of green taper candles. The box is made of cardboard and has a logo that says 'The Light' with a bee and honeycomb design. The candles are arranged in the box and one candle is standing upright next to the box.](https://i.etsystatic.com/19902072/r/il/a4496a/6147228763/il_75x75.6147228763_1e75.jpg)
- ![May include: A cardboard box with the words 'The Light' printed on it. The box is open and contains several pink taper candles. The candles are arranged in a row and are partially visible. The box is sitting on a white surface.](https://i.etsystatic.com/19902072/r/il/70d4c2/6147230249/il_75x75.6147230249_1syv.jpg)
- ![May include: A set of six taper candles, three are purple, two are cream, and one is pink. The candles are arranged in a stack with the purple candles on top, the cream candles in the middle, and the pink candle on the bottom.](https://i.etsystatic.com/19902072/r/il/e2c210/4172477845/il_75x75.4172477845_dqcc.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1202056379%2F100-pure-beeswax-taper-candles-lasts-10%23report-overlay-trigger)

In 18 carts

Price:$11.99+


Loading


# 100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light

Made by [BeeTheLightChandlers](https://www.etsy.com/shop/BeeTheLightChandlers)

[5 out of 5 stars](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?amp;click_sum=23f8e04d&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2#reviews)

Arrives soon! Get it by

Nov 14-17


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

Color


Select an option

Rainbow ($42.99 - $349.99)

Red Blossom ($12.99 - $349.99)

Natural Yellow ($11.99 - $339.99)

Orange Sunset ($12.99 - $349.99)

Earthen Green ($12.99 - $349.99)

Rustic Blue ($12.99 - $349.99)

Cosmic Purple ($12.99 - $349.99)

Pink Sunrise ($12.99 - $349.99)

Ivory White ($12.99 - $345.99)

Advent (3Pr,1Pk,1Wt) ($28.99 - $199.99)

Please select an option


Pack Size


Select an option

12 Pack ($39.99 - $42.99)

5 Pack ($18.99 - $28.99)

2 Pack ($11.99 - $12.99)

24 Pack ($73.99 - $76.99)

60 Pack (Bulk Box) ($172.99 - $199.99)

120 Pack (Bulk Box) ($339.99 - $349.99)

Please select an option


Quantity



123456789101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899100101102103104105106107108109110111112113114115116117118119120121122123124125126127128129130131132133134135136137138139140141142143144145146147148149150151152153154155156157158159160161162163164165166167168169170171172173174175176177178179180181182183184185186187188189190191192193194195196197198199200201202203204205206207208209210211212213214215216217218219220221222223224225226227228229230231232233234235236237238239240241242243244245246247248249250251252253254255256257258259260261262263264265266267268269270271272273274275276277278279280281282283284285286287288289290291292293294295296297298299300301302303304305306307308309310311312313314315316317318319320321322323324325326327328329330331332333334335336337338339340341342343344345346347348349350351352353354355356357358359360361362363364365366367368369370371372373374375376377378379380381382383384385386387388389390391392393394395396397398399400401402403404405406407408409410411412413414415416417418419420421422423424425426427428429430431432433434435436437438439440441442443444445446447448449450451452453454455456457458459460461462463464465466467468469470471472473474475476477478479480481482483484485486487488489490491492493494495496497498499500501502503504505506507508509510511512513514515516517518519520521522523524525526527528529530531532533534535536537538539540541542543544545546547548549550551552553554555556557558559560561562563564565566567568569570571572573574575576577578579580581582583584585586587588589590591592593594595596597598599600601602603604605606607608609610611612613614615616617618619620621622623624625626627628629630631632633634635636637638639640641642643644645646647648649650651652653654655656657658659660661662663664665666667668669670671672673674675676677678679680681682683684685686687688689690691692693694695696697698699700701702703704705706707708709710711712713714715716717718719720721722723724725726727728729730731732733734735736737738739740741742743744745746747748749750751752753754755756757758759760761762763764765766767768769770771772773774775776777778779780781782783784785786787788789790791792793794795796797798799800801802803804805806807808809810811812813814815816817818819820821822823824825826827828829830831832833834835836837838839840841842843844845846847848849850851852853854855856857858859860861862863864865866867868869870871872873874875876877878879880881882883884885886887888889890891892893894895896897898899900901902903904905906907908909910911912913914915916917918919920921922923924925926927928929930931932933934935936937938939940941942943944945946947948949950951952953954955956957958959960961962963964965966967968969970971972973974975976977978979980981982983984985986987988989990991992993994995996997998999

4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Buy together, get free shipping

## Buy together, get free shipping

Add both to cart



Loading


[See more items](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?amp;click_sum=23f8e04d&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2#recs_ribbon_container)

![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5&quot; x 7/8&quot; Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_340x270.6147225037_4iga.jpg)
This listing

### 100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light

$11.99


Add to Favorites


[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_340x270.6117018964_qllw.jpg)\\
\\
**Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light**\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?click_key=0851bf498148479867a5fd615e654b78%3ALTb4b1f506d760c4542f4ec33ae7c74c124e585f2b&click_sum=72360ebb&ls=r&ref=listing-free-shipping-bundle-1&content_source=0851bf498148479867a5fd615e654b78%253ALTb4b1f506d760c4542f4ec33ae7c74c124e585f2b "Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light")


Add to Favorites


![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5&quot; x 7/8&quot; Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_340x270.6147225037_4iga.jpg)
This listing

### 100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light

$11.99


Add to Favorites


[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_340x270.6117018964_qllw.jpg)\\
\\
**Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light**\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?click_key=0851bf498148479867a5fd615e654b78%3ALTb4b1f506d760c4542f4ec33ae7c74c124e585f2b&click_sum=72360ebb&ls=r&ref=listing-free-shipping-bundle-1&content_source=0851bf498148479867a5fd615e654b78%253ALTb4b1f506d760c4542f4ec33ae7c74c124e585f2b "Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light")


Add to Favorites


![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5&quot; x 7/8&quot; Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_340x270.6147225037_4iga.jpg)
This listing

### 100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light

$11.99


Add to Favorites


[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_340x270.6117018964_qllw.jpg)\\
\\
**Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light**\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?click_key=0851bf498148479867a5fd615e654b78%3ALTb4b1f506d760c4542f4ec33ae7c74c124e585f2b&click_sum=72360ebb&ls=r&ref=listing-free-shipping-bundle-1&content_source=0851bf498148479867a5fd615e654b78%253ALTb4b1f506d760c4542f4ec33ae7c74c124e585f2b "Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light")


Add to Favorites


## Item details

### Highlights

Made by [BeeTheLightChandlers](https://www.etsy.com/shop/BeeTheLightChandlers)

- Materials: Wax type: Beeswax


100% Pure USA Beeswax Handmade in small batches in Virginia

Height: 8.5 inches OR 6 inches for the 6" option

Diameter: 7/8 inches OR 9/16 inches for the 6" option

Burn time: 10 hours OR 6 hours for the 6" option

Profits will help orphans and refugees!

Nothing but 100% pure beeswax (the colored options have a smidge of veggie-based colorant! The Yellow option has NO colorants)!

These andles burn approximately 10 hours each (Pack of 12 = 120 hours total) of 100% pure beeswax-generated light for all but the 6" Option! For that option: 6 hours each, approximately 9/16" wide and 6" tall.

Enjoy the warm and comforting vibes of our pure beeswax candles. Each beeswax candle emits a very subtle honey scent and purifies the air as it burns. Great for any occasion, and packaged in a giftable box, these indoor or outdoor taper candles create a cozy and inviting atmosphere. Whether you're unwinding after a long day or hosting a dinner party, our beautiful and ethical beeswax taper candles are sure to add a little charm.

Universal fit

When inserting your taper candle into a holder, first soften the bottom of the candle with a match then press it into the holder. This will not only secure the candle in place, but will cause it to fit into nearly any size holder.

Pure and unscented

100% Pure Beeswax! We add no scent to our bee wax taper candle, but beeswax itself is naturally honey scented with a very light and gentle aroma. Festive and cozy, our lovely golden church candle create a warm and inviting atmosphere that purifies the air, uplifts the mood and soothes the senses.

Gift ready

Our naturally yellow-gold candle sticks are beautifully packaged in a recyclable gift box stamped with our logo. As we are committed to caring for the earth, we don’t use plastic but recycled brown paper for protection. This handmade taper candle will make a sweet gift for your home, or for the home of a loved one.

Crafted with care

We put as much love and intention as we can into all aspects of our little, homespun business. Our handmade, candle sticks, are made in small batches with pure USA sourced beeswax. We are committed to paying fair wages to our wonderful employees and responsibly sourcing our materials. Our organic beeswax taper candle is also hypoallergenic and purify the air as they burn, making them a thoughtful and healthy choice for you and the environment.

Long lasting

Enjoy over 12 hours of burn time with each dripless taper candle. To maximize the burn time, trim the wick before lighting and keep it away from drafts and flammable materials. These bee wax candle sticks are handmade in the rustic dipped style as opposed to machine-form-made, meaning each beeswax taper candle is a unique creation. Always burn in a fireproof holder, away from children and flammable materials. NEVER leave candles unattended.

Safe and compact

Rest assured that our tall taper candles use only 100% cotton wicks, free from lead and other toxins, making them safe for you and your loved ones. Measuring 8.5” tall x 7/8" at the base, these long lasting taper candles fit perfectly into any standard candle stick holder.

Hand poured

We hand-pour beeswax taper candles in our little shop here in Harrisonburg, Virginia. We have a vision for a different sort of work environment - one where folks on the margins of society can find a supportive way to bring some income, but also a positive space for good friendship and conversation, no matter your background! So if you're ever in our neck o' the woods, come pull up a chair, have a chat, or make a candle!

Beeswax candle care

These handcrafted taper candles will last for longer and burn virtually smokeless and dripless if you follow the following: Trim the wick to about ¼ inch. Burn away from drafts and keep the wick trimmed throughout the entire burn. Use a match to heat and soften the bottom of your taper, then secure it into nearly any size taper holder - the heated bottom will cool and harden, "cementing" your candle in place. Always burn in a holder, on fireproof surfaces and away from children, and anything flammable. NEVER leave candles unattended.

Our story

After we got married, we knew we wanted to do something that was GOOD for people. Whatever we did, we wanted it to generate funds for humanitarian work and to honor our community, and everyone in the supply chain from the raw materials all the way to the folks who end up with the product. When we met, Daniel was living at a wonderful off-the-grid-in-the-city hospitality house and experimenting in ecological living. There was no electrical lighting in the house, so every night they lit up the beeswax candles, not just for fun or ambiance! It was a powerful and inspiring season of our life, and later, when we were thinking of things we could do that met our vision, beeswax candles came to mind. We got on craigslist and found a local beekeeper who was selling it by the block it worked, so we added soap and other products... and the rest is history!


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-17**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 30 days


- Ships from: **Harrisonburg, VA**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

## Meet your sellers

![Daniel Bryant](https://i.etsystatic.com/19902072/r/isla/cdf47d/57799161/isla_75x75.57799161_o3epzur1.jpg)

Daniel Bryant

Owner of [BeeTheLightChandlers](https://www.etsy.com/shop/BeeTheLightChandlers?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyMDkzNDE2NTQ6MTc2MjgyMzkwNDpiMjUzZTE5NmE5ZGRhZWY4YWVjNDgyZTMxODc1Nzg4OA%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1202056379%2F100-pure-beeswax-taper-candles-lasts-10%3Famp%253Bclick_sum%3D23f8e04d%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2)

[Message Daniel](https://www.etsy.com/messages/new?with_id=209341654&referring_id=1202056379&referring_type=listing&recipient_id=209341654&from_action=contact-seller)

This seller usually responds **within a few hours.**

## Reviews for this item (1.6k)

4.9/5

item average

5.0Item quality

5.0Shipping

4.9Customer service

99%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Beautiful

Fast shipping

Love it

Smells amazing

Great quality

Would recommend

Great product


Filter by category


Quality (536)


Shipping & Packaging (262)


Appearance (208)


Description accuracy (86)


Value (54)


Seller service (51)


Ease of use (34)


Sizing & Fit (14)


Condition (13)


Comfort (8)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Tamra Hill](https://www.etsy.com/people/wmumacgw?ref=l_review)
Nov 10, 2025


Love these candles! Burn evenly, smell lovely and are so pretty! Thank you!



[Tamra Hill](https://www.etsy.com/people/wmumacgw?ref=l_review)
Nov 10, 2025


5 out of 5 stars
5

This item

[Sage Hall](https://www.etsy.com/people/69j0lmz6w306y4ux?ref=l_review)
Nov 10, 2025


They fit perfectly into my holders!



[Sage Hall](https://www.etsy.com/people/69j0lmz6w306y4ux?ref=l_review)
Nov 10, 2025


5 out of 5 stars
5

This item

[amanda kruk](https://www.etsy.com/people/amandakruk?ref=l_review)
Nov 9, 2025


Delightful candles, just as expected



[amanda kruk](https://www.etsy.com/people/amandakruk?ref=l_review)
Nov 9, 2025


5 out of 5 stars
5

This item

[Darcey Fairchild](https://www.etsy.com/people/darceysant?ref=l_review)
Nov 9, 2025


These are wonderful! If these are the mistakes I’d love to see the A Team candles. I definitely recommend.



[Darcey Fairchild](https://www.etsy.com/people/darceysant?ref=l_review)
Nov 9, 2025


View all reviews for this item

### Photos from reviews

![Maxwell added a photo of their purchase](https://i.etsystatic.com/iap/78fa34/7062676142/iap_300x300.7062676142_t1m7cx77.jpg?version=0)

![Kai added a photo of their purchase](https://i.etsystatic.com/iap/fc4a73/6916209728/iap_300x300.6916209728_a19si76a.jpg?version=0)

![Reeza added a photo of their purchase](https://i.etsystatic.com/iap/7ed76c/6912344924/iap_300x300.6912344924_mag5m97s.jpg?version=0)

![Karley added a photo of their purchase](https://i.etsystatic.com/iap/b420ab/7289016096/iap_300x300.7289016096_pl3k6gjt.jpg?version=0)

![OncleE added a photo of their purchase](https://i.etsystatic.com/iap/b97ece/7097280721/iap_300x300.7097280721_2cilcx8l.jpg?version=0)

![genevievem17 added a photo of their purchase](https://i.etsystatic.com/iap/d33ed5/7100142812/iap_300x300.7100142812_ofk91r8o.jpg?version=0)

![Katie added a photo of their purchase](https://i.etsystatic.com/iap/9d09f7/6712455049/iap_300x300.6712455049_7m9m4q9r.jpg?version=0)

![Johanna added a photo of their purchase](https://i.etsystatic.com/iap/cb54f6/7151258703/iap_300x300.7151258703_bgxzp2h5.jpg?version=0)

![RaeAnn added a photo of their purchase](https://i.etsystatic.com/iap/9e3128/6762369458/iap_300x300.6762369458_ialggkmn.jpg?version=0)

![Julia added a photo of their purchase](https://i.etsystatic.com/iap/b1c08a/6711951053/iap_300x300.6711951053_h6ha6izr.jpg?version=0)

![Benjamin added a photo of their purchase](https://i.etsystatic.com/iap/67b303/7414858125/iap_300x300.7414858125_bu3s4y4q.jpg?version=0)

![mkogoma1 added a photo of their purchase](https://i.etsystatic.com/iap/3911a7/6629651069/iap_300x300.6629651069_2vbuymuo.jpg?version=0)

![Kristin added a photo of their purchase](https://i.etsystatic.com/iap/5aa147/6912456132/iap_300x300.6912456132_bg9om691.jpg?version=0)

![Kristen added a photo of their purchase](https://i.etsystatic.com/iap/541cf3/6532521367/iap_300x300.6532521367_13jn2p1n.jpg?version=0)

![Vianey added a photo of their purchase](https://i.etsystatic.com/iap/737237/6638237622/iap_300x300.6638237622_l8o0619l.jpg?version=0)

![K added a photo of their purchase](https://i.etsystatic.com/iap/94debe/6490945584/iap_300x300.6490945584_5pev906a.jpg?version=0)

![brotchford added a photo of their purchase](https://i.etsystatic.com/iap/0decaf/7290077920/iap_300x300.7290077920_4uz3rsxq.jpg?version=0)

![Linda*Lou added a photo of their purchase](https://i.etsystatic.com/iap/ae817c/6645608908/iap_300x300.6645608908_r6n8ud4s.jpg?version=0)

![Josh added a photo of their purchase](https://i.etsystatic.com/iap/c859f9/7065877599/iap_300x300.7065877599_ndd3eryb.jpg?version=0)

![Simin added a photo of their purchase](https://i.etsystatic.com/iap/e57b79/6797274238/iap_300x300.6797274238_ehivy9i8.jpg?version=0)

[BeeTheLightChandlers](https://www.etsy.com/shop/BeeTheLightChandlers?ref=shop_profile&listing_id=1202056379)

[Owned by Daniel Bryant](https://www.etsy.com/shop/BeeTheLightChandlers?ref=shop_profile&listing_id=1202056379) \|

Harrisonburg, Virginia

4.9
(3.2k)


13.9k sales

6 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=209341654&referring_id=1202056379&referring_type=listing&recipient_id=209341654&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyMDkzNDE2NTQ6MTc2MjgyMzkwNDpiMjUzZTE5NmE5ZGRhZWY4YWVjNDgyZTMxODc1Nzg4OA%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1202056379%2F100-pure-beeswax-taper-candles-lasts-10%3Famp%253Bclick_sum%3D23f8e04d%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/BeeTheLightChandlers?ref=lp_mys_mfts)

- [![Dipped Taper Candles - 100% Pure Beeswax Candles - 6 Hour Burn Each - 6&quot; - All Natural, Handmade, Unscented Bees Wax Tapers by Bee The Light](https://i.etsystatic.com/19902072/r/il/a87ce1/6117022396/il_340x270.6117022396_4q8p.jpg)\\
\\
**Dipped Taper Candles - 100% Pure Beeswax Candles - 6 Hour Burn Each - 6" - All Natural, Handmade, Unscented Bees Wax Tapers by Bee The Light**\\
\\
$9.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/695960583/dipped-taper-candles-100-pure-beeswax?click_key=2da1073a0b848f4e753790f62a0ab6b3%3ALT34392de0f4e90dce395ecc8aa1dcb12d67296d2a&click_sum=8da354c6&ls=r&ref=related-1&content_source=2da1073a0b848f4e753790f62a0ab6b3%253ALT34392de0f4e90dce395ecc8aa1dcb12d67296d2a "Dipped Taper Candles - 100% Pure Beeswax Candles - 6 Hour Burn Each - 6\" - All Natural, Handmade, Unscented Bees Wax Tapers by Bee The Light")




Add to Favorites


- [![100% Pure Beeswax Lantern Candles (12 Hours Burn Time Each) - All Natural, Handmade, Unscented Bees Wax Camping Candles by Bee The Light](https://i.etsystatic.com/19902072/r/il/01eeae/6165152683/il_340x270.6165152683_85a2.jpg)\\
\\
**100% Pure Beeswax Lantern Candles (12 Hours Burn Time Each) - All Natural, Handmade, Unscented Bees Wax Camping Candles by Bee The Light**\\
\\
$17.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/693295988/100-pure-beeswax-lantern-candles-12?click_key=2da1073a0b848f4e753790f62a0ab6b3%3ALT6f3ce1d501a9986c02dffd092f8a283d10438be4&click_sum=0c78fce8&ls=r&ref=related-2&content_source=2da1073a0b848f4e753790f62a0ab6b3%253ALT6f3ce1d501a9986c02dffd092f8a283d10438be4 "100% Pure Beeswax Lantern Candles (12 Hours Burn Time Each) - All Natural, Handmade, Unscented Bees Wax Camping Candles by Bee The Light")




Add to Favorites


- [![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_340x270.6117018964_qllw.jpg)\\
\\
**Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light**\\
\\
$28.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?click_key=2da1073a0b848f4e753790f62a0ab6b3%3ALT60175f3d8d85e688e67b67c40ef5cd52216f9ca3&click_sum=bd75a297&ls=r&ref=related-3&content_source=2da1073a0b848f4e753790f62a0ab6b3%253ALT60175f3d8d85e688e67b67c40ef5cd52216f9ca3 "Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light")




Add to Favorites


- [![100% Pure Beeswax Dipped Hanukkah, Orthodox Church or Birthday Candles, 8&quot; or 6&quot; All Natural Handmade Bees Wax Candles by Bee The Light](https://i.etsystatic.com/19902072/r/il/02bfb4/6166338813/il_340x270.6166338813_da9m.jpg)\\
\\
**100% Pure Beeswax Dipped Hanukkah, Orthodox Church or Birthday Candles, 8" or 6" All Natural Handmade Bees Wax Candles by Bee The Light**\\
\\
$23.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1760327773/100-pure-beeswax-dipped-hanukkah?click_key=05df11b92cf665e1b61be240f4d0a31dbac17fb1%3A1760327773&click_sum=cebef6bf&ref=related-4 "100% Pure Beeswax Dipped Hanukkah, Orthodox Church or Birthday Candles, 8\" or 6\" All Natural Handmade Bees Wax Candles by Bee The Light")




Add to Favorites



Loading...

Loading


**Disclaimer:** Button/coin batteries may cause serious injury and even death if swallowed. Items containing button/coin batteries should not be easily accessible without the use of a tool. Sellers are responsible for complying with all applicable labeling, design, testing, packaging, and other safety requirements. Etsy assumes no responsibility for the accuracy or contents of a seller’s listing. If you have questions about button/coin batteries, contact the seller by sending a Message. See Etsy's [Terms of Use](https://www.etsy.com/legal/terms-of-use/?ref=product_safety_banner_info_button_batteries_risk#warranties) for more information.

Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading wedding form

Loading


## Top wedding searches to shop

[![](https://i.etsystatic.com/19757930/c/1333/1333/0/301/il/cfe72f/3482678762/il_300x300.3482678762_pxw3.jpg)\\
Bridesmaid gifts](https://www.etsy.com/search?q=bridesmaid+gifts&mosv=sese&moci=635510339037&mosi=618520640322&featured_listing=1110003408&ref=wedding_recs_lp_bridesmaid_gifts)

[![](https://i.etsystatic.com/19483987/r/il/42cd8d/2512481731/il_300x300.2512481731_8gz7.jpg)\\
Groomsmen gifts](https://www.etsy.com/search?q=groomsmen+gifts&mosv=sese&moci=635510339037&mosi=635510910189&featured_listing=761677858&ref=wedding_recs_lp_groomsmen_gifts)

[![](https://i.etsystatic.com/6748817/c/2000/2000/0/828/il/b140dc/3394740672/il_300x300.3394740672_mong.jpg)\\
Wedding gifts](https://www.etsy.com/search?q=wedding+gifts&mosv=sese&moci=635510339037&mosi=618520762754&featured_listing=1087712798&ref=wedding_recs_lp_wedding_gifts)

[![](https://i.etsystatic.com/5354512/r/il/35af5c/5783958379/il_300x300.5783958379_pio7.jpg)\\
Engagement gifts](https://www.etsy.com/search?q=engagement+gifts&mosv=sese&moci=635510339037&mosi=635511121285&featured_listing=190344599&ref=wedding_recs_lp_engagement_gifts)

Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 10, 2025


[8738 favorites](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=23f8e04d&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=23f8e04d&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=23f8e04d&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=23f8e04d&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Home Decor

[Laura Lys for Sale](https://www.etsy.com/market/laura_lys) [Police Lighted Sign for Sale](https://www.etsy.com/market/police_lighted_sign) [Shop Rams Sugar Skull](https://www.etsy.com/market/rams_sugar_skull) [Fireflies Illuminate Forest Painting](https://www.etsy.com/listing/1553020156/fireflies-illuminate-forest-painting) [Shop Food Metal Art](https://www.etsy.com/market/food_metal_art) [Buy Sojara Online](https://www.etsy.com/market/sojara) [Bat Lovers for Sale](https://www.etsy.com/market/bat_lovers) [Shop Mana Potion](https://www.etsy.com/market/mana_potion) [Moda Spiegel - US](https://www.etsy.com/market/moda_spiegel) [Peacock - Paper Quilling by BlueJsDesigns](https://www.etsy.com/listing/678584741/peacock-paper-quilling) [Buy Princess Quote Sign Online](https://www.etsy.com/market/princess_quote_sign) [Sand Dollar Bowl - US](https://www.etsy.com/market/sand_dollar_bowl) [Shop Someone In Michigan Loves You](https://www.etsy.com/market/someone_in_michigan_loves_you) [Disney World Main Street Entrance Here You Leave Today Welcome Plaque Inspired Sign - Dual Color (Park Prop Inspired Replica)](https://www.etsy.com/listing/477547463/disney-world-main-street-entrance-here)

Shopping

[Buy Clark's Rant Online](https://www.etsy.com/market/clark%27s_rant)

Music

[Buy Marshmallow Contact Mic Online](https://www.etsy.com/market/marshmallow_contact_mic)

Toys

[Labubu Macaron Monsters for Sale](https://www.etsy.com/market/labubu_macaron_monsters)

Gifts & Mementos

[Shop Our Love Story Album](https://www.etsy.com/market/our_love_story_album)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1202056379%2F100-pure-beeswax-taper-candles-lasts-10%3Famp%253Bclick_sum%3D23f8e04d%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgyMzkwNDo2OTBhZmUxNzRkOWUzODJlNjJiMmM2MjU3ZDE3NDE5Zg==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1202056379%2F100-pure-beeswax-taper-candles-lasts-10%3Famp%253Bclick_sum%3D23f8e04d%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?amp;click_sum=23f8e04d&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1202056379%2F100-pure-beeswax-taper-candles-lasts-10%3Famp%253Bclick_sum%3D23f8e04d%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Item in the photo is in **Color: Natural Yellow**




Select this option








Option selected!













This option is sold out.


- Loading


- Item in the photo is in **Color: Rainbow**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Color: Orange Sunset**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Color: Rustic Blue**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Color: Cosmic Purple**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Color: Red Blossom**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Color: Ivory White**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Color: Earthen Green**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Color: Pink Sunrise**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Color: Advent (3Pr,1Pk,1Wt)**




Select this option








Option selected!













This option is sold out.



Click to zoom

- ![May include: A box of 100% beeswax taper candles in a cardboard box with the words 'The Light' printed on the box. The candles are a light yellow color and are arranged in the box with the wicks facing up.](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_300x300.6147225037_4iga.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/BeeTheLightVid1_ubtqj1.jpg)

- ![May include: A cardboard box with the words 'the light' and a bee logo printed on the side. The box is open and contains a variety of colored candles, including green, purple, orange, and red. A single yellow candle is standing upright outside of the box.](https://i.etsystatic.com/19902072/r/il/02860e/6147227513/il_300x300.6147227513_ldyv.jpg)
- ![May include: A box of 10 orange taper candles. The box is brown cardboard with a bee and honeycomb logo that says 'the light'. The candles are arranged in the box with one candle standing upright outside the box.](https://i.etsystatic.com/19902072/r/il/e452a4/6147227535/il_300x300.6147227535_q1hi.jpg)
- ![May include: A box of blue taper candles. The box is brown cardboard with a bee and honeycomb logo that reads 'be the light'. The candles are arranged in the box with one candle standing upright outside the box.](https://i.etsystatic.com/19902072/r/il/0435fa/6099138748/il_300x300.6099138748_ak6h.jpg)
- ![May include: A box of purple taper candles. The box is made of cardboard and has a logo that says 'Be the Light' with a bee and honeycomb design. The candles are arranged in the box and one candle is standing upright outside of the box.](https://i.etsystatic.com/19902072/r/il/97fad6/6099138756/il_300x300.6099138756_gthv.jpg)
- ![May include: A box of red taper candles. The box is made of brown cardboard and has a logo that says 'The Light' with a bee and honeycomb design. The candles are arranged in the box and one candle is sticking out of the box.](https://i.etsystatic.com/19902072/r/il/fc18b3/6099138768/il_300x300.6099138768_mkpv.jpg)
- ![May include: A box of white taper candles with a brown cardboard box. The box has a hexagonal logo with a bee and the text 'The Light'.](https://i.etsystatic.com/19902072/r/il/d2c155/6099138780/il_300x300.6099138780_79eh.jpg)
- ![May include: A box of green taper candles. The box is made of cardboard and has a logo that says 'The Light' with a bee and honeycomb design. The candles are arranged in the box and one candle is standing upright next to the box.](https://i.etsystatic.com/19902072/r/il/a4496a/6147228763/il_300x300.6147228763_1e75.jpg)
- ![May include: A cardboard box with the words 'The Light' printed on it. The box is open and contains several pink taper candles. The candles are arranged in a row and are partially visible. The box is sitting on a white surface.](https://i.etsystatic.com/19902072/r/il/70d4c2/6147230249/il_300x300.6147230249_1syv.jpg)
- ![May include: A set of six taper candles, three are purple, two are cream, and one is pink. The candles are arranged in a stack with the purple candles on top, the cream candles in the middle, and the pink candle on the bottom.](https://i.etsystatic.com/19902072/r/il/e2c210/4172477845/il_300x300.4172477845_dqcc.jpg)

- ![](https://i.etsystatic.com/iap/78fa34/7062676142/iap_640x640.7062676142_t1m7cx77.jpg?version=0)

5 out of 5 stars

- Color:

Natural Yellow

- Pack Size:

12 Pack


Fast shipping, excellent packaging and service! Beautiful candles.

Jul 29, 2025


[Maxwell](https://www.etsy.com/people/50eceuv32nozu9w3)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/fc4a73/6916209728/iap_640x640.6916209728_a19si76a.jpg?version=0)

5 out of 5 stars

- Color:

Ivory White

- Pack Size:

12 Pack


Outstanding candles! Perfect for all of my late-night conspiring :)
Will be back for more. The candles were packaged well enough to gift. Seller was v kind in answering any questions I had.

![](https://i.etsystatic.com/iusa/2e7335/64875381/iusa_75x75.64875381_bxz8.jpg?version=0)

Jun 5, 2025


[Kai Johnson](https://www.etsy.com/people/6w7kqas9)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/7ed76c/6912344924/iap_640x640.6912344924_mag5m97s.jpg?version=0)

5 out of 5 stars

- Color:

Natural Yellow

- Pack Size:

24 Pack


This is my third time ordering from them. I love the smell of the candles. They are subtle and sweet. I love burning beeswax candles throughout the year.

![](https://i.etsystatic.com/iusa/d2e63c/20177302/iusa_75x75.20177302.jpg?version=0)

Jun 3, 2025


[Reeza Salvador](https://www.etsy.com/people/reeza87)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/b420ab/7289016096/iap_640x640.7289016096_pl3k6gjt.jpg?version=0)

5 out of 5 stars

- Color:

Natural Yellow

- Pack Size:

12 Pack


Lovely candles! They burn well and bring calming energy with them. I have bought more as the they will make a great gift! Thank you 😊

Oct 15, 2025


[Karley H](https://www.etsy.com/people/karley064)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/b97ece/7097280721/iap_640x640.7097280721_2cilcx8l.jpg?version=0)

5 out of 5 stars

- Color:

Natural Yellow

- Pack Size:

12 Pack


As described as pictured, they smell amazing!

![](https://i.etsystatic.com/iusa/8a7a2b/64214871/iusa_75x75.64214871_8ukc.jpg?version=0)

Jul 24, 2025


[OncleE](https://www.etsy.com/people/OncleE)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/d33ed5/7100142812/iap_640x640.7100142812_ofk91r8o.jpg?version=0)

4 out of 5 stars

- Color:

Natural Yellow

- Pack Size:

12 Pack


These are decent candles that appear to be made from real bees wax, with a very slight hint of bees wax and true texture. The shipping was great and very fast. The only downfall is that these burn very quickly, and also drip all over the place. The price is fair, so it’s not a deal breaker in the future.

![](https://i.etsystatic.com/iusa/e0ae38/72171224/iusa_75x75.72171224_ii2x.jpg?version=0)

Aug 11, 2025


[genevievem17](https://www.etsy.com/people/genevievem17)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/9d09f7/6712455049/iap_640x640.6712455049_7m9m4q9r.jpg?version=0)

5 out of 5 stars

- Color:

Natural Yellow

- Pack Size:

12 Pack


Absolutely wonderful candles! So pleased with my purchase, will definitely be a repeat customer! Smells wonderful and burns nicely! Packaged with care and shipped super fast! Thank you!

Feb 21, 2025


[Katie](https://www.etsy.com/people/4u4b8bms)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/cb54f6/7151258703/iap_640x640.7151258703_bgxzp2h5.jpg?version=0)

5 out of 5 stars

- Color:

Natural Yellow

- Pack Size:

12 Pack


Super happy with this purchase! I got a pack of their natural yellow taper candles and the first thing I noticed when I opened up the package was, for one, the excellent packing job (super secure and neat), as well as the unmistakable God-given honey scent of the beeswax!

I can definitely see myself purchasing these again! Thank you Bee the Light for your gorgeous craft, I can definitely feel the love and care you put into your service!

Aug 12, 2025


[Johanna Thamas](https://www.etsy.com/people/Johannathamas)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/9e3128/6762369458/iap_640x640.6762369458_ialggkmn.jpg?version=0)

5 out of 5 stars

- Color:

Natural Yellow

- Pack Size:

5 Pack


Beautifully crafted and smells delightful! We love the light honey scent and we use them as we go through the Stations of the Cross. Each child carries his candle and the beeswax dries before the wax falls to the base of the taper. Very pleased!

![](https://i.etsystatic.com/iusa/3c2736/58986997/iusa_75x75.58986997_fqyn.jpg?version=0)

Apr 2, 2025


[RaeAnn Allen](https://www.etsy.com/people/pinkster91)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/b1c08a/6711951053/iap_640x640.6711951053_h6ha6izr.jpg?version=0)

2 out of 5 stars

- Color:

Rustic Blue

- Pack Size:

2 Pack


I bought the blue taper candles and the color was completely different than that shown - a much darker and duller blue. There was also white residue on the candles, which is fine if that’s how they come but then it should be reflected in the pictures. I reached out to the seller with my issue with no response.

Feb 21, 2025


[Julia Smith](https://www.etsy.com/people/juliabartz1)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/67b303/7414858125/iap_640x640.7414858125_bu3s4y4q.jpg?version=0)

5 out of 5 stars

- Color:

Natural Yellow

- Pack Size:

5 Pack


Great quality, burning time, and no issues

![](https://i.etsystatic.com/iusa/8b9578/107024906/iusa_75x75.107024906_nlop.jpg?version=0)

Nov 6, 2025


[Benjamin Colin](https://www.etsy.com/people/jqzcki0pnmk79ar5)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/3911a7/6629651069/iap_640x640.6629651069_2vbuymuo.jpg?version=0)

5 out of 5 stars

- Color:

Natural Yellow

- Pack Size:

12 Pack


These candles are just as described and perfect for my needs. They arrived very quickly and were well packaged (packaging is cute as well if you are gifting). I would definitely buy from this shop again.

Jan 19, 2025


[mkogoma1](https://www.etsy.com/people/mkogoma1)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/5aa147/6912456132/iap_640x640.6912456132_bg9om691.jpg?version=0)

5 out of 5 stars

- Color:

Ivory White

- Pack Size:

12 Pack


Beautifully and carefully packaged. Shipped quick. Great quality.

Jun 3, 2025


[Kristin Hill](https://www.etsy.com/people/hillfamilyoregon)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/541cf3/6532521367/iap_640x640.6532521367_13jn2p1n.jpg?version=0)

5 out of 5 stars

- Color:

Natural Yellow

- Pack Size:

12 Pack


Lovely candles! They smell great and don’t burn too fast. Perfect for Christmas.

![](https://i.etsystatic.com/iusa/fddeb7/31690257/iusa_75x75.31690257_jp3h.jpg?version=0)

Dec 5, 2024


[Kristen Morgan-Davie](https://www.etsy.com/people/kristenmorgandavie)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/737237/6638237622/iap_640x640.6638237622_l8o0619l.jpg?version=0)

5 out of 5 stars

- Color:

Natural Yellow

- Pack Size:

2 Pack


Love it! And the honey scent is so good!!

Feb 11, 2025


[Vianey Cordova](https://www.etsy.com/people/vcordova3)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/94debe/6490945584/iap_640x640.6490945584_5pev906a.jpg?version=0)

5 out of 5 stars

- Color:

Natural Yellow

- Pack Size:

5 Pack


I love the candles!! I can tell they’re great quality, and they are perfect for our Advent wreath (I put purple and pink ribbon on the bottom.)

Dec 8, 2024


[K Anderson](https://www.etsy.com/people/sipperdog2001)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/0decaf/7290077920/iap_640x640.7290077920_4uz3rsxq.jpg?version=0)

5 out of 5 stars

- Color:

Natural Yellow

- Pack Size:

12 Pack


These are beautiful beeswax taper candles. Arrived in perfect condition in their well protected packaging.

Oct 15, 2025


[brotchford](https://www.etsy.com/people/brotchford)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/ae817c/6645608908/iap_640x640.6645608908_r6n8ud4s.jpg?version=0)

5 out of 5 stars

- Color:

Natural Yellow

- Pack Size:

12 Pack


This is my second batch order! I'm absolutely in love with these candles. They burn so beautifully!

Feb 14, 2025


[Linda\*Lou Gonzales](https://www.etsy.com/people/LindaLousMuze)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/c859f9/7065877599/iap_640x640.7065877599_ndd3eryb.jpg?version=0)

5 out of 5 stars

- Color:

Natural Yellow

- Pack Size:

12 Pack


Smells divine. Lools gorgeous in our space. Affordable. Would reccomend.

Jul 14, 2025


[Josh Helmuth](https://www.etsy.com/people/tn3oy5tiigtbe564)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/e57b79/6797274238/iap_640x640.6797274238_ehivy9i8.jpg?version=0)

1 out of 5 stars

- Color:

Ivory White

- Pack Size:

2 Pack


Two candles not two packs of candles costed me $20.

Apr 16, 2025


[Simin Ghaffari Anaraki](https://www.etsy.com/people/4shkhrt46djulrvl)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)

Purchased item:

[![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_170x135.6147225037_4iga.jpg)\\
\\
100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light\\
\\
$11.99](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?ref=ap-listing)