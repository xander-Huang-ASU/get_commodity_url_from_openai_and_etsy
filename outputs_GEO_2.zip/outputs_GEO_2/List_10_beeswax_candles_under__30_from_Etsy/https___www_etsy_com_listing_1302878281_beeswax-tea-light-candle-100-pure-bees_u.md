[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?utm_source=openai&explicit=1&ref=catnav_breadcrumb-3)
- [Tea Lights](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/tea-lights?utm_source=openai&explicit=1&ref=catnav_breadcrumb-4)

Bestseller

This item has had a high sales volume over the past 6 months.



Add to Favorites


- ![May include: A cardboard box with the words 'The Light' and a bee logo printed on the top. The box is open and filled with 24 yellow beeswax tea light candles. Three candles are sitting outside the box on a white surface.](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_794xN.6117018964_qllw.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![May include: A box of 12 yellow beeswax tea light candles in a cardboard box with the words 'The Light' and a bee logo printed on the top. The box is open and the candles are visible inside. There are three candles outside of the box on a white surface.](https://i.etsystatic.com/19902072/r/il/d5ceb8/6117018902/il_794xN.6117018902_nvl4.jpg)
- ![May include: A set of 12 unscented, yellow tea light candles in aluminum containers. The candles are 1.5 inches in diameter and 0.5 inches in height. The candles have a burn time of 4 hours each. The candles are arranged in a circle on a white background.](https://i.etsystatic.com/19902072/r/il/8da686/4874318866/il_794xN.4874318866_ij3d.jpg)
- ![May include: A yellow tea light candle in a silver holder](https://i.etsystatic.com/19902072/r/il/071854/4922569493/il_794xN.4922569493_piuw.jpg)
- ![May include: A close-up of several yellow tea light candles with white wicks. The candles are arranged in a circular pattern on a white surface.](https://i.etsystatic.com/19902072/r/il/6d927e/4874322546/il_794xN.4874322546_kxtt.jpg)
- ![May include: Thirty-six yellow tea light candles with white wicks arranged in a rectangular pattern on a white surface.](https://i.etsystatic.com/19902072/r/il/b98102/4922569285/il_794xN.4922569285_gumj.jpg)
- ![May include: Twenty-four yellow tea light candles arranged in a rectangular grid on a white surface. Each candle has a white wick in the center.](https://i.etsystatic.com/19902072/r/il/52e3fe/4922569853/il_794xN.4922569853_lz8p.jpg)
- ![May include: A close-up of a group of unscented tea light candles on a dark brown wooden surface. The candles are white and have a silver base. The candles are lit and the flames are visible. The text 'BURN TIME' and '4 HRS EACH' is visible in the top right corner of the image. The text 'LONG-LASTING' and 'Each candle lasts up to 4 hours' is visible in the top left corner of the image.](https://i.etsystatic.com/19902072/r/il/fb9cf9/4922579865/il_794xN.4922579865_cq7o.jpg)
- ![May include: A set of 24 unscented, pure beeswax tea light candles. The candles are arranged in a circle and are surrounded by icons that describe the product features, including: USA beeswax, fair trade, handmade, cruelty free, smokeless, non-toxic, and ecological.](https://i.etsystatic.com/19902072/r/il/9c4481/4922580291/il_794xN.4922580291_5okx.jpg)
- ![May include: Multipurpose tea light candles in a white container. The candles are shown in four different settings: a date night, a wedding, a bedroom, and a dinner table.](https://i.etsystatic.com/19902072/r/il/fb0137/4874320186/il_794xN.4874320186_tle5.jpg)

- ![May include: A cardboard box with the words 'The Light' and a bee logo printed on the top. The box is open and filled with 24 yellow beeswax tea light candles. Three candles are sitting outside the box on a white surface.](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_75x75.6117018964_qllw.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/BeeTheLight_Video_Trimmed_qmh5cg.jpg)

- ![May include: A box of 12 yellow beeswax tea light candles in a cardboard box with the words 'The Light' and a bee logo printed on the top. The box is open and the candles are visible inside. There are three candles outside of the box on a white surface.](https://i.etsystatic.com/19902072/r/il/d5ceb8/6117018902/il_75x75.6117018902_nvl4.jpg)
- ![May include: A set of 12 unscented, yellow tea light candles in aluminum containers. The candles are 1.5 inches in diameter and 0.5 inches in height. The candles have a burn time of 4 hours each. The candles are arranged in a circle on a white background.](https://i.etsystatic.com/19902072/r/il/8da686/4874318866/il_75x75.4874318866_ij3d.jpg)
- ![May include: A yellow tea light candle in a silver holder](https://i.etsystatic.com/19902072/r/il/071854/4922569493/il_75x75.4922569493_piuw.jpg)
- ![May include: A close-up of several yellow tea light candles with white wicks. The candles are arranged in a circular pattern on a white surface.](https://i.etsystatic.com/19902072/r/il/6d927e/4874322546/il_75x75.4874322546_kxtt.jpg)
- ![May include: Thirty-six yellow tea light candles with white wicks arranged in a rectangular pattern on a white surface.](https://i.etsystatic.com/19902072/r/il/b98102/4922569285/il_75x75.4922569285_gumj.jpg)
- ![May include: Twenty-four yellow tea light candles arranged in a rectangular grid on a white surface. Each candle has a white wick in the center.](https://i.etsystatic.com/19902072/r/il/52e3fe/4922569853/il_75x75.4922569853_lz8p.jpg)
- ![May include: A close-up of a group of unscented tea light candles on a dark brown wooden surface. The candles are white and have a silver base. The candles are lit and the flames are visible. The text 'BURN TIME' and '4 HRS EACH' is visible in the top right corner of the image. The text 'LONG-LASTING' and 'Each candle lasts up to 4 hours' is visible in the top left corner of the image.](https://i.etsystatic.com/19902072/r/il/fb9cf9/4922579865/il_75x75.4922579865_cq7o.jpg)
- ![May include: A set of 24 unscented, pure beeswax tea light candles. The candles are arranged in a circle and are surrounded by icons that describe the product features, including: USA beeswax, fair trade, handmade, cruelty free, smokeless, non-toxic, and ecological.](https://i.etsystatic.com/19902072/r/il/9c4481/4922580291/il_75x75.4922580291_5okx.jpg)
- ![May include: Multipurpose tea light candles in a white container. The candles are shown in four different settings: a date night, a wedding, a bedroom, and a dinner table.](https://i.etsystatic.com/19902072/r/il/fb0137/4874320186/il_75x75.4874320186_tle5.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1302878281%2Fbeeswax-tea-light-candle-100-pure-bees%23report-overlay-trigger)

In 20+ carts

Price:$28.99+


Loading


# Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light

[BeeTheLightChandlers](https://www.etsy.com/shop/BeeTheLightChandlers?ref=shop-header-name&listing_id=1302878281&from_page=listing)

[5 out of 5 stars](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?utm_source=openai#reviews)

Arrives soon! Get it by

Nov 14-17


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

Pack Size


Select an option

24 Pack ($28.99)

48 Pack ($44.99)

Bulk box of 192 ($169.99)

Please select an option


4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Buy together, get free shipping

## Buy together, get free shipping

Add both to cart



Loading


[See more items](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?utm_source=openai#recs_ribbon_container)

![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_340x270.6117018964_qllw.jpg)
This listing

### Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light

$28.99


Add to Favorites


[![Beeswax Votive Candles - 100% Pure Beeswax (15 Hours Burn Time Each) - All Natural, Handmade, Unscented Candles with Light Honey Fragrance](https://i.etsystatic.com/19902072/r/il/740ca9/6147251613/il_340x270.6147251613_a2je.jpg)\\
\\
**Beeswax Votive Candles - 100% Pure Beeswax (15 Hours Burn Time Each) - All Natural, Handmade, Unscented Candles with Light Honey Fragrance**\\
\\
$18.99](https://www.etsy.com/listing/707145117/beeswax-votive-candles-100-pure-beeswax?click_key=7ed9be42d2883371c734c16a34098aad%3ALT3a58b20224d7836e60879abe6a14e03ce63e45e9&click_sum=608bee37&ls=r&ref=listing-free-shipping-bundle-1&content_source=7ed9be42d2883371c734c16a34098aad%253ALT3a58b20224d7836e60879abe6a14e03ce63e45e9 "Beeswax Votive Candles - 100% Pure Beeswax (15 Hours Burn Time Each) - All Natural, Handmade, Unscented Candles with Light Honey Fragrance")


Add to Favorites


![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_340x270.6117018964_qllw.jpg)
This listing

### Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light

$28.99


Add to Favorites


[![Beeswax Votive Candles - 100% Pure Beeswax (15 Hours Burn Time Each) - All Natural, Handmade, Unscented Candles with Light Honey Fragrance](https://i.etsystatic.com/19902072/r/il/740ca9/6147251613/il_340x270.6147251613_a2je.jpg)\\
\\
**Beeswax Votive Candles - 100% Pure Beeswax (15 Hours Burn Time Each) - All Natural, Handmade, Unscented Candles with Light Honey Fragrance**\\
\\
$18.99](https://www.etsy.com/listing/707145117/beeswax-votive-candles-100-pure-beeswax?click_key=7ed9be42d2883371c734c16a34098aad%3ALT3a58b20224d7836e60879abe6a14e03ce63e45e9&click_sum=608bee37&ls=r&ref=listing-free-shipping-bundle-1&content_source=7ed9be42d2883371c734c16a34098aad%253ALT3a58b20224d7836e60879abe6a14e03ce63e45e9 "Beeswax Votive Candles - 100% Pure Beeswax (15 Hours Burn Time Each) - All Natural, Handmade, Unscented Candles with Light Honey Fragrance")


Add to Favorites


![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_340x270.6117018964_qllw.jpg)
This listing

### Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light

$28.99


Add to Favorites


[![Beeswax Votive Candles - 100% Pure Beeswax (15 Hours Burn Time Each) - All Natural, Handmade, Unscented Candles with Light Honey Fragrance](https://i.etsystatic.com/19902072/r/il/740ca9/6147251613/il_340x270.6147251613_a2je.jpg)\\
\\
**Beeswax Votive Candles - 100% Pure Beeswax (15 Hours Burn Time Each) - All Natural, Handmade, Unscented Candles with Light Honey Fragrance**\\
\\
$18.99](https://www.etsy.com/listing/707145117/beeswax-votive-candles-100-pure-beeswax?click_key=7ed9be42d2883371c734c16a34098aad%3ALT3a58b20224d7836e60879abe6a14e03ce63e45e9&click_sum=608bee37&ls=r&ref=listing-free-shipping-bundle-1&content_source=7ed9be42d2883371c734c16a34098aad%253ALT3a58b20224d7836e60879abe6a14e03ce63e45e9 "Beeswax Votive Candles - 100% Pure Beeswax (15 Hours Burn Time Each) - All Natural, Handmade, Unscented Candles with Light Honey Fragrance")


Add to Favorites


## Item details

### Highlights

Made by [BeeTheLightChandlers](https://www.etsy.com/shop/BeeTheLightChandlers)

- Materials: Wax type: Beeswax


100% Pure USA Beeswax handmade in the USA!

Size: 1.5″ D x 0.5″ H

Burn time: 4 Hours Burn Time

Handmade in small batches in Virginia

Our Profits will Help Orphans and Refugees

Enjoy the warm and comforting vibes of our pure beeswax candles. Each beeswax candle emits a very subtle honey scent and purifies the air as it burns. Great for any occasion, and packaged in a giftable box, these indoor or outdoor tealight candles create a cozy and inviting atmosphere. Whether you're unwinding after a long day or hosting a dinner party, our beautiful and ethical beeswax tealights are sure to add a little charm.

Pure and Unscented

100% Pure Beeswax! We add no scent to our tealight candles, but beeswax itself is naturally honey-scented with a very light and gentle aroma. Festive and cozy, our lovely golden tea light candles create a warm and inviting atmosphere that purifies the air, uplifts the mood and soothes the senses.

Gift ready

Our naturally yellow-gold beeswax tealight church candle are beautifully packaged in a recyclable gift box stamped with our logo. As we are committed to caring for the earth, we don’t use plastic but recycled brown paper for protection.

Crafted with care

We put as much love and intention as we can into all aspects of our little, homespun business. Our handmade unscented tealight candle sticks are made in small batches with pure USA-sourced beeswax. We are committed to paying fair wages to our wonderful employees and responsibly sourcing our materials. Our beeswax candle sticks are also hypoallergenic and purify the air as they burn, making them a thoughtful and healthy choice for you and the environment.

Long lasting

Enjoy over 10 hours of burn time with each long lasting tea light candle. To maximize the burn time, trim the wick to nearly 1⁄4 inch. Light from the base of the wick, not the tip. Remove “wick bloom” if it develops. Always burn in a fireproof holder, away from children and flammable materials. NEVER leave candles unattended.

Safe and compact

Rest assured that our decorative candles use only 100% cotton wicks, free from lead and other toxins, making them safe for you and your loved ones. Measures 1.5" wide x 0.5" tall.

Hand poured

We hand-pour beeswax tea light candles in our little shop here in Harrisonburg, Virginia. We have a vision for a different sort of work environment - one where folks on the margins of society can find a supportive way to bring some income, but also a positive space for good friendship and conversation, no matter your background! So if you're ever in our neck o' the woods, come pull up a chair, have a chat, or make a candle!

Beeswax candle care

These 100% pure beeswax tea light candles will last around 10 hours each and burn virtually smokeless and dripless if you follow the following: Trim the wick to about ¼ inch. Burn away from drafts. Always burn in a holder, on fireproof surfaces, away from children and anything flammable. NEVER leave candles unattended.

Our story

After we got married, we knew we wanted to do something that was GOOD for people. Whatever we did, we wanted it to generate funds for humanitarian work and to honor our community, and everyone in the supply chain from the raw materials all the way to the folks who end up with the product. When we met, Daniel was living at a wonderful off-the-grid-in-the-city hospitality house and experimenting in ecological living. There was no electrical lighting in the house, so every night they lit up the beeswax candles, not just for fun or ambiance! It was a powerful and inspiring season of our life, and later, when we were thinking of things we could do that met our vision, beeswax candles came to mind. We got on craigslist and found a local beekeeper who was selling it by the block it worked, so we added soap and other products... and the rest is history!


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-17**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 30 days


- Ships from: **Harrisonburg, VA**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

## Reviews for this item (517)

5.0/5

item average

5.0Item quality

5.0Shipping

5.0Customer service

99%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Fast shipping

Smells amazing

Love it

Great product

Great quality

Would recommend

Well packaged


Filter by category


Quality (171)


Shipping & Packaging (88)


Appearance (33)


Description accuracy (31)


Seller service (23)


Value (11)


Ease of use (10)


Comfort (3)


Sizing & Fit (2)


Condition (2)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Hannah](https://www.etsy.com/people/9zarxogd?ref=l_review)
Nov 9, 2025


Returning customer. These are the best candles.



[Hannah](https://www.etsy.com/people/9zarxogd?ref=l_review)
Nov 9, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/59d78b/58630515/iusa_75x75.58630515_95ex.jpg?version=0)

[Blake](https://www.etsy.com/people/lwjwu5ps?ref=l_review)
Nov 8, 2025


The candles are great, and long burning. Shipping was fast



![](https://i.etsystatic.com/iusa/59d78b/58630515/iusa_75x75.58630515_95ex.jpg?version=0)

[Blake](https://www.etsy.com/people/lwjwu5ps?ref=l_review)
Nov 8, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/61c0a3/34266911/iusa_75x75.34266911_eo0t.jpg?version=0)

[Becki Persons](https://www.etsy.com/people/beckipersons?ref=l_review)
Nov 8, 2025


Lovely light, burns very evenly. Slow burning.



![Becki Persons added a photo of their purchase](https://i.etsystatic.com/iap/651f67/7422178535/iap_300x300.7422178535_f8jrhvyn.jpg?version=0)

![](https://i.etsystatic.com/iusa/61c0a3/34266911/iusa_75x75.34266911_eo0t.jpg?version=0)

[Becki Persons](https://www.etsy.com/people/beckipersons?ref=l_review)
Nov 8, 2025


5 out of 5 stars
5

This item

[Emily](https://www.etsy.com/people/emily10951?ref=l_review)
Nov 7, 2025


Fast shipping and exactly as described. Thank you!



[Emily](https://www.etsy.com/people/emily10951?ref=l_review)
Nov 7, 2025


View all reviews for this item

### Photos from reviews

![patricia added a photo of their purchase](https://i.etsystatic.com/iap/e8c071/6578641088/iap_300x300.6578641088_4v08o9ng.jpg?version=0)

![Becki added a photo of their purchase](https://i.etsystatic.com/iap/651f67/7422178535/iap_300x300.7422178535_f8jrhvyn.jpg?version=0)

![Carly added a photo of their purchase](https://i.etsystatic.com/iap/ada5ff/6310777244/iap_300x300.6310777244_5abbombq.jpg?version=0)

![Mary added a photo of their purchase](https://i.etsystatic.com/iap/5a13f2/5657880696/iap_300x300.5657880696_720c4kg3.jpg?version=0)

![Shanna added a photo of their purchase](https://i.etsystatic.com/iap/b04f56/6787613435/iap_300x300.6787613435_mcxnuqui.jpg?version=0)

![Saskia added a photo of their purchase](https://i.etsystatic.com/iap/668dde/5140164700/iap_300x300.5140164700_mxf26zzm.jpg?version=0)

![kmo0612 added a photo of their purchase](https://i.etsystatic.com/iap/6015a1/5823833193/iap_300x300.5823833193_fc3azjgg.jpg?version=0)

![Kaelie added a photo of their purchase](https://i.etsystatic.com/iap/89f695/6854515686/iap_300x300.6854515686_ec45zk0h.jpg?version=0)

![Gabriel added a photo of their purchase](https://i.etsystatic.com/iap/d4fdc6/6498252817/iap_300x300.6498252817_hggcu0wj.jpg?version=0)

![Deborah added a photo of their purchase](https://i.etsystatic.com/iap/472122/6617490092/iap_300x300.6617490092_4fi99i8g.jpg?version=0)

![Kaelie added a photo of their purchase](https://i.etsystatic.com/iap/e51d6e/6818301556/iap_300x300.6818301556_sxomj4yd.jpg?version=0)

![Allegra added a photo of their purchase](https://i.etsystatic.com/iap/ccfa5a/5672407411/iap_300x300.5672407411_h40mr012.jpg?version=0)

![Emi added a photo of their purchase](https://i.etsystatic.com/iap/a46f54/4617990869/iap_300x300.4617990869_gysa9n1r.jpg?version=0)

![LatinTemptress added a photo of their purchase](https://i.etsystatic.com/iap/257f99/6855952103/iap_300x300.6855952103_4nnbu5rm.jpg?version=0)

![The.Fountainhead added a photo of their purchase](https://i.etsystatic.com/iap/488f96/7201857536/iap_300x300.7201857536_7pkb1j3l.jpg?version=0)

![Kaelie added a photo of their purchase](https://i.etsystatic.com/iap/a32ed6/6881095232/iap_300x300.6881095232_8ge04t6r.jpg?version=0)

![psully1387 added a photo of their purchase](https://i.etsystatic.com/iap/359bda/4660938753/iap_300x300.4660938753_smcem271.jpg?version=0)

![Karen added a photo of their purchase](https://i.etsystatic.com/iap/837766/6566579652/iap_300x300.6566579652_o0m5az7x.jpg?version=0)

![Amelia added a photo of their purchase](https://i.etsystatic.com/iap/783448/5067021726/iap_300x300.5067021726_6tw22hrw.jpg?version=0)

![Cat added a photo of their purchase](https://i.etsystatic.com/iap/6127e5/4496570094/iap_300x300.4496570094_qxbk2mhf.jpg?version=0)

[BeeTheLightChandlers](https://www.etsy.com/shop/BeeTheLightChandlers?ref=shop_profile&listing_id=1302878281)

[Owned by Daniel Bryant](https://www.etsy.com/shop/BeeTheLightChandlers?ref=shop_profile&listing_id=1302878281) \|

Harrisonburg, Virginia

4.9
(3.2k)


13.9k sales

6 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=209341654&referring_id=1302878281&referring_type=listing&recipient_id=209341654&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyMDkzNDE2NTQ6MTc2Mjc4NzA1MDpjOTdkNjhlNzhhOWFlMzdmMDdjNTY1Njk4ZDk5OGIzYg%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1302878281%2Fbeeswax-tea-light-candle-100-pure-bees%3Futm_source%3Dopenai)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/BeeTheLightChandlers?ref=lp_mys_mfts)

- [![Beeswax Votive Candles - 100% Pure Beeswax (15 Hours Burn Time Each) - All Natural, Handmade, Unscented Candles with Light Honey Fragrance](https://i.etsystatic.com/19902072/r/il/740ca9/6147251613/il_340x270.6147251613_a2je.jpg)\\
\\
**Beeswax Votive Candles - 100% Pure Beeswax (15 Hours Burn Time Each) - All Natural, Handmade, Unscented Candles with Light Honey Fragrance**\\
\\
$18.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/707145117/beeswax-votive-candles-100-pure-beeswax?click_key=a4d04e4fd2bdcdf1f81a6d829f5102c4%3ALT3cd19d8bfde859b10f7aec677f43eb460f314565&click_sum=4a6454a8&ls=r&ref=related-1&content_source=a4d04e4fd2bdcdf1f81a6d829f5102c4%253ALT3cd19d8bfde859b10f7aec677f43eb460f314565 "Beeswax Votive Candles - 100% Pure Beeswax (15 Hours Burn Time Each) - All Natural, Handmade, Unscented Candles with Light Honey Fragrance")




Add to Favorites


- [![100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5&quot; x 7/8&quot; Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light](https://i.etsystatic.com/19902072/r/il/276702/6147225037/il_340x270.6147225037_4iga.jpg)\\
\\
**100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5" x 7/8" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light**\\
\\
$11.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1202056379/100-pure-beeswax-taper-candles-lasts-10?click_key=a4d04e4fd2bdcdf1f81a6d829f5102c4%3ALT5030bddda4df198b1083d7e1a6ba400b716a356a&click_sum=d3d2f736&ls=r&ref=related-2&content_source=a4d04e4fd2bdcdf1f81a6d829f5102c4%253ALT5030bddda4df198b1083d7e1a6ba400b716a356a "100% Pure Beeswax Taper Candles (Lasts 10 Hours Each) - 8.5\" x 7/8\" Handmade, All Natural, Unscented Bees Wax Dipped Style by Bee The Light")




Add to Favorites


- [![100% Pure Beeswax Lantern Candles (12 Hours Burn Time Each) - All Natural, Handmade, Unscented Bees Wax Camping Candles by Bee The Light](https://i.etsystatic.com/19902072/r/il/01eeae/6165152683/il_340x270.6165152683_85a2.jpg)\\
\\
**100% Pure Beeswax Lantern Candles (12 Hours Burn Time Each) - All Natural, Handmade, Unscented Bees Wax Camping Candles by Bee The Light**\\
\\
$17.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/693295988/100-pure-beeswax-lantern-candles-12?click_key=a4d04e4fd2bdcdf1f81a6d829f5102c4%3ALTba1a18b0702f21e4f772e85265ce1aa43585b9ac&click_sum=595c8555&ls=r&ref=related-3&content_source=a4d04e4fd2bdcdf1f81a6d829f5102c4%253ALTba1a18b0702f21e4f772e85265ce1aa43585b9ac "100% Pure Beeswax Lantern Candles (12 Hours Burn Time Each) - All Natural, Handmade, Unscented Bees Wax Camping Candles by Bee The Light")




Add to Favorites


- [![Dipped Taper Candles - 100% Pure Beeswax Candles - 6 Hour Burn Each - 6&quot; - All Natural, Handmade, Unscented Bees Wax Tapers by Bee The Light](https://i.etsystatic.com/19902072/r/il/a87ce1/6117022396/il_340x270.6117022396_4q8p.jpg)\\
\\
**Dipped Taper Candles - 100% Pure Beeswax Candles - 6 Hour Burn Each - 6" - All Natural, Handmade, Unscented Bees Wax Tapers by Bee The Light**\\
\\
$9.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/695960583/dipped-taper-candles-100-pure-beeswax?click_key=c1dfec35879893c45ffb6302240fb82606930ab8%3A695960583&click_sum=d8721c71&ref=related-4 "Dipped Taper Candles - 100% Pure Beeswax Candles - 6 Hour Burn Each - 6\" - All Natural, Handmade, Unscented Bees Wax Tapers by Bee The Light")




Add to Favorites



Loading...

Loading


**Disclaimer:** Button/coin batteries may cause serious injury and even death if swallowed. Items containing button/coin batteries should not be easily accessible without the use of a tool. Sellers are responsible for complying with all applicable labeling, design, testing, packaging, and other safety requirements. Etsy assumes no responsibility for the accuracy or contents of a seller’s listing. If you have questions about button/coin batteries, contact the seller by sending a Message. See Etsy's [Terms of Use](https://www.etsy.com/legal/terms-of-use/?ref=product_safety_banner_info_button_batteries_risk#warranties) for more information.

Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 9, 2025


[1495 favorites](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Tea Lights](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/tea-lights?utm_source=openai&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Home Decor

[Shop Maine Cottage](https://www.etsy.com/market/maine_cottage) [Decorative Pillow](https://www.etsy.com/listing/1352712254/decorative-pillow-turkish-kilim-pillow) [Custom Letter Initial Baby Name Wall Art Prints by LaineeDesignCo](https://www.etsy.com/listing/1795278710/personalized-daisy-white-floral-baby) [Jeffrey Dahmer Gift Dark Humor True Crime Addict My favorite Murder - If you can't beat'em eat'em - Soy Candle 9 oz for Crime Junkie](https://www.etsy.com/listing/1673483290/jeffrey-dahmer-gift-dark-humor-true) [Manhattan Map Print - Black and White - New York Poster by CartoCreative](https://www.etsy.com/listing/197756806/manhattan-map-print-black-and-white-new) [Japanese Woven Rocks - US](https://www.etsy.com/market/japanese_woven_rocks) [Buy Pensacola Landmark Online](https://www.etsy.com/market/pensacola_landmark) [Snorkel Wedding - US](https://www.etsy.com/market/snorkel_wedding) [Holographic Suncatcher for Sale](https://www.etsy.com/market/holographic_suncatcher) [Halloween Front Door Decor - Home Decor](https://www.etsy.com/listing/4333905757/halloween-front-door-decor-halloween)

Canvas & Surfaces

[Graduation Cap Silhouette - US](https://www.etsy.com/market/graduation_cap_silhouette)

Earrings

[Chicos Multicolor Bead Bronze/Brass Statement Earrings](https://www.etsy.com/listing/4300721371/chicos-multicolor-bead-bronzebrass)

Mens Clothing

[Buy Mens Futuristic Suit Online](https://www.etsy.com/market/mens_futuristic_suit) [Leopard Speedo - US](https://www.etsy.com/market/leopard_speedo)

Keychains & Lanyards

[Yacht Key Ring for Sale](https://www.etsy.com/market/yacht_key_ring) [Red And Black Rose And Skulls Silicone Beaded Double Bar Keychain - Keychains & Lanyards](https://www.etsy.com/listing/1841938896/red-and-black-rose-and-skulls-silicone)

Costume Accessories

[Therian mask](https://www.etsy.com/listing/4296954466/therian-mask-white-tiger-mask-please)

Gender Neutral Kids Clothing

[Custom 4th of July Dump Truck Shirt American Boy T-shirt Dump Truck 4th of July Boy Shirt Patriotic Day Dump Truck Shirt For Boys 4th Tee](https://www.etsy.com/listing/4316397685/custom-4th-of-july-dump-truck-shirt)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1302878281%2Fbeeswax-tea-light-candle-100-pure-bees%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc4NzA1MDo3ZmJkODliZmY5Mjg1MWQ0YmEzM2E1MDY4NDMxMzZmZQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1302878281%2Fbeeswax-tea-light-candle-100-pure-bees%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1302878281%2Fbeeswax-tea-light-candle-100-pure-bees%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Item in the photo is in **Pack Size: 48 Pack**




Select this option








Option selected!













This option is sold out.


- Loading


- Item in the photo is in **Pack Size: 24 Pack**




Select this option








Option selected!













This option is sold out.



Click to zoom

- ![May include: A cardboard box with the words 'The Light' and a bee logo printed on the top. The box is open and filled with 24 yellow beeswax tea light candles. Three candles are sitting outside the box on a white surface.](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_300x300.6117018964_qllw.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/BeeTheLight_Video_Trimmed_qmh5cg.jpg)

- ![May include: A box of 12 yellow beeswax tea light candles in a cardboard box with the words 'The Light' and a bee logo printed on the top. The box is open and the candles are visible inside. There are three candles outside of the box on a white surface.](https://i.etsystatic.com/19902072/r/il/d5ceb8/6117018902/il_300x300.6117018902_nvl4.jpg)
- ![May include: A set of 12 unscented, yellow tea light candles in aluminum containers. The candles are 1.5 inches in diameter and 0.5 inches in height. The candles have a burn time of 4 hours each. The candles are arranged in a circle on a white background.](https://i.etsystatic.com/19902072/r/il/8da686/4874318866/il_300x300.4874318866_ij3d.jpg)
- ![May include: A yellow tea light candle in a silver holder](https://i.etsystatic.com/19902072/r/il/071854/4922569493/il_300x300.4922569493_piuw.jpg)
- ![May include: A close-up of several yellow tea light candles with white wicks. The candles are arranged in a circular pattern on a white surface.](https://i.etsystatic.com/19902072/r/il/6d927e/4874322546/il_300x300.4874322546_kxtt.jpg)
- ![May include: Thirty-six yellow tea light candles with white wicks arranged in a rectangular pattern on a white surface.](https://i.etsystatic.com/19902072/r/il/b98102/4922569285/il_300x300.4922569285_gumj.jpg)
- ![May include: Twenty-four yellow tea light candles arranged in a rectangular grid on a white surface. Each candle has a white wick in the center.](https://i.etsystatic.com/19902072/r/il/52e3fe/4922569853/il_300x300.4922569853_lz8p.jpg)
- ![May include: A close-up of a group of unscented tea light candles on a dark brown wooden surface. The candles are white and have a silver base. The candles are lit and the flames are visible. The text 'BURN TIME' and '4 HRS EACH' is visible in the top right corner of the image. The text 'LONG-LASTING' and 'Each candle lasts up to 4 hours' is visible in the top left corner of the image.](https://i.etsystatic.com/19902072/r/il/fb9cf9/4922579865/il_300x300.4922579865_cq7o.jpg)
- ![May include: A set of 24 unscented, pure beeswax tea light candles. The candles are arranged in a circle and are surrounded by icons that describe the product features, including: USA beeswax, fair trade, handmade, cruelty free, smokeless, non-toxic, and ecological.](https://i.etsystatic.com/19902072/r/il/9c4481/4922580291/il_300x300.4922580291_5okx.jpg)
- ![May include: Multipurpose tea light candles in a white container. The candles are shown in four different settings: a date night, a wedding, a bedroom, and a dinner table.](https://i.etsystatic.com/19902072/r/il/fb0137/4874320186/il_300x300.4874320186_tle5.jpg)

- ![](https://i.etsystatic.com/iap/e8c071/6578641088/iap_640x640.6578641088_4v08o9ng.jpg?version=0)

5 out of 5 stars

- Pack Size:

24 Pack


Second time ordering, is now my go to

![](https://i.etsystatic.com/iusa/15e380/26339631/iusa_75x75.26339631_g2n6.jpg?version=0)

Jan 18, 2025


[patricia seaman](https://www.etsy.com/people/patriciaseaman13)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/651f67/7422178535/iap_640x640.7422178535_f8jrhvyn.jpg?version=0)

5 out of 5 stars

- Pack Size:

24 Pack


Lovely light, burns very evenly. Slow burning.

![](https://i.etsystatic.com/iusa/61c0a3/34266911/iusa_75x75.34266911_eo0t.jpg?version=0)

Nov 8, 2025


[Becki Persons](https://www.etsy.com/people/beckipersons)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/ada5ff/6310777244/iap_640x640.6310777244_5abbombq.jpg?version=0)

5 out of 5 stars

- Quantity:

Bulk box of 192


Arrived quickly and exactly what I expected. I love the smell of natural beeswax.

Sep 29, 2024


[Carly H](https://www.etsy.com/people/cahutchinson2007)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/5a13f2/5657880696/iap_640x640.5657880696_720c4kg3.jpg?version=0)

5 out of 5 stars

- Quantity:

24 Pack


Amazing quality, Well packaged, shipped so fast, smell great, look great….10/10 y’all!! Thank you, will be buying more in the future! 🙏🏻

Jan 9, 2024


[Mary Jane Srdar](https://www.etsy.com/people/prkjj8f5)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/b04f56/6787613435/iap_640x640.6787613435_mcxnuqui.jpg?version=0)

5 out of 5 stars

- Pack Size:

24 Pack


These candles are fantastic. I use them on my family altar I have in my living room. I keep five of the tea lights (safely) lit for the entire day when I know I will be home with them, and they stay lit for the entirety of the afternoon. The warm honey fragrance is wonderful without being over powering, and if you follow the instructions they give for proper burning, you will get no soot at all. Also, every ounce of wax was used up.
The packaging was very sturdy and secure so no candles had any sort of damage, plus everything is recyclable so there’s no plastic waste.
I highly recommend this family business and the causes they dedicate their time to.

![](https://i.etsystatic.com/iusa/bbadfc/58631262/iusa_75x75.58631262_i34v.jpg?version=0)

Mar 23, 2025


[Shanna Burns](https://www.etsy.com/people/DesignsOfTheMind)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/668dde/5140164700/iap_640x640.5140164700_mxf26zzm.jpg?version=0)

5 out of 5 stars

- Quantity:

48 Pack


These marvelous tea lights burn cleanly and thoroughly. I’m definitely going to buy more when the time comes!

![](https://i.etsystatic.com/iusa/66d0f1/82922063/iusa_75x75.82922063_8qgk.jpg?version=0)

Jul 31, 2023


[Saskia Dunadair](https://www.etsy.com/people/BryherOShae)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/6015a1/5823833193/iap_640x640.5823833193_fc3azjgg.jpg?version=0)

5 out of 5 stars

- Quantity:

48 Pack


I use your tea lights every night!

Feb 19, 2024


[kmo0612](https://www.etsy.com/people/kmo0612)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/89f695/6854515686/iap_640x640.6854515686_ec45zk0h.jpg?version=0)

5 out of 5 stars

- Pack Size:

24 Pack


Really high-quality tea lights made with bee's wax! I like using them for my wax warmers and they burn for awhile. The price of these is reasonable and the seller shipped them quickly. I have and will order from this seller again!

![](https://i.etsystatic.com/iusa/bdea0d/83391281/iusa_75x75.83391281_k91q.jpg?version=0)

May 11, 2025


[Kaelie C](https://www.etsy.com/people/kconnors88)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/d4fdc6/6498252817/iap_640x640.6498252817_hggcu0wj.jpg?version=0)

5 out of 5 stars

- Pack Size:

24 Pack


Opening the package you can instantly smell the beeswax and honey of it all. I’m using it to burn some loose incense and is amazing. This takes so long you burn down. I will be a returning customer.

Hive/Hive (5/5 stars)

Nov 21, 2024


[Gabriel Cordova](https://www.etsy.com/people/cjybjsos)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/472122/6617490092/iap_640x640.6617490092_4fi99i8g.jpg?version=0)

5 out of 5 stars

- Pack Size:

48 Pack


Beautiful tea lite candles! I am a repeat customer because these are by far the best beeswax crafted tea lite candles ever! They have a sweet honey smell as they burn. And they burn beautifully. They were packaged well and smell wonderful in the box, and shipped fast! I light one every morning as I sit and ponder the day with Jesus. Amen! 🙏🏻💜☮️

Feb 3, 2025


[Deborah](https://www.etsy.com/people/gwmzc48v)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/e51d6e/6818301556/iap_640x640.6818301556_sxomj4yd.jpg?version=0)

5 out of 5 stars

- Pack Size:

24 Pack


Awesome, high-quality candles - great for use in wax warmers and other candle holders or warmers! I love the logo and that this seller supports meaningful work to help others, it's much appreciated and definitely makes me want to buy more soon. I will be ordering again soon and recommend this shop to anyone that wants high-quality bee wax candles for a good price and wants to support their community and small businesses!

![](https://i.etsystatic.com/iusa/bdea0d/83391281/iusa_75x75.83391281_k91q.jpg?version=0)

Apr 25, 2025


[Kaelie C](https://www.etsy.com/people/kconnors88)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/ccfa5a/5672407411/iap_640x640.5672407411_h40mr012.jpg?version=0)

5 out of 5 stars

- Quantity:

48 Pack


Great experience. Will back. Ty!

![](https://i.etsystatic.com/iusa/c20b57/112696690/iusa_75x75.112696690_5un6.jpg?version=0)

Dec 27, 2023


[Allegra W Lamb](https://www.etsy.com/people/finyx)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/a46f54/4617990869/iap_640x640.4617990869_gysa9n1r.jpg?version=0)

5 out of 5 stars

- Quantity:

48 Pack


The honey bee tea candle was arrived safely with detailed instructions.

Jan 28, 2023


[Emi Coffman](https://www.etsy.com/people/emicoffman)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/257f99/6855952103/iap_640x640.6855952103_4nnbu5rm.jpg?version=0)

5 out of 5 stars

- Pack Size:

24 Pack


Received today! Smells like honey 🍯 and burns beautifully.

![](https://i.etsystatic.com/iusa/553935/23351343/iusa_75x75.23351343_bukh.jpg?version=0)

Apr 21, 2025


[LatinTemptress](https://www.etsy.com/people/LatinTemptress)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/488f96/7201857536/iap_640x640.7201857536_7pkb1j3l.jpg?version=0)

5 out of 5 stars

- Pack Size:

48 Pack


What beautiful beeswax tea lights! They arrived quickly and are very pleasant smelling. Solid quality product! I am pleased.

![](https://i.etsystatic.com/iusa/1ba8fa/97438511/iusa_75x75.97438511_k2ma.jpg?version=0)

Sep 15, 2025


[The.Fountainhead](https://www.etsy.com/people/leo1975)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/a32ed6/6881095232/iap_640x640.6881095232_8ge04t6r.jpg?version=0)

5 out of 5 stars

- Pack Size:

48 Pack


Beautiful quality beeswax candles - I absolutely love these and how all the profits go to help local charities and initiatives! It was great to read that when I opened my order. These candles burn for awhile and are worth the price for sure. The seller ships them quickly and none of mine have been damaged in shipping (I have ordered more than 2 times now). I will be ordering more in the future as these are worth the price!

![](https://i.etsystatic.com/iusa/bdea0d/83391281/iusa_75x75.83391281_k91q.jpg?version=0)

May 22, 2025


[Kaelie C](https://www.etsy.com/people/kconnors88)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/359bda/4660938753/iap_640x640.4660938753_smcem271.jpg?version=0)

5 out of 5 stars

- Quantity:

48 Pack


These burn SO CLEAN! I’m sensitive to smells, chemicals, life - but I love candles. I am always on the search for a good candle that doesn’t give me headaches from smoke or scents. These are lovely. They burned a long time, no detectable smoke, and just a pleasant warm natural wax scent that didn’t bother me at all. Please never stop selling these. So good!

![](https://i.etsystatic.com/iusa/2731dd/56289346/iusa_75x75.56289346_s9jc.jpg?version=0)

Feb 9, 2023


[psully1387](https://www.etsy.com/people/psully1387)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/837766/6566579652/iap_640x640.6566579652_o0m5az7x.jpg?version=0)

5 out of 5 stars

- Pack Size:

24 Pack


Cute packaging and the candles are great! As described, and can't wait to use them! Love that they are in tins and not plastic.😃

![](https://i.etsystatic.com/iusa/9edc2d/24845640/iusa_75x75.24845640_ol2c.jpg?version=0)

Jan 13, 2025


[Karen M](https://www.etsy.com/people/KaLyMerc)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/783448/5067021726/iap_640x640.5067021726_6tw22hrw.jpg?version=0)

5 out of 5 stars

- Quantity:

24 Pack


These candles are very pure and burn nicely at my prayer corner. Thank you!

![](https://i.etsystatic.com/iusa/61502a/87680115/iusa_75x75.87680115_eo3n.jpg?version=0)

Jul 6, 2023


[Amelia M.](https://www.etsy.com/people/ameliarod83)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/6127e5/4496570094/iap_640x640.4496570094_qxbk2mhf.jpg?version=0)

5 out of 5 stars

- Quantity:

48 Pack


Wonderful seller with prompt delivery! I’ll be returning for more, thank you.

![](https://i.etsystatic.com/iusa/544ace/106971121/iusa_75x75.106971121_j28z.jpg?version=0)

Jan 6, 2023


[Cat Whiskers](https://www.etsy.com/people/ucdmcnicurn)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)

Purchased item:

[![Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light](https://i.etsystatic.com/19902072/r/il/94eb72/6117018964/il_170x135.6117018964_qllw.jpg)\\
\\
Beeswax Tea Light Candle - 100% Pure Bees Wax (4 Hours Burn Time Each) - All Natural Handmade Candles - Unscented Tealights by Bee The Light\\
\\
$28.99](https://www.etsy.com/listing/1302878281/beeswax-tea-light-candle-100-pure-bees?ref=ap-listing)