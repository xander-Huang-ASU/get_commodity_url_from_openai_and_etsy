[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1360343063/neutral-abstract-set-of-3-wall-art?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Prints](https://www.etsy.com/c/art-and-collectibles/prints?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Digital Prints](https://www.etsy.com/c/art-and-collectibles/prints/digital-prints?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)


Add to Favorites


- ![May include: A living room interior with a white sectional sofa, three framed abstract paintings in neutral colors, a wooden coffee table, a gray throw blanket, a gray and white rug, a lamp with a white shade, a potted plant with dried brown reeds, and a vase with dried brown reeds.](https://i.etsystatic.com/10962041/r/il/b6433f/4445707542/il_794xN.4445707542_87qv.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![May include: A brown sectional sofa with a throw blanket and pillows. The sofa is in a living room with three framed abstract art prints on the wall behind it. There is a wooden coffee table in front of the sofa and a woven basket on the floor next to the sofa.](https://i.etsystatic.com/10962041/r/il/50c891/4400725402/il_794xN.4400725402_ry5o.jpg)
- ![May include: A light brown wicker chair with a tan pillow and a white blanket draped over the back. The chair is in front of a white wall with three framed abstract paintings. A white cabinet with two drawers and two doors is to the right of the chair. The cabinet has a light brown top and a basket is sitting on the floor in front of it.](https://i.etsystatic.com/10962041/r/il/8788a4/4448109253/il_794xN.4448109253_3uux.jpg)
- ![May include: A living room with a white couch, a white armchair, a wooden coffee table, a floor lamp with a white shade, and three abstract paintings on the wall. The paintings are in shades of brown, gray, and white. The coffee table has a vase with dried flowers and a book on top. The floor is covered in a light brown rug.](https://i.etsystatic.com/10962041/r/il/e9967c/4448109183/il_794xN.4448109183_tevn.jpg)
- ![May include: Three framed abstract paintings with a beige background and black and brown brushstrokes. The paintings are hanging above a white headboard with a white, beige, and brown pillow arrangement.](https://i.etsystatic.com/10962041/r/il/081bc0/4400718314/il_794xN.4400718314_kjgf.jpg)
- ![May include: A bedroom with a bed with a white duvet and a gray blanket, a wooden side table with a lamp, a wooden coffee table with a vase of dried flowers, a book, a candle, and a cup, and three framed abstract paintings with brown and black paint on a white background.](https://i.etsystatic.com/10962041/r/il/c9942d/4400718406/il_794xN.4400718406_5vdd.jpg)

- ![May include: A living room interior with a white sectional sofa, three framed abstract paintings in neutral colors, a wooden coffee table, a gray throw blanket, a gray and white rug, a lamp with a white shade, a potted plant with dried brown reeds, and a vase with dried brown reeds.](https://i.etsystatic.com/10962041/c/1433/1139/845/79/il/b6433f/4445707542/il_75x75.4445707542_87qv.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/abc_hk5yma.jpg)

- ![May include: A brown sectional sofa with a throw blanket and pillows. The sofa is in a living room with three framed abstract art prints on the wall behind it. There is a wooden coffee table in front of the sofa and a woven basket on the floor next to the sofa.](https://i.etsystatic.com/10962041/c/1922/1528/16/24/il/50c891/4400725402/il_75x75.4400725402_ry5o.jpg)
- ![May include: A light brown wicker chair with a tan pillow and a white blanket draped over the back. The chair is in front of a white wall with three framed abstract paintings. A white cabinet with two drawers and two doors is to the right of the chair. The cabinet has a light brown top and a basket is sitting on the floor in front of it.](https://i.etsystatic.com/10962041/r/il/8788a4/4448109253/il_75x75.4448109253_3uux.jpg)
- ![May include: A living room with a white couch, a white armchair, a wooden coffee table, a floor lamp with a white shade, and three abstract paintings on the wall. The paintings are in shades of brown, gray, and white. The coffee table has a vase with dried flowers and a book on top. The floor is covered in a light brown rug.](https://i.etsystatic.com/10962041/r/il/e9967c/4448109183/il_75x75.4448109183_tevn.jpg)
- ![May include: Three framed abstract paintings with a beige background and black and brown brushstrokes. The paintings are hanging above a white headboard with a white, beige, and brown pillow arrangement.](https://i.etsystatic.com/10962041/r/il/081bc0/4400718314/il_75x75.4400718314_kjgf.jpg)
- ![May include: A bedroom with a bed with a white duvet and a gray blanket, a wooden side table with a lamp, a wooden coffee table with a vase of dried flowers, a book, a candle, and a cup, and three framed abstract paintings with brown and black paint on a white background.](https://i.etsystatic.com/10962041/r/il/c9942d/4400718406/il_75x75.4400718406_5vdd.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1360343063%2Fneutral-abstract-set-of-3-wall-art%23report-overlay-trigger)

Price:$12.73


Loading


# Neutral Abstract Set of 3 Wall Art Prints, Line Art, Modern Abstract Minimalist Brush Strokes, Beige Black Gallery Wall Decor, Printable Art

Designed by [synplus](https://www.etsy.com/shop/synplus)

[5 out of 5 stars](https://www.etsy.com/listing/1360343063/neutral-abstract-set-of-3-wall-art?utm_source=openai#reviews)

4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Designed by [synplus](https://www.etsy.com/shop/synplus)

- Digital download


- Digital file type(s): 1 PDF


► INSTANT DOWNLOAD:

Neutral Modern Wall Art Set of 3 Nordic Prints, Simple Abstract Art Minimalist Brush Strokes, Modern Line Art. This printable art features brush stroke paintings in neutral tones of beige and black. These artworks can add a contemporary feel to your home, living room, bedroom, office or any other space.

• PRINTABLE ART:

This printable art is easily customizable to 20+ sizes and instantly accessible as digital download. Simply download the digital files and print them at home, take them to your local print shop or upload to an online printing service and have them delivered to your door! You get the a lot of flexibility in choosing the size, framing options and printing on anything you'd like paper, canvas, wood, metal and more. (Personal use only - commercial resale is prohibited)

This is a DIGITAL DOWNLOAD item. This listing includes only digital files.

For PERSONAL USE only. Commercial use is not permitted. Do not share, edit, modify, resale or distribute in any way.

• HOW TO DOWNLOAD?

As soon as you check out your file will be available to download right here on Etsy. You can access your files through You>Purchases&Reviews>Order and click Download. If you are using mobile device you need to login in to your Etsy account from your device's browser and not the Etsy app, since it doesn't have a download option. Additionally, you will receive an email after the checkout process that your payment has processed and it will include a link to your download.

• WHERE TO PRINT?

Print the downloaded file at your local print shop, your favorite online printer, or print it yourself at home. You can use a printing service like Staples, Walgreen's, Kinko's, FedEx, Walmart, Target, Costco, Officeworks, Boots, Harvey Norman, Mpix, WHCC, Blick Art, Finerworks.com, Persnicketyprints.com etc. For printing we recommend using archival quality heavyweight matte paper.

F I L E S – I N C L U D E D:

Each abstract design includes 5 jpegs in high-resolution (300 dots per inch):

FILE 1 - Image size 24"x 30" - Ratio 4:5

Can be printed on sizes: 4"x 5", 8"x 10", 12"x 15", 16"x 20", 24"x 30", 40 x 50 cm

FILE 2 - Image size 24"x 32" - Ratio 3:4

Can be printed on sizes: 6"x 8", 9"x 12", 18"x 24", 21"x 28", 24"x 32", 60 x 80 cm

FILE 3 - Image size 24"x 36" - Ratio 2:3

Can be printed on sizes: 4"x 6", 6"x 9", 8"x 12", 10"x 15", 12"x 18", 16"x 24", 20"x 30", 24"x 36", 60 x 90 cm

FILE 4 - Image size A1 - 594 mm x 841 mm (ISO 216)

Can be printed on sizes: A5, A4, A3, A2, A1

FILE 5 - Image size 11"x 14", 22"x 28"

KINDLY NOTE

This is a DIGITAL DOWNLOAD file. NO PHYSICAL print will be shipped to your address. Frame is not included. Colors may vary on different color monitors and on print.

COPYRIGHT NOTICE

The artwork in this shop is the property of Synplus. This download is strictly for PERSONAL USE ONLY. Commercial use is not permitted. Do not share, edit, modify, resale or distribute in any way.

By purchasing this design you agree and are bound by the copyright agreement.

Artwork is copyright © of Synplus.

...............................................................

Visit our website for more designs at:

https://www.synplusart.com

https://www.instagram.com/synplusart


## Delivery

Instant Download

Your files will be available to download once payment is confirmed.
[Here's how.](https://www.etsy.com/help/article/3949)

Instant download items don’t accept returns, exchanges or cancellations. Please contact the seller about any problems with your order.

## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

View additional shop policies

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (1)

Loading


5 out of 5 stars
5

This item

[Jackie Swerdon](https://www.etsy.com/people/jackieswer?ref=l_review)
Mar 20, 2023


[Jackie Swerdon](https://www.etsy.com/people/jackieswer?ref=l_review)
Mar 20, 2023


[![synplus](https://i.etsystatic.com/iusa/3979aa/88120726/iusa_75x75.88120726_n71r.jpg?version=0)](https://www.etsy.com/shop/synplus?ref=shop_profile&listing_id=1360343063)

[synplus](https://www.etsy.com/shop/synplus?ref=shop_profile&listing_id=1360343063)

[Owned by synplusLR](https://www.etsy.com/shop/synplus?ref=shop_profile&listing_id=1360343063) \|

New York, United States

4.9
(3.8k)


58.8k sales

10 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=64317300&referring_id=1360343063&referring_type=listing&recipient_id=64317300&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo2NDMxNzMwMDoxNzYyNzY4ODIyOmY4NDhlNzhhMDNjYzg3MmU2M2RiYjliNGE4NWUyYmQ5&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1360343063%2Fneutral-abstract-set-of-3-wall-art%3Futm_source%3Dopenai)

This seller usually responds **within 24 hours.**

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/synplus?ref=lp_mys_mfts)

- [![Neutral Gallery Wall Art Set of 6 Abstract Prints, Beige Black White Abstract Minimalist Brush Strokes, Line Art, Modern Wall Art, Printable](https://i.etsystatic.com/10962041/c/1739/1739/0/0/il/a48295/7300632066/il_340x270.7300632066_6glq.jpg)\\
\\
Digital download\\
\\
\\
**Neutral Gallery Wall Art Set of 6 Abstract Prints, Beige Black White Abstract Minimalist Brush Strokes, Line Art, Modern Wall Art, Printable**\\
\\
Sale Price $25.46\\
$25.46\\
\\
$36.37\\
Original Price $36.37\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1343071342/neutral-gallery-wall-art-set-of-6?click_key=a4be45140ea0af865cad2dff54398b55%3ALT138e1d3749a00dfae6e9c33124464ec43fa37380&click_sum=c184e612&ls=r&ref=related-1&pro=1&dd=1&content_source=a4be45140ea0af865cad2dff54398b55%253ALT138e1d3749a00dfae6e9c33124464ec43fa37380 "Neutral Gallery Wall Art Set of 6 Abstract Prints, Beige Black White Abstract Minimalist Brush Strokes, Line Art, Modern Wall Art, Printable")




Add to Favorites


- [![Set of 3 Abstract Print, Beige White Brush Strokes Wall Art, Neutral Soft Tones Minimalist Bedroom Living Room Wall Art Decor, Printable Art](https://i.etsystatic.com/10962041/c/1160/1160/73/43/il/bb2947/7324561872/il_340x270.7324561872_8xrn.jpg)\\
\\
Digital download\\
\\
\\
**Set of 3 Abstract Print, Beige White Brush Strokes Wall Art, Neutral Soft Tones Minimalist Bedroom Living Room Wall Art Decor, Printable Art**\\
\\
Sale Price $12.73\\
$12.73\\
\\
$18.19\\
Original Price $18.19\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1624750386/set-of-3-abstract-print-beige-white?click_key=a4be45140ea0af865cad2dff54398b55%3ALT20494f331e57f9fdd207711a0dfe7aa9cfe47005&click_sum=d5029e83&ls=r&ref=related-2&pro=1&dd=1&content_source=a4be45140ea0af865cad2dff54398b55%253ALT20494f331e57f9fdd207711a0dfe7aa9cfe47005 "Set of 3 Abstract Print, Beige White Brush Strokes Wall Art, Neutral Soft Tones Minimalist Bedroom Living Room Wall Art Decor, Printable Art")




Add to Favorites


- [![Set of 3 Abstract Wall Art Prints, Beige Brown Black Watercolor Painting Art, Modern Minimalist Living Room Wall Art, Home Decor, Printable](https://i.etsystatic.com/10962041/c/1493/1187/740/108/il/75b0e0/5874934755/il_340x270.5874934755_33nm.jpg)\\
\\
Digital download\\
\\
\\
**Set of 3 Abstract Wall Art Prints, Beige Brown Black Watercolor Painting Art, Modern Minimalist Living Room Wall Art, Home Decor, Printable**\\
\\
Sale Price $12.73\\
$12.73\\
\\
$18.19\\
Original Price $18.19\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1678699690/set-of-3-abstract-wall-art-prints-beige?click_key=a4be45140ea0af865cad2dff54398b55%3ALT3cd47f67b72aff4ec4dbe26a29bc798538d1b3e5&click_sum=f0cd6dd7&ls=r&ref=related-3&pro=1&dd=1&content_source=a4be45140ea0af865cad2dff54398b55%253ALT3cd47f67b72aff4ec4dbe26a29bc798538d1b3e5 "Set of 3 Abstract Wall Art Prints, Beige Brown Black Watercolor Painting Art, Modern Minimalist Living Room Wall Art, Home Decor, Printable")




Add to Favorites


- [![Beige Black White Abstract Wall Art Prints, Brush Strokes Paintings Set of 3, Line Art, Minimalist Neutral Gallery Wall Decor, Printable Art](https://i.etsystatic.com/10962041/c/1412/1122/863/66/il/9e074e/4304507222/il_340x270.4304507222_mcsw.jpg)\\
\\
Digital download\\
\\
\\
**Beige Black White Abstract Wall Art Prints, Brush Strokes Paintings Set of 3, Line Art, Minimalist Neutral Gallery Wall Decor, Printable Art**\\
\\
Sale Price $12.73\\
$12.73\\
\\
$18.19\\
Original Price $18.19\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1323051822/beige-black-white-abstract-wall-art?click_key=a4be45140ea0af865cad2dff54398b55%3ALT6987de779fd9fed17be56d79f8b9ed003190af47&click_sum=f5e80a82&ls=r&ref=related-4&pro=1&dd=1&content_source=a4be45140ea0af865cad2dff54398b55%253ALT6987de779fd9fed17be56d79f8b9ed003190af47 "Beige Black White Abstract Wall Art Prints, Brush Strokes Paintings Set of 3, Line Art, Minimalist Neutral Gallery Wall Decor, Printable Art")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Oct 1, 2025


[79 favorites](https://www.etsy.com/listing/1360343063/neutral-abstract-set-of-3-wall-art/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Prints](https://www.etsy.com/c/art-and-collectibles/prints?utm_source=openai&explicit=1&ref=breadcrumb_listing) [Digital Prints](https://www.etsy.com/c/art-and-collectibles/prints/digital-prints?utm_source=openai&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Prints

[Buy Bratz Cup Wrap Png Online](https://www.etsy.com/market/bratz_cup_wrap_png) [Vintage Style Botanical Illustration - Prints](https://www.etsy.com/listing/640396884/elephant-ear-plant-print-vintage-style) [Buy Kintsugi Svg Online](https://www.etsy.com/market/kintsugi_svg) [Best Dad 11oz Mug Template - Prints](https://www.etsy.com/listing/1725851553/best-dad-in-the-world-3d-inflated-mug) [Buy Lone Wolf Painting Online](https://www.etsy.com/market/lone_wolf_painting) [Botanical Floral Line Work Design by GeoGiaDesign](https://www.etsy.com/listing/908213325/minimalist-flower-bouquet-digital-wall) [East Greenwich Ri Art for Sale](https://www.etsy.com/market/east_greenwich_ri_art) [Vibrant Nature Art](https://www.etsy.com/listing/1733496298/hummingbird-in-nest-watercolor-print) [Mississippi or ANY STATE Wedding Gift - Personalized State and Heart - Custom Date by EmbieDesign](https://www.etsy.com/listing/108430042/mississippi-or-any-state-wedding-gift) [Cute Duck Drawing - Prints](https://www.etsy.com/listing/1847192635/vintage-duck-nursery-art-cute-duck) [4th Of July America Png](https://www.etsy.com/listing/4305870890/est-1776-patriotic-us-american-flag-svg) [Audubon Blue Jay for Sale](https://www.etsy.com/market/audubon_blue_jay)

Furniture

[Bone Inlay Chest](https://www.etsy.com/listing/1475089451/bone-inlay-three-drawer-cabinet-black) [Made to measure radiator covers any size by CebilBoutique](https://www.etsy.com/listing/1758239167/made-to-measure-radiator-covers-any-size)

Rings

[Dainty Diamond Promise Ring](https://www.etsy.com/listing/1168095453/dainty-diamond-promise-ring-womens)

Fiber Arts

[Mola Depicting Battalion 2000 of the Panama Defense Forces by ZenaKruzickTribalArt](https://www.etsy.com/listing/1500297283/mola-depicting-battalion-2000-of-the)

Gender Neutral Adult Clothing

[Acupuncture Skeleton St. Patricks Day Shirt - Gender-Neutral Adult Clothing](https://www.etsy.com/listing/1662229751/acupuncture-skeleton-st-patricks-day)

Shopping

[24 X 36 Print Keith Haring for Sale](https://www.etsy.com/market/24_x_36_print_keith_haring)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1360343063%2Fneutral-abstract-set-of-3-wall-art%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc2ODgyMjo2NTBjYjc1MDg1YWM1NmQ3MjExNGIxNDE0OWEwMzkyZA==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1360343063%2Fneutral-abstract-set-of-3-wall-art%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1360343063/neutral-abstract-set-of-3-wall-art?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1360343063%2Fneutral-abstract-set-of-3-wall-art%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for synplus

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## Seller details

### Other details

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=64317300&referring_id=10962041&referring_type=shop&recipient_id=64317300&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![May include: A living room interior with a white sectional sofa, three framed abstract paintings in neutral colors, a wooden coffee table, a gray throw blanket, a gray and white rug, a lamp with a white shade, a potted plant with dried brown reeds, and a vase with dried brown reeds.](https://i.etsystatic.com/10962041/c/1433/1433/845/0/il/b6433f/4445707542/il_300x300.4445707542_87qv.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/abc_hk5yma.jpg)

- ![May include: A brown sectional sofa with a throw blanket and pillows. The sofa is in a living room with three framed abstract art prints on the wall behind it. There is a wooden coffee table in front of the sofa and a woven basket on the floor next to the sofa.](https://i.etsystatic.com/10962041/c/1922/1922/16/0/il/50c891/4400725402/il_300x300.4400725402_ry5o.jpg)
- ![May include: A light brown wicker chair with a tan pillow and a white blanket draped over the back. The chair is in front of a white wall with three framed abstract paintings. A white cabinet with two drawers and two doors is to the right of the chair. The cabinet has a light brown top and a basket is sitting on the floor in front of it.](https://i.etsystatic.com/10962041/r/il/8788a4/4448109253/il_300x300.4448109253_3uux.jpg)
- ![May include: A living room with a white couch, a white armchair, a wooden coffee table, a floor lamp with a white shade, and three abstract paintings on the wall. The paintings are in shades of brown, gray, and white. The coffee table has a vase with dried flowers and a book on top. The floor is covered in a light brown rug.](https://i.etsystatic.com/10962041/r/il/e9967c/4448109183/il_300x300.4448109183_tevn.jpg)
- ![May include: Three framed abstract paintings with a beige background and black and brown brushstrokes. The paintings are hanging above a white headboard with a white, beige, and brown pillow arrangement.](https://i.etsystatic.com/10962041/r/il/081bc0/4400718314/il_300x300.4400718314_kjgf.jpg)
- ![May include: A bedroom with a bed with a white duvet and a gray blanket, a wooden side table with a lamp, a wooden coffee table with a vase of dried flowers, a book, a candle, and a cup, and three framed abstract paintings with brown and black paint on a white background.](https://i.etsystatic.com/10962041/r/il/c9942d/4400718406/il_300x300.4400718406_5vdd.jpg)