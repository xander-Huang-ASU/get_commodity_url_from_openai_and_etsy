[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1414663734/?utm_source=openai#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?utm_source=openai&explicit=1&ref=catnav_breadcrumb-0)
- [Prints](https://www.etsy.com/c/art-and-collectibles/prints?utm_source=openai&explicit=1&ref=catnav_breadcrumb-1)
- [Giclée](https://www.etsy.com/c/art-and-collectibles/prints/giclee?utm_source=openai&explicit=1&ref=catnav_breadcrumb-2)

Sorry, this item is unavailable.

### Similar items on Etsy

(Results include adsLearn more
Sellers looking to grow their business and reach more interested buyers can use Etsy’s advertising platform to promote their items. You’ll see ad results based on factors like relevancy, and the amount sellers pay per click. [Learn more](https://www.etsy.com/legal/policy/search-advertisement-ranking-disclosures/899478564529).
)

- [![Bauhaus Wall Art Set: Retro Abstract Exhibition Posters](https://i.etsystatic.com/24595100/r/il/ac2b14/6175309238/il_340x270.6175309238_osic.jpg)\\
\\
**Bauhaus Wall Art Set: Retro Abstract Exhibition Posters**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
KarmenArtPrints\\
From shop KarmenArtPrints\\
\\
Sale Price $39.40\\
$39.40\\
\\
$78.80\\
Original Price $78.80\\
\\
\\
(50% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1431121790/bauhaus-wall-art-set-retro-abstract?click_key=LT6a055e4e22ec75ca7c8b695a513a6f6af927e9c4%3A1431121790&click_sum=8296d72a&ls=a&ref=sold_out_ad-1&pro=1&frs=1 "Bauhaus Wall Art Set: Retro Abstract Exhibition Posters")





Add to Favorites


- [![2 Geometric Abstract Prints (Giclée Fine Art Prints on Paper or Canvas) SYSTEMS by Jazzberry Blue (Framed or Unframed](https://i.etsystatic.com/6668013/r/il/522c53/7042101964/il_340x270.7042101964_tjl2.jpg)\\
\\
**2 Geometric Abstract Prints (Giclée Fine Art Prints on Paper or Canvas) SYSTEMS by Jazzberry Blue (Framed or Unframed**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
JazzberryBlue\\
From shop JazzberryBlue\\
\\
$46.00\\
\\
FREE shipping](https://www.etsy.com/listing/660563404/2-geometric-abstract-prints-giclee-fine?click_key=LT74d1584683ede8c1862e6ba34849fc08f230509d%3A660563404&click_sum=26dfe365&ls=a&ref=sold_out_ad-2&frs=1&sts=1 "2 Geometric Abstract Prints (Giclée Fine Art Prints on Paper or Canvas) SYSTEMS by Jazzberry Blue (Framed or Unframed")





Add to Favorites


- [![Midcentury Modern Desert Landscape Art Print: Retro Western Sunset](https://i.etsystatic.com/23256673/r/il/7f9928/7173156416/il_340x270.7173156416_r176.jpg)\\
\\
**Midcentury Modern Desert Landscape Art Print: Retro Western Sunset**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
ElBakerArt\\
From shop ElBakerArt\\
\\
$30.00\\
\\
FREE shipping](https://www.etsy.com/listing/1670795053/midcentury-modern-desert-landscape-art?click_key=LT2533608e37998dd2926d10374e2e0245825f592e%3A1670795053&click_sum=45e80cc9&ls=a&ref=sold_out_ad-3&frs=1&sts=1 "Midcentury Modern Desert Landscape Art Print: Retro Western Sunset")





Add to Favorites


- [![Aerial Beach Print Coastal Prints People On The Beach Wall Art Minimalist Neutral Beach Wall Decor Sea Print Beach Poster Summer Art Print](https://i.etsystatic.com/39244760/r/il/906c9a/5566371261/il_340x270.5566371261_aa6b.jpg)\\
\\
**Aerial Beach Print Coastal Prints People On The Beach Wall Art Minimalist Neutral Beach Wall Decor Sea Print Beach Poster Summer Art Print**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
luciademiguelart\\
From shop luciademiguelart\\
\\
Sale Price $32.00\\
$32.00\\
\\
$40.00\\
Original Price $40.00\\
\\
\\
(20% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1576655226/aerial-beach-print-coastal-prints-people?click_key=LT31c36c04020b5c76c31a41f1131808f392f6bb89%3A1576655226&click_sum=5e61e31c&ls=a&ref=sold_out_ad-4&pro=1&frs=1 "Aerial Beach Print Coastal Prints People On The Beach Wall Art Minimalist Neutral Beach Wall Decor Sea Print Beach Poster Summer Art Print")





Add to Favorites


- [![Abstract Wall Art Print: Colorful Mid Century Modern Painting, Large Wall Decor, Framed Canvas](https://i.etsystatic.com/5821145/c/1250/1250/391/88/il/1974e3/7359170497/il_340x270.7359170497_jpp1.jpg)\\
\\
**Abstract Wall Art Print: Colorful Mid Century Modern Painting, Large Wall Decor, Framed Canvas**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
BlossomMind\\
From shop BlossomMind\\
\\
Sale Price $37.39\\
$37.39\\
\\
$53.41\\
Original Price $53.41\\
\\
\\
(30% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/4391074102/abstract-wall-art-print-colorful-mid?click_key=LTdfc4f84f5fed991ead08e5d16cc009311547b605%3A4391074102&click_sum=5b0f520e&ls=a&ref=sold_out_ad-5&pro=1&frs=1&sts=1 "Abstract Wall Art Print: Colorful Mid Century Modern Painting, Large Wall Decor, Framed Canvas")





Add to Favorites


- [![Bernard Villemot Exhibition Poster - Vintage French Art Show Print, Resting Woman Illustration, Retro Gallery Wall Decor](https://i.etsystatic.com/46061014/r/il/520015/7291672095/il_340x270.7291672095_5ist.jpg)\\
\\
**Bernard Villemot Exhibition Poster - Vintage French Art Show Print, Resting Woman Illustration, Retro Gallery Wall Decor**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
DecoXOX\\
From shop DecoXOX\\
\\
Sale Price $15.75\\
$15.75\\
\\
$21.00\\
Original Price $21.00\\
\\
\\
(25% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/4345045506/bernard-villemot-exhibition-poster?click_key=LT044c2b54407b62496f761bcf08af23fde2910997%3A4345045506&click_sum=6dc0e5f4&ls=a&ref=sold_out_ad-6&pro=1&frs=1&sts=1 "Bernard Villemot Exhibition Poster - Vintage French Art Show Print, Resting Woman Illustration, Retro Gallery Wall Decor")





Add to Favorites


- [![2026 Calendar](https://i.etsystatic.com/33953589/r/il/973d65/7266838926/il_340x270.7266838926_s6df.jpg)\\
\\
**2026 Calendar**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
SheWalksShePaints\\
From shop SheWalksShePaints\\
\\
$32.94](https://www.etsy.com/listing/4383300041/2026-calendar?click_key=49c4a3c6a40fae4474366aafabbedfd7c09a1617%3A4383300041&click_sum=1925e46d&ref=sold_out-1&bes=1 "2026 Calendar")





Add to Favorites


- [![Anfield Stadium Poster, Liverpool FC Poster Print, Football Stadium Poster, Premier League Soccer Art, Sports Poster, Soccer Fan Gift Print](https://i.etsystatic.com/38031717/r/il/d6c92d/6372204832/il_340x270.6372204832_9v8o.jpg)\\
\\
**Anfield Stadium Poster, Liverpool FC Poster Print, Football Stadium Poster, Premier League Soccer Art, Sports Poster, Soccer Fan Gift Print**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
BoumStudio\\
From shop BoumStudio\\
\\
Sale Price $8.99\\
$8.99\\
\\
$11.24\\
Original Price $11.24\\
\\
\\
(20% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1800141118/anfield-stadium-poster-liverpool-fc?click_key=e461bca4ab3e9049db679796b924ae7f7a9f63ba%3A1800141118&click_sum=a11cb363&ref=sold_out-2&pro=1&frs=1&sts=1 "Anfield Stadium Poster, Liverpool FC Poster Print, Football Stadium Poster, Premier League Soccer Art, Sports Poster, Soccer Fan Gift Print")





Add to Favorites


- [![Station 19 Maya Bishop and Carina DeLuca (Version 1) | Photography Print, Danielle Savre, Stefania Spampinato, Station 19 Collectible](https://i.etsystatic.com/61234443/c/1886/1886/557/56/il/439458/7407556919/il_340x270.7407556919_10e0.jpg)\\
\\
**Station 19 Maya Bishop and Carina DeLuca (Version 1) \| Photography Print, Danielle Savre, Stefania Spampinato, Station 19 Collectible**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
amrStudioPrints\\
From shop amrStudioPrints\\
\\
$40.00\\
\\
FREE shipping](https://www.etsy.com/listing/4398973740/station-19-maya-bishop-and-carina-deluca?click_key=eecb18a373a586c731dd684b32d4a15195cd5efd%3A4398973740&click_sum=e7ab2200&ref=sold_out-3&frs=1 "Station 19 Maya Bishop and Carina DeLuca (Version 1) | Photography Print, Danielle Savre, Stefania Spampinato, Station 19 Collectible")





Add to Favorites


- [![How To Train Your Dragon](https://i.etsystatic.com/6919390/r/il/67d6a5/4019906786/il_340x270.4019906786_lrba.jpg)\\
\\
**How To Train Your Dragon**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
LineByLinePosters\\
From shop LineByLinePosters\\
\\
$40.00](https://www.etsy.com/listing/1256582692/how-to-train-your-dragon?click_key=4bbf5cf7a54983842d80c619c32bca844a3c7b3e%3A1256582692&click_sum=86a698ec&ref=sold_out-4&bes=1 "How To Train Your Dragon")





Add to Favorites


- [![Thanksgiving Word Search Game, Word Find, Crossword Poster Puzzle, Gathering Activity, Multiple Sizes](https://i.etsystatic.com/13563738/r/il/0c79b6/7390503953/il_340x270.7390503953_guq1.jpg)\\
\\
**Thanksgiving Word Search Game, Word Find, Crossword Poster Puzzle, Gathering Activity, Multiple Sizes**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
ModernDigitalDesigns\\
From shop ModernDigitalDesigns\\
\\
$19.99\\
\\
FREE shipping](https://www.etsy.com/listing/4395026774/thanksgiving-word-search-game-word-find?click_key=80f24e63a632d4dd9a076c2022a4a8d1215fa0b2%3A4395026774&click_sum=22e1f3ad&ref=sold_out-5&frs=1 "Thanksgiving Word Search Game, Word Find, Crossword Poster Puzzle, Gathering Activity, Multiple Sizes")





Add to Favorites


- [![Fruity Aniteez Small Prints](https://i.etsystatic.com/62121795/r/il/aa94a8/7359542023/il_340x270.7359542023_kc6o.jpg)\\
\\
**Fruity Aniteez Small Prints**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
padeenydrop\\
From shop padeenydrop\\
\\
$4.40\\
\\
Free shipping eligible](https://www.etsy.com/listing/4391163971/fruity-aniteez-small-prints?click_key=a6ea24ed83cc1d5ea0ae94becccbd888daf6234d%3A4391163971&click_sum=50f433e6&ref=sold_out-6&frs=1 "Fruity Aniteez Small Prints")





Add to Favorites


- [![Funny Dog Portrait, Custom Pet Portrait, Ugly Pet Portrait, Silly Pet Portrait, Digital Line Art, Ugly Colored Line Drawing, Funny Cat Art](https://i.etsystatic.com/61539799/r/il/5c51e1/7166610380/il_340x270.7166610380_syee.jpg)\\
\\
**Funny Dog Portrait, Custom Pet Portrait, Ugly Pet Portrait, Silly Pet Portrait, Digital Line Art, Ugly Colored Line Drawing, Funny Cat Art**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
PekoPaw\\
From shop PekoPaw\\
\\
Sale Price $9.89\\
$9.89\\
\\
$16.48\\
Original Price $16.48\\
\\
\\
(40% off)\\
\\
\\
\\
Digital Download](https://www.etsy.com/listing/4362966700/funny-dog-portrait-custom-pet-portrait?click_key=86ebc879f59f586480c18d91121c0a5074f58e8c%3A4362966700&click_sum=10788e4d&ref=sold_out-7&pro=1&dd=1 "Funny Dog Portrait, Custom Pet Portrait, Ugly Pet Portrait, Silly Pet Portrait, Digital Line Art, Ugly Colored Line Drawing, Funny Cat Art")





Add to Favorites


- [![Britain New Zealand Map Print: Marble Country Connection Art](https://i.etsystatic.com/51250421/r/il/8090f3/5911048184/il_340x270.5911048184_18qg.jpg)\\
\\
**Britain New Zealand Map Print: Marble Country Connection Art**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
MarbleousInk\\
From shop MarbleousInk\\
\\
Sale Price $23.95\\
$23.95\\
\\
$47.91\\
Original Price $47.91\\
\\
\\
(50% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1698678634/britain-new-zealand-map-print-marble?click_key=73051e58fb82f4b1e1c4c7e11cfc6119b245e34d%3A1698678634&click_sum=a10084f7&ref=sold_out-8&pro=1&frs=1 "Britain New Zealand Map Print: Marble Country Connection Art")





Add to Favorites


- [![Famous Golf Courses – 3-Print Set (Augusta, Pebble Beach, St Andrews), Vintage Golf Wall Art, Gift for Dad, Man Cave Golf Decor](https://i.etsystatic.com/56693760/r/il/b669f3/6954053955/il_340x270.6954053955_onv6.jpg)\\
\\
**Famous Golf Courses – 3-Print Set (Augusta, Pebble Beach, St Andrews), Vintage Golf Wall Art, Gift for Dad, Man Cave Golf Decor**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
CuriousCanvasCorner\\
From shop CuriousCanvasCorner\\
\\
Sale Price $59.50\\
$59.50\\
\\
$85.00\\
Original Price $85.00\\
\\
\\
(30% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/4313794411/famous-golf-courses-3-print-set-augusta?click_key=6e13adac40eae7c8d5101f2e5ba68d83c738bf7c%3A4313794411&click_sum=005c75d2&ref=sold_out-9&pro=1&frs=1 "Famous Golf Courses – 3-Print Set (Augusta, Pebble Beach, St Andrews), Vintage Golf Wall Art, Gift for Dad, Man Cave Golf Decor")





Add to Favorites


- [![Personalized 10-Year Anniversary Map: Aluminum  Tin “Hello, Will You, I Do”](https://i.etsystatic.com/13871141/c/1158/921/425/470/il/aff1f1/4304716442/il_340x270.4304716442_a8gr.jpg)\\
\\
**Personalized 10-Year Anniversary Map: Aluminum Tin “Hello, Will You, I Do”**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
ModernMapArt\\
From shop ModernMapArt\\
\\
Sale Price $56.24\\
$56.24\\
\\
$74.99\\
Original Price $74.99\\
\\
\\
(25% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1323101168/personalized-10-year-anniversary-map?click_key=f6540b023cfb27983039674706a29d5de840d099%3A1323101168&click_sum=6d04aebc&ref=sold_out-10&pro=1&frs=1&sts=1 "Personalized 10-Year Anniversary Map: Aluminum  Tin “Hello, Will You, I Do”")





Add to Favorites


- [![Print and Frame Anything Framed Print, Print your own Artwork, poster or photos Custom printing Service, custom image in frame art print](https://i.etsystatic.com/16263938/c/1999/1587/0/0/il/a02033/2998606075/il_340x270.2998606075_nd0e.jpg)\\
\\
**Print and Frame Anything Framed Print, Print your own Artwork, poster or photos Custom printing Service, custom image in frame art print**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
LelloLiving\\
From shop LelloLiving\\
\\
$9.54](https://www.etsy.com/listing/969513556/print-and-frame-anything-framed-print?click_key=914fb797629a6f16acfbc30b442fe102a22489d5%3A969513556&click_sum=9381e2e2&ref=sold_out-11&bes=1 "Print and Frame Anything Framed Print, Print your own Artwork, poster or photos Custom printing Service, custom image in frame art print")





Add to Favorites


- [![Woman Yelling at Cat - Ukiyo-e style - Set of 2 giclee prints - OFFICIAL ukiyomemes product!](https://i.etsystatic.com/27904950/r/il/6b54f7/2966134938/il_340x270.2966134938_h573.jpg)\\
\\
**Woman Yelling at Cat - Ukiyo-e style - Set of 2 giclee prints - OFFICIAL ukiyomemes product!**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
Ukiyomemes\\
From shop Ukiyomemes\\
\\
$49.50](https://www.etsy.com/listing/973673162/woman-yelling-at-cat-ukiyo-e-style-set?click_key=cb02b19317ba074711fef3970d8c7e317a1e5d5c%3A973673162&click_sum=a3f4ac21&ref=sold_out-12&bes=1 "Woman Yelling at Cat - Ukiyo-e style - Set of 2 giclee prints - OFFICIAL ukiyomemes product!")





Add to Favorites


- [![Custom Song Lyrics Print, Black-Orange, Personalised Music Poster, Customizable Music Gift, Wedding Anniversary Gift, Music Lover-NP02](https://i.etsystatic.com/39332705/c/1470/1470/444/313/il/c211b0/7414403085/il_340x270.7414403085_cf27.jpg)\\
\\
**Custom Song Lyrics Print, Black-Orange, Personalised Music Poster, Customizable Music Gift, Wedding Anniversary Gift, Music Lover-NP02**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
TheNorthGallery\\
From shop TheNorthGallery\\
\\
Sale Price $16.15\\
$16.15\\
\\
$19.00\\
Original Price $19.00\\
\\
\\
(15% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1832118223/custom-song-lyrics-print-black-orange?click_key=ba29ccba594ef72942fbb9e12fc554a7a1398006%3A1832118223&click_sum=8fe45443&ref=sold_out-13&pro=1&frs=1&sts=1 "Custom Song Lyrics Print, Black-Orange, Personalised Music Poster, Customizable Music Gift, Wedding Anniversary Gift, Music Lover-NP02")





Add to Favorites


- [![Money Saving Offer - Any 5 Prints of your Choice, Choose Your Size, Travel Poster, Travel Print, Art Prints, Art Gifts, National Park Print](https://i.etsystatic.com/19654473/r/il/568b4c/6039638181/il_340x270.6039638181_nswu.jpg)\\
\\
**Money Saving Offer - Any 5 Prints of your Choice, Choose Your Size, Travel Poster, Travel Print, Art Prints, Art Gifts, National Park Print**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
StudioInception\\
From shop StudioInception\\
\\
Sale Price $38.44\\
$38.44\\
\\
$48.04\\
Original Price $48.04\\
\\
\\
(20% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/726221805/money-saving-offer-any-5-prints-of-your?click_key=4d6f5f9977f6f693fbd65ddc5876f62f48d8d813%3A726221805&click_sum=b0cef9a4&ref=sold_out-14&pro=1&frs=1&sts=1 "Money Saving Offer - Any 5 Prints of your Choice, Choose Your Size, Travel Poster, Travel Print, Art Prints, Art Gifts, National Park Print")





Add to Favorites


- [![Memento Mori Personalized Life Calendar Week: Stoic Life in Weeks Custom Calendars for Wall](https://i.etsystatic.com/29679624/r/il/b0b622/5086376385/il_340x270.5086376385_6ysx.jpg)\\
\\
**Memento Mori Personalized Life Calendar Week: Stoic Life in Weeks Custom Calendars for Wall**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
StoicPeople\\
From shop StoicPeople\\
\\
Sale Price $41.66\\
$41.66\\
\\
$55.54\\
Original Price $55.54\\
\\
\\
(25% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1236108881/memento-mori-personalized-life-calendar?click_key=bfa39fa4c4c7cd731497753daa398a32f583a277%3A1236108881&click_sum=516a7fff&ref=sold_out-15&pro=1&frs=1&sts=1 "Memento Mori Personalized Life Calendar Week: Stoic Life in Weeks Custom Calendars for Wall")





Add to Favorites


- [![Rudyard Kipling &quot;If&quot; Poem Art Print: Motivational Wall Decor](https://i.etsystatic.com/10724506/c/1560/1560/186/230/il/e23eaf/6923203494/il_340x270.6923203494_fan5.jpg)\\
\\
**Rudyard Kipling "If" Poem Art Print: Motivational Wall Decor**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
WallBuddy\\
From shop WallBuddy\\
\\
Sale Price $14.57\\
$14.57\\
\\
$19.43\\
Original Price $19.43\\
\\
\\
(25% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/261931239/rudyard-kipling-if-poem-art-print?click_key=f29feb9caef29ca728b7e608716536b0ee49a670%3A261931239&click_sum=bb2d7919&ref=sold_out-16&pro=1&frs=1&sts=1 "Rudyard Kipling \"If\" Poem Art Print: Motivational Wall Decor")





Add to Favorites


- [![Sean Connery Print, 007 James Bond Classic Car Black and White Wall Art, Vintage Print, Photography Prints, Museum Quality Photo Print](https://i.etsystatic.com/45554638/r/il/d60666/5545147652/il_340x270.5545147652_crqh.jpg)\\
\\
**Sean Connery Print, 007 James Bond Classic Car Black and White Wall Art, Vintage Print, Photography Prints, Museum Quality Photo Print**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
ALLBLACKPRINTS\\
From shop ALLBLACKPRINTS\\
\\
Sale Price $8.99\\
$8.99\\
\\
$11.24\\
Original Price $11.24\\
\\
\\
(20% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1620778641/sean-connery-print-007-james-bond?click_key=533b2b5cf073c964b7ec67618c5d14a69c09bdeb%3A1620778641&click_sum=7b8be794&ref=sold_out-17&pro=1&frs=1&sts=1 "Sean Connery Print, 007 James Bond Classic Car Black and White Wall Art, Vintage Print, Photography Prints, Museum Quality Photo Print")





Add to Favorites


- [![Histomap with FRAME Four Thousand Years of World History | States, Nations, Empires c 1931 | Vintage Framed Timeline of World History Print](https://i.etsystatic.com/6670895/r/il/3c46bb/6409371864/il_340x270.6409371864_plf3.jpg)\\
\\
**Histomap with FRAME Four Thousand Years of World History \| States, Nations, Empires c 1931 \| Vintage Framed Timeline of World History Print**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
CarlsonBrands\\
From shop CarlsonBrands\\
\\
Sale Price $31.20\\
$31.20\\
\\
$39.00\\
Original Price $39.00\\
\\
\\
(20% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1798567253/histomap-with-frame-four-thousand-years?click_key=95a41ff3b3b9d6773e05ee5b68afc0fe9ef23b75%3A1798567253&click_sum=8b32e962&ref=sold_out-18&pro=1&frs=1&sts=1 "Histomap with FRAME Four Thousand Years of World History | States, Nations, Empires c 1931 | Vintage Framed Timeline of World History Print")





Add to Favorites


- [![Carrie and Mr Big Print, Bathroom Black and White Wall Art, Vintage Print, Photography Prints, Museum Quality Photo Art Print](https://i.etsystatic.com/45554638/r/il/b2501f/6969022648/il_340x270.6969022648_g1c7.jpg)\\
\\
**Carrie and Mr Big Print, Bathroom Black and White Wall Art, Vintage Print, Photography Prints, Museum Quality Photo Art Print**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
ALLBLACKPRINTS\\
From shop ALLBLACKPRINTS\\
\\
Sale Price $8.99\\
$8.99\\
\\
$11.24\\
Original Price $11.24\\
\\
\\
(20% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/4325977692/carrie-and-mr-big-print-bathroom-black?click_key=LT358cb957e2afa6b372c225793285c1e555019591%3A4325977692&click_sum=f8f8dbbf&ls=a&ref=sold_out_ad-7&pro=1&frs=1&sts=1 "Carrie and Mr Big Print, Bathroom Black and White Wall Art, Vintage Print, Photography Prints, Museum Quality Photo Art Print")





Add to Favorites


- [![Guinea Pig Art Print: Matisse Style Bathroom Decor](https://i.etsystatic.com/19619146/r/il/16e1b4/6654571811/il_340x270.6654571811_4jab.jpg)\\
\\
**Guinea Pig Art Print: Matisse Style Bathroom Decor**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
ElkaPrints\\
From shop ElkaPrints\\
\\
Sale Price $28.80\\
$28.80\\
\\
$48.00\\
Original Price $48.00\\
\\
\\
(40% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1866589303/guinea-pig-art-print-matisse-style?click_key=LTf97b60db6cf866edd61dc84c1e9c72e89ea2af84%3A1866589303&click_sum=1c9ddd53&ls=a&ref=sold_out_ad-8&pro=1&frs=1&sts=1 "Guinea Pig Art Print: Matisse Style Bathroom Decor")





Add to Favorites


- [![Minimalist Abstract Wall Decor Minimalistic Kitchen Print Scandinavian Kitchen Wall Art Scandinavian Neutral Poster Retro Oranges Art Print](https://i.etsystatic.com/58613972/r/il/5a7b67/6931543346/il_340x270.6931543346_ki1e.jpg)\\
\\
**Minimalist Abstract Wall Decor Minimalistic Kitchen Print Scandinavian Kitchen Wall Art Scandinavian Neutral Poster Retro Oranges Art Print**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
roomofscandinavia\\
From shop roomofscandinavia\\
\\
Sale Price $28.79\\
$28.79\\
\\
$47.99\\
Original Price $47.99\\
\\
\\
(40% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/4318915621/minimalist-abstract-wall-decor?click_key=LT20dec85c80563b23c3372711b7f0d0c915fa1d45%3A4318915621&click_sum=ad1efbdb&ls=a&ref=sold_out_ad-9&pro=1&frs=1&sts=1 "Minimalist Abstract Wall Decor Minimalistic Kitchen Print Scandinavian Kitchen Wall Art Scandinavian Neutral Poster Retro Oranges Art Print")





Add to Favorites


- [![Retro Coffee Machine Wall Art | Hand Drawn Coffee Print in Linen Green & Blue, Neutral Kitchen Poster, Minimalist Scandi Cafe Decor MR3](https://i.etsystatic.com/55491259/r/il/b6b267/7300719513/il_340x270.7300719513_24lx.jpg)\\
\\
**Retro Coffee Machine Wall Art \| Hand Drawn Coffee Print in Linen Green & Blue, Neutral Kitchen Poster, Minimalist Scandi Cafe Decor MR3**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
Intadeal\\
From shop Intadeal\\
\\
Sale Price $23.46\\
$23.46\\
\\
$38.46\\
Original Price $38.46\\
\\
\\
(39% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/4380453798/retro-coffee-machine-wall-art-hand-drawn?click_key=LTe52c8ca9d7705560769e89f4d1c698836b671dcf%3A4380453798&click_sum=d3a8c1f9&ls=a&ref=sold_out_ad-10&pro=1&frs=1&sts=1 "Retro Coffee Machine Wall Art | Hand Drawn Coffee Print in Linen Green & Blue, Neutral Kitchen Poster, Minimalist Scandi Cafe Decor MR3")





Add to Favorites


- [![Henri Matisse Blue Art Print: La Perruche et la Sirène Abstract Colorful](https://i.etsystatic.com/42984424/r/il/c39f5d/7394142385/il_340x270.7394142385_nnv6.jpg)\\
\\
**Henri Matisse Blue Art Print: La Perruche et la Sirène Abstract Colorful**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
wallartK\\
From shop wallartK\\
\\
Sale Price $9.42\\
$9.42\\
\\
$14.49\\
Original Price $14.49\\
\\
\\
(35% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/4396777495/henri-matisse-blue-art-print-la-perruche?click_key=LTbc8901dc3c39f513192a359efcdd950732297043%3A4396777495&click_sum=f9b09ca2&ls=a&ref=sold_out_ad-11&pro=1&frs=1&sts=1 "Henri Matisse Blue Art Print: La Perruche et la Sirène Abstract Colorful")





Add to Favorites


- [![Sardine Print , Fish Wall Art , Large Framed Print , Andy Warhol Style , Kitchen Decor , Still Life Painting , Maximalist Decor , Pop Art ,](https://i.etsystatic.com/21860557/r/il/92caea/5377461936/il_340x270.5377461936_jngd.jpg)\\
\\
**Sardine Print , Fish Wall Art , Large Framed Print , Andy Warhol Style , Kitchen Decor , Still Life Painting , Maximalist Decor , Pop Art ,**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
MinusArtAU\\
From shop MinusArtAU\\
\\
Sale Price $35.22\\
$35.22\\
\\
$44.03\\
Original Price $44.03\\
\\
\\
(20% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1569887750/sardine-print-fish-wall-art-large-framed?click_key=LT146e48db1ee0f2fe333bd4425570f6aec9e9f004%3A1569887750&click_sum=59cc1ac7&ls=a&ref=sold_out_ad-12&pro=1&frs=1 "Sardine Print , Fish Wall Art , Large Framed Print , Andy Warhol Style , Kitchen Decor , Still Life Painting , Maximalist Decor , Pop Art ,")





Add to Favorites


- [![Prince Of Peace | 5x7 Double Matted Print](https://i.etsystatic.com/17737481/r/il/06ce2b/4632890247/il_340x270.4632890247_b4jr.jpg)\\
\\
**Prince Of Peace \| 5x7 Double Matted Print**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
Akiane\\
From shop Akiane\\
\\
Sale Price $70.12\\
$70.12\\
\\
$82.50\\
Original Price $82.50\\
\\
\\
(15% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1394096788/prince-of-peace-5x7-double-matted-print?click_key=ec8f5dbb8d59014d0778afc148009c6b9dd1b6fd%3A1394096788&click_sum=04885b70&ref=sold_out-19&pro=1&frs=1 "Prince Of Peace | 5x7 Double Matted Print")





Add to Favorites


- [![Personalized Triathlon Finisher Poster: Custom Race Print](https://i.etsystatic.com/52821503/r/il/d419e6/7164563462/il_340x270.7164563462_rjil.jpg)\\
\\
**Personalized Triathlon Finisher Poster: Custom Race Print**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
TheCotswoldDesigner\\
From shop TheCotswoldDesigner\\
\\
$16.46\\
\\
FREE shipping](https://www.etsy.com/listing/4362622077/personalized-triathlon-finisher-poster?click_key=b4ce55b1b65aafb9c44e17f71312ff9e1e544bd5%3A4362622077&click_sum=08df321e&ref=sold_out-20&frs=1 "Personalized Triathlon Finisher Poster: Custom Race Print")





Add to Favorites


- [![Listen Closely ~PAPER PRINT  from &quot;Suits&quot;  by artist Heather Millar](https://i.etsystatic.com/10213740/r/il/7c083f/6273122913/il_340x270.6273122913_fszn.jpg)\\
\\
**Listen Closely ~PAPER PRINT from "Suits" by artist Heather Millar**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
HeatherMillarArt\\
From shop HeatherMillarArt\\
\\
$137.40](https://www.etsy.com/listing/211358824/listen-closely-paper-print-from-suits-by?click_key=9b7dccb9782c90e0421770d887abe7ae847ac794%3A211358824&click_sum=25151989&ref=sold_out-21 "Listen Closely ~PAPER PRINT  from \"Suits\"  by artist Heather Millar")





Add to Favorites


- [![Limited Edition Palestine Wall Art: Al-Aqsa Mosque with Olive Trees](https://i.etsystatic.com/19500032/r/il/91a2b5/5738978369/il_340x270.5738978369_tfq2.jpg)\\
\\
**Limited Edition Palestine Wall Art: Al-Aqsa Mosque with Olive Trees**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
ArabCanvas\\
From shop ArabCanvas\\
\\
$121.00\\
\\
Eligible orders get 30% off\\
\\
\\
Buy 3 items and get 30% off your order\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1647852212/limited-edition-palestine-wall-art-al?click_key=753c3b1f5c8cc30ad9a9c11ef7df2c17489f5eb3%3A1647852212&click_sum=d5543b4b&ref=sold_out-22&pro=1&frs=1&sts=1 "Limited Edition Palestine Wall Art: Al-Aqsa Mosque with Olive Trees")





Add to Favorites


- [![Camogie Player Word Art Print: Customized With Name & Number, In Any Colors](https://i.etsystatic.com/16965524/c/1785/1785/107/107/il/cf2e5d/6227024540/il_340x270.6227024540_m8my.jpg)\\
\\
**Camogie Player Word Art Print: Customized With Name & Number, In Any Colors**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
SportyType\\
From shop SportyType\\
\\
$25.99\\
\\
FREE shipping](https://www.etsy.com/listing/1361452672/camogie-player-word-art-print-customized?click_key=da97ddb4f608404fefce3d4f6f15fc770e2019dd%3A1361452672&click_sum=fdfc295c&ref=sold_out-23&frs=1 "Camogie Player Word Art Print: Customized With Name & Number, In Any Colors")





Add to Favorites


- [![Arsenal FC Emirates Stadium print. Arsenal Under the Moon, Arsenal FC, London Art Prints - Gifts for football fans, Gunners, gifts for him](https://i.etsystatic.com/12164343/c/2948/2343/0/100/il/e27f77/1969732210/il_340x270.1969732210_qegs.jpg)\\
\\
**Arsenal FC Emirates Stadium print. Arsenal Under the Moon, Arsenal FC, London Art Prints - Gifts for football fans, Gunners, gifts for him**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
EyeForLondonPrints\\
From shop EyeForLondonPrints\\
\\
$17.84\\
\\
Free shipping eligible](https://www.etsy.com/listing/713775484/arsenal-fc-emirates-stadium-print?click_key=bdb250038009357739dbdb3078e11af49a121ea0%3A713775484&click_sum=a99fd39f&ref=sold_out-24&frs=1&sts=1 "Arsenal FC Emirates Stadium print. Arsenal Under the Moon, Arsenal FC, London Art Prints - Gifts for football fans, Gunners, gifts for him")





Add to Favorites



[Shop more similar items](https://www.etsy.com/listing/1414663734/similar?page=2&ref=sold_out_more_like_this)

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1414663734%2F%3Futm_source%3Dopenai&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc2ODg1Njo5M2M2YTdkZGY5ZTM3ZTY1NDRjOWUxZDU4MTQzZDc5Yw==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1414663734%2F%3Futm_source%3Dopenai) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1414663734/?utm_source=openai#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1414663734%2F%3Futm_source%3Dopenai)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done