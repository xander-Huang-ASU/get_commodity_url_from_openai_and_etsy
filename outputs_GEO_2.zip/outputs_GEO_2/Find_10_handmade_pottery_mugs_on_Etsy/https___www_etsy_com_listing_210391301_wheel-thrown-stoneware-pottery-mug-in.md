[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/210391301/wheel-thrown-stoneware-pottery-mug-in#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?explicit=1&ref=catnav_breadcrumb-0)
- [Kitchen & Dining](https://www.etsy.com/c/home-and-living/kitchen-and-dining?explicit=1&ref=catnav_breadcrumb-1)
- [Drink & Barware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware?explicit=1&ref=catnav_breadcrumb-2)
- [Drinkware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware?explicit=1&ref=catnav_breadcrumb-3)
- [Mugs](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/mugs?explicit=1&ref=catnav_breadcrumb-4)


Add to Favorites


- ![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY image 1](https://i.etsystatic.com/5960357/r/il/0d144d/6898978507/il_794xN.6898978507_8eet.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![May include: Stock images show handcrafted ceramic pieces. Each item is hand-thrown, glazed, and kiln-fired, resulting in slight color and form variations.  Minor differences from the pictured examples are expected.  Contact the seller for a photo of the specific piece in stock.](https://i.etsystatic.com/5960357/r/il/2852f8/5304465563/il_794xN.5304465563_hqyc.jpg)
- ![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY image 3](https://i.etsystatic.com/5960357/r/il/7bd245/7198117756/il_794xN.7198117756_i4ia.jpg)
- ![May include: Stack of handmade ceramic mugs.  Each mug features a light gray-blue glaze with subtle variations in color and texture, accented with darker brown and gold-toned drips and streaks. The mugs have a rustic, handcrafted look and feel.  They are cylindrical with a slightly curved handle. The mugs are stacked on a marble surface.](https://i.etsystatic.com/5960357/r/il/1f9cd6/5256275160/il_794xN.5256275160_hous.jpg)
- ![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY image 5](https://i.etsystatic.com/5960357/r/il/11d051/6850965506/il_794xN.6850965506_olr3.jpg)
- ![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY image 6](https://i.etsystatic.com/5960357/r/il/1a435b/6850965544/il_794xN.6850965544_zfaj.jpg)
- ![May include: Stack of six handmade ceramic mugs. Each mug features a light blue glaze with a darker brown-green band at the top. The mugs have a rustic, handcrafted look and feel.  The glaze has a subtle ombre effect. These stoneware mugs are perfect for coffee, tea, or other hot beverages.](https://i.etsystatic.com/5960357/r/il/2c42ca/6020132813/il_794xN.6020132813_dv1a.jpg)
- ![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY image 8](https://i.etsystatic.com/5960357/r/il/27fa07/6898942443/il_794xN.6898942443_m7vh.jpg)
- ![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY image 9](https://i.etsystatic.com/5960357/r/il/7d11e6/6850968210/il_794xN.6850968210_9v7o.jpg)
- ![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY image 10](https://i.etsystatic.com/5960357/r/il/19672e/6850968250/il_794xN.6850968250_wn1f.jpg)

- ![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY image 1](https://i.etsystatic.com/5960357/c/1533/1533/422/516/il/0d144d/6898978507/il_75x75.6898978507_8eet.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/file_jlzcch.jpg)

- ![May include: Stock images show handcrafted ceramic pieces. Each item is hand-thrown, glazed, and kiln-fired, resulting in slight color and form variations.  Minor differences from the pictured examples are expected.  Contact the seller for a photo of the specific piece in stock.](https://i.etsystatic.com/5960357/r/il/2852f8/5304465563/il_75x75.5304465563_hqyc.jpg)
- ![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY image 3](https://i.etsystatic.com/5960357/r/il/7bd245/7198117756/il_75x75.7198117756_i4ia.jpg)
- ![May include: Stack of handmade ceramic mugs.  Each mug features a light gray-blue glaze with subtle variations in color and texture, accented with darker brown and gold-toned drips and streaks. The mugs have a rustic, handcrafted look and feel.  They are cylindrical with a slightly curved handle. The mugs are stacked on a marble surface.](https://i.etsystatic.com/5960357/r/il/1f9cd6/5256275160/il_75x75.5256275160_hous.jpg)
- ![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY image 5](https://i.etsystatic.com/5960357/r/il/11d051/6850965506/il_75x75.6850965506_olr3.jpg)
- ![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY image 6](https://i.etsystatic.com/5960357/r/il/1a435b/6850965544/il_75x75.6850965544_zfaj.jpg)
- ![May include: Stack of six handmade ceramic mugs. Each mug features a light blue glaze with a darker brown-green band at the top. The mugs have a rustic, handcrafted look and feel.  The glaze has a subtle ombre effect. These stoneware mugs are perfect for coffee, tea, or other hot beverages.](https://i.etsystatic.com/5960357/r/il/2c42ca/6020132813/il_75x75.6020132813_dv1a.jpg)
- ![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY image 8](https://i.etsystatic.com/5960357/r/il/27fa07/6898942443/il_75x75.6898942443_m7vh.jpg)
- ![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY image 9](https://i.etsystatic.com/5960357/r/il/7d11e6/6850968210/il_75x75.6850968210_9v7o.jpg)
- ![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY image 10](https://i.etsystatic.com/5960357/r/il/19672e/6850968250/il_75x75.6850968250_wn1f.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F210391301%2Fwheel-thrown-stoneware-pottery-mug-in%23report-overlay-trigger)

14 views in the last 24 hours

Price:$38.00+


Loading


# Wheel thrown stoneware pottery mug in Patina glaze / coffee mug \| tea mug \| 14-16oz straight shape / SOLD INDIVIDUALLY

Made by [littleepottery](https://www.etsy.com/shop/littleepottery)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/210391301/wheel-thrown-stoneware-pottery-mug-in#reviews)

Arrives soon! Get it by

Nov 14-20


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

shipping destination


Select an option

continental US ($38.00)

AK, HI or PR ($42.00)

Please select an option


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Made by [littleepottery](https://www.etsy.com/shop/littleepottery)

- Materials: Ceramic


- Capacity: 14 fluid ounces

This mug was hand thrown on the wheel. It is thin walled and light, but has a thicker rounded lip rim for maximum durability through daily use. This simple straight walled form is classic and timeless. I glazed these in my own dynamic layered mix of sage green and coppery brown tendrils that I call Patina. Capacity to the rim is 16oz . Size is about 4.5" tall x 3.5" wide

Price is per mug- you can order a single mug or buy the whole set :)

All of my pieces are dishwasher, microwave, and oven safe. If you want maximum longevity of glaze shine hand washing is recommended, as dishwasher detergents will etch the surface slowly over time and dull the finish. The glazes are my own recipe and are lead free and food safe. My pieces are fired to 2232 F, and are completely non porous, even in places where there is no glaze. The bottoms of all pieces are bare natural clay, and have a bit of grit to them. It is always okay to sand the bottoms with sandpaper if you prefer a smoother surface.

If you would like to view other mugs in my Etsy shop visit my mugs and cups section:

[https://www.etsy.com/shop/littleepottery?section\_id=7324005](https://www.etsy.com/shop/littleepottery?section_id=7324005)

www.littleepottery.com


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-20**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges not accepted




But please contact me if you have problems with your order


- Free shipping


- Ships from: **Smithville, TX**


Deliver to United States

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## FAQs

I'm in Austin, can I just pick it up?


I'm sorry, but local pick up is not available. I work in my home and for insurance, legal, and personal privacy reasons, I have a strict policy of no customers on site.


Wholesale availability


At this time I am not accepting wholesale accounts.


Can you match the glaze of pieces I have from another potter?


I'm sorry, but I don't offer custom glazes. My glazes are all hand mixed and are my own unique recipes and combinations that require months of testing to perfect. I do not use commercial glazes so new colors are not possible. If you would like to look for a color of mine that may coordinate with the pieces you already have please browse my glaze gallery here:

www.littleepottery.com/glaze-gallery


## Meet your seller

![Emily](https://i.etsystatic.com/5960357/r/isla/c1dd8f/15861490/isla_75x75.15861490_4qarycag.jpg)

Emily

Owner of [littleepottery](https://www.etsy.com/shop/littleepottery?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoxMDU1MzgzMDoxNzYyNzY1NzQ1OmJkMmFiMjNjYzhkNjUwNDhhMDRkMzA0MmQ5ZGUwMzI5&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F210391301%2Fwheel-thrown-stoneware-pottery-mug-in)

[Message Emily](https://www.etsy.com/messages/new?with_id=10553830&referring_id=210391301&referring_type=listing&recipient_id=10553830&from_action=contact-seller)

This seller usually responds **within 24 hours.**

## Reviews for this item (20)

5.0/5

item average

4.9Item quality

5.0Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Love it

Fast shipping

Would recommend

Beautiful

Great quality

Gift-worthy

Comfortable


Filter by category


Quality (4)


Comfort (3)


Shipping & Packaging (2)


Seller service (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Darlene Lombardo](https://www.etsy.com/people/dlombada?ref=l_review)
Sep 29, 2025


Love these mugs! They are the perfect size, very comfortable to hold in your hand by the handle. Fast shipping! Highly recommend her products! #1



![Darlene Lombardo added a photo of their purchase](https://i.etsystatic.com/iap/a0cbe3/7290235331/iap_300x300.7290235331_op8htge5.jpg?version=0)

[Darlene Lombardo](https://www.etsy.com/people/dlombada?ref=l_review)
Sep 29, 2025


5 out of 5 stars
5

This item

[Peter](https://www.etsy.com/people/lunjamjh?ref=l_review)
Aug 5, 2025


These last two mugs complete a set of 8 that I’ve purchased and am so pleased with. I’ll be purchasing 8 more mugs of a different design and these will complete my kitchen renovation of a change in all my tea and coffee mugs.



[Peter](https://www.etsy.com/people/lunjamjh?ref=l_review)
Aug 5, 2025


5 out of 5 stars
5

This item

[Peter](https://www.etsy.com/people/lunjamjh?ref=l_review)
Jul 15, 2025


This purchase was an addition to my original mugs. Emily who owns and makes all her mugs has been wonderful to deal with. Having studied and made pottery myself years ago, I can attest to the beauty and quality of her work. She was so specific in her work, she had me send her a photo of my existing mugs, so she could send me the additional two to be identical to the collection. That is rare and really appreciated. And the mugs in both circumstances were delivered with the same packing and delivery speed as the quality of the mugs. I will continue to buy from her. I’m a frequent Etsy customer, so when I find a good store, I stay with it. - Peter S.



[Peter](https://www.etsy.com/people/lunjamjh?ref=l_review)
Jul 15, 2025


5 out of 5 stars
5

This item

[Peter](https://www.etsy.com/people/lunjamjh?ref=l_review)
Jul 1, 2025


This was a replacement for one that had broken and it was as beautiful as the original order. I definitely will be back



[Peter](https://www.etsy.com/people/lunjamjh?ref=l_review)
Jul 1, 2025


View all reviews for this item

### Photos from reviews

![Darlene added a photo of their purchase](https://i.etsystatic.com/iap/a0cbe3/7290235331/iap_300x300.7290235331_op8htge5.jpg?version=0)

[![littleepottery](https://i.etsystatic.com/iusa/a09a4f/53414819/iusa_75x75.53414819_cooa.jpg?version=0)](https://www.etsy.com/shop/littleepottery?ref=shop_profile&listing_id=210391301)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[littleepottery](https://www.etsy.com/shop/littleepottery?ref=shop_profile&listing_id=210391301)

[Owned by Emily](https://www.etsy.com/shop/littleepottery?ref=shop_profile&listing_id=210391301) \|

Rosanky, Texas

5.0
(5.5k)


19.6k sales

15 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=10553830&referring_id=210391301&referring_type=listing&recipient_id=10553830&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoxMDU1MzgzMDoxNzYyNzY1NzQ1OmJkMmFiMjNjYzhkNjUwNDhhMDRkMzA0MmQ5ZGUwMzI5&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F210391301%2Fwheel-thrown-stoneware-pottery-mug-in)

This seller usually responds **within 24 hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

Loading recommendations

Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 8, 2025


[243 favorites](https://www.etsy.com/listing/210391301/wheel-thrown-stoneware-pottery-mug-in/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?explicit=1&ref=breadcrumb_listing) [Kitchen & Dining](https://www.etsy.com/c/home-and-living/kitchen-and-dining?explicit=1&ref=breadcrumb_listing) [Drink & Barware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware?explicit=1&ref=breadcrumb_listing) [Drinkware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware?explicit=1&ref=breadcrumb_listing) [Mugs](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/mugs?explicit=1&ref=breadcrumb_listing)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F210391301%2Fwheel-thrown-stoneware-pottery-mug-in&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc2NTc0NTpmYWNlZjU4NThlNGU4OTM3OGMyYmQzMzBkNzllYjBjYw==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F210391301%2Fwheel-thrown-stoneware-pottery-mug-in) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/210391301/wheel-thrown-stoneware-pottery-mug-in#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F210391301%2Fwheel-thrown-stoneware-pottery-mug-in)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for littleepottery

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: not accepted

Please contact the seller if you have any problems with your order.

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY image 1](https://i.etsystatic.com/5960357/c/1533/1533/422/516/il/0d144d/6898978507/il_300x300.6898978507_8eet.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/file_jlzcch.jpg)

- ![May include: Stock images show handcrafted ceramic pieces. Each item is hand-thrown, glazed, and kiln-fired, resulting in slight color and form variations.  Minor differences from the pictured examples are expected.  Contact the seller for a photo of the specific piece in stock.](https://i.etsystatic.com/5960357/r/il/2852f8/5304465563/il_300x300.5304465563_hqyc.jpg)
- ![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY image 3](https://i.etsystatic.com/5960357/r/il/7bd245/7198117756/il_300x300.7198117756_i4ia.jpg)
- ![May include: Stack of handmade ceramic mugs.  Each mug features a light gray-blue glaze with subtle variations in color and texture, accented with darker brown and gold-toned drips and streaks. The mugs have a rustic, handcrafted look and feel.  They are cylindrical with a slightly curved handle. The mugs are stacked on a marble surface.](https://i.etsystatic.com/5960357/r/il/1f9cd6/5256275160/il_300x300.5256275160_hous.jpg)
- ![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY image 5](https://i.etsystatic.com/5960357/r/il/11d051/6850965506/il_300x300.6850965506_olr3.jpg)
- ![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY image 6](https://i.etsystatic.com/5960357/r/il/1a435b/6850965544/il_300x300.6850965544_zfaj.jpg)
- ![May include: Stack of six handmade ceramic mugs. Each mug features a light blue glaze with a darker brown-green band at the top. The mugs have a rustic, handcrafted look and feel.  The glaze has a subtle ombre effect. These stoneware mugs are perfect for coffee, tea, or other hot beverages.](https://i.etsystatic.com/5960357/r/il/2c42ca/6020132813/il_300x300.6020132813_dv1a.jpg)
- ![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY image 8](https://i.etsystatic.com/5960357/r/il/27fa07/6898942443/il_300x300.6898942443_m7vh.jpg)
- ![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY image 9](https://i.etsystatic.com/5960357/r/il/7d11e6/6850968210/il_300x300.6850968210_9v7o.jpg)
- ![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY image 10](https://i.etsystatic.com/5960357/r/il/19672e/6850968250/il_300x300.6850968250_wn1f.jpg)

- ![](https://i.etsystatic.com/iap/a0cbe3/7290235331/iap_640x640.7290235331_op8htge5.jpg?version=0)











5 out of 5 stars





- shipping destination:

continental US


Love these mugs! They are the perfect size, very comfortable to hold in your hand by the handle. Fast shipping! Highly recommend her products! #1

Sep 29, 2025


[Darlene Lombardo](https://www.etsy.com/people/dlombada)

Purchased item:

[![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY](https://i.etsystatic.com/5960357/c/1533/1533/422/516/il/0d144d/6898978507/il_170x135.6898978507_8eet.jpg)\\
\\
Wheel thrown stoneware pottery mug in Patina glaze / coffee mug \| tea mug \| 14-16oz straight shape / SOLD INDIVIDUALLY\\
\\
$38.00](https://www.etsy.com/listing/210391301/wheel-thrown-stoneware-pottery-mug-in?ref=ap-listing)

Purchased item:

[![Wheel thrown stoneware pottery mug in Patina glaze / coffee mug | tea mug | 14-16oz straight shape / SOLD INDIVIDUALLY](https://i.etsystatic.com/5960357/c/1533/1533/422/516/il/0d144d/6898978507/il_170x135.6898978507_8eet.jpg)\\
\\
Wheel thrown stoneware pottery mug in Patina glaze / coffee mug \| tea mug \| 14-16oz straight shape / SOLD INDIVIDUALLY\\
\\
$38.00](https://www.etsy.com/listing/210391301/wheel-thrown-stoneware-pottery-mug-in?ref=ap-listing)