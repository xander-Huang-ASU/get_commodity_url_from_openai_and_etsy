[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/4331730180/rustic-handmade-mug-wheel-thrown-pottery#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?explicit=1&ref=catnav_breadcrumb-0)
- [Kitchen & Dining](https://www.etsy.com/c/home-and-living/kitchen-and-dining?explicit=1&ref=catnav_breadcrumb-1)
- [Drink & Barware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware?explicit=1&ref=catnav_breadcrumb-2)
- [Drinkware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware?explicit=1&ref=catnav_breadcrumb-3)
- [Mugs](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/mugs?explicit=1&ref=catnav_breadcrumb-4)


Add to Favorites


- ![May include: A ceramic mug with a rich, reddish-brown glaze. The mug features horizontal, textured ridges around the body and a rounded handle with a small, decorative detail. The mug sits on a wooden surface, showcasing its warm color and handcrafted appearance, ideal for coffee or tea.](https://i.etsystatic.com/5172094/r/il/d5f552/7049349235/il_794xN.7049349235_g3io.jpg)
- ![May include: A red ceramic mug with a rounded body and a handle. The mug has horizontal ridges around its exterior. The handle is a curved shape with a small, rounded extension at the top. The mug sits on a wooden surface, and the background is a dark gray color.](https://i.etsystatic.com/5172094/r/il/6bc9f5/7001373196/il_794xN.7001373196_dzog.jpg)
- ![May include: A ceramic mug with a reddish-brown glaze. The mug has a cylindrical shape with horizontal ridges around the body. It features a curved handle with a small, decorative detail at the top. The mug sits on a wooden surface, and the background is a dark gray.](https://i.etsystatic.com/5172094/r/il/1b1756/7049348291/il_794xN.7049348291_osqg.jpg)
- ![May include: A red ceramic mug with a handle and a small knob on the handle. The mug has a cylindrical shape with horizontal ridges around the exterior. The interior of the mug is a darker shade of red, and it sits on a light brown wooden surface.](https://i.etsystatic.com/5172094/r/il/4bf268/7049348289/il_794xN.7049348289_1hi5.jpg)
- ![May include: A red ceramic mug with a dark handle and a dark gray base. The mug is sitting upside down on a wooden surface, revealing the bottom of the mug. The mug has a ridged texture and a glossy finish. The base of the mug has a circular design with text.](https://i.etsystatic.com/5172094/r/il/f6134b/7049348275/il_794xN.7049348275_3jgy.jpg)
- ![May include: A square gift box wrapped in tan paper with a gold geometric pattern. A large, decorative gold bow sits on top, with curled ribbon. The text 'Gift Wrapping Available' is visible in the bottom left corner.](https://i.etsystatic.com/5172094/r/il/cc0b2e/3574793210/il_794xN.3574793210_c1c5.jpg)

- ![May include: A ceramic mug with a rich, reddish-brown glaze. The mug features horizontal, textured ridges around the body and a rounded handle with a small, decorative detail. The mug sits on a wooden surface, showcasing its warm color and handcrafted appearance, ideal for coffee or tea.](https://i.etsystatic.com/5172094/r/il/d5f552/7049349235/il_75x75.7049349235_g3io.jpg)
- ![May include: A red ceramic mug with a rounded body and a handle. The mug has horizontal ridges around its exterior. The handle is a curved shape with a small, rounded extension at the top. The mug sits on a wooden surface, and the background is a dark gray color.](https://i.etsystatic.com/5172094/r/il/6bc9f5/7001373196/il_75x75.7001373196_dzog.jpg)
- ![May include: A ceramic mug with a reddish-brown glaze. The mug has a cylindrical shape with horizontal ridges around the body. It features a curved handle with a small, decorative detail at the top. The mug sits on a wooden surface, and the background is a dark gray.](https://i.etsystatic.com/5172094/r/il/1b1756/7049348291/il_75x75.7049348291_osqg.jpg)
- ![May include: A red ceramic mug with a handle and a small knob on the handle. The mug has a cylindrical shape with horizontal ridges around the exterior. The interior of the mug is a darker shade of red, and it sits on a light brown wooden surface.](https://i.etsystatic.com/5172094/r/il/4bf268/7049348289/il_75x75.7049348289_1hi5.jpg)
- ![May include: A red ceramic mug with a dark handle and a dark gray base. The mug is sitting upside down on a wooden surface, revealing the bottom of the mug. The mug has a ridged texture and a glossy finish. The base of the mug has a circular design with text.](https://i.etsystatic.com/5172094/r/il/f6134b/7049348275/il_75x75.7049348275_3jgy.jpg)
- ![May include: A square gift box wrapped in tan paper with a gold geometric pattern. A large, decorative gold bow sits on top, with curled ribbon. The text 'Gift Wrapping Available' is visible in the bottom left corner.](https://i.etsystatic.com/5172094/r/il/cc0b2e/3574793210/il_75x75.3574793210_c1c5.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F4331730180%2Frustic-handmade-mug-wheel-thrown-pottery%23report-overlay-trigger)

Only 1 left and in 1 cart

Price:$40.00


Loading


# Rustic Handmade Mug, Wheel-thrown pottery, Red / Dishwasher Safe / 16 oz.

Made by [CreektreeClay](https://www.etsy.com/shop/CreektreeClay)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/4331730180/rustic-handmade-mug-wheel-thrown-pottery#reviews)

Arrives soon! Get it by

Nov 13-17


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

4 payments of **$10.00** at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Made by [CreektreeClay](https://www.etsy.com/shop/CreektreeClay)

- Materials: Ceramic


- Capacity: 16 fluid ounces

- Gift wrapping available

See details

Gift wrapping by CreektreeClay

Includes a neutral wrapping (suitable for any occasion or recipient) with coordinating bow.

Wheel-thrown ceramic mug, glazed with a speckled rusty red, over dark brown stoneware clay. Holds approx. 16 oz.

No need to hand wash - Mugs are dishwasher and microwave SAFE!


## Shipping and return policies

Loading


- Order today to get by

**Nov 13-17**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 14 days


- Ships from: **Fishers, IN**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## Be the first to review this item

This is a unique item, and there are no reviews yet. See what customers say about other items from this shop.


Read reviews for other items


[![CreektreeClay](https://i.etsystatic.com/iusa/10f485/96332229/iusa_75x75.96332229_fczj.jpg?version=0)](https://www.etsy.com/shop/CreektreeClay?ref=shop_profile&listing_id=4331730180)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[CreektreeClay](https://www.etsy.com/shop/CreektreeClay?ref=shop_profile&listing_id=4331730180)

[Owned by Amanda Waymire](https://www.etsy.com/shop/CreektreeClay?ref=shop_profile&listing_id=4331730180) \|

United States

5.0
(1.2k)


2.9k sales

18 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=5169860&referring_id=4331730180&referring_type=listing&recipient_id=5169860&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo1MTY5ODYwOjE3NjI3NjU4NTQ6NDI1YmZkNDgyOThkZmEzYzg0ZGY4ZjZjNmM3ZDliYzk%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F4331730180%2Frustic-handmade-mug-wheel-thrown-pottery)

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## All reviews from this shop (1.2k)

Show all

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Why are these reviews shown?

All reviews are from verified buyers. Reviews are shown automatically based on factors like recency, whether they include comments, your chosen language, and whether the rating reflects the typical experience with the shop.

## More from this shop

[Visit shop](https://www.etsy.com/shop/CreektreeClay?ref=lp_mys_mfts)

- [![Rustic Handmade Mug, Wheel-thrown pottery, Red / Dishwasher Safe / 16 oz.](https://i.etsystatic.com/5172094/r/il/251236/7049354151/il_340x270.7049354151_6bel.jpg)\\
\\
**Rustic Handmade Mug, Wheel-thrown pottery, Red / Dishwasher Safe / 16 oz.**\\
\\
$40.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4331730552/rustic-handmade-mug-wheel-thrown-pottery?click_key=27ae956ebfe3e7504676af2fffc8ec84%3ALT38da25aba40d419b9960ccec342eb90d652a1efb&click_sum=9fb2cb44&ls=r&ref=related-1&sts=1&content_source=27ae956ebfe3e7504676af2fffc8ec84%253ALT38da25aba40d419b9960ccec342eb90d652a1efb "Rustic Handmade Mug, Wheel-thrown pottery, Red / Dishwasher Safe / 16 oz.")




Add to Favorites


- [![Rustic Handmade Mug / Wheel-thrown Pottery / Lavender / Dishwasher Safe / 16 oz.](https://i.etsystatic.com/5172094/r/il/5b75b1/7049301373/il_340x270.7049301373_hq4f.jpg)\\
\\
**Rustic Handmade Mug / Wheel-thrown Pottery / Lavender / Dishwasher Safe / 16 oz.**\\
\\
$40.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1824304533/rustic-handmade-mug-wheel-thrown-pottery?click_key=27ae956ebfe3e7504676af2fffc8ec84%3ALT27600ae3b6a09f9505ec3306ba8d736af5105502&click_sum=fa82e4b7&ls=r&ref=related-2&sts=1&content_source=27ae956ebfe3e7504676af2fffc8ec84%253ALT27600ae3b6a09f9505ec3306ba8d736af5105502 "Rustic Handmade Mug / Wheel-thrown Pottery / Lavender / Dishwasher Safe / 16 oz.")




Add to Favorites


- [![Rustic Handmade Mug, Wheel-thrown pottery, Green / Dishwasher Safe / 16 oz. / Brown Earthy Natural Man Husband Boyfriend Gift](https://i.etsystatic.com/5172094/r/il/9a30b2/7262240132/il_340x270.7262240132_siv4.jpg)\\
\\
**Rustic Handmade Mug, Wheel-thrown pottery, Green / Dishwasher Safe / 16 oz. / Brown Earthy Natural Man Husband Boyfriend Gift**\\
\\
$40.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4382326783/rustic-handmade-mug-wheel-thrown-pottery?click_key=27ae956ebfe3e7504676af2fffc8ec84%3ALT9c90b5d88d8c70718495b4fa392014e314bfc872&click_sum=cfa946b7&ls=r&ref=related-3&sts=1&content_source=27ae956ebfe3e7504676af2fffc8ec84%253ALT9c90b5d88d8c70718495b4fa392014e314bfc872 "Rustic Handmade Mug, Wheel-thrown pottery, Green / Dishwasher Safe / 16 oz. / Brown Earthy Natural Man Husband Boyfriend Gift")




Add to Favorites


- [![Handmade Carved Sunburst Mug - Red, Dishwasher Safe, 14 oz.](https://i.etsystatic.com/5172094/r/il/92698d/6736612433/il_340x270.6736612433_adi3.jpg)\\
\\
**Handmade Carved Sunburst Mug - Red, Dishwasher Safe, 14 oz.**\\
\\
$50.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1882889517/handmade-carved-sunburst-mug-red?click_key=da68cefeae194e126443500836ebf00eaa50a042%3A1882889517&click_sum=9574e176&ref=related-4&sts=1 "Handmade Carved Sunburst Mug - Red, Dishwasher Safe, 14 oz.")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 8, 2025


[5 favorites](https://www.etsy.com/listing/4331730180/rustic-handmade-mug-wheel-thrown-pottery/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?explicit=1&ref=breadcrumb_listing) [Kitchen & Dining](https://www.etsy.com/c/home-and-living/kitchen-and-dining?explicit=1&ref=breadcrumb_listing) [Drink & Barware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware?explicit=1&ref=breadcrumb_listing) [Drinkware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware?explicit=1&ref=breadcrumb_listing) [Mugs](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/mugs?explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Kitchen & Dining

[Buy White Ribbed China Online](https://www.etsy.com/market/white_ribbed_china) [Buy Italian Flower Dish Online](https://www.etsy.com/market/italian_flower_dish) [Shop Moon Pint Glass](https://www.etsy.com/market/moon_pint_glass) [Lincoln BeautyWare Vintage Coffee Tin](https://www.etsy.com/listing/1891310312/lincoln-beautyware-vintage-coffee-tin) [Buy Desuir Online](https://www.etsy.com/market/desuir) [Host/Hostess Gift Idea - Kitchen & Dining](https://www.etsy.com/listing/1790612173/autumn-leaves-table-runner-hosthostess) [Raccoon Shot Glass - US](https://www.etsy.com/market/raccoon_shot_glass) [Falmouth Spoon for Sale](https://www.etsy.com/market/falmouth_spoon) [Vtg Tupperware 9 3/4 Cup Plastic Modular Mates Oval Container by SiouxValleyWarrior](https://www.etsy.com/listing/4346946752/vtg-tupperware-9-34-cup-plastic-modular) [Custard Cup Rack for Sale](https://www.etsy.com/market/custard_cup_rack)

Frames Hoops & Stands

[Cross Stitch Wood Frames - US](https://www.etsy.com/market/cross_stitch_wood_frames)

Gender Neutral Adult Shoes

[Blue Converse style Cherry Blossom Low tops - Gender-Neutral Adult Shoes](https://www.etsy.com/listing/1666679926/blue-converse-style-cherry-blossom-low)

Girls Clothing

[Character Tutu Dress for Sale](https://www.etsy.com/market/character_tutu_dress)

Paper

[Thank You Note Welcome Bag - Paper, Stationery & Cards](https://www.etsy.com/listing/1754630744/baby-breath-greenery-wedding-itinerary)

Toys

[1977 Matchbox Superfast No. 53 CJ6 Jeep by HighDesertPasTime](https://www.etsy.com/listing/1618925286/1977-matchbox-superfast-no-53-cj6-jeep) [Frog Doll Shoes for Sale](https://www.etsy.com/market/frog_doll_shoes)

Luggage & Travel

[1940s Travel Case for Sale](https://www.etsy.com/market/1940s_travel_case)

Mens Shoes

[Shop Wwii Flight Boots](https://www.etsy.com/market/wwii_flight_boots)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F4331730180%2Frustic-handmade-mug-wheel-thrown-pottery&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc2NTg1NDo5MWI3NjEyNGFjYzA2Zjc1NmJjMDg5Njk0NTM3MmEwYQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F4331730180%2Frustic-handmade-mug-wheel-thrown-pottery) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/4331730180/rustic-handmade-mug-wheel-thrown-pottery#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F4331730180%2Frustic-handmade-mug-wheel-thrown-pottery)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for CreektreeClay

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: before item has shipped

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: A ceramic mug with a rich, reddish-brown glaze. The mug features horizontal, textured ridges around the body and a rounded handle with a small, decorative detail. The mug sits on a wooden surface, showcasing its warm color and handcrafted appearance, ideal for coffee or tea.](https://i.etsystatic.com/5172094/r/il/d5f552/7049349235/il_300x300.7049349235_g3io.jpg)
- ![May include: A red ceramic mug with a rounded body and a handle. The mug has horizontal ridges around its exterior. The handle is a curved shape with a small, rounded extension at the top. The mug sits on a wooden surface, and the background is a dark gray color.](https://i.etsystatic.com/5172094/r/il/6bc9f5/7001373196/il_300x300.7001373196_dzog.jpg)
- ![May include: A ceramic mug with a reddish-brown glaze. The mug has a cylindrical shape with horizontal ridges around the body. It features a curved handle with a small, decorative detail at the top. The mug sits on a wooden surface, and the background is a dark gray.](https://i.etsystatic.com/5172094/r/il/1b1756/7049348291/il_300x300.7049348291_osqg.jpg)
- ![May include: A red ceramic mug with a handle and a small knob on the handle. The mug has a cylindrical shape with horizontal ridges around the exterior. The interior of the mug is a darker shade of red, and it sits on a light brown wooden surface.](https://i.etsystatic.com/5172094/r/il/4bf268/7049348289/il_300x300.7049348289_1hi5.jpg)
- ![May include: A red ceramic mug with a dark handle and a dark gray base. The mug is sitting upside down on a wooden surface, revealing the bottom of the mug. The mug has a ridged texture and a glossy finish. The base of the mug has a circular design with text.](https://i.etsystatic.com/5172094/r/il/f6134b/7049348275/il_300x300.7049348275_3jgy.jpg)
- ![May include: A square gift box wrapped in tan paper with a gold geometric pattern. A large, decorative gold bow sits on top, with curled ribbon. The text 'Gift Wrapping Available' is visible in the bottom left corner.](https://i.etsystatic.com/5172094/r/il/cc0b2e/3574793210/il_300x300.3574793210_c1c5.jpg)

Scroll previousScroll next