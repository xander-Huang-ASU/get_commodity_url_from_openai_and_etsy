[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/878329809/nevertheless-she-persisted-elizabeth#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?explicit=1&ref=catnav_breadcrumb-0)
- [Prints](https://www.etsy.com/c/art-and-collectibles/prints?explicit=1&ref=catnav_breadcrumb-1)
- [Digital Prints](https://www.etsy.com/c/art-and-collectibles/prints/digital-prints?explicit=1&ref=catnav_breadcrumb-2)


Add to Favorites


- ![May include: A black and white printable poster with the text 'Nevertheless, SHE persisted.'](https://i.etsystatic.com/24134568/r/il/1119cf/2762006238/il_794xN.2762006238_hha8.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![May include: A white brick wall with a blue banner at the top and bottom. The banner has the text 'Hi there, I'm Karen...' at the top and the text 'I have five star reviews!' at the bottom. The banner also has a black and white logo that says 'Cursive & BLOCK' in the top right corner and the bottom right corner. The text in the middle of the image reads 'I offer a variety of high-quality, easy to download digital art prints that will enhance your decor. My designs are created with careful attention to detail and will add a meaningful touch to your living spaces.'](https://i.etsystatic.com/24134568/r/il/bf2112/3437556157/il_794xN.3437556157_26nz.jpg)
- ![May include: A digital art print file download description. The text reads: 'This is a digital art print file that you download. NO PHYSICAL PRODUCT WILL BE SENT. High-resolution, 300 dpi, JPG files for crisp prints. You will receive (4) file sizes: 8x10, 11x14, 16x20 and 24x36. Also included is a downloadable 'Helpful Hints Guide' on how to print your art at home, or using a printing service. PURCHASE, DOWNLOAD, PRINT = Instant art! (See item description below for more details.)'](https://i.etsystatic.com/24134568/r/il/794e61/3437556563/il_794xN.3437556563_ktw1.jpg)
- ![May include: A framed black and white print with the text 'Nevertheless, SHE persisted.'  A laptop computer is open on a white surface with a black and white logo that says 'Cursive & Block'.](https://i.etsystatic.com/24134568/r/il/3f5d18/2556669224/il_794xN.2556669224_jiyh.jpg)
- ![May include: A black framed poster with white text that reads 'Nevertheless, SHE persisted.'](https://i.etsystatic.com/24134568/r/il/591f48/2556668096/il_794xN.2556668096_ij1u.jpg)
- ![May include: A white and blue graphic with the text 'HOW DO I DOWNLOAD MY FILES?' in black. The text 'Three Different Ways' is in black and is below the main title. The graphic lists three ways to download files. The first way is to click 'View your digital files now' on the 'Thanks for your order' page. The second way is to download files from the receipt email. The third way is to go to 'Your account' in the top right corner of the screen, click 'Purchases and reviews', and then click 'Download files'.](https://i.etsystatic.com/24134568/r/il/9f9d3f/3222030883/il_794xN.3222030883_k132.jpg)
- ![May include: A blue and white graphic with the text 'Get the Latest News...' and a black and white logo that says 'Cursive & BLOCK'. The graphic also includes the text 'For shop updates, notifications on upcoming sales and a 20% Off Discount Code to use on your purchase JOIN THE CURSIVEANDBLOCK SHOP NEWS LIST Just type the link below into your browser: http://www.bit.ly/33rRjq2'](https://i.etsystatic.com/24134568/r/il/c15db9/3389883686/il_794xN.3389883686_962m.jpg)

- ![May include: A black and white printable poster with the text 'Nevertheless, SHE persisted.'](https://i.etsystatic.com/24134568/r/il/1119cf/2762006238/il_75x75.2762006238_hha8.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/Generic_Benefits_of_Printable_Art_Video_adukw7.jpg)

- ![May include: A white brick wall with a blue banner at the top and bottom. The banner has the text 'Hi there, I'm Karen...' at the top and the text 'I have five star reviews!' at the bottom. The banner also has a black and white logo that says 'Cursive & BLOCK' in the top right corner and the bottom right corner. The text in the middle of the image reads 'I offer a variety of high-quality, easy to download digital art prints that will enhance your decor. My designs are created with careful attention to detail and will add a meaningful touch to your living spaces.'](https://i.etsystatic.com/24134568/r/il/bf2112/3437556157/il_75x75.3437556157_26nz.jpg)
- ![May include: A digital art print file download description. The text reads: 'This is a digital art print file that you download. NO PHYSICAL PRODUCT WILL BE SENT. High-resolution, 300 dpi, JPG files for crisp prints. You will receive (4) file sizes: 8x10, 11x14, 16x20 and 24x36. Also included is a downloadable 'Helpful Hints Guide' on how to print your art at home, or using a printing service. PURCHASE, DOWNLOAD, PRINT = Instant art! (See item description below for more details.)'](https://i.etsystatic.com/24134568/r/il/794e61/3437556563/il_75x75.3437556563_ktw1.jpg)
- ![May include: A framed black and white print with the text 'Nevertheless, SHE persisted.'  A laptop computer is open on a white surface with a black and white logo that says 'Cursive & Block'.](https://i.etsystatic.com/24134568/r/il/3f5d18/2556669224/il_75x75.2556669224_jiyh.jpg)
- ![May include: A black framed poster with white text that reads 'Nevertheless, SHE persisted.'](https://i.etsystatic.com/24134568/r/il/591f48/2556668096/il_75x75.2556668096_ij1u.jpg)
- ![May include: A white and blue graphic with the text 'HOW DO I DOWNLOAD MY FILES?' in black. The text 'Three Different Ways' is in black and is below the main title. The graphic lists three ways to download files. The first way is to click 'View your digital files now' on the 'Thanks for your order' page. The second way is to download files from the receipt email. The third way is to go to 'Your account' in the top right corner of the screen, click 'Purchases and reviews', and then click 'Download files'.](https://i.etsystatic.com/24134568/r/il/9f9d3f/3222030883/il_75x75.3222030883_k132.jpg)
- ![May include: A blue and white graphic with the text 'Get the Latest News...' and a black and white logo that says 'Cursive & BLOCK'. The graphic also includes the text 'For shop updates, notifications on upcoming sales and a 20% Off Discount Code to use on your purchase JOIN THE CURSIVEANDBLOCK SHOP NEWS LIST Just type the link below into your browser: http://www.bit.ly/33rRjq2'](https://i.etsystatic.com/24134568/r/il/c15db9/3389883686/il_75x75.3389883686_962m.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F878329809%2Fnevertheless-she-persisted-elizabeth%23report-overlay-trigger)

Price:$5.79


Loading


# Nevertheless She Persisted Elizabeth Warren Feminism Poster, Motivational Poster Download, Printable Quote Wall Art For Women

Designed by [CursiveAndBlock](https://www.etsy.com/shop/CursiveAndBlock)

[5 out of 5 stars](https://www.etsy.com/listing/878329809/nevertheless-she-persisted-elizabeth#reviews)

4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Designed by [CursiveAndBlock](https://www.etsy.com/shop/CursiveAndBlock)

- Digital download


- Digital file type(s): 4 JPG, 1 PDF


- Width: 8 inches

Height: 10 inches

This particular quote became a popular, motivational statement for all women who have been silenced and dismissed by others. The strong, eye-catching typography of this printable quote highlights the word "SHE". The "She" refers to Democratic Senator Elizabeth Warren. In February 2017, Senator Warren was giving a speech in opposition to the nomination of Republican Senator Jeff Sessions for Attorney General. Senator Warren was not allowed to finish her speech and was silenced by Republican Senate Majority Leader, Mitch McConnell for what he claimed was a violation of Senate rules. He stated: "Senator Warren was giving a lengthy speech. She was warned. She was given an explanation. Nevertheless, she persisted."

In TIME Magazine of 3/1/2018, Senator Warren commented on McConnell's words and why they resonate with women: "Millions of women have taken up 'Nevertheless she persisted' as their rallying cry because they know that together, we can make a change," Make a change in your life. Put this motivational quote in a special place in your home or office. Stay inspired to persist with what you believe in.

ITEM DESCRIPTION:

\*\*THIS IS AN INSTANT DOWNLOAD DIGITAL FILE. NO PHYSICAL ITEM WILL BE SENT.

\-\- YOUR FILES ARE high-resolution, 300 dpi, JPG files for crisp, clean printing.

\-\- YOU WILL RECEIVE (4) file sizes: 8x10", 11x14", 16x20", and 24x36".

\*\*Need a different size than those listed? -- I offer ONE (1) FREE size customization per order, Just contact me after your purchase.

\-\- ALSO FREE WITH PURCHASE: A download of my helpful hints guide which contains instructions for printing your art at home or with a professional printing service.

\-\- MANY OPTIONS: Your digital files can be printed on a variety of other products such as t-shirts, mugs, pillows, office supplies, etc. using a professional printing company like Shutterfly, VistaPrint, Walgreens, Walmart, and others. Create a special gift for yourself or someone else!

✔ WANT TO EXPLORE FURTHER? YOU MAY ALSO LIKE THIS FEMINIST PRINT HERE: [https://www.etsy.com/listing/864386206](https://www.etsy.com/listing/864386206/ruth-bader-ginsburg-notorious-rbg-i)

✔ VISIT THE ENTIRE CURSIVE AND BLOCK COLLECTION - CLICK HERE: [https://www.etsy.com/shop/CursiveAndBlock](https://www.etsy.com/shop/CursiveAndBlock)

AND...Please don't hesitate to contact me for any reason. I'd love to hear from you!

❤ LIKE WHAT YOU SEE? FAVORITE THIS LISTING 🤍 OR FAVORITE MY SHOP 🤍

😉 THANKS FOR VISITING CURSIVEANDBLOCK AND SUPPORTING MY SMALL BUSINESS!

\\_\\_\\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

PRINTING RECOMMENDATIONS:

1- Using your home or office printer on quality paper, or a heavyweight, matte or smooth cardstock.

2- At your local office store such as Kinko's or Staples.

3- Upload your file to an online print-on-demand service like Shutterfly or VistaPrint.

4- Take your file on a USB drive to your local, small business print shop, or to a local photo processor like Walgreen's, Walmart or Costco.

\*\*All printable files purchased from Cursive and Block are for your personal use only. Non-commercial use only. Do not sell, share, or redistribute files in any way.


## Delivery

Instant Download

Your files will be available to download once payment is confirmed.
[Here's how.](https://www.etsy.com/help/article/3949)

Instant download items don’t accept returns, exchanges or cancellations. Please contact the seller about any problems with your order.

## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

View additional shop policies

## FAQs

How do I unzip a digital download file?


Open File Explorer, and find the zipped folder.

To unzip the entire folder, right-click to select 'Extract All', and then follow the instructions.

To unzip a single file or folder, double-click the zipped folder to open it. Then, drag or copy the item from the zipped folder to a new location.


Can I use my downloads for commercial purposes?


No.

All of CursiveAnd Block's printable art files and images are for PERSONAL USE ONLY. You may not resell or distribute art files, or physical printed copies.


Custom and personalized orders


No, not at this time.


Where can I get my digital art files printed?


You may print the 8x10 size on your home or office printer. For larger size prints, you may choose to have them printed at a local print shop such as Walmart, Walgreens, Costco. etc. or you can upload your files and get them printed through an online printing service. Here are some suggested printers: shutterfly.com, mpix.com, vistaprint.com and there are others you can find online as well.


Will the printed image look exactly like it does on screen?


Because printers are calibrated differently than computer monitors, it is likely that any colors you see on screen may turn out a bit different when they are printed.


If I am printing at home, what type of paper should I use?


A nice, smooth cardstock, a smooth matte paper, or heavyweight photo paper will give you a crisp finish. But, you may want to experiment with different types of papers to see which kind you prefer.


What are the advantages to purchasing digital printable art vs. an actual paper print?


Great question! Downloadable, digital art files allow you the flexibility and convenience of printing at home. You get to choose the paper, the size you'd like and you can print more than one copy if needed. Digital files are also quick and easy to upload to an online printing service or take to your local print shop so they can do the work for you.


How do I get my files after purchase?


There will be a link for you to download them as soon as your payment has cleared Esty. For more help with digital downloads, Etsy has a wonderful help article to assist you here: http://help.etsy.com/hc/en-us/articles/115013328108-Downloading-a-Digital-Item


Can you use printable art as gifts?


Yes, absolutely! Printable art can be used as a unique gift item for many occasions and for different types of recipients. Because it is digital, you can print your art at any time and for any occasion. Just print your digital art on the type of paper or cardstock you like and then you can easily add a matte and/or frame of your choice to create a memorable DIY art gift for someone special!


## Be the first to review this item

No reviews yet. See what customers say about other items from this shop.


Read reviews for other items


[![CursiveAndBlock](https://i.etsystatic.com/iusa/730178/79003829/iusa_75x75.79003829_lxlt.jpg?version=0)](https://www.etsy.com/shop/CursiveAndBlock?ref=shop_profile&listing_id=878329809)

[CursiveAndBlock](https://www.etsy.com/shop/CursiveAndBlock?ref=shop_profile&listing_id=878329809)

[Owned by Karen North](https://www.etsy.com/shop/CursiveAndBlock?ref=shop_profile&listing_id=878329809) \|

West Valley City, Utah

5.0
(36)


222 sales

5 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=335587965&referring_id=878329809&referring_type=listing&recipient_id=335587965&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDozMzU1ODc5NjU6MTc2Mjc3MjE2MDoyZTFiNjI4OGY5YTgwODQxY2E2MWI5MTQ5NTgxNDU5OA%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F878329809%2Fnevertheless-she-persisted-elizabeth)

This seller usually responds **within a few hours.**

## All reviews from this shop (36)

Show all

Beautiful piece for my B&W themed wall

![Wen added a photo of their purchase](https://i.etsystatic.com/iap/8c905b/6792539671/iap_300x300.6792539671_h63wa3pe.jpg?version=0)

![](https://i.etsystatic.com/iusa/fd0026/34284027/iusa_75x75.34284027_i3yy.jpg?version=0)

WenMar 25, 2025

Purchased: [Oscar Wilde Quote, Literary Print Download, Above Bed Art, Daisies Flower Wall Decor, Printable Spring Sign, Flower Blossoms For Its Own JoyOpens a new tab](https://www.etsy.com/listing/963069218/oscar-wilde-quote-literary-print?ref=mys_shop_reviews)

Excellent quality and my students really enjoyed filling in with Shakespeare thoughts for dear ones.

![Diana Maria added a photo of their purchase](https://i.etsystatic.com/iap/ecc49c/6124298832/iap_300x300.6124298832_gfjho2dk.jpg?version=0)

![](https://i.etsystatic.com/iusa/8bc9d1/113831873/iusa_75x75.113831873_niup.jpg?version=0)

Diana MariaJul 14, 2024

Purchased: [Funny Birthday Card With Shakespeare Macbeth Quote Make A Wish Digital DownloadOpens a new tab](https://www.etsy.com/listing/1074195928/funny-birthday-card-with-shakespeare?ref=mys_shop_reviews)

Quick and easy. Loved it!

Heather DingemanNov 6, 2025

Purchased: [Happy Anniversary Bee Greeting Card, Special Occasion, Card for Couple, Printable Digital Download NotecardOpens a new tab](https://www.etsy.com/listing/848991967/happy-anniversary-bee-greeting-card?ref=mys_shop_reviews)

Great product and beautiful design!

![](https://i.etsystatic.com/iusa/67682e/111303482/iusa_75x75.111303482_72p5.jpg?version=0)

SarahFeb 26, 2025

Purchased: [Funny Birthday Card With Shakespeare Macbeth Quote Make A Wish Digital DownloadOpens a new tab](https://www.etsy.com/listing/1074195928/funny-birthday-card-with-shakespeare?ref=mys_shop_reviews)

I love it in my Social Studies class!

![](https://i.etsystatic.com/iusa/b9913c/34675666/iusa_75x75.34675666_gj77.jpg?version=0)

CherylJul 20, 2024

Purchased: [Funny Snarky Saying Don't Make Me Repeat Myself History Poster, Printable Quote Classroom Sign For History Teacher Instant DownloadOpens a new tab](https://www.etsy.com/listing/1023348991/funny-snarky-saying-dont-make-me-repeat?ref=mys_shop_reviews)

Was just as expected. My daughter loved it.

BrendaApr 28, 2024

Purchased: [Funny Birthday Card With Shakespeare Macbeth Quote Make A Wish Digital DownloadOpens a new tab](https://www.etsy.com/listing/1074195928/funny-birthday-card-with-shakespeare?ref=mys_shop_reviews)

Why are these reviews shown?

All reviews are from verified buyers. Reviews are shown automatically based on factors like recency, whether they include comments, your chosen language, and whether the rating reflects the typical experience with the shop.

## More from this shop

[Visit shop](https://www.etsy.com/shop/CursiveAndBlock?ref=lp_mys_mfts)

- [![Feminist Poster Quote Prints, Nevertheless She Persisted And I Dissent Ruth Bader Ginsburg Elizabeth Warren Digital Downloads Feminism Art](https://i.etsystatic.com/24134568/r/il/1a652f/2627369995/il_340x270.2627369995_pvxc.jpg)\\
\\
Digital download\\
\\
\\
**Feminist Poster Quote Prints, Nevertheless She Persisted And I Dissent Ruth Bader Ginsburg Elizabeth Warren Digital Downloads Feminism Art**\\
\\
$6.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/870363784/feminist-poster-quote-prints?click_key=fe7cbc0dc6458ce4c95e84061d40d204%3ALTa888b172378ad0fc4b2c421f5bc796d8bde4e299&click_sum=4bc581b8&ls=r&ref=related-1&dd=1&content_source=fe7cbc0dc6458ce4c95e84061d40d204%253ALTa888b172378ad0fc4b2c421f5bc796d8bde4e299 "Feminist Poster Quote Prints, Nevertheless She Persisted And I Dissent Ruth Bader Ginsburg Elizabeth Warren Digital Downloads Feminism Art")




Add to Favorites


- [![Romeo And Juliet Literature Poster, The Bard William Shakespeare Printable Quote Wall Art, Rose By Any Name Digital Print](https://i.etsystatic.com/24134568/r/il/2fee41/3194340655/il_340x270.3194340655_rsck.jpg)\\
\\
Digital download\\
\\
\\
**Romeo And Juliet Literature Poster, The Bard William Shakespeare Printable Quote Wall Art, Rose By Any Name Digital Print**\\
\\
$5.79\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1036195041/romeo-and-juliet-literature-poster-the?click_key=fe7cbc0dc6458ce4c95e84061d40d204%3ALTb0e7c7b98a0d0e013b698c97a07249c591cec3a1&click_sum=54af33ed&ls=r&ref=related-2&dd=1&content_source=fe7cbc0dc6458ce4c95e84061d40d204%253ALTb0e7c7b98a0d0e013b698c97a07249c591cec3a1 "Romeo And Juliet Literature Poster, The Bard William Shakespeare Printable Quote Wall Art, Rose By Any Name Digital Print")




Add to Favorites


- [![Matisse Print Digital Download, Artist Henri Matisse Printable Word Art Poster, Flower Wall Art, Encouraging Quote Wall Decor](https://i.etsystatic.com/24134568/r/il/244eee/2819119354/il_340x270.2819119354_apsx.jpg)\\
\\
Digital download\\
\\
\\
**Matisse Print Digital Download, Artist Henri Matisse Printable Word Art Poster, Flower Wall Art, Encouraging Quote Wall Decor**\\
\\
$5.79\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/935026834/matisse-print-digital-download-artist?click_key=fe7cbc0dc6458ce4c95e84061d40d204%3ALT4e88b148005b44c8b68cc24c12888b0c92004b55&click_sum=5065569f&ls=r&ref=related-3&dd=1&content_source=fe7cbc0dc6458ce4c95e84061d40d204%253ALT4e88b148005b44c8b68cc24c12888b0c92004b55 "Matisse Print Digital Download, Artist Henri Matisse Printable Word Art Poster, Flower Wall Art, Encouraging Quote Wall Decor")




Add to Favorites


- [![Thank You Gratitude Appreciation Card Printable Download For Business, Teacher, Mail Carrier, Essential Worker](https://i.etsystatic.com/24134568/r/il/49735a/2698731001/il_340x270.2698731001_4nnp.jpg)\\
\\
Digital download\\
\\
\\
**Thank You Gratitude Appreciation Card Printable Download For Business, Teacher, Mail Carrier, Essential Worker**\\
\\
$3.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/902167403/thank-you-gratitude-appreciation-card?click_key=5c5e059339864cce4933a6a80cd663bb711fd163%3A902167403&click_sum=4a92f734&ref=related-4&dd=1 "Thank You Gratitude Appreciation Card Printable Download For Business, Teacher, Mail Carrier, Essential Worker")




Add to Favorites



## You may also like

Including ads
Learn more
Sellers looking to grow their business and reach more interested buyers can use Etsy’s advertising platform to promote their items. You’ll see ad results based on factors like relevancy, and the amount sellers pay per click. [Learn more](https://www.etsy.com/legal/policy/search-advertisement-ranking-disclosures/899478564529).


[See more](https://www.etsy.com/r/similar/878329809?ref=internal_similar_listing_bot)

- [![She Remembered Who She Was, Feminist Art Print, Female Empowerment, Woman line art,  Strong Women Motivational Quote, Divorce Gift for Her](https://i.etsystatic.com/27870891/r/il/880671/6878006857/il_340x270.6878006857_gvun.jpg)\\
\\
Digital download\\
\\
\\
**She Remembered Who She Was, Feminist Art Print, Female Empowerment, Woman line art, Strong Women Motivational Quote, Divorce Gift for Her**\\
\\
$5.65\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1871755720/she-remembered-who-she-was-feminist-art?click_key=9891a717de237ab67d8692f4d1f30685%3ALT2ee6b90cfedb25c967d9b8df2e3013adfe506c38&click_sum=aaee9589&ls=r&ref=internal-recs-733496-1&sts=1&dd=1&content_source=9891a717de237ab67d8692f4d1f30685%253ALT2ee6b90cfedb25c967d9b8df2e3013adfe506c38 "She Remembered Who She Was, Feminist Art Print, Female Empowerment, Woman line art,  Strong Women Motivational Quote, Divorce Gift for Her")




Add to Favorites


- [![Feminist Wall Art: Motivational Women Empowerment Quote (Digital Download)](https://i.etsystatic.com/55458647/c/1724/1724/129/210/il/da310c/7213401144/il_340x270.7213401144_4wnx.jpg)\\
\\
Digital download\\
\\
\\
**Feminist Wall Art: Motivational Women Empowerment Quote (Digital Download)**\\
\\
Sale Price $6.04\\
$6.04\\
\\
$9.30\\
Original Price $9.30\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1807198648/feminist-wall-art-motivational-women?click_key=9891a717de237ab67d8692f4d1f30685%3ALTd7eb4429ef60b5f60cbdd8ff39129abc8218e5d8&click_sum=72f7e17d&ls=r&ref=internal-recs-733496-2&pro=1&dd=1&content_source=9891a717de237ab67d8692f4d1f30685%253ALTd7eb4429ef60b5f60cbdd8ff39129abc8218e5d8 "Feminist Wall Art: Motivational Women Empowerment Quote (Digital Download)")




Add to Favorites


- [![Nevertheless She Persisted Art Print || Feminist Poster](https://i.etsystatic.com/14020210/c/2681/2131/148/0/il/5a0c6e/2908036343/il_340x270.2908036343_r11o.jpg)\\
\\
**Nevertheless She Persisted Art Print \|\| Feminist Poster**\\
\\
$11.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/945927656/nevertheless-she-persisted-art-print?click_key=9891a717de237ab67d8692f4d1f30685%3ALT57311d27ccfc38c925e32c2586ae0f44a1f57206&click_sum=d35a9c87&ls=r&ref=internal-recs-733496-3&content_source=9891a717de237ab67d8692f4d1f30685%253ALT57311d27ccfc38c925e32c2586ae0f44a1f57206 "Nevertheless She Persisted Art Print || Feminist Poster")




Add to Favorites


- [![RBG Quote, Ruth Bader Ginsburg Wall Art Printable, Fight for the Things You Care About, Inspiration Quote RBG, Instant Download in Blue](https://i.etsystatic.com/7890320/r/il/0944c6/2592591475/il_340x270.2592591475_bvvs.jpg)\\
\\
Digital download\\
\\
\\
**RBG Quote, Ruth Bader Ginsburg Wall Art Printable, Fight for the Things You Care About, Inspiration Quote RBG, Instant Download in Blue**\\
\\
$5.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/874811809/rbg-quote-ruth-bader-ginsburg-wall-art?click_key=9891a717de237ab67d8692f4d1f30685%3ALTa1b761ea99af8fa66d4d61b67a73390289817573&click_sum=8798fab1&ls=r&ref=internal-recs-733496-4&dd=1&content_source=9891a717de237ab67d8692f4d1f30685%253ALTa1b761ea99af8fa66d4d61b67a73390289817573 "RBG Quote, Ruth Bader Ginsburg Wall Art Printable, Fight for the Things You Care About, Inspiration Quote RBG, Instant Download in Blue")




Add to Favorites


- [![I Am My Own Muse Print: Feminist Wall Art (Digital Download)](https://i.etsystatic.com/27870891/r/il/f48fe9/6169931188/il_340x270.6169931188_5xez.jpg)\\
\\
Digital download\\
\\
\\
**I Am My Own Muse Print: Feminist Wall Art (Digital Download)**\\
\\
$4.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1739498174/i-am-my-own-muse-print-feminist-wall-art?click_key=9891a717de237ab67d8692f4d1f30685%3ALT62b247d4e4c4b1cd049b76f247e4255b9a59edae&click_sum=2f7c4460&ls=r&ref=internal-recs-733496-5&sts=1&dd=1&content_source=9891a717de237ab67d8692f4d1f30685%253ALT62b247d4e4c4b1cd049b76f247e4255b9a59edae "I Am My Own Muse Print: Feminist Wall Art (Digital Download)")




Add to Favorites


- [![Ruth Bader Ginsburg Quote. Feminist Print. Inspirational Wall Art. Motivational Wall Decor. RBG Art. Not Fragile Like A Flower.](https://i.etsystatic.com/28152866/r/il/3f0562/3486261002/il_340x270.3486261002_pv6r.jpg)\\
\\
Digital download\\
\\
\\
**Ruth Bader Ginsburg Quote. Feminist Print. Inspirational Wall Art. Motivational Wall Decor. RBG Art. Not Fragile Like A Flower.**\\
\\
Sale Price $3.97\\
$3.97\\
\\
$6.61\\
Original Price $6.61\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1125995153/ruth-bader-ginsburg-quote-feminist-print?click_key=9891a717de237ab67d8692f4d1f30685%3ALTc2f324ac9c4494ab0dc01372904aaaf3bb643a60&click_sum=4ee2a0b1&ls=r&ref=internal-recs-733496-6&pro=1&sts=1&dd=1&content_source=9891a717de237ab67d8692f4d1f30685%253ALTc2f324ac9c4494ab0dc01372904aaaf3bb643a60 "Ruth Bader Ginsburg Quote. Feminist Print. Inspirational Wall Art. Motivational Wall Decor. RBG Art. Not Fragile Like A Flower.")




Add to Favorites



[![And Still, I Rise – Maya Angelou Printable Quote | Resilience Wall Decor | Empowerment Digital Poster Download](https://i.etsystatic.com/62065144/r/il/df2539/7244257529/il_340x270.7244257529_lkg2.jpg)\\
\\
Digital download\\
\\
\\
**And Still, I Rise – Maya Angelou Printable Quote \| Resilience Wall Decor \| Empowerment Digital Poster Download**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
fivesisstudio\\
From shop fivesisstudio\\
\\
$6.03\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4369031629/and-still-i-rise-maya-angelou-printable?click_key=LTab2acf0137025fb7bfd893f5d3c93b5501ed36c9%3A4369031629&click_sum=55eb956e&ls=a&ref=internal-recs-733495-1&dd=1 "And Still, I Rise – Maya Angelou Printable Quote | Resilience Wall Decor | Empowerment Digital Poster Download")


Add to Favorites


[![Marjane Satrapi Quote Print: Unity Beyond Borders (Digital Download)](https://i.etsystatic.com/58052321/r/il/14cc8d/6754044316/il_340x270.6754044316_hv4v.jpg)\\
\\
Digital download\\
\\
\\
**Marjane Satrapi Quote Print: Unity Beyond Borders (Digital Download)**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
MaktaraArt\\
From shop MaktaraArt\\
\\
Sale Price $4.32\\
$4.32\\
\\
$8.65\\
Original Price $8.65\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1895600543/marjane-satrapi-quote-print-unity-beyond?click_key=LT3a663a024ecb764cbff7186f2725682b6971982c%3A1895600543&click_sum=18fba73d&ls=a&ref=internal-recs-733495-2&pro=1&dd=1 "Marjane Satrapi Quote Print: Unity Beyond Borders (Digital Download)")


Add to Favorites


[![Blunt Political Quote Printable, &quot;Charisma of a Damp Rag&quot; Farage Poster, Sarcastic Typography Wall Art, Funny Political Gift](https://i.etsystatic.com/59450658/r/il/5e31b4/7137352730/il_340x270.7137352730_ee80.jpg)\\
\\
Digital download\\
\\
\\
**Blunt Political Quote Printable, "Charisma of a Damp Rag" Farage Poster, Sarcastic Typography Wall Art, Funny Political Gift**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
DigiPrintByCook\\
From shop DigiPrintByCook\\
\\
$4.56\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4323565787/blunt-political-quote-printable-charisma?click_key=LTb03ff5ba26c6faa7ef34973b62306aa005ee4745%3A4323565787&click_sum=e6461037&ls=a&ref=internal-recs-733495-3&dd=1 "Blunt Political Quote Printable, \"Charisma of a Damp Rag\" Farage Poster, Sarcastic Typography Wall Art, Funny Political Gift")


Add to Favorites


[![Journey Print, Funny Wall Art, Humorous Print,](https://i.etsystatic.com/30810614/r/il/63598c/5842720276/il_340x270.5842720276_aytf.jpg)\\
\\
**Journey Print, Funny Wall Art, Humorous Print,**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
CleoDesignsArt\\
From shop CleoDesignsArt\\
\\
$7.77\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1696478211/journey-print-funny-wall-art-humorous?click_key=LT99631e07844f0dcbb1282fe309aec21bd0817791%3A1696478211&click_sum=5bb901b6&ls=a&ref=internal-recs-733495-4 "Journey Print, Funny Wall Art, Humorous Print,")


Add to Favorites


[![Endless Discovery: Inspirational Quote Wall Art | Thoughtful Printable Poster for Soulful Home Decor](https://i.etsystatic.com/23279956/r/il/e82b2e/7010805995/il_340x270.7010805995_k3hz.jpg)\\
\\
Digital download\\
\\
\\
**Endless Discovery: Inspirational Quote Wall Art \| Thoughtful Printable Poster for Soulful Home Decor**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
ByFableDesignStudio\\
From shop ByFableDesignStudio\\
\\
$7.29\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4324758444/endless-discovery-inspirational-quote?click_key=LTeb811f077e48dea68e85fd261718e17bd62a02cd%3A4324758444&click_sum=a3a43c56&ls=a&ref=internal-recs-733495-5&dd=1 "Endless Discovery: Inspirational Quote Wall Art | Thoughtful Printable Poster for Soulful Home Decor")


Add to Favorites


[![I am the Storm Canvas Print: Blue & Gold Feminist Wall Art](https://i.etsystatic.com/34151806/r/il/987d25/7116637415/il_340x270.7116637415_ex2a.jpg)\\
\\
Digital download\\
\\
\\
**I am the Storm Canvas Print: Blue & Gold Feminist Wall Art**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
SnowdropTee\\
From shop SnowdropTee\\
\\
Sale Price $3.12\\
$3.12\\
\\
$7.80\\
Original Price $7.80\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4358550214/i-am-the-storm-canvas-print-blue-gold?click_key=LT1cdca23d45a29427d2bb0f302c216f0b60fa726e%3A4358550214&click_sum=8ed183cd&ls=a&ref=internal-recs-733495-6&pro=1&dd=1 "I am the Storm Canvas Print: Blue & Gold Feminist Wall Art")


Add to Favorites


GIFTS

Browse by interest for the best gifts!

[Shop now](https://www.etsy.com/gift-mode?ref=listing_suggested_personas_related)

[The \\
\\
Art Admirer \\
\\
![The <br /> Art Admirer](https://i.etsystatic.com/ij/05f5e3/5641706915/ij_300x300.5641706915_m0bwlgl1.jpg?version=0)](https://www.etsy.com/gift-mode/persona/the-art-admirer?ref=listing_suggested_personas_related) [The \\
\\
Coach \\
\\
![The <br /> Coach](https://i.etsystatic.com/ij/3f05cf/5598215508/ij_300x300.5598215508_iddzyj95.jpg?version=0)](https://www.etsy.com/gift-mode/persona/the-coach?ref=listing_suggested_personas_related) [The \\
\\
Interior Designer \\
\\
![The <br /> Interior Designer](https://i.etsystatic.com/ij/35e966/5598538384/ij_300x300.5598538384_2tnokeg0.jpg?version=0)](https://www.etsy.com/gift-mode/persona/the-interior-designer?ref=listing_suggested_personas_related) [The \\
\\
Poet \\
\\
![The <br /> Poet](https://i.etsystatic.com/ij/b5bf55/5646735169/ij_300x300.5646735169_2lqb0dj3.jpg?version=0)](https://www.etsy.com/gift-mode/persona/the-poet?ref=listing_suggested_personas_related) [The \\
\\
Fitness Fanatic \\
\\
![The <br /> Fitness Fanatic](https://i.etsystatic.com/ij/a66bf0/5598361602/ij_300x300.5598361602_bsntk5ma.jpg?version=0)](https://www.etsy.com/gift-mode/persona/the-fitness-fanatic?ref=listing_suggested_personas_related)

[Shop now](https://www.etsy.com/gift-mode?ref=listing_suggested_personas_related)

## Explore related searches

![](https://i.etsystatic.com/7916159/r/il/e47c97/5720658168/il_75x75.5720658168_oxwf.jpg)

Michelle Obama Quotes


![](https://i.etsystatic.com/5178603/r/il/cdf6fd/7278766771/il_75x75.7278766771_h7qu.jpg)

Female Empowerment Prints


![](https://i.etsystatic.com/22360851/r/il/d08b27/6369763875/il_75x75.6369763875_c6vw.jpg)

Strong Women Quotes


![](https://i.etsystatic.com/14020210/c/2681/2131/148/0/il/5a0c6e/2908036343/il_75x75.2908036343_r11o.jpg)

Nevertheless She Persisted Poster


![](https://i.etsystatic.com/43971578/r/il/a26ed7/5565429789/il_75x75.5565429789_8idm.jpg)

Empowered Women Poster


## Explore more related searches

[Nevertheless She Persisted Print](https://www.etsy.com/market/nevertheless_she_persisted_print?ref=lp_queries_internal_bottom-6)

[Women Protesters](https://www.etsy.com/market/women_protesters?ref=lp_queries_internal_bottom-7)

[Famous Female Quotes](https://www.etsy.com/market/famous_female_quotes?ref=lp_queries_internal_bottom-8)

[Older Women Quotes](https://www.etsy.com/market/older_women_quotes?ref=lp_queries_internal_bottom-9)

[Female Motivation Posters](https://www.etsy.com/market/female_motivation_posters?ref=lp_queries_internal_bottom-10)

[Inspiration Women](https://www.etsy.com/market/inspiration_women?ref=lp_queries_internal_bottom-11)

[Nevertheless She Persisted Art](https://www.etsy.com/market/nevertheless_she_persisted_art?ref=lp_queries_internal_bottom-12)

[One Morning She Woke Up](https://www.etsy.com/market/one_morning_she_woke_up?ref=lp_queries_internal_bottom-13)

[Women History Art](https://www.etsy.com/market/women_history_art?ref=lp_queries_internal_bottom-14)

[Women Empowerment Bathroom Quote](https://www.etsy.com/market/women_empowerment_bathroom_quote?ref=lp_queries_internal_bottom-15)

[She Woke Up](https://www.etsy.com/market/she_woke_up?ref=lp_queries_internal_bottom-16)

[She Persisted Poster](https://www.etsy.com/market/she_persisted_poster?ref=lp_queries_internal_bottom-17)

[Quotes Woman](https://www.etsy.com/market/quotes_woman?ref=lp_queries_internal_bottom-18)

[Well Behaved Women Poster](https://www.etsy.com/market/well_behaved_women_poster?ref=lp_queries_internal_bottom-19)

[Historical Women Prints](https://www.etsy.com/market/historical_women_prints?ref=lp_queries_internal_bottom-20)

[Female Empowerment Drawing & Illustration](https://www.etsy.com/market/female_empowerment_drawing_%26_illustration?ref=lp_queries_internal_bottom-21)

[Signage for Women](https://www.etsy.com/market/signage_for_women?ref=lp_queries_internal_bottom-22)

[Famous Women Quotes](https://www.etsy.com/market/famous_women_quotes?ref=lp_queries_internal_bottom-23)

Listed on Oct 15, 2025


[4 favorites](https://www.etsy.com/listing/878329809/nevertheless-she-persisted-elizabeth/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?explicit=1&ref=breadcrumb_listing) [Prints](https://www.etsy.com/c/art-and-collectibles/prints?explicit=1&ref=breadcrumb_listing) [Digital Prints](https://www.etsy.com/c/art-and-collectibles/prints/digital-prints?explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Prints

[Shop 8x11 Floral Art Printable](https://www.etsy.com/market/8x11_floral_art_printable) [Highland Cow Bathroom Print Scottish Highlands Cow Print Funny Toilet Art Animal Humor Bathroom Home Wall Decor Restroom Potty Download by BlackDogCustomGifts](https://www.etsy.com/listing/1598971351/highland-cow-bathroom-print-scottish) [Shop Betty Leopard](https://www.etsy.com/market/betty_leopard) [Shop Autumn Drawing](https://www.etsy.com/market/autumn_drawing) [Chemistry Birthday Card](https://www.etsy.com/listing/1795899876/chemistry-birthday-card-nerd-geek-gift) [Lion and the lamb PNG digital download by KngdmKreations](https://www.etsy.com/listing/1528511792/lion-and-the-lamb-png-digital-download) [Punjabi Village Art I Village Life I Indian Ethnic Home Decor I Sikh Gift Ideas I Traditional Indian Printable Wall Art I Punjabi wall decor - Prints](https://www.etsy.com/listing/986263025/punjabi-village-art-i-village-life-i) [Carolina Swamp Rabbit by OldFangledFinds](https://www.etsy.com/listing/1291734302/audubon-1954-marsh-rabbit-carolina-swamp)

Books

[Shop Books from LifeCoachLarry](https://www.etsy.com/shop/LifeCoachLarry)

Bracelets

[Superconductor Bracelet - US](https://www.etsy.com/market/superconductor_bracelet)

Tools & Equipment

[Shop Husqvarna Viking Designer Topaz 30](https://www.etsy.com/market/husqvarna_viking_designer_topaz_30)

Fabric & Notions

[3m Reflective Fabric - US](https://www.etsy.com/market/3m_reflective_fabric) [2 pcs floral embroidery Lace Applique Patch - Fabric & Notions](https://www.etsy.com/listing/611291328/2-pcs-floral-embroidery-lace-applique)

Home Decor

[Black Cat Witch - Home Decor](https://www.etsy.com/listing/1813611396/scented-candles-black-cat-witch-coconut)

Pet Collars & Leashes

[Petal Perfect Dog Collar - Multiple Sizes by BeachBiscuitLove](https://www.etsy.com/listing/1193440423/petal-perfect-dog-collar-multiple-sizes)

Gender Neutral Adult Clothing

[Nature Conservation Shirt](https://www.etsy.com/listing/1888533247/support-national-parks-shirt-nature)

Paper

[PRIDE AVOCADO STICKER by DoseOfWhimsyArt](https://www.etsy.com/listing/1243544613/pride-avocado-sticker-rainbow-lgbt-lgbtq)

Toys

[Shop Range Viper](https://www.etsy.com/market/range_viper)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F878329809%2Fnevertheless-she-persisted-elizabeth&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc3MjE2MDpmNDU1ZDQ3OTM5NTQxMzRhM2JjMTg4ZjFlZGQyNzUxNw==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F878329809%2Fnevertheless-she-persisted-elizabeth) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/878329809/nevertheless-she-persisted-elizabeth#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F878329809%2Fnevertheless-she-persisted-elizabeth)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for CursiveAndBlock

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![May include: A black and white printable poster with the text 'Nevertheless, SHE persisted.'](https://i.etsystatic.com/24134568/r/il/1119cf/2762006238/il_300x300.2762006238_hha8.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/Generic_Benefits_of_Printable_Art_Video_adukw7.jpg)

- ![May include: A white brick wall with a blue banner at the top and bottom. The banner has the text 'Hi there, I'm Karen...' at the top and the text 'I have five star reviews!' at the bottom. The banner also has a black and white logo that says 'Cursive & BLOCK' in the top right corner and the bottom right corner. The text in the middle of the image reads 'I offer a variety of high-quality, easy to download digital art prints that will enhance your decor. My designs are created with careful attention to detail and will add a meaningful touch to your living spaces.'](https://i.etsystatic.com/24134568/r/il/bf2112/3437556157/il_300x300.3437556157_26nz.jpg)
- ![May include: A digital art print file download description. The text reads: 'This is a digital art print file that you download. NO PHYSICAL PRODUCT WILL BE SENT. High-resolution, 300 dpi, JPG files for crisp prints. You will receive (4) file sizes: 8x10, 11x14, 16x20 and 24x36. Also included is a downloadable 'Helpful Hints Guide' on how to print your art at home, or using a printing service. PURCHASE, DOWNLOAD, PRINT = Instant art! (See item description below for more details.)'](https://i.etsystatic.com/24134568/r/il/794e61/3437556563/il_300x300.3437556563_ktw1.jpg)
- ![May include: A framed black and white print with the text 'Nevertheless, SHE persisted.'  A laptop computer is open on a white surface with a black and white logo that says 'Cursive & Block'.](https://i.etsystatic.com/24134568/r/il/3f5d18/2556669224/il_300x300.2556669224_jiyh.jpg)
- ![May include: A black framed poster with white text that reads 'Nevertheless, SHE persisted.'](https://i.etsystatic.com/24134568/r/il/591f48/2556668096/il_300x300.2556668096_ij1u.jpg)
- ![May include: A white and blue graphic with the text 'HOW DO I DOWNLOAD MY FILES?' in black. The text 'Three Different Ways' is in black and is below the main title. The graphic lists three ways to download files. The first way is to click 'View your digital files now' on the 'Thanks for your order' page. The second way is to download files from the receipt email. The third way is to go to 'Your account' in the top right corner of the screen, click 'Purchases and reviews', and then click 'Download files'.](https://i.etsystatic.com/24134568/r/il/9f9d3f/3222030883/il_300x300.3222030883_k132.jpg)
- ![May include: A blue and white graphic with the text 'Get the Latest News...' and a black and white logo that says 'Cursive & BLOCK'. The graphic also includes the text 'For shop updates, notifications on upcoming sales and a 20% Off Discount Code to use on your purchase JOIN THE CURSIVEANDBLOCK SHOP NEWS LIST Just type the link below into your browser: http://www.bit.ly/33rRjq2'](https://i.etsystatic.com/24134568/r/il/c15db9/3389883686/il_300x300.3389883686_962m.jpg)

## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


Regions Etsy does business in:

[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)

[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)

[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)

[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)

[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)

[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)

[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)

[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)

[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)

[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)

[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)

[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)

[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)

[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)

[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)

[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)

[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)

[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)

[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)

[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)

[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)

[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)

[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)

[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)

[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)

[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)

[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)

Got it

Scroll previousScroll next