[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1463731889/progress-over-perfection-inspirational#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?explicit=1&ref=catnav_breadcrumb-0)
- [Prints](https://www.etsy.com/c/art-and-collectibles/prints?explicit=1&ref=catnav_breadcrumb-1)
- [Digital Prints](https://www.etsy.com/c/art-and-collectibles/prints/digital-prints?explicit=1&ref=catnav_breadcrumb-2)


Add to Favorites


- ![May include: A framed print with the text 'PROGRESS - OVER - PERFECTION' in black text on a white background. The print is framed in a light brown wood frame and is sitting on a light brown wood floor. The text 'arrie design co' and 'DIGITAL DOWNLOAD' is in the bottom right corner of the print.](https://i.etsystatic.com/36702753/r/il/3f8141/4827862456/il_794xN.4827862456_44xz.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![Progress Over Perfection Inspirational Office Art Print, Minimalist Home Office Decor, Positive Affirmation Poster, Motivational Typography image 2](https://i.etsystatic.com/36702753/r/il/b8cac4/4112637252/il_794xN.4112637252_p271.jpg)
- ![Progress Over Perfection Inspirational Office Art Print, Minimalist Home Office Decor, Positive Affirmation Poster, Motivational Typography image 3](https://i.etsystatic.com/36702753/r/il/c36931/4193729709/il_794xN.4193729709_20be.jpg)
- ![May include: A wooden frame with a white card inside that reads 'PROGRESS OVER PERFECTION'. A light gray ceramic mug is on a wooden coaster next to the frame.](https://i.etsystatic.com/36702753/r/il/4c2ea0/4827818614/il_794xN.4827818614_5kdv.jpg)
- ![May include: A white desk with a wooden top and two white drawers. On the desk is a black keyboard, a black camera, a potted plant, a black and silver computer monitor, a black laptop, and a framed print with the text 'PROGRESS OVER PERFECTION' in black letters. There is also a framed print with a geometric design and a framed print with the text 'CREATE' in black letters.](https://i.etsystatic.com/36702753/r/il/91084c/4876078327/il_794xN.4876078327_n1kp.jpg)
- ![May include: A framed print with the text 'PROGRESS -OVER- PERFECTION' on a light beige background. The print is sitting on a light brown wooden bench with a woven rattan top. There are three books stacked on top of the print. A white ceramic vase and a brown ceramic vase are on the bench.](https://i.etsystatic.com/36702753/r/il/73d948/4827818606/il_794xN.4827818606_fel3.jpg)
- ![May include: A black framed poster with white text that reads 'PROGRESS -OVER- PERFECTION' hanging on a white wall. A small green plant is in a black pot on the left side of the image. A cactus is in a white pot on the right side of the image. A white table with a black bench and two pink chairs are in the foreground.](https://i.etsystatic.com/36702753/r/il/5ca1c4/4876078321/il_794xN.4876078321_jh5m.jpg)
- ![May include: A white computer monitor with a black frame displaying a website with a grid of colorful images. The monitor is on a desk with a plant in a terracotta pot to the left. Above the monitor are three framed pictures, one with a mirror, one with a colorful illustration of a tree and a building, and one with a colorful illustration of a woman. To the right of the monitor is a white wire grid with several cards with colorful illustrations and text. One card has the text 'Progress over Perfection'.](https://i.etsystatic.com/36702753/r/il/884f76/4876078355/il_794xN.4876078355_9qsg.jpg)
- ![May include: White card with black text on a wooden background with green leaves. The text reads 'PROGRESS OVER PERFECTION.'](https://i.etsystatic.com/36702753/r/il/7141e9/4827818620/il_794xN.4827818620_awuk.jpg)

- ![May include: A framed print with the text 'PROGRESS - OVER - PERFECTION' in black text on a white background. The print is framed in a light brown wood frame and is sitting on a light brown wood floor. The text 'arrie design co' and 'DIGITAL DOWNLOAD' is in the bottom right corner of the print.](https://i.etsystatic.com/36702753/c/1994/1585/460/323/il/3f8141/4827862456/il_75x75.4827862456_44xz.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/progress-perfection_n8g4br.jpg)

- ![Progress Over Perfection Inspirational Office Art Print, Minimalist Home Office Decor, Positive Affirmation Poster, Motivational Typography image 2](https://i.etsystatic.com/36702753/r/il/b8cac4/4112637252/il_75x75.4112637252_p271.jpg)
- ![Progress Over Perfection Inspirational Office Art Print, Minimalist Home Office Decor, Positive Affirmation Poster, Motivational Typography image 3](https://i.etsystatic.com/36702753/r/il/c36931/4193729709/il_75x75.4193729709_20be.jpg)
- ![May include: A wooden frame with a white card inside that reads 'PROGRESS OVER PERFECTION'. A light gray ceramic mug is on a wooden coaster next to the frame.](https://i.etsystatic.com/36702753/r/il/4c2ea0/4827818614/il_75x75.4827818614_5kdv.jpg)
- ![May include: A white desk with a wooden top and two white drawers. On the desk is a black keyboard, a black camera, a potted plant, a black and silver computer monitor, a black laptop, and a framed print with the text 'PROGRESS OVER PERFECTION' in black letters. There is also a framed print with a geometric design and a framed print with the text 'CREATE' in black letters.](https://i.etsystatic.com/36702753/r/il/91084c/4876078327/il_75x75.4876078327_n1kp.jpg)
- ![May include: A framed print with the text 'PROGRESS -OVER- PERFECTION' on a light beige background. The print is sitting on a light brown wooden bench with a woven rattan top. There are three books stacked on top of the print. A white ceramic vase and a brown ceramic vase are on the bench.](https://i.etsystatic.com/36702753/r/il/73d948/4827818606/il_75x75.4827818606_fel3.jpg)
- ![May include: A black framed poster with white text that reads 'PROGRESS -OVER- PERFECTION' hanging on a white wall. A small green plant is in a black pot on the left side of the image. A cactus is in a white pot on the right side of the image. A white table with a black bench and two pink chairs are in the foreground.](https://i.etsystatic.com/36702753/r/il/5ca1c4/4876078321/il_75x75.4876078321_jh5m.jpg)
- ![May include: A white computer monitor with a black frame displaying a website with a grid of colorful images. The monitor is on a desk with a plant in a terracotta pot to the left. Above the monitor are three framed pictures, one with a mirror, one with a colorful illustration of a tree and a building, and one with a colorful illustration of a woman. To the right of the monitor is a white wire grid with several cards with colorful illustrations and text. One card has the text 'Progress over Perfection'.](https://i.etsystatic.com/36702753/r/il/884f76/4876078355/il_75x75.4876078355_9qsg.jpg)
- ![May include: White card with black text on a wooden background with green leaves. The text reads 'PROGRESS OVER PERFECTION.'](https://i.etsystatic.com/36702753/r/il/7141e9/4827818620/il_75x75.4827818620_awuk.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1463731889%2Fprogress-over-perfection-inspirational%23report-overlay-trigger)

Price:$4.50


Loading


# Progress Over Perfection Inspirational Office Art Print, Minimalist Home Office Decor, Positive Affirmation Poster, Motivational Typography

Designed by [ArrieDesignCo](https://www.etsy.com/shop/ArrieDesignCo)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1463731889/progress-over-perfection-inspirational#reviews)

4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Designed by [ArrieDesignCo](https://www.etsy.com/shop/ArrieDesignCo)

- Digital download


- Digital file type(s): 5 JPG


This "Progress Over Perfection" wall art quote is the perfect addition to your home office, art studio, workspace or home gym.

🔸DIGITAL DOWNLOAD🔸

Printable art is an easy, affordable way to decorate your space. Simply download, print and hang!

🔸HOW TO PRINT🔸

1\. Use an online photo service or print shop, like Shutterfly or Walgreens. Make as many prints as you’d like, on anything you’d like (photo, poster, canvas, pillows, mugs, etc.)

-OR-

2\. Print at home using a reliable printer and card stock or photo paper.

🔸WHAT'S INCLUDED🔸

5 high quality JPG files (300 dpi) of different aspect ratios that can be printed at the sizes below:

– 2:3 ratio (4x6, 8x12, 12x18, 16x24, 20x30, 24x36)

– 4:5 ratio (4x5, 8x10, 16x20)

– 5:7 ratio (A1, A2, A3, A4, A5, 5x7)

– 11:14 ratio (11x14)

– 8x10 actual size, for easy at-home printing

🔸PLEASE NOTE🔸

– This purchase is for a digital download. NO PHYSICAL ITEM IS SHIPPED.

– Colors may vary slightly due to different monitor settings. Final print quality will depend on the printer and paper used.

– Any textures used in the artwork are intentional.

– Artwork position may vary slightly between different aspect ratios to ensure the best fit.

– This purchase is for PERSONAL USE ONLY. Commercial use is prohibited. The designs are Copyright ©ArrieDesignCo. They are not permitted to be shared, copied, reproduced or resold.

Thank you for viewing this listing! For more designs, visit [https://www.etsy.com/shop/ArrieDesignCo](https://www.etsy.com/shop/ArrieDesignCo)

Progress Over Perfection Inspirational Office Print, Minimalist Home Office Decor, Positive Affirmation Poster, Motivational Typography Art


## Delivery

Instant Download

Your files will be available to download once payment is confirmed.
[Here's how.](https://www.etsy.com/help/article/3949)

Instant download items don’t accept returns, exchanges or cancellations. Please contact the seller about any problems with your order.

## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

## Reviews for this item (3)

Loading


5 out of 5 stars
5

This item

[Katherine Litrocapes](https://www.etsy.com/people/katherine12l?ref=l_review)
Oct 7, 2024


Simple, but perfect! Thank you!



[Katherine Litrocapes](https://www.etsy.com/people/katherine12l?ref=l_review)
Oct 7, 2024


![](https://i.etsystatic.com/iusa/9e98de/95308640/iusa_75x75.95308640_95tj.jpg?version=0)

Response from LK

You’re very welcome Katherine! Thank you for your review 🧡



5 out of 5 stars
5

This item

[khanstevon](https://www.etsy.com/people/khanstevon?ref=l_review)
Apr 25, 2024


Good product and nice service.



[khanstevon](https://www.etsy.com/people/khanstevon?ref=l_review)
Apr 25, 2024


![](https://i.etsystatic.com/iusa/9e98de/95308640/iusa_75x75.95308640_95tj.jpg?version=0)

Response from LK

Thank you for your purchase! 🧡



5 out of 5 stars
5

This item

[stacilynn127](https://www.etsy.com/people/stacilynn127?ref=l_review)
Aug 23, 2023


[stacilynn127](https://www.etsy.com/people/stacilynn127?ref=l_review)
Aug 23, 2023


![](https://i.etsystatic.com/iusa/9e98de/95308640/iusa_75x75.95308640_95tj.jpg?version=0)

Response from LK

🧡🧡🧡



[![ArrieDesignCo](https://i.etsystatic.com/iusa/9e98de/95308640/iusa_75x75.95308640_95tj.jpg?version=0)](https://www.etsy.com/shop/ArrieDesignCo?ref=shop_profile&listing_id=1463731889)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[ArrieDesignCo](https://www.etsy.com/shop/ArrieDesignCo?ref=shop_profile&listing_id=1463731889)

[Owned by LK](https://www.etsy.com/shop/ArrieDesignCo?ref=shop_profile&listing_id=1463731889) \|

Chicago, Illinois

5.0
(111)


1.1k sales

3 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=661605706&referring_id=1463731889&referring_type=listing&recipient_id=661605706&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo2NjE2MDU3MDY6MTc2Mjc3MjEyMzphNTQxMjJmY2MxYzUzYjYxMjVjN2E2MmQ1ODY3MTEwYw%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1463731889%2Fprogress-over-perfection-inspirational)

This seller usually responds **within a few hours.**

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/ArrieDesignCo?ref=lp_mys_mfts)

- [![Progress Over Perfection Print, Inspirational Wall Art, Home Office Decor, Positivity Quote, Motivational Prints, Printable DIGITAL DOWNLOAD](https://i.etsystatic.com/36702753/c/2542/2018/216/543/il/f13be0/5223723233/il_340x270.5223723233_jxvr.jpg)\\
\\
Digital download\\
\\
\\
**Progress Over Perfection Print, Inspirational Wall Art, Home Office Decor, Positivity Quote, Motivational Prints, Printable DIGITAL DOWNLOAD**\\
\\
$4.50\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1541906687/progress-over-perfection-print?click_key=a3cb1c19c878c849800ed62dae31b8f5%3ALTe587a0b617dc2d9f3e0cc31d3d93e7100ba78e10&click_sum=d00315b1&ls=r&ref=related-1&sts=1&dd=1&content_source=a3cb1c19c878c849800ed62dae31b8f5%253ALTe587a0b617dc2d9f3e0cc31d3d93e7100ba78e10 "Progress Over Perfection Print, Inspirational Wall Art, Home Office Decor, Positivity Quote, Motivational Prints, Printable DIGITAL DOWNLOAD")




Add to Favorites


- [![Yes You Can Printable Wall Art, Motivational Quotes, Office Decor, Gym Decor, Workout Motivation, Inspiring Wall Art Quote, DIGITAL DOWNLOAD](https://i.etsystatic.com/36702753/c/2542/2020/217/554/il/b0aa26/4898721416/il_340x270.4898721416_if2x.jpg)\\
\\
Digital download\\
\\
\\
**Yes You Can Printable Wall Art, Motivational Quotes, Office Decor, Gym Decor, Workout Motivation, Inspiring Wall Art Quote, DIGITAL DOWNLOAD**\\
\\
$4.50\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1480297485/yes-you-can-printable-wall-art?click_key=a3cb1c19c878c849800ed62dae31b8f5%3ALTb28219c55e86923a2d63aeaac67652fde23968b7&click_sum=4b7947ba&ls=r&ref=related-2&sts=1&dd=1&content_source=a3cb1c19c878c849800ed62dae31b8f5%253ALTb28219c55e86923a2d63aeaac67652fde23968b7 "Yes You Can Printable Wall Art, Motivational Quotes, Office Decor, Gym Decor, Workout Motivation, Inspiring Wall Art Quote, DIGITAL DOWNLOAD")




Add to Favorites


- [![Done Is Better Than Perfect Print, Inspirational Wall Art Printable, Home Office Decor, Motivational Quote Print, DIGITAL DOWNLOAD](https://i.etsystatic.com/36702753/c/1724/1369/125/353/il/22333b/6147584243/il_340x270.6147584243_k5wh.jpg)\\
\\
Digital download\\
\\
\\
**Done Is Better Than Perfect Print, Inspirational Wall Art Printable, Home Office Decor, Motivational Quote Print, DIGITAL DOWNLOAD**\\
\\
$4.50\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1756078847/done-is-better-than-perfect-print?click_key=a3cb1c19c878c849800ed62dae31b8f5%3ALTa81b863d5f4d16e8f124617bdf25c79f958d0652&click_sum=9b29c987&ls=r&ref=related-3&sts=1&dd=1&content_source=a3cb1c19c878c849800ed62dae31b8f5%253ALTa81b863d5f4d16e8f124617bdf25c79f958d0652 "Done Is Better Than Perfect Print, Inspirational Wall Art Printable, Home Office Decor, Motivational Quote Print, DIGITAL DOWNLOAD")




Add to Favorites


- [![Abstract Sky Wall Art, Sunset Photography Print, Clouds Poster, Warm Decor, Bedroom Decor, Geometric Printable Art, DIGITAL DOWNLOAD](https://i.etsystatic.com/36702753/c/1724/1369/127/359/il/0227e9/6106236608/il_340x270.6106236608_lj3s.jpg)\\
\\
Digital download\\
\\
\\
**Abstract Sky Wall Art, Sunset Photography Print, Clouds Poster, Warm Decor, Bedroom Decor, Geometric Printable Art, DIGITAL DOWNLOAD**\\
\\
$4.75\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1743383602/abstract-sky-wall-art-sunset-photography?click_key=f0cfb8af61da1ac97eb42ba11ae146a368feb6b8%3A1743383602&click_sum=48b84992&ref=related-4&sts=1&dd=1 "Abstract Sky Wall Art, Sunset Photography Print, Clouds Poster, Warm Decor, Bedroom Decor, Geometric Printable Art, DIGITAL DOWNLOAD")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Sep 17, 2025


[112 favorites](https://www.etsy.com/listing/1463731889/progress-over-perfection-inspirational/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?explicit=1&ref=breadcrumb_listing) [Prints](https://www.etsy.com/c/art-and-collectibles/prints?explicit=1&ref=breadcrumb_listing) [Digital Prints](https://www.etsy.com/c/art-and-collectibles/prints/digital-prints?explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Necklaces

[Cat On Moon Locket for Sale](https://www.etsy.com/market/cat_on_moon_locket)

Paper

[Halloween Challenges for Sale](https://www.etsy.com/market/halloween_challenges)

Personal Care

[Shop Chief Mask](https://www.etsy.com/market/chief_mask)

Prints

[Keep In Perspective for Sale](https://www.etsy.com/market/keep_in_perspective) [Massage Therapist's Prayer Wall Art - Home](https://www.etsy.com/listing/1501768876/massage-therapists-prayer-wall-art-home) [Modern Coffee Cocktail Wall Art](https://www.etsy.com/listing/4344125402/java-rush-espresso-martini-print-modern) [Angel Oil Print Pastel Pink Wall Art Spiritual Guardian Artwork Heavenly Impasto Painting Nursery Wall Decor](https://www.etsy.com/listing/1872483264/angel-oil-print-pastel-pink-wall-art) [Leon Giran-Max : Woman in a Poppy Field - Giclee Fine Art Print](https://www.etsy.com/listing/1677132643/leon-giran-max-woman-in-a-poppy-field) [Ash Gildan 18000 Flat Lay Mockup Ash Grey Flatlay Mockup Sweatshirt Gildan 18000 Folded Mockup Ash Gray Lay Flat Sweatshirt Mockup Aesthetic by TheGroovyMocks](https://www.etsy.com/listing/1566542284/ash-gildan-18000-flat-lay-mockup-ash) [Funny Summer Skeleton Clipart by OchnaStudio](https://www.etsy.com/listing/1701474288/hot-ghoul-summer-png-funny-summer) [Buy Zion Hand Painted Online](https://www.etsy.com/market/zion_hand_painted) [Mark Rothko Print by RondoPrints](https://www.etsy.com/listing/1863574708/mark-rothko-print-orange-yellow-vintage)

Gender Neutral Adult Clothing

[Buy 90s Seattle Mariners Online](https://www.etsy.com/market/90s_seattle_mariners) [Chicken Nugs Mama's Hugs Sweatshirt - Gender-Neutral Adult Clothing](https://www.etsy.com/listing/1450479939/chicken-nugs-mamas-hugs-sweatshirt-funny)

Shopping

[Minelli France for Sale](https://www.etsy.com/market/minelli_france)

Keychains & Lanyards

[Buy Ffxiv Job Crystal Online](https://www.etsy.com/market/ffxiv_job_crystal)

Electronics Cases

[Cat phone case by CollinIdeas](https://www.etsy.com/listing/1834091946/funny-phone-case-for-iphone-16-15-14-13)

Pouches & Coin Purses

[Small Padded Bag by NerdyandFurry](https://www.etsy.com/listing/1389412120/small-padded-bag)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1463731889%2Fprogress-over-perfection-inspirational&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc3MjEyMzozOWVhYWNjYzAxMGUzY2I1YzI5MTg5MWEyMDM1ZTVkNQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1463731889%2Fprogress-over-perfection-inspirational) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1463731889/progress-over-perfection-inspirational#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1463731889%2Fprogress-over-perfection-inspirational)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![May include: A framed print with the text 'PROGRESS - OVER - PERFECTION' in black text on a white background. The print is framed in a light brown wood frame and is sitting on a light brown wood floor. The text 'arrie design co' and 'DIGITAL DOWNLOAD' is in the bottom right corner of the print.](https://i.etsystatic.com/36702753/c/1994/1994/460/118/il/3f8141/4827862456/il_300x300.4827862456_44xz.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/progress-perfection_n8g4br.jpg)

- ![Progress Over Perfection Inspirational Office Art Print, Minimalist Home Office Decor, Positive Affirmation Poster, Motivational Typography image 2](https://i.etsystatic.com/36702753/r/il/b8cac4/4112637252/il_300x300.4112637252_p271.jpg)
- ![Progress Over Perfection Inspirational Office Art Print, Minimalist Home Office Decor, Positive Affirmation Poster, Motivational Typography image 3](https://i.etsystatic.com/36702753/r/il/c36931/4193729709/il_300x300.4193729709_20be.jpg)
- ![May include: A wooden frame with a white card inside that reads 'PROGRESS OVER PERFECTION'. A light gray ceramic mug is on a wooden coaster next to the frame.](https://i.etsystatic.com/36702753/r/il/4c2ea0/4827818614/il_300x300.4827818614_5kdv.jpg)
- ![May include: A white desk with a wooden top and two white drawers. On the desk is a black keyboard, a black camera, a potted plant, a black and silver computer monitor, a black laptop, and a framed print with the text 'PROGRESS OVER PERFECTION' in black letters. There is also a framed print with a geometric design and a framed print with the text 'CREATE' in black letters.](https://i.etsystatic.com/36702753/r/il/91084c/4876078327/il_300x300.4876078327_n1kp.jpg)
- ![May include: A framed print with the text 'PROGRESS -OVER- PERFECTION' on a light beige background. The print is sitting on a light brown wooden bench with a woven rattan top. There are three books stacked on top of the print. A white ceramic vase and a brown ceramic vase are on the bench.](https://i.etsystatic.com/36702753/r/il/73d948/4827818606/il_300x300.4827818606_fel3.jpg)
- ![May include: A black framed poster with white text that reads 'PROGRESS -OVER- PERFECTION' hanging on a white wall. A small green plant is in a black pot on the left side of the image. A cactus is in a white pot on the right side of the image. A white table with a black bench and two pink chairs are in the foreground.](https://i.etsystatic.com/36702753/r/il/5ca1c4/4876078321/il_300x300.4876078321_jh5m.jpg)
- ![May include: A white computer monitor with a black frame displaying a website with a grid of colorful images. The monitor is on a desk with a plant in a terracotta pot to the left. Above the monitor are three framed pictures, one with a mirror, one with a colorful illustration of a tree and a building, and one with a colorful illustration of a woman. To the right of the monitor is a white wire grid with several cards with colorful illustrations and text. One card has the text 'Progress over Perfection'.](https://i.etsystatic.com/36702753/r/il/884f76/4876078355/il_300x300.4876078355_9qsg.jpg)
- ![May include: White card with black text on a wooden background with green leaves. The text reads 'PROGRESS OVER PERFECTION.'](https://i.etsystatic.com/36702753/r/il/7141e9/4827818620/il_300x300.4827818620_awuk.jpg)