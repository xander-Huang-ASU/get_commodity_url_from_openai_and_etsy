[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/85555104/sterling-silver-hammered-hoop-earrings#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Jewelry](https://www.etsy.com/c/jewelry?explicit=1&ref=catnav_breadcrumb-0)
- [Earrings](https://www.etsy.com/c/jewelry/earrings?explicit=1&ref=catnav_breadcrumb-1)
- [Hoop Earrings](https://www.etsy.com/c/jewelry/earrings/hoop-earrings?explicit=1&ref=catnav_breadcrumb-2)


Add to Favorites


- ![May include: Two silver hoop earrings, one slightly larger than the other, on a gray textured surface.](https://i.etsystatic.com/5334318/r/il/e61542/284190227/il_794xN.284190227.jpg)
- ![May include: Two silver hoop earrings. The hoops are simple and have a smooth, polished finish.](https://i.etsystatic.com/5334318/r/il/6271fa/284313806/il_794xN.284313806.jpg)
- ![May include: Two silver hoop earrings with a hammered finish. The earrings are simple and elegant, and would be a great addition to any jewelry collection.](https://i.etsystatic.com/5334318/r/il/67e3e0/284313984/il_794xN.284313984.jpg)
- ![May include: Two silver hoop earrings, one inside the other, measured against a white tape measure with black markings. The tape measure reads '19' and '21'.](https://i.etsystatic.com/5334318/r/il/eb2887/284190529/il_794xN.284190529.jpg)

- ![May include: Two silver hoop earrings, one slightly larger than the other, on a gray textured surface.](https://i.etsystatic.com/5334318/r/il/e61542/284190227/il_75x75.284190227.jpg)
- ![May include: Two silver hoop earrings. The hoops are simple and have a smooth, polished finish.](https://i.etsystatic.com/5334318/r/il/6271fa/284313806/il_75x75.284313806.jpg)
- ![May include: Two silver hoop earrings with a hammered finish. The earrings are simple and elegant, and would be a great addition to any jewelry collection.](https://i.etsystatic.com/5334318/r/il/67e3e0/284313984/il_75x75.284313984.jpg)
- ![May include: Two silver hoop earrings, one inside the other, measured against a white tape measure with black markings. The tape measure reads '19' and '21'.](https://i.etsystatic.com/5334318/r/il/eb2887/284190529/il_75x75.284190529.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F85555104%2Fsterling-silver-hammered-hoop-earrings%23report-overlay-trigger)

Only 5 left and in 1 cart

Price:$34.95+


Loading


# Sterling Silver Hammered Hoop Earrings, Handmade Classic Hoops Jewelry Gift

[ArtistiKat](https://www.etsy.com/shop/ArtistiKat?ref=shop-header-name&listing_id=85555104&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/85555104/sterling-silver-hammered-hoop-earrings#reviews)

Ships from Tennessee

Arrives soon! Get it by

Nov 13-18


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Size


Select an option

.75 inches ($34.95)

1 inches ($35.95)

1.25 inches ($36.95)

1.50 inches ($38.95)

1.75 inches ($40.95)

2 inches ($42.95)

Please select an option


You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Item details

### Highlights

Made by [ArtistiKat](https://www.etsy.com/shop/ArtistiKat)

- Ships from Tennessee! Shorter shipping distances are

kinder to the planet

Ordering items closer to you is more likely to reduce your purchase's carbon footprint.


- Materials: 18 gauge sterling silver wire

- Gift wrapping available


Hammered Silver Hoop Earrings, eco friendly sterling silver hoops.

Silver hoop earrings handmade from 18 gauge sterling silver wire; hammered for strength and to emphasize the curve of the hoop. Then lightly sanded and buffed to shine and smooth the edges for comfort.

These hoops are from sturdy 18 gauge solid sterling silver wire. If you have tiny or brand new piercings, I'd recommend a slightly thinner 20 gauge hoop. See link below.

Choose your size. Options are from 3/4 inch (.75 inch) hoops to 2 inch diameter hoops.

Photo shows the 1 inch diameter hoop.

Prefer a lighter weight hoop? Check out my 20 gauge hoops here: [http://www.etsy.com/listing/91928551/silver-hoop-earrings-20-gauge-sterling](http://www.etsy.com/listing/91928551/reserved-for-jill-custom-sterling-silver)

\\* Your silver hoop earrings will arrive nicely boxed and ready for gift giving.

For more gift ideas for a loved one or for yourself:

[http://www.etsy.com/shop/ArtistiKat](http://www.etsy.com/shop/ArtistiKat)

Thanks for shopping hand made this holiday season.

;D

PLEASE read shop policies prior to purchasing.


## Shipping and return policies

Loading


- Order today to get by

**Nov 13-18**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges not accepted




But please contact me if you have problems with your order


- Ships from: **Erwin, TN**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## FAQs

Are VAT and customs fees included in the price?


I am a US seller, not VAT registered and cannot by law collect VAT or duties. All pricing is minus VAT, customs fees or duties. If your country charges VAT, duties or delivery fees, these are the buyers responsibility. Please check with your local postal authorities for estimates of any additional costs you may have when importing from the US


## Reviews for this item (13)

5.0/5

item average

5.0Item quality

5.0Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Love it

Very well made

Fast shipping

Beautiful

Cute

Dainty

Gorgeous


Filter by category


Quality (6)


Shipping & Packaging (2)


Appearance (1)


Sizing & Fit (1)


Value (1)


Description accuracy (1)


Seller service (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[rideknightly](https://www.etsy.com/people/rideknightly?ref=l_review)
Sep 2, 2025


Very cute earrings. They are sturdy but they look delicate with no bulky hinge to see. Very nice!



[rideknightly](https://www.etsy.com/people/rideknightly?ref=l_review)
Sep 2, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/47a13e/82425431/iusa_75x75.82425431_o1bf.jpg?version=0)

[lars](https://www.etsy.com/people/allwaysbrown?ref=l_review)
Sep 17, 2023


Gorgeous hoops!!



![](https://i.etsystatic.com/iusa/47a13e/82425431/iusa_75x75.82425431_o1bf.jpg?version=0)

[lars](https://www.etsy.com/people/allwaysbrown?ref=l_review)
Sep 17, 2023


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/908b75/97416267/iusa_75x75.97416267_fi8u.jpg?version=0)

[Joe Colucci](https://www.etsy.com/people/joecolucci?ref=l_review)
Feb 15, 2020


Silver hoop earrings that are made well. My significant other loves the simplicity and size. I score major points with these.



![](https://i.etsystatic.com/iusa/908b75/97416267/iusa_75x75.97416267_fi8u.jpg?version=0)

[Joe Colucci](https://www.etsy.com/people/joecolucci?ref=l_review)
Feb 15, 2020


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/a263cb/81476180/iusa_75x75.81476180_mgpp.jpg?version=0)

[El González](https://www.etsy.com/people/elliegonzalez18?ref=l_review)
Sep 20, 2018


fave earrings ever, thank you so much



![](https://i.etsystatic.com/iusa/a263cb/81476180/iusa_75x75.81476180_mgpp.jpg?version=0)

[El González](https://www.etsy.com/people/elliegonzalez18?ref=l_review)
Sep 20, 2018


View all reviews for this item

[![ArtistiKat](https://i.etsystatic.com/iusa/c3384f/40254271/iusa_75x75.40254271_bsvo.jpg?version=0)](https://www.etsy.com/shop/ArtistiKat?ref=shop_profile&listing_id=85555104)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[ArtistiKat](https://www.etsy.com/shop/ArtistiKat?ref=shop_profile&listing_id=85555104)

[Owned by ArtistiKat](https://www.etsy.com/shop/ArtistiKat?ref=shop_profile&listing_id=85555104) \|

Erwin, Tennessee

4.8
(2.3k)


10.8k sales

17 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=6078917&referring_id=85555104&referring_type=listing&recipient_id=6078917&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo2MDc4OTE3OjE3NjI3Nzc1ODQ6ZjMyNDRkMzcwYmNkYjFiY2E5YWJlNzkwYjNhNTEzMTQ%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F85555104%2Fsterling-silver-hammered-hoop-earrings)

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

Loading recommendations

Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 2, 2025


[328 favorites](https://www.etsy.com/listing/85555104/sterling-silver-hammered-hoop-earrings/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Jewelry](https://www.etsy.com/c/jewelry?explicit=1&ref=breadcrumb_listing) [Earrings](https://www.etsy.com/c/jewelry/earrings?explicit=1&ref=breadcrumb_listing) [Hoop Earrings](https://www.etsy.com/c/jewelry/earrings/hoop-earrings?explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Canvas & Surfaces

[Buy Seamless Wildflower Pattern Svg Online](https://www.etsy.com/market/seamless_wildflower_pattern_svg) [High Heel Template - US](https://www.etsy.com/market/high_heel_template)

Hats & Caps

[Luxury Handmade British Sheepskin Shearling Hat - The "Katy" - Hats & Caps](https://www.etsy.com/listing/386682900/luxury-handmade-british-sheepskin)

Gender Neutral Adult Clothing

[Vintage Core Concepts Surf Sweatshirt Back Print Sweatshirt Crewneck - Gender-Neutral Adult Clothing](https://www.etsy.com/listing/1805463515/vintage-core-concepts-surf-sweatshirt)

Earrings

[14k Yellow Gold Braided Hoop Earrings - Earrings](https://www.etsy.com/listing/827248534/14k-yellow-gold-braided-hoop-earrings) [Cow Print Clay Earrings](https://www.etsy.com/listing/1027918313/cow-print-clay-earrings) [23mm - Charlotte Gold - Vintage Gold Gift For Loved Ones 375 9k by CharlotteGoldJewelry](https://www.etsy.com/listing/4306516091/vintage-9ct-gold-twisted-hoop-earrings) [Valentines Heart Candy Earrings - US](https://www.etsy.com/market/valentines_heart_candy_earrings)

Scarves & Wraps

[Fanta Eyes polka dot 44x70 Scarf Wrap Bathing suit Sarong - Scarves & Wraps](https://www.etsy.com/listing/1140064202/fanta-eyes-polka-dot-44x70-scarf-wrap)

Kitchen & Dining

[Yoga Poses Cookie Cutters Relaxation by BakeDo](https://www.etsy.com/listing/1601644945/yoga-poses-cookie-cutters-relaxation)

Shopping

[Stream Deck Icons Genshin - US](https://www.etsy.com/market/stream_deck_icons_genshin)

Tools & Equipment

[Leather Burnishing Stick Double Sided Sander paper Sanding Sticks 180mm x 20mm 7pcs A Pack by CraftSupprise](https://www.etsy.com/listing/488862551/leather-burnishing-stick-double-sided)

Handbags

[Buy Skull And Roses Purse Strap Online](https://www.etsy.com/market/skull_and_roses_purse_strap)

Toys

[Buy Sun Lovin Malibu Pj Online](https://www.etsy.com/market/sun_lovin_malibu_pj)

Home Decor

[Handmade Crochet Flower Decoration by lailaleighcrochet](https://www.etsy.com/listing/1696253209/handmade-crochet-flower-decoration)

Painting

[Very Rare Ceiling Tin Tile Thistle Art Nouveau 135 yrs old Ceramic Glazed Historical Fragment Lori Daniels Art Cottage Majolica. by TinExpressions](https://www.etsy.com/listing/235929633/very-rare-ceiling-tin-tile-thistle-art)

Prints

[Minnie Daisy Clipart - US](https://www.etsy.com/market/minnie_daisy_clipart)

Car Parts & Accessories

[Ford Tailgate Badge for Sale](https://www.etsy.com/market/ford_tailgate_badge)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F85555104%2Fsterling-silver-hammered-hoop-earrings&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc3NzU4NDowMGI2MTkzYTljYWU0YWUwM2VkNWEzOTdmZTJiOTI4Nw==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F85555104%2Fsterling-silver-hammered-hoop-earrings) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/85555104/sterling-silver-hammered-hoop-earrings#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F85555104%2Fsterling-silver-hammered-hoop-earrings)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for ArtistiKat

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 24 hours of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: Two silver hoop earrings, one slightly larger than the other, on a gray textured surface.](https://i.etsystatic.com/5334318/r/il/e61542/284190227/il_300x300.284190227.jpg)
- ![May include: Two silver hoop earrings. The hoops are simple and have a smooth, polished finish.](https://i.etsystatic.com/5334318/r/il/6271fa/284313806/il_300x300.284313806.jpg)
- ![May include: Two silver hoop earrings with a hammered finish. The earrings are simple and elegant, and would be a great addition to any jewelry collection.](https://i.etsystatic.com/5334318/r/il/67e3e0/284313984/il_300x300.284313984.jpg)
- ![May include: Two silver hoop earrings, one inside the other, measured against a white tape measure with black markings. The tape measure reads '19' and '21'.](https://i.etsystatic.com/5334318/r/il/eb2887/284190529/il_300x300.284190529.jpg)