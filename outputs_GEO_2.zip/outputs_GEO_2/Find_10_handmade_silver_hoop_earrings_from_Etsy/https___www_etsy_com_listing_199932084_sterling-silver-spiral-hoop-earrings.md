[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/199932084/sterling-silver-spiral-hoop-earrings#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Jewelry](https://www.etsy.com/c/jewelry?explicit=1&ref=catnav_breadcrumb-0)
- [Earrings](https://www.etsy.com/c/jewelry/earrings?explicit=1&ref=catnav_breadcrumb-1)
- [Hoop Earrings](https://www.etsy.com/c/jewelry/earrings/hoop-earrings?explicit=1&ref=catnav_breadcrumb-2)


Add to Favorites


- ![May include: Two silver hoop earrings with a spiral design. The earrings are simple and elegant.](https://i.etsystatic.com/5616016/r/il/653eb1/2763099021/il_794xN.2763099021_e13n.jpg)
- ![May include: Two silver hoop earrings with a spiral design. The earrings are on a white surface.](https://i.etsystatic.com/5616016/r/il/0c80d7/2715438068/il_794xN.2715438068_a8uh.jpg)
- ![May include: Two silver spiral hoop earrings. The earrings are made of thin wire and are shaped like a spiral. The earrings are hanging from a white surface.](https://i.etsystatic.com/5616016/r/il/bb2ce0/2763119401/il_794xN.2763119401_2crv.jpg)
- ![May include: Silver spiral hoop earrings. The earrings are approximately 7/8 inch in diameter. The earrings are shown on a model's ear and next to a ruler for size reference.](https://i.etsystatic.com/5616016/r/il/0bac23/2763098599/il_794xN.2763098599_acha.jpg)
- ![May include: Wire Details: 20 Gauge (Standard Piercing) Sterling Silver earrings. The ends of the earrings that pass through the ear have been filed smooth. A pair of rubber stoppers and a small polishing cloth are included with each pair of earrings. Also available in Niobium (see listing description for a link).](https://i.etsystatic.com/5616016/r/il/865929/2763118899/il_794xN.2763118899_tob8.jpg)
- ![Sterling Silver Spiral Hoop Earrings, Handmade in USA image 6](https://i.etsystatic.com/5616016/r/il/3d71b8/2763101091/il_794xN.2763101091_sjyk.jpg)

- ![May include: Two silver hoop earrings with a spiral design. The earrings are simple and elegant.](https://i.etsystatic.com/5616016/r/il/653eb1/2763099021/il_75x75.2763099021_e13n.jpg)
- ![May include: Two silver hoop earrings with a spiral design. The earrings are on a white surface.](https://i.etsystatic.com/5616016/c/1875/1491/312/352/il/0c80d7/2715438068/il_75x75.2715438068_a8uh.jpg)
- ![May include: Two silver spiral hoop earrings. The earrings are made of thin wire and are shaped like a spiral. The earrings are hanging from a white surface.](https://i.etsystatic.com/5616016/c/3000/2384/0/410/il/bb2ce0/2763119401/il_75x75.2763119401_2crv.jpg)
- ![May include: Silver spiral hoop earrings. The earrings are approximately 7/8 inch in diameter. The earrings are shown on a model's ear and next to a ruler for size reference.](https://i.etsystatic.com/5616016/r/il/0bac23/2763098599/il_75x75.2763098599_acha.jpg)
- ![May include: Wire Details: 20 Gauge (Standard Piercing) Sterling Silver earrings. The ends of the earrings that pass through the ear have been filed smooth. A pair of rubber stoppers and a small polishing cloth are included with each pair of earrings. Also available in Niobium (see listing description for a link).](https://i.etsystatic.com/5616016/r/il/865929/2763118899/il_75x75.2763118899_tob8.jpg)
- ![Sterling Silver Spiral Hoop Earrings, Handmade in USA image 6](https://i.etsystatic.com/5616016/r/il/3d71b8/2763101091/il_75x75.2763101091_sjyk.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F199932084%2Fsterling-silver-spiral-hoop-earrings%23report-overlay-trigger)

Low in stock, only 3 left

Price:$25.00


Loading


# Sterling Silver Spiral Hoop Earrings, Handmade in USA

[wearever](https://www.etsy.com/shop/wearever?ref=shop-header-name&listing_id=199932084&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/199932084/sterling-silver-spiral-hoop-earrings#reviews)

Arrives soon! Get it by

Nov 14-21


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Item details

### Highlights

Made by [wearever](https://www.etsy.com/shop/wearever)

- Materials: Silver

- Location: Earlobe

- Closure: Ear wire

- Style: Minimalist

- Gift wrapping available

See details![](https://i.etsystatic.com/igwp/2b93c2/1624360902/igwp_300xN.1624360902_ls02uclp.jpg?version=0)

Gift wrapping by wearever

Silver jewelry tin with a black satin bow (instead of the wearever label). A small purple notecard will be tucked under the bow.

Each hand formed sterling silver spiral earring has been lightly hammered for strength and polished to shine. These simple swirls are quite versatile and great for everyday wear!

This is one of my most popular styles of earring; as each pair is hand formed, they may vary slightly.

Earring Length/Diameter ▾ approx. 7/8 inches (2.2 cm)

Wire Gauge ▾ 20 gauge (standard piercing), sterling silver

As with all of my earrings, the end that passes through the ear has been filed smooth. I also include a pair of rubber stoppers for each pair of earrings, and a small sterling silver polishing cloth.

This style is also available in niobium wire:

[https://www.etsy.com/listing/905007656/niobium-spiral-earrings-small?ref=shop\_home\_active\_1](https://www.etsy.com/listing/905007656/niobium-spiral-earrings-small?ref=shop_home_active_1)

## Shipping and return policies

Loading


- Order today to get by

**Nov 14-21**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 14 days


- Ships from: **Poulsbo, WA**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaJapanNew ZealandSingaporeUnited States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## FAQs

What metal is used in wearever pieces?


The majority of wearever pieces are made of sterling silver (.925).

For my bright sterling silver pieces, I offer Sunshine Small Polishing Cloths ($2.00)...this option can be chosen prior to adding an item to your cart. All sterling silver dulls/tarnishes over time; these cloths help you to keep your silver bright!

I also offer most of my earring styles in Niobium for those with skin sensitivities who require hypoallergenic options. If you do not see the bead color option that you would like with Niobium, please contact me and I will be happy to create a listing for you.


Custom and Personalized Orders


Find a piece of jewelry that you would prefer to have in bright silver versus oxidized (darkened) silver? Or prefer a different color bead for a particular piece? Contact me to request a custom order...if I have more of the bead in stock, I will be happy to customize a piece for you.

If you would like multiples of a particular piece, please contact me as well. I normally order my beads in large quantities. Most likely, I will be able to create a custom listing for you in the quantity that you desire.


How will my jewelry be packaged? Do you offer gift wrapping?


I package all jewelry with gift-giving in mind (for yourself as well as for others). In an effort to conserve packing materials, I will combine items in the same tin when appropriate. (For an example of my packaging, please see the last photo in many of my listings.)

If you are gifting your purchase and prefer to have each item boxed separately, please leave me a note in the "notes to seller" section upon checkout.

I also offer a minimalist style of gift wrapping...more information, including a photo, is available on individual listing pages. This option can be chosen prior to checkout.


Is there a charge for shipping additional items in the same order?


No...shipping on additional items (to the same address) from wearever.etsy.com is always free. Take a look around before checkout and save on shipping.


Does wearever collect VAT, customs fees, or other international taxes?


I am located in the USA, and am not legally authorized to collect international customs fees, taxes or VAT fees. These are the sole responsibility of the customer, based on the laws of the country/region in which they reside.

Additionally, all international orders are sent marked as merchandise and declared at the full purchase value, even those for which the buyer has selected "mark as gift". (Although the recipient may be receiving the item as a gift from the purchaser, it is still merchandise purchased from wearever.) The purchase price is required to appear on the customs form/shipping label, regardless of whether "mark as gift" has been selected. (https://pe.usps.com/text/imm/immc1\_009.htm)


## Meet your seller

![Jen](https://i.etsystatic.com/5616016/r/isla/b3d2e9/32046206/isla_75x75.32046206_fobc1nsb.jpg)

Jen

Owner of [wearever](https://www.etsy.com/shop/wearever?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo3ODEwOTY5OjE3NjI3Nzc2NDU6YWIwNTBhYTU4ZTA1NDEzNGYzOGI5YWExZTNhYzU1ZTI%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F199932084%2Fsterling-silver-spiral-hoop-earrings)

[Message Jen](https://www.etsy.com/messages/new?with_id=7810969&referring_id=199932084&referring_type=listing&recipient_id=7810969&from_action=contact-seller)

This seller usually responds **within 24 hours.**

## Reviews for this item (16)

Loading


Buyer highlights, summarized by AI

Lightweight

Love it

Fast shipping

Adorable

Comfortable

Exactly what I wanted

Great quality


Filter by category


Comfort (4)


Quality (5)


Appearance (3)


Shipping & Packaging (3)


Seller service (1)


Sizing & Fit (1)


Description accuracy (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Mary Senecal](https://www.etsy.com/people/thulina55?ref=l_review)
Oct 27, 2024


The earrings are delicate and pretty, just what I was looking for.



[Mary Senecal](https://www.etsy.com/people/thulina55?ref=l_review)
Oct 27, 2024


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/70a9f3/47250376/iusa_75x75.47250376_7y5a.jpg?version=0)

[Carrie](https://www.etsy.com/people/carrieslevin1?ref=l_review)
Oct 30, 2020


I put these adorable and lightweight earrings on immediately. Love them ! And thank you for the cleaning cloth. They are so well-made and comfortable. Have ordered in the past from this seller and will order again.



![](https://i.etsystatic.com/iusa/70a9f3/47250376/iusa_75x75.47250376_7y5a.jpg?version=0)

[Carrie](https://www.etsy.com/people/carrieslevin1?ref=l_review)
Oct 30, 2020


4 out of 5 stars
4

This item

![](https://i.etsystatic.com/iusa/ba041b/106038310/iusa_75x75.106038310_gpqo.jpg?version=0)

[8q4tqgmz](https://www.etsy.com/people/8q4tqgmz?ref=l_review)
Oct 18, 2020


If you like light earrings, you'll like these.



![](https://i.etsystatic.com/iusa/ba041b/106038310/iusa_75x75.106038310_gpqo.jpg?version=0)

[8q4tqgmz](https://www.etsy.com/people/8q4tqgmz?ref=l_review)
Oct 18, 2020


5 out of 5 stars
5

This item

Reviewed by Inactive
Jun 13, 2020


Absolutely perfect!



Reviewed by Inactive
Jun 13, 2020


View all reviews for this item

### Photos from reviews

![knedeau added a photo of their purchase](https://i.etsystatic.com/iap/42d73f/2008686524/iap_300x300.2008686524_75iwecv7.jpg?version=0)

[![wearever](https://i.etsystatic.com/iusa/a6ddb7/83049198/iusa_75x75.83049198_e5qq.jpg?version=0)](https://www.etsy.com/shop/wearever?ref=shop_profile&listing_id=199932084)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[wearever](https://www.etsy.com/shop/wearever?ref=shop_profile&listing_id=199932084)

[Owned by Jen](https://www.etsy.com/shop/wearever?ref=shop_profile&listing_id=199932084) \|

Poulsbo, Washington

4.9
(1k)


3.1k sales

16 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=7810969&referring_id=199932084&referring_type=listing&recipient_id=7810969&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo3ODEwOTY5OjE3NjI3Nzc2NDU6YWIwNTBhYTU4ZTA1NDEzNGYzOGI5YWExZTNhYzU1ZTI%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F199932084%2Fsterling-silver-spiral-hoop-earrings)

This seller usually responds **within 24 hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

Loading recommendations

Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Oct 21, 2025


[358 favorites](https://www.etsy.com/listing/199932084/sterling-silver-spiral-hoop-earrings/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Jewelry](https://www.etsy.com/c/jewelry?explicit=1&ref=breadcrumb_listing) [Earrings](https://www.etsy.com/c/jewelry/earrings?explicit=1&ref=breadcrumb_listing) [Hoop Earrings](https://www.etsy.com/c/jewelry/earrings/hoop-earrings?explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Canvas & Surfaces

[Casino Mode On Svg for cricut - Canvas & Surfaces](https://www.etsy.com/listing/1447615181/casino-mode-on-svg-for-cricut-jackpot)

Earrings

[Shop Clay Leather Earring](https://www.etsy.com/market/clay_leather_earring) [Transcendence Earrings by JennergyLove](https://www.etsy.com/listing/1841884690/transcendence-earrings) [Small Silver Hoop Earrings with Green Jade / Huggies](https://www.etsy.com/listing/1107189969/small-silver-hoop-earrings-with-green) [Golden Yellow and Brown Wood Flower Dangle Earrings - Chevron Design - Lightweight - Nickel Free](https://www.etsy.com/listing/1615723832/golden-yellow-and-brown-wood-flower) [Circus Tent Ring - US](https://www.etsy.com/market/circus_tent_ring)

Shopping

[Shop Demon's Servant](https://www.etsy.com/market/demon%27s_servant) [Buy Bowl Of Cherries Tee Online](https://www.etsy.com/market/bowl_of_cherries_tee) [Buy Farm Field Landscape Svg Online](https://www.etsy.com/market/farm_field_landscape_svg)

Home Decor

[Shop Home Decor from VintageBodacious](https://www.etsy.com/shop/VintageBodacious)

Pens Pencils & Marking Tools

[Shop Moka Pen](https://www.etsy.com/market/moka_pen)

Beads Gems & Cabochons

[Pasty vintage silver charm or pendant - Funny - Novelty - Food by TheVintageCoopUK](https://www.etsy.com/listing/1694220743/pasty-vintage-silver-charm-or-pendant)

Paints Inks & Dyes

[Amy Howard at Home Toscana Milk Paint](https://www.etsy.com/listing/4349278038/amy-howard-at-home-toscana-milk-paint)

Prints

[Oversized Canvas Art Not Printed for Sale](https://www.etsy.com/market/oversized_canvas_art_not_printed)

Books

[Military Tank - Coloring Page - Kids Teens Adults - Printable PDF - Instant Download - Military Army Navy Coast Guard by MilitaryCraftStudio](https://www.etsy.com/listing/1469526768/military-tank-coloring-page-kids-teens) [Vintage Calligraphy Books - US](https://www.etsy.com/market/vintage_calligraphy_books)

Spirituality & Religion

[Buy No Communication Oracle Online](https://www.etsy.com/market/no_communication_oracle)

Paper

[Buy Romantic Dirty Partner Card Online](https://www.etsy.com/market/romantic_dirty_partner_card)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F199932084%2Fsterling-silver-spiral-hoop-earrings&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2Mjc3NzY0NTo5MzBhZTFmMDE5YWI1YTk3MzA1MmQzMjcwM2E1NmJiOQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F199932084%2Fsterling-silver-spiral-hoop-earrings) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/199932084/sterling-silver-spiral-hoop-earrings#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F199932084%2Fsterling-silver-spiral-hoop-earrings)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for wearever

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 1 hour of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: Two silver hoop earrings with a spiral design. The earrings are simple and elegant.](https://i.etsystatic.com/5616016/r/il/653eb1/2763099021/il_300x300.2763099021_e13n.jpg)
- ![May include: Two silver hoop earrings with a spiral design. The earrings are on a white surface.](https://i.etsystatic.com/5616016/c/1875/1875/312/160/il/0c80d7/2715438068/il_300x300.2715438068_a8uh.jpg)
- ![May include: Two silver spiral hoop earrings. The earrings are made of thin wire and are shaped like a spiral. The earrings are hanging from a white surface.](https://i.etsystatic.com/5616016/c/3000/3000/0/0/il/bb2ce0/2763119401/il_300x300.2763119401_2crv.jpg)
- ![May include: Silver spiral hoop earrings. The earrings are approximately 7/8 inch in diameter. The earrings are shown on a model's ear and next to a ruler for size reference.](https://i.etsystatic.com/5616016/r/il/0bac23/2763098599/il_300x300.2763098599_acha.jpg)
- ![May include: Wire Details: 20 Gauge (Standard Piercing) Sterling Silver earrings. The ends of the earrings that pass through the ear have been filed smooth. A pair of rubber stoppers and a small polishing cloth are included with each pair of earrings. Also available in Niobium (see listing description for a link).](https://i.etsystatic.com/5616016/r/il/865929/2763118899/il_300x300.2763118899_tob8.jpg)
- ![Sterling Silver Spiral Hoop Earrings, Handmade in USA image 6](https://i.etsystatic.com/5616016/r/il/3d71b8/2763101091/il_300x300.2763101091_sjyk.jpg)

- ![](https://i.etsystatic.com/iap/42d73f/2008686524/iap_640x640.2008686524_75iwecv7.jpg?version=0)











5 out of 5 stars



Received very quickly. Great quality. Very dainty. Just what I was looking for.


















Sep 14, 2019




[knedeau](https://www.etsy.com/people/knedeau)













Purchased item:

[![Sterling Silver Spiral Hoop Earrings, Handmade in USA](https://i.etsystatic.com/5616016/r/il/653eb1/2763099021/il_170x135.2763099021_e13n.jpg)\\
\\
Sterling Silver Spiral Hoop Earrings, Handmade in USA\\
\\
$25.00](https://www.etsy.com/listing/199932084/sterling-silver-spiral-hoop-earrings?ref=ap-listing)





Purchased item:

[![Sterling Silver Spiral Hoop Earrings, Handmade in USA](https://i.etsystatic.com/5616016/r/il/653eb1/2763099021/il_170x135.2763099021_e13n.jpg)\\
\\
Sterling Silver Spiral Hoop Earrings, Handmade in USA\\
\\
$25.00](https://www.etsy.com/listing/199932084/sterling-silver-spiral-hoop-earrings?ref=ap-listing)