[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1674667164/mothers-day-gift-for-mom-from-daughter?amp;click_sum=ae6602ff&amp;ls=a&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=Show+10+personalized+birthstone+earrings+on+Etsy&amp;ref=search_grid-726877-1-2&amp;sr_prefetch=1&amp;pf_from=search&amp;pro=1&amp;frs=1&amp;sts=1&amp;nob=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Jewelry](https://www.etsy.com/c/jewelry?amp%3Bclick_sum=ae6602ff&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Show+10+personalized+birthstone+earrings+on+Etsy&%3Bref=search_grid-726877-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bfrs=1&%3Bsts=1&%3Bnob=1&explicit=1&ref=catnav_breadcrumb-0)
- [Earrings](https://www.etsy.com/c/jewelry/earrings?amp%3Bclick_sum=ae6602ff&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Show+10+personalized+birthstone+earrings+on+Etsy&%3Bref=search_grid-726877-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bfrs=1&%3Bsts=1&%3Bnob=1&explicit=1&ref=catnav_breadcrumb-1)
- [Dangle & Drop Earrings](https://www.etsy.com/c/jewelry/earrings/dangle-earrings?amp%3Bclick_sum=ae6602ff&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Show+10+personalized+birthstone+earrings+on+Etsy&%3Bref=search_grid-726877-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bfrs=1&%3Bsts=1&%3Bnob=1&explicit=1&ref=catnav_breadcrumb-2)


Add to Favorites


- ![Birth Stone Earrings](https://i.etsystatic.com/38011619/r/il/514150/5808916000/il_794xN.5808916000_l603.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![Birthstone Colors](https://i.etsystatic.com/38011619/r/il/07d5f7/5807611094/il_794xN.5807611094_t8cb.jpg)
- ![Birthstone Earrings](https://i.etsystatic.com/38011619/r/il/927747/5856998121/il_794xN.5856998121_523i.jpg)
- ![Custom Mom Gift](https://i.etsystatic.com/38011619/r/il/b1763b/5856999601/il_794xN.5856999601_qbqh.jpg)
- ![Family Birthstone Earrings](https://i.etsystatic.com/38011619/r/il/f0c9d1/5808916902/il_794xN.5808916902_2oi8.jpg)
- ![Gift for Mom](https://i.etsystatic.com/38011619/r/il/653c4b/5808917666/il_794xN.5808917666_8akn.jpg)
- ![Mom Gift](https://i.etsystatic.com/38011619/r/il/245a8d/5808918238/il_794xN.5808918238_rozv.jpg)
- ![Mothers Day Gift](https://i.etsystatic.com/38011619/r/il/fd039b/5857002725/il_794xN.5857002725_1gdd.jpg)
- ![Mothers Gifts](https://i.etsystatic.com/38011619/r/il/00bd1c/5857003111/il_794xN.5857003111_l1m6.jpg)
- ![May include: Elegant gold earrings featuring three vibrant gemstones: a rich red garnet, a captivating purple amethyst, and a sparkling light blue gemstone.  The gemstones are arranged vertically on a delicate gold chain, creating a stylish and eye-catching design. These dangle earrings are perfect for adding a touch of color and sophistication to any outfit.](https://i.etsystatic.com/38011619/r/il/1da135/5808919574/il_794xN.5808919574_btop.jpg)

- ![Birth Stone Earrings](https://i.etsystatic.com/38011619/r/il/514150/5808916000/il_75x75.5808916000_l603.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/ZUMRAKolyeDogumTasiKupe_zstye2.jpg)

- ![Birthstone Colors](https://i.etsystatic.com/38011619/r/il/07d5f7/5807611094/il_75x75.5807611094_t8cb.jpg)
- ![Birthstone Earrings](https://i.etsystatic.com/38011619/r/il/927747/5856998121/il_75x75.5856998121_523i.jpg)
- ![Custom Mom Gift](https://i.etsystatic.com/38011619/r/il/b1763b/5856999601/il_75x75.5856999601_qbqh.jpg)
- ![Family Birthstone Earrings](https://i.etsystatic.com/38011619/r/il/f0c9d1/5808916902/il_75x75.5808916902_2oi8.jpg)
- ![Gift for Mom](https://i.etsystatic.com/38011619/r/il/653c4b/5808917666/il_75x75.5808917666_8akn.jpg)
- ![Mom Gift](https://i.etsystatic.com/38011619/r/il/245a8d/5808918238/il_75x75.5808918238_rozv.jpg)
- ![Mothers Day Gift](https://i.etsystatic.com/38011619/r/il/fd039b/5857002725/il_75x75.5857002725_1gdd.jpg)
- ![Mothers Gifts](https://i.etsystatic.com/38011619/r/il/00bd1c/5857003111/il_75x75.5857003111_l1m6.jpg)
- ![May include: Elegant gold earrings featuring three vibrant gemstones: a rich red garnet, a captivating purple amethyst, and a sparkling light blue gemstone.  The gemstones are arranged vertically on a delicate gold chain, creating a stylish and eye-catching design. These dangle earrings are perfect for adding a touch of color and sophistication to any outfit.](https://i.etsystatic.com/38011619/r/il/1da135/5808919574/il_75x75.5808919574_btop.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1674667164%2Fmothers-day-gift-for-mom-from-daughter%23report-overlay-trigger)

In 17 carts

Price:$22.80+


Original Price:
$38.00+


Loading


**New markdown!**

40% off


•

Limited time sale


# Mothers Day Gift for Mom From Daughter - Family Birthstone Earrings - Mothers Gift from Daughter - Birthstone Earrings - Custom Mom Gift

[ZumraJewels](https://www.etsy.com/shop/ZumraJewels?ref=shop-header-name&listing_id=1674667164&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[4.5 out of 5 stars](https://www.etsy.com/listing/1674667164/mothers-day-gift-for-mom-from-daughter?amp;click_sum=ae6602ff&amp;ls=a&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=Show+10+personalized+birthstone+earrings+on+Etsy&amp;ref=search_grid-726877-1-2&amp;sr_prefetch=1&amp;pf_from=search&amp;pro=1&amp;frs=1&amp;sts=1&amp;nob=1#reviews)

Arrives soon! Get it by

Nov 13-22


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

Number of Your Favourite Birthstones


Select an option

1 Stone ($22.80)

2 Stones ($28.80)

3 Stones ($34.80)

4 Stones ($37.20)

5 Stones ($40.20)

6 Stones ($43.20)

7 Birthstones ($46.20)

8 Birthstones ($49.80)

9 Birthstones ($52.20)

10 Birthstones ($55.20)

11 Birthstones ($58.20)

Please select an option


Finish


Select an option

925 Sterling Silver

14K Gold Filled

14K Rose Gold Filled

Please select an option


Add personalization


- Personalization





Please type your favourite month(s) in order:

January

February

March

April

May

June

July

August

September

October

November

December


















0/256


4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Item details

### Highlights

Designed by [ZumraJewels](https://www.etsy.com/shop/ZumraJewels)

- Materials: Silver

- Sustainable features: recycled metal. Items may include additional materials or use methods that aren't considered sustainable features on our site. [Learn more](https://help.etsy.com/hc/articles/15532793357847)

- Gemstone: Cubic zirconia

- Location: Earlobe

- Style: Minimalist

- Can be personalized

- Recycled

- Made to Order


- Gift wrapping available

See details

Gift wrapping by ZumraJewels

Your order will be delivered with a branded gift box. Ready to present straightaway!

BIRTHSTONE EARRINGS

Add a touch of sparkle to your gift-giving with these gorgeous Handcrafted Family Birthstone Earrings. Each pair is individually handmade with love, care, and attention to detail.

These beautiful earrings shine with the brilliance of meticulously selected birthstones, intertwined within a sturdy, tarnish-free framework. A bespoke symbol of your family's unique lineage, the stones represent the birth months of your cherished ones, making each pair truly one of a kind. A treasured keepsake, these earrings make a thoughtful and meaningful gift, whether you're celebrating a special occasion or simply expressing your love.

Your elegantly packaged earrings also come with an option for personal customization. Express your love and appreciation with this timeless gift, perfect for treasuring precious moments and celebrating the beautiful journey of life.

✨ Why Choose Zumra Jewels?

✅ Waterproof Jewelry so that You can wear in the shower or swim with.

✅ Heat and Sweat Proof so that You can wear in the gym.

✅ Tarnish Free so that You can carry the shine all the time.

✅ Free Delivery so that you can enjoy Free Shipping without paying Extra.

✅ 1-2 Days production time so that you can receive your order faster.

✨ How to Order?

1- Choose Your preferred material and length,

2- Choose The total number of birthstones you want to add,

3- Type the desired months in the Personalization Box,

✨ Product Details

-Great Material : The product is authentic and %100 925 Sterling Silver, 14K Gold Filled and 14K Yellow Real Solid Gold.

-Great Packing: All Zumra Jewels pieces are delivered with solid gift box ready to present

-Communication: Our friendly and fast customer service members are ready to help during your purchasing process as well as after sale!

-Easy ordering: Etsy offers quite easy and straightforward ordering process, that is why we love to bring our products on this platform to meet you!

-Flawless Delivery: Our production team works very hard to please you with your order, therefore you will receive your order flawless and so your delivery. If you have any issue at any stage please contact us. Your order will be delivered by USPS and you will receive confirmation email with tracking code from Etsy.

\- Production Process: Your order will be produced within 1 business day and it might take up to 2 days in off peak season, we appreciate your consideration.

\- Return: We will be pleased to accept return or cancellations, however due to nature of the products personalized items can not be returned unless it is our own fault.

\+ Chain Sizes:

14 inches (36 cm) - Age 5 years or Under

16 inches (41 cm) - Age 6-18 years

18 inches (46 cm) - Ideal and popular size for women

20 inches (51 cm)

22 inches (56


### Production partners

ZumraJewels makes this item with help from


Edi Jewelry, NJ, United States


## Shipping and return policies

Loading


- Order today to get by

**Nov 13-22**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 14 days


- Free shipping


- Ships from: **North Bergen, NJ**


Deliver to United States

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## FAQs

Custom and personalized orders


Please make sure you choose the right font when you place your order. All personalized items carefully handcrafted to please you utmost!


Sizing details


We offer different sizes for each item from 14" to 22". Please also check necklace size chart in each listing to avoid disappointment.


Care instructions


Each of our jewel pieces are made of genuine materials. We carefully source the best quality of raw materials which won't tarnish, not harm your skin, and you can put it on daily. Please make sure you follow care instructions we offer in each listing to have your jewels for a long lasting keepsake!


Gift wrapping and packaging


Each piece of Zumra Jewels comes in a branded gift box and

complimentary ribbon-tied gift bag. We also add a gift message if requested. We do not include receipt or invoice in the package!


How long does the production take?


Personalized items are produced within 2 business days. We are dedicated to make you happy by producing as fast as possible.


How fast can i receive my order?


We offer FREE shipping for US Orders. Once we made your item, It will be handed over to USPS and will be delivered between 3-5 days.


Can i cancel my order?


If you need to cancel or make a change to your order, please reach us asap within 3 hours of placing order.


## Meet your seller

![ZUMRA JEWELS](https://i.etsystatic.com/38011619/r/isla/6722a8/58497683/isla_75x75.58497683_v12i2vmm.jpg)

ZUMRA JEWELS

Owner of [ZumraJewels](https://www.etsy.com/shop/ZumraJewels?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo2OTM5Mjk5MDc6MTc2MjgxNzY1NzphYTgzYWJlZjIxYzAzMGI1N2MyYTU3NWIwMGRhZGU3Mw%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1674667164%2Fmothers-day-gift-for-mom-from-daughter%3Famp%253Bclick_sum%3Dae6602ff%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DShow%2B10%2Bpersonalized%2Bbirthstone%2Bearrings%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-726877-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bfrs%3D1%26amp%253Bsts%3D1%26amp%253Bnob%3D1)

[Message ZUMRA](https://www.etsy.com/messages/new?with_id=693929907&referring_id=1674667164&referring_type=listing&recipient_id=693929907&from_action=contact-seller)

This seller usually responds **within a few hours.**

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (101)

4.6/5

item average

4.6Item quality

4.6Shipping

4.6Customer service

89%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Beautiful

Love it

Gift-worthy

Fast shipping

Great product

As described

Excellent customer service


Filter by category


Appearance (33)


Quality (23)


Shipping & Packaging (21)


Seller service (15)


Description accuracy (14)


Value (5)


Comfort (2)


Sizing & Fit (2)


Ease of use (2)


Condition (2)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/4c5432/41906932/iusa_75x75.41906932_bpmo.jpg?version=0)

[dmjohnson514](https://www.etsy.com/people/dmjohnson514?ref=l_review)
Sep 24, 2025


Bought these for my daughter in law, and she really liked them, especially the fact that they are the birthstones of her children :)



![](https://i.etsystatic.com/iusa/4c5432/41906932/iusa_75x75.41906932_bpmo.jpg?version=0)

[dmjohnson514](https://www.etsy.com/people/dmjohnson514?ref=l_review)
Sep 24, 2025


5 out of 5 stars
5

This item

[Diana](https://www.etsy.com/people/te1ezd90?ref=l_review)
Aug 23, 2025


Very pretty earrings with my parents birthstones. Nice size and lightweight.



[Diana](https://www.etsy.com/people/te1ezd90?ref=l_review)
Aug 23, 2025


5 out of 5 stars
5

This item

[pedspta](https://www.etsy.com/people/pedspta?ref=l_review)
Aug 9, 2025


Took forever but my daughter in law loves them!



[pedspta](https://www.etsy.com/people/pedspta?ref=l_review)
Aug 9, 2025


5 out of 5 stars
5

This item

[Jenna](https://www.etsy.com/people/jennaneto?ref=l_review)
Jul 24, 2025


I got these birthstone earrings for my mom for Mother’s Day. They had me and my siblings birthstones on them. She loved the gift!



[Jenna](https://www.etsy.com/people/jennaneto?ref=l_review)
Jul 24, 2025


View all reviews for this item

### Photos from reviews

![Briget added a photo of their purchase](https://i.etsystatic.com/iap/a6b222/6502856584/iap_300x300.6502856584_h0wbf3ip.jpg?version=0)

![CHRISTINA added a photo of their purchase](https://i.etsystatic.com/iap/e6b3c8/6575793471/iap_300x300.6575793471_oibhqf9d.jpg?version=0)

![Lauren added a photo of their purchase](https://i.etsystatic.com/iap/c61c68/6306646463/iap_300x300.6306646463_js8qrf2r.jpg?version=0)

![Beate added a photo of their purchase](https://i.etsystatic.com/iap/a1c5f2/6453816825/iap_300x300.6453816825_t911omiw.jpg?version=0)

![Jessica added a photo of their purchase](https://i.etsystatic.com/iap/649a75/6273613859/iap_300x300.6273613859_ge7mxjdl.jpg?version=0)

[![ZumraJewels](https://i.etsystatic.com/iusa/fba1b7/96197585/iusa_75x75.96197585_36dq.jpg?version=0)](https://www.etsy.com/shop/ZumraJewels?ref=shop_profile&listing_id=1674667164)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[ZumraJewels](https://www.etsy.com/shop/ZumraJewels?ref=shop_profile&listing_id=1674667164)

[Owned by ZUMRA JEWELS](https://www.etsy.com/shop/ZumraJewels?ref=shop_profile&listing_id=1674667164) \|

New Jersey, United States

4.7
(2.2k)


14k sales

3 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=693929907&referring_id=1674667164&referring_type=listing&recipient_id=693929907&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo2OTM5Mjk5MDc6MTc2MjgxNzY1NzphYTgzYWJlZjIxYzAzMGI1N2MyYTU3NWIwMGRhZGU3Mw%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1674667164%2Fmothers-day-gift-for-mom-from-daughter%3Famp%253Bclick_sum%3Dae6602ff%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DShow%2B10%2Bpersonalized%2Bbirthstone%2Bearrings%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-726877-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bfrs%3D1%26amp%253Bsts%3D1%26amp%253Bnob%3D1)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/ZumraJewels?ref=lp_mys_mfts)

- [![Mothers Day Gift for Grandma, Family Birthstone Earrings, Grandma Earrings, Mothers Gift from Daughter, Birthstone Earrings, Custom Mom Gift](https://i.etsystatic.com/38011619/r/il/514150/5808916000/il_340x270.5808916000_l603.jpg)\\
\\
**Mothers Day Gift for Grandma, Family Birthstone Earrings, Grandma Earrings, Mothers Gift from Daughter, Birthstone Earrings, Custom Mom Gift**\\
\\
Sale Price $21.00\\
$21.00\\
\\
$35.00\\
Original Price $35.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1721691485/mothers-day-gift-for-grandma-family?click_key=3c9ac0242923041c12c6f621665b06ef%3ALTc827d2a2435f0bc0cedd5805b382d7b6aff823e5&click_sum=6403fdd2&ls=r&ref=related-1&pro=1&sts=1&content_source=3c9ac0242923041c12c6f621665b06ef%253ALTc827d2a2435f0bc0cedd5805b382d7b6aff823e5 "Mothers Day Gift for Grandma, Family Birthstone Earrings, Grandma Earrings, Mothers Gift from Daughter, Birthstone Earrings, Custom Mom Gift")




Add to Favorites


- [![Mothers Day Gift for Mom From Daughter - Birthstone Earrings - Mothers Gift from Daughter - Family Birthstone Earrings - Custom Mom Gift](https://i.etsystatic.com/38011619/r/il/514150/5808916000/il_340x270.5808916000_l603.jpg)\\
\\
**Mothers Day Gift for Mom From Daughter - Birthstone Earrings - Mothers Gift from Daughter - Family Birthstone Earrings - Custom Mom Gift**\\
\\
Sale Price $21.00\\
$21.00\\
\\
$35.00\\
Original Price $35.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1720388115/mothers-day-gift-for-mom-from-daughter?click_key=3c9ac0242923041c12c6f621665b06ef%3ALT750f91da0abddfd1f5ceda7d3ad3d200736b2bf4&click_sum=6e784467&ls=r&ref=related-2&pro=1&sts=1&content_source=3c9ac0242923041c12c6f621665b06ef%253ALT750f91da0abddfd1f5ceda7d3ad3d200736b2bf4 "Mothers Day Gift for Mom From Daughter - Birthstone Earrings - Mothers Gift from Daughter - Family Birthstone Earrings - Custom Mom Gift")




Add to Favorites


- [![Birthstone Necklace - Mothers Day Gift for Mom - Childrens Birth Stones Necklace - Family Birthstone Necklace - Mom Gift - Personalized Gift](https://i.etsystatic.com/38011619/r/il/c8dcab/6386021254/il_340x270.6386021254_3ago.jpg)\\
\\
**Birthstone Necklace - Mothers Day Gift for Mom - Childrens Birth Stones Necklace - Family Birthstone Necklace - Mom Gift - Personalized Gift**\\
\\
Sale Price $23.40\\
$23.40\\
\\
$39.00\\
Original Price $39.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1802921050/birthstone-necklace-mothers-day-gift-for?click_key=3c9ac0242923041c12c6f621665b06ef%3ALT4ad0bbd9de412366f0569b8422959ed33d295344&click_sum=93bff2b8&ls=r&ref=related-3&pro=1&sts=1&content_source=3c9ac0242923041c12c6f621665b06ef%253ALT4ad0bbd9de412366f0569b8422959ed33d295344 "Birthstone Necklace - Mothers Day Gift for Mom - Childrens Birth Stones Necklace - Family Birthstone Necklace - Mom Gift - Personalized Gift")




Add to Favorites


- [![14K Gold Cross Bracelet - Dainty Cross Jewelry - Religious Bracelet - Cross Bracelet Women, Christian Gifts for Women - Communion Gift](https://i.etsystatic.com/38011619/c/1602/1273/568/417/il/8f79f6/4312890761/il_340x270.4312890761_7ovl.jpg)\\
\\
**14K Gold Cross Bracelet - Dainty Cross Jewelry - Religious Bracelet - Cross Bracelet Women, Christian Gifts for Women - Communion Gift**\\
\\
Sale Price $41.40\\
$41.40\\
\\
$69.00\\
Original Price $69.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1328234377/14k-gold-cross-bracelet-dainty-cross?click_key=c9cf96957bb4041bf79c53ef8f847d727f226f93%3A1328234377&click_sum=6300e9d1&ref=related-4&pro=1&sts=1 "14K Gold Cross Bracelet - Dainty Cross Jewelry - Religious Bracelet - Cross Bracelet Women, Christian Gifts for Women - Communion Gift")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 10, 2025


[591 favorites](https://www.etsy.com/listing/1674667164/mothers-day-gift-for-mom-from-daughter/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Jewelry](https://www.etsy.com/c/jewelry?amp%3Bclick_sum=ae6602ff&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Show+10+personalized+birthstone+earrings+on+Etsy&%3Bref=search_grid-726877-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bfrs=1&%3Bsts=1&%3Bnob=1&explicit=1&ref=breadcrumb_listing) [Earrings](https://www.etsy.com/c/jewelry/earrings?amp%3Bclick_sum=ae6602ff&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Show+10+personalized+birthstone+earrings+on+Etsy&%3Bref=search_grid-726877-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bfrs=1&%3Bsts=1&%3Bnob=1&explicit=1&ref=breadcrumb_listing) [Dangle & Drop Earrings](https://www.etsy.com/c/jewelry/earrings/dangle-earrings?amp%3Bclick_sum=ae6602ff&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Show+10+personalized+birthstone+earrings+on+Etsy&%3Bref=search_grid-726877-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bfrs=1&%3Bsts=1&%3Bnob=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Home Decor

[Petra Jordan Print Minimalist Home Travel Poster Wall Decor by kazaloop](https://www.etsy.com/listing/1028844586/petra-jordan-print-minimalist-home)

Earrings

[Buy Jessica Davis Online](https://www.etsy.com/market/jessica_davis) [Star Crystal Hoops - Earrings](https://www.etsy.com/listing/892755554/star-crystal-hoops) [Holiday Fair Isle Pattern Beaded Fringe Earrings by ATingeofFringe](https://www.etsy.com/listing/1612442656/holiday-fair-isle-pattern-beaded-fringe) [Buy Lord Helix Online](https://www.etsy.com/market/lord_helix)

Canvas & Surfaces

[Yellow Camouflage Seamless Background Pattern - Military Camo Digital Paper PNG - Digital Download Files](https://www.etsy.com/listing/1037152002/yellow-camouflage-seamless-background)

Bathroom

[Makeup Towel - US](https://www.etsy.com/market/makeup_towel)

Beads Gems & Cabochons

[Paper Beads-Tropical Leaves by MargabeadaGirl](https://www.etsy.com/listing/599601962/paper-beads-tropical-leaves)

Patches & Pins

[Mallard - Hat & Glasses Uv Printed Patches - Patches & Pins](https://www.etsy.com/listing/1860320582/mallard-hat-glasses-uv-printed-patches)

Games & Puzzles

[Century Golem Insert - US](https://www.etsy.com/market/century_golem_insert)

Collectibles

[Badge auto car German Rally Tour Club Grille plaque ADAC #2181 1980 Styraburg by RPMAUTOMOBILIA](https://www.etsy.com/listing/1891920822/badge-auto-car-german-rally-tour-club) [Larry Csonka Signed for Sale](https://www.etsy.com/market/larry_csonka_signed)

Shopping

[Gothic Doll Crib for Sale](https://www.etsy.com/market/gothic_doll_crib) [Mens Apron With Pockets for Sale](https://www.etsy.com/market/mens_apron_with_pockets)

Mens Clothing

[Hot Guy Bulge - US](https://www.etsy.com/market/hot_guy_bulge)

Rings

[Shop Antique Crystal Ring](https://www.etsy.com/market/antique_crystal_ring)

Jewelry

[1970s Les Bernard Rams Head Faux Pearl Necklace by TookeyBuxton](https://www.etsy.com/listing/1846525269/1970s-les-bernard-rams-head-faux-pearl)

Suit & Tie Accessories

[Black Floral Bow Tie](https://www.etsy.com/listing/1050517151/black-floral-bow-tie)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1674667164%2Fmothers-day-gift-for-mom-from-daughter%3Famp%253Bclick_sum%3Dae6602ff%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DShow%2B10%2Bpersonalized%2Bbirthstone%2Bearrings%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-726877-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bfrs%3D1%26amp%253Bsts%3D1%26amp%253Bnob%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgxNzY1Nzo2YzEyNDgzNTIyYjk3YjhhMGRmZDc4NThkNmFhMjRlNQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1674667164%2Fmothers-day-gift-for-mom-from-daughter%3Famp%253Bclick_sum%3Dae6602ff%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DShow%2B10%2Bpersonalized%2Bbirthstone%2Bearrings%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-726877-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bfrs%3D1%26amp%253Bsts%3D1%26amp%253Bnob%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1674667164/mothers-day-gift-for-mom-from-daughter?amp;click_sum=ae6602ff&amp;ls=a&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=Show+10+personalized+birthstone+earrings+on+Etsy&amp;ref=search_grid-726877-1-2&amp;sr_prefetch=1&amp;pf_from=search&amp;pro=1&amp;frs=1&amp;sts=1&amp;nob=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1674667164%2Fmothers-day-gift-for-mom-from-daughter%3Famp%253Bclick_sum%3Dae6602ff%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DShow%2B10%2Bpersonalized%2Bbirthstone%2Bearrings%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-726877-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bfrs%3D1%26amp%253Bsts%3D1%26amp%253Bnob%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for ZumraJewels

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 3 hours of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## Seller details

### Business registration number

### Location

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=693929907&referring_id=38011619&referring_type=shop&recipient_id=693929907&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![Birth Stone Earrings](https://i.etsystatic.com/38011619/r/il/514150/5808916000/il_300x300.5808916000_l603.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/ZUMRAKolyeDogumTasiKupe_zstye2.jpg)

- ![Birthstone Colors](https://i.etsystatic.com/38011619/r/il/07d5f7/5807611094/il_300x300.5807611094_t8cb.jpg)
- ![Birthstone Earrings](https://i.etsystatic.com/38011619/r/il/927747/5856998121/il_300x300.5856998121_523i.jpg)
- ![Custom Mom Gift](https://i.etsystatic.com/38011619/r/il/b1763b/5856999601/il_300x300.5856999601_qbqh.jpg)
- ![Family Birthstone Earrings](https://i.etsystatic.com/38011619/r/il/f0c9d1/5808916902/il_300x300.5808916902_2oi8.jpg)
- ![Gift for Mom](https://i.etsystatic.com/38011619/r/il/653c4b/5808917666/il_300x300.5808917666_8akn.jpg)
- ![Mom Gift](https://i.etsystatic.com/38011619/r/il/245a8d/5808918238/il_300x300.5808918238_rozv.jpg)
- ![Mothers Day Gift](https://i.etsystatic.com/38011619/r/il/fd039b/5857002725/il_300x300.5857002725_1gdd.jpg)
- ![Mothers Gifts](https://i.etsystatic.com/38011619/r/il/00bd1c/5857003111/il_300x300.5857003111_l1m6.jpg)
- ![May include: Elegant gold earrings featuring three vibrant gemstones: a rich red garnet, a captivating purple amethyst, and a sparkling light blue gemstone.  The gemstones are arranged vertically on a delicate gold chain, creating a stylish and eye-catching design. These dangle earrings are perfect for adding a touch of color and sophistication to any outfit.](https://i.etsystatic.com/38011619/r/il/1da135/5808919574/il_300x300.5808919574_btop.jpg)

- ![](https://i.etsystatic.com/iap/a6b222/6502856584/iap_640x640.6502856584_h0wbf3ip.jpg?version=0)

2 out of 5 stars

- Number of Your Favourite Birthstones:

3 Stones

- Finish:

14K Gold Filled


The quality is really nice and shipping was good. Unfortunately it looks like they didn't do the right stones I understand March and December are close but it looks like I got double March. So it's not correct. They are still nice.

![](https://i.etsystatic.com/iusa/26cd0c/88064450/iusa_75x75.88064450_gs9m.jpg?version=0)

Dec 13, 2024


[Briget Barnes](https://www.etsy.com/people/munhbkfg)

Purchased item:

[![Mothers Day Gift for Mom From Daughter - Family Birthstone Earrings - Mothers Gift from Daughter - Birthstone Earrings - Custom Mom Gift](https://i.etsystatic.com/38011619/r/il/514150/5808916000/il_170x135.5808916000_l603.jpg)\\
\\
Mothers Day Gift for Mom From Daughter - Family Birthstone Earrings - Mothers Gift from Daughter - Birthstone Earrings - Custom Mom Gift\\
\\
Sale Price $22.80\\
$22.80\\
\\
$38.00\\
Original Price $38.00\\
\\
\\
(40% off)](https://www.etsy.com/listing/1674667164/mothers-day-gift-for-mom-from-daughter?ref=ap-listing)

Purchased item:

[![Mothers Day Gift for Mom From Daughter - Family Birthstone Earrings - Mothers Gift from Daughter - Birthstone Earrings - Custom Mom Gift](https://i.etsystatic.com/38011619/r/il/514150/5808916000/il_170x135.5808916000_l603.jpg)\\
\\
Mothers Day Gift for Mom From Daughter - Family Birthstone Earrings - Mothers Gift from Daughter - Birthstone Earrings - Custom Mom Gift\\
\\
Sale Price $22.80\\
$22.80\\
\\
$38.00\\
Original Price $38.00\\
\\
\\
(40% off)](https://www.etsy.com/listing/1674667164/mothers-day-gift-for-mom-from-daughter?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/e6b3c8/6575793471/iap_640x640.6575793471_oibhqf9d.jpg?version=0)

5 out of 5 stars

- Number of Your Favourite Birthstones:

4 Stones

- Finish:

925 Sterling Silver


It's beautiful! My friend will love this for her birthday!
It took a few days longer than origanlly expected for shipping but it was the holiday and it is hard to estimate shipping during that time.

Dec 27, 2024


[CHRISTINA CUNDIFF](https://www.etsy.com/people/christinacundiff95)

Purchased item:

[![Mothers Day Gift for Mom From Daughter - Family Birthstone Earrings - Mothers Gift from Daughter - Birthstone Earrings - Custom Mom Gift](https://i.etsystatic.com/38011619/r/il/514150/5808916000/il_170x135.5808916000_l603.jpg)\\
\\
Mothers Day Gift for Mom From Daughter - Family Birthstone Earrings - Mothers Gift from Daughter - Birthstone Earrings - Custom Mom Gift\\
\\
Sale Price $22.80\\
$22.80\\
\\
$38.00\\
Original Price $38.00\\
\\
\\
(40% off)](https://www.etsy.com/listing/1674667164/mothers-day-gift-for-mom-from-daughter?ref=ap-listing)

Purchased item:

[![Mothers Day Gift for Mom From Daughter - Family Birthstone Earrings - Mothers Gift from Daughter - Birthstone Earrings - Custom Mom Gift](https://i.etsystatic.com/38011619/r/il/514150/5808916000/il_170x135.5808916000_l603.jpg)\\
\\
Mothers Day Gift for Mom From Daughter - Family Birthstone Earrings - Mothers Gift from Daughter - Birthstone Earrings - Custom Mom Gift\\
\\
Sale Price $22.80\\
$22.80\\
\\
$38.00\\
Original Price $38.00\\
\\
\\
(40% off)](https://www.etsy.com/listing/1674667164/mothers-day-gift-for-mom-from-daughter?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/c61c68/6306646463/iap_640x640.6306646463_js8qrf2r.jpg?version=0)

5 out of 5 stars

- Number of Your Favourite Birthstones:

3 Stones

- Finish:

925 Sterling Silver


Perfect gift for my sister in law!! Exactly as described

![](https://i.etsystatic.com/iusa/adc6e5/80524655/iusa_75x75.80524655_45yz.jpg?version=0)

Sep 8, 2024


[Lauren](https://www.etsy.com/people/4soe0rny)

Purchased item:

[![Mothers Day Gift for Mom From Daughter - Family Birthstone Earrings - Mothers Gift from Daughter - Birthstone Earrings - Custom Mom Gift](https://i.etsystatic.com/38011619/r/il/514150/5808916000/il_170x135.5808916000_l603.jpg)\\
\\
Mothers Day Gift for Mom From Daughter - Family Birthstone Earrings - Mothers Gift from Daughter - Birthstone Earrings - Custom Mom Gift\\
\\
Sale Price $22.80\\
$22.80\\
\\
$38.00\\
Original Price $38.00\\
\\
\\
(40% off)](https://www.etsy.com/listing/1674667164/mothers-day-gift-for-mom-from-daughter?ref=ap-listing)

Purchased item:

[![Mothers Day Gift for Mom From Daughter - Family Birthstone Earrings - Mothers Gift from Daughter - Birthstone Earrings - Custom Mom Gift](https://i.etsystatic.com/38011619/r/il/514150/5808916000/il_170x135.5808916000_l603.jpg)\\
\\
Mothers Day Gift for Mom From Daughter - Family Birthstone Earrings - Mothers Gift from Daughter - Birthstone Earrings - Custom Mom Gift\\
\\
Sale Price $22.80\\
$22.80\\
\\
$38.00\\
Original Price $38.00\\
\\
\\
(40% off)](https://www.etsy.com/listing/1674667164/mothers-day-gift-for-mom-from-daughter?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/a1c5f2/6453816825/iap_640x640.6453816825_t911omiw.jpg?version=0)

5 out of 5 stars

- Number of Your Favourite Birthstones:

4 Stones

- Finish:

14K Gold Filled


The earrings look great
and exactly as described. Any questions were answered very quickly. Highly recommended.

See in original language


Translated by Google


Die Ohrringe sehen toll aus
und genau wie beschrieben. Bei Fragen wurde sehr schnell geantwortet. Sehr zu empfehlen.


![](https://i.etsystatic.com/iusa/b64098/111528294/iusa_75x75.111528294_gvrc.jpg?version=0)

Nov 5, 2024


[Beate](https://www.etsy.com/people/q0de4aeg1gusayru)

Purchased item:

[![Mothers Day Gift for Mom From Daughter - Family Birthstone Earrings - Mothers Gift from Daughter - Birthstone Earrings - Custom Mom Gift](https://i.etsystatic.com/38011619/r/il/514150/5808916000/il_170x135.5808916000_l603.jpg)\\
\\
Mothers Day Gift for Mom From Daughter - Family Birthstone Earrings - Mothers Gift from Daughter - Birthstone Earrings - Custom Mom Gift\\
\\
Sale Price $22.80\\
$22.80\\
\\
$38.00\\
Original Price $38.00\\
\\
\\
(40% off)](https://www.etsy.com/listing/1674667164/mothers-day-gift-for-mom-from-daughter?ref=ap-listing)

Purchased item:

[![Mothers Day Gift for Mom From Daughter - Family Birthstone Earrings - Mothers Gift from Daughter - Birthstone Earrings - Custom Mom Gift](https://i.etsystatic.com/38011619/r/il/514150/5808916000/il_170x135.5808916000_l603.jpg)\\
\\
Mothers Day Gift for Mom From Daughter - Family Birthstone Earrings - Mothers Gift from Daughter - Birthstone Earrings - Custom Mom Gift\\
\\
Sale Price $22.80\\
$22.80\\
\\
$38.00\\
Original Price $38.00\\
\\
\\
(40% off)](https://www.etsy.com/listing/1674667164/mothers-day-gift-for-mom-from-daughter?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/649a75/6273613859/iap_640x640.6273613859_ge7mxjdl.jpg?version=0)

5 out of 5 stars

- Number of Your Favourite Birthstones:

3 Stones

- Finish:

925 Sterling Silver


These turned out absolutely perfect! Such beautiful quality. This is a gift for my mother for my wedding, birthstones are for my late grandma, uncle & aunt.

![](https://i.etsystatic.com/iusa/73fb4f/106911236/iusa_75x75.106911236_t5wc.jpg?version=0)

Aug 26, 2024


[Jessica Burciaga](https://www.etsy.com/people/jburciaga93)

Purchased item:

[![Mothers Day Gift for Mom From Daughter - Family Birthstone Earrings - Mothers Gift from Daughter - Birthstone Earrings - Custom Mom Gift](https://i.etsystatic.com/38011619/r/il/514150/5808916000/il_170x135.5808916000_l603.jpg)\\
\\
Mothers Day Gift for Mom From Daughter - Family Birthstone Earrings - Mothers Gift from Daughter - Birthstone Earrings - Custom Mom Gift\\
\\
Sale Price $22.80\\
$22.80\\
\\
$38.00\\
Original Price $38.00\\
\\
\\
(40% off)](https://www.etsy.com/listing/1674667164/mothers-day-gift-for-mom-from-daughter?ref=ap-listing)

Purchased item:

[![Mothers Day Gift for Mom From Daughter - Family Birthstone Earrings - Mothers Gift from Daughter - Birthstone Earrings - Custom Mom Gift](https://i.etsystatic.com/38011619/r/il/514150/5808916000/il_170x135.5808916000_l603.jpg)\\
\\
Mothers Day Gift for Mom From Daughter - Family Birthstone Earrings - Mothers Gift from Daughter - Birthstone Earrings - Custom Mom Gift\\
\\
Sale Price $22.80\\
$22.80\\
\\
$38.00\\
Original Price $38.00\\
\\
\\
(40% off)](https://www.etsy.com/listing/1674667164/mothers-day-gift-for-mom-from-daughter?ref=ap-listing)