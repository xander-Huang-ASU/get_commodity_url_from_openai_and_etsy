[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1268756258/handmade-hydrangea-real-flower-resin?amp;click_sum=a0d03a73&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;pro=1&amp;sts=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Jewelry](https://www.etsy.com/c/jewelry?amp%3Bclick_sum=a0d03a73&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bpro=1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-0)
- [Earrings](https://www.etsy.com/c/jewelry/earrings?amp%3Bclick_sum=a0d03a73&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bpro=1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-1)
- [Stud Earrings](https://www.etsy.com/c/jewelry/earrings/stud-earrings?amp%3Bclick_sum=a0d03a73&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bpro=1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-2)

Etsy’s Pick

Etsy’s Picks are hand selected by our style experts to highlight items from shops that have shown quality, reliability and style.

[Discover More](https://www.etsy.com/featured/hub/etsy-picks?ref=listing_etsys_pick_signal)


Add to Favorites


- ![May include: Two blue flower earrings with white pearl centers. The earrings are displayed on a white surface.](https://i.etsystatic.com/21371013/r/il/bcf5fc/4068207948/il_794xN.4068207948_rixk.jpg)
- ![May include: Two pairs of blue flower earrings. Each earring is made of a single blue flower with a white center. The flowers are delicate and have a translucent appearance.](https://i.etsystatic.com/21371013/r/il/c88e31/4068207950/il_794xN.4068207950_a83f.jpg)
- ![May include: A pair of blue flower stud earrings with silver posts and clear backs](https://i.etsystatic.com/21371013/r/il/55fad0/4115857701/il_794xN.4115857701_oewn.jpg)
- ![May include: A pair of blue flower stud earrings.](https://i.etsystatic.com/21371013/r/il/211769/4609603020/il_794xN.4609603020_3ec1.jpg)
- ![Handmade Hydrangea Real Flower Resin Stud Earrings| Light Blue Red Green Flower Statement Earrings| 925 Sterling Silver Flower Earrings image 5](https://i.etsystatic.com/21371013/r/il/b0da27/6996908951/il_794xN.6996908951_c4rc.jpg)
- ![Handmade Hydrangea Real Flower Resin Stud Earrings| Light Blue Red Green Flower Statement Earrings| 925 Sterling Silver Flower Earrings image 6](https://i.etsystatic.com/21371013/r/il/5f1b47/6948958012/il_794xN.6948958012_5xob.jpg)
- ![Handmade Hydrangea Real Flower Resin Stud Earrings| Light Blue Red Green Flower Statement Earrings| 925 Sterling Silver Flower Earrings image 7](https://i.etsystatic.com/21371013/r/il/448169/6948958022/il_794xN.6948958022_24zd.jpg)
- ![Handmade Hydrangea Real Flower Resin Stud Earrings| Light Blue Red Green Flower Statement Earrings| 925 Sterling Silver Flower Earrings image 8](https://i.etsystatic.com/21371013/r/il/da0219/6948958024/il_794xN.6948958024_4v7n.jpg)
- ![Handmade Hydrangea Real Flower Resin Stud Earrings| Light Blue Red Green Flower Statement Earrings| 925 Sterling Silver Flower Earrings image 9](https://i.etsystatic.com/21371013/r/il/b04604/6996925887/il_794xN.6996925887_crny.jpg)

- ![May include: Two blue flower earrings with white pearl centers. The earrings are displayed on a white surface.](https://i.etsystatic.com/21371013/r/il/bcf5fc/4068207948/il_75x75.4068207948_rixk.jpg)
- ![May include: Two pairs of blue flower earrings. Each earring is made of a single blue flower with a white center. The flowers are delicate and have a translucent appearance.](https://i.etsystatic.com/21371013/r/il/c88e31/4068207950/il_75x75.4068207950_a83f.jpg)
- ![May include: A pair of blue flower stud earrings with silver posts and clear backs](https://i.etsystatic.com/21371013/r/il/55fad0/4115857701/il_75x75.4115857701_oewn.jpg)
- ![May include: A pair of blue flower stud earrings.](https://i.etsystatic.com/21371013/r/il/211769/4609603020/il_75x75.4609603020_3ec1.jpg)
- ![Handmade Hydrangea Real Flower Resin Stud Earrings| Light Blue Red Green Flower Statement Earrings| 925 Sterling Silver Flower Earrings image 5](https://i.etsystatic.com/21371013/r/il/b0da27/6996908951/il_75x75.6996908951_c4rc.jpg)
- ![Handmade Hydrangea Real Flower Resin Stud Earrings| Light Blue Red Green Flower Statement Earrings| 925 Sterling Silver Flower Earrings image 6](https://i.etsystatic.com/21371013/r/il/5f1b47/6948958012/il_75x75.6948958012_5xob.jpg)
- ![Handmade Hydrangea Real Flower Resin Stud Earrings| Light Blue Red Green Flower Statement Earrings| 925 Sterling Silver Flower Earrings image 7](https://i.etsystatic.com/21371013/r/il/448169/6948958022/il_75x75.6948958022_24zd.jpg)
- ![Handmade Hydrangea Real Flower Resin Stud Earrings| Light Blue Red Green Flower Statement Earrings| 925 Sterling Silver Flower Earrings image 8](https://i.etsystatic.com/21371013/r/il/da0219/6948958024/il_75x75.6948958024_4v7n.jpg)
- ![Handmade Hydrangea Real Flower Resin Stud Earrings| Light Blue Red Green Flower Statement Earrings| 925 Sterling Silver Flower Earrings image 9](https://i.etsystatic.com/21371013/r/il/b04604/6996925887/il_75x75.6996925887_crny.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1268756258%2Fhandmade-hydrangea-real-flower-resin%23report-overlay-trigger)

In 6 carts

Price:$22.49


Original Price:
$29.99


Loading


**25% off**

Sale ends on December 1


# Handmade Hydrangea Real Flower Resin Stud Earrings\| Light Blue Red Green Flower Statement Earrings\| 925 Sterling Silver Flower Earrings

Made by [FloralMemoriesJewel](https://www.etsy.com/shop/FloralMemoriesJewel)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1268756258/handmade-hydrangea-real-flower-resin?amp;click_sum=a0d03a73&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;pro=1&amp;sts=1#reviews)

Arrives soon! Get it by

Nov 14-18


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

Primary color


Select a color

Pink \[Sold out\]

Purple \[Sold out\]

Green

Red

Light Blue

White

Please select a color


4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Made by [FloralMemoriesJewel](https://www.etsy.com/shop/FloralMemoriesJewel)

- Materials: real flower, 925 sterling silver

- Closure: Push back

- Width: 20 Millimeters


- Made to Order


Real hydrangea coated with resin, 925 sterling silver ear pins.

Diameter approx. 3/4"-1"

Light weight and sturdy.

Come with gift box

Since we use natural flowers, there are subtle differences in color and form.


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-18**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 30 days


- Ships from: **West Linn, OR**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

## Reviews for this item (24)

4.8/5

item average

5.0Item quality

5.0Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Love it

Beautiful

Fast shipping

Gift-worthy

As described

Cute

Great quality


Filter by category


Appearance (9)


Shipping & Packaging (6)


Quality (6)


Sizing & Fit (3)


Description accuracy (3)


Seller service (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Chloe P](https://www.etsy.com/people/2ttid6f3v4avto37?ref=l_review)
Nov 10, 2025


Beautiful earrings, even more so in person than I thought they'd be! They came packaged really nicely and securely in a durable box which worked well as they're intended to be a gift.



![Chloe P added a photo of their purchase](https://i.etsystatic.com/iap/ce0c50/7428205607/iap_300x300.7428205607_cus72z1s.jpg?version=0)

[Chloe P](https://www.etsy.com/people/2ttid6f3v4avto37?ref=l_review)
Nov 10, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/8904c3/61980969/iusa_75x75.61980969_9l73.jpg?version=0)

[Sarah Alm](https://www.etsy.com/people/sarahalm?ref=l_review)
Aug 30, 2025


These arrived so fast! 48 hours after placing the order I had them. They're so cute and look just as pictured.



![](https://i.etsystatic.com/iusa/8904c3/61980969/iusa_75x75.61980969_9l73.jpg?version=0)

[Sarah Alm](https://www.etsy.com/people/sarahalm?ref=l_review)
Aug 30, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/aa7e04/102189000/iusa_75x75.102189000_g4m2.jpg?version=0)

[Chelsea Guthrie](https://www.etsy.com/people/ashton7idell?ref=l_review)
Aug 21, 2025


Earrings are a great size, and very pretty on. They are delicate, so keep that in mind.



![Chelsea Guthrie added a photo of their purchase](https://i.etsystatic.com/iap/814b24/7177505989/iap_300x300.7177505989_1yct4c7m.jpg?version=0)

![](https://i.etsystatic.com/iusa/aa7e04/102189000/iusa_75x75.102189000_g4m2.jpg?version=0)

[Chelsea Guthrie](https://www.etsy.com/people/ashton7idell?ref=l_review)
Aug 21, 2025


4 out of 5 stars
4

This item

[Andrew Cavanaugh](https://www.etsy.com/people/wc1jedlj6i2q2y13?ref=l_review)
Aug 10, 2025


My wife loved these earrings, except for the size. They looked smaller in the photos than they are in person. But the quality and design are great!



[Andrew Cavanaugh](https://www.etsy.com/people/wc1jedlj6i2q2y13?ref=l_review)
Aug 10, 2025


View all reviews for this item

### Photos from reviews

![Chelsea added a photo of their purchase](https://i.etsystatic.com/iap/814b24/7177505989/iap_300x300.7177505989_1yct4c7m.jpg?version=0)

![Alina added a photo of their purchase](https://i.etsystatic.com/iap/59a120/6794327792/iap_300x300.6794327792_7tzb5lxx.jpg?version=0)

![Chloe added a photo of their purchase](https://i.etsystatic.com/iap/ce0c50/7428205607/iap_300x300.7428205607_cus72z1s.jpg?version=0)

[![FloralMemoriesJewel](https://i.etsystatic.com/iusa/680a02/69477791/iusa_75x75.69477791_s049.jpg?version=0)](https://www.etsy.com/shop/FloralMemoriesJewel?ref=shop_profile&listing_id=1268756258)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[FloralMemoriesJewel](https://www.etsy.com/shop/FloralMemoriesJewel?ref=shop_profile&listing_id=1268756258)

[Owned by Angie](https://www.etsy.com/shop/FloralMemoriesJewel?ref=shop_profile&listing_id=1268756258) \|

Oregon, United States

4.9
(4k)


19.5k sales

6 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=248506135&referring_id=1268756258&referring_type=listing&recipient_id=248506135&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyNDg1MDYxMzU6MTc2MjgxOTExNDozM2U5OWEwN2E2ZWUxN2RkYzQxZWE2ZGM4N2IzOTY1MA%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1268756258%2Fhandmade-hydrangea-real-flower-resin%3Famp%253Bclick_sum%3Da0d03a73%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bpro%3D1%26amp%253Bsts%3D1)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/FloralMemoriesJewel?ref=lp_mys_mfts)

- [![Red Rose Petal Dangle Earrings: Pearl & Gold Clip-Ons](https://i.etsystatic.com/21371013/r/il/e91824/2164372744/il_340x270.2164372744_rhns.jpg)\\
\\
**Red Rose Petal Dangle Earrings: Pearl & Gold Clip-Ons**\\
\\
Sale Price $19.49\\
$19.49\\
\\
$25.99\\
Original Price $25.99\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/774232475/red-rose-petal-dangle-earrings-pearl?click_key=8532a86b9a2df6010059282d68a9c5f4%3ALTd381dec4fdfc132f92b601d0141e82078a4dc32c&click_sum=e71599bd&ls=r&ref=related-1&pro=1&sts=1&content_source=8532a86b9a2df6010059282d68a9c5f4%253ALTd381dec4fdfc132f92b601d0141e82078a4dc32c "Red Rose Petal Dangle Earrings: Pearl & Gold Clip-Ons")




Add to Favorites


- [![Handmade Real Natural Red Rose Dangle Earrings| Dried Rose Resin Earrings| Botanical Jewelry](https://i.etsystatic.com/21371013/c/2202/1750/385/216/il/4959a0/4798733658/il_340x270.4798733658_dgp8.jpg)\\
\\
**Handmade Real Natural Red Rose Dangle Earrings\| Dried Rose Resin Earrings\| Botanical Jewelry**\\
\\
Sale Price $14.99\\
$14.99\\
\\
$19.99\\
Original Price $19.99\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1442634158/handmade-real-natural-red-rose-dangle?click_key=8532a86b9a2df6010059282d68a9c5f4%3ALTe3679d9b05c8d3bc1cbd4d92e6717ccc956b5629&click_sum=bb1f1d35&ls=r&ref=related-2&pro=1&sts=1&content_source=8532a86b9a2df6010059282d68a9c5f4%253ALTe3679d9b05c8d3bc1cbd4d92e6717ccc956b5629 "Handmade Real Natural Red Rose Dangle Earrings| Dried Rose Resin Earrings| Botanical Jewelry")




Add to Favorites


- [![Dried Flower Resin Stud Earrings| Real Flowers Petals Leaves 925 Sterling Silver Stud Earrings| Forget Me Not Stud Earrings](https://i.etsystatic.com/21371013/c/1962/1998/0/0/il/675497/6395390630/il_340x270.6395390630_q97d.jpg)\\
\\
**Dried Flower Resin Stud Earrings\| Real Flowers Petals Leaves 925 Sterling Silver Stud Earrings\| Forget Me Not Stud Earrings**\\
\\
Sale Price $14.99\\
$14.99\\
\\
$19.99\\
Original Price $19.99\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1101223522/dried-flower-resin-stud-earrings-real?click_key=8532a86b9a2df6010059282d68a9c5f4%3ALT748727ffe73cea6e60d8ac14eac7d52f518fc783&click_sum=aca581bf&ls=r&ref=related-3&pro=1&sts=1&content_source=8532a86b9a2df6010059282d68a9c5f4%253ALT748727ffe73cea6e60d8ac14eac7d52f518fc783 "Dried Flower Resin Stud Earrings| Real Flowers Petals Leaves 925 Sterling Silver Stud Earrings| Forget Me Not Stud Earrings")




Add to Favorites


- [![Birth Month Flower Bracelet Personalized Birthday Gift Pressed Flower Adjustable Bracelet Forgetme not Lavender Hydrangea Sunflower Bracelet](https://i.etsystatic.com/21371013/r/il/8c94bf/7222615511/il_340x270.7222615511_fplh.jpg)\\
\\
**Birth Month Flower Bracelet Personalized Birthday Gift Pressed Flower Adjustable Bracelet Forgetme not Lavender Hydrangea Sunflower Bracelet**\\
\\
Sale Price $26.99\\
$26.99\\
\\
$35.99\\
Original Price $35.99\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1859896209/birth-month-flower-bracelet-personalized?click_key=a13a2503ec3fa7b4421c66777808b9301f3401e1%3A1859896209&click_sum=089e6ff4&ref=related-4&pro=1&sts=1 "Birth Month Flower Bracelet Personalized Birthday Gift Pressed Flower Adjustable Bracelet Forgetme not Lavender Hydrangea Sunflower Bracelet")




Add to Favorites



Loading...

Loading


**Disclaimer:** Button/coin batteries may cause serious injury and even death if swallowed. Items containing button/coin batteries should not be easily accessible without the use of a tool. Sellers are responsible for complying with all applicable labeling, design, testing, packaging, and other safety requirements. Etsy assumes no responsibility for the accuracy or contents of a seller’s listing. If you have questions about button/coin batteries, contact the seller by sending a Message. See Etsy's [Terms of Use](https://www.etsy.com/legal/terms-of-use/?ref=product_safety_banner_info_button_batteries_risk#warranties) for more information.

Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading wedding form

Loading


## Top wedding searches to shop

[![](https://i.etsystatic.com/19757930/c/1333/1333/0/301/il/cfe72f/3482678762/il_300x300.3482678762_pxw3.jpg)\\
Bridesmaid gifts](https://www.etsy.com/search?q=bridesmaid+gifts&mosv=sese&moci=635510339037&mosi=618520640322&featured_listing=1110003408&ref=wedding_recs_lp_bridesmaid_gifts)

[![](https://i.etsystatic.com/19483987/r/il/42cd8d/2512481731/il_300x300.2512481731_8gz7.jpg)\\
Groomsmen gifts](https://www.etsy.com/search?q=groomsmen+gifts&mosv=sese&moci=635510339037&mosi=635510910189&featured_listing=761677858&ref=wedding_recs_lp_groomsmen_gifts)

[![](https://i.etsystatic.com/6748817/c/2000/2000/0/828/il/b140dc/3394740672/il_300x300.3394740672_mong.jpg)\\
Wedding gifts](https://www.etsy.com/search?q=wedding+gifts&mosv=sese&moci=635510339037&mosi=618520762754&featured_listing=1087712798&ref=wedding_recs_lp_wedding_gifts)

[![](https://i.etsystatic.com/5354512/r/il/35af5c/5783958379/il_300x300.5783958379_pio7.jpg)\\
Engagement gifts](https://www.etsy.com/search?q=engagement+gifts&mosv=sese&moci=635510339037&mosi=635511121285&featured_listing=190344599&ref=wedding_recs_lp_engagement_gifts)

Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 10, 2025


[652 favorites](https://www.etsy.com/listing/1268756258/handmade-hydrangea-real-flower-resin/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Jewelry](https://www.etsy.com/c/jewelry?amp%3Bclick_sum=a0d03a73&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bpro=1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Earrings](https://www.etsy.com/c/jewelry/earrings?amp%3Bclick_sum=a0d03a73&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bpro=1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Stud Earrings](https://www.etsy.com/c/jewelry/earrings/stud-earrings?amp%3Bclick_sum=a0d03a73&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bpro=1&%3Bsts=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Beads Gems & Cabochons

[Sky Blue Apatite Gemstone Beads: AAA Smooth Roundels](https://www.etsy.com/listing/1033300254/sky-blue-apatite-gemstone-beads-aaa)

Necklaces

[Handmade LOVE Script with Black Nylon Strap Necklace (Approx 16in length)](https://www.etsy.com/listing/1474412862/handmade-love-script-with-black-nylon)

Paper

[4" x 5"](https://www.etsy.com/listing/1479635808/maplestory-vinyl-sticker-sheet-homemade) [Buy Bacon Pun Card Online](https://www.etsy.com/market/bacon_pun_card) [African American Joyful Forest Gathering Christmas Wrapping Paper. Wrap paper forkids. Christmasgift wrappingpaper.](https://www.etsy.com/listing/1623101235/african-american-joyful-forest-gathering)

Gender Neutral Adult Clothing

[Buy Rumi Tshirt Online](https://www.etsy.com/market/rumi_tshirt) [Funny Cat Yoga Shirt - Gender-Neutral Adult Clothing](https://www.etsy.com/listing/1259043047/funny-cat-yoga-shirt-meditation-shirt)

Fragrances

[Shop Fragrances Arabian Vanilla Premium Oil...](https://www.etsy.com/market/fragrances_arabian_vanilla_premium_oil...)

Patterns & How To

[Buy Flourishing Workbook Online](https://www.etsy.com/market/flourishing_workbook) [I Don't Get Drunk I Get Lucky by PerfectStylishCuts](https://www.etsy.com/listing/267196085/i-dont-get-drunk-i-get-lucky-st-patricks)

Rings

[Marquise Diamond Wedding Band/ Shared Prong Set Marquise Lab Grown Diamond Ring/ Unique 3/4 Eternity Diamond Stacking Ring/ Gold or Platinum](https://www.etsy.com/listing/1251006824/marquise-diamond-wedding-band-shared)

Prints

[Sonic Seamless Pattern - US](https://www.etsy.com/market/sonic_seamless_pattern) [Shop Love Thy Neighbor Wall Art](https://www.etsy.com/market/love_thy_neighbor_wall_art)

Books

[Vox Magazine Oct 1996 with 2 Giant Oasis Poster - Books](https://www.etsy.com/listing/1627667560/vox-magazine-oct-1996-with-2-giant-oasis)

Drawing & Illustration

[Masters Golf Sublimation - US](https://www.etsy.com/market/masters_golf_sublimation)

Keychains & Lanyards

[Barbie doll Mattel Gymnastics keychain](https://www.etsy.com/listing/1539561800/barbie-doll-mattel-gymnastics-keychain) [Aya Maruyama for Sale](https://www.etsy.com/market/aya_maruyama)

Hair Accessories

[Shop Poop Bows](https://www.etsy.com/market/poop_bows)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1268756258%2Fhandmade-hydrangea-real-flower-resin%3Famp%253Bclick_sum%3Da0d03a73%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bpro%3D1%26amp%253Bsts%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgxOTExNDo0NWQ2NDkyNzYyZjI5MzE2ZTEyZTQ1OTUxMTA4M2NiYQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1268756258%2Fhandmade-hydrangea-real-flower-resin%3Famp%253Bclick_sum%3Da0d03a73%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bpro%3D1%26amp%253Bsts%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1268756258/handmade-hydrangea-real-flower-resin?amp;click_sum=a0d03a73&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;pro=1&amp;sts=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1268756258%2Fhandmade-hydrangea-real-flower-resin%3Famp%253Bclick_sum%3Da0d03a73%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bpro%3D1%26amp%253Bsts%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: Two blue flower earrings with white pearl centers. The earrings are displayed on a white surface.](https://i.etsystatic.com/21371013/r/il/bcf5fc/4068207948/il_300x300.4068207948_rixk.jpg)
- ![May include: Two pairs of blue flower earrings. Each earring is made of a single blue flower with a white center. The flowers are delicate and have a translucent appearance.](https://i.etsystatic.com/21371013/r/il/c88e31/4068207950/il_300x300.4068207950_a83f.jpg)
- ![May include: A pair of blue flower stud earrings with silver posts and clear backs](https://i.etsystatic.com/21371013/r/il/55fad0/4115857701/il_300x300.4115857701_oewn.jpg)
- ![May include: A pair of blue flower stud earrings.](https://i.etsystatic.com/21371013/r/il/211769/4609603020/il_300x300.4609603020_3ec1.jpg)
- ![Handmade Hydrangea Real Flower Resin Stud Earrings| Light Blue Red Green Flower Statement Earrings| 925 Sterling Silver Flower Earrings image 5](https://i.etsystatic.com/21371013/r/il/b0da27/6996908951/il_300x300.6996908951_c4rc.jpg)
- ![Handmade Hydrangea Real Flower Resin Stud Earrings| Light Blue Red Green Flower Statement Earrings| 925 Sterling Silver Flower Earrings image 6](https://i.etsystatic.com/21371013/r/il/5f1b47/6948958012/il_300x300.6948958012_5xob.jpg)
- ![Handmade Hydrangea Real Flower Resin Stud Earrings| Light Blue Red Green Flower Statement Earrings| 925 Sterling Silver Flower Earrings image 7](https://i.etsystatic.com/21371013/r/il/448169/6948958022/il_300x300.6948958022_24zd.jpg)
- ![Handmade Hydrangea Real Flower Resin Stud Earrings| Light Blue Red Green Flower Statement Earrings| 925 Sterling Silver Flower Earrings image 8](https://i.etsystatic.com/21371013/r/il/da0219/6948958024/il_300x300.6948958024_4v7n.jpg)
- ![Handmade Hydrangea Real Flower Resin Stud Earrings| Light Blue Red Green Flower Statement Earrings| 925 Sterling Silver Flower Earrings image 9](https://i.etsystatic.com/21371013/r/il/b04604/6996925887/il_300x300.6996925887_crny.jpg)

- ![](https://i.etsystatic.com/iap/814b24/7177505989/iap_640x640.7177505989_1yct4c7m.jpg?version=0)

5 out of 5 stars

- Color:

Light Blue


Earrings are a great size, and very pretty on. They are delicate, so keep that in mind.

![](https://i.etsystatic.com/iusa/aa7e04/102189000/iusa_75x75.102189000_g4m2.jpg?version=0)

Aug 21, 2025


[Chelsea Guthrie](https://www.etsy.com/people/ashton7idell)

Purchased item:

[![Handmade Hydrangea Real Flower Resin Stud Earrings| Light Blue Red Green Flower Statement Earrings| 925 Sterling Silver Flower Earrings](https://i.etsystatic.com/21371013/r/il/bcf5fc/4068207948/il_170x135.4068207948_rixk.jpg)\\
\\
Handmade Hydrangea Real Flower Resin Stud Earrings\| Light Blue Red Green Flower Statement Earrings\| 925 Sterling Silver Flower Earrings\\
\\
Sale Price $22.49\\
$22.49\\
\\
$29.99\\
Original Price $29.99\\
\\
\\
(25% off)](https://www.etsy.com/listing/1268756258/handmade-hydrangea-real-flower-resin?ref=ap-listing)

Purchased item:

[![Handmade Hydrangea Real Flower Resin Stud Earrings| Light Blue Red Green Flower Statement Earrings| 925 Sterling Silver Flower Earrings](https://i.etsystatic.com/21371013/r/il/bcf5fc/4068207948/il_170x135.4068207948_rixk.jpg)\\
\\
Handmade Hydrangea Real Flower Resin Stud Earrings\| Light Blue Red Green Flower Statement Earrings\| 925 Sterling Silver Flower Earrings\\
\\
Sale Price $22.49\\
$22.49\\
\\
$29.99\\
Original Price $29.99\\
\\
\\
(25% off)](https://www.etsy.com/listing/1268756258/handmade-hydrangea-real-flower-resin?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/59a120/6794327792/iap_640x640.6794327792_7tzb5lxx.jpg?version=0)

5 out of 5 stars

- Color:

Light Blue


Beautiful earrings. As described. Quick shipping. Well packaged. Gifting ready!

![](https://i.etsystatic.com/iusa/e793d8/73747742/iusa_75x75.73747742_9tg8.jpg?version=0)

Apr 15, 2025


[Alina Z](https://www.etsy.com/people/alina112891)

Purchased item:

[![Handmade Hydrangea Real Flower Resin Stud Earrings| Light Blue Red Green Flower Statement Earrings| 925 Sterling Silver Flower Earrings](https://i.etsystatic.com/21371013/r/il/bcf5fc/4068207948/il_170x135.4068207948_rixk.jpg)\\
\\
Handmade Hydrangea Real Flower Resin Stud Earrings\| Light Blue Red Green Flower Statement Earrings\| 925 Sterling Silver Flower Earrings\\
\\
Sale Price $22.49\\
$22.49\\
\\
$29.99\\
Original Price $29.99\\
\\
\\
(25% off)](https://www.etsy.com/listing/1268756258/handmade-hydrangea-real-flower-resin?ref=ap-listing)

Purchased item:

[![Handmade Hydrangea Real Flower Resin Stud Earrings| Light Blue Red Green Flower Statement Earrings| 925 Sterling Silver Flower Earrings](https://i.etsystatic.com/21371013/r/il/bcf5fc/4068207948/il_170x135.4068207948_rixk.jpg)\\
\\
Handmade Hydrangea Real Flower Resin Stud Earrings\| Light Blue Red Green Flower Statement Earrings\| 925 Sterling Silver Flower Earrings\\
\\
Sale Price $22.49\\
$22.49\\
\\
$29.99\\
Original Price $29.99\\
\\
\\
(25% off)](https://www.etsy.com/listing/1268756258/handmade-hydrangea-real-flower-resin?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/ce0c50/7428205607/iap_640x640.7428205607_cus72z1s.jpg?version=0)

5 out of 5 stars

- Color:

Green


Beautiful earrings, even more so in person than I thought they'd be! They came packaged really nicely and securely in a durable box which worked well as they're intended to be a gift.

Nov 10, 2025


[Chloe P](https://www.etsy.com/people/2ttid6f3v4avto37)

Purchased item:

[![Handmade Hydrangea Real Flower Resin Stud Earrings| Light Blue Red Green Flower Statement Earrings| 925 Sterling Silver Flower Earrings](https://i.etsystatic.com/21371013/r/il/bcf5fc/4068207948/il_170x135.4068207948_rixk.jpg)\\
\\
Handmade Hydrangea Real Flower Resin Stud Earrings\| Light Blue Red Green Flower Statement Earrings\| 925 Sterling Silver Flower Earrings\\
\\
Sale Price $22.49\\
$22.49\\
\\
$29.99\\
Original Price $29.99\\
\\
\\
(25% off)](https://www.etsy.com/listing/1268756258/handmade-hydrangea-real-flower-resin?ref=ap-listing)

Purchased item:

[![Handmade Hydrangea Real Flower Resin Stud Earrings| Light Blue Red Green Flower Statement Earrings| 925 Sterling Silver Flower Earrings](https://i.etsystatic.com/21371013/r/il/bcf5fc/4068207948/il_170x135.4068207948_rixk.jpg)\\
\\
Handmade Hydrangea Real Flower Resin Stud Earrings\| Light Blue Red Green Flower Statement Earrings\| 925 Sterling Silver Flower Earrings\\
\\
Sale Price $22.49\\
$22.49\\
\\
$29.99\\
Original Price $29.99\\
\\
\\
(25% off)](https://www.etsy.com/listing/1268756258/handmade-hydrangea-real-flower-resin?ref=ap-listing)