[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1163630241/square-macrame-fringe-earrings-boho?amp;click_sum=0c79f48f&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Jewelry](https://www.etsy.com/c/jewelry?amp%3Bclick_sum=0c79f48f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&explicit=1&ref=catnav_breadcrumb-0)
- [Earrings](https://www.etsy.com/c/jewelry/earrings?amp%3Bclick_sum=0c79f48f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&explicit=1&ref=catnav_breadcrumb-1)
- [Dangle & Drop Earrings](https://www.etsy.com/c/jewelry/earrings/dangle-earrings?amp%3Bclick_sum=0c79f48f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&explicit=1&ref=catnav_breadcrumb-2)


Add to Favorites


- ![May include: Six pairs of handmade macrame earrings with geometric shapes and fringe details. The earrings are in various colors including mustard yellow, teal, white, light pink, and orange. The earrings are displayed on a white background.](https://i.etsystatic.com/10873356/r/il/b43f56/4704899607/il_794xN.4704899607_2y46.jpg)
- ![May include: Cord color options for 100% recycled cotton cord. The colors are: Natural, Blush, Mustard, Eucalyptus, Peacock, Rainbow Dust, White, Wild Rose, Terracotta, Milky Green, Blackberry, Coffee, Sand, Mauve, Caramel, Laurel, Avocado, and Black.](https://i.etsystatic.com/10873356/r/il/eaaf0d/4684099819/il_794xN.4684099819_bcjr.jpg)
- ![May include: A pair of pink tassel earrings with silver triangle frames. The earrings are made of macrame and have a fringe design.](https://i.etsystatic.com/10873356/r/il/be40e9/4635864388/il_794xN.4635864388_ayd4.jpg)
- ![May include: A pair of brown tassel earrings with gold metal frames. The earrings are in the shape of a diamond with a fringe of brown tassels hanging from the bottom.](https://i.etsystatic.com/10873356/r/il/b9bc09/4635864392/il_794xN.4635864392_2s16.jpg)
- ![May include: A pair of light blue macrame earrings with a diamond shape and fringe. The earrings are made with a light blue cord and have a gold-tone metal hook.](https://i.etsystatic.com/10873356/r/il/4df1ed/4635864424/il_794xN.4635864424_p2sq.jpg)
- ![May include: Two pairs of white tassel earrings with silver triangle frames. The tassels are made of white string with small colorful flecks throughout.](https://i.etsystatic.com/10873356/r/il/7dcb75/4635864430/il_794xN.4635864430_1mnu.jpg)
- ![May include: A pair of gold and teal blue tassel earrings. The earrings are made of a thin gold wire that forms a diamond shape. The diamond shape is filled with teal blue tassels. The earrings are hanging from gold hooks.](https://i.etsystatic.com/10873356/r/il/7ab5b1/4635864428/il_794xN.4635864428_d3ja.jpg)
- ![May include: A pair of mustard yellow macrame earrings with a gold-toned metal frame and a tassel design.](https://i.etsystatic.com/10873356/r/il/9de025/4635864434/il_794xN.4635864434_et2o.jpg)
- ![May include: Two pairs of earrings with gold hoops and fringe details. One pair has brown fringe and the other pair has white fringe.](https://i.etsystatic.com/10873356/r/il/1a19f4/4635864724/il_794xN.4635864724_lz7q.jpg)
- ![May include: Six pairs of handmade tassel earrings with square metal frames. The earrings are in various colors including yellow, teal, white, light green, and orange.](https://i.etsystatic.com/10873356/r/il/8b6c79/4635864748/il_794xN.4635864748_eru9.jpg)

- ![May include: Six pairs of handmade macrame earrings with geometric shapes and fringe details. The earrings are in various colors including mustard yellow, teal, white, light pink, and orange. The earrings are displayed on a white background.](https://i.etsystatic.com/10873356/c/2068/1643/362/291/il/b43f56/4704899607/il_75x75.4704899607_2y46.jpg)
- ![May include: Cord color options for 100% recycled cotton cord. The colors are: Natural, Blush, Mustard, Eucalyptus, Peacock, Rainbow Dust, White, Wild Rose, Terracotta, Milky Green, Blackberry, Coffee, Sand, Mauve, Caramel, Laurel, Avocado, and Black.](https://i.etsystatic.com/10873356/r/il/eaaf0d/4684099819/il_75x75.4684099819_bcjr.jpg)
- ![May include: A pair of pink tassel earrings with silver triangle frames. The earrings are made of macrame and have a fringe design.](https://i.etsystatic.com/10873356/r/il/be40e9/4635864388/il_75x75.4635864388_ayd4.jpg)
- ![May include: A pair of brown tassel earrings with gold metal frames. The earrings are in the shape of a diamond with a fringe of brown tassels hanging from the bottom.](https://i.etsystatic.com/10873356/r/il/b9bc09/4635864392/il_75x75.4635864392_2s16.jpg)
- ![May include: A pair of light blue macrame earrings with a diamond shape and fringe. The earrings are made with a light blue cord and have a gold-tone metal hook.](https://i.etsystatic.com/10873356/r/il/4df1ed/4635864424/il_75x75.4635864424_p2sq.jpg)
- ![May include: Two pairs of white tassel earrings with silver triangle frames. The tassels are made of white string with small colorful flecks throughout.](https://i.etsystatic.com/10873356/r/il/7dcb75/4635864430/il_75x75.4635864430_1mnu.jpg)
- ![May include: A pair of gold and teal blue tassel earrings. The earrings are made of a thin gold wire that forms a diamond shape. The diamond shape is filled with teal blue tassels. The earrings are hanging from gold hooks.](https://i.etsystatic.com/10873356/r/il/7ab5b1/4635864428/il_75x75.4635864428_d3ja.jpg)
- ![May include: A pair of mustard yellow macrame earrings with a gold-toned metal frame and a tassel design.](https://i.etsystatic.com/10873356/r/il/9de025/4635864434/il_75x75.4635864434_et2o.jpg)
- ![May include: Two pairs of earrings with gold hoops and fringe details. One pair has brown fringe and the other pair has white fringe.](https://i.etsystatic.com/10873356/r/il/1a19f4/4635864724/il_75x75.4635864724_lz7q.jpg)
- ![May include: Six pairs of handmade tassel earrings with square metal frames. The earrings are in various colors including yellow, teal, white, light green, and orange.](https://i.etsystatic.com/10873356/r/il/8b6c79/4635864748/il_75x75.4635864748_eru9.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1163630241%2Fsquare-macrame-fringe-earrings-boho%23report-overlay-trigger)

In 20+ carts

Price:$12.00


Loading


# Square Macrame Fringe Earrings \| Boho Detailed Hand Tied Macrame Jewelry \| Choose Your Color

[MadebyMoonliteCo](https://www.etsy.com/shop/MadebyMoonliteCo?ref=shop-header-name&listing_id=1163630241&from_page=listing)

[4.5 out of 5 stars](https://www.etsy.com/listing/1163630241/square-macrame-fringe-earrings-boho?amp;click_sum=0c79f48f&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1#reviews)

Ships from Tennessee

Metal Finish


Select an option

Silver

Gold

Bronze

Please select an option


Cord Color


Select an option

Natural

Blush

Mustard

Eucalyptus

Peacock

Rainbow Dust

White

Wild Rose

Terracotta

Blackberry

Coffee

Sand

Mauve

Caramel

Laurel

Avocado

Black

Please select an option


Quantity



1234567891011121314

You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Made by [MadebyMoonliteCo](https://www.etsy.com/shop/MadebyMoonliteCo)

- Ships from Tennessee! Shorter shipping distances are

kinder to the planet

Ordering items closer to you is more likely to reduce your purchase's carbon footprint.


- Materials: Cotton

- Location: Earlobe

- Closure: Ear wire

- Style: Boho & hippie

- Drop length: 2.75 Inches; Width: 1.75 Inches


- Made to Order


- Gift wrapping available

See details

Gift wrapping by MadebyMoonliteCo

Your earrings will be carefully set in a white jewelry box. We can add a note in calligraphy or add any additional touches you’d like!

\*\*\*ITEM DETAILS\*\*\*

Materials:

~eco-friendly cotton cord in your choice of color

~hypoallergenic / nickel-free metal earring hooks and squares in your choice of bronze, silver or gold

Measurement:

~approx 2.75 inches long from top of hook to bottom of fringe

~approx 1.75 inches at widest point

Additional Info:

~dangle earrings, very lightweight and wearable

~each piece is hand tied and made to order with an eclectic boho aesthetic

~stylish & recyclable packaging that is ready to gift (or keep for yourself)

\*Please note that the size is approximate due to the handmade nature of each item.

\*\*Please remember that dependent on the resolution of your screen, colors may appears slightly different in person.

\*\*\*To care for your new favorite earrings:

Brush out the fringe to your liking with a small tooth comb.

\*\*\*\*Thanks for shopping with us! Please message us if you want us to make something special just for you. Follow us on Instagram & Facebook to keep up with our latest creations @MadeByMoonlite


## Shipping and return policies

Loading


- Order today to get by

**Nov 18-Dec 1**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges not accepted




But please contact me if you have problems with your order


- Free shipping


- Ships from: **Knoxville, TN**


Deliver to United States

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## FAQs

Wholesale Availability


Please message us for wholesale orders. We would be happy to discuss some options with you!


Color Variations


Please note that colors on your screen may appear slightly different than in person. If you have any concerns, let us know!


Care Instructions


If your macrame product becomes tangled, it may be gently brushed with a comb. Carefully trim away any "disorderly" strands of cord.


How Do I Use My Diffuser?


Our macrame diffusers are very versatile! You can simply dab, drop or spray your favorite essential oil on the cotton cord, natural wood accents or beads.


Can I Return My Order?


Due to the custom made nature of our products, returns are not accepted. We offer the best quality at the lowest price and want to make sure our customers are happy. Please let us know of any issues.


What's Taking So Long?


We specify in each product description how long each order will take to ship. Our products are made to order by hand. We believe in full transparency and will let you know of any delays on our part! Once your product has shipped, we have no control over how quickly it will arrive to you.


## Meet your sellers

![Ashley and Stephanie](https://i.etsystatic.com/10873356/r/isla/6570a7/54104840/isla_75x75.54104840_scm9mpxe.jpg)

Ashley and Stephanie

Owner of [MadebyMoonliteCo](https://www.etsy.com/shop/MadebyMoonliteCo?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo2MzQxNjYyNToxNzYyODE3MjI5OjQwZjI5OWMyODUxZTUwNjBjZGRlMjNkZTUyOGQyODc0&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1163630241%2Fsquare-macrame-fringe-earrings-boho%3Famp%253Bclick_sum%3D0c79f48f%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1)

[Message Ashley and Stephanie](https://www.etsy.com/messages/new?with_id=63416625&referring_id=1163630241&referring_type=listing&recipient_id=63416625&from_action=contact-seller)

This seller usually responds **within 24 hours.**

## Reviews for this item (510)

4.6/5

item average

4.7Item quality

4.4Shipping

4.0Customer service

87%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Love it

Beautiful

Cute

Great quality

Very well made

Very pretty

As described


Filter by category


Appearance (159)


Quality (125)


Shipping & Packaging (59)


Description accuracy (34)


Seller service (29)


Comfort (19)


Sizing & Fit (14)


Value (7)


Ease of use (2)


Condition (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Kerri](https://www.etsy.com/people/6xvpsjvq?ref=l_review)
Oct 30, 2025


I ordered these for my bridesmaids. I was a little late ordering but it didn’t matter because they were on top of it. Custom made me 7 pairs of earrings, plus sent a free pair just cuz. These are real artisans and I love the earrings!



[Kerri](https://www.etsy.com/people/6xvpsjvq?ref=l_review)
Oct 30, 2025


4 out of 5 stars
4

This item

[Corrine](https://www.etsy.com/people/2o2pzlxeszk4ghtw?ref=l_review)
Oct 21, 2025


This took a long time to get to me and said it was shipped for weeks before it was actually shipped. I never heard back about the delay when I sent a message. The quality and craft however is great.



[Corrine](https://www.etsy.com/people/2o2pzlxeszk4ghtw?ref=l_review)
Oct 21, 2025


5 out of 5 stars
5

This item

[Diane](https://www.etsy.com/people/utfpi31x?ref=l_review)
Aug 17, 2025


Took two or three weeks to receive, but was worth it



[Diane](https://www.etsy.com/people/utfpi31x?ref=l_review)
Aug 17, 2025


5 out of 5 stars
5

This item

[Ariel](https://www.etsy.com/people/gucipjg7vnezedby?ref=l_review)
Jul 21, 2025


so amazingly cute. love the color



[Ariel](https://www.etsy.com/people/gucipjg7vnezedby?ref=l_review)
Jul 21, 2025


View all reviews for this item

### Photos from reviews

![Kailey added a photo of their purchase](https://i.etsystatic.com/iap/af5be9/5791924717/iap_300x300.5791924717_6lgm3xl1.jpg?version=0)

![JESSICA added a photo of their purchase](https://i.etsystatic.com/iap/0e5b5f/5110253719/iap_300x300.5110253719_pkxb9sz3.jpg?version=0)

![Robin added a photo of their purchase](https://i.etsystatic.com/iap/109f67/5488261112/iap_300x300.5488261112_cexcvitz.jpg?version=0)

![Sarah added a photo of their purchase](https://i.etsystatic.com/iap/1e6bd3/5324537582/iap_300x300.5324537582_7y9p539n.jpg?version=0)

![EricaSig added a photo of their purchase](https://i.etsystatic.com/iap/9f6578/6324183418/iap_300x300.6324183418_lhxaqhxr.jpg?version=0)

![Beth added a photo of their purchase](https://i.etsystatic.com/iap/8b92e5/6385481131/iap_300x300.6385481131_g591w009.jpg?version=0)

![Corrie added a photo of their purchase](https://i.etsystatic.com/iap/7fecc2/4760544628/iap_300x300.4760544628_44o8p747.jpg?version=0)

![Mary added a photo of their purchase](https://i.etsystatic.com/iap/3d274f/5751840762/iap_300x300.5751840762_5o31jcxi.jpg?version=0)

![Denise added a photo of their purchase](https://i.etsystatic.com/iap/d25284/4744755440/iap_300x300.4744755440_q98zzyqr.jpg?version=0)

![Jennifer added a photo of their purchase](https://i.etsystatic.com/iap/fde0a0/5597018923/iap_300x300.5597018923_l8mstz91.jpg?version=0)

![Gretchen added a photo of their purchase](https://i.etsystatic.com/iap/374c0b/4447924204/iap_300x300.4447924204_3cc81drb.jpg?version=0)

![Desiree added a photo of their purchase](https://i.etsystatic.com/iap/d659f9/4405144099/iap_300x300.4405144099_5se5sfg2.jpg?version=0)

![Stacy added a photo of their purchase](https://i.etsystatic.com/iap/ae3d03/5190580889/iap_300x300.5190580889_llvsvj41.jpg?version=0)

![Avery added a photo of their purchase](https://i.etsystatic.com/iap/229895/4472032259/iap_300x300.4472032259_n0v9q63b.jpg?version=0)

![Christy added a photo of their purchase](https://i.etsystatic.com/iap/18c1ea/6656405336/iap_300x300.6656405336_7298ar4t.jpg?version=0)

![Jennifer added a photo of their purchase](https://i.etsystatic.com/iap/852d0d/5597007635/iap_300x300.5597007635_aslayme4.jpg?version=0)

![Nicole added a photo of their purchase](https://i.etsystatic.com/iap/d69add/5885242655/iap_300x300.5885242655_prgxlli3.jpg?version=0)

![Julie added a photo of their purchase](https://i.etsystatic.com/iap/21ce04/4369797782/iap_300x300.4369797782_6lyzfczp.jpg?version=0)

![AlissaCaitlyn added a photo of their purchase](https://i.etsystatic.com/iap/e126d7/6356179080/iap_300x300.6356179080_mnym5g2b.jpg?version=0)

![Lindsey added a photo of their purchase](https://i.etsystatic.com/iap/d5300e/6479569626/iap_300x300.6479569626_oazpiequ.jpg?version=0)

[![MadebyMoonliteCo](https://i.etsystatic.com/iusa/61e8bc/66721527/iusa_75x75.66721527_xocg.jpg?version=0)](https://www.etsy.com/shop/MadebyMoonliteCo?ref=shop_profile&listing_id=1163630241)

[MadebyMoonliteCo](https://www.etsy.com/shop/MadebyMoonliteCo?ref=shop_profile&listing_id=1163630241)

[Owned by Ashley and Stephanie](https://www.etsy.com/shop/MadebyMoonliteCo?ref=shop_profile&listing_id=1163630241) \|

Knoxville, Tennessee

4.6
(2.7k)


9.6k sales

9 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=63416625&referring_id=1163630241&referring_type=listing&recipient_id=63416625&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo2MzQxNjYyNToxNzYyODE3MjI5OjQwZjI5OWMyODUxZTUwNjBjZGRlMjNkZTUyOGQyODc0&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1163630241%2Fsquare-macrame-fringe-earrings-boho%3Famp%253Bclick_sum%3D0c79f48f%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1)

This seller usually responds **within 24 hours.**

## More from this shop

[Visit shop](https://www.etsy.com/shop/MadebyMoonliteCo?ref=lp_mys_mfts)

- [![Macrame Tassel Earrings | Custom Color Options | Boho Fringe Earrings | Bridesmaid Gift](https://i.etsystatic.com/10873356/c/2623/2085/78/0/il/b72fa1/4704914301/il_340x270.4704914301_ag2u.jpg)\\
\\
**Macrame Tassel Earrings \| Custom Color Options \| Boho Fringe Earrings \| Bridesmaid Gift**\\
\\
$10.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/973252371/macrame-tassel-earrings-custom-color?click_key=6517184756448d1aa561455b986a15ba%3ALT6f994f77b77a5653764a1ed112ffed6a06263ee3&click_sum=619a1a70&ls=r&ref=related-1&content_source=6517184756448d1aa561455b986a15ba%253ALT6f994f77b77a5653764a1ed112ffed6a06263ee3 "Macrame Tassel Earrings | Custom Color Options | Boho Fringe Earrings | Bridesmaid Gift")




Add to Favorites


- [![Hoop Macrame Fringe Earrings | Custom Macrame Earrings | Boho Earrings | Macrame Hoop Earrings | Bridesmaid Gift](https://i.etsystatic.com/10873356/c/2485/1975/308/127/il/3d30f9/4704915651/il_340x270.4704915651_q4xx.jpg)\\
\\
**Hoop Macrame Fringe Earrings \| Custom Macrame Earrings \| Boho Earrings \| Macrame Hoop Earrings \| Bridesmaid Gift**\\
\\
$13.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/973243021/hoop-macrame-fringe-earrings-custom?click_key=6517184756448d1aa561455b986a15ba%3ALTca09ae587b6bb7c60791629c02a0cadf89e600fe&click_sum=f8980f18&ls=r&ref=related-2&content_source=6517184756448d1aa561455b986a15ba%253ALTca09ae587b6bb7c60791629c02a0cadf89e600fe "Hoop Macrame Fringe Earrings | Custom Macrame Earrings | Boho Earrings | Macrame Hoop Earrings | Bridesmaid Gift")




Add to Favorites


- [![Triangle Macrame Earrings | Custom Macrame Earrings | Boho Earrings | Bridesmaid Gift](https://i.etsystatic.com/10873356/c/2250/1788/0/625/il/1445bf/3876353541/il_340x270.3876353541_oitp.jpg)\\
\\
**Triangle Macrame Earrings \| Custom Macrame Earrings \| Boho Earrings \| Bridesmaid Gift**\\
\\
$12.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/960717077/triangle-macrame-earrings-custom-macrame?click_key=6517184756448d1aa561455b986a15ba%3ALT339e56843fc8f78c6ed9565d7406944bf39efda9&click_sum=36aef270&ls=r&ref=related-3&content_source=6517184756448d1aa561455b986a15ba%253ALT339e56843fc8f78c6ed9565d7406944bf39efda9 "Triangle Macrame Earrings | Custom Macrame Earrings | Boho Earrings | Bridesmaid Gift")




Add to Favorites


- [![Hoop Earrings with Hand-tied Macrame Fringe | Custom Color Selection | Handmade Boho Jewelry](https://i.etsystatic.com/10873356/r/il/70e4fb/4704907559/il_340x270.4704907559_g53j.jpg)\\
\\
**Hoop Earrings with Hand-tied Macrame Fringe \| Custom Color Selection \| Handmade Boho Jewelry**\\
\\
$11.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1210981052/hoop-earrings-with-hand-tied-macrame?click_key=5c22be7f97b934ebb94eed16628aea999ddc1521%3A1210981052&click_sum=a1a7cf1a&ref=related-4 "Hoop Earrings with Hand-tied Macrame Fringe | Custom Color Selection | Handmade Boho Jewelry")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading wedding form

Loading


## Top wedding searches to shop

[![](https://i.etsystatic.com/19757930/c/1333/1333/0/301/il/cfe72f/3482678762/il_300x300.3482678762_pxw3.jpg)\\
Bridesmaid gifts](https://www.etsy.com/search?q=bridesmaid+gifts&mosv=sese&moci=635510339037&mosi=618520640322&featured_listing=1110003408&ref=wedding_recs_lp_bridesmaid_gifts)

[![](https://i.etsystatic.com/19483987/r/il/42cd8d/2512481731/il_300x300.2512481731_8gz7.jpg)\\
Groomsmen gifts](https://www.etsy.com/search?q=groomsmen+gifts&mosv=sese&moci=635510339037&mosi=635510910189&featured_listing=761677858&ref=wedding_recs_lp_groomsmen_gifts)

[![](https://i.etsystatic.com/6748817/c/2000/2000/0/828/il/b140dc/3394740672/il_300x300.3394740672_mong.jpg)\\
Wedding gifts](https://www.etsy.com/search?q=wedding+gifts&mosv=sese&moci=635510339037&mosi=618520762754&featured_listing=1087712798&ref=wedding_recs_lp_wedding_gifts)

[![](https://i.etsystatic.com/5354512/r/il/35af5c/5783958379/il_300x300.5783958379_pio7.jpg)\\
Engagement gifts](https://www.etsy.com/search?q=engagement+gifts&mosv=sese&moci=635510339037&mosi=635511121285&featured_listing=190344599&ref=wedding_recs_lp_engagement_gifts)

Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 2, 2025


[3951 favorites](https://www.etsy.com/listing/1163630241/square-macrame-fringe-earrings-boho/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Jewelry](https://www.etsy.com/c/jewelry?amp%3Bclick_sum=0c79f48f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&explicit=1&ref=breadcrumb_listing) [Earrings](https://www.etsy.com/c/jewelry/earrings?amp%3Bclick_sum=0c79f48f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&explicit=1&ref=breadcrumb_listing) [Dangle & Drop Earrings](https://www.etsy.com/c/jewelry/earrings/dangle-earrings?amp%3Bclick_sum=0c79f48f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Earrings

[Buy Earring Extension Online](https://www.etsy.com/market/earring_extension)

Girls Clothing

[Baby Stars Dress - US](https://www.etsy.com/market/baby_stars_dress)

Car Parts & Accessories

[Kurt And Ram Heathers for Sale](https://www.etsy.com/market/kurt_and_ram_heathers)

Necklaces

[Round silver dragon on black leather chain](https://www.etsy.com/listing/1528316561/round-silver-dragon-on-black-leather)

Collectibles

[Suisse Credit - US](https://www.etsy.com/market/suisse_credit)

Spirituality & Religion

[Buy Nuns Wood Cross Online](https://www.etsy.com/market/nuns_wood_cross)

Home Decor

[Bible Home Decor - Home Decor](https://www.etsy.com/listing/1204212136/romans-12-2-vinyl-wall-quote-bible-home)

Kitchen & Dining

[Buy Swedish Copper Molds Online](https://www.etsy.com/market/swedish_copper_molds)

Gender Neutral Adult Shoes

[Shop Diesel Shoes Men](https://www.etsy.com/market/diesel_shoes_men)

Womens Shoes

[Red Vintage Cowboy Boots for Sale](https://www.etsy.com/market/red_vintage_cowboy_boots)

Canvas & Surfaces

[Purple Garden Journal Kit - Canvas & Surfaces](https://www.etsy.com/listing/924647416/purple-garden-journal-kit-journal-page)

Prints

[Somerset Galleries - US](https://www.etsy.com/market/somerset_galleries)

Toys

[Original 1986 Cribsy Baby Pink Popple Rattle Tail](https://www.etsy.com/listing/1411728616/original-1986-cribsy-baby-pink-popple)

Shopping

[Buy November Spread Online](https://www.etsy.com/market/november_spread)

Blanks

[Flat Round Pad Base Earring Settings](https://www.etsy.com/listing/1802409691/stainless-steel-stud-earring-findings)

Bracelets

[Oui Bracelet - US](https://www.etsy.com/market/oui_bracelet)

Patches & Pins

[O Positive Blood Drop Patch Embroidered Iron On Patch Sew On Badge Applique](https://www.etsy.com/listing/951966746/o-positive-blood-drop-patch-embroidered)

Fabric & Notions

[Silk Crepe de Chine fabric - Fabric & Notions](https://www.etsy.com/listing/949369796/pure-mulberry-silk-fabric-silk-crepe-de)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1163630241%2Fsquare-macrame-fringe-earrings-boho%3Famp%253Bclick_sum%3D0c79f48f%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgxNzIyOTowOWE4OWFkODczZGQxOTY5ZmUxM2UyNDBjYjcwNmNkOA==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1163630241%2Fsquare-macrame-fringe-earrings-boho%3Famp%253Bclick_sum%3D0c79f48f%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1163630241/square-macrame-fringe-earrings-boho?amp;click_sum=0c79f48f&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1163630241%2Fsquare-macrame-fringe-earrings-boho%3Famp%253Bclick_sum%3D0c79f48f%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for MadebyMoonliteCo

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 24 hours of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: Six pairs of handmade macrame earrings with geometric shapes and fringe details. The earrings are in various colors including mustard yellow, teal, white, light pink, and orange. The earrings are displayed on a white background.](https://i.etsystatic.com/10873356/c/2068/2068/362/78/il/b43f56/4704899607/il_300x300.4704899607_2y46.jpg)
- ![May include: Cord color options for 100% recycled cotton cord. The colors are: Natural, Blush, Mustard, Eucalyptus, Peacock, Rainbow Dust, White, Wild Rose, Terracotta, Milky Green, Blackberry, Coffee, Sand, Mauve, Caramel, Laurel, Avocado, and Black.](https://i.etsystatic.com/10873356/r/il/eaaf0d/4684099819/il_300x300.4684099819_bcjr.jpg)
- ![May include: A pair of pink tassel earrings with silver triangle frames. The earrings are made of macrame and have a fringe design.](https://i.etsystatic.com/10873356/r/il/be40e9/4635864388/il_300x300.4635864388_ayd4.jpg)
- ![May include: A pair of brown tassel earrings with gold metal frames. The earrings are in the shape of a diamond with a fringe of brown tassels hanging from the bottom.](https://i.etsystatic.com/10873356/r/il/b9bc09/4635864392/il_300x300.4635864392_2s16.jpg)
- ![May include: A pair of light blue macrame earrings with a diamond shape and fringe. The earrings are made with a light blue cord and have a gold-tone metal hook.](https://i.etsystatic.com/10873356/r/il/4df1ed/4635864424/il_300x300.4635864424_p2sq.jpg)
- ![May include: Two pairs of white tassel earrings with silver triangle frames. The tassels are made of white string with small colorful flecks throughout.](https://i.etsystatic.com/10873356/r/il/7dcb75/4635864430/il_300x300.4635864430_1mnu.jpg)
- ![May include: A pair of gold and teal blue tassel earrings. The earrings are made of a thin gold wire that forms a diamond shape. The diamond shape is filled with teal blue tassels. The earrings are hanging from gold hooks.](https://i.etsystatic.com/10873356/r/il/7ab5b1/4635864428/il_300x300.4635864428_d3ja.jpg)
- ![May include: A pair of mustard yellow macrame earrings with a gold-toned metal frame and a tassel design.](https://i.etsystatic.com/10873356/r/il/9de025/4635864434/il_300x300.4635864434_et2o.jpg)
- ![May include: Two pairs of earrings with gold hoops and fringe details. One pair has brown fringe and the other pair has white fringe.](https://i.etsystatic.com/10873356/r/il/1a19f4/4635864724/il_300x300.4635864724_lz7q.jpg)
- ![May include: Six pairs of handmade tassel earrings with square metal frames. The earrings are in various colors including yellow, teal, white, light green, and orange.](https://i.etsystatic.com/10873356/r/il/8b6c79/4635864748/il_300x300.4635864748_eru9.jpg)