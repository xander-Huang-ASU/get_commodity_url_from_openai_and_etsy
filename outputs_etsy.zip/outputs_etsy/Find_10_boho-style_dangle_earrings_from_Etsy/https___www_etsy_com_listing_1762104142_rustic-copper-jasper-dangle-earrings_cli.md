[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1762104142/rustic-copper-jasper-dangle-earrings?amp;click_sum=d5215a94&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3&amp;sts=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Jewelry](https://www.etsy.com/c/jewelry?amp%3Bclick_sum=d5215a94&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-0)
- [Earrings](https://www.etsy.com/c/jewelry/earrings?amp%3Bclick_sum=d5215a94&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-1)
- [Dangle & Drop Earrings](https://www.etsy.com/c/jewelry/earrings/dangle-earrings?amp%3Bclick_sum=d5215a94&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-2)


Add to Favorites


- ![May include: Copper dangle earrings with three turquoise green gemstone beads on each earring. The earrings have a hammered copper circle at the top of each earring.](https://i.etsystatic.com/31739587/r/il/e2c739/6245127993/il_794xN.6245127993_og0o.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![May include: Copper earrings with three turquoise green beads on each earring. The earrings have a hammered copper circle at the top of each earring.](https://i.etsystatic.com/31739587/r/il/b5bb15/6245131063/il_794xN.6245131063_ob55.jpg)
- ![May include: Copper earrings with turquoise beads. The earrings have a hammered copper hoop and three turquoise beads hanging from the hoop.](https://i.etsystatic.com/31739587/r/il/473591/6197100434/il_794xN.6197100434_rydi.jpg)
- ![May include: A pair of copper earrings with green and white gemstone beads. The earrings have a simple design with a small copper hoop at the top and three beads hanging below.](https://i.etsystatic.com/31739587/r/il/3f8284/6245128003/il_794xN.6245128003_n2vl.jpg)
- ![May include: Copper hoop earrings with three turquoise green beads hanging from each hoop.](https://i.etsystatic.com/31739587/r/il/34fa37/6245127751/il_794xN.6245127751_sp8j.jpg)
- ![May include: Copper earrings with turquoise green beads and a copper circle charm.](https://i.etsystatic.com/31739587/r/il/f4db2a/6197100326/il_794xN.6197100326_2ua2.jpg)
- ![May include: Copper earrings with turquoise green beads and hammered copper hoops.](https://i.etsystatic.com/31739587/r/il/72479c/6197100386/il_794xN.6197100386_qr2h.jpg)

- ![May include: Copper dangle earrings with three turquoise green gemstone beads on each earring. The earrings have a hammered copper circle at the top of each earring.](https://i.etsystatic.com/31739587/r/il/e2c739/6245127993/il_75x75.6245127993_og0o.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/IMG_5448_wl2kbu.jpg)

- ![May include: Copper earrings with three turquoise green beads on each earring. The earrings have a hammered copper circle at the top of each earring.](https://i.etsystatic.com/31739587/c/2250/1786/0/488/il/b5bb15/6245131063/il_75x75.6245131063_ob55.jpg)
- ![May include: Copper earrings with turquoise beads. The earrings have a hammered copper hoop and three turquoise beads hanging from the hoop.](https://i.etsystatic.com/31739587/r/il/473591/6197100434/il_75x75.6197100434_rydi.jpg)
- ![May include: A pair of copper earrings with green and white gemstone beads. The earrings have a simple design with a small copper hoop at the top and three beads hanging below.](https://i.etsystatic.com/31739587/r/il/3f8284/6245128003/il_75x75.6245128003_n2vl.jpg)
- ![May include: Copper hoop earrings with three turquoise green beads hanging from each hoop.](https://i.etsystatic.com/31739587/r/il/34fa37/6245127751/il_75x75.6245127751_sp8j.jpg)
- ![May include: Copper earrings with turquoise green beads and a copper circle charm.](https://i.etsystatic.com/31739587/r/il/f4db2a/6197100326/il_75x75.6197100326_2ua2.jpg)
- ![May include: Copper earrings with turquoise green beads and hammered copper hoops.](https://i.etsystatic.com/31739587/r/il/72479c/6197100386/il_75x75.6197100386_qr2h.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1762104142%2Frustic-copper-jasper-dangle-earrings%23report-overlay-trigger)

20+ views in the last 24 hours

Price:$28.00


Loading


# Rustic Copper Jasper Dangle Earrings: Boho Gemstone Jewelry

Made by [AdriaArtistry](https://www.etsy.com/shop/AdriaArtistry)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1762104142/rustic-copper-jasper-dangle-earrings?amp;click_sum=d5215a94&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3&amp;sts=1#reviews)

Arrives soon! Get it by

Nov 13-17


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Made by [AdriaArtistry](https://www.etsy.com/shop/AdriaArtistry)

- Materials: Copper

- Gemstone: Jasper

- Location: Earlobe

- Closure: Ear wire

- Style: Boho & hippie

- Drop length: 1.75 Inches; Length: 1.75 Inches


- Made to Order


These earrings made of imperial jasper and copper have a rustic charm. The textured copper ring beautifully complements the cool blue, green, and tan shades of the jasper stones that hang below. They are lightweight and come with handcrafted ear wires. Perfect for making a statement!

EARRING FEATURES

Total Length: Approximately 1.75 inches

Gemstone: Imperial Jasper

Metal: Antiqued Copper

♥ All orders come beautifully hand-packaged with care, making it the perfect gift for yourself or someone special.

♥ Each piece is handmade with love in my home studio in Rockaway, NJ.


## Shipping and return policies

Loading


- Order today to get by

**Nov 13-17**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges not accepted




But please contact me if you have problems with your order


- Ships from: **Rockaway, NJ**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

## Reviews for this item (10)

5.0/5

item average

5.0Item quality

5.0Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Fast shipping

Beautiful

Love it

Well packaged

Would recommend

Perfect condition

Very pretty


Filter by category


Shipping & Packaging (3)


Appearance (4)


Quality (4)


Description accuracy (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Victoria Rogers](https://www.etsy.com/people/vmielke?ref=l_review)
Oct 22, 2025


Great packaging ! so very perfect and nice ! Will certainly order again , also fast shipping !



[Victoria Rogers](https://www.etsy.com/people/vmielke?ref=l_review)
Oct 22, 2025


5 out of 5 stars
5

This item

[tina wiff](https://www.etsy.com/people/tinawiff?ref=l_review)
May 26, 2025


Just so perfect in every way



[tina wiff](https://www.etsy.com/people/tinawiff?ref=l_review)
May 26, 2025


5 out of 5 stars
5

This item

[Annette](https://www.etsy.com/people/alsn60?ref=l_review)
Apr 29, 2025


Love these earrings! They are so pretty.



[Annette](https://www.etsy.com/people/alsn60?ref=l_review)
Apr 29, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/7eca29/70483453/iusa_75x75.70483453_or6f.jpg?version=0)

[Sarah Fuller](https://www.etsy.com/people/u25rdssf?ref=l_review)
Apr 27, 2025


These earrings are a beautiful, quality item!



![](https://i.etsystatic.com/iusa/7eca29/70483453/iusa_75x75.70483453_or6f.jpg?version=0)

[Sarah Fuller](https://www.etsy.com/people/u25rdssf?ref=l_review)
Apr 27, 2025


View all reviews for this item

### Photos from reviews

![cheryl added a photo of their purchase](https://i.etsystatic.com/iap/a6fba2/6708027556/iap_300x300.6708027556_gt0st9vi.jpg?version=0)

[![AdriaArtistry](https://i.etsystatic.com/iusa/efd791/92496737/iusa_75x75.92496737_a50m.jpg?version=0)](https://www.etsy.com/shop/AdriaArtistry?ref=shop_profile&listing_id=1762104142)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[AdriaArtistry](https://www.etsy.com/shop/AdriaArtistry?ref=shop_profile&listing_id=1762104142)

[Owned by Adria Bieksha](https://www.etsy.com/shop/AdriaArtistry?ref=shop_profile&listing_id=1762104142) \|

Rockaway, New Jersey

4.9
(264)


805 sales

2.5 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=20765798&referring_id=1762104142&referring_type=listing&recipient_id=20765798&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyMDc2NTc5ODoxNzYyODE3NDUyOmZmNWQwMmE5NmQyZDFlNjNkOWI3NTE5NjJhNDY0OTQw&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1762104142%2Frustic-copper-jasper-dangle-earrings%3Famp%253Bclick_sum%3Dd5215a94%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bsts%3D1)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

Loading recommendations

Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 9, 2025


[311 favorites](https://www.etsy.com/listing/1762104142/rustic-copper-jasper-dangle-earrings/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Jewelry](https://www.etsy.com/c/jewelry?amp%3Bclick_sum=d5215a94&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Earrings](https://www.etsy.com/c/jewelry/earrings?amp%3Bclick_sum=d5215a94&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Dangle & Drop Earrings](https://www.etsy.com/c/jewelry/earrings/dangle-earrings?amp%3Bclick_sum=d5215a94&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Handbags

[Shop Elegant Gold Clutch](https://www.etsy.com/market/elegant_gold_clutch)

Shopping

[Funny Chicken Badge Reel for Sale](https://www.etsy.com/market/funny_chicken_badge_reel)

Outdoor & Garden

[Villager Fresh Mint for Sale](https://www.etsy.com/market/villager_fresh_mint)

Paper

[Coachella Vip Passes Printable - US](https://www.etsy.com/market/coachella_vip_passes_printable)

Earrings

[Thick Small Hoop Earrings - Black Hoops Earrings - Ear Hoops - Black Earrings - Thick Hoops - Sleeper Earrings - Simple Hoops - Huggie Hoops by ZlataJewels](https://www.etsy.com/listing/1171100719/thick-small-hoop-earrings-black-hoops) [Sterling Silver Healing Hand Hamsa Dangle Earrings](https://www.etsy.com/listing/4324301002/sterling-silver-healing-hand-hamsa) [Black Gray Ivory Tagua Nut Earrings - Earrings](https://www.etsy.com/listing/1177205373/black-gray-ivory-tagua-nut-earrings) [Set of 3 Pairs by GinasVintageBoutique](https://www.etsy.com/listing/1242463802/vintage-pierced-earrings-set-of-3-pairs) [Dorel - US](https://www.etsy.com/market/dorel)

Totes

[Personalised Work Bag - Totes](https://www.etsy.com/listing/1761782003/personalised-jute-lunch-bag-with-name)

Kitchen & Dining

[Buy Lucky Charm Cutter Online](https://www.etsy.com/market/lucky_charm_cutter) [Minimalist Plates for Sale](https://www.etsy.com/market/minimalist_plates) [The Dadalorian With I Have Spoken 11 oz. Black Coffee Mug Father's Day Gift - Kitchen & Dining](https://www.etsy.com/listing/1462452898/the-dadalorian-with-i-have-spoken-11-oz)

Yarn & Fiber

[Buy Yarnart Denim Online](https://www.etsy.com/market/yarnart_denim)

Car Parts & Accessories

[Vtr - US](https://www.etsy.com/market/vtr)

Jewelry

[Vintage Coro AB Rhinestone Necklace Floral Design by TheElusiveVintage](https://www.etsy.com/listing/4355676376/vintage-coro-ab-rhinestone-necklace)

Beads Gems & Cabochons

[5pcs Moon Star Charms by MedusaBoutiqueStore](https://www.etsy.com/listing/1881218959/5pcs-moon-star-charms-acrylic-moon)

Rings

[Hexagon Blue Sandstone 14K Rose Gold 925 Silver Ring Engagement Ring Wedding Ring Dainty Ring Promise Ring Statement Ring Birthday Gift by TravelBugJewelry](https://www.etsy.com/listing/1825695941/hexagon-blue-sandstone-14k-rose-gold-925)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1762104142%2Frustic-copper-jasper-dangle-earrings%3Famp%253Bclick_sum%3Dd5215a94%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bsts%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgxNzQ1Mjo2MzJkNGU1NDcxODkyZTY2YjViOTk4MTUwMDgxOTRlNQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1762104142%2Frustic-copper-jasper-dangle-earrings%3Famp%253Bclick_sum%3Dd5215a94%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bsts%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1762104142/rustic-copper-jasper-dangle-earrings?amp;click_sum=d5215a94&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3&amp;sts=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1762104142%2Frustic-copper-jasper-dangle-earrings%3Famp%253Bclick_sum%3Dd5215a94%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bsts%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![May include: Copper dangle earrings with three turquoise green gemstone beads on each earring. The earrings have a hammered copper circle at the top of each earring.](https://i.etsystatic.com/31739587/r/il/e2c739/6245127993/il_300x300.6245127993_og0o.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/IMG_5448_wl2kbu.jpg)

- ![May include: Copper earrings with three turquoise green beads on each earring. The earrings have a hammered copper circle at the top of each earring.](https://i.etsystatic.com/31739587/c/2250/2250/0/256/il/b5bb15/6245131063/il_300x300.6245131063_ob55.jpg)
- ![May include: Copper earrings with turquoise beads. The earrings have a hammered copper hoop and three turquoise beads hanging from the hoop.](https://i.etsystatic.com/31739587/r/il/473591/6197100434/il_300x300.6197100434_rydi.jpg)
- ![May include: A pair of copper earrings with green and white gemstone beads. The earrings have a simple design with a small copper hoop at the top and three beads hanging below.](https://i.etsystatic.com/31739587/r/il/3f8284/6245128003/il_300x300.6245128003_n2vl.jpg)
- ![May include: Copper hoop earrings with three turquoise green beads hanging from each hoop.](https://i.etsystatic.com/31739587/r/il/34fa37/6245127751/il_300x300.6245127751_sp8j.jpg)
- ![May include: Copper earrings with turquoise green beads and a copper circle charm.](https://i.etsystatic.com/31739587/r/il/f4db2a/6197100326/il_300x300.6197100326_2ua2.jpg)
- ![May include: Copper earrings with turquoise green beads and hammered copper hoops.](https://i.etsystatic.com/31739587/r/il/72479c/6197100386/il_300x300.6197100386_qr2h.jpg)

- ![](https://i.etsystatic.com/iap/a6fba2/6708027556/iap_640x640.6708027556_gt0st9vi.jpg?version=0)











5 out of 5 stars



More beautiful in person . It's exactly what I was looking for. Lightweight yet quality..


















Mar 11, 2025




[cheryl smelson](https://www.etsy.com/people/7wesbinsuq8n3uvh)













Purchased item:

[![Rustic Copper Jasper Dangle Earrings: Boho Gemstone Jewelry](https://i.etsystatic.com/31739587/r/il/e2c739/6245127993/il_170x135.6245127993_og0o.jpg)\\
\\
Rustic Copper Jasper Dangle Earrings: Boho Gemstone Jewelry\\
\\
$28.00](https://www.etsy.com/listing/1762104142/rustic-copper-jasper-dangle-earrings?ref=ap-listing)





Purchased item:

[![Rustic Copper Jasper Dangle Earrings: Boho Gemstone Jewelry](https://i.etsystatic.com/31739587/r/il/e2c739/6245127993/il_170x135.6245127993_og0o.jpg)\\
\\
Rustic Copper Jasper Dangle Earrings: Boho Gemstone Jewelry\\
\\
$28.00](https://www.etsy.com/listing/1762104142/rustic-copper-jasper-dangle-earrings?ref=ap-listing)