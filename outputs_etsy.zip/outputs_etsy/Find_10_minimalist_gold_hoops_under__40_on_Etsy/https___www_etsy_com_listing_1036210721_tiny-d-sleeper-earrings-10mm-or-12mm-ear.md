[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?amp;click_sum=f980c13d&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;sts=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Jewelry](https://www.etsy.com/c/jewelry?amp%3Bclick_sum=f980c13d&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-0)
- [Earrings](https://www.etsy.com/c/jewelry/earrings?amp%3Bclick_sum=f980c13d&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-1)
- [Threader Earrings](https://www.etsy.com/c/jewelry/earrings/threader-earrings?amp%3Bclick_sum=f980c13d&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-2)

Bestseller

This item has had a high sales volume over the past 6 months.



Add to Favorites


- ![May include: Close-up view of three pairs of small, hammered metal hoop earrings displayed on a white ceramic dish. Each pair is shown in a different metallic color: silver, rose gold, and gold. The earrings have a simple, minimalist design, with a slightly irregular, hammered texture.  The hoops are open at the top, and appear to be crafted from a thin gauge of metal. The image showcases the subtle variations in color and texture of the earrings.](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_794xN.5072824089_7or0.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver image 2](https://i.etsystatic.com/9687561/r/il/80239f/6710176743/il_794xN.6710176743_e6bx.jpg)
- ![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver image 3](https://i.etsystatic.com/9687561/r/il/cefbc7/7289158525/il_794xN.7289158525_eqh0.jpg)
- ![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver image 4](https://i.etsystatic.com/9687561/r/il/e06b68/7241118740/il_794xN.7241118740_bvsi.jpg)
- ![May include: Close-up view of an assortment of small, minimalist hoop earrings displayed on a white square dish. The hoops are in silver, rose gold, and gold finishes, showcasing a variety of metallic hues. Each earring features a simple, half-circle design, crafted with delicate, thin metal. The earrings are small and understated, ideal for everyday wear or as subtle accents.](https://i.etsystatic.com/9687561/r/il/985f16/5024601756/il_794xN.5024601756_1rdi.jpg)
- ![May include: A pair of minimalist hammered sterling silver hoop earrings.  These small, simple earrings feature a slightly textured, curved, open-hoop design. The hoops are crafted from smooth, polished silver metal, giving them a subtle, elegant look.  These delicate earrings are perfect for everyday wear or special occasions. The earrings are shown on a white background.](https://i.etsystatic.com/9687561/r/il/e63552/5477601514/il_794xN.5477601514_s4qz.jpg)
- ![May include: A pair of gold hammered open hoop earrings.  These minimalist earrings have a simple, slightly irregular, curved shape. The hoops are crafted from 14k gold and feature a textured, hammered finish. The earrings are shown against a plain white background.](https://i.etsystatic.com/9687561/r/il/ef0e07/5525708029/il_794xN.5525708029_ec7l.jpg)
- ![May include: Rose gold hammered open half-circle earrings. These minimalist earrings have a simple, modern design.  The smooth, slightly textured metal creates a subtle, elegant look. The earrings are shown on a white background.](https://i.etsystatic.com/9687561/r/il/ae5493/5525549131/il_794xN.5525549131_for1.jpg)
- ![May include: Close-up view of two hammered silver ear cuffs. One cuff is shown closed, the other open.  The text 'Closed' appears above the closed cuff and 'Open' above the open cuff. Both cuffs have a simple, curved design.  These minimalist silver ear cuffs are ideal for everyday wear.](https://i.etsystatic.com/9687561/r/il/5d964d/6092643061/il_794xN.6092643061_qdi8.jpg)
- ![May include: Close-up view of gold half hoop earrings displayed in a silver tin with a mandala design on the lid.  The earrings are presented on a gray card with the logo 'Laura B Elements.'  Accompanying cards provide care instructions and details about the handcrafted jewelry, emphasizing its unique and lasting quality. The text on the cards includes 'Laura B Elements,' 'Care,' and 'Love.' ](https://i.etsystatic.com/9687561/r/il/7bf5d3/5226418660/il_794xN.5226418660_6ntc.jpg)

- ![May include: Close-up view of three pairs of small, hammered metal hoop earrings displayed on a white ceramic dish. Each pair is shown in a different metallic color: silver, rose gold, and gold. The earrings have a simple, minimalist design, with a slightly irregular, hammered texture.  The hoops are open at the top, and appear to be crafted from a thin gauge of metal. The image showcases the subtle variations in color and texture of the earrings.](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_75x75.5072824089_7or0.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/file_nklqjm.jpg)

- ![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver image 2](https://i.etsystatic.com/9687561/r/il/80239f/6710176743/il_75x75.6710176743_e6bx.jpg)
- ![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver image 3](https://i.etsystatic.com/9687561/r/il/cefbc7/7289158525/il_75x75.7289158525_eqh0.jpg)
- ![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver image 4](https://i.etsystatic.com/9687561/r/il/e06b68/7241118740/il_75x75.7241118740_bvsi.jpg)
- ![May include: Close-up view of an assortment of small, minimalist hoop earrings displayed on a white square dish. The hoops are in silver, rose gold, and gold finishes, showcasing a variety of metallic hues. Each earring features a simple, half-circle design, crafted with delicate, thin metal. The earrings are small and understated, ideal for everyday wear or as subtle accents.](https://i.etsystatic.com/9687561/r/il/985f16/5024601756/il_75x75.5024601756_1rdi.jpg)
- ![May include: A pair of minimalist hammered sterling silver hoop earrings.  These small, simple earrings feature a slightly textured, curved, open-hoop design. The hoops are crafted from smooth, polished silver metal, giving them a subtle, elegant look.  These delicate earrings are perfect for everyday wear or special occasions. The earrings are shown on a white background.](https://i.etsystatic.com/9687561/r/il/e63552/5477601514/il_75x75.5477601514_s4qz.jpg)
- ![May include: A pair of gold hammered open hoop earrings.  These minimalist earrings have a simple, slightly irregular, curved shape. The hoops are crafted from 14k gold and feature a textured, hammered finish. The earrings are shown against a plain white background.](https://i.etsystatic.com/9687561/r/il/ef0e07/5525708029/il_75x75.5525708029_ec7l.jpg)
- ![May include: Rose gold hammered open half-circle earrings. These minimalist earrings have a simple, modern design.  The smooth, slightly textured metal creates a subtle, elegant look. The earrings are shown on a white background.](https://i.etsystatic.com/9687561/r/il/ae5493/5525549131/il_75x75.5525549131_for1.jpg)
- ![May include: Close-up view of two hammered silver ear cuffs. One cuff is shown closed, the other open.  The text 'Closed' appears above the closed cuff and 'Open' above the open cuff. Both cuffs have a simple, curved design.  These minimalist silver ear cuffs are ideal for everyday wear.](https://i.etsystatic.com/9687561/r/il/5d964d/6092643061/il_75x75.6092643061_qdi8.jpg)
- ![May include: Close-up view of gold half hoop earrings displayed in a silver tin with a mandala design on the lid.  The earrings are presented on a gray card with the logo 'Laura B Elements.'  Accompanying cards provide care instructions and details about the handcrafted jewelry, emphasizing its unique and lasting quality. The text on the cards includes 'Laura B Elements,' 'Care,' and 'Love.' ](https://i.etsystatic.com/9687561/r/il/7bf5d3/5226418660/il_75x75.5226418660_6ntc.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1036210721%2Ftiny-d-sleeper-earrings-10mm-or-12mm-ear%23report-overlay-trigger)

In 20+ carts

Price:$14.00+


Loading


# Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver

Made by [LauraBElements](https://www.etsy.com/shop/LauraBElements)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?amp;click_sum=f980c13d&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;sts=1#reviews)

Arrives soon! Get it by

Nov 14-17


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

Material


Select an option

Argentium Silver

14k Gold filled

14k Rose gold filled

Please select an option


Style


Select an option

10mm pair ($28.00)

10mm Left ($14.00)

10mm Right ($14.00)

12mm Pair ($28.00)

12mm Left ($14.00)

12mm Right ($14.00)

Please select an option


Quantity



123456789101112131415161718192021222324252627282930313233343536

You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Made by [LauraBElements](https://www.etsy.com/shop/LauraBElements)

- Materials: Rose gold, Silver, Yellow gold

- Sustainable features: recycled metal. Items may include additional materials or use methods that aren't considered sustainable features on our site. [Learn more](https://help.etsy.com/hc/articles/15532793357847)

- Location: Earlobe

- Closure: Threader

- Style: Minimalist

- Length: 1/2 Inches


- Made to Order


Little half circle D shaped ear hugging hoops hammered down one side and thread through the earlobe. Backless everyday live in 24/7 style earrings, comfortable enough to sleep in. Adjustable by squeezing the ends together for a snug fit. Hand formed from 19 gauge wire, slightly thicker than traditional ear wires. This gives you a little bolder look and helps to keep their form while inserting and removing. Modern minimalist capsule wardrobe must-have. Two sizes to choose from for multiple piercings you can make a fun ear stack.

Choose from 1/2" (12mm) standard, or 3/8" (10mm) for second piercing or small, thin, low pierced earlobes for a snugger look. Shown in the 1/2" on video. Picture with two on are both sizes with the 3/8" in the top piercing.

14k gold or rose gold filled, or Argentium silver (935 non-tarnishing silver) making these a great option for sensitive skin. Hypoallergenic and nickle free. \*shop other sizes with my shop link below.

Comes wrapped in a hand stamped metal tin ready for gift giving and storing in when not being worn. Complete with polishing cloth and instructions on how to care for your new jewelry.

SHOP MY COLLECTION

[https://laurabelements.etsy.com](https://laurabelements.etsy.com/)

I use 100% USA SOURCED RECYCLED METALS

Each piece is handmade so there may be slight variations in size, texture, and detail making it uniquely yours. You will always receive a carefully crafted piece of jewelry created by Laura in her Seattle area studio.

SHIPPING DETAILS

All orders ship from my Washington studio via First-class USPS service with tracking. Priority mail upgrades are available for $8

CONTACT ME

any questions??? Feel free to contact me 7 days a week

100% SMILE GUARANTEE

Top quality materials, excellent craftsmanship and customer satisfaction is my standard practice. I want you 100% happy with your purchase from Laura B Elements. If it isn’t exactly what you expected please message me for a full refund or easy exchange.

Thanks so much for stopping by Laura B Elements

WHAT IS GOLD FILL

It is a genuine layer of gold or silver permanently bonded onto its base metal with heat and pressure. The bond produced is a permanent one. It is far superior to plating, has much more value, and the finish can last many years if cared for. People with sensitive skin can wear gold filled jewelry.

WHAT IS ARGENTIUM SILVER

It was developed specifically to combat the tarnish that occurs as silver oxidizes when it comes into contact with air, which is a major drawback for all who love silver. It contains a greater amount of pure silver (935 which contains 93.5% pure silver) making it more expensive than sterling silver, tarnish resistance and more durable.


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-17**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 14 days


- Ships from: **Woodinville, WA**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## Reviews for this item (797)

4.9/5

item average

5.0Item quality

4.9Shipping

4.9Customer service

98%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Love it

Cute

Comfortable

Beautiful

Fast shipping

Great quality

Well packaged


Filter by category


Appearance (211)


Comfort (199)


Shipping & Packaging (167)


Quality (170)


Description accuracy (103)


Sizing & Fit (74)


Ease of use (69)


Seller service (54)


Value (10)


Condition (5)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Mary-Grace Borck-Wells](https://www.etsy.com/people/gcf78ki3yel8vxa7?ref=l_review)
Nov 10, 2025


Thought my order was lost and reached out to Laura. She immediately got back to me. Once I got my package, the hoops are perfect and the packaging is thoughtful. Perfect!



[Mary-Grace Borck-Wells](https://www.etsy.com/people/gcf78ki3yel8vxa7?ref=l_review)
Nov 10, 2025


5 out of 5 stars
5

This item

[Sara Berwald](https://www.etsy.com/people/d7zfx75k8e0ivm76?ref=l_review)
Nov 10, 2025


My ears are highly sensitive (legit cannot wear anything for some reason), but I can wear these! I can wear them all day and even sleep on them! I’m buying more so I can stack my piercings.



[Sara Berwald](https://www.etsy.com/people/d7zfx75k8e0ivm76?ref=l_review)
Nov 10, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/53eef4/35230756/iusa_75x75.35230756_i5q3.jpg?version=0)

[harley colquhoun](https://www.etsy.com/people/harleyann2639?ref=l_review)
Nov 9, 2025


beautiful and lightweight, exactly what i was looking for



![](https://i.etsystatic.com/iusa/53eef4/35230756/iusa_75x75.35230756_i5q3.jpg?version=0)

[harley colquhoun](https://www.etsy.com/people/harleyann2639?ref=l_review)
Nov 9, 2025


5 out of 5 stars
5

This item

[MAureen](https://www.etsy.com/people/134yjgb2ne712kxv?ref=l_review)
Nov 8, 2025


I love these earrings, they are perfect
Easy to put on and feel weightless. good quality too.



[MAureen](https://www.etsy.com/people/134yjgb2ne712kxv?ref=l_review)
Nov 8, 2025


View all reviews for this item

### Photos from reviews

![starr added a photo of their purchase](https://i.etsystatic.com/iap/a38572/7324590442/iap_300x300.7324590442_sl2miotg.jpg?version=0)

![L added a photo of their purchase](https://i.etsystatic.com/iap/2de543/7352893961/iap_300x300.7352893961_5mzohy22.jpg?version=0)

![Sydni added a photo of their purchase](https://i.etsystatic.com/iap/33fb7f/7358959292/iap_300x300.7358959292_joi06z8z.jpg?version=0)

![Allyson added a photo of their purchase](https://i.etsystatic.com/iap/068c7c/7316749450/iap_300x300.7316749450_65q0eubw.jpg?version=0)

![Annabelle added a photo of their purchase](https://i.etsystatic.com/iap/0d8442/7409785623/iap_300x300.7409785623_anwljg4g.jpg?version=0)

![Fyote added a photo of their purchase](https://i.etsystatic.com/iap/1c1e07/7323321441/iap_300x300.7323321441_35l7k3yk.jpg?version=0)

![Kate added a photo of their purchase](https://i.etsystatic.com/iap/5f95eb/7298118209/iap_300x300.7298118209_5mko2keu.jpg?version=0)

![ktimpson added a photo of their purchase](https://i.etsystatic.com/iap/3e1d58/7181502558/iap_300x300.7181502558_3gerznx8.jpg?version=0)

![Karin added a photo of their purchase](https://i.etsystatic.com/iap/7a3c21/7231890160/iap_300x300.7231890160_93bcw6pr.jpg?version=0)

![Kate added a photo of their purchase](https://i.etsystatic.com/iap/c122a0/7304006231/iap_300x300.7304006231_o4oq7rs2.jpg?version=0)

![Lindsay added a photo of their purchase](https://i.etsystatic.com/iap/d4f43d/7123376543/iap_300x300.7123376543_e6z0vzrb.jpg?version=0)

![maileeturner added a photo of their purchase](https://i.etsystatic.com/iap/7e22df/7208045518/iap_300x300.7208045518_o960e7dd.jpg?version=0)

![aleecehayes added a photo of their purchase](https://i.etsystatic.com/iap/5e7164/7020250103/iap_300x300.7020250103_36p93adw.jpg?version=0)

![Christy added a photo of their purchase](https://i.etsystatic.com/iap/af15ea/7222607005/iap_300x300.7222607005_1lz3upyn.jpg?version=0)

![Ashley added a photo of their purchase](https://i.etsystatic.com/iap/cd3181/7132321194/iap_300x300.7132321194_oziekwrk.jpg?version=0)

![Sandra added a photo of their purchase](https://i.etsystatic.com/iap/48e33a/7235777125/iap_300x300.7235777125_tplyhuym.jpg?version=0)

![Amanda added a photo of their purchase](https://i.etsystatic.com/iap/a6ba49/7060687844/iap_300x300.7060687844_wiv5faew.jpg?version=0)

![Christina added a photo of their purchase](https://i.etsystatic.com/iap/a84796/7076257940/iap_300x300.7076257940_nfi24zck.jpg?version=0)

![Dawn added a photo of their purchase](https://i.etsystatic.com/iap/79b731/6715831874/iap_300x300.6715831874_oz9f0e50.jpg?version=0)

![Alexzandria added a photo of their purchase](https://i.etsystatic.com/iap/d743ab/6907726447/iap_300x300.6907726447_583o0dho.jpg?version=0)

[![LauraBElements](https://i.etsystatic.com/iusa/962bbf/61633020/iusa_75x75.61633020_9nm7.jpg?version=0)](https://www.etsy.com/shop/LauraBElements?ref=shop_profile&listing_id=1036210721)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[LauraBElements](https://www.etsy.com/shop/LauraBElements?ref=shop_profile&listing_id=1036210721)

[Owned by Laura Bradford](https://www.etsy.com/shop/LauraBElements?ref=shop_profile&listing_id=1036210721) \|

Snohomish, Washington

4.9
(2.6k)


9.8k sales

11 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=50135835&referring_id=1036210721&referring_type=listing&recipient_id=50135835&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo1MDEzNTgzNToxNzYyODE5Njc5Ojg0YTc0OThiNDQ2ZDI0MGJlNzkyZmRjOWY2OTkzMTkz&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1036210721%2Ftiny-d-sleeper-earrings-10mm-or-12mm-ear%3Famp%253Bclick_sum%3Df980c13d%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bsts%3D1)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

Loading recommendations

Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 10, 2025


[9419 favorites](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Jewelry](https://www.etsy.com/c/jewelry?amp%3Bclick_sum=f980c13d&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Earrings](https://www.etsy.com/c/jewelry/earrings?amp%3Bclick_sum=f980c13d&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Threader Earrings](https://www.etsy.com/c/jewelry/earrings/threader-earrings?amp%3Bclick_sum=f980c13d&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Shopping

[Buy Custom His And Hers Sweater Online](https://www.etsy.com/market/custom_his_and_hers_sweater) [Rivendell Play Mat Magic Tcg - US](https://www.etsy.com/market/rivendell_play_mat_magic_tcg)

Patterns & How To

[Mitten Quilt Block for Sale](https://www.etsy.com/market/mitten_quilt_block)

Knives & Cutting Tools

[Buy Work Sharp Professional Precision Adjust Stones Online](https://www.etsy.com/market/work_sharp_professional_precision_adjust_stones)

Accessories

[Buy Montana Wildflower Bouquet Online](https://www.etsy.com/market/montana_wildflower_bouquet)

Brooches Pins & Clips

[Shop Shrug Clip](https://www.etsy.com/market/shrug_clip)

Suit & Tie Accessories

[Buy Nail Tie Clip Online](https://www.etsy.com/market/nail_tie_clip)

Earrings

[Buy 16g Surgical Steel Cartilage Online](https://www.etsy.com/market/16g_surgical_steel_cartilage) [Buy Chic Ear Cuff Online](https://www.etsy.com/market/chic_ear_cuff) [Ear cuff - Single Ring Beaded earring cuff no piercing required - sterling silver](https://www.etsy.com/listing/777575798/ear-cuff-single-ring-beaded-earring-cuff) [Steampunk Earrings Jewelry Hippie Festival Earrings Chains Steampunk Accessories Boho Earring Cyberpunk Gothic Shell Gold Earrings New Shell](https://www.etsy.com/listing/1472681674/steampunk-earrings-jewelry-hippie)

Baby & Child Care

[Eat sleep repeat baby bib - Baby & Child Care](https://www.etsy.com/listing/1190399445/eat-sleep-repeat-baby-bib)

Kitchen Supplies

[Congrats Cake Topper - US](https://www.etsy.com/market/congrats_cake_topper)

Dolls & Miniatures

[1:12 Dollhouse miniature Eagle Lady gold-filled picture](https://www.etsy.com/listing/1107595167/112-dollhouse-miniature-eagle-lady-gold)

Closures & Fasteners

[Boots With Rivets - US](https://www.etsy.com/market/boots_with_rivets)

Curtains & Window Treatments

[Cute Sheer Curtains - US](https://www.etsy.com/market/cute_sheer_curtains)

Hair Accessories

[Buy Embroidery Hair Bow Online](https://www.etsy.com/market/embroidery_hair_bow)

Necklaces

[Sterling Silver Our Lady of Guadalupe Medal](https://www.etsy.com/listing/264675111/sterling-silver-our-lady-of-guadalupe)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1036210721%2Ftiny-d-sleeper-earrings-10mm-or-12mm-ear%3Famp%253Bclick_sum%3Df980c13d%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bsts%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgxOTY3OTo1Y2I4YTcyODlmMjBiNzU3OWM5OTJjZDc2MGY4MWI5Nw==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1036210721%2Ftiny-d-sleeper-earrings-10mm-or-12mm-ear%3Famp%253Bclick_sum%3Df980c13d%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bsts%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?amp;click_sum=f980c13d&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;sts=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1036210721%2Ftiny-d-sleeper-earrings-10mm-or-12mm-ear%3Famp%253Bclick_sum%3Df980c13d%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bsts%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for LauraBElements

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: not accepted

Please contact the seller if you have any problems with your order.

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading


- Item in the photo is in **Material: Argentium Silver**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Material: 14k Gold filled**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Material: 14k Rose gold filled**




Select this option








Option selected!













This option is sold out.



Click to zoom

- ![May include: Close-up view of three pairs of small, hammered metal hoop earrings displayed on a white ceramic dish. Each pair is shown in a different metallic color: silver, rose gold, and gold. The earrings have a simple, minimalist design, with a slightly irregular, hammered texture.  The hoops are open at the top, and appear to be crafted from a thin gauge of metal. The image showcases the subtle variations in color and texture of the earrings.](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_300x300.5072824089_7or0.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/file_nklqjm.jpg)

- ![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver image 2](https://i.etsystatic.com/9687561/r/il/80239f/6710176743/il_300x300.6710176743_e6bx.jpg)
- ![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver image 3](https://i.etsystatic.com/9687561/r/il/cefbc7/7289158525/il_300x300.7289158525_eqh0.jpg)
- ![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver image 4](https://i.etsystatic.com/9687561/r/il/e06b68/7241118740/il_300x300.7241118740_bvsi.jpg)
- ![May include: Close-up view of an assortment of small, minimalist hoop earrings displayed on a white square dish. The hoops are in silver, rose gold, and gold finishes, showcasing a variety of metallic hues. Each earring features a simple, half-circle design, crafted with delicate, thin metal. The earrings are small and understated, ideal for everyday wear or as subtle accents.](https://i.etsystatic.com/9687561/r/il/985f16/5024601756/il_300x300.5024601756_1rdi.jpg)
- ![May include: A pair of minimalist hammered sterling silver hoop earrings.  These small, simple earrings feature a slightly textured, curved, open-hoop design. The hoops are crafted from smooth, polished silver metal, giving them a subtle, elegant look.  These delicate earrings are perfect for everyday wear or special occasions. The earrings are shown on a white background.](https://i.etsystatic.com/9687561/r/il/e63552/5477601514/il_300x300.5477601514_s4qz.jpg)
- ![May include: A pair of gold hammered open hoop earrings.  These minimalist earrings have a simple, slightly irregular, curved shape. The hoops are crafted from 14k gold and feature a textured, hammered finish. The earrings are shown against a plain white background.](https://i.etsystatic.com/9687561/r/il/ef0e07/5525708029/il_300x300.5525708029_ec7l.jpg)
- ![May include: Rose gold hammered open half-circle earrings. These minimalist earrings have a simple, modern design.  The smooth, slightly textured metal creates a subtle, elegant look. The earrings are shown on a white background.](https://i.etsystatic.com/9687561/r/il/ae5493/5525549131/il_300x300.5525549131_for1.jpg)
- ![May include: Close-up view of two hammered silver ear cuffs. One cuff is shown closed, the other open.  The text 'Closed' appears above the closed cuff and 'Open' above the open cuff. Both cuffs have a simple, curved design.  These minimalist silver ear cuffs are ideal for everyday wear.](https://i.etsystatic.com/9687561/r/il/5d964d/6092643061/il_300x300.6092643061_qdi8.jpg)
- ![May include: Close-up view of gold half hoop earrings displayed in a silver tin with a mandala design on the lid.  The earrings are presented on a gray card with the logo 'Laura B Elements.'  Accompanying cards provide care instructions and details about the handcrafted jewelry, emphasizing its unique and lasting quality. The text on the cards includes 'Laura B Elements,' 'Care,' and 'Love.' ](https://i.etsystatic.com/9687561/r/il/7bf5d3/5226418660/il_300x300.5226418660_6ntc.jpg)

- ![](https://i.etsystatic.com/iap/a38572/7324590442/iap_640x640.7324590442_sl2miotg.jpg?version=0)

5 out of 5 stars

- Material:

14k Gold filled

- Style:

12mm Pair


Great comfortable and beautiful earring.

Oct 25, 2025


[starr](https://www.etsy.com/people/jv7xnu8yocgx1wb4)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/2de543/7352893961/iap_640x640.7352893961_5mzohy22.jpg?version=0)

5 out of 5 stars

- Material:

14k Gold filled

- Style:

12mm Pair


I purchased these earrings because I'm sensitive to metals and don't wear earrings much, even though I love them, because my lobes get so irritated. I started to worry about my piercings closing so I thought I'd try to leave something comfortable in for a bit. So far, so good!

Oct 20, 2025


[L RP](https://www.etsy.com/people/luripa)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/33fb7f/7358959292/iap_640x640.7358959292_joi06z8z.jpg?version=0)

5 out of 5 stars

- Material:

14k Rose gold filled

- Style:

10mm pair


I have waited 46 years to find these earrings. I’d recommend the 12mm unless you want them to fit pretty snugly. Nothing about them pokes uncomfortably anywhere, ever. Once you pinch them closed, you can shower with them in with no issues, even washing your hair. They are classy. They don’t jiggle when you move your head. I can sleep perfectly without removing them.

I used to never wear earrings but now I wear these every day because I don’t need to take them out.

Nov 4, 2025


[Sydni Phillips](https://www.etsy.com/people/csphillips)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/068c7c/7316749450/iap_640x640.7316749450_65q0eubw.jpg?version=0)

4 out of 5 stars

- Material:

14k Rose gold filled

- Style:

12mm Pair


These are cute & well made, but not what I hoped for. I had an 8mm similar design from somewhere else and it was too small, so I got the 12mm here. They are still SO SMALL. If you have large earlobes or your piercing is higher on your lobe, these will be snug. I've still worn them the last few days and nights, because I really want an earring to leave in that is comfortable to sleep in, but last night one fell out while sleeping. I think these would be perfect for perfectly pierced tiny ears, but I'm back to square one now looking for leave-in earrings.

![](https://i.etsystatic.com/iusa/73c3ba/21622137/iusa_75x75.21622137_bian.jpg?version=0)

Oct 23, 2025


[Allyson Orange](https://www.etsy.com/people/aorange1186)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/0d8442/7409785623/iap_640x640.7409785623_anwljg4g.jpg?version=0)

5 out of 5 stars

- Material:

14k Gold filled

- Style:

12mm Pair


They are beautiful and delicate.

Nov 5, 2025


[Annabelle](https://www.etsy.com/people/mk7lspy5)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/1c1e07/7323321441/iap_640x640.7323321441_35l7k3yk.jpg?version=0)

5 out of 5 stars

- Material:

14k Gold filled

- Style:

10mm pair


New favorite earrings! I've been searching for earrings that are comfortable to sleep in and aren't a struggle to put in, and these are perfect. They're sturdy too so I don't need to worry about accidentally bending them out of shape.

Oct 10, 2025


[Fyote](https://www.etsy.com/people/Fyote)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/5f95eb/7298118209/iap_640x640.7298118209_5mko2keu.jpg?version=0)

5 out of 5 stars

- Material:

14k Gold filled

- Style:

10mm pair


These earrings are adorable! They fit my ear perfectly and were surprisingly easy to put on. They are the perfect size, in my opinion- not too thick, very subtle- perfect for my style. Love that they don’t have a back (that would most definitely get ripped off as a mom of 2 littles). I think these would be a cute gift. The packaging is great too! I’m planning on using the little tin as either a lip balm container or using it to store earrings for travel! Very, very pleased with my purchase!!

Oct 2, 2025


[Kate Foy](https://www.etsy.com/people/katefoy8)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/3e1d58/7181502558/iap_640x640.7181502558_3gerznx8.jpg?version=0)

5 out of 5 stars

- Material:

14k Gold filled

- Style:

Single Right earring


I was able to request a smaller gauge. I really love the shape and how they feel - I forget I’m wearing it.
Plus the shape is unique.

Sep 8, 2025


[ktimpson](https://www.etsy.com/people/ktimpson)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/7a3c21/7231890160/iap_640x640.7231890160_93bcw6pr.jpg?version=0)

5 out of 5 stars

- Material:

Argentium Silver

- Style:

Pair of earrings


My sister loves the earrings I gave her as a gift!

Sep 25, 2025


[Karin](https://www.etsy.com/people/4gns3llw)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/c122a0/7304006231/iap_640x640.7304006231_o4oq7rs2.jpg?version=0)

5 out of 5 stars

- Material:

14k Gold filled

- Style:

Pair of earrings


Super cute, comfortable and stylish yet subtle. I have three lobe piercings on each ear and was looking for something that I could keep in all the time and that would go with any outfit. These are it. I bought three gold pairs and am so happy with them. Highly recommend.

Oct 4, 2025


[Kate Leathe](https://www.etsy.com/people/icin7jefm6c14ntc)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/d4f43d/7123376543/iap_640x640.7123376543_e6z0vzrb.jpg?version=0)

5 out of 5 stars

- Material:

Pair - 935 Silver


I was a little worried about the fit on these but they went in easily and are very comfortable!

Aug 2, 2025


[Lindsay](https://www.etsy.com/people/1d6nzn4l)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/7e22df/7208045518/iap_640x640.7208045518_o960e7dd.jpg?version=0)

5 out of 5 stars

- Material:

Argentium Silver

- Style:

Pair of earrings


Love love love these minimalist earrings. I wear my earrings even when I sleep so I need earrings that are hypoallergenic and easy to take on and off when I need/want to change them. These are beautiful and dainty. I will probably add a silicone backing to ensure they don’t come off when I sleep.

Sep 17, 2025


[maileeturner](https://www.etsy.com/people/maileeturner)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/5e7164/7020250103/iap_640x640.7020250103_36p93adw.jpg?version=0)

5 out of 5 stars

- Material:

14k Gold fill


Very pretty and well made! Love them!

Jun 26, 2025


[aleecehayes](https://www.etsy.com/people/aleecehayes)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/af15ea/7222607005/iap_640x640.7222607005_1lz3upyn.jpg?version=0)

5 out of 5 stars

- Material:

14k Gold filled

- Style:

Pair of earrings


Adorably and carefully packaged, with a handwritten note; these are delicate, shiny, and classy looking. They were easy to put in my old, 80s needle and ice cube piercings, and are super comfortable!

Sep 5, 2025


[Christy](https://www.etsy.com/people/2ucw2gqjsvxzi817)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/cd3181/7132321194/iap_640x640.7132321194_oziekwrk.jpg?version=0)

5 out of 5 stars

- Material:

Argentium Silver

- Style:

Pair of earrings


Super cute earrings I bought for myself and a gift for my sister! Quick shipping and great earrings.

![](https://i.etsystatic.com/iusa/e8adcc/75862999/iusa_75x75.75862999_6uf9.jpg?version=0)

Aug 22, 2025


[Ashley L](https://www.etsy.com/people/ashlouie88)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/48e33a/7235777125/iap_640x640.7235777125_tplyhuym.jpg?version=0)

5 out of 5 stars

- Material:

Argentium Silver

- Style:

Pair of earrings


These are very comfortable and very easy to insert. My only complaint is they are a lot smaller than anticipated, but I guess I'll have to order a bigger pair.

Sep 10, 2025


[Sandra Roblin](https://www.etsy.com/people/sdr127)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/a6ba49/7060687844/iap_640x640.7060687844_wiv5faew.jpg?version=0)

5 out of 5 stars

- Material:

Pair - 14k Gold fill


Perfect! They sit so comfortably in my ears! And they’re super cute! Will be purchasing more to fill the rest of my ear!

Jul 28, 2025


[Amanda](https://www.etsy.com/people/attguvj7)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/a84796/7076257940/iap_640x640.7076257940_nfi24zck.jpg?version=0)

5 out of 5 stars

- Material:

Pair - 935 Silver


Super cute! Took a sec to figure out how to put on lol but the little instruction sheet helped a lot. I love they don’t have the typical backs of earrings but still feel very durable and settled so I know they won’t fall out easily.

![](https://i.etsystatic.com/iusa/5e20b9/84021129/iusa_75x75.84021129_pi1q.jpg?version=0)

Aug 3, 2025


[Christina Mohr](https://www.etsy.com/people/blackdaisyartstudio)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/79b731/6715831874/iap_640x640.6715831874_oz9f0e50.jpg?version=0)

5 out of 5 stars

- Material:

935 Argentium Silver


I have been looking for these earrings FOR ever! Something simple, with a glint of silver and something I can wear 24/7! These are not only beautifully made - but I can see never removing them from my lobes!

Mar 14, 2025


[Dawn Faulkner](https://www.etsy.com/people/dawnfaulkner)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/d743ab/6907726447/iap_640x640.6907726447_583o0dho.jpg?version=0)

5 out of 5 stars

- Material:

14k Gold fill


I put my earrings in as SOON as they arrived. I love them!

May 13, 2025


[Alexzandria Reynolds](https://www.etsy.com/people/7vvroypm)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)

Purchased item:

[![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_170x135.5072824089_7or0.jpg)\\
\\
Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver\\
\\
$14.00](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?ref=ap-listing)