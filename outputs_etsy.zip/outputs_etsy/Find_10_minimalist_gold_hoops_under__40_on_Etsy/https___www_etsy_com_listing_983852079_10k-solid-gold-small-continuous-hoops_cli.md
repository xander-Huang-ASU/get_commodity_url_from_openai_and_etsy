[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?amp;click_sum=b4b69f84&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;pro=1&amp;sts=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Jewelry](https://www.etsy.com/c/jewelry?amp%3Bclick_sum=b4b69f84&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-0)
- [Earrings](https://www.etsy.com/c/jewelry/earrings?amp%3Bclick_sum=b4b69f84&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-1)
- [Hoop Earrings](https://www.etsy.com/c/jewelry/earrings/hoop-earrings?amp%3Bclick_sum=b4b69f84&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-2)

Bestseller

This item has had a high sales volume over the past 6 months.



Add to Favorites


- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 1](https://i.etsystatic.com/24925695/r/il/65ffa9/4604955125/il_794xN.4604955125_fpkv.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 2](https://i.etsystatic.com/24925695/r/il/4451ce/2987562222/il_794xN.2987562222_j90x.jpg)
- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 3](https://i.etsystatic.com/24925695/r/il/375b9e/4604949053/il_794xN.4604949053_lyab.jpg)
- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 4](https://i.etsystatic.com/24925695/r/il/e06d71/2987562532/il_794xN.2987562532_jegx.jpg)
- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 5](https://i.etsystatic.com/24925695/r/il/af5dc6/2987570852/il_794xN.2987570852_96a1.jpg)
- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 6](https://i.etsystatic.com/24925695/r/il/8d2f17/3000030853/il_794xN.3000030853_q7ok.jpg)
- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 7](https://i.etsystatic.com/24925695/r/il/ead63f/2952323686/il_794xN.2952323686_opra.jpg)
- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 8](https://i.etsystatic.com/24925695/r/il/8b4f74/4604949051/il_794xN.4604949051_sh5l.jpg)
- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 9](https://i.etsystatic.com/24925695/r/il/db6033/3035285183/il_794xN.3035285183_i3rw.jpg)

- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 1](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_75x75.4604955125_fpkv.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/trim.26D4DAD6-9F30-4DC6-BDD1-62F84E723910_l5oqpn.jpg)

- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 2](https://i.etsystatic.com/24925695/r/il/4451ce/2987562222/il_75x75.2987562222_j90x.jpg)
- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 3](https://i.etsystatic.com/24925695/r/il/375b9e/4604949053/il_75x75.4604949053_lyab.jpg)
- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 4](https://i.etsystatic.com/24925695/r/il/e06d71/2987562532/il_75x75.2987562532_jegx.jpg)
- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 5](https://i.etsystatic.com/24925695/r/il/af5dc6/2987570852/il_75x75.2987570852_96a1.jpg)
- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 6](https://i.etsystatic.com/24925695/r/il/8d2f17/3000030853/il_75x75.3000030853_q7ok.jpg)
- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 7](https://i.etsystatic.com/24925695/r/il/ead63f/2952323686/il_75x75.2952323686_opra.jpg)
- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 8](https://i.etsystatic.com/24925695/r/il/8b4f74/4604949051/il_75x75.4604949051_sh5l.jpg)
- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 9](https://i.etsystatic.com/24925695/r/il/db6033/3035285183/il_75x75.3035285183_i3rw.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F983852079%2F10k-solid-gold-small-continuous-hoops%23report-overlay-trigger)

In 20+ carts

Price:$33.62+


Original Price:
$37.35+


Loading


10% off


•

Limited time sale


# 10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings

[SerenaSparklesCanada](https://www.etsy.com/shop/SerenaSparklesCanada?ref=shop-header-name&listing_id=983852079&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[4.5 out of 5 stars](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?amp;click_sum=b4b69f84&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;pro=1&amp;sts=1#reviews)

Returns & exchanges accepted

Color


Select an option

10k Yellow Gold ($33.62 - $188.82)

10k White Gold ($40.05 - $200.27)

Please select an option


Size & Piece(Also Available in Single Piece)


Select an option

10mm Single Piece ($33.62 - $40.05)

10mm One Pair ($57.93 - $63.66)

12mm Single Piece ($40.05 - $45.77)

12mm One Pair ($62.23 - $68.66)

15mm Single Piece ($50.78 - $56.51)

15mm One Pair ($86.54 - $92.27)

Set Of All 3 Singles ($110.15 - $118.73)

Set Of All 3 Pairs ($188.82 - $200.27)

Please select an option


4 payments of **$8.40** at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Item details

### Highlights

Designed by [SerenaSparklesCanada](https://www.etsy.com/shop/SerenaSparklesCanada)

- Materials: Yellow gold

- Location: Cartilage, Conch, Daith, Earlobe, Tragus

- Closure: Ear wire

- Style: Minimalist

- Gift wrapping available

See details

Gift wrapping by SerenaSparklesCanada

Gift packaging includes Jewelry box, Ribbon or Bow and your personalized message.

10k Solid Gold Continuous Hoops Available in Three Different Small Sizes 10mm, 12mm, 15mm.

These Are Real Gold Daily Wear Sleeper Hoop Earrings For A Minimalist Look.

Everyday Dainty Solid Gold Hoop Earrings Can Be A Perfect Gift For Your Loved Ones.

Each Earring Is Stamped 10k To Prove Its Authenticity.

Metal: Solid Gold

Gold Purity: 10k

Stamp﻿: 10k

Made : Made In Italy

Thickness : 1.2 mm (All Are Equal In Thickness)

Piercing Post Gauge : 0.6mm

••• PURCHASING OPTIONS •••

Single Piece - Refers to 1 individual hoop

One Pair - Refers to 2 individual hoops

Set Of All 3 Singles - Refers to 1 Individual Hoop of 10mm, 12mm & 15mm Each (Total 3 Individual Pieces)

Set Of All 3 Pairs- Refers to 1 Pair of 10mm, 12mm & 15mm Each (Total 6 Individual Pieces)

••• PACKAGE •••

Can be Gift packed on request. Gift packaging includes Jewelry box, Ribbon or Bow and your personalized message.

••• SHIPPING •••

All jewelry are neatly packaged in an Eco-Friendly jewelry box that are gift ready.

UNITED STATES

USPS (Tracked Packet)

• 4-7 Days

• Includes Tracking

CANADA

1) Canada Post(Regular Parcel)

• 2-14 Days

• Does Not Includes Tracking and Insurance

\\* Upgrades Available\*

INTERNATIONAL (2 Options)

1) Canada Post(Small Packet International Air)

• 6-12 Days

• Does Not Includes Tracking and Insurance

2) Canada Post (Tracked Packet- International)

• 4-7 Days

• Includes Tracking

Please ensure that the correct shipping address is placed on the order, as we will not send a replacement parcel or offer a refund if the parcel was "Returned To Sender" for the following reasons:

1\. The address provided by you was not correct.

2\. The parcel is unclaimed once attempted to be delivered.

••• SHIPPING ADDRESS •••

All the orders will be shipped to the shipping address supplied through your Etsy Order.

Please double check this address is correct before checking out. We are not responsible for packages shipped to wrong address. It is the buyer’s responsibility to ensure that all shipping information is correct when placing the order.

All parcels that are "Returned To Sender" due to incomplete or inaccurate address will be disposed upon returning to our shipping carriers. Please ensure the correct shipping address is placed on the order as we will not send any replacement parcels due to incorrect addresses.

••• RETURNS / REFUNDS •••

If you would like to return a product, please contact us within 5 days of receiving your package and we will accept the return in the form of Store Credit. We will then provide you instructions on mailing your package back to us at your expense. Store Credit will only be made to the product, and not the shipping cost.

All jewelry must be returned unworn and in their original condition and packaging. Earrings and Nose Studs/Rings are NOT returnable due to hygiene reasons.

Serena Sparkles holds the right to deny a return if the product returned does not meet our return policy requirements. Customer/Buyer is responsible for the return shipping costs as well as items lost or damaged, thus we recommend shipping with tracking and insurance.

••• CUSTOMS & DUTIES •••

Buyers/Customers are responsible for any customs or duties fees that may apply at their country's borders. We are not responsible for any delays due to customs or issues with postal services.

••• LOST or DAMAGED PARCELS •••

Parcels that are shipped with tracking & insurance, any lost or damaged parcels can be claimed through their corresponding shipping provider.

For parcels that are shipped with NO tracking & insurance (Canada Post Regular Parcel), Serena Sparkles is not responsible for any lost or damaged parcels with no tracking & insurance.


### Production partners

SerenaSparklesCanada makes this item with help from


Gold Production Partner, Arezzo, Italy


## Shipping and return policies

Loading


- Order today to get by

**Nov 15-29**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 14 days


- Ships from: **Canada**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## Meet your seller

![Hazer](https://i.etsystatic.com/24925695/r/isla/03c17e/71017714/isla_75x75.71017714_nnlbj0fz.jpg)

Hazer

Owner of [SerenaSparklesCanada](https://www.etsy.com/shop/SerenaSparklesCanada?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDozNTcyODExNDk6MTc2MjgxOTY1NjpjYjk0ZjU2YmFhYmRhMTkwYWE0ZjI2ZDAwNmIxZDYwYg%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F983852079%2F10k-solid-gold-small-continuous-hoops%3Famp%253Bclick_sum%3Db4b69f84%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bpro%3D1%26amp%253Bsts%3D1)

[Message Hazer](https://www.etsy.com/messages/new?with_id=357281149&referring_id=983852079&referring_type=listing&recipient_id=357281149&from_action=contact-seller)

This seller usually responds **within a few hours.**

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (341)

4.5/5

item average

4.5Item quality

4.4Shipping

4.1Customer service

84%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Great quality

Love it

Beautiful

Fast shipping

As described

Would recommend

Exactly what I wanted


Filter by category


Quality (90)


Description accuracy (64)


Appearance (60)


Shipping & Packaging (54)


Seller service (46)


Ease of use (36)


Comfort (29)


Sizing & Fit (27)


Value (16)


Condition (3)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Tammy](https://www.etsy.com/people/duxycate?ref=l_review)
Nov 3, 2025


Item as described. Thank you!



[Tammy](https://www.etsy.com/people/duxycate?ref=l_review)
Nov 3, 2025


![](https://i.etsystatic.com/iusa/6a7c68/99006999/iusa_75x75.99006999_qicd.jpg?version=0)

Response from Hazer

♥️



5 out of 5 stars
5

This item

[Katharine Grace](https://www.etsy.com/people/kenny339?ref=l_review)
Oct 28, 2025


Matched description, met expectations. Very pretty and as described



[Katharine Grace](https://www.etsy.com/people/kenny339?ref=l_review)
Oct 28, 2025


![](https://i.etsystatic.com/iusa/6a7c68/99006999/iusa_75x75.99006999_qicd.jpg?version=0)

Response from Hazer

♥️



4 out of 5 stars
4

This item

[Sandra](https://www.etsy.com/people/9o8w4hqmrt4h31nd?ref=l_review)
Oct 21, 2025


Very good quality and very shiny



[Sandra](https://www.etsy.com/people/9o8w4hqmrt4h31nd?ref=l_review)
Oct 21, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/3ef328/103292238/iusa_75x75.103292238_szex.jpg?version=0)

[blondebarracuda](https://www.etsy.com/people/blondebarracuda?ref=l_review)
Oct 11, 2025


Pretty. Good size selection. I would say they are just slightly on the thinner side of a medium gauge hoop.



![](https://i.etsystatic.com/iusa/3ef328/103292238/iusa_75x75.103292238_szex.jpg?version=0)

[blondebarracuda](https://www.etsy.com/people/blondebarracuda?ref=l_review)
Oct 11, 2025


![](https://i.etsystatic.com/iusa/6a7c68/99006999/iusa_75x75.99006999_qicd.jpg?version=0)

Response from Hazer

♥️



View all reviews for this item

### Photos from reviews

![Drew added a photo of their purchase](https://i.etsystatic.com/iap/d55421/7089121228/iap_300x300.7089121228_238icym1.jpg?version=0)

![Nicky added a photo of their purchase](https://i.etsystatic.com/iap/80a72e/7020092971/iap_300x300.7020092971_9fogjuav.jpg?version=0)

![Karina added a photo of their purchase](https://i.etsystatic.com/iap/fd315c/6376336477/iap_300x300.6376336477_tcoa7ws0.jpg?version=0)

![Melissa added a photo of their purchase](https://i.etsystatic.com/iap/b5bc7b/6230540216/iap_300x300.6230540216_22plfueo.jpg?version=0)

![Michael added a photo of their purchase](https://i.etsystatic.com/iap/cfe657/7263814466/iap_300x300.7263814466_g7enj9j7.jpg?version=0)

![Arrianna added a photo of their purchase](https://i.etsystatic.com/iap/289a7e/6669738039/iap_300x300.6669738039_4jz7pbpf.jpg?version=0)

![Amelia added a photo of their purchase](https://i.etsystatic.com/iap/2b4d0e/6382360099/iap_300x300.6382360099_gskph2a1.jpg?version=0)

![Lee added a photo of their purchase](https://i.etsystatic.com/iap/fe04f7/6332104156/iap_300x300.6332104156_r0sa6pya.jpg?version=0)

![jluffman2 added a photo of their purchase](https://i.etsystatic.com/iap/807723/5723756963/iap_300x300.5723756963_nmx1f7k5.jpg?version=0)

![Emma-Lea added a photo of their purchase](https://i.etsystatic.com/iap/2a7de8/6719294590/iap_300x300.6719294590_1ztj3qe9.jpg?version=0)

![Jimena added a photo of their purchase](https://i.etsystatic.com/iap/839580/5468959671/iap_300x300.5468959671_kg0ifalo.jpg?version=0)

![Stephanie added a photo of their purchase](https://i.etsystatic.com/iap/ac085e/5811303092/iap_300x300.5811303092_4ybo9sed.jpg?version=0)

![Héctor added a photo of their purchase](https://i.etsystatic.com/iap/86a474/5427053952/iap_300x300.5427053952_hfq5yvvz.jpg?version=0)

![Marsha added a photo of their purchase](https://i.etsystatic.com/iap/b8f99c/5891150081/iap_300x300.5891150081_6ewke7vs.jpg?version=0)

![Jenny added a photo of their purchase](https://i.etsystatic.com/iap/f46816/5419054406/iap_300x300.5419054406_ds4mowzg.jpg?version=0)

![Najma added a photo of their purchase](https://i.etsystatic.com/iap/339381/4893440571/iap_300x300.4893440571_oqg4x3dd.jpg?version=0)

![book added a photo of their purchase](https://i.etsystatic.com/iap/58c908/5350562659/iap_300x300.5350562659_7wi34nww.jpg?version=0)

![Ozlem added a photo of their purchase](https://i.etsystatic.com/iap/e9b74f/5347725450/iap_300x300.5347725450_1db4sc3z.jpg?version=0)

![linda added a photo of their purchase](https://i.etsystatic.com/iap/c62a61/5727681381/iap_300x300.5727681381_mzyq1lpb.jpg?version=0)

![M. added a photo of their purchase](https://i.etsystatic.com/iap/a22a4d/5716776983/iap_300x300.5716776983_1thr7gqs.jpg?version=0)

[![SerenaSparklesCanada](https://i.etsystatic.com/iusa/6a7c68/99006999/iusa_75x75.99006999_qicd.jpg?version=0)](https://www.etsy.com/shop/SerenaSparklesCanada?ref=shop_profile&listing_id=983852079)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[SerenaSparklesCanada](https://www.etsy.com/shop/SerenaSparklesCanada?ref=shop_profile&listing_id=983852079)

[Owned by Hazer](https://www.etsy.com/shop/SerenaSparklesCanada?ref=shop_profile&listing_id=983852079) \|

Toronto, Canada

4.7
(7.1k)


25.7k sales

5 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=357281149&referring_id=983852079&referring_type=listing&recipient_id=357281149&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDozNTcyODExNDk6MTc2MjgxOTY1NjpjYjk0ZjU2YmFhYmRhMTkwYWE0ZjI2ZDAwNmIxZDYwYg%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F983852079%2F10k-solid-gold-small-continuous-hoops%3Famp%253Bclick_sum%3Db4b69f84%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bpro%3D1%26amp%253Bsts%3D1)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/SerenaSparklesCanada?ref=lp_mys_mfts)

- [![10k Solid Gold Lock & Key Charm, Dainty Lock Charm Necklace, Minimalist Gold Lock Pendant, Gold Padlock, Real Gold Lock Charm](https://i.etsystatic.com/24925695/c/1834/1458/94/642/il/45f377/5706664531/il_340x270.5706664531_42fw.jpg)\\
\\
**10k Solid Gold Lock & Key Charm, Dainty Lock Charm Necklace, Minimalist Gold Lock Pendant, Gold Padlock, Real Gold Lock Charm**\\
\\
$79.17\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/943918747/10k-solid-gold-lock-key-charm-dainty?click_key=16637a5d79a97e0e28c593b8e0d258a0%3ALT10297e0b226e9baad9382a1d080147e958cdd3a5&click_sum=f627edfe&ls=r&ref=related-1&sts=1&content_source=16637a5d79a97e0e28c593b8e0d258a0%253ALT10297e0b226e9baad9382a1d080147e958cdd3a5 "10k Solid Gold Lock & Key Charm, Dainty Lock Charm Necklace, Minimalist Gold Lock Pendant, Gold Padlock, Real Gold Lock Charm")




Add to Favorites


- [![14K Solid Gold Push Back Pairs- Replacement Backing- Silicon Gold Push, Butterfly Backings- One Pair Of Earring Backs, Gold Stud Backings](https://i.etsystatic.com/24925695/c/1512/1202/717/1150/il/8e92d2/3790638453/il_340x270.3790638453_2n6f.jpg)\\
\\
**14K Solid Gold Push Back Pairs- Replacement Backing- Silicon Gold Push, Butterfly Backings- One Pair Of Earring Backs, Gold Stud Backings**\\
\\
$28.37\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/969235836/14k-solid-gold-push-back-pairs?click_key=16637a5d79a97e0e28c593b8e0d258a0%3ALT36e5cc7dc809da1eef6bb90603c79f10eef4bb73&click_sum=17847641&ls=r&ref=related-2&sts=1&content_source=16637a5d79a97e0e28c593b8e0d258a0%253ALT36e5cc7dc809da1eef6bb90603c79f10eef4bb73 "14K Solid Gold Push Back Pairs- Replacement Backing- Silicon Gold Push, Butterfly Backings- One Pair Of Earring Backs, Gold Stud Backings")




Add to Favorites


- [![10k Solid Gold Nose Ring, White Gold Nose Ring, Gold Nose Ring, 10mm Gold Nose Ring, 12mm Gold Nose Ring, Hoop nose ring, Gold Round Ring](https://i.etsystatic.com/24925695/c/1807/1436/424/795/il/142ced/2815404259/il_340x270.2815404259_j75y.jpg)\\
\\
**10k Solid Gold Nose Ring, White Gold Nose Ring, Gold Nose Ring, 10mm Gold Nose Ring, 12mm Gold Nose Ring, Hoop nose ring, Gold Round Ring**\\
\\
Sale Price $32.85\\
$32.85\\
\\
$36.50\\
Original Price $36.50\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/857720066/10k-solid-gold-nose-ring-white-gold-nose?click_key=16637a5d79a97e0e28c593b8e0d258a0%3ALTed72257e08eb3e01a1368f0b6b433ba7a678ba53&click_sum=e8ffbd96&ls=r&ref=related-3&pro=1&sts=1&content_source=16637a5d79a97e0e28c593b8e0d258a0%253ALTed72257e08eb3e01a1368f0b6b433ba7a678ba53 "10k Solid Gold Nose Ring, White Gold Nose Ring, Gold Nose Ring, 10mm Gold Nose Ring, 12mm Gold Nose Ring, Hoop nose ring, Gold Round Ring")




Add to Favorites


- [![14k Solid Gold ball nose stud, Nose Pin, Ball nose pin, everyday jewelry, Nose pin for daily use, Light weight nose pin, Yellow gold](https://i.etsystatic.com/24925695/r/il/3ed4dc/2564186743/il_340x270.2564186743_rmc9.jpg)\\
\\
**14k Solid Gold ball nose stud, Nose Pin, Ball nose pin, everyday jewelry, Nose pin for daily use, Light weight nose pin, Yellow gold**\\
\\
Sale Price $33.32\\
$33.32\\
\\
$37.02\\
Original Price $37.02\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/867900463/14k-solid-gold-ball-nose-stud-nose-pin?click_key=16637a5d79a97e0e28c593b8e0d258a0%3ALT7ddbad9b82c381956f784bab7470b65cdb775a7c&click_sum=2d7e5b65&ls=r&ref=related-4&pro=1&sts=1&content_source=16637a5d79a97e0e28c593b8e0d258a0%253ALT7ddbad9b82c381956f784bab7470b65cdb775a7c "14k Solid Gold ball nose stud, Nose Pin, Ball nose pin, everyday jewelry, Nose pin for daily use, Light weight nose pin, Yellow gold")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 10, 2025


[2191 favorites](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Jewelry](https://www.etsy.com/c/jewelry?amp%3Bclick_sum=b4b69f84&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Earrings](https://www.etsy.com/c/jewelry/earrings?amp%3Bclick_sum=b4b69f84&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Hoop Earrings](https://www.etsy.com/c/jewelry/earrings/hoop-earrings?amp%3Bclick_sum=b4b69f84&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&%3Bsts=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Party Supplies

[Shop Bunny Party Bags](https://www.etsy.com/market/bunny_party_bags)

Kitchen & Dining

[Buddha Mug for Sale](https://www.etsy.com/market/buddha_mug)

Womens Clothing

[Buy Bush Costume Online](https://www.etsy.com/market/bush_costume)

Outdoor & Garden

[Shop Lotus Water Bowl](https://www.etsy.com/market/lotus_water_bowl) [Shop Fun Cantaloupe Gifts](https://www.etsy.com/market/fun_cantaloupe_gifts)

Patterns & How To

[Buy Pumpkin Poncho Online](https://www.etsy.com/market/pumpkin_poncho) [Mandarin Collar Tunic Pdf Sewing Patterns by CRAFTBOOK99](https://www.etsy.com/listing/960490579/mandarin-collar-tunic-pdf-sewing)

Food & Drink

[Buy Pamela Dean Kennedy Recipe Online](https://www.etsy.com/market/pamela_dean_kennedy_recipe)

Home Decor

[20x20 Chair Cushion - US](https://www.etsy.com/market/20x20_chair_cushion)

Paper

[Buy Ofertas Online](https://www.etsy.com/market/ofertas)

Earrings

[Social Value Jewelry - US](https://www.etsy.com/market/social_value_jewelry) [Buy Linear Claw Earring Online](https://www.etsy.com/market/linear_claw_earring) [Pashtun Earrings for Sale](https://www.etsy.com/market/pashtun_earrings)

Books

[Sports Notebook - US](https://www.etsy.com/market/sports_notebook)

Bracelets

[10k Gold Bracelet Turkish - US](https://www.etsy.com/market/10k_gold_bracelet_turkish)

Games & Puzzles

[Buy Settlers Of Catan Dice Online](https://www.etsy.com/market/settlers_of_catan_dice)

Dolls & Miniatures

[Buy Funko Pop Custom Head Online](https://www.etsy.com/market/funko_pop_custom_head)

Spirituality & Religion

[Jeremejevite Crystal - AAA Jeremejevite - Raw Jeremejevite - Blue Jeremejevite Stone - Jeremejevite Stone - Blue Jeremejevite - Jeremejevite - Spirituality & Religion](https://www.etsy.com/listing/1395311020/jeremejevite-crystal-aaa-jeremejevite)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F983852079%2F10k-solid-gold-small-continuous-hoops%3Famp%253Bclick_sum%3Db4b69f84%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bpro%3D1%26amp%253Bsts%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgxOTY1Njo3NjY3MzBiMDllODQzYTRhMGExMDZhMzFhYjQyODJmMw==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F983852079%2F10k-solid-gold-small-continuous-hoops%3Famp%253Bclick_sum%3Db4b69f84%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bpro%3D1%26amp%253Bsts%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?amp;click_sum=b4b69f84&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;pro=1&amp;sts=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F983852079%2F10k-solid-gold-small-continuous-hoops%3Famp%253Bclick_sum%3Db4b69f84%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bpro%3D1%26amp%253Bsts%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for SerenaSparklesCanada

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: not accepted

Please contact the seller if you have any problems with your order.

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


Customs and import taxes

Buyers are responsible for any customs and import taxes that may apply. I'm not responsible for delays due to customs.


## Seller details

### Business registration number

### Location

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=357281149&referring_id=24925695&referring_type=shop&recipient_id=357281149&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 1](https://i.etsystatic.com/24925695/c/2000/2000/0/682/il/65ffa9/4604955125/il_300x300.4604955125_fpkv.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/trim.26D4DAD6-9F30-4DC6-BDD1-62F84E723910_l5oqpn.jpg)

- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 2](https://i.etsystatic.com/24925695/r/il/4451ce/2987562222/il_300x300.2987562222_j90x.jpg)
- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 3](https://i.etsystatic.com/24925695/r/il/375b9e/4604949053/il_300x300.4604949053_lyab.jpg)
- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 4](https://i.etsystatic.com/24925695/r/il/e06d71/2987562532/il_300x300.2987562532_jegx.jpg)
- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 5](https://i.etsystatic.com/24925695/r/il/af5dc6/2987570852/il_300x300.2987570852_96a1.jpg)
- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 6](https://i.etsystatic.com/24925695/r/il/8d2f17/3000030853/il_300x300.3000030853_q7ok.jpg)
- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 7](https://i.etsystatic.com/24925695/r/il/ead63f/2952323686/il_300x300.2952323686_opra.jpg)
- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 8](https://i.etsystatic.com/24925695/r/il/8b4f74/4604949051/il_300x300.4604949051_sh5l.jpg)
- ![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings image 9](https://i.etsystatic.com/24925695/r/il/db6033/3035285183/il_300x300.3035285183_i3rw.jpg)

- ![](https://i.etsystatic.com/iap/d55421/7089121228/iap_640x640.7089121228_238icym1.jpg?version=0)

5 out of 5 stars

- Color:

10k Yellow Gold

- Size & Piece(Also Available in Single Piece):

10mm One Pair


These earrings were exactly what I was looking for for my double piercings! I had a little trouble getting them in/closed, but I don’t plan on taking them out often so I’m not concerned about that. They’re super lightweight and comfortable for everyday wear!

Aug 7, 2025


[Drew](https://www.etsy.com/people/f1pfr0cp)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/80a72e/7020092971/iap_640x640.7020092971_9fogjuav.jpg?version=0)

5 out of 5 stars

- Color:

10k Yellow Gold

- Size & Piece(Also Available in Single Piece):

15mm Single Piece


awesome product and great customer service

![](https://i.etsystatic.com/iusa/31be53/104764467/iusa_75x75.104764467_hu0n.jpg?version=0)

Jun 26, 2025


[Nicky](https://www.etsy.com/people/z4mdfx3l)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/fd315c/6376336477/iap_640x640.6376336477_tcoa7ws0.jpg?version=0)

4 out of 5 stars

- Color:

10k Yellow Gold

- Size & Piece(Also Available in Single Piece):

10mm Single Piece


Very good, as described.

See in original language


Translated by Google


Très bien, comme la description.


Oct 6, 2024


[Karina Lévesque](https://www.etsy.com/people/kj6ph5yunx7b62fi)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/b5bc7b/6230540216/iap_640x640.6230540216_22plfueo.jpg?version=0)

2 out of 5 stars

- Color:

10k Yellow Gold

- Size & Piece(Also Available in Single Piece):

10mm One Pair


Item quality seemed poor. The earrings were smaller and thinner than I expected. It was not easy to open the back ends and the earrings became bent from me attempting to open it. It was also super difficult to close the ends and the shape for warped. There were no pictures to indicate these were infinity hoop earrings which I didn’t realize required a special way to open them. I am currently in the middle of returning these earrings back to the seller. They are located in Canada so it cost me $17 to ship back.

![](https://i.etsystatic.com/iusa/f53dc7/58875344/iusa_75x75.58875344_523l.jpg?version=0)

Aug 28, 2024


[Melissa](https://www.etsy.com/people/wvllqaci)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/cfe657/7263814466/iap_640x640.7263814466_g7enj9j7.jpg?version=0)

5 out of 5 stars

- Color:

10k Yellow Gold

- Size & Piece(Also Available in Single Piece):

12mm Single Piece


Exactly what I was looking for. Took me a while to put it on but I'll get used to it . It's perfect diameter and gauge.

Oct 7, 2025


[Michael Java](https://www.etsy.com/people/michaeljava)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/289a7e/6669738039/iap_640x640.6669738039_4jz7pbpf.jpg?version=0)

5 out of 5 stars

- Color:

10k Yellow Gold

- Size & Piece(Also Available in Single Piece):

15mm Single Piece


Very cute I like it

Feb 5, 2025


[Arrianna Vickers](https://www.etsy.com/people/arriannavickers)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/2b4d0e/6382360099/iap_640x640.6382360099_gskph2a1.jpg?version=0)

5 out of 5 stars

- Color:

10k Yellow Gold

- Size & Piece(Also Available in Single Piece):

10mm One Pair


These are so pretty! They are extremely hard to get in so they're really only good if you plan to leave them in, but they're perfectly comfy to sleep in.

Oct 8, 2024


[Amelia](https://www.etsy.com/people/f56im9nxbvxdt5yj)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/fe04f7/6332104156/iap_640x640.6332104156_r0sa6pya.jpg?version=0)

5 out of 5 stars

- Color:

10k Yellow Gold

- Size & Piece(Also Available in Single Piece):

15mm One Pair


Absolutely Phenomenal seller! I only bought a simple pair of 14k hoop earrings, but the seller went a mile beyond. The packing and pouch and the style of delivery won me over. Seriously well done! I will likely buy from them again 😎👍🏻

![](https://i.etsystatic.com/iusa/2749ee/66713195/iusa_75x75.66713195_2gbp.jpg?version=0)

Oct 7, 2024


[Lee](https://www.etsy.com/people/kowebwk2)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/807723/5723756963/iap_640x640.5723756963_nmx1f7k5.jpg?version=0)

5 out of 5 stars

- Color:

10k Yellow Gold

- Size & Piece(Also Available in Single Piece):

10mm One Pair


I ordered two 10mm hoops for my helix piercings, I wanted to make sure they matched the other hoops I already owned. The shipping was very fast, and the quality of the hoops looked and felt great. It takes a bit of patience to connect the hoops once they're in your ear.

Jan 15, 2024


[jluffman2](https://www.etsy.com/people/jluffman2)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/2a7de8/6719294590/iap_640x640.6719294590_1ztj3qe9.jpg?version=0)

1 out of 5 stars

- Color:

10k Yellow Gold

- Size & Piece(Also Available in Single Piece):

15mm One Pair


Oh boy don’t buy these. Seller is the literal worst. I’ve never received such horrible customer service and he still won’t admit that he sent 12mm earrings not the 15mm I paid for. I assure you, this man’s a liar.

![](https://i.etsystatic.com/iusa/ed135d/20934777/iusa_75x75.20934777_ofm6.jpg?version=0)

Mar 16, 2025


[Emma-Lea Schwartzentruber](https://www.etsy.com/people/emmaleajs)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/839580/5468959671/iap_640x640.5468959671_kg0ifalo.jpg?version=0)

5 out of 5 stars

- Color:

10k Yellow Gold

- Size & Piece(Also Available in Single Piece):

12mm Single Piece


Great earring! It arrived quickly

Oct 20, 2023


[Jimena](https://www.etsy.com/people/qs9lflxytkuz85cw)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/ac085e/5811303092/iap_640x640.5811303092_4ybo9sed.jpg?version=0)

5 out of 5 stars

- Color:

10k Yellow Gold

- Size & Piece(Also Available in Single Piece):

12mm One Pair


Perfect dainty every day hoop

![](https://i.etsystatic.com/iusa/db6b07/73568450/iusa_75x75.73568450_42rg.jpg?version=0)

Mar 3, 2024


[Stephanie Arlt](https://www.etsy.com/people/pndbmvvl)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/86a474/5427053952/iap_640x640.5427053952_hfq5yvvz.jpg?version=0)

5 out of 5 stars

- Color:

10k Yellow Gold

- Size & Piece(Also Available in Single Piece):

15mm One Pair


Awesome dainty earrings, very shiny and pretty. The box and the gift wrapping was great too. Would recommend 10/10

Oct 22, 2023


[Héctor Martínez](https://www.etsy.com/people/vhbth4h5rkkzbpqw)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/b8f99c/5891150081/iap_640x640.5891150081_6ewke7vs.jpg?version=0)

1 out of 5 stars

- Color:

10k Yellow Gold

- Size & Piece(Also Available in Single Piece):

12mm Single Piece


I returned item ordered on 1/18/24 order # 3176404729 perfect in its original packaging via USPS Priority International Mail on 2/12/24 after sending repeated messages to the seller (which were not answered). I paid $31.45 for an earring and had to pay $34.26 to ship it back to Toronto. I reported the problem to my credit card company ad they are investigating why I have not received responses and a refund…Etsy disavows responsibility throwing the matter back to the seller they has been unresponsive. I am out $63.00 so far and will not ever buy from Etsy again. Very disappointed, Marsha

Mar 14, 2024


[Marsha J Darling](https://www.etsy.com/people/k91oi336tkees71o)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/f46816/5419054406/iap_640x640.5419054406_ds4mowzg.jpg?version=0)

5 out of 5 stars

- Color:

10k Yellow Gold

- Size & Piece(Also Available in Single Piece):

15mm One Pair


Beautiful easy to wear earings. Love them very much

Oct 20, 2023


[Jenny](https://www.etsy.com/people/ka09n5ej3jhcnwfp)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/339381/4893440571/iap_640x640.4893440571_oqg4x3dd.jpg?version=0)

1 out of 5 stars

- Color:

10k Yellow Gold

- Size & Piece(Also Available in Single Piece):

10mm One Pair


I bought these in February and wrote a review then. I came here in April to edit my review. I do NOT recommend these earrings. They are cheaply made. The closing was very hard to get inside the tiny little hole. In order to put the earring through the piercing, you have to physically bend the earring. This obviously damages the earring and for me it ended up breaking. I attached a picture to show what I mean. I do NOT recommend these little hoops.

Apr 23, 2023


[Najma](https://www.etsy.com/people/f346yb9kuevsb7gs)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/58c908/5350562659/iap_640x640.5350562659_7wi34nww.jpg?version=0)

5 out of 5 stars

- Color:

10k Yellow Gold

- Size & Piece(Also Available in Single Piece):

15mm One Pair


![](https://i.etsystatic.com/iusa/cc7a0c/94421747/iusa_75x75.94421747_ofx6.jpg?version=0)

Sep 18, 2023


[book worm](https://www.etsy.com/people/gabbypazos)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/e9b74f/5347725450/iap_640x640.5347725450_1db4sc3z.jpg?version=0)

5 out of 5 stars

- Color:

10k Yellow Gold

- Size & Piece(Also Available in Single Piece):

12mm One Pair


These gold earings are light weight and comfortable to wear all the time. I really like them.

Sep 30, 2023


[Ozlem Scupham](https://www.etsy.com/people/gdyt598nk0e703tj)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/c62a61/5727681381/iap_640x640.5727681381_mzyq1lpb.jpg?version=0)

1 out of 5 stars

- Color:

10k Yellow Gold

- Size & Piece(Also Available in Single Piece):

15mm One Pair


I ordered the 15" and this is what I got. Earrings smaller than a dime

Jan 16, 2024


[linda wilson](https://www.etsy.com/people/pdq1w2mvrsdhlf58)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/a22a4d/5716776983/iap_640x640.5716776983_1thr7gqs.jpg?version=0)

5 out of 5 stars

- Color:

10k White Gold

- Size & Piece(Also Available in Single Piece):

10mm One Pair


Securely packaged, nicely presented, fit in my postal box (very efficient) and exactly as promised. Lovely small sleeper hoops for my second piercing. Very pretty A+++

![](https://i.etsystatic.com/iusa/a60f41/84728460/iusa_75x75.84728460_92at.jpg?version=0)

Jan 12, 2024


[M. Wood](https://www.etsy.com/people/michelewood792)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)

Purchased item:

[![10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings](https://i.etsystatic.com/24925695/c/2000/1589/0/888/il/65ffa9/4604955125/il_170x135.4604955125_fpkv.jpg)\\
\\
10k Solid Gold Small Continuous Hoops 10mm, 12mm, 15mm, Real Gold Daily Wear Sleeper Hoops, Minimalist Gold Hoops, Everyday Hoop Earrings\\
\\
Sale Price $33.62\\
$33.62\\
\\
$37.35\\
Original Price $37.35\\
\\
\\
(10% off)](https://www.etsy.com/listing/983852079/10k-solid-gold-small-continuous-hoops?ref=ap-listing)