[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1438052419/vintage-botanical-print-cottagecore?amp;click_sum=4c3895ee&amp;ls=s&amp;ga_order=most_relevant&amp;ga_search_type=vintage&amp;ga_view_type=gallery&amp;ga_search_query=List+10+wall+prints+under+%2425+from+Etsy&amp;ref=search_grid-216189-1-3&amp;sr_prefetch=1&amp;pf_from=search&amp;frs=1&amp;bes=1&amp;sts=1&amp;content_source=46523a64-3613-40f1-8803-e488d3effaa9%253ALTb254417965f3abddf208ac693ed47e96e6aa6907#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=4c3895ee&%3Bls=s&%3Bga_order=most_relevant&%3Bga_search_type=vintage&%3Bga_view_type=gallery&%3Bga_search_query=List+10+wall+prints+under+%2425+from+Etsy&%3Bref=search_grid-216189-1-3&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bfrs=1&%3Bbes=1&%3Bsts=1&%3Bcontent_source=46523a64-3613-40f1-8803-e488d3effaa9%253ALTb254417965f3abddf208ac693ed47e96e6aa6907&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=4c3895ee&%3Bls=s&%3Bga_order=most_relevant&%3Bga_search_type=vintage&%3Bga_view_type=gallery&%3Bga_search_query=List+10+wall+prints+under+%2425+from+Etsy&%3Bref=search_grid-216189-1-3&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bfrs=1&%3Bbes=1&%3Bsts=1&%3Bcontent_source=46523a64-3613-40f1-8803-e488d3effaa9%253ALTb254417965f3abddf208ac693ed47e96e6aa6907&explicit=1&ref=catnav_breadcrumb-1)
- [Wall Decor](https://www.etsy.com/c/home-and-living/home-decor/wall-decor?amp%3Bclick_sum=4c3895ee&%3Bls=s&%3Bga_order=most_relevant&%3Bga_search_type=vintage&%3Bga_view_type=gallery&%3Bga_search_query=List+10+wall+prints+under+%2425+from+Etsy&%3Bref=search_grid-216189-1-3&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bfrs=1&%3Bbes=1&%3Bsts=1&%3Bcontent_source=46523a64-3613-40f1-8803-e488d3effaa9%253ALTb254417965f3abddf208ac693ed47e96e6aa6907&explicit=1&ref=catnav_breadcrumb-2)

Etsy’s Pick

Etsy’s Picks are hand selected by our style experts to highlight items from shops that have shown quality, reliability and style.

[Discover More](https://www.etsy.com/featured/hub/etsy-picks?ref=listing_etsys_pick_signal)


Add to Favorites


- ![Vintage botanical print, cottage core, white neutral decor, Ellen Thayer Fisher, White flowers](https://i.etsystatic.com/39921923/r/il/8bc82e/6643271796/il_794xN.6643271796_4w1f.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![May include: A botanical illustration of white hydrangea flowers with green leaves on a light brown background. The artist's signature 'E.T.E.A.G.E.' is in the bottom right corner.](https://i.etsystatic.com/39921923/r/il/b15efe/4766730759/il_794xN.4766730759_7unt.jpg)
- ![May include: A vintage botanical illustration of white flowers with green leaves on a light green background. The illustration is framed with a cream border.](https://i.etsystatic.com/39921923/r/il/ac5234/4841584979/il_794xN.4841584979_hzyj.jpg)
- ![May include: A framed botanical illustration of white flowers with green leaves on a light green background.](https://i.etsystatic.com/39921923/r/il/32444f/4766894537/il_794xN.4766894537_7udv.jpg)
- ![May include: A framed botanical illustration of white flowers with green leaves on a light green background. The image is in a wooden frame. Below the frame, there is a brown wicker basket filled with brown eggs, a black ceramic pitcher, and a small black ceramic cup on a brown wooden surface.](https://i.etsystatic.com/39921923/r/il/f19a63/4766894557/il_794xN.4766894557_l591.jpg)
- ![May include: A framed botanical print of white flowers on a green branch, hanging on a green wall with a gold candle sconce on the right side of the frame.](https://i.etsystatic.com/39921923/r/il/ec1b60/4718652740/il_794xN.4718652740_bgd4.jpg)
- ![Vintage Botanical Print | Cottagecore Farmhouse French Country Watercolor Antique Art | White Flowers | 8x10 art print | Snowballs image 7](https://i.etsystatic.com/39921923/r/il/6ce06f/4766900461/il_794xN.4766900461_66xi.jpg)
- ![May include: A green velvet sofa with a carved wooden frame and four legs. The sofa has three pillows with a geometric pattern. The sofa is in front of a light gray wall with a framed picture of white flowers on a green background.](https://i.etsystatic.com/39921923/r/il/6e6073/4718679584/il_794xN.4718679584_qvjr.jpg)
- ![May include: A crocheted teddy bear sitting on a wooden surface with a brown mug, fall leaves, and nuts. The teddy bear is light brown with cream colored paws and a light brown nose. The bear is looking at the camera. The mug is filled with coffee beans. The leaves are brown and orange. The nuts are brown and have a shiny finish.](https://i.etsystatic.com/39921923/r/il/f4975a/4718679768/il_794xN.4718679768_99s4.jpg)
- ![May include: A white framed print of a botanical illustration of white flowers with green leaves on a light green background. The print is hanging on a light blue wall above a white bathtub with a white towel draped over the side. A wooden stool with a white towel on top is next to the bathtub. There is a light brown floor and a gray and white rug in the foreground.](https://i.etsystatic.com/39921923/r/il/b92934/4766922015/il_794xN.4766922015_ifis.jpg)

- ![Vintage botanical print, cottage core, white neutral decor, Ellen Thayer Fisher, White flowers](https://i.etsystatic.com/39921923/r/il/8bc82e/6643271796/il_75x75.6643271796_4w1f.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/general_etsy_video_g15wga.jpg)

- ![May include: A botanical illustration of white hydrangea flowers with green leaves on a light brown background. The artist's signature 'E.T.E.A.G.E.' is in the bottom right corner.](https://i.etsystatic.com/39921923/r/il/b15efe/4766730759/il_75x75.4766730759_7unt.jpg)
- ![May include: A vintage botanical illustration of white flowers with green leaves on a light green background. The illustration is framed with a cream border.](https://i.etsystatic.com/39921923/r/il/ac5234/4841584979/il_75x75.4841584979_hzyj.jpg)
- ![May include: A framed botanical illustration of white flowers with green leaves on a light green background.](https://i.etsystatic.com/39921923/r/il/32444f/4766894537/il_75x75.4766894537_7udv.jpg)
- ![May include: A framed botanical illustration of white flowers with green leaves on a light green background. The image is in a wooden frame. Below the frame, there is a brown wicker basket filled with brown eggs, a black ceramic pitcher, and a small black ceramic cup on a brown wooden surface.](https://i.etsystatic.com/39921923/r/il/f19a63/4766894557/il_75x75.4766894557_l591.jpg)
- ![May include: A framed botanical print of white flowers on a green branch, hanging on a green wall with a gold candle sconce on the right side of the frame.](https://i.etsystatic.com/39921923/r/il/ec1b60/4718652740/il_75x75.4718652740_bgd4.jpg)
- ![Vintage Botanical Print | Cottagecore Farmhouse French Country Watercolor Antique Art | White Flowers | 8x10 art print | Snowballs image 7](https://i.etsystatic.com/39921923/r/il/6ce06f/4766900461/il_75x75.4766900461_66xi.jpg)
- ![May include: A green velvet sofa with a carved wooden frame and four legs. The sofa has three pillows with a geometric pattern. The sofa is in front of a light gray wall with a framed picture of white flowers on a green background.](https://i.etsystatic.com/39921923/r/il/6e6073/4718679584/il_75x75.4718679584_qvjr.jpg)
- ![May include: A crocheted teddy bear sitting on a wooden surface with a brown mug, fall leaves, and nuts. The teddy bear is light brown with cream colored paws and a light brown nose. The bear is looking at the camera. The mug is filled with coffee beans. The leaves are brown and orange. The nuts are brown and have a shiny finish.](https://i.etsystatic.com/39921923/r/il/f4975a/4718679768/il_75x75.4718679768_99s4.jpg)
- ![May include: A white framed print of a botanical illustration of white flowers with green leaves on a light green background. The print is hanging on a light blue wall above a white bathtub with a white towel draped over the side. A wooden stool with a white towel on top is next to the bathtub. There is a light brown floor and a gray and white rug in the foreground.](https://i.etsystatic.com/39921923/r/il/b92934/4766922015/il_75x75.4766922015_ifis.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1438052419%2Fvintage-botanical-print-cottagecore%23report-overlay-trigger)

In 20+ carts

Price:$13.99+


Loading


# Vintage Botanical Print \| Cottagecore Farmhouse French Country Watercolor Antique Art \| White Flowers \| 8x10 art print \| Snowballs

[ClarityPress](https://www.etsy.com/shop/ClarityPress?ref=shop-header-name&listing_id=1438052419&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1438052419/vintage-botanical-print-cottagecore?amp;click_sum=4c3895ee&amp;ls=s&amp;ga_order=most_relevant&amp;ga_search_type=vintage&amp;ga_view_type=gallery&amp;ga_search_query=List+10+wall+prints+under+%2425+from+Etsy&amp;ref=search_grid-216189-1-3&amp;sr_prefetch=1&amp;pf_from=search&amp;frs=1&amp;bes=1&amp;sts=1&amp;content_source=46523a64-3613-40f1-8803-e488d3effaa9%253ALTb254417965f3abddf208ac693ed47e96e6aa6907#reviews)

Arrives soon! Get it by

Nov 15-20


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

Size


Select an option

13x18 cm / 5x7″ ($13.99)

15x20 cm / 6x8″ ($14.99)

20x25 cm / 8x10″ ($15.99)

A4 21x29.7 cm / 8x12″ ($16.99)

27x35 cm / 11x14″ ($18.99)

30x40 cm / 12x16″ ($19.99)

30x45 cm / 12x18″ ($20.99)

40x50 cm / 16x20″ ($21.99)

45x60 cm / 18x24″ ($22.99)

60x80 cm / 24x32″ ($27.99)

Please select an option


Quantity



123456789101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899100101102103104105106107108109110111112113114115116117118119120121122123124125126127128129130131132133134135136137138139140141142143144145146147148149150151152153154155156157158159160161162163164165166167168169170171172173174175176177178179180181182183184185186187188189190191192193194195196197198199200201202203204205206207208209210211212213214215216217218219220221222223224225226227228229230231232233234235236237238239240241242243244245246247248249250251252253254255256257258259260261262263264265266267268269270271272273274275276277278279280281282283284285286287288289290291292293294295296297298299300301302303304305306307308309310311312313314315316317318319320321322323324325326327328329330331332333334335336337338339340341342343344345346347348349350351352353354355356357358359360361362363364365366367368369370371372373374375376377378379380381382383384385386387388389390391392393394395396397398399400401402403404405406407408409410411412413414415416417418419420421422423424425426427428429430431432433434435436437438439440441442443444445446447448449450451452453454455456457458459460461462463464465466467468469470471472473474475476477478479480481482483484485486487488489490491492493494495496497498499500501502503504505506507508509510511512513514515516517518519520521522523524525526527528529530531532533534535536537538539540541542543544545546547548549550551552553554555556557558559560561562563564565566567568569570571572573574575576577578579580581582583584585586587588589590591592593594595596597598599600601602603604605606607608609610611612613614615616617618619620621622623624625626627628629630631632633634635636637638639640641642643644645646647648649650651652653654655656657658659660661662663664665666667668669670671672673674675676677678679680681682683684685686687688689690691692693694695696697698699700701702703704705706707708709710711712713714715716717718719720721722723724725726727728729730731732733734735736737738739740741742743744745746747748749750751752753754755756757758759760761762763764765766767768769770771772773774775776777778779780781782783784785786787788789790791792793794795796797798799800801802803804805806807808809810811812813814815816817818819820821822823824825826827828829830831832833834835836837838839840841842843844845846847848849850851852853854855856857858859860861862863864865866867868869870871872873874875876877878879880881882883884885886887888889890891892893894895896897898899900901902903904905906907908909910911912913914915916917918919920921922923924925926927928929930931932933934935936937938939940941942943944945946947948949950951952953954955956957958959960961962963964965966967968969970971972973974975976977978979980981982983984985986987988989990991992993994995996997

4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Item details

### Highlights

Handpicked by [ClarityPress](https://www.etsy.com/shop/ClarityPress)

- Vintage from the 19th century


- Materials: paper, print



This vintage botanical print was painted between 1884 and 1887 by Ellen Thayer Fisher for Louis Prang & Company, which made chromolithograph greeting cards. Louis Prang is actually credited as the inventor of the Christmas card because Christmas cards weren’t commonly exchanged before his factory began producing them!

Ellen Thayer Fisher was a self-taught artist who specialized in watercolor paintings of plants and flowers. These prints have been reproduced from her proofs for Louis Prang & Co., which we have digitally restored. We have added an off-white border, which can be changed to a custom color for an added charge. Please message us BEFORE placing your order if you’re interested in a custom border color.

The white flower in this print looks very similar to a hydrangea, but it's actually a snowball, or Viburnum plicatum.

We offer individual prints as well as curated sets or gallery walls. These plant illustrations could work anywhere in your home, from your kitchen or dining room, to your entryway, living room, bedrooms, or nursery, whether your style is rustic, modern farmhouse, cottagecore, boho, French Country, or traditional.

THE DETAILS:

\- All artwork is printed on matte, archival paper.

\- The off-white border you see on the images is not matting. It is included in your print.

\- Frames are not included, but we offer sizes that fit many standard retail frames.

\- Colors may vary slightly based on your computer monitor's calibration.

\- Please reach out to us with any questions or concerns!

Order now to add a unique touch of history and beauty to your space!

ABOUT US:

Peter and Claire are a husband and wife team based in California. All of our work is printed and manufactured in the US.


## Shipping and return policies

Loading


- Order today to get by

**Nov 15-20**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 30 days


- Free shipping


- Ships from: **United States**


Deliver to United States

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

## Reviews for this item (17)

4.9/5

item average

4.9Item quality

4.9Shipping

4.8Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Beautiful

As described

Would recommend

Fast shipping

Lovely

Love it

Looks great


Filter by category


Appearance (6)


Shipping & Packaging (5)


Description accuracy (5)


Quality (5)


Seller service (3)


Sizing & Fit (2)


Ease of use (1)


Value (1)


Condition (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/8043e8/92992734/iusa_75x75.92992734_lzll.jpg?version=0)

[sgoodnight1](https://www.etsy.com/people/sgoodnight1?ref=l_review)
Sep 27, 2025


Arrived fast and is SO cute



![](https://i.etsystatic.com/iusa/8043e8/92992734/iusa_75x75.92992734_lzll.jpg?version=0)

[sgoodnight1](https://www.etsy.com/people/sgoodnight1?ref=l_review)
Sep 27, 2025


5 out of 5 stars
5

This item

[Lindsey Love](https://www.etsy.com/people/ditalini?ref=l_review)
Sep 27, 2025


Just lovely! It arrived quickly and just as pictured.



[Lindsey Love](https://www.etsy.com/people/ditalini?ref=l_review)
Sep 27, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/1cb034/68104264/iusa_75x75.68104264_7l5b.jpg?version=0)

[Lauren Tomlin](https://www.etsy.com/people/jpi8p3av?ref=l_review)
Sep 8, 2025


loved it! fit well for my gallery wall :)



![Lauren Tomlin added a photo of their purchase](https://i.etsystatic.com/iap/7d85fa/7230130561/iap_300x300.7230130561_64b2idvv.jpg?version=0)

![](https://i.etsystatic.com/iusa/1cb034/68104264/iusa_75x75.68104264_7l5b.jpg?version=0)

[Lauren Tomlin](https://www.etsy.com/people/jpi8p3av?ref=l_review)
Sep 8, 2025


4 out of 5 stars
4

This item

[Terin Matlock](https://www.etsy.com/people/Terinmatlock?ref=l_review)
Aug 2, 2025


Easy download and great product



[Terin Matlock](https://www.etsy.com/people/Terinmatlock?ref=l_review)
Aug 2, 2025


View all reviews for this item

### Photos from reviews

![Lauren added a photo of their purchase](https://i.etsystatic.com/iap/7d85fa/7230130561/iap_300x300.7230130561_64b2idvv.jpg?version=0)

[![ClarityPress](https://i.etsystatic.com/iusa/f649ea/97881700/iusa_75x75.97881700_gck4.jpg?version=0)](https://www.etsy.com/shop/ClarityPress?ref=shop_profile&listing_id=1438052419)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[ClarityPress](https://www.etsy.com/shop/ClarityPress?ref=shop_profile&listing_id=1438052419)

[Owned by chepstein1](https://www.etsy.com/shop/ClarityPress?ref=shop_profile&listing_id=1438052419) \|

Los Angeles, California

4.9
(101)


606 sales

2.5 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=100384056&referring_id=1438052419&referring_type=listing&recipient_id=100384056&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoxMDAzODQwNTY6MTc2MjgxNTI2Mzo0NWVkNTczNDY5YThlYzIxMjU2MzRmZDQ1ZTNkZGU2Yw%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1438052419%2Fvintage-botanical-print-cottagecore%3Famp%253Bclick_sum%3D4c3895ee%26amp%253Bls%3Ds%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dvintage%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DList%2B10%2Bwall%2Bprints%2Bunder%2B%252425%2Bfrom%2BEtsy%26amp%253Bref%3Dsearch_grid-216189-1-3%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bfrs%3D1%26amp%253Bbes%3D1%26amp%253Bsts%3D1%26amp%253Bcontent_source%3D46523a64-3613-40f1-8803-e488d3effaa9%25253ALTb254417965f3abddf208ac693ed47e96e6aa6907)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/ClarityPress?ref=lp_mys_mfts)

- [![Vintage Botanical Print | Cottagecore Farmhouse French Country Watercolor Art | Gardening Gift | White Flowers | Gallery Wall Set of 3](https://i.etsystatic.com/39921923/c/1502/1502/249/0/il/26860e/6691367943/il_340x270.6691367943_nnjh.jpg)\\
\\
**Vintage Botanical Print \| Cottagecore Farmhouse French Country Watercolor Art \| Gardening Gift \| White Flowers \| Gallery Wall Set of 3**\\
\\
$36.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1423878796/vintage-botanical-print-cottagecore?click_key=3cacccb02df692e49eeded9d276fddb6%3ALT8bba58162d0fc43913396e26108302429f82311f&click_sum=ec5d876f&ls=r&ref=related-1&sts=1&content_source=3cacccb02df692e49eeded9d276fddb6%253ALT8bba58162d0fc43913396e26108302429f82311f "Vintage Botanical Print | Cottagecore Farmhouse French Country Watercolor Art | Gardening Gift | White Flowers | Gallery Wall Set of 3")




Add to Favorites


- [![Vintage Botanical Print | Cottagecore Farmhouse French Country Watercolor Antique Art | Neutral Art White Flowers | 5x7 Print | Elder Flower](https://i.etsystatic.com/39921923/r/il/75a7a5/6691328893/il_340x270.6691328893_9wdz.jpg)\\
\\
**Vintage Botanical Print \| Cottagecore Farmhouse French Country Watercolor Antique Art \| Neutral Art White Flowers \| 5x7 Print \| Elder Flower**\\
\\
$13.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1438075541/vintage-botanical-print-cottagecore?click_key=3cacccb02df692e49eeded9d276fddb6%3ALT902d917edb34112770762e276bdf80828822b94e&click_sum=dd92cca5&ls=r&ref=related-2&sts=1&content_source=3cacccb02df692e49eeded9d276fddb6%253ALT902d917edb34112770762e276bdf80828822b94e "Vintage Botanical Print | Cottagecore Farmhouse French Country Watercolor Antique Art | Neutral Art White Flowers | 5x7 Print | Elder Flower")




Add to Favorites


- [![Vintage Botanical Print | Cottagecore Farmhouse French Country Watercolor Antique Art | White Flowers | Mother&#39;s Day Gift | Dogwood](https://i.etsystatic.com/39921923/r/il/8c42b0/6643285020/il_340x270.6643285020_qgpx.jpg)\\
\\
**Vintage Botanical Print \| Cottagecore Farmhouse French Country Watercolor Antique Art \| White Flowers \| Mother's Day Gift \| Dogwood**\\
\\
$13.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1423874558/vintage-botanical-print-cottagecore?click_key=3cacccb02df692e49eeded9d276fddb6%3ALT30461f376baa94d15a558b24781d8c8275a9a545&click_sum=d1d3237c&ls=r&ref=related-3&sts=1&content_source=3cacccb02df692e49eeded9d276fddb6%253ALT30461f376baa94d15a558b24781d8c8275a9a545 "Vintage Botanical Print | Cottagecore Farmhouse French Country Watercolor Antique Art | White Flowers | Mother's Day Gift | Dogwood")




Add to Favorites


- [![Vintage Dogwood Botanical Print: French Country Cottagecore Art (Digital Print File)](https://i.etsystatic.com/39921923/r/il/8c8069/6881546514/il_340x270.6881546514_qps4.jpg)\\
\\
Digital download\\
\\
\\
**Vintage Dogwood Botanical Print: French Country Cottagecore Art (Digital Print File)**\\
\\
$5.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4309272372/vintage-dogwood-botanical-print-french?click_key=977f88df351d01dec9fd9c38a09dae030cfcaf08%3A4309272372&click_sum=68757b2c&ref=related-4&sts=1&dd=1 "Vintage Dogwood Botanical Print: French Country Cottagecore Art (Digital Print File)")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 7, 2025


[1376 favorites](https://www.etsy.com/listing/1438052419/vintage-botanical-print-cottagecore/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=4c3895ee&%3Bls=s&%3Bga_order=most_relevant&%3Bga_search_type=vintage&%3Bga_view_type=gallery&%3Bga_search_query=List+10+wall+prints+under+%2425+from+Etsy&%3Bref=search_grid-216189-1-3&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bfrs=1&%3Bbes=1&%3Bsts=1&%3Bcontent_source=46523a64-3613-40f1-8803-e488d3effaa9%253ALTb254417965f3abddf208ac693ed47e96e6aa6907&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=4c3895ee&%3Bls=s&%3Bga_order=most_relevant&%3Bga_search_type=vintage&%3Bga_view_type=gallery&%3Bga_search_query=List+10+wall+prints+under+%2425+from+Etsy&%3Bref=search_grid-216189-1-3&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bfrs=1&%3Bbes=1&%3Bsts=1&%3Bcontent_source=46523a64-3613-40f1-8803-e488d3effaa9%253ALTb254417965f3abddf208ac693ed47e96e6aa6907&explicit=1&ref=breadcrumb_listing) [Wall Decor](https://www.etsy.com/c/home-and-living/home-decor/wall-decor?amp%3Bclick_sum=4c3895ee&%3Bls=s&%3Bga_order=most_relevant&%3Bga_search_type=vintage&%3Bga_view_type=gallery&%3Bga_search_query=List+10+wall+prints+under+%2425+from+Etsy&%3Bref=search_grid-216189-1-3&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bfrs=1&%3Bbes=1&%3Bsts=1&%3Bcontent_source=46523a64-3613-40f1-8803-e488d3effaa9%253ALTb254417965f3abddf208ac693ed47e96e6aa6907&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Patterns & How To

[Buy Magnolia Crossstitch Online](https://www.etsy.com/market/magnolia_crossstitch)

Furniture

[Step stool log - Furniture](https://www.etsy.com/listing/1559218910/step-stool-log)

Home Decor

[Lion Roaring Black and White Glass Wall Art - Home Decor](https://www.etsy.com/listing/1313758743/lion-roaring-black-and-white-glass-wall) [Chinois Vase for Sale](https://www.etsy.com/market/chinois_vase) [Cocoa Butter Cashmere 12oz Soy Candle - Home Decor](https://www.etsy.com/listing/4311165203/cocoa-butter-cashmere-12oz-soy-candle) [Shop Pantry Transfer](https://www.etsy.com/market/pantry_transfer) [Valentine's Day Gift Heart Love Heart Balloon Love Gift Rose Gift Valentine's Day Flowers Valentine's Day Balloons Valentine's Day Surprise - Home Decor](https://www.etsy.com/listing/1648325414/valentines-day-gift-heart-love-heart) [Shop Frosty And Karen](https://www.etsy.com/market/frosty_and_karen) [Crochet Heart Candle With Dish / Valentine Gift For Her / Birthday Gift / Cute Gift / Pretty Candle / Anniversary Gift /Decorative Candle](https://www.etsy.com/listing/1662483720/crochet-heart-candle-with-dish-valentine) [Shop Fish Clocks For Wall](https://www.etsy.com/market/fish_clocks_for_wall) [Homewood - US](https://www.etsy.com/market/homewood) [Vintage Haiti for Sale](https://www.etsy.com/market/vintage_haiti)

Gender Neutral Adult Clothing

[Light Blue Bachelorette Sweatshirt - US](https://www.etsy.com/market/light_blue_bachelorette_sweatshirt)

Paper

[Wizard Sticker Four Pack by ArtAndSoulWatercolor](https://www.etsy.com/listing/1688217895/wizard-sticker-four-pack-gift-idea)

Party Supplies

[What Happened 1926 - US](https://www.etsy.com/market/what_happened_1926)

Car Parts & Accessories

[U.S. Navy Military Logo Spare Tire Cover ~ ALL Sizes available in menu~ Camera opening option in Menu ~ Heavy Duty Tire Protector by TireCoverCentral](https://www.etsy.com/listing/637803797/us-navy-military-logo-spare-tire-cover)

Keychains & Lanyards

[Shop Rhode Island Key Fob](https://www.etsy.com/market/rhode_island_key_fob)

Fine Art Ceramics

[Vintage KAHLA Serving Platter Fish Design Made in Germany Porcelain Oval Platter GDR Kahla Platter Serving Tray Seafood Platter by Masterpearl](https://www.etsy.com/listing/4349008093/vintage-kahla-serving-platter-fish)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1438052419%2Fvintage-botanical-print-cottagecore%3Famp%253Bclick_sum%3D4c3895ee%26amp%253Bls%3Ds%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dvintage%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DList%2B10%2Bwall%2Bprints%2Bunder%2B%252425%2Bfrom%2BEtsy%26amp%253Bref%3Dsearch_grid-216189-1-3%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bfrs%3D1%26amp%253Bbes%3D1%26amp%253Bsts%3D1%26amp%253Bcontent_source%3D46523a64-3613-40f1-8803-e488d3effaa9%25253ALTb254417965f3abddf208ac693ed47e96e6aa6907&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgxNTI2Mzo0NzQ4NTdjNWJlNWIxNTc2YTBlYWJhM2ZjNzMxMjhmZg==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1438052419%2Fvintage-botanical-print-cottagecore%3Famp%253Bclick_sum%3D4c3895ee%26amp%253Bls%3Ds%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dvintage%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DList%2B10%2Bwall%2Bprints%2Bunder%2B%252425%2Bfrom%2BEtsy%26amp%253Bref%3Dsearch_grid-216189-1-3%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bfrs%3D1%26amp%253Bbes%3D1%26amp%253Bsts%3D1%26amp%253Bcontent_source%3D46523a64-3613-40f1-8803-e488d3effaa9%25253ALTb254417965f3abddf208ac693ed47e96e6aa6907) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1438052419/vintage-botanical-print-cottagecore?amp;click_sum=4c3895ee&amp;ls=s&amp;ga_order=most_relevant&amp;ga_search_type=vintage&amp;ga_view_type=gallery&amp;ga_search_query=List+10+wall+prints+under+%2425+from+Etsy&amp;ref=search_grid-216189-1-3&amp;sr_prefetch=1&amp;pf_from=search&amp;frs=1&amp;bes=1&amp;sts=1&amp;content_source=46523a64-3613-40f1-8803-e488d3effaa9%253ALTb254417965f3abddf208ac693ed47e96e6aa6907#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1438052419%2Fvintage-botanical-print-cottagecore%3Famp%253Bclick_sum%3D4c3895ee%26amp%253Bls%3Ds%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dvintage%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DList%2B10%2Bwall%2Bprints%2Bunder%2B%252425%2Bfrom%2BEtsy%26amp%253Bref%3Dsearch_grid-216189-1-3%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bfrs%3D1%26amp%253Bbes%3D1%26amp%253Bsts%3D1%26amp%253Bcontent_source%3D46523a64-3613-40f1-8803-e488d3effaa9%25253ALTb254417965f3abddf208ac693ed47e96e6aa6907)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![Vintage botanical print, cottage core, white neutral decor, Ellen Thayer Fisher, White flowers](https://i.etsystatic.com/39921923/r/il/8bc82e/6643271796/il_300x300.6643271796_4w1f.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/general_etsy_video_g15wga.jpg)

- ![May include: A botanical illustration of white hydrangea flowers with green leaves on a light brown background. The artist's signature 'E.T.E.A.G.E.' is in the bottom right corner.](https://i.etsystatic.com/39921923/r/il/b15efe/4766730759/il_300x300.4766730759_7unt.jpg)
- ![May include: A vintage botanical illustration of white flowers with green leaves on a light green background. The illustration is framed with a cream border.](https://i.etsystatic.com/39921923/r/il/ac5234/4841584979/il_300x300.4841584979_hzyj.jpg)
- ![May include: A framed botanical illustration of white flowers with green leaves on a light green background.](https://i.etsystatic.com/39921923/r/il/32444f/4766894537/il_300x300.4766894537_7udv.jpg)
- ![May include: A framed botanical illustration of white flowers with green leaves on a light green background. The image is in a wooden frame. Below the frame, there is a brown wicker basket filled with brown eggs, a black ceramic pitcher, and a small black ceramic cup on a brown wooden surface.](https://i.etsystatic.com/39921923/r/il/f19a63/4766894557/il_300x300.4766894557_l591.jpg)
- ![May include: A framed botanical print of white flowers on a green branch, hanging on a green wall with a gold candle sconce on the right side of the frame.](https://i.etsystatic.com/39921923/r/il/ec1b60/4718652740/il_300x300.4718652740_bgd4.jpg)
- ![Vintage Botanical Print | Cottagecore Farmhouse French Country Watercolor Antique Art | White Flowers | 8x10 art print | Snowballs image 7](https://i.etsystatic.com/39921923/r/il/6ce06f/4766900461/il_300x300.4766900461_66xi.jpg)
- ![May include: A green velvet sofa with a carved wooden frame and four legs. The sofa has three pillows with a geometric pattern. The sofa is in front of a light gray wall with a framed picture of white flowers on a green background.](https://i.etsystatic.com/39921923/r/il/6e6073/4718679584/il_300x300.4718679584_qvjr.jpg)
- ![May include: A crocheted teddy bear sitting on a wooden surface with a brown mug, fall leaves, and nuts. The teddy bear is light brown with cream colored paws and a light brown nose. The bear is looking at the camera. The mug is filled with coffee beans. The leaves are brown and orange. The nuts are brown and have a shiny finish.](https://i.etsystatic.com/39921923/r/il/f4975a/4718679768/il_300x300.4718679768_99s4.jpg)
- ![May include: A white framed print of a botanical illustration of white flowers with green leaves on a light green background. The print is hanging on a light blue wall above a white bathtub with a white towel draped over the side. A wooden stool with a white towel on top is next to the bathtub. There is a light brown floor and a gray and white rug in the foreground.](https://i.etsystatic.com/39921923/r/il/b92934/4766922015/il_300x300.4766922015_ifis.jpg)

- ![](https://i.etsystatic.com/iap/7d85fa/7230130561/iap_640x640.7230130561_64b2idvv.jpg?version=0)











5 out of 5 stars





- Size:

20x25 cm / 8x10″


loved it! fit well for my gallery wall :)

![](https://i.etsystatic.com/iusa/1cb034/68104264/iusa_75x75.68104264_7l5b.jpg?version=0)

Sep 8, 2025


[Lauren Tomlin](https://www.etsy.com/people/jpi8p3av)

Purchased item:

[![Vintage Botanical Print | Cottagecore Farmhouse French Country Watercolor Antique Art | White Flowers | 8x10 art print | Snowballs](https://i.etsystatic.com/39921923/r/il/8bc82e/6643271796/il_170x135.6643271796_4w1f.jpg)\\
\\
Vintage Botanical Print \| Cottagecore Farmhouse French Country Watercolor Antique Art \| White Flowers \| 8x10 art print \| Snowballs\\
\\
$13.99](https://www.etsy.com/listing/1438052419/vintage-botanical-print-cottagecore?ref=ap-listing)

Purchased item:

[![Vintage Botanical Print | Cottagecore Farmhouse French Country Watercolor Antique Art | White Flowers | 8x10 art print | Snowballs](https://i.etsystatic.com/39921923/r/il/8bc82e/6643271796/il_170x135.6643271796_4w1f.jpg)\\
\\
Vintage Botanical Print \| Cottagecore Farmhouse French Country Watercolor Antique Art \| White Flowers \| 8x10 art print \| Snowballs\\
\\
$13.99](https://www.etsy.com/listing/1438052419/vintage-botanical-print-cottagecore?ref=ap-listing)