[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1733249409/5000-mega-bundle-wall-art-gallery-wall?amp;click_sum=a955d84b&amp;ls=s&amp;ga_order=most_relevant&amp;ga_search_type=vintage&amp;ga_view_type=gallery&amp;ga_search_query=List+10+wall+prints+under+%2425+from+Etsy&amp;ref=search_grid-216189-1-2&amp;sr_prefetch=1&amp;pf_from=search&amp;pro=1&amp;pop=1&amp;sts=1&amp;dd=1&amp;content_source=46523a64-3613-40f1-8803-e488d3effaa9%253ALT5c9a465cf721d5cf58f6782972c0500e783b5c6f#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?amp%3Bclick_sum=a955d84b&%3Bls=s&%3Bga_order=most_relevant&%3Bga_search_type=vintage&%3Bga_view_type=gallery&%3Bga_search_query=List+10+wall+prints+under+%2425+from+Etsy&%3Bref=search_grid-216189-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bpop=1&%3Bsts=1&%3Bdd=1&%3Bcontent_source=46523a64-3613-40f1-8803-e488d3effaa9%253ALT5c9a465cf721d5cf58f6782972c0500e783b5c6f&explicit=1&ref=catnav_breadcrumb-0)
- [Prints](https://www.etsy.com/c/art-and-collectibles/prints?amp%3Bclick_sum=a955d84b&%3Bls=s&%3Bga_order=most_relevant&%3Bga_search_type=vintage&%3Bga_view_type=gallery&%3Bga_search_query=List+10+wall+prints+under+%2425+from+Etsy&%3Bref=search_grid-216189-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bpop=1&%3Bsts=1&%3Bdd=1&%3Bcontent_source=46523a64-3613-40f1-8803-e488d3effaa9%253ALT5c9a465cf721d5cf58f6782972c0500e783b5c6f&explicit=1&ref=catnav_breadcrumb-1)
- [Digital Prints](https://www.etsy.com/c/art-and-collectibles/prints/digital-prints?amp%3Bclick_sum=a955d84b&%3Bls=s&%3Bga_order=most_relevant&%3Bga_search_type=vintage&%3Bga_view_type=gallery&%3Bga_search_query=List+10+wall+prints+under+%2425+from+Etsy&%3Bref=search_grid-216189-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bpop=1&%3Bsts=1&%3Bdd=1&%3Bcontent_source=46523a64-3613-40f1-8803-e488d3effaa9%253ALT5c9a465cf721d5cf58f6782972c0500e783b5c6f&explicit=1&ref=catnav_breadcrumb-2)

Bestseller

This item has had a high sales volume over the past 6 months.



Add to Favorites


- ![May include: A gallery wall featuring a curated collection of 5000+ vintage prints. The assortment includes landscapes, botanical illustrations, portraits, and still life paintings in various sizes and frames.  The prints are displayed on a light beige wall, creating a cohesive and aesthetically pleasing display.  The overall style is vintage and eclectic, with a muted color palette of creams, browns, and greens. The text '5000+ Vintage Prints' is prominently displayed at the bottom.](https://i.etsystatic.com/32066133/r/il/3648b2/6046332173/il_794xN.6046332173_2xu1.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![May include: Four curated gallery wall sets showcasing diverse artistic styles.  'Indigo-Green' features nature scenes and dark-toned artwork. 'Coastal' presents seascapes and light blues. 'Spring' displays floral arrangements and pastel hues. 'Warm Tones' offers rich earth tones and classical paintings. Each set includes various sizes and frames, creating a cohesive yet varied aesthetic.  All sets are ideal for home decor and interior design.](https://i.etsystatic.com/32066133/r/il/6a0eaf/6046332189/il_794xN.6046332189_p5ei.jpg)
- ![May include: Four gallery wall sets showcasing various framed prints.  Taupe set features landscapes and still life. Pink and green set includes ballet dancers and floral arrangements. Spring set displays nature scenes and a butterfly. Winter set shows cityscapes and winter scenes. All sets feature a variety of artistic styles and color palettes.](https://i.etsystatic.com/32066133/r/il/0c2263/6046332227/il_794xN.6046332227_35xk.jpg)
- ![May include: Four curated gallery wall sets showcasing various painting styles.  'Still Life' features floral and landscape paintings in muted tones. 'Warm Tones' presents a collection of warm-toned artwork, including still life and landscape scenes. 'Burnt Orange' displays a palette of burnt orange hues in landscapes and still life. 'Muted Green' showcases paintings in muted greens and floral arrangements. Each set offers a diverse range of artistic styles and color palettes for home decor.](https://i.etsystatic.com/32066133/r/il/44751d/6046332275/il_794xN.6046332275_mr4p.jpg)
- ![May include: 5000+ Vintage Prints Mega Bundle.  A collage showcases numerous framed sepia-toned and muted beige vintage prints.  The prints depict various subjects including floral arrangements, landscapes, and still lifes.  The overall aesthetic is elegant and classic.  The text '5000+' and 'Vintage Prints MEGA BUNDLE' is prominently displayed.](https://i.etsystatic.com/32066133/r/il/10953a/5998257966/il_794xN.5998257966_s7k7.jpg)
- ![May include: A gallery wall showcasing 5000+ vintage prints.  The prints feature various subjects including floral arrangements, landscapes, portraits, and birds.  The frames are light wood, and the prints are in muted tones of beige, cream, and green.  The text '5000+ Vintage Prints' is prominently displayed at the bottom.](https://i.etsystatic.com/32066133/r/il/80f390/5998258036/il_794xN.5998258036_9jyg.jpg)
- ![May include: A collage showcases 5000+ vintage prints.  The collection features various styles, including landscapes, portraits, and nature scenes in muted blues, grays, and creams.  Images depict cityscapes with bridges, snowy villages, peacocks, horses, and floral patterns.  The text '5000+ Vintage Prints' is prominently displayed.](https://i.etsystatic.com/32066133/r/il/e0e5ac/6046332491/il_794xN.6046332491_dv8c.jpg)
- ![May include: A gallery wall showcasing 5000+ vintage prints.  The prints feature a variety of subjects including cityscapes, floral botanical illustrations, and classical art.  The prints are framed in light wood and arranged on a cream-colored wall. The text '5000+ Vintage Prints' is prominently displayed at the bottom.](https://i.etsystatic.com/32066133/r/il/0671c8/6046332557/il_794xN.6046332557_f5fh.jpg)
- ![May include: A gallery wall showcasing 5000+ vintage floral prints in various sizes and frames.  The prints feature muted tones of beige, cream, and brown, depicting bouquets of roses, lilies, and other flowers in antique-style arrangements.  Many of the prints are in ornate wooden frames. The text '5000+ Vintage Prints' is prominently displayed at the bottom.](https://i.etsystatic.com/32066133/r/il/a6806b/5998258260/il_794xN.5998258260_o9zv.jpg)
- ![May include: A gallery wall showcasing a curated collection of 5000+ vintage prints.  The prints feature a variety of subjects and styles, including landscapes, cityscapes, floral still lifes, and abstract designs.  The frames are light-colored wood, creating a cohesive and aesthetically pleasing display. The prints are in various sizes and orientations, adding visual interest. The text '5000+ VINTAGE PRINTS' is overlaid on the image.](https://i.etsystatic.com/32066133/r/il/fc4233/6046332699/il_794xN.6046332699_l65e.jpg)

- ![May include: A gallery wall featuring a curated collection of 5000+ vintage prints. The assortment includes landscapes, botanical illustrations, portraits, and still life paintings in various sizes and frames.  The prints are displayed on a light beige wall, creating a cohesive and aesthetically pleasing display.  The overall style is vintage and eclectic, with a muted color palette of creams, browns, and greens. The text '5000+ Vintage Prints' is prominently displayed at the bottom.](https://i.etsystatic.com/32066133/r/il/3648b2/6046332173/il_75x75.6046332173_2xu1.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/YATAY_ETSY_VI%CC%87DEO_sxgv1u.jpg)

- ![May include: Four curated gallery wall sets showcasing diverse artistic styles.  'Indigo-Green' features nature scenes and dark-toned artwork. 'Coastal' presents seascapes and light blues. 'Spring' displays floral arrangements and pastel hues. 'Warm Tones' offers rich earth tones and classical paintings. Each set includes various sizes and frames, creating a cohesive yet varied aesthetic.  All sets are ideal for home decor and interior design.](https://i.etsystatic.com/32066133/r/il/6a0eaf/6046332189/il_75x75.6046332189_p5ei.jpg)
- ![May include: Four gallery wall sets showcasing various framed prints.  Taupe set features landscapes and still life. Pink and green set includes ballet dancers and floral arrangements. Spring set displays nature scenes and a butterfly. Winter set shows cityscapes and winter scenes. All sets feature a variety of artistic styles and color palettes.](https://i.etsystatic.com/32066133/r/il/0c2263/6046332227/il_75x75.6046332227_35xk.jpg)
- ![May include: Four curated gallery wall sets showcasing various painting styles.  'Still Life' features floral and landscape paintings in muted tones. 'Warm Tones' presents a collection of warm-toned artwork, including still life and landscape scenes. 'Burnt Orange' displays a palette of burnt orange hues in landscapes and still life. 'Muted Green' showcases paintings in muted greens and floral arrangements. Each set offers a diverse range of artistic styles and color palettes for home decor.](https://i.etsystatic.com/32066133/r/il/44751d/6046332275/il_75x75.6046332275_mr4p.jpg)
- ![May include: 5000+ Vintage Prints Mega Bundle.  A collage showcases numerous framed sepia-toned and muted beige vintage prints.  The prints depict various subjects including floral arrangements, landscapes, and still lifes.  The overall aesthetic is elegant and classic.  The text '5000+' and 'Vintage Prints MEGA BUNDLE' is prominently displayed.](https://i.etsystatic.com/32066133/r/il/10953a/5998257966/il_75x75.5998257966_s7k7.jpg)
- ![May include: A gallery wall showcasing 5000+ vintage prints.  The prints feature various subjects including floral arrangements, landscapes, portraits, and birds.  The frames are light wood, and the prints are in muted tones of beige, cream, and green.  The text '5000+ Vintage Prints' is prominently displayed at the bottom.](https://i.etsystatic.com/32066133/r/il/80f390/5998258036/il_75x75.5998258036_9jyg.jpg)
- ![May include: A collage showcases 5000+ vintage prints.  The collection features various styles, including landscapes, portraits, and nature scenes in muted blues, grays, and creams.  Images depict cityscapes with bridges, snowy villages, peacocks, horses, and floral patterns.  The text '5000+ Vintage Prints' is prominently displayed.](https://i.etsystatic.com/32066133/r/il/e0e5ac/6046332491/il_75x75.6046332491_dv8c.jpg)
- ![May include: A gallery wall showcasing 5000+ vintage prints.  The prints feature a variety of subjects including cityscapes, floral botanical illustrations, and classical art.  The prints are framed in light wood and arranged on a cream-colored wall. The text '5000+ Vintage Prints' is prominently displayed at the bottom.](https://i.etsystatic.com/32066133/r/il/0671c8/6046332557/il_75x75.6046332557_f5fh.jpg)
- ![May include: A gallery wall showcasing 5000+ vintage floral prints in various sizes and frames.  The prints feature muted tones of beige, cream, and brown, depicting bouquets of roses, lilies, and other flowers in antique-style arrangements.  Many of the prints are in ornate wooden frames. The text '5000+ Vintage Prints' is prominently displayed at the bottom.](https://i.etsystatic.com/32066133/r/il/a6806b/5998258260/il_75x75.5998258260_o9zv.jpg)
- ![May include: A gallery wall showcasing a curated collection of 5000+ vintage prints.  The prints feature a variety of subjects and styles, including landscapes, cityscapes, floral still lifes, and abstract designs.  The frames are light-colored wood, creating a cohesive and aesthetically pleasing display. The prints are in various sizes and orientations, adding visual interest. The text '5000+ VINTAGE PRINTS' is overlaid on the image.](https://i.etsystatic.com/32066133/r/il/fc4233/6046332699/il_75x75.6046332699_l65e.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1733249409%2F5000-mega-bundle-wall-art-gallery-wall%23report-overlay-trigger)

In 20+ carts

NowPrice:$2.75


Original Price:
$5.00


Loading


45% off


•

Sale ends on December 3


# 5000+ Mega Bundle Wall Art, Gallery Wall Art, Printable Wall Art, Eclectic Gallery Set, Maximalist Wall Art, Trendy Vintage Prints

[bonafidesaVINTAGE](https://www.etsy.com/shop/bonafidesaVINTAGE?ref=shop-header-name&listing_id=1733249409&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1733249409/5000-mega-bundle-wall-art-gallery-wall?amp;click_sum=a955d84b&amp;ls=s&amp;ga_order=most_relevant&amp;ga_search_type=vintage&amp;ga_view_type=gallery&amp;ga_search_query=List+10+wall+prints+under+%2425+from+Etsy&amp;ref=search_grid-216189-1-2&amp;sr_prefetch=1&amp;pf_from=search&amp;pro=1&amp;pop=1&amp;sts=1&amp;dd=1&amp;content_source=46523a64-3613-40f1-8803-e488d3effaa9%253ALT5c9a465cf721d5cf58f6782972c0500e783b5c6f#reviews)

4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Item details

### Highlights

Designed by [bonafidesaVINTAGE](https://www.etsy.com/shop/bonafidesaVINTAGE)

- Vintage from the 19th century


- Digital download


- Digital file type(s): 1 PDF


Welcome to our incredible Mega Bundle Set, a captivating compilation of over 5000 vintage digital art prints that seamlessly fuse aesthetic French decor with farmhouse charm.

Step into a world of artistic nostalgia with this meticulously curated collection, featuring landscapes, portraits, still lifes, botanicals, animals, seascapes, and coastal scenes.

This rustic collection of downloadable art contains our best-selling listings, with each print capturing the essence of timeless beauty, making it the perfect addition to your wall decor. Whether you're drawn to French-inspired decor or farmhouse aesthetics, this Mega Bundle offers versatility that effortlessly complements various design preferences.

Dive into the diversity of this collection, where each piece narrates a unique story through its vintage allure.

Experience the pleasure of decorating with this collection of antique oil painting prints, where each digital print serves as a portal to a world of vintage charm and artistic expression. Immerse yourself in the allure of French decor and farmhouse style, turning your walls into a canvas of timeless beauty. Explore the potential of digital art and let your home narrate a tale of sophistication and creativity with this exquisite collection of over 5000 prints.

You'll receive a PDF file with simple, step-by-step instructions on how to download your files from Google Drive.

Attention : You will receive all works in their original sizes(ratios). If your frame difference from the sizes(ratios) of the original work, you'll need to edit it.


## Delivery

Instant Download

Your files will be available to download once payment is confirmed.
[Here's how.](https://www.etsy.com/help/article/3949)

Instant download items don’t accept returns, exchanges or cancellations. Please contact the seller about any problems with your order.

## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

View additional shop policies

## FAQs

What type of paper should I choose?


A heavyweight matte paper or card stock is a perfect budget friendly choice.

Premium archival fine art paper with a slight watercolor or linen texture will result in the most authentic vintage art reproductions.


Can I get a custom size?


We provide 𝐨𝐧𝐞 free resize per design from any printable art listing.

If you require a different size than what is included, please message me first to see if the custom size can be accommodated.


Can I use your artwork for commercial use?


You are not permitted to use, share or distribute our digital files or reproduce for commercial use or resale in any form.

You are not permitted to use our artwork to edit or make changes to, then in turn use for commercial use or resale in any form.


Where can I find picture frames?


The frames used in our shop listings are product photos, and are not physical frames that are sold.


𝐈 𝐜𝐚𝐧’𝐭 𝐟𝐢𝐧𝐝 𝐦𝐲 𝐝𝐨𝐰𝐧𝐥𝐨𝐚𝐝 𝐧𝐨𝐭𝐢𝐟𝐢𝐜𝐚𝐭𝐢𝐨𝐧 𝐞𝐦𝐚𝐢𝐥 / 𝐄𝐭𝐬𝐲 𝐫𝐞𝐜𝐞𝐢𝐩𝐭.


First, check your spam or junk inbox. If you use Gmail, also check your Social and Promotions tabs. If it’s not there, adding transaction@etsy.com to your address book or safe list can help you locate these emails in the future.


𝐖𝐡𝐞𝐫𝐞 𝐜𝐚𝐧 𝐈 𝐟𝐢𝐧𝐝 𝐦𝐲 𝐝𝐢𝐠𝐢𝐭𝐚𝐥 𝐩𝐮𝐫𝐜𝐡𝐚𝐬𝐞𝐬 𝐢𝐧 𝐦𝐲 𝐚𝐜𝐜𝐨𝐮𝐧𝐭?


To access your digital files from your account:

Sign in to Etsy.com (not the Etsy app on a mobile device) and go to "Your account".

Go to "Purchases and reviews".

Next to the order, select Download Files. This goes to the Downloads page for all the files attached to your order.

You can also go back to the item’s listing page, where you should see an “Instant Download: message on the images for the item.

There are generally no limits for when or how many times you can download a file. In most cases, you can access a file any time on your Purchases page, provided the transaction hasn't been cancelled or removed.

If your payment is still processing, the Download Files button will be grey.


𝐈 𝐩𝐮𝐫𝐜𝐡𝐚𝐬𝐞𝐝 𝐚 𝐝𝐢𝐠𝐢𝐭𝐚𝐥 𝐢𝐭𝐞𝐦, 𝐛𝐮𝐭 𝐈 𝐝𝐨𝐧'𝐭 𝐡𝐚𝐯𝐞 𝐚𝐧 𝐄𝐭𝐬𝐲 𝐚𝐜𝐜𝐨𝐮𝐧𝐭.


If you purchased an instant digital download as a guest, you'll find a link to download your files in the receipt email that was sent to you after purchase.

If you don't see the emailed receipt from Etsy, check your spam or junk inbox. If you use Gmail, also check your Social and Promotions tabs. If it’s not there, adding transaction@etsy.com to your address book or safe list can help you locate these emails in the future.


## Reviews for this item (5)

4.8/5

item average

4.8Item quality

5.0Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Love it

As described

Very pretty


Filter by category


Appearance (1)


Description accuracy (1)


Value (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[kelljaneen33](https://www.etsy.com/people/kelljaneen33?ref=l_review)
Nov 6, 2025


Love these. Really pretty. Just as pictured.



[kelljaneen33](https://www.etsy.com/people/kelljaneen33?ref=l_review)
Nov 6, 2025


![](https://i.etsystatic.com/iusa/d38ee1/102849145/iusa_75x75.102849145_mrdl.jpg?version=0)

Response from Bona Fidesa

Thank you so much for your lovely review 💛 I’m so happy to hear that you love your prints and that they look just as pictured 🌿 It means so much to know the artwork met your expectations and brought beauty to your space ✨ Your kind words truly brighten my day and your support is deeply appreciated 💫



4 out of 5 stars
4

This item

![](https://i.etsystatic.com/iusa/c3328a/71189586/iusa_75x75.71189586_4j8g.jpg?version=0)

[Abigail Wezelis](https://www.etsy.com/people/jiagjfky?ref=l_review)
Nov 2, 2025


Great set of photos, but wish it was tagged or named to be searchable by mood/color/etc. Overall great value.



![](https://i.etsystatic.com/iusa/c3328a/71189586/iusa_75x75.71189586_4j8g.jpg?version=0)

[Abigail Wezelis](https://www.etsy.com/people/jiagjfky?ref=l_review)
Nov 2, 2025


![](https://i.etsystatic.com/iusa/d38ee1/102849145/iusa_75x75.102849145_mrdl.jpg?version=0)

Response from Bona Fidesa

Thank you so much for your honest and thoughtful feedback! 💛 I truly appreciate you taking the time to share your experience. 🌿 I’m so glad you enjoyed the photo set and found it to be a great value. ✨ I’ll definitely keep your suggestion in mind for adding searchable tags by mood and color. it’s very helpful! 💫



5 out of 5 stars
5

This item

[MANDAR TRADERS](https://www.etsy.com/people/ggr3hk3bhwmawwvi?ref=l_review)
Oct 23, 2025


I really loved this images.



[MANDAR TRADERS](https://www.etsy.com/people/ggr3hk3bhwmawwvi?ref=l_review)
Oct 23, 2025


![](https://i.etsystatic.com/iusa/d38ee1/102849145/iusa_75x75.102849145_mrdl.jpg?version=0)

Response from Bona Fidesa

I’m so glad to hear that you loved the images! 🥰✨ Thank you for your kind words and for supporting my shop. It truly means a lot! 💕



5 out of 5 stars
5

This item

[Clint](https://www.etsy.com/people/d4lyrdnk?ref=l_review)
Oct 12, 2025


great images. just as described and awesome customer service. highly recommend



[Clint](https://www.etsy.com/people/d4lyrdnk?ref=l_review)
Oct 12, 2025


![](https://i.etsystatic.com/iusa/d38ee1/102849145/iusa_75x75.102849145_mrdl.jpg?version=0)

Response from Bona Fidesa

Thank you so much for your wonderful review 😊✨ I’m so happy to hear that you loved the images and that they were just as described 🖼️ It means a lot to know you appreciated the customer service as well — I always want every experience to feel easy and personal 💛 Your recommendation truly means the world to me, thank you for your kind support 🌟



View all reviews for this item

[![bonafidesaVINTAGE](https://i.etsystatic.com/iusa/d38ee1/102849145/iusa_75x75.102849145_mrdl.jpg?version=0)](https://www.etsy.com/shop/bonafidesaVINTAGE?ref=shop_profile&listing_id=1733249409)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[bonafidesaVINTAGE](https://www.etsy.com/shop/bonafidesaVINTAGE?ref=shop_profile&listing_id=1733249409)

[Owned by Bona Fidesa](https://www.etsy.com/shop/bonafidesaVINTAGE?ref=shop_profile&listing_id=1733249409) \|

Europe

5.0
(106)


1.9k sales

4 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=538878521&referring_id=1733249409&referring_type=listing&recipient_id=538878521&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo1Mzg4Nzg1MjE6MTc2MjgxNDkzMTowODZiZDA4ZjE1MDQzNjdiYzk1MmEwMDYzYmQ2NjZkMQ%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1733249409%2F5000-mega-bundle-wall-art-gallery-wall%3Famp%253Bclick_sum%3Da955d84b%26amp%253Bls%3Ds%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dvintage%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DList%2B10%2Bwall%2Bprints%2Bunder%2B%252425%2Bfrom%2BEtsy%26amp%253Bref%3Dsearch_grid-216189-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bpop%3D1%26amp%253Bsts%3D1%26amp%253Bdd%3D1%26amp%253Bcontent_source%3D46523a64-3613-40f1-8803-e488d3effaa9%25253ALT5c9a465cf721d5cf58f6782972c0500e783b5c6f)

This seller usually responds **within a few hours.**

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/bonafidesaVINTAGE?ref=lp_mys_mfts)

- [![5000+ Mega Bundle Wall Art, Gallery Wall Art, Printable Wall Art, Eclectic Gallery Set, Maximalist Wall Art, Trendy Vintage Prints](https://i.etsystatic.com/32066133/r/il/c377d3/7348668366/il_340x270.7348668366_swtm.jpg)\\
\\
Digital download\\
\\
\\
**5000+ Mega Bundle Wall Art, Gallery Wall Art, Printable Wall Art, Eclectic Gallery Set, Maximalist Wall Art, Trendy Vintage Prints**\\
\\
Sale Price $2.75\\
$2.75\\
\\
$5.00\\
Original Price $5.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4395886959/5000-mega-bundle-wall-art-gallery-wall?click_key=344409e99c854dba169c07359fd7b7d2%3ALT26723892358ffbdbe8bd7c61fe6cf7df9521f257&click_sum=a456b3ea&ls=r&ref=related-1&pro=1&sts=1&dd=1&content_source=344409e99c854dba169c07359fd7b7d2%253ALT26723892358ffbdbe8bd7c61fe6cf7df9521f257 "5000+ Mega Bundle Wall Art, Gallery Wall Art, Printable Wall Art, Eclectic Gallery Set, Maximalist Wall Art, Trendy Vintage Prints")




Add to Favorites


- [![Landscape House Print, Moody Art Print Download, Victorian Era Prints, Gallery Wall Art, Vintage Oil Painting](https://i.etsystatic.com/32066133/r/il/de4015/5341397272/il_340x270.5341397272_fqyw.jpg)\\
\\
Digital download\\
\\
\\
**Landscape House Print, Moody Art Print Download, Victorian Era Prints, Gallery Wall Art, Vintage Oil Painting**\\
\\
Sale Price $2.20\\
$2.20\\
\\
$4.00\\
Original Price $4.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1562621816/landscape-house-print-moody-art-print?click_key=344409e99c854dba169c07359fd7b7d2%3ALTe0df475be9965dd243ffaec70f6b289c96bc7289&click_sum=058af817&ls=r&ref=related-2&pro=1&sts=1&dd=1&content_source=344409e99c854dba169c07359fd7b7d2%253ALTe0df475be9965dd243ffaec70f6b289c96bc7289 "Landscape House Print, Moody Art Print Download, Victorian Era Prints, Gallery Wall Art, Vintage Oil Painting")




Add to Favorites


- [![600+ Advertisement Vintage Mega Wall Art Bundle, Printable Wall Art, Maximalist Decor, Trendy Aesthetic Prints, Eclectic Wall Art, Digital](https://i.etsystatic.com/32066133/r/il/2dc42b/7348628716/il_340x270.7348628716_dzp6.jpg)\\
\\
Digital download\\
\\
\\
**600+ Advertisement Vintage Mega Wall Art Bundle, Printable Wall Art, Maximalist Decor, Trendy Aesthetic Prints, Eclectic Wall Art, Digital**\\
\\
Sale Price $2.75\\
$2.75\\
\\
$5.00\\
Original Price $5.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4397164670/600-advertisement-vintage-mega-wall-art?click_key=344409e99c854dba169c07359fd7b7d2%3ALT15e9a0a20d1e2fbe0e005f43cf6fee68934426ee&click_sum=f427c47c&ls=r&ref=related-3&pro=1&sts=1&dd=1&content_source=344409e99c854dba169c07359fd7b7d2%253ALT15e9a0a20d1e2fbe0e005f43cf6fee68934426ee "600+ Advertisement Vintage Mega Wall Art Bundle, Printable Wall Art, Maximalist Decor, Trendy Aesthetic Prints, Eclectic Wall Art, Digital")




Add to Favorites


- [![Vintage Christmas Santa Print, Christmas Decor, Moody Printable Wall Art, Neutral Santa Holding Tree Drawing Winter Forest Holiday Poster](https://i.etsystatic.com/32066133/c/1721/1721/163/461/il/c74763/7301937009/il_340x270.7301937009_emp4.jpg)\\
\\
Digital download\\
\\
\\
**Vintage Christmas Santa Print, Christmas Decor, Moody Printable Wall Art, Neutral Santa Holding Tree Drawing Winter Forest Holiday Poster**\\
\\
Sale Price $2.20\\
$2.20\\
\\
$4.00\\
Original Price $4.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4380682623/vintage-christmas-santa-print-christmas?click_key=b346ca80b39fdbdbcbd8af672e6ac720cd4d4245%3A4380682623&click_sum=dafe0126&ref=related-4&pro=1&sts=1&dd=1 "Vintage Christmas Santa Print, Christmas Decor, Moody Printable Wall Art, Neutral Santa Holding Tree Drawing Winter Forest Holiday Poster")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 10, 2025


[215 favorites](https://www.etsy.com/listing/1733249409/5000-mega-bundle-wall-art-gallery-wall/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?amp%3Bclick_sum=a955d84b&%3Bls=s&%3Bga_order=most_relevant&%3Bga_search_type=vintage&%3Bga_view_type=gallery&%3Bga_search_query=List+10+wall+prints+under+%2425+from+Etsy&%3Bref=search_grid-216189-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bpop=1&%3Bsts=1&%3Bdd=1&%3Bcontent_source=46523a64-3613-40f1-8803-e488d3effaa9%253ALT5c9a465cf721d5cf58f6782972c0500e783b5c6f&explicit=1&ref=breadcrumb_listing) [Prints](https://www.etsy.com/c/art-and-collectibles/prints?amp%3Bclick_sum=a955d84b&%3Bls=s&%3Bga_order=most_relevant&%3Bga_search_type=vintage&%3Bga_view_type=gallery&%3Bga_search_query=List+10+wall+prints+under+%2425+from+Etsy&%3Bref=search_grid-216189-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bpop=1&%3Bsts=1&%3Bdd=1&%3Bcontent_source=46523a64-3613-40f1-8803-e488d3effaa9%253ALT5c9a465cf721d5cf58f6782972c0500e783b5c6f&explicit=1&ref=breadcrumb_listing) [Digital Prints](https://www.etsy.com/c/art-and-collectibles/prints/digital-prints?amp%3Bclick_sum=a955d84b&%3Bls=s&%3Bga_order=most_relevant&%3Bga_search_type=vintage&%3Bga_view_type=gallery&%3Bga_search_query=List+10+wall+prints+under+%2425+from+Etsy&%3Bref=search_grid-216189-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bpop=1&%3Bsts=1&%3Bdd=1&%3Bcontent_source=46523a64-3613-40f1-8803-e488d3effaa9%253ALT5c9a465cf721d5cf58f6782972c0500e783b5c6f&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Prints

[Pediatrician Cartoon - US](https://www.etsy.com/market/pediatrician_cartoon) [Buy E Thomas Paintings Online](https://www.etsy.com/market/e_thomas_paintings) [Garden hummingbird Art Print (Matted)](https://www.etsy.com/listing/1736717704/garden-hummingbird-art-print-matted) [Florida to Alaska Print - Prints](https://www.etsy.com/listing/1759780270/florida-to-alaska-print-watercolor-map) [Vintage Textile Art Print William Morris Digital Download PRINTABLE Antique Floral Textile Wall Art #41 - Prints](https://www.etsy.com/listing/1461122223/vintage-textile-art-print-william-morris) [Shop Elote Art](https://www.etsy.com/market/elote_art) [Buy Cursive Hello Print Online](https://www.etsy.com/market/cursive_hello_print)

Home Decor

[Marble Display Holder for Sale](https://www.etsy.com/market/marble_display_holder) [Spring Floral Bottle Bouquet - Home Decor](https://www.etsy.com/listing/1871946276/spring-floral-bottle-bouquet-pastel)

Collectibles

[Fallout Graduation for Sale](https://www.etsy.com/market/fallout_graduation)

Shopping

[Christmas I Love You Snow Much Craft - US](https://www.etsy.com/market/christmas_i_love_you_snow_much_craft) [8x10 Shadow Boxes - US](https://www.etsy.com/market/8x10_shadow_boxes)

Patches & Pins

[Toretto Patch for Sale](https://www.etsy.com/market/toretto_patch)

Bracelets

[Shop Sterling Smoky Topaz Bracelet](https://www.etsy.com/market/sterling_smoky_topaz_bracelet)

Beads Gems & Cabochons

[Gold Artemis Coin Pendant - Beads, Gems & Cabochons](https://www.etsy.com/listing/1688517407/greek-coin-charm-gold-artemis-coin)

Furniture

[Midcentury Dresser - US](https://www.etsy.com/market/midcentury_dresser)

Necklaces

[Dagger Pendant Necklace - Necklaces](https://www.etsy.com/listing/1573005926/dagger-pendant-necklace-unique-mens-gift)

Gender Neutral Adult Clothing

[Emo Shirt Skeleton Shirt Goth Shirt E Girl Clothing Elder Emo Shirt Mall Goth Clothing Emo Clothing Emo Clothes Emo Boy Accessories Skeleton by SparrowAndWilde](https://www.etsy.com/listing/1307407482/emo-shirt-skeleton-shirt-goth-shirt-e)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1733249409%2F5000-mega-bundle-wall-art-gallery-wall%3Famp%253Bclick_sum%3Da955d84b%26amp%253Bls%3Ds%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dvintage%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DList%2B10%2Bwall%2Bprints%2Bunder%2B%252425%2Bfrom%2BEtsy%26amp%253Bref%3Dsearch_grid-216189-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bpop%3D1%26amp%253Bsts%3D1%26amp%253Bdd%3D1%26amp%253Bcontent_source%3D46523a64-3613-40f1-8803-e488d3effaa9%25253ALT5c9a465cf721d5cf58f6782972c0500e783b5c6f&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgxNDkzMTowM2Y4MDM1NTA1Mjk2M2YwNjFjN2I5NmNkYjE2MWQwNg==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1733249409%2F5000-mega-bundle-wall-art-gallery-wall%3Famp%253Bclick_sum%3Da955d84b%26amp%253Bls%3Ds%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dvintage%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DList%2B10%2Bwall%2Bprints%2Bunder%2B%252425%2Bfrom%2BEtsy%26amp%253Bref%3Dsearch_grid-216189-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bpop%3D1%26amp%253Bsts%3D1%26amp%253Bdd%3D1%26amp%253Bcontent_source%3D46523a64-3613-40f1-8803-e488d3effaa9%25253ALT5c9a465cf721d5cf58f6782972c0500e783b5c6f) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1733249409/5000-mega-bundle-wall-art-gallery-wall?amp;click_sum=a955d84b&amp;ls=s&amp;ga_order=most_relevant&amp;ga_search_type=vintage&amp;ga_view_type=gallery&amp;ga_search_query=List+10+wall+prints+under+%2425+from+Etsy&amp;ref=search_grid-216189-1-2&amp;sr_prefetch=1&amp;pf_from=search&amp;pro=1&amp;pop=1&amp;sts=1&amp;dd=1&amp;content_source=46523a64-3613-40f1-8803-e488d3effaa9%253ALT5c9a465cf721d5cf58f6782972c0500e783b5c6f#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1733249409%2F5000-mega-bundle-wall-art-gallery-wall%3Famp%253Bclick_sum%3Da955d84b%26amp%253Bls%3Ds%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dvintage%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DList%2B10%2Bwall%2Bprints%2Bunder%2B%252425%2Bfrom%2BEtsy%26amp%253Bref%3Dsearch_grid-216189-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bpop%3D1%26amp%253Bsts%3D1%26amp%253Bdd%3D1%26amp%253Bcontent_source%3D46523a64-3613-40f1-8803-e488d3effaa9%25253ALT5c9a465cf721d5cf58f6782972c0500e783b5c6f)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for bonafidesaVINTAGE

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![May include: A gallery wall featuring a curated collection of 5000+ vintage prints. The assortment includes landscapes, botanical illustrations, portraits, and still life paintings in various sizes and frames.  The prints are displayed on a light beige wall, creating a cohesive and aesthetically pleasing display.  The overall style is vintage and eclectic, with a muted color palette of creams, browns, and greens. The text '5000+ Vintage Prints' is prominently displayed at the bottom.](https://i.etsystatic.com/32066133/r/il/3648b2/6046332173/il_300x300.6046332173_2xu1.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/YATAY_ETSY_VI%CC%87DEO_sxgv1u.jpg)

- ![May include: Four curated gallery wall sets showcasing diverse artistic styles.  'Indigo-Green' features nature scenes and dark-toned artwork. 'Coastal' presents seascapes and light blues. 'Spring' displays floral arrangements and pastel hues. 'Warm Tones' offers rich earth tones and classical paintings. Each set includes various sizes and frames, creating a cohesive yet varied aesthetic.  All sets are ideal for home decor and interior design.](https://i.etsystatic.com/32066133/r/il/6a0eaf/6046332189/il_300x300.6046332189_p5ei.jpg)
- ![May include: Four gallery wall sets showcasing various framed prints.  Taupe set features landscapes and still life. Pink and green set includes ballet dancers and floral arrangements. Spring set displays nature scenes and a butterfly. Winter set shows cityscapes and winter scenes. All sets feature a variety of artistic styles and color palettes.](https://i.etsystatic.com/32066133/r/il/0c2263/6046332227/il_300x300.6046332227_35xk.jpg)
- ![May include: Four curated gallery wall sets showcasing various painting styles.  'Still Life' features floral and landscape paintings in muted tones. 'Warm Tones' presents a collection of warm-toned artwork, including still life and landscape scenes. 'Burnt Orange' displays a palette of burnt orange hues in landscapes and still life. 'Muted Green' showcases paintings in muted greens and floral arrangements. Each set offers a diverse range of artistic styles and color palettes for home decor.](https://i.etsystatic.com/32066133/r/il/44751d/6046332275/il_300x300.6046332275_mr4p.jpg)
- ![May include: 5000+ Vintage Prints Mega Bundle.  A collage showcases numerous framed sepia-toned and muted beige vintage prints.  The prints depict various subjects including floral arrangements, landscapes, and still lifes.  The overall aesthetic is elegant and classic.  The text '5000+' and 'Vintage Prints MEGA BUNDLE' is prominently displayed.](https://i.etsystatic.com/32066133/r/il/10953a/5998257966/il_300x300.5998257966_s7k7.jpg)
- ![May include: A gallery wall showcasing 5000+ vintage prints.  The prints feature various subjects including floral arrangements, landscapes, portraits, and birds.  The frames are light wood, and the prints are in muted tones of beige, cream, and green.  The text '5000+ Vintage Prints' is prominently displayed at the bottom.](https://i.etsystatic.com/32066133/r/il/80f390/5998258036/il_300x300.5998258036_9jyg.jpg)
- ![May include: A collage showcases 5000+ vintage prints.  The collection features various styles, including landscapes, portraits, and nature scenes in muted blues, grays, and creams.  Images depict cityscapes with bridges, snowy villages, peacocks, horses, and floral patterns.  The text '5000+ Vintage Prints' is prominently displayed.](https://i.etsystatic.com/32066133/r/il/e0e5ac/6046332491/il_300x300.6046332491_dv8c.jpg)
- ![May include: A gallery wall showcasing 5000+ vintage prints.  The prints feature a variety of subjects including cityscapes, floral botanical illustrations, and classical art.  The prints are framed in light wood and arranged on a cream-colored wall. The text '5000+ Vintage Prints' is prominently displayed at the bottom.](https://i.etsystatic.com/32066133/r/il/0671c8/6046332557/il_300x300.6046332557_f5fh.jpg)
- ![May include: A gallery wall showcasing 5000+ vintage floral prints in various sizes and frames.  The prints feature muted tones of beige, cream, and brown, depicting bouquets of roses, lilies, and other flowers in antique-style arrangements.  Many of the prints are in ornate wooden frames. The text '5000+ Vintage Prints' is prominently displayed at the bottom.](https://i.etsystatic.com/32066133/r/il/a6806b/5998258260/il_300x300.5998258260_o9zv.jpg)
- ![May include: A gallery wall showcasing a curated collection of 5000+ vintage prints.  The prints feature a variety of subjects and styles, including landscapes, cityscapes, floral still lifes, and abstract designs.  The frames are light-colored wood, creating a cohesive and aesthetically pleasing display. The prints are in various sizes and orientations, adding visual interest. The text '5000+ VINTAGE PRINTS' is overlaid on the image.](https://i.etsystatic.com/32066133/r/il/fc4233/6046332699/il_300x300.6046332699_l65e.jpg)