[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?amp;click_sum=97767668&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;pro=1&amp;sts=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Bags & Purses](https://www.etsy.com/c/bags-and-purses?amp%3Bclick_sum=97767668&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-0)
- [Handbags](https://www.etsy.com/c/bags-and-purses/handbags?amp%3Bclick_sum=97767668&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-1)
- [Shoulder Bags](https://www.etsy.com/c/bags-and-purses/handbags/shoulder-bags?amp%3Bclick_sum=97767668&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-2)

Etsy’s Pick

Etsy’s Picks are hand selected by our style experts to highlight items from shops that have shown quality, reliability and style.

[Discover More](https://www.etsy.com/featured/hub/etsy-picks?ref=listing_etsys_pick_signal)


Add to Favorites


- ![May include: A black leather tote bag with a wide opening and two handles.](https://i.etsystatic.com/15225213/r/il/7b1a5f/4161283680/il_794xN.4161283680_f8yl.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![May include: A brown leather tote bag with a wide opening and two handles.](https://i.etsystatic.com/15225213/r/il/a55c21/4161225086/il_794xN.4161225086_m3ci.jpg)
- ![May include: Four leather tote bags in different colors: cappuccino, yellow, caramel, and cognac. The bags have a simple design with two top handles and a spacious interior.](https://i.etsystatic.com/15225213/r/il/b3ea11/4347713650/il_794xN.4347713650_acpc.jpg)
- ![May include: Four leather tote bags in different colors: chocolate, red, green, and navy blue. The bags have a simple design with a single handle and a spacious interior. The bags are made of high-quality leather and are perfect for everyday use.](https://i.etsystatic.com/15225213/r/il/ad789d/4395104261/il_794xN.4395104261_f2jk.jpg)
- ![May include: Four leather tote bags in different colors: blue, burgundy, black, and olive. The bags have a simple design with two top handles and a spacious interior.](https://i.etsystatic.com/15225213/r/il/1b1674/4347713652/il_794xN.4347713652_2pqb.jpg)
- ![May include: A brown leather tote bag with a large capacity. The bag has two handles and is shown in an extra large size.](https://i.etsystatic.com/15225213/r/il/2b3d9b/4161221872/il_794xN.4161221872_23q2.jpg)
- ![May include: Four brown leather tote bags in different sizes. The bags have a simple design with two handles. The bags are labeled 'MINI SIZE', 'SMALL SIZE', 'MEDIUM SIZE', and 'LARGE SIZE'.](https://i.etsystatic.com/15225213/r/il/24cb99/4208879061/il_794xN.4208879061_hxy6.jpg)
- ![May include: A brown leather tote bag with a single pocket on the front. The bag is shown in three different views: the interior of the bag, the exterior of the bag, and a close-up of the leather texture. The text 'DETAILS' is displayed in the image.](https://i.etsystatic.com/15225213/r/il/12b5f8/4161222522/il_794xN.4161222522_17xq.jpg)
- ![May include: Five brown leather tote bags of different sizes. The bags are lined up from largest to smallest, labeled 'EXTRA LARGE', 'LARGE', 'MEDIUM', 'SMALL', and 'MINI'.](https://i.etsystatic.com/15225213/r/il/e3c3ea/4161222642/il_794xN.4161222642_4sos.jpg)
- ![May include: A brown leather tote bag with personalization options. The bag has two handles and a large main compartment. The personalization options include engraving, stamping, and text. The engraving options are shown in black, while the stamping options are shown in gold and silver. The text options include the customer's initials, a name, or a congratulatory message. The bag is shown on a white wooden background with a black arrow pointing to the bottom right corner of the bag.](https://i.etsystatic.com/15225213/r/il/a8345e/4208879131/il_794xN.4208879131_skh6.jpg)

- ![May include: A black leather tote bag with a wide opening and two handles.](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_75x75.4161283680_f8yl.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/%D0%94%D0%B6%D0%B5%D0%BD%D1%96%D1%84%D0%B5%D1%80_4_%D0%B7_%D0%BD%D0%BE%D1%80%D0%BC_%D1%80%D1%83%D1%87%D0%BA%D0%B0%D0%BC%D0%B8_l4spul.jpg)

- ![May include: A brown leather tote bag with a wide opening and two handles.](https://i.etsystatic.com/15225213/r/il/a55c21/4161225086/il_75x75.4161225086_m3ci.jpg)
- ![May include: Four leather tote bags in different colors: cappuccino, yellow, caramel, and cognac. The bags have a simple design with two top handles and a spacious interior.](https://i.etsystatic.com/15225213/r/il/b3ea11/4347713650/il_75x75.4347713650_acpc.jpg)
- ![May include: Four leather tote bags in different colors: chocolate, red, green, and navy blue. The bags have a simple design with a single handle and a spacious interior. The bags are made of high-quality leather and are perfect for everyday use.](https://i.etsystatic.com/15225213/r/il/ad789d/4395104261/il_75x75.4395104261_f2jk.jpg)
- ![May include: Four leather tote bags in different colors: blue, burgundy, black, and olive. The bags have a simple design with two top handles and a spacious interior.](https://i.etsystatic.com/15225213/r/il/1b1674/4347713652/il_75x75.4347713652_2pqb.jpg)
- ![May include: A brown leather tote bag with a large capacity. The bag has two handles and is shown in an extra large size.](https://i.etsystatic.com/15225213/r/il/2b3d9b/4161221872/il_75x75.4161221872_23q2.jpg)
- ![May include: Four brown leather tote bags in different sizes. The bags have a simple design with two handles. The bags are labeled 'MINI SIZE', 'SMALL SIZE', 'MEDIUM SIZE', and 'LARGE SIZE'.](https://i.etsystatic.com/15225213/r/il/24cb99/4208879061/il_75x75.4208879061_hxy6.jpg)
- ![May include: A brown leather tote bag with a single pocket on the front. The bag is shown in three different views: the interior of the bag, the exterior of the bag, and a close-up of the leather texture. The text 'DETAILS' is displayed in the image.](https://i.etsystatic.com/15225213/r/il/12b5f8/4161222522/il_75x75.4161222522_17xq.jpg)
- ![May include: Five brown leather tote bags of different sizes. The bags are lined up from largest to smallest, labeled 'EXTRA LARGE', 'LARGE', 'MEDIUM', 'SMALL', and 'MINI'.](https://i.etsystatic.com/15225213/r/il/e3c3ea/4161222642/il_75x75.4161222642_4sos.jpg)
- ![May include: A brown leather tote bag with personalization options. The bag has two handles and a large main compartment. The personalization options include engraving, stamping, and text. The engraving options are shown in black, while the stamping options are shown in gold and silver. The text options include the customer's initials, a name, or a congratulatory message. The bag is shown on a white wooden background with a black arrow pointing to the bottom right corner of the bag.](https://i.etsystatic.com/15225213/r/il/a8345e/4208879131/il_75x75.4208879131_skh6.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1304733755%2Fwoman-shoulder-bag-leather-shopping-bag%23report-overlay-trigger)

In 20+ carts

Price:$63.75+


Original Price:
$75.00+


Loading


15% off


•

Limited time sale


# Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote

Made by [OTLbags](https://www.etsy.com/shop/OTLbags)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?amp;click_sum=97767668&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;pro=1&amp;sts=1#reviews)

Returns & exchanges accepted

SIZE


Select an option

MINI SIZE ($63.75)

SMALL SIZE ($72.25)

MEDIUM SIZE ($80.75)

LARGE SIZE ($85.00)

EXTRA SIZE ($93.50)

Please select an option


Primary color


Select a color

Black

Blue

Green

Yellow

Red

Caramel

Cognac

Burgundy

Navy blue

Cappuccino

Chocolate

Please select a color


Add personalization
(optional)

- Personalization





You can choose one of the personalization ideas and simply indicate its number (ideas for personalization are shown in the photo). You can also contact us to clarify the style and details of your personalization.


















0/256


From **$11/month**, or 4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Made by [OTLbags](https://www.etsy.com/shop/OTLbags)

- Materials: Full grain leather, Cognac leather, Caramel leather, Black leather, Pockets



● This bag model is simply the best solution for a modern woman. Its shape is perfect, the size is very roomy and you can get both comfort and a beautiful minimalist design in one bag. The quality of genuine leather for bags is very high, the bag keeps its shape perfectly. We also offer several size options for your most necessary daily items: phone, gadgets, cosmetic bag, wallet, notepad ●

● On top between the handles of the bag is the logo of the store. It can be a place for your personalization, initials, name or logo of your company. Also we can personalize your bag in the bottom corner of the bag

Inside there are two pockets for the phone and other things ●

● We pay special attention to personalization, because a bag can be a good gift. We offer a wide range of embossing and engraving options free of charge for you and your loved ones

OTL bags takes our leather goods packaging responsibly and ensures that your bag or wallet arrives in perfect condition ●

● We engrave all congratulatory texts on leather tags so that the received gift brings maximum positive emotions ●

● OTL bags offers a wide range of natural leather colors: Cognac, Caramel, Cappuccino, Bordeaux, Green, Blue, Dark blue, Olive, Yellow, Chocolate, Black ●

● For any questions, you can write us a message and we will be happy to help you

It is also very important for us that part of our profit goes to help our country.

Leather products OTL bags are high quality accessories for you and your loved ones!

● ATTENTION!!! IF YOU WANT TO MAKE CHANGES TO THE BAG SUCH AS AN ADDITIONAL INTERNAL MAGNETIC BUTTON, HEIGHT OF HANDLES IN THE BAG OR NOT TO PLACE THE LOGO PLEASE CONTACT US AND WRITE IT IN A MESSAGE! ●

DIMENSIONS:

● MINI SIZE ●

Height: 11 inches (27 cm)

Width: 9,5 inches (24 cm)

Depth: 5,5 inches (13 cm)

Handle height: 9 inches (22.5 cm)

2 inside pockets

Weight (approximate) - 1.1 pounds (500 grams)

● SMALL SIZE ●

Height: 14 inches (35 cm)

Width: 12.5 inches (32 cm)

Depth: 5 inches (12 cm)

Handle height: 9.5 inches (24 cm)

2 inside pockets

Height: 5.2 inches (13 cm)

Width: 5.2 inches (13 cm)

Weight (approximate) - 1.54 pounds (700 grams)

● MEDIUM SIZE ●

Height: 12.5 inches (32 cm)

Width: 14.5 inches (36 cm)

Depth: 5 inches (12 cm)

Handle height 10.5 inches (21 cm)

2 inside pockets

Height: 5.2 inches (13 cm)

Width: 5.2 inches (13 cm)

Weight (approximate) - 1.87 pounds (850 grams)

● LARGE SIZE ●

Height: 12.5 inches (32 cm)

Width: 16 inches (40 cm)

Depth: 6 inches (15 cm)

Handle height 10.5 inches (21 cm)

2 inside pockets

Height: 5.2 inches (13 cm)

Width: 5.2 inches (13 cm)

Weight (approximate) - 2.2 pounds (1000 grams)

● EXTRA LARGE SIZE ●

Height: 14 inches (35 cm)

Width: 18 inches (45 cm)

Depth: 6 inches (15 cm)

Handle height 12.5 inches (31 cm)

2 inside pockets

Height: 5.2 inches (13 cm)

Width: 5.2 inches (13 cm)

Weight (approximate) - 2.5 pounds (1150 grams)


## Shipping and return policies

Loading


- Order today to get by

**Nov 20-Dec 8**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 21 days


- Free shipping


- Ships from: **Ukraine**


Deliver to United States

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## Meet your sellers

![Victoria Klochkovska](https://i.etsystatic.com/15225213/r/isla/6b1414/80557875/isla_75x75.80557875_9a3goool.jpg)

Victoria Klochkovska

Owner of [OTLbags](https://www.etsy.com/shop/OTLbags?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoxMDk2NDY2MDQ6MTc2MjgyMTQ3NDo2NjIxMWY3MDFhNmQxMzYxZmY0MmEzMDhkNDBiZjFmZg%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1304733755%2Fwoman-shoulder-bag-leather-shopping-bag%3Famp%253Bclick_sum%3D97767668%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bpro%3D1%26amp%253Bsts%3D1)

[Message Victoria](https://www.etsy.com/messages/new?with_id=109646604&referring_id=1304733755&referring_type=listing&recipient_id=109646604&from_action=contact-seller)

This seller usually responds **within a few hours.**

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (140)

4.8/5

item average

4.9Item quality

4.6Shipping

4.8Customer service

96%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Beautiful

Love it

Great quality

Would recommend

Excellent communication

Excellent craftsmanship

Excellent customer service


Filter by category


Quality (79)


Seller service (44)


Appearance (40)


Shipping & Packaging (25)


Description accuracy (18)


Sizing & Fit (15)


Comfort (10)


Value (8)


Ease of use (3)


Condition (2)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Ana Ladd](https://www.etsy.com/people/qkdfn6n6ga8h2rw7?ref=l_review)
Nov 7, 2025


Wonderful bag.. Great service. Love ❤️



[Ana Ladd](https://www.etsy.com/people/qkdfn6n6ga8h2rw7?ref=l_review)
Nov 7, 2025


5 out of 5 stars
5

This item

[Tawna](https://www.etsy.com/people/jwfjudof?ref=l_review)
Nov 7, 2025


The seller texted when the product shipped. My daughter was very happy with the quality and loved me the bag



[Tawna](https://www.etsy.com/people/jwfjudof?ref=l_review)
Nov 7, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/214e53/73577647/iusa_75x75.73577647_9jln.jpg?version=0)

[Kyle Torgerson](https://www.etsy.com/people/e3xpphrh?ref=l_review)
Nov 4, 2025


Perfect transaction! Thank you very much!



![](https://i.etsystatic.com/iusa/214e53/73577647/iusa_75x75.73577647_9jln.jpg?version=0)

[Kyle Torgerson](https://www.etsy.com/people/e3xpphrh?ref=l_review)
Nov 4, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/63788a/77781235/iusa_75x75.77781235_1ig1.jpg?version=0)

[Bibiana PadillaMaltos](https://www.etsy.com/people/bbbibiana?ref=l_review)
Oct 16, 2025


Loved it! thank you so much!



![](https://i.etsystatic.com/iusa/63788a/77781235/iusa_75x75.77781235_1ig1.jpg?version=0)

[Bibiana PadillaMaltos](https://www.etsy.com/people/bbbibiana?ref=l_review)
Oct 16, 2025


View all reviews for this item

### Photos from reviews

![Jackie added a photo of their purchase](https://i.etsystatic.com/iap/0d14eb/7077642119/iap_300x300.7077642119_dw3hc5oe.jpg?version=0)

![Sandra added a photo of their purchase](https://i.etsystatic.com/iap/72ac19/7011364588/iap_300x300.7011364588_4cy8pcvo.jpg?version=0)

![Camille added a photo of their purchase](https://i.etsystatic.com/iap/30607f/7201002110/iap_300x300.7201002110_k89uh48q.jpg?version=0)

![Isabel added a photo of their purchase](https://i.etsystatic.com/iap/894843/7259609105/iap_300x300.7259609105_cy20in2l.jpg?version=0)

![stacymquick added a photo of their purchase](https://i.etsystatic.com/iap/b57e2d/6948467866/iap_300x300.6948467866_ipbloiti.jpg?version=0)

![Francois added a photo of their purchase](https://i.etsystatic.com/iap/f75338/6935804862/iap_300x300.6935804862_2vuh2snq.jpg?version=0)

![Cheryll added a photo of their purchase](https://i.etsystatic.com/iap/c9f72f/6858295335/iap_300x300.6858295335_fyp1v6g3.jpg?version=0)

![Masha added a photo of their purchase](https://i.etsystatic.com/iap/3d3156/6599079938/iap_300x300.6599079938_tp97fih1.jpg?version=0)

![Jackie added a photo of their purchase](https://i.etsystatic.com/iap/59e10e/6863585068/iap_300x300.6863585068_4fzl2ayl.jpg?version=0)

![sharon added a photo of their purchase](https://i.etsystatic.com/iap/77e327/6475710800/iap_300x300.6475710800_lvzz21i0.jpg?version=0)

![Veronica added a photo of their purchase](https://i.etsystatic.com/iap/cd443d/6574703129/iap_300x300.6574703129_syelyphs.jpg?version=0)

![Julia added a photo of their purchase](https://i.etsystatic.com/iap/96b9c9/6808195186/iap_300x300.6808195186_32owgw5u.jpg?version=0)

![Stephanie added a photo of their purchase](https://i.etsystatic.com/iap/3f69ec/6818359747/iap_300x300.6818359747_r25ja80c.jpg?version=0)

![Goody added a photo of their purchase](https://i.etsystatic.com/iap/b153be/6403191684/iap_300x300.6403191684_ki4jo8ao.jpg?version=0)

![Lynn added a photo of their purchase](https://i.etsystatic.com/iap/9a90ff/6720212306/iap_300x300.6720212306_d7dcj5gh.jpg?version=0)

![Cassandra added a photo of their purchase](https://i.etsystatic.com/iap/2f842f/6308163366/iap_300x300.6308163366_48djcapp.jpg?version=0)

![Linda added a photo of their purchase](https://i.etsystatic.com/iap/508d35/6810066979/iap_300x300.6810066979_dxcu0pvv.jpg?version=0)

![Tara added a photo of their purchase](https://i.etsystatic.com/iap/2039d3/6485150643/iap_300x300.6485150643_iizs66ay.jpg?version=0)

![Chiraporn added a photo of their purchase](https://i.etsystatic.com/iap/b237e5/6285625188/iap_300x300.6285625188_qxb3pty1.jpg?version=0)

![Mia added a photo of their purchase](https://i.etsystatic.com/iap/dbd90e/6545458489/iap_300x300.6545458489_sr8fnlql.jpg?version=0)

[![OTLbags](https://i.etsystatic.com/iusa/d924a4/95615159/iusa_75x75.95615159_t4os.jpg?version=0)](https://www.etsy.com/shop/OTLbags?ref=shop_profile&listing_id=1304733755)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[OTLbags](https://www.etsy.com/shop/OTLbags?ref=shop_profile&listing_id=1304733755)

[Owned by Victoria Klochkovska](https://www.etsy.com/shop/OTLbags?ref=shop_profile&listing_id=1304733755) \|

Ukraine

4.9
(587)


1.9k sales

8 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=109646604&referring_id=1304733755&referring_type=listing&recipient_id=109646604&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoxMDk2NDY2MDQ6MTc2MjgyMTQ3NDo2NjIxMWY3MDFhNmQxMzYxZmY0MmEzMDhkNDBiZjFmZg%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1304733755%2Fwoman-shoulder-bag-leather-shopping-bag%3Famp%253Bclick_sum%3D97767668%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bpro%3D1%26amp%253Bsts%3D1)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/OTLbags?ref=lp_mys_mfts)

- [![Black leather tote, Woman shoulder bag, Leather shoulder bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag](https://i.etsystatic.com/15225213/r/il/8b339e/4240935944/il_340x270.4240935944_atin.jpg)\\
\\
**Black leather tote, Woman shoulder bag, Leather shoulder bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag**\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1322848947/black-leather-tote-woman-shoulder-bag?click_key=2cf23ebc7f77e42f2298eb6d39b624f2%3ALT287ee0d48058ed6c7aff73ab5dd5cf0d98afaa36&click_sum=51c624e7&ls=r&ref=related-1&pro=1&sts=1&content_source=2cf23ebc7f77e42f2298eb6d39b624f2%253ALT287ee0d48058ed6c7aff73ab5dd5cf0d98afaa36 "Black leather tote, Woman shoulder bag, Leather shoulder bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag")




Add to Favorites


- [![Woman shoulder bag, Leather shopping bag, Cognac leather tote, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag](https://i.etsystatic.com/15225213/r/il/cb1c45/4203631199/il_340x270.4203631199_hzhh.jpg)\\
\\
**Woman shoulder bag, Leather shopping bag, Cognac leather tote, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag**\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1289536590/woman-shoulder-bag-leather-shopping-bag?click_key=2cf23ebc7f77e42f2298eb6d39b624f2%3ALT95f6814794aad578e15f94b69d5a353e1dd47ddf&click_sum=52f9b4f8&ls=r&ref=related-2&pro=1&sts=1&content_source=2cf23ebc7f77e42f2298eb6d39b624f2%253ALT95f6814794aad578e15f94b69d5a353e1dd47ddf "Woman shoulder bag, Leather shopping bag, Cognac leather tote, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag")




Add to Favorites


- [![Tote leather bag, Cognac leather tote, Leather tote bag, Small tote bag, Woman shoulder bag, Gift for woman, Leather shopping bag, Gift](https://i.etsystatic.com/15225213/r/il/3e9130/4363900550/il_340x270.4363900550_eys1.jpg)\\
\\
**Tote leather bag, Cognac leather tote, Leather tote bag, Small tote bag, Woman shoulder bag, Gift for woman, Leather shopping bag, Gift**\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1336944976/tote-leather-bag-cognac-leather-tote?click_key=2cf23ebc7f77e42f2298eb6d39b624f2%3ALTbdcad5117e3c96634ae9d576f341ee062665eba4&click_sum=d634c011&ls=r&ref=related-3&pro=1&sts=1&content_source=2cf23ebc7f77e42f2298eb6d39b624f2%253ALTbdcad5117e3c96634ae9d576f341ee062665eba4 "Tote leather bag, Cognac leather tote, Leather tote bag, Small tote bag, Woman shoulder bag, Gift for woman, Leather shopping bag, Gift")




Add to Favorites


- [![Green leather tote, Tote leather bag, Leather tote bag, Small tote bag, Woman shoulder bag, Gift for woman, Leather shopping bag, Gift](https://i.etsystatic.com/15225213/c/3000/2384/0/64/il/468790/4158028942/il_340x270.4158028942_knxt.jpg)\\
\\
**Green leather tote, Tote leather bag, Leather tote bag, Small tote bag, Woman shoulder bag, Gift for woman, Leather shopping bag, Gift**\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1289974768/green-leather-tote-tote-leather-bag?click_key=1fc384e64887d156c07e3ded7e749a63903ee873%3A1289974768&click_sum=1314367d&ref=related-4&pro=1&sts=1 "Green leather tote, Tote leather bag, Leather tote bag, Small tote bag, Woman shoulder bag, Gift for woman, Leather shopping bag, Gift")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 10, 2025


[2944 favorites](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?amp%3Bclick_sum=97767668&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Handbags](https://www.etsy.com/c/bags-and-purses/handbags?amp%3Bclick_sum=97767668&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Shoulder Bags](https://www.etsy.com/c/bags-and-purses/handbags/shoulder-bags?amp%3Bclick_sum=97767668&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&%3Bsts=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Drawing & Illustration

[Retro truck with pumpkins svg / Truck with pumpkins svg / Pumpkin vintage truck / Fall truck with pumpkin svg / fall truck svg for cricut](https://www.etsy.com/listing/1790734984/retro-truck-with-pumpkins-svg-truck-with)

Music

[Stratocaster Trem Cover-The Brothers Series - Music](https://www.etsy.com/listing/963345572/stratocaster-trem-cover-the-brothers)

Paper

[Buy Ultimate Resell Digital Products Online](https://www.etsy.com/market/ultimate_resell_digital_products) [Printable Daily Cat Pet Care Chart - Paper, Stationery & Cards](https://www.etsy.com/listing/1306503345/printable-daily-cat-pet-care-chart)

Shopping

[Buy Taylor's Version Pillow Online](https://www.etsy.com/market/taylor%27s_version_pillow) [Buy Retirement Gifts For Choir Teacher Online](https://www.etsy.com/market/retirement_gifts_for_choir_teacher)

Books

[Rocketbook Case - US](https://www.etsy.com/market/rocketbook_case)

Rings

[Corazon Sagrado Ring - US](https://www.etsy.com/market/corazon_sagrado_ring)

Furniture

[Coalbrookdale Bench - US](https://www.etsy.com/market/coalbrookdale_bench)

Womens Clothing

[Luxury Bridal Lingerie for Sale](https://www.etsy.com/market/luxury_bridal_lingerie)

Patterns & How To

[Shop 13 Inch Doll Dress Pattern](https://www.etsy.com/market/13_inch_doll_dress_pattern) [Jasmine Becket Griffith - US](https://www.etsy.com/market/jasmine_becket_griffith)

Home Decor

[Shop No Kids Allowed](https://www.etsy.com/market/no_kids_allowed)

Riding & Farm Animals

[Buy Muletape Breastcollar Online](https://www.etsy.com/market/muletape_breastcollar)

Pouches & Coin Purses

[Personalized Gold Initial Accessory Pouch-Letter D - Pouches & Coin Purses](https://www.etsy.com/listing/4357660524/personalized-gold-initial-accessory)

Prints

[Buy Lancaster Pa Png Online](https://www.etsy.com/market/lancaster_pa_png)

Hand Fans

[Buy Scsu Fan Online](https://www.etsy.com/market/scsu_fan)

Handbags

[Buy Thick Felt Bag Online](https://www.etsy.com/market/thick_felt_bag)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1304733755%2Fwoman-shoulder-bag-leather-shopping-bag%3Famp%253Bclick_sum%3D97767668%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bpro%3D1%26amp%253Bsts%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgyMTQ3NDozOWNhMGQzZTA2N2FlMTAwYzYzYjIyMzEwZWUzMTFhZg==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1304733755%2Fwoman-shoulder-bag-leather-shopping-bag%3Famp%253Bclick_sum%3D97767668%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bpro%3D1%26amp%253Bsts%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?amp;click_sum=97767668&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;pro=1&amp;sts=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1304733755%2Fwoman-shoulder-bag-leather-shopping-bag%3Famp%253Bclick_sum%3D97767668%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bpro%3D1%26amp%253Bsts%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for OTLbags

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: not accepted

Please contact the seller if you have any problems with your order.

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


Customs and import taxes

Buyers are responsible for any customs and import taxes that may apply. I'm not responsible for delays due to customs.


## Seller details

### Other details

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=109646604&referring_id=15225213&referring_type=shop&recipient_id=109646604&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![May include: A black leather tote bag with a wide opening and two handles.](https://i.etsystatic.com/15225213/c/3000/3000/0/0/il/7b1a5f/4161283680/il_300x300.4161283680_f8yl.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/%D0%94%D0%B6%D0%B5%D0%BD%D1%96%D1%84%D0%B5%D1%80_4_%D0%B7_%D0%BD%D0%BE%D1%80%D0%BC_%D1%80%D1%83%D1%87%D0%BA%D0%B0%D0%BC%D0%B8_l4spul.jpg)

- ![May include: A brown leather tote bag with a wide opening and two handles.](https://i.etsystatic.com/15225213/r/il/a55c21/4161225086/il_300x300.4161225086_m3ci.jpg)
- ![May include: Four leather tote bags in different colors: cappuccino, yellow, caramel, and cognac. The bags have a simple design with two top handles and a spacious interior.](https://i.etsystatic.com/15225213/r/il/b3ea11/4347713650/il_300x300.4347713650_acpc.jpg)
- ![May include: Four leather tote bags in different colors: chocolate, red, green, and navy blue. The bags have a simple design with a single handle and a spacious interior. The bags are made of high-quality leather and are perfect for everyday use.](https://i.etsystatic.com/15225213/r/il/ad789d/4395104261/il_300x300.4395104261_f2jk.jpg)
- ![May include: Four leather tote bags in different colors: blue, burgundy, black, and olive. The bags have a simple design with two top handles and a spacious interior.](https://i.etsystatic.com/15225213/r/il/1b1674/4347713652/il_300x300.4347713652_2pqb.jpg)
- ![May include: A brown leather tote bag with a large capacity. The bag has two handles and is shown in an extra large size.](https://i.etsystatic.com/15225213/r/il/2b3d9b/4161221872/il_300x300.4161221872_23q2.jpg)
- ![May include: Four brown leather tote bags in different sizes. The bags have a simple design with two handles. The bags are labeled 'MINI SIZE', 'SMALL SIZE', 'MEDIUM SIZE', and 'LARGE SIZE'.](https://i.etsystatic.com/15225213/r/il/24cb99/4208879061/il_300x300.4208879061_hxy6.jpg)
- ![May include: A brown leather tote bag with a single pocket on the front. The bag is shown in three different views: the interior of the bag, the exterior of the bag, and a close-up of the leather texture. The text 'DETAILS' is displayed in the image.](https://i.etsystatic.com/15225213/r/il/12b5f8/4161222522/il_300x300.4161222522_17xq.jpg)
- ![May include: Five brown leather tote bags of different sizes. The bags are lined up from largest to smallest, labeled 'EXTRA LARGE', 'LARGE', 'MEDIUM', 'SMALL', and 'MINI'.](https://i.etsystatic.com/15225213/r/il/e3c3ea/4161222642/il_300x300.4161222642_4sos.jpg)
- ![May include: A brown leather tote bag with personalization options. The bag has two handles and a large main compartment. The personalization options include engraving, stamping, and text. The engraving options are shown in black, while the stamping options are shown in gold and silver. The text options include the customer's initials, a name, or a congratulatory message. The bag is shown on a white wooden background with a black arrow pointing to the bottom right corner of the bag.](https://i.etsystatic.com/15225213/r/il/a8345e/4208879131/il_300x300.4208879131_skh6.jpg)

- ![](https://i.etsystatic.com/iap/0d14eb/7077642119/iap_640x640.7077642119_dw3hc5oe.jpg?version=0)

5 out of 5 stars

- SIZE:

EXTRA SIZE

- Color:

Black


I love these bags so much I bought more than one! The x large tote is the perfect option for all of your daily necessities plus a water bottle, a book, laptop, etc. The leather is beautiful, it looks and feels high quality — I get compliments on my bags all the time! Highly recommend.

![](https://i.etsystatic.com/iusa/9d6a64/33049309/iusa_75x75.33049309_8o1e.jpg?version=0)

Jul 17, 2025


[Jackie Incorvia](https://www.etsy.com/people/missincorvia2)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/72ac19/7011364588/iap_640x640.7011364588_4cy8pcvo.jpg?version=0)

5 out of 5 stars

- SIZE:

EXTRA SIZE

- Color:

Black


The bag arrived today, and I'm absolutely thrilled. The craftsmanship is superb, and the leather itself is fantastic. I had my name engraved on it, which looks really nice. Shipping was also pretty fast. And the seller contacted me several times. Very nice. I'm extremely satisfied.

See in original language


Translated by Google


Die Tasche ist heute bei mir angekommen und ich bin total begeistert. Super schön die Verarbeitung und das Leder an sich toll. Ich habe mir meinen Namen einstanzen lassen das sieht auch sehr schön aus...Auch der Versand ging recht schnell. Und die Verkäuferin hatte mich mehrfach kontaktiert..Sehr nett..Bin super zufrieden..


Jul 11, 2025


[Sandra Alt](https://www.etsy.com/people/jawha7iqlx49sdch)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/30607f/7201002110/iap_640x640.7201002110_k89uh48q.jpg?version=0)

4 out of 5 stars

- SIZE:

EXTRA SIZE

- Color:

Black


This tote is excellent for work/school. It’s pictured fully packed with a large planner, reporter’s notebook, glasses, wallet, slender toiletry bag, hand sanitizer, other tiny daily objects, a 4.5 cup food container, and a 12in laptop (it also fits my 13in macbook with room to spare). It’s a bit heavy when fully packed, but the straps are pretty comfy.
The leather is beautiful! Soft, lightweight, and very smooth. Also, there are two small internal pockets. As other reviewers mentioned, the pockets are closer to the bottom of the bag, but it works for now! The dye transfers a bit, so be careful. I’d wipe down the areas that rub against your body with one of those dye protector laundry sheets. Lastly, the package arrived in 2 weeks from the date of purchase!! Amazing!! FYI, they include the product value on the package label.

![](https://i.etsystatic.com/iusa/cc79ac/63195391/iusa_75x75.63195391_chpr.jpg?version=0)

Sep 15, 2025


[Camille](https://www.etsy.com/people/nulskdcv)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/894843/7259609105/iap_640x640.7259609105_cy20in2l.jpg?version=0)

5 out of 5 stars

- SIZE:

LARGE SIZE

- Color:

Cognac


10/10 I always want to order again

Sep 19, 2025


[Isabel Amos](https://www.etsy.com/people/m392k7sne5224qnl)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/b57e2d/6948467866/iap_640x640.6948467866_ipbloiti.jpg?version=0)

5 out of 5 stars

- SIZE:

EXTRA SIZE

- Color:

Chocolate


The bag is way better then I expected! I love it!! I highly recommend this bag. I got the extra large in choclate

Jun 17, 2025


[stacymquick](https://www.etsy.com/people/stacymquick)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/f75338/6935804862/iap_640x640.6935804862_2vuh2snq.jpg?version=0)

5 out of 5 stars

- SIZE:

LARGE SIZE

- Color:

Cognac


My wife loves the bag. Great quality !! The bag size on the picture is large.

Jun 12, 2025


[Francois](https://www.etsy.com/people/4z6lvid2lrod1gho)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/c9f72f/6858295335/iap_640x640.6858295335_fyp1v6g3.jpg?version=0)

5 out of 5 stars

- SIZE:

EXTRA SIZE

- Color:

Navy blue


This is my second bag from OTLbags which is XL size Navy Blue with brown handle bag. I still love the simplicity of it. OTL added all the requests I made without additional cost which I love. Amazing product and amazing company.

![](https://i.etsystatic.com/iusa/2d527f/82895349/iusa_75x75.82895349_e129.jpg?version=0)

Apr 22, 2025


[Cheryll](https://www.etsy.com/people/bsvzy4ol3c8s6tfl)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/3d3156/6599079938/iap_640x640.6599079938_tp97fih1.jpg?version=0)

5 out of 5 stars

- SIZE:

MEDIUM SIZE

- Color:

Black


I’m obsessed with this bag. Such a high quality crafted product. I almost wish I went for the bigger size! But I love everything about it. The material, the texture. And the strap length is perfect for that wrist to shoulder swoop to sit comfortably on my shoulder!

![](https://i.etsystatic.com/iusa/abfa79/41780529/iusa_75x75.41780529_dz3d.jpg?version=0)

Jan 26, 2025


[Masha Vainblat](https://www.etsy.com/people/mashavainblat)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/59e10e/6863585068/iap_640x640.6863585068_4fzl2ayl.jpg?version=0)

5 out of 5 stars

- SIZE:

EXTRA SIZE

- Color:

Caramel


I love this bag so much I immediately ordered another in a different color! I got the X large size in caramel, it is a beautiful camel colored leather that looks great with everything. I can fit everything in this bag and while the leather is high quality and beautiful, it is not too heavy. The seller was very friendly and responsive, shipping did not take that long to the US. Highly recommend this shop!

![](https://i.etsystatic.com/iusa/9d6a64/33049309/iusa_75x75.33049309_8o1e.jpg?version=0)

May 15, 2025


[Jackie Incorvia](https://www.etsy.com/people/missincorvia2)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/77e327/6475710800/iap_640x640.6475710800_lvzz21i0.jpg?version=0)

5 out of 5 stars

- SIZE:

EXTRA SIZE

- Color:

Black


Love this bag and great quality leather.

Dec 2, 2024


[sharon](https://www.etsy.com/people/6finoqzo)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/cd443d/6574703129/iap_640x640.6574703129_syelyphs.jpg?version=0)

5 out of 5 stars

- SIZE:

EXTRA SIZE

- Color:

Black


I like the bag, however the directions I gave for the imprint were not fully followed. The imprint is also not deep or noticeable but the bag is beautiful and worth it. Would definitely recommend it !

Update: The team reached out and was very professional. I shared my concerns and they took care of my needs. I appreciate them reaching out to make things right. Once again the bags are amazing, I bought this as a diaper bag for my son and I’m glad I did.

![](https://i.etsystatic.com/iusa/eb79fc/65971483/iusa_75x75.65971483_to1p.jpg?version=0)

Dec 26, 2024


[Veronica Osei](https://www.etsy.com/people/p7lpzbxl)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/96b9c9/6808195186/iap_640x640.6808195186_32owgw5u.jpg?version=0)

5 out of 5 stars

- SIZE:

EXTRA SIZE

- Color:

Black


Absolutely beautiful bag. Quality leather, it fits everything that I need for work. Very comfortable strap. Would definitely recommend. Took a bit of time to arrive - but the seller set my expectations well.

![](https://i.etsystatic.com/iusa/53c46f/9814720/iusa_75x75.9814720.jpg?version=0)

Apr 21, 2025


[Julia E](https://www.etsy.com/people/jerakovic)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/3f69ec/6818359747/iap_640x640.6818359747_r25ja80c.jpg?version=0)

4 out of 5 stars

- SIZE:

LARGE SIZE

- Color:

Green


The bag is beautiful. Took awhile to get here, understandable. Unfortunately the bag has a couple large scratches in the front, which it’s unfortunate.

Apr 5, 2025


[Stephanie](https://www.etsy.com/people/c2o4xel8)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/b153be/6403191684/iap_640x640.6403191684_ki4jo8ao.jpg?version=0)

5 out of 5 stars

- SIZE:

LARGE SIZE

- Color:

Black


Beautiful bag, crafted with care and designed expertly. I love it.

![](https://i.etsystatic.com/iusa/b6c1f6/94120934/iusa_75x75.94120934_isrz.jpg?version=0)

Nov 4, 2024


[Goody Cloyse](https://www.etsy.com/people/young4552)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/9a90ff/6720212306/iap_640x640.6720212306_d7dcj5gh.jpg?version=0)

1 out of 5 stars

- SIZE:

EXTRA SIZE

- Color:

Red


The item did not match the description and was not the colour in the picture shown. On the website I was expecting a red bag but this is more a deep orange and has some marks on it.

Mar 16, 2025


[Lynn](https://www.etsy.com/people/6j9ntyxkedvru7fl)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/2f842f/6308163366/iap_640x640.6308163366_48djcapp.jpg?version=0)

5 out of 5 stars

- SIZE:

EXTRA SIZE

- Color:

Black


PROS: Overall I’m happy with the item. It is a very soft and sturdy leather and it’s the perfect size for all my work things, even my laptop. It also stands up by itself.

Sep 28, 2024


[Cassandra Rivera](https://www.etsy.com/people/cassandranrivera)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/508d35/6810066979/iap_640x640.6810066979_dxcu0pvv.jpg?version=0)

4 out of 5 stars

- SIZE:

MEDIUM SIZE

- Color:

Cappuccino


Stiches of the bag is no the same color as bag, it is dissapointing.:(( it makes the bag look cheaper that it actually is.
Everything elese is super. High quality leather and perfect work.

Apr 2, 2025


[Linda Kaziniece](https://www.etsy.com/people/3wdgip21vh5qkh9y)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/2039d3/6485150643/iap_640x640.6485150643_iizs66ay.jpg?version=0)

5 out of 5 stars

- SIZE:

LARGE SIZE

- Color:

Cognac


Note: the bag is tapered.

The base of the bag is not as wide as the measurements given, although the bag does open that wide. I bought it for my laptop. It fits, but doesn’t go all the way down. I wish I had gotten the extra large. I purchased the large.

Beautiful! Strong sturdy leather. Love the feel of it.

I also really like the simple monogram. Seller added a magnetic clasp as asked.
Would like to purchase another later!

Nov 17, 2024


[Tara Chinnock](https://www.etsy.com/people/7t181geef8ihgfuz)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/b237e5/6285625188/iap_640x640.6285625188_qxb3pty1.jpg?version=0)

4 out of 5 stars

- SIZE:

EXTRA SIZE

- Color:

Cognac


The bag is beautiful, easy to carry, and lightweight.

Sep 19, 2024


[Chiraporn](https://www.etsy.com/people/npdk9p6ivp78tk8k)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/dbd90e/6545458489/iap_640x640.6545458489_sr8fnlql.jpg?version=0)

5 out of 5 stars

- SIZE:

EXTRA SIZE

- Color:

Cappuccino


The bag is amazing quality x appears small but sits a lot! The seller is lovely and it arrived on time and exactly like the photos x the most perfect school or work bag x

Dec 11, 2024


[Mia](https://www.etsy.com/people/q143a7buki11o2v5)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)

Purchased item:

[![Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote](https://i.etsystatic.com/15225213/c/3000/2384/0/525/il/7b1a5f/4161283680/il_170x135.4161283680_f8yl.jpg)\\
\\
Woman shoulder bag, Leather shopping bag, Tote leather bag, Leather tote bag, Extra large tote bag, Shoulder woman bag, Black leather tote\\
\\
Sale Price $63.75\\
$63.75\\
\\
$75.00\\
Original Price $75.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1304733755/woman-shoulder-bag-leather-shopping-bag?ref=ap-listing)