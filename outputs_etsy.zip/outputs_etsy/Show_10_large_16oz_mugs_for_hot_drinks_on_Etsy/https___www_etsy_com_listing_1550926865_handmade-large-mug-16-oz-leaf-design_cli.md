[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1550926865/handmade-large-mug-16-oz-leaf-design?amp;click_sum=c5ea2a4e&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;pro=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=c5ea2a4e&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bpro=1&explicit=1&ref=catnav_breadcrumb-0)
- [Kitchen & Dining](https://www.etsy.com/c/home-and-living/kitchen-and-dining?amp%3Bclick_sum=c5ea2a4e&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bpro=1&explicit=1&ref=catnav_breadcrumb-1)
- [Drink & Barware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware?amp%3Bclick_sum=c5ea2a4e&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bpro=1&explicit=1&ref=catnav_breadcrumb-2)
- [Drinkware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware?amp%3Bclick_sum=c5ea2a4e&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bpro=1&explicit=1&ref=catnav_breadcrumb-3)
- [Mugs](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/mugs?amp%3Bclick_sum=c5ea2a4e&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bpro=1&explicit=1&ref=catnav_breadcrumb-4)

Etsy’s Pick

Etsy’s Picks are hand selected by our style experts to highlight items from shops that have shown quality, reliability and style.

[Discover More](https://www.etsy.com/featured/hub/etsy-picks?ref=listing_etsys_pick_signal)


Add to Favorites


- ![May include: A ceramic mug with a light gray glaze and a light brown rim. The mug has a handle and a design of leaves on the side.](https://i.etsystatic.com/6575430/r/il/5e1e57/5467159730/il_794xN.5467159730_hs0h.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![May include: A light blue ceramic mug with a light green glaze and a leaf design.](https://i.etsystatic.com/6575430/r/il/2aa476/5515266595/il_794xN.5515266595_pni7.jpg)
- ![May include: A ceramic mug with a light brown glaze and a speckled finish. The mug has a rounded body and a large handle. The mug is sitting on a woven coaster.](https://i.etsystatic.com/6575430/r/il/704707/5467156556/il_794xN.5467156556_7wyr.jpg)
- ![May include: A ceramic mug with a gray, blue, and yellow glaze. The mug has a rounded body and a handle.](https://i.etsystatic.com/6575430/r/il/37ffd4/5515262017/il_794xN.5515262017_8uvp.jpg)
- ![May include: A yellow ceramic mug with a handle and a textured design of small circles and swirls.](https://i.etsystatic.com/6575430/r/il/43b290/5515263265/il_794xN.5515263265_5c3k.jpg)
- ![May include: A gray ceramic mug with a light blue glaze and a raised design of swirls and dots. The mug has a rounded body and a handle.](https://i.etsystatic.com/6575430/r/il/a163e9/5515264355/il_794xN.5515264355_p3rv.jpg)
- ![May include: A ceramic mug with a light gray glaze and a light brown rim. The mug has a handle and a design of leaves on the side.](https://i.etsystatic.com/6575430/r/il/ad704f/5515265717/il_794xN.5515265717_kx8x.jpg)
- ![May include: A blue ceramic mug with a white rim and handle.](https://i.etsystatic.com/6575430/r/il/1333e2/5518763181/il_794xN.5518763181_b5m9.jpg)
- ![May include: A blue ceramic mug with a handle. The mug has a light blue glaze with a darker blue glaze on the top and bottom. The mug has a raised design of seashells on the bottom.](https://i.etsystatic.com/6575430/r/il/4fb385/5473080900/il_794xN.5473080900_1peq.jpg)
- ![May include: A ceramic mug with a light yellow glaze and a white rim. The mug has a rounded body and a handle. The mug is sitting on a wooden surface.](https://i.etsystatic.com/6575430/r/il/a419d5/5521192109/il_794xN.5521192109_3n1u.jpg)

- ![May include: A ceramic mug with a light gray glaze and a light brown rim. The mug has a handle and a design of leaves on the side.](https://i.etsystatic.com/6575430/r/il/5e1e57/5467159730/il_75x75.5467159730_hs0h.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/file_w1bq9s.jpg)

- ![May include: A light blue ceramic mug with a light green glaze and a leaf design.](https://i.etsystatic.com/6575430/r/il/2aa476/5515266595/il_75x75.5515266595_pni7.jpg)
- ![May include: A ceramic mug with a light brown glaze and a speckled finish. The mug has a rounded body and a large handle. The mug is sitting on a woven coaster.](https://i.etsystatic.com/6575430/r/il/704707/5467156556/il_75x75.5467156556_7wyr.jpg)
- ![May include: A ceramic mug with a gray, blue, and yellow glaze. The mug has a rounded body and a handle.](https://i.etsystatic.com/6575430/r/il/37ffd4/5515262017/il_75x75.5515262017_8uvp.jpg)
- ![May include: A yellow ceramic mug with a handle and a textured design of small circles and swirls.](https://i.etsystatic.com/6575430/r/il/43b290/5515263265/il_75x75.5515263265_5c3k.jpg)
- ![May include: A gray ceramic mug with a light blue glaze and a raised design of swirls and dots. The mug has a rounded body and a handle.](https://i.etsystatic.com/6575430/r/il/a163e9/5515264355/il_75x75.5515264355_p3rv.jpg)
- ![May include: A ceramic mug with a light gray glaze and a light brown rim. The mug has a handle and a design of leaves on the side.](https://i.etsystatic.com/6575430/r/il/ad704f/5515265717/il_75x75.5515265717_kx8x.jpg)
- ![May include: A blue ceramic mug with a white rim and handle.](https://i.etsystatic.com/6575430/r/il/1333e2/5518763181/il_75x75.5518763181_b5m9.jpg)
- ![May include: A blue ceramic mug with a handle. The mug has a light blue glaze with a darker blue glaze on the top and bottom. The mug has a raised design of seashells on the bottom.](https://i.etsystatic.com/6575430/r/il/4fb385/5473080900/il_75x75.5473080900_1peq.jpg)
- ![May include: A ceramic mug with a light yellow glaze and a white rim. The mug has a rounded body and a handle. The mug is sitting on a wooden surface.](https://i.etsystatic.com/6575430/r/il/a419d5/5521192109/il_75x75.5521192109_3n1u.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1550926865%2Fhandmade-large-mug-16-oz-leaf-design%23report-overlay-trigger)

11 views in the last 24 hours

NowPrice:$45.05


Original Price:
$53.00


Loading


15% off


•

Sale ends in 3 days


# Handmade Large Mug: 16 oz, Leaf Design, Julia E. Dean

[juliaedean](https://www.etsy.com/shop/juliaedean?ref=shop-header-name&listing_id=1550926865&from_page=listing)

[5 out of 5 stars](https://www.etsy.com/listing/1550926865/handmade-large-mug-16-oz-leaf-design?amp;click_sum=c5ea2a4e&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;pro=1#reviews)

Arrives soon! Get it by

Nov 18-21


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

Pattern


Select an option

Gray Woodland leaf

Gray plain

Gray Shells

Honey woodland \[Sold out\]

Honey Plain

Honey shells

Blue Woodland leaf

Blue plain

Blue shells

Please select an option


From **$15/month**, or 4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Buy together, get 15% off

![Handmade Large Mug: 16 oz, Leaf Design, Julia E. Dean](https://i.etsystatic.com/6575430/r/il/5e1e57/5467159730/il_340x270.5467159730_hs0h.jpg)
This listing

### Handmade Large Mug: 16 oz, Leaf Design, Julia E. Dean

Sale Price $45.05
$45.05

$53.00
Original Price $53.00


15% off "buy together" offer


Add to Favorites


[![Handmade Ceramic Soup Bowl: Shell Patterned Serving Bowl](https://i.etsystatic.com/6575430/r/il/1bb9f7/5467496886/il_340x270.5467496886_n580.jpg)\\
\\
**Handmade Ceramic Soup Bowl: Shell Patterned Serving Bowl**\\
\\
Sale Price $25.50\\
$25.50\\
\\
$30.00\\
Original Price $30.00\\
\\
\\
15% off "buy together" offer](https://www.etsy.com/listing/1536738044/handmade-ceramic-soup-bowl-shell?click_key=9baf23137c0608ab8b946046e0769584a3af6550%3A1536738044&click_sum=70ebb67b&ref=lp_mix_and_match_bundle-2&pro=1&mnm=1 "Handmade Ceramic Soup Bowl: Shell Patterned Serving Bowl")


Add to Favorites


![Handmade Large Mug: 16 oz, Leaf Design, Julia E. Dean](https://i.etsystatic.com/6575430/r/il/5e1e57/5467159730/il_340x270.5467159730_hs0h.jpg)
This listing

### Handmade Large Mug: 16 oz, Leaf Design, Julia E. Dean

Sale Price $45.05
$45.05

$53.00
Original Price $53.00


15% off "buy together" offer


Add to Favorites


[![Handmade Ceramic Soup Bowl: Shell Patterned Serving Bowl](https://i.etsystatic.com/6575430/r/il/1bb9f7/5467496886/il_340x270.5467496886_n580.jpg)\\
\\
**Handmade Ceramic Soup Bowl: Shell Patterned Serving Bowl**\\
\\
Sale Price $25.50\\
$25.50\\
\\
$30.00\\
Original Price $30.00\\
\\
\\
15% off "buy together" offer](https://www.etsy.com/listing/1536738044/handmade-ceramic-soup-bowl-shell?click_key=9baf23137c0608ab8b946046e0769584a3af6550%3A1536738044&click_sum=70ebb67b&ref=lp_mix_and_match_bundle-2&pro=1&mnm=1 "Handmade Ceramic Soup Bowl: Shell Patterned Serving Bowl")


Add to Favorites


![Handmade Large Mug: 16 oz, Leaf Design, Julia E. Dean](https://i.etsystatic.com/6575430/r/il/5e1e57/5467159730/il_340x270.5467159730_hs0h.jpg)
This listing

### Handmade Large Mug: 16 oz, Leaf Design, Julia E. Dean

Sale Price $45.05
$45.05

$53.00
Original Price $53.00


15% off "buy together" offer


Add to Favorites


[![Handmade Ceramic Soup Bowl: Shell Patterned Serving Bowl](https://i.etsystatic.com/6575430/r/il/1bb9f7/5467496886/il_340x270.5467496886_n580.jpg)\\
\\
**Handmade Ceramic Soup Bowl: Shell Patterned Serving Bowl**\\
\\
Sale Price $25.50\\
$25.50\\
\\
$30.00\\
Original Price $30.00\\
\\
\\
15% off "buy together" offer](https://www.etsy.com/listing/1536738044/handmade-ceramic-soup-bowl-shell?click_key=d68529cd86f9f33e640f64f27a1cbc087604aa8b%3A1536738044&click_sum=ec81f65c&ref=lp_mix_and_match_bundle-2&pro=1&mnm=1 "Handmade Ceramic Soup Bowl: Shell Patterned Serving Bowl")


Add to Favorites


Original value: $83.00


New total: $70.55


Add both to cart



Loading


## Item details

### Highlights

Made by [juliaedean](https://www.etsy.com/shop/juliaedean)

- Materials: Ceramic


The perfect gift for a coffee lover, it comes in your choice of:

Gray, blue or honey color

16 oz (LEAF, SHELLS, OR PLAIN) - 5.5"H x 3.5" diameter

NOTE: this mug style is slipcasted from an original hand-thrown mug. We use the same technique of rolling each leaf or pressing each shell into the surface when the mug dries to the right texture. Leaves and shells may vary from those used in photograph, ensuring your order is truly one of a kind!

CARE: Oven, microwave and dishwasher safe.

SHIPPING:

\*Orders generally ship on Tuesdays and Fridays via USPS Priority Mail

\*This item arrives well packaged in a beautiful Julia e. Dean gift box - see gift box photo.

PROCESS:

My family and I collect individually beautiful leaves of all species in the fall season and preserve them for use throughout the year.

Shells, we gather on family vacations to the shore.

The objects are pressed into the damp surface of the hand thrown forms at the "leather hard" stage of drying, which is usually the day after they are made.

Once dry and fired once, all pieces are brushed with an iron oxide wash, which is then wiped off to reveal the textured imprint in the surface.

Glaze is applied and the piece fires for a second time to a higher temperature.

See a video about this making process in my story and follow me #juliaedean on Instagram.

Thanks for supporting my work on Etsy since 2011!


## Shipping and return policies

Loading


- Order today to get by

**Nov 18-21**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 14 days


- Free shipping


- Ships from: **Ithaca, NY**


Deliver to United States

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (39)

4.9/5

item average

4.8Item quality

5.0Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Beautiful

Love it

Fast shipping

Great quality

Very pretty

Perfect size

Would recommend


Filter by category


Quality (23)


Appearance (16)


Comfort (6)


Shipping & Packaging (6)


Ease of use (7)


Sizing & Fit (6)


Description accuracy (4)


Seller service (2)


Value (2)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/f9c40d/80631796/iusa_75x75.80631796_r4on.jpg?version=0)

[Margaret Crespo](https://www.etsy.com/people/thsyqr1o?ref=l_review)
Nov 6, 2025


It is a beautiful mug and a perfect addition to my mug collection.



![Margaret Crespo added a photo of their purchase](https://i.etsystatic.com/iap/5eb4d2/7413486975/iap_300x300.7413486975_reea56af.jpg?version=0)

![](https://i.etsystatic.com/iusa/f9c40d/80631796/iusa_75x75.80631796_r4on.jpg?version=0)

[Margaret Crespo](https://www.etsy.com/people/thsyqr1o?ref=l_review)
Nov 6, 2025


4 out of 5 stars
4

This item

[ryder guthrie](https://www.etsy.com/people/qorij8fro3tye3t1?ref=l_review)
Jul 26, 2025


Wish it was a little heavier.



[ryder guthrie](https://www.etsy.com/people/qorij8fro3tye3t1?ref=l_review)
Jul 26, 2025


5 out of 5 stars
5

This item

[chefforyou](https://www.etsy.com/people/krisetze?ref=l_review)
Jul 12, 2025


The mugs are beautiful! Love them!



[chefforyou](https://www.etsy.com/people/krisetze?ref=l_review)
Jul 12, 2025


5 out of 5 stars
5

This item

[Pamela Sullivan](https://www.etsy.com/people/pnnpczkej29cjb3s?ref=l_review)
Apr 13, 2025


My mom loves them 💕



[Pamela Sullivan](https://www.etsy.com/people/pnnpczkej29cjb3s?ref=l_review)
Apr 13, 2025


View all reviews for this item

### Photos from reviews

![Kim added a photo of their purchase](https://i.etsystatic.com/iap/687ba9/6741945446/iap_300x300.6741945446_9obge3th.jpg?version=0)

![Margaret added a photo of their purchase](https://i.etsystatic.com/iap/5eb4d2/7413486975/iap_300x300.7413486975_reea56af.jpg?version=0)

[![juliaedean](https://i.etsystatic.com/iusa/12bc13/28713737/iusa_75x75.28713737_l383.jpg?version=0)](https://www.etsy.com/shop/juliaedean?ref=shop_profile&listing_id=1550926865)

[juliaedean](https://www.etsy.com/shop/juliaedean?ref=shop_profile&listing_id=1550926865)

[Owned by Julia E. Dean, Inc.](https://www.etsy.com/shop/juliaedean?ref=shop_profile&listing_id=1550926865) \|

Ithaca, New York

4.9
(5.3k)


18.3k sales

14 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=14591098&referring_id=1550926865&referring_type=listing&recipient_id=14591098&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoxNDU5MTA5ODoxNzYyODA4MjQ2OmIwMzE4NTU3MWVkNzc5MmQ2MmYwZDJhMDg4NDllYzY3&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1550926865%2Fhandmade-large-mug-16-oz-leaf-design%3Famp%253Bclick_sum%3Dc5ea2a4e%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bpro%3D1)

Smooth shippingHas a history of shipping on time with tracking.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/juliaedean?ref=lp_mys_mfts)

- [![Handmade Pottery Coffee Mug: Woodland Leaf Design, Julia E. Dean](https://i.etsystatic.com/6575430/r/il/348686/1104378683/il_340x270.1104378683_5qea.jpg)\\
\\
**Handmade Pottery Coffee Mug: Woodland Leaf Design, Julia E. Dean**\\
\\
Sale Price $44.20\\
$44.20\\
\\
$52.00\\
Original Price $52.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/175789619/handmade-pottery-coffee-mug-woodland?click_key=3f12e4081941c16025c0d2a567da2be2%3ALT8fdee2195b67661a4e040d4bde949aac046a3666&click_sum=a86ded3c&ls=r&ref=related-1&pro=1&content_source=3f12e4081941c16025c0d2a567da2be2%253ALT8fdee2195b67661a4e040d4bde949aac046a3666 "Handmade Pottery Coffee Mug: Woodland Leaf Design, Julia E. Dean")




Add to Favorites


- [![Discounted, slightly flawed Pottery](https://i.etsystatic.com/6575430/r/il/3148a8/6180031947/il_340x270.6180031947_9w1e.jpg)\\
\\
**Discounted, slightly flawed Pottery**\\
\\
Sale Price $8.50\\
$8.50\\
\\
$10.00\\
Original Price $10.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1736004834/discounted-slightly-flawed-pottery?click_key=3f12e4081941c16025c0d2a567da2be2%3ALTe4cb722d763c9efb9c0804619bfc518376238b99&click_sum=7e94d749&ls=r&ref=related-2&pro=1&content_source=3f12e4081941c16025c0d2a567da2be2%253ALTe4cb722d763c9efb9c0804619bfc518376238b99 "Discounted, slightly flawed Pottery")




Add to Favorites


- [![Personalized Pottery Coffee Mug: Handmade Leaf Design, Gift Box](https://i.etsystatic.com/6575430/r/il/f47604/2199469485/il_340x270.2199469485_m4bf.jpg)\\
\\
**Personalized Pottery Coffee Mug: Handmade Leaf Design, Gift Box**\\
\\
Sale Price $49.30\\
$49.30\\
\\
$58.00\\
Original Price $58.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/95131105/personalized-pottery-coffee-mug-handmade?click_key=3f12e4081941c16025c0d2a567da2be2%3ALT7b7402c47fc4701137c1f5cfb8c8525e9a53b0d4&click_sum=adcbf6e1&ls=r&ref=related-3&pro=1&content_source=3f12e4081941c16025c0d2a567da2be2%253ALT7b7402c47fc4701137c1f5cfb8c8525e9a53b0d4 "Personalized Pottery Coffee Mug: Handmade Leaf Design, Gift Box")




Add to Favorites


- [![Chowder Bowl - Large Soup bowl - Large Cereal bowl](https://i.etsystatic.com/6575430/r/il/7d36ff/1058520782/il_340x270.1058520782_rcre.jpg)\\
\\
**Chowder Bowl - Large Soup bowl - Large Cereal bowl**\\
\\
$50.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/484213555/chowder-bowl-large-soup-bowl-large?click_key=9b18526be54979ab0942d1bf8d440d96e327b488%3A484213555&click_sum=7a437aae&ref=related-4 "Chowder Bowl - Large Soup bowl - Large Cereal bowl")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 4, 2025


[451 favorites](https://www.etsy.com/listing/1550926865/handmade-large-mug-16-oz-leaf-design/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=c5ea2a4e&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bpro=1&explicit=1&ref=breadcrumb_listing) [Kitchen & Dining](https://www.etsy.com/c/home-and-living/kitchen-and-dining?amp%3Bclick_sum=c5ea2a4e&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bpro=1&explicit=1&ref=breadcrumb_listing) [Drink & Barware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware?amp%3Bclick_sum=c5ea2a4e&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bpro=1&explicit=1&ref=breadcrumb_listing) [Drinkware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware?amp%3Bclick_sum=c5ea2a4e&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bpro=1&explicit=1&ref=breadcrumb_listing) [Mugs](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/mugs?amp%3Bclick_sum=c5ea2a4e&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bpro=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Kitchen & Dining

[Being My Sibling Is Really The Only Gift You Need Ceramic Coffee Mug – Beer Stein – Water Bottle - Kitchen & Dining](https://www.etsy.com/listing/1863053650/being-my-sibling-is-really-the-only-gift) [Fish Sauce Boat for Sale](https://www.etsy.com/market/fish_sauce_boat) [Royal Crown Derby Tureen for Sale](https://www.etsy.com/market/royal_crown_derby_tureen) [Sweet Child Mug - Kitchen & Dining](https://www.etsy.com/listing/1844830110/sweet-child-mug) [Cow Hide - Kitchen & Dining](https://www.etsy.com/listing/1432112433/cow-hide-western-aztec-tumbler-cow) [Sage Pasta Bowl for Sale](https://www.etsy.com/market/sage_pasta_bowl) [3D Decent DE1 Skale 2 Drip Tray Adapter](https://www.etsy.com/listing/1715407507/3d-decent-de1-skale-2-drip-tray-adapter)

Storage & Organization

[Double Opening Box - US](https://www.etsy.com/market/double_opening_box)

Paper

[Balloon Animal Valentine Day Cards](https://www.etsy.com/listing/1668155773/balloon-dog-valentine-cards-balloon)

Shopping

[North Pole Elf Spa Sign - US](https://www.etsy.com/market/north_pole_elf_spa_sign) [Dog Paw Vinyl Rolls - US](https://www.etsy.com/market/dog_paw_vinyl_rolls)

Car Parts & Accessories

[Buy Hondajet Online](https://www.etsy.com/market/hondajet)

Collectibles

[Jane Hutchinson for Sale](https://www.etsy.com/market/jane_hutchinson)

Necklaces

[Paired Necklace - US](https://www.etsy.com/market/paired_necklace)

Home Decor

[Stain Glass Cross Ornament. - Home Decor](https://www.etsy.com/listing/1331698176/stain-glass-cross-ornament)

Earrings

[Buy 5mm Stud Men Earring Online](https://www.etsy.com/market/5mm_stud_men_earring)

Keychains & Lanyards

[Vintage Disney’s Pleasure Island Avigators Supply keychain](https://www.etsy.com/listing/1563677657/vintage-disneys-pleasure-island)

Gender Neutral Adult Clothing

[Shop Stars And Moon Tops](https://www.etsy.com/market/stars_and_moon_tops)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1550926865%2Fhandmade-large-mug-16-oz-leaf-design%3Famp%253Bclick_sum%3Dc5ea2a4e%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bpro%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgwODI0NjowYjE5YWJiNDYxNDQ0Yzg4YzNmZDI4ZTY3MmEwY2JkYw==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1550926865%2Fhandmade-large-mug-16-oz-leaf-design%3Famp%253Bclick_sum%3Dc5ea2a4e%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bpro%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1550926865/handmade-large-mug-16-oz-leaf-design?amp;click_sum=c5ea2a4e&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;pro=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1550926865%2Fhandmade-large-mug-16-oz-leaf-design%3Famp%253Bclick_sum%3Dc5ea2a4e%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bpro%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for juliaedean

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: not accepted

Please contact the seller if you have any problems with your order.

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## Seller details

### Business registration number

### Location

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=14591098&referring_id=6575430&referring_type=shop&recipient_id=14591098&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading


- Item in the photo is in **Pattern: Blue Woodland leaf**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Pattern: Honey woodland**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Pattern: Gray Woodland leaf**




Select this option








Option selected!













This option is sold out.



Click to zoom

- ![May include: A ceramic mug with a light gray glaze and a light brown rim. The mug has a handle and a design of leaves on the side.](https://i.etsystatic.com/6575430/r/il/5e1e57/5467159730/il_300x300.5467159730_hs0h.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/file_w1bq9s.jpg)

- ![May include: A light blue ceramic mug with a light green glaze and a leaf design.](https://i.etsystatic.com/6575430/r/il/2aa476/5515266595/il_300x300.5515266595_pni7.jpg)
- ![May include: A ceramic mug with a light brown glaze and a speckled finish. The mug has a rounded body and a large handle. The mug is sitting on a woven coaster.](https://i.etsystatic.com/6575430/r/il/704707/5467156556/il_300x300.5467156556_7wyr.jpg)
- ![May include: A ceramic mug with a gray, blue, and yellow glaze. The mug has a rounded body and a handle.](https://i.etsystatic.com/6575430/r/il/37ffd4/5515262017/il_300x300.5515262017_8uvp.jpg)
- ![May include: A yellow ceramic mug with a handle and a textured design of small circles and swirls.](https://i.etsystatic.com/6575430/r/il/43b290/5515263265/il_300x300.5515263265_5c3k.jpg)
- ![May include: A gray ceramic mug with a light blue glaze and a raised design of swirls and dots. The mug has a rounded body and a handle.](https://i.etsystatic.com/6575430/r/il/a163e9/5515264355/il_300x300.5515264355_p3rv.jpg)
- ![May include: A ceramic mug with a light gray glaze and a light brown rim. The mug has a handle and a design of leaves on the side.](https://i.etsystatic.com/6575430/r/il/ad704f/5515265717/il_300x300.5515265717_kx8x.jpg)
- ![May include: A blue ceramic mug with a white rim and handle.](https://i.etsystatic.com/6575430/r/il/1333e2/5518763181/il_300x300.5518763181_b5m9.jpg)
- ![May include: A blue ceramic mug with a handle. The mug has a light blue glaze with a darker blue glaze on the top and bottom. The mug has a raised design of seashells on the bottom.](https://i.etsystatic.com/6575430/r/il/4fb385/5473080900/il_300x300.5473080900_1peq.jpg)
- ![May include: A ceramic mug with a light yellow glaze and a white rim. The mug has a rounded body and a handle. The mug is sitting on a wooden surface.](https://i.etsystatic.com/6575430/r/il/a419d5/5521192109/il_300x300.5521192109_3n1u.jpg)

- ![](https://i.etsystatic.com/iap/687ba9/6741945446/iap_640x640.6741945446_9obge3th.jpg?version=0)

5 out of 5 stars

- Pattern:

Blue plain


Beautiful mug! Definitely my favorite. Very lightweight, which is the distinction of a well-thrown pottery piece. I will likely order forgot in the future.

Mar 24, 2025


[Kim Webber](https://www.etsy.com/people/webbersnowlover)

Purchased item:

[![Handmade Large Mug: 16 oz, Leaf Design, Julia E. Dean](https://i.etsystatic.com/6575430/r/il/5e1e57/5467159730/il_170x135.5467159730_hs0h.jpg)\\
\\
Handmade Large Mug: 16 oz, Leaf Design, Julia E. Dean\\
\\
Sale Price $45.05\\
$45.05\\
\\
$53.00\\
Original Price $53.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1550926865/handmade-large-mug-16-oz-leaf-design?ref=ap-listing)

Purchased item:

[![Handmade Large Mug: 16 oz, Leaf Design, Julia E. Dean](https://i.etsystatic.com/6575430/r/il/5e1e57/5467159730/il_170x135.5467159730_hs0h.jpg)\\
\\
Handmade Large Mug: 16 oz, Leaf Design, Julia E. Dean\\
\\
Sale Price $45.05\\
$45.05\\
\\
$53.00\\
Original Price $53.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1550926865/handmade-large-mug-16-oz-leaf-design?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/5eb4d2/7413486975/iap_640x640.7413486975_reea56af.jpg?version=0)

5 out of 5 stars

- Pattern:

Gray Woodland leaf


It is a beautiful mug and a perfect addition to my mug collection.

![](https://i.etsystatic.com/iusa/f9c40d/80631796/iusa_75x75.80631796_r4on.jpg?version=0)

Nov 6, 2025


[Margaret Crespo](https://www.etsy.com/people/thsyqr1o)

Purchased item:

[![Handmade Large Mug: 16 oz, Leaf Design, Julia E. Dean](https://i.etsystatic.com/6575430/r/il/5e1e57/5467159730/il_170x135.5467159730_hs0h.jpg)\\
\\
Handmade Large Mug: 16 oz, Leaf Design, Julia E. Dean\\
\\
Sale Price $45.05\\
$45.05\\
\\
$53.00\\
Original Price $53.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1550926865/handmade-large-mug-16-oz-leaf-design?ref=ap-listing)

Purchased item:

[![Handmade Large Mug: 16 oz, Leaf Design, Julia E. Dean](https://i.etsystatic.com/6575430/r/il/5e1e57/5467159730/il_170x135.5467159730_hs0h.jpg)\\
\\
Handmade Large Mug: 16 oz, Leaf Design, Julia E. Dean\\
\\
Sale Price $45.05\\
$45.05\\
\\
$53.00\\
Original Price $53.00\\
\\
\\
(15% off)](https://www.etsy.com/listing/1550926865/handmade-large-mug-16-oz-leaf-design?ref=ap-listing)