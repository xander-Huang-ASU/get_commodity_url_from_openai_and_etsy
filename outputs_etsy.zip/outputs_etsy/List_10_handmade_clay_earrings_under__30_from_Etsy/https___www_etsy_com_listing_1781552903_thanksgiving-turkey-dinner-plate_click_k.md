[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?amp;click_sum=fbeaef12&amp;ls=a&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=List+10+handmade+clay+earrings+under+%2430+from+Etsy&amp;ref=search_grid-707023-1-2&amp;sr_prefetch=1&amp;pf_from=search&amp;pop=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Jewelry](https://www.etsy.com/c/jewelry?amp%3Bclick_sum=fbeaef12&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=List+10+handmade+clay+earrings+under+%2430+from+Etsy&%3Bref=search_grid-707023-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpop=1&explicit=1&ref=catnav_breadcrumb-0)
- [Earrings](https://www.etsy.com/c/jewelry/earrings?amp%3Bclick_sum=fbeaef12&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=List+10+handmade+clay+earrings+under+%2430+from+Etsy&%3Bref=search_grid-707023-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpop=1&explicit=1&ref=catnav_breadcrumb-1)
- [Dangle & Drop Earrings](https://www.etsy.com/c/jewelry/earrings/dangle-earrings?amp%3Bclick_sum=fbeaef12&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=List+10+handmade+clay+earrings+under+%2430+from+Etsy&%3Bref=search_grid-707023-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpop=1&explicit=1&ref=catnav_breadcrumb-2)

Bestseller

This item has had a high sales volume over the past 6 months.



Add to Favorites


- ![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings image 1](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_794xN.7399031169_mayf.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings image 2](https://i.etsystatic.com/44745067/r/il/3a65bb/7399031167/il_794xN.7399031167_ns02.jpg)
- ![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings image 3](https://i.etsystatic.com/44745067/r/il/854ace/7399031165/il_794xN.7399031165_ch0g.jpg)
- ![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings image 4](https://i.etsystatic.com/44745067/r/il/21796d/7351101036/il_794xN.7351101036_clgn.jpg)
- ![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings image 5](https://i.etsystatic.com/44745067/r/il/fc0048/7399031161/il_794xN.7399031161_g0hr.jpg)
- ![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings image 6](https://i.etsystatic.com/44745067/r/il/32d6a6/7399031163/il_794xN.7399031163_6w2n.jpg)

- ![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings image 1](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_75x75.7399031169_mayf.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/IMG_7776_1_ijqhsh.jpg)

- ![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings image 2](https://i.etsystatic.com/44745067/r/il/3a65bb/7399031167/il_75x75.7399031167_ns02.jpg)
- ![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings image 3](https://i.etsystatic.com/44745067/r/il/854ace/7399031165/il_75x75.7399031165_ch0g.jpg)
- ![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings image 4](https://i.etsystatic.com/44745067/r/il/21796d/7351101036/il_75x75.7351101036_clgn.jpg)
- ![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings image 5](https://i.etsystatic.com/44745067/r/il/fc0048/7399031161/il_75x75.7399031161_g0hr.jpg)
- ![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings image 6](https://i.etsystatic.com/44745067/r/il/32d6a6/7399031163/il_75x75.7399031163_6w2n.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1781552903%2Fthanksgiving-turkey-dinner-plate%23report-overlay-trigger)

20+ views in the last 24 hours

Price:$19.50


Loading


# Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings

Made by [ArtyCraftsyShop](https://www.etsy.com/shop/ArtyCraftsyShop)

[5 out of 5 stars](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?amp;click_sum=fbeaef12&amp;ls=a&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=List+10+handmade+clay+earrings+under+%2430+from+Etsy&amp;ref=search_grid-707023-1-2&amp;sr_prefetch=1&amp;pf_from=search&amp;pop=1#reviews)

Arrives soon! Get it by

Nov 13-17


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns accepted

Quantity



12345678910111213141516171819202122

You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Made by [ArtyCraftsyShop](https://www.etsy.com/shop/ArtyCraftsyShop)

- Materials: 925 silver plated copper, nickel free and Hypo allergenic, Air Dry Clay

- Drop length: 2 Inches


Thanksgiving Dinner Plate Earrings 🍽️🦃

Celebrate Thanksgiving in the most adorable way with these handmade miniature dinner plate earrings! Each plate features all your holiday favorites — turkey with gravy, mashed potatoes, stuffing, green beans, sweet carrots, and cranberry sauce — beautifully crafted from polymer clay with amazing detail.

Perfect for adding a festive touch to your outfit or as a fun conversation starter at your Thanksgiving gathering! Lightweight, hypoallergenic hooks, and made with love.

✨ Great as a gift for food lovers, Thanksgiving hosts, or anyone who loves cute handmade jewelry!

Note: Each pair is handmade, so expect unique variations in design and color that add to their one-of-a-kind appeal.

The earring hooks are made of 925 silver plated copper, nickel free and Hypo allergenic.


## Shipping and return policies

Loading


- Order today to get by

**Nov 13-17**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 14 days


- Ships from: **Sherman, TX**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

## Meet your sellers

![Ornnatcha](https://i.etsystatic.com/44745067/r/isla/7ea665/81381875/isla_75x75.81381875_aqsycw3t.jpg)

Ornnatcha

Owner of [ArtyCraftsyShop](https://www.etsy.com/shop/ArtyCraftsyShop?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo4MDAyODI1MDY6MTc2MjgxNzgxMTpiOWUwODU0MTdhNGY5N2Y3ZmQ2MjUzNjAyY2M3ZTcxMw%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1781552903%2Fthanksgiving-turkey-dinner-plate%3Famp%253Bclick_sum%3Dfbeaef12%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DList%2B10%2Bhandmade%2Bclay%2Bearrings%2Bunder%2B%252430%2Bfrom%2BEtsy%26amp%253Bref%3Dsearch_grid-707023-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpop%3D1)

[Message Ornnatcha](https://www.etsy.com/messages/new?with_id=800282506&referring_id=1781552903&referring_type=listing&recipient_id=800282506&from_action=contact-seller)

This seller usually responds **within a few hours.**

## Reviews for this item (114)

5.0/5

item average

5.0Item quality

5.0Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Cute

Adorable

Would recommend

Love it

As described

Fast shipping


Filter by category


Appearance (1)


Description accuracy (1)


Shipping & Packaging (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Aude Mann](https://www.etsy.com/people/mann331?ref=l_review)
Nov 9, 2025


Cannot wait to wear them



[Aude Mann](https://www.etsy.com/people/mann331?ref=l_review)
Nov 9, 2025


5 out of 5 stars
5

This item

[millievarnadoe](https://www.etsy.com/people/millievarnadoe?ref=l_review)
Nov 9, 2025


Adorable pair of earrings! Highly recommend!



[millievarnadoe](https://www.etsy.com/people/millievarnadoe?ref=l_review)
Nov 9, 2025


5 out of 5 stars
5

This item

[Sign in with Apple user](https://www.etsy.com/people/8xoc9a9blqun6u1b?ref=l_review)
Nov 8, 2025


Very detailed and looks real! Love these earrings



[Sign in with Apple user](https://www.etsy.com/people/8xoc9a9blqun6u1b?ref=l_review)
Nov 8, 2025


5 out of 5 stars
5

This item

[Lauren](https://www.etsy.com/people/wenyoefz?ref=l_review)
Nov 1, 2025


Soooo cute! Really looking forward to wearing around the hospital



[Lauren](https://www.etsy.com/people/wenyoefz?ref=l_review)
Nov 1, 2025


View all reviews for this item

### Photos from reviews

![Jodie added a photo of their purchase](https://i.etsystatic.com/iap/30151f/6430832061/iap_300x300.6430832061_ovamort3.jpg?version=0)

![Melly added a photo of their purchase](https://i.etsystatic.com/iap/d8d385/6424209782/iap_300x300.6424209782_qs08o6kn.jpg?version=0)

![Jessica added a photo of their purchase](https://i.etsystatic.com/iap/ab9e82/6501040217/iap_300x300.6501040217_ihjalt46.jpg?version=0)

![Lauren added a photo of their purchase](https://i.etsystatic.com/iap/ca2855/6509095107/iap_300x300.6509095107_grm33pn3.jpg?version=0)

![Jordyn added a photo of their purchase](https://i.etsystatic.com/iap/a9f07c/6462365711/iap_300x300.6462365711_apb22b7z.jpg?version=0)

![Timmura added a photo of their purchase](https://i.etsystatic.com/iap/125026/6432864004/iap_300x300.6432864004_pkjakmkv.jpg?version=0)

![Emily added a photo of their purchase](https://i.etsystatic.com/iap/e9fa2e/6331009598/iap_300x300.6331009598_5zloqwzk.jpg?version=0)

![Karen added a photo of their purchase](https://i.etsystatic.com/iap/7b3adc/6391384294/iap_300x300.6391384294_t52xtqow.jpg?version=0)

![Ashley added a photo of their purchase](https://i.etsystatic.com/iap/352619/6284389724/iap_300x300.6284389724_ici1crcd.jpg?version=0)

![Anna added a photo of their purchase](https://i.etsystatic.com/iap/5d5b21/6492065255/iap_300x300.6492065255_5wbsfu94.jpg?version=0)

![Brenda added a photo of their purchase](https://i.etsystatic.com/iap/8fab8b/6322058984/iap_300x300.6322058984_69n8nubn.jpg?version=0)

![Erinne added a photo of their purchase](https://i.etsystatic.com/iap/ae5c8e/6432237858/iap_300x300.6432237858_p25ud8zd.jpg?version=0)

![Elizabeth added a photo of their purchase](https://i.etsystatic.com/iap/6d37f1/6325485564/iap_300x300.6325485564_b1f6dw86.jpg?version=0)

![Kristina added a photo of their purchase](https://i.etsystatic.com/iap/d006a6/6424535113/iap_300x300.6424535113_oupss4m3.jpg?version=0)

![Kristina added a photo of their purchase](https://i.etsystatic.com/iap/0822ce/6426562115/iap_300x300.6426562115_3x0z5lv0.jpg?version=0)

![Veronica added a photo of their purchase](https://i.etsystatic.com/iap/ce0d10/6468578124/iap_300x300.6468578124_5d5zheds.jpg?version=0)

![angelluyster added a photo of their purchase](https://i.etsystatic.com/iap/091cea/6515860453/iap_300x300.6515860453_7myfdram.jpg?version=0)

![Katherine added a photo of their purchase](https://i.etsystatic.com/iap/212e9c/6266707754/iap_300x300.6266707754_qsrojz99.jpg?version=0)

[![ArtyCraftsyShop](https://i.etsystatic.com/iusa/01ca40/115036747/iusa_75x75.115036747_2ssf.jpg?version=0)](https://www.etsy.com/shop/ArtyCraftsyShop?ref=shop_profile&listing_id=1781552903)

[ArtyCraftsyShop](https://www.etsy.com/shop/ArtyCraftsyShop?ref=shop_profile&listing_id=1781552903)

[Owned by Ornnatcha](https://www.etsy.com/shop/ArtyCraftsyShop?ref=shop_profile&listing_id=1781552903) \|

Sherman, Texas

5.0
(142)


455 sales

2 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=800282506&referring_id=1781552903&referring_type=listing&recipient_id=800282506&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo4MDAyODI1MDY6MTc2MjgxNzgxMTpiOWUwODU0MTdhNGY5N2Y3ZmQ2MjUzNjAyY2M3ZTcxMw%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1781552903%2Fthanksgiving-turkey-dinner-plate%3Famp%253Bclick_sum%3Dfbeaef12%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DList%2B10%2Bhandmade%2Bclay%2Bearrings%2Bunder%2B%252430%2Bfrom%2BEtsy%26amp%253Bref%3Dsearch_grid-707023-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpop%3D1)

This seller usually responds **within a few hours.**

## More from this shop

[Visit shop](https://www.etsy.com/shop/ArtyCraftsyShop?ref=lp_mys_mfts)

- [![Breakfast Skillet Dangle Earrings ,Yummy and Handmade Food Earrings](https://i.etsystatic.com/44745067/r/il/704366/5277726180/il_340x270.5277726180_ml4y.jpg)\\
\\
**Breakfast Skillet Dangle Earrings ,Yummy and Handmade Food Earrings**\\
\\
$12.50\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1499727142/breakfast-skillet-dangle-earrings-yummy?click_key=169526b187eed4bd058b9f412467f263%3ALT3f7e5c086c6588b81b6a6fbd3485f9cb8ef08254&click_sum=078bbfad&ls=r&ref=related-1&content_source=169526b187eed4bd058b9f412467f263%253ALT3f7e5c086c6588b81b6a6fbd3485f9cb8ef08254 "Breakfast Skillet Dangle Earrings ,Yummy and Handmade Food Earrings")




Add to Favorites


- [![Donut Dangle Earrings ,Yummy and Handmade Food Earrings](https://i.etsystatic.com/44745067/r/il/e2921b/5097046245/il_340x270.5097046245_c7m9.jpg)\\
\\
**Donut Dangle Earrings ,Yummy and Handmade Food Earrings**\\
\\
$12.50\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1514313987/donut-dangle-earrings-yummy-and-handmade?click_key=169526b187eed4bd058b9f412467f263%3ALTa64cbb9977fb59da5ea5fd1aa155ccc4d80705ba&click_sum=db97e057&ls=r&ref=related-2&content_source=169526b187eed4bd058b9f412467f263%253ALTa64cbb9977fb59da5ea5fd1aa155ccc4d80705ba "Donut Dangle Earrings ,Yummy and Handmade Food Earrings")




Add to Favorites


- [![Crochet Earrings, Boho Earrings, Handmade Earrings, Lightweight Jewelry, Knitting jewelry, Microcrochet, Crochet Jewelry, Handmade Crochet](https://i.etsystatic.com/44745067/r/il/b0daf5/5689501036/il_340x270.5689501036_dpqo.jpg)\\
\\
**Crochet Earrings, Boho Earrings, Handmade Earrings, Lightweight Jewelry, Knitting jewelry, Microcrochet, Crochet Jewelry, Handmade Crochet**\\
\\
$12.50\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1661676439/crochet-earrings-boho-earrings-handmade?click_key=169526b187eed4bd058b9f412467f263%3ALTd0ec548fc207f2bbbbbe6dc925f1bc357e8ecbf0&click_sum=8c87d1c5&ls=r&ref=related-3&content_source=169526b187eed4bd058b9f412467f263%253ALTd0ec548fc207f2bbbbbe6dc925f1bc357e8ecbf0 "Crochet Earrings, Boho Earrings, Handmade Earrings, Lightweight Jewelry, Knitting jewelry, Microcrochet, Crochet Jewelry, Handmade Crochet")




Add to Favorites


- [![Crochet Earrings, Boho Earrings, Handmade Earrings, Lightweight Jewelry, Knitting jewelry, Microcrochet, Crochet Jewelry, Handmade Crochet](https://i.etsystatic.com/44745067/r/il/d73704/5689552682/il_340x270.5689552682_6pba.jpg)\\
\\
**Crochet Earrings, Boho Earrings, Handmade Earrings, Lightweight Jewelry, Knitting jewelry, Microcrochet, Crochet Jewelry, Handmade Crochet**\\
\\
$12.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1661685957/crochet-earrings-boho-earrings-handmade?click_key=169526b187eed4bd058b9f412467f263%3ALT82f6b4f691ea56936dc9a202f460b25b0be811ce&click_sum=6369e07c&ls=r&ref=related-4&content_source=169526b187eed4bd058b9f412467f263%253ALT82f6b4f691ea56936dc9a202f460b25b0be811ce "Crochet Earrings, Boho Earrings, Handmade Earrings, Lightweight Jewelry, Knitting jewelry, Microcrochet, Crochet Jewelry, Handmade Crochet")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 10, 2025


[1090 favorites](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Jewelry](https://www.etsy.com/c/jewelry?amp%3Bclick_sum=fbeaef12&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=List+10+handmade+clay+earrings+under+%2430+from+Etsy&%3Bref=search_grid-707023-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpop=1&explicit=1&ref=breadcrumb_listing) [Earrings](https://www.etsy.com/c/jewelry/earrings?amp%3Bclick_sum=fbeaef12&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=List+10+handmade+clay+earrings+under+%2430+from+Etsy&%3Bref=search_grid-707023-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpop=1&explicit=1&ref=breadcrumb_listing) [Dangle & Drop Earrings](https://www.etsy.com/c/jewelry/earrings/dangle-earrings?amp%3Bclick_sum=fbeaef12&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=List+10+handmade+clay+earrings+under+%2430+from+Etsy&%3Bref=search_grid-707023-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpop=1&explicit=1&ref=breadcrumb_listing)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1781552903%2Fthanksgiving-turkey-dinner-plate%3Famp%253Bclick_sum%3Dfbeaef12%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DList%2B10%2Bhandmade%2Bclay%2Bearrings%2Bunder%2B%252430%2Bfrom%2BEtsy%26amp%253Bref%3Dsearch_grid-707023-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpop%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgxNzgxMTo0OGIyZTdhMDdlYjkxZjM3MmM5MGI2MGJmZThiNGZlNw==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1781552903%2Fthanksgiving-turkey-dinner-plate%3Famp%253Bclick_sum%3Dfbeaef12%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DList%2B10%2Bhandmade%2Bclay%2Bearrings%2Bunder%2B%252430%2Bfrom%2BEtsy%26amp%253Bref%3Dsearch_grid-707023-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpop%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?amp;click_sum=fbeaef12&amp;ls=a&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=List+10+handmade+clay+earrings+under+%2430+from+Etsy&amp;ref=search_grid-707023-1-2&amp;sr_prefetch=1&amp;pf_from=search&amp;pop=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1781552903%2Fthanksgiving-turkey-dinner-plate%3Famp%253Bclick_sum%3Dfbeaef12%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DList%2B10%2Bhandmade%2Bclay%2Bearrings%2Bunder%2B%252430%2Bfrom%2BEtsy%26amp%253Bref%3Dsearch_grid-707023-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpop%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings image 1](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_300x300.7399031169_mayf.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/IMG_7776_1_ijqhsh.jpg)

- ![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings image 2](https://i.etsystatic.com/44745067/r/il/3a65bb/7399031167/il_300x300.7399031167_ns02.jpg)
- ![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings image 3](https://i.etsystatic.com/44745067/r/il/854ace/7399031165/il_300x300.7399031165_ch0g.jpg)
- ![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings image 4](https://i.etsystatic.com/44745067/r/il/21796d/7351101036/il_300x300.7351101036_clgn.jpg)
- ![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings image 5](https://i.etsystatic.com/44745067/r/il/fc0048/7399031161/il_300x300.7399031161_g0hr.jpg)
- ![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings image 6](https://i.etsystatic.com/44745067/r/il/32d6a6/7399031163/il_300x300.7399031163_6w2n.jpg)

- ![](https://i.etsystatic.com/iap/30151f/6430832061/iap_640x640.6430832061_ovamort3.jpg?version=0)

5 out of 5 stars

So cute!! I’m so excited for Thanksgiving to come. 🦃

Oct 27, 2024


[Jodie](https://www.etsy.com/people/dnmgelpli537c0ri)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/d8d385/6424209782/iap_640x640.6424209782_qs08o6kn.jpg?version=0)

5 out of 5 stars

Such good quality.They some how look even better than they do in the pictures.
I'll be purchasing from this shop again in the future.

![](https://i.etsystatic.com/iusa/b96317/93216219/iusa_75x75.93216219_l8pz.jpg?version=0)

Nov 12, 2024


[Melly](https://www.etsy.com/people/5e1tydl9)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/ab9e82/6501040217/iap_640x640.6501040217_ihjalt46.jpg?version=0)

5 out of 5 stars

Great earrings. So many people complemented them.

Nov 23, 2024


[Jessica Wiskow](https://www.etsy.com/people/jessicawiskow)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/ca2855/6509095107/iap_640x640.6509095107_grm33pn3.jpg?version=0)

5 out of 5 stars

so cute and note heavy at all

![](https://i.etsystatic.com/iusa/350511/103097983/iusa_75x75.103097983_ekss.jpg?version=0)

Nov 26, 2024


[Lauren S.](https://www.etsy.com/people/HuFox)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/a9f07c/6462365711/iap_640x640.6462365711_apb22b7z.jpg?version=0)

5 out of 5 stars

Exactly as pictured!!! So excited to wear these to work, my kindergarteners are going to LOVE them!!

![](https://i.etsystatic.com/iusa/6410a6/83900064/iusa_75x75.83900064_tjng.jpg?version=0)

Nov 8, 2024


[Jordyn](https://www.etsy.com/people/rhh38wao)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/125026/6432864004/iap_640x640.6432864004_pkjakmkv.jpg?version=0)

5 out of 5 stars

These earrings are so fun! I love how realistic the dinner plate looks. Can’t wait to wear them for Thanksgiving! Thank you!

![](https://i.etsystatic.com/iusa/b5860a/63931764/iusa_75x75.63931764_fhe3.jpg?version=0)

Nov 15, 2024


[Timmura J](https://www.etsy.com/people/marabakes)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/e9fa2e/6331009598/iap_640x640.6331009598_5zloqwzk.jpg?version=0)

5 out of 5 stars

Stunning quality! Absolutely adorable in person & attention to detail is unmatched. My daughter and I cannot wait to wear these for the holiday season!

![](https://i.etsystatic.com/iusa/1e5f3e/25723357/iusa_75x75.25723357_8k47.jpg?version=0)

Oct 7, 2024


[Emily Moorman](https://www.etsy.com/people/eregan93)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/7b3adc/6391384294/iap_640x640.6391384294_t52xtqow.jpg?version=0)

5 out of 5 stars

These earrings are adorable! They’re perfect to wear for this Thanksgiving

![](https://i.etsystatic.com/iusa/ad3de2/107338731/iusa_75x75.107338731_1b67.jpg?version=0)

Oct 30, 2024


[Karen Rau](https://www.etsy.com/people/ki4w3elq)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/352619/6284389724/iap_640x640.6284389724_ici1crcd.jpg?version=0)

5 out of 5 stars

Omg I’m in loveeeee with these earrings!!! I can’t wait to wear them on thanksgiving!!!

![](https://i.etsystatic.com/iusa/e946b0/91932293/iusa_75x75.91932293_2sg1.jpg?version=0)

Sep 18, 2024


[Ashley Esposito](https://www.etsy.com/people/ashlaya)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/5d5b21/6492065255/iap_640x640.6492065255_5wbsfu94.jpg?version=0)

5 out of 5 stars

Super cute and absolutely perfect Thanksgiving earrings!

Nov 19, 2024


[Anna](https://www.etsy.com/people/xqfxl0b9)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/8fab8b/6322058984/iap_640x640.6322058984_69n8nubn.jpg?version=0)

5 out of 5 stars

They looks so realistic I love them

Oct 3, 2024


[Brenda Ochoa](https://www.etsy.com/people/dookiechan)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/ae5c8e/6432237858/iap_640x640.6432237858_p25ud8zd.jpg?version=0)

5 out of 5 stars

Love these! So cute and great quality.

![](https://i.etsystatic.com/iusa/f31127/7798325/iusa_75x75.7798325.jpg?version=0)

Nov 15, 2024


[Erinne Matte-Daniels](https://www.etsy.com/people/emattedaniels)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/6d37f1/6325485564/iap_640x640.6325485564_b1f6dw86.jpg?version=0)

5 out of 5 stars

I was so excited that the earrings I received were not only exactly what I ordered, but also somehow better. They also came SUPER early, so there was plenty of time to receive them before the holiday that I intended to wear the earrings to.

![](https://i.etsystatic.com/iusa/8066b7/103794891/iusa_75x75.103794891_m9x0.jpg?version=0)

Oct 5, 2024


[Elizabeth South](https://www.etsy.com/people/95ba281l9zu1me2s)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/d006a6/6424535113/iap_640x640.6424535113_oupss4m3.jpg?version=0)

5 out of 5 stars

Item came as described. Beautifully done. Very happy. Thanks you

![](https://i.etsystatic.com/iusa/bbcc13/52402373/iusa_75x75.52402373_gnlj.jpg?version=0)

Oct 24, 2024


[Kristina Gaddy](https://www.etsy.com/people/kristinagaddy3)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/0822ce/6426562115/iap_640x640.6426562115_3x0z5lv0.jpg?version=0)

5 out of 5 stars

My order came really quickly. The packaging was perfect from the sticker to the thank you card. I felt valued as a customer and like my money was well spent. The earrings are exactly what I ordered and were somehow better in person. I would definitely place an order from this seller again. I can't wait to show off my new earrings!

Oct 25, 2024


[Kristina Sparkman](https://www.etsy.com/people/Krissspark)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/ce0d10/6468578124/iap_640x640.6468578124_5d5zheds.jpg?version=0)

5 out of 5 stars

Super cute! I got a lot of compliments while wearing them

![](https://i.etsystatic.com/iusa/63d3e1/24292812/iusa_75x75.24292812_fboe.jpg?version=0)

Nov 29, 2024


[Veronica Bosley](https://www.etsy.com/people/vbose12345)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/091cea/6515860453/iap_640x640.6515860453_7myfdram.jpg?version=0)

5 out of 5 stars

These are little masterpieces! So cute and detailed! And they arrived in time to wear on the big day! Every big dinner from now on is going to be graced by these showstoppers!

![](https://i.etsystatic.com/iusa/5cd965/49788459/iusa_75x75.49788459_qrd0.jpg?version=0)

Nov 28, 2024


[angelluyster](https://www.etsy.com/people/angelluyster)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/212e9c/6266707754/iap_640x640.6266707754_qsrojz99.jpg?version=0)

5 out of 5 stars

Just like the listing!! SO cute in person!! Great craftsmanship!

![](https://i.etsystatic.com/iusa/55ea20/114169519/iusa_75x75.114169519_tjhw.jpg?version=0)

Sep 11, 2024


[Katherine D](https://www.etsy.com/people/kdrd06)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)

Purchased item:

[![Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings](https://i.etsystatic.com/44745067/r/il/0edfc1/7399031169/il_170x135.7399031169_mayf.jpg)\\
\\
Thanksgiving Turkey Dinner Plate Earrings: Miniature Polymer Clay Earrings\\
\\
$19.50](https://www.etsy.com/listing/1781552903/thanksgiving-turkey-dinner-plate?ref=ap-listing)