[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1687014371/dandelion-tote-bag-block-printed-organic?amp;click_sum=940dbf06&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Bags & Purses](https://www.etsy.com/c/bags-and-purses?amp%3Bclick_sum=940dbf06&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&explicit=1&ref=catnav_breadcrumb-0)
- [Totes](https://www.etsy.com/c/bags-and-purses/totes?amp%3Bclick_sum=940dbf06&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&explicit=1&ref=catnav_breadcrumb-1)

Etsy’s Pick

Etsy’s Picks are hand selected by our style experts to highlight items from shops that have shown quality, reliability and style.

[Discover More](https://www.etsy.com/featured/hub/etsy-picks?ref=listing_etsys_pick_signal)


Add to Favorites


- ![May include: A white tote bag with a green and yellow dandelion print. The bag has a label that reads 'organic cotton'.](https://i.etsystatic.com/23705448/r/il/12ee69/5848650785/il_794xN.5848650785_k1kp.jpg)
- ![May include: A white tote bag with a green and yellow dandelion print. The print is in a square shape and is centered on the bag. The bag has two straps.](https://i.etsystatic.com/23705448/r/il/eba061/5800577740/il_794xN.5800577740_5scw.jpg)
- ![May include: A white tote bag with a green and yellow dandelion print. The dandelion is a stylized design with a green stem and leaves and yellow flowers.](https://i.etsystatic.com/23705448/r/il/27d2ef/5848650711/il_794xN.5848650711_ih4g.jpg)
- ![May include: A tote bag with a green and yellow print of dandelions. The print is in a rectangular frame and features multiple dandelions in various stages of bloom. The dandelions are depicted with green stems and leaves.](https://i.etsystatic.com/23705448/r/il/60a382/5848650803/il_794xN.5848650803_m6mp.jpg)
- ![May include: A close-up of a white canvas tote bag with green and yellow printed design. The bag has two white straps and is stitched with white thread.](https://i.etsystatic.com/23705448/r/il/5beb8d/5800577808/il_794xN.5800577808_gu81.jpg)
- ![May include: A white fabric label with the text 'ORGANIC COTTON' printed in black](https://i.etsystatic.com/23705448/r/il/85f86e/5848650597/il_794xN.5848650597_hx38.jpg)

- ![May include: A white tote bag with a green and yellow dandelion print. The bag has a label that reads 'organic cotton'.](https://i.etsystatic.com/23705448/r/il/12ee69/5848650785/il_75x75.5848650785_k1kp.jpg)
- ![May include: A white tote bag with a green and yellow dandelion print. The print is in a square shape and is centered on the bag. The bag has two straps.](https://i.etsystatic.com/23705448/r/il/eba061/5800577740/il_75x75.5800577740_5scw.jpg)
- ![May include: A white tote bag with a green and yellow dandelion print. The dandelion is a stylized design with a green stem and leaves and yellow flowers.](https://i.etsystatic.com/23705448/r/il/27d2ef/5848650711/il_75x75.5848650711_ih4g.jpg)
- ![May include: A tote bag with a green and yellow print of dandelions. The print is in a rectangular frame and features multiple dandelions in various stages of bloom. The dandelions are depicted with green stems and leaves.](https://i.etsystatic.com/23705448/r/il/60a382/5848650803/il_75x75.5848650803_m6mp.jpg)
- ![May include: A close-up of a white canvas tote bag with green and yellow printed design. The bag has two white straps and is stitched with white thread.](https://i.etsystatic.com/23705448/r/il/5beb8d/5800577808/il_75x75.5800577808_gu81.jpg)
- ![May include: A white fabric label with the text 'ORGANIC COTTON' printed in black](https://i.etsystatic.com/23705448/r/il/85f86e/5848650597/il_75x75.5848650597_hx38.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1687014371%2Fdandelion-tote-bag-block-printed-organic%23report-overlay-trigger)

Only 4 left and in 1 cart

Price:$23.00


Loading


# Dandelion Tote Bag, Block Printed Organic Cotton Canvas Bag, 14x15 inches

Made by [QuietCoastGoods](https://www.etsy.com/shop/QuietCoastGoods)

[5 out of 5 stars](https://www.etsy.com/listing/1687014371/dandelion-tote-bag-block-printed-organic?amp;click_sum=940dbf06&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3#reviews)

Returns & exchanges accepted

You can only make an offer when buying a single item


Add to cart



Loading


## Buy together, get free shipping

## Buy together, get free shipping

Add both to cart



Loading


[See more items](https://www.etsy.com/listing/1687014371/dandelion-tote-bag-block-printed-organic?amp;click_sum=940dbf06&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3#recs_ribbon_container)

![Dandelion Tote Bag, Block Printed Organic Cotton Canvas Bag, 14x15 inches](https://i.etsystatic.com/23705448/r/il/12ee69/5848650785/il_340x270.5848650785_k1kp.jpg)
This listing

### Dandelion Tote Bag, Block Printed Organic Cotton Canvas Bag, 14x15 inches

$23.00


Add to Favorites


[![Strawberry Tote Bag, Block Printed Organic Cotton Canvas Fabric Shoulder Bag with Strawberry Print, 14.5x15.5 inches](https://i.etsystatic.com/23705448/c/2208/1755/0/28/il/d70e6a/5700155904/il_340x270.5700155904_tslk.jpg)\\
\\
**Strawberry Tote Bag, Block Printed Organic Cotton Canvas Fabric Shoulder Bag with Strawberry Print, 14.5x15.5 inches**\\
\\
$23.00](https://www.etsy.com/listing/1459950905/strawberry-tote-bag-block-printed?click_key=cf11a5985802510c256aa6be4c38d20f%3ALTbc12732f3c5568d30995635958fa20a0e85db35e&click_sum=c8b1c557&ls=r&ref=listing-free-shipping-bundle-1&content_source=cf11a5985802510c256aa6be4c38d20f%253ALTbc12732f3c5568d30995635958fa20a0e85db35e "Strawberry Tote Bag, Block Printed Organic Cotton Canvas Fabric Shoulder Bag with Strawberry Print, 14.5x15.5 inches")


Add to Favorites


![Dandelion Tote Bag, Block Printed Organic Cotton Canvas Bag, 14x15 inches](https://i.etsystatic.com/23705448/r/il/12ee69/5848650785/il_340x270.5848650785_k1kp.jpg)
This listing

### Dandelion Tote Bag, Block Printed Organic Cotton Canvas Bag, 14x15 inches

$23.00


Add to Favorites


[![Strawberry Tote Bag, Block Printed Organic Cotton Canvas Fabric Shoulder Bag with Strawberry Print, 14.5x15.5 inches](https://i.etsystatic.com/23705448/c/2208/1755/0/28/il/d70e6a/5700155904/il_340x270.5700155904_tslk.jpg)\\
\\
**Strawberry Tote Bag, Block Printed Organic Cotton Canvas Fabric Shoulder Bag with Strawberry Print, 14.5x15.5 inches**\\
\\
$23.00](https://www.etsy.com/listing/1459950905/strawberry-tote-bag-block-printed?click_key=cf11a5985802510c256aa6be4c38d20f%3ALTbc12732f3c5568d30995635958fa20a0e85db35e&click_sum=c8b1c557&ls=r&ref=listing-free-shipping-bundle-1&content_source=cf11a5985802510c256aa6be4c38d20f%253ALTbc12732f3c5568d30995635958fa20a0e85db35e "Strawberry Tote Bag, Block Printed Organic Cotton Canvas Fabric Shoulder Bag with Strawberry Print, 14.5x15.5 inches")


Add to Favorites


![Dandelion Tote Bag, Block Printed Organic Cotton Canvas Bag, 14x15 inches](https://i.etsystatic.com/23705448/r/il/12ee69/5848650785/il_340x270.5848650785_k1kp.jpg)
This listing

### Dandelion Tote Bag, Block Printed Organic Cotton Canvas Bag, 14x15 inches

$23.00


Add to Favorites


[![Strawberry Tote Bag, Block Printed Organic Cotton Canvas Fabric Shoulder Bag with Strawberry Print, 14.5x15.5 inches](https://i.etsystatic.com/23705448/c/2208/1755/0/28/il/d70e6a/5700155904/il_340x270.5700155904_tslk.jpg)\\
\\
**Strawberry Tote Bag, Block Printed Organic Cotton Canvas Fabric Shoulder Bag with Strawberry Print, 14.5x15.5 inches**\\
\\
$23.00](https://www.etsy.com/listing/1459950905/strawberry-tote-bag-block-printed?click_key=cf11a5985802510c256aa6be4c38d20f%3ALTbc12732f3c5568d30995635958fa20a0e85db35e&click_sum=c8b1c557&ls=r&ref=listing-free-shipping-bundle-1&content_source=cf11a5985802510c256aa6be4c38d20f%253ALTbc12732f3c5568d30995635958fa20a0e85db35e "Strawberry Tote Bag, Block Printed Organic Cotton Canvas Fabric Shoulder Bag with Strawberry Print, 14.5x15.5 inches")


Add to Favorites


## Item details

### Highlights

Made by [QuietCoastGoods](https://www.etsy.com/shop/QuietCoastGoods)

- Materials: Primary fabric type: Cotton; Secondary fabric type: Canvas


- Gift wrapping available


This Dandelion tote bag was printed by hand from hand-carved rubber blocks. The fabric is a durable canvas made from organic cotton, so it's perfect for carrying books, bringing to the beach, carrying groceries, and other everyday uses. These totes also make great gifts. Use it as an eco-friendly gift bag and fill it with smaller goodies--two gifts in one!

Cotton Canvas

about 14x15 inches

CARE INSTRUCTIONS

Machine wash in cold water.

Tumble dry on low heat.

Iron on reverse.


## Shipping and return policies

Loading


- Order today to get by

**Nov 15-Dec 1**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 30 days


- Ships from: **Portland, ME**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBrazilBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaGabonGambiaGeorgiaGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuineaGuinea-BissauGuyanaHaitiHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth KoreaSpainSri LankaSudanSurinameSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## Meet your seller

![Alex Boucher](https://i.etsystatic.com/23705448/r/isla/3bdabe/41156234/isla_75x75.41156234_67yvsdff.jpg)

Alex Boucher

Owner of [QuietCoastGoods](https://www.etsy.com/shop/QuietCoastGoods?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDozMTg0MTcyNDg6MTc2MjgyMDA2MzoxYWVlYzM3MzUwNWY5OWI5NWE4MDFhMDEzOWJlZmJlZg%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1687014371%2Fdandelion-tote-bag-block-printed-organic%3Famp%253Bclick_sum%3D940dbf06%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3)

[Message Alex](https://www.etsy.com/messages/new?with_id=318417248&referring_id=1687014371&referring_type=listing&recipient_id=318417248&from_action=contact-seller)

This seller usually responds **within 24 hours.**

## Reviews for this item (6)

5.0/5

item average

5.0Item quality

4.5Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Great quality

Love it

As described

Lots of compliments

Beautiful

Gift-worthy

Fast shipping


Filter by category


Quality (5)


Appearance (3)


Description accuracy (2)


Ease of use (1)


Shipping & Packaging (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/b27c4a/75083223/iusa_75x75.75083223_jpds.jpg?version=0)

[Zoë](https://www.etsy.com/people/2nl2hzfr?ref=l_review)
Jul 21, 2025


I love this bag! It’s high quality and I always get compliments.



![](https://i.etsystatic.com/iusa/b27c4a/75083223/iusa_75x75.75083223_jpds.jpg?version=0)

[Zoë](https://www.etsy.com/people/2nl2hzfr?ref=l_review)
Jul 21, 2025


5 out of 5 stars
5

This item

[Kate Mielke](https://www.etsy.com/people/kflower6?ref=l_review)
Apr 29, 2025


Just like the pictures! Perfect gift!



[Kate Mielke](https://www.etsy.com/people/kflower6?ref=l_review)
Apr 29, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/7ab651/44806073/iusa_75x75.44806073_9emq.jpg?version=0)

[Jennifer James](https://www.etsy.com/people/madamminnie?ref=l_review)
Oct 21, 2024


The print is beautiful. The fabric is heavy and good quality.



![](https://i.etsystatic.com/iusa/7ab651/44806073/iusa_75x75.44806073_9emq.jpg?version=0)

[Jennifer James](https://www.etsy.com/people/madamminnie?ref=l_review)
Oct 21, 2024


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/732629/89929307/iusa_75x75.89929307_9w03.jpg?version=0)

[Lori Thompson](https://www.etsy.com/people/fmjykpoyp1p0l7y0?ref=l_review)
Aug 8, 2024


Beautiful & useful gift for my daughter. She loves it!



![](https://i.etsystatic.com/iusa/732629/89929307/iusa_75x75.89929307_9w03.jpg?version=0)

[Lori Thompson](https://www.etsy.com/people/fmjykpoyp1p0l7y0?ref=l_review)
Aug 8, 2024


View all reviews for this item

[![QuietCoastGoods](https://i.etsystatic.com/iusa/b486a9/79608380/iusa_75x75.79608380_cimq.jpg?version=0)](https://www.etsy.com/shop/QuietCoastGoods?ref=shop_profile&listing_id=1687014371)

[QuietCoastGoods](https://www.etsy.com/shop/QuietCoastGoods?ref=shop_profile&listing_id=1687014371)

[Owned by Alex Boucher](https://www.etsy.com/shop/QuietCoastGoods?ref=shop_profile&listing_id=1687014371) \|

Portland, Maine

5.0
(226)


1k sales

5 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=318417248&referring_id=1687014371&referring_type=listing&recipient_id=318417248&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDozMTg0MTcyNDg6MTc2MjgyMDA2MzoxYWVlYzM3MzUwNWY5OWI5NWE4MDFhMDEzOWJlZmJlZg%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1687014371%2Fdandelion-tote-bag-block-printed-organic%3Famp%253Bclick_sum%3D940dbf06%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3)

This seller usually responds **within 24 hours.**

Smooth shippingHas a history of shipping on time with tracking.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/QuietCoastGoods?ref=lp_mys_mfts)

- [![Strawberry Tote Bag, Block Printed Organic Cotton Canvas Fabric Shoulder Bag with Strawberry Print, 14.5x15.5 inches](https://i.etsystatic.com/23705448/c/2208/1755/0/28/il/d70e6a/5700155904/il_340x270.5700155904_tslk.jpg)\\
\\
**Strawberry Tote Bag, Block Printed Organic Cotton Canvas Fabric Shoulder Bag with Strawberry Print, 14.5x15.5 inches**\\
\\
$23.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1459950905/strawberry-tote-bag-block-printed?click_key=f5064b4131be45887a8d2c4b266e09a3%3ALT8a5408f3699246b307435686400b9afd96c2e0dc&click_sum=0520874a&ls=r&ref=related-1&content_source=f5064b4131be45887a8d2c4b266e09a3%253ALT8a5408f3699246b307435686400b9afd96c2e0dc "Strawberry Tote Bag, Block Printed Organic Cotton Canvas Fabric Shoulder Bag with Strawberry Print, 14.5x15.5 inches")




Add to Favorites


- [![Purple Flower Tote Bag, Block Printed Organic Cotton Canvas Tote with Handprinted Flower Design, 14.5x15.5 inches](https://i.etsystatic.com/23705448/r/il/0e5ec7/6762725490/il_340x270.6762725490_398u.jpg)\\
\\
**Purple Flower Tote Bag, Block Printed Organic Cotton Canvas Tote with Handprinted Flower Design, 14.5x15.5 inches**\\
\\
$23.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1897340385/purple-flower-tote-bag-block-printed?click_key=f5064b4131be45887a8d2c4b266e09a3%3ALT52ceeb8dac3c0386da18eebe876701f3bf8d1972&click_sum=35b04894&ls=r&ref=related-2&content_source=f5064b4131be45887a8d2c4b266e09a3%253ALT52ceeb8dac3c0386da18eebe876701f3bf8d1972 "Purple Flower Tote Bag, Block Printed Organic Cotton Canvas Tote with Handprinted Flower Design, 14.5x15.5 inches")




Add to Favorites


- [![Orange Flower Tote Bag, Block Printed Organic Cotton Canvas Tote with Handprinted Flower Design, 14.5x15.5 inches](https://i.etsystatic.com/23705448/c/2283/2200/0/0/il/361072/5812225225/il_340x270.5812225225_bxs1.jpg)\\
\\
**Orange Flower Tote Bag, Block Printed Organic Cotton Canvas Tote with Handprinted Flower Design, 14.5x15.5 inches**\\
\\
$22.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1664853420/orange-flower-tote-bag-block-printed?click_key=f5064b4131be45887a8d2c4b266e09a3%3ALTc3631c556671c80b1fd544eda0f8767f5fda85da&click_sum=31e5a04d&ls=r&ref=related-3&content_source=f5064b4131be45887a8d2c4b266e09a3%253ALTc3631c556671c80b1fd544eda0f8767f5fda85da "Orange Flower Tote Bag, Block Printed Organic Cotton Canvas Tote with Handprinted Flower Design, 14.5x15.5 inches")




Add to Favorites


- [![Aquarius Tote Bag, Block Printed Organic Cotton Shoulder Bag, Reusable Fabric Bag, Gift for Aquarius, Fabric Gift Bag](https://i.etsystatic.com/23705448/c/2014/1601/309/43/il/509129/4312226199/il_340x270.4312226199_eyfx.jpg)\\
\\
**Aquarius Tote Bag, Block Printed Organic Cotton Shoulder Bag, Reusable Fabric Bag, Gift for Aquarius, Fabric Gift Bag**\\
\\
$23.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1328077067/aquarius-tote-bag-block-printed-organic?click_key=3a57ff14252d5b5f10676f9e86ccba123c542a11%3A1328077067&click_sum=5bfa3ceb&ref=related-4 "Aquarius Tote Bag, Block Printed Organic Cotton Shoulder Bag, Reusable Fabric Bag, Gift for Aquarius, Fabric Gift Bag")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading wedding form

Loading


## Top wedding searches to shop

[![](https://i.etsystatic.com/19757930/c/1333/1333/0/301/il/cfe72f/3482678762/il_300x300.3482678762_pxw3.jpg)\\
Bridesmaid gifts](https://www.etsy.com/search?q=bridesmaid+gifts&mosv=sese&moci=635510339037&mosi=618520640322&featured_listing=1110003408&ref=wedding_recs_lp_bridesmaid_gifts)

[![](https://i.etsystatic.com/19483987/r/il/42cd8d/2512481731/il_300x300.2512481731_8gz7.jpg)\\
Groomsmen gifts](https://www.etsy.com/search?q=groomsmen+gifts&mosv=sese&moci=635510339037&mosi=635510910189&featured_listing=761677858&ref=wedding_recs_lp_groomsmen_gifts)

[![](https://i.etsystatic.com/6748817/c/2000/2000/0/828/il/b140dc/3394740672/il_300x300.3394740672_mong.jpg)\\
Wedding gifts](https://www.etsy.com/search?q=wedding+gifts&mosv=sese&moci=635510339037&mosi=618520762754&featured_listing=1087712798&ref=wedding_recs_lp_wedding_gifts)

[![](https://i.etsystatic.com/5354512/r/il/35af5c/5783958379/il_300x300.5783958379_pio7.jpg)\\
Engagement gifts](https://www.etsy.com/search?q=engagement+gifts&mosv=sese&moci=635510339037&mosi=635511121285&featured_listing=190344599&ref=wedding_recs_lp_engagement_gifts)

Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Oct 10, 2025


[387 favorites](https://www.etsy.com/listing/1687014371/dandelion-tote-bag-block-printed-organic/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?amp%3Bclick_sum=940dbf06&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&explicit=1&ref=breadcrumb_listing) [Totes](https://www.etsy.com/c/bags-and-purses/totes?amp%3Bclick_sum=940dbf06&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Sunglasses & Eyewear

[Fabric Sunglasses Pouch - Glasses Case - Modern Pink Stripes - Regular Size - Sunglasses & Eyewear](https://www.etsy.com/listing/4317422132/fabric-sunglasses-pouch-glasses-case)

Patches & Pins

[Alice In Wonderland Enamel Pins for Sale](https://www.etsy.com/market/alice_in_wonderland_enamel_pins) [First Disneyland Trip Badge - US](https://www.etsy.com/market/first_disneyland_trip_badge)

Shopping

[Small Lotus Patch - US](https://www.etsy.com/market/small_lotus_patch) [Crepey Skin for Sale](https://www.etsy.com/market/crepey_skin)

Craft Supplies & Tools

[2.5" Acorn - Craft Supplies & Tools](https://www.etsy.com/listing/1752209972/25-acorn-oak-and-maple-wire-wired-edge)

Bracelets

[Pandora TURKIYE Heart Flag Dangle Charm Travel Pendant S925 Silver Jewelry for Bracelet for Necklace Mixed Enamel with Gift Box by RINPOCHEsCollections](https://www.etsy.com/listing/1780177298/pandora-turkiye-heart-flag-dangle-charm)

Home Decor

[Shop Textured Cross Canvas](https://www.etsy.com/market/textured_cross_canvas)

Kitchen & Dining

[If it costs you your peace mug](https://www.etsy.com/listing/1472799465/if-it-costs-you-your-peace-mug)

Beads Gems & Cabochons

[Coin Bird Czech Beads by DryGulch](https://www.etsy.com/listing/4335009313/blue-opal-ab-bird-coin-beads-coin-bird)

Office

[Vintage Piggy Bank Kitsch Money Box Pig Piggybank Ceramic Piggy Bank Tip Box Coin Bank Pig Figurine by VintageByThomas](https://www.etsy.com/listing/1255079484/vintage-piggy-bank-kitsch-money-box-pig)

Artist Trading Cards

[Leafeon V by GeneralMagikarp](https://www.etsy.com/listing/1400119856/leafeon-v)

Paper

[Iris Stationery Set for Sale](https://www.etsy.com/market/iris_stationery_set)

Prints

[Tai Poutini - Prints](https://www.etsy.com/listing/1563930737/tai-poutini-new-zealand-travel-print) [Buy Chicago Bear With Sunglasses Svg Online](https://www.etsy.com/market/chicago_bear_with_sunglasses_svg)

Keychains & Lanyards

[Pencil Topper - Keychains & Lanyards](https://www.etsy.com/listing/1070773955/pencil-topper-embroidered-turkey-turkey)

Knives & Cutting Tools

[Mom heart cutter by ClayLaneCollections](https://www.etsy.com/listing/1470772745/mom-heart-cutter-o-clay-cutters-o)

Womens Clothing

[Elrow - US](https://www.etsy.com/market/elrow)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1687014371%2Fdandelion-tote-bag-block-printed-organic%3Famp%253Bclick_sum%3D940dbf06%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgyMDA2MzpkODkxYjViZDY2OTY1MmVkNWU1Y2MzYjE5NmRlOGFlZg==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1687014371%2Fdandelion-tote-bag-block-printed-organic%3Famp%253Bclick_sum%3D940dbf06%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1687014371/dandelion-tote-bag-block-printed-organic?amp;click_sum=940dbf06&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1687014371%2Fdandelion-tote-bag-block-printed-organic%3Famp%253Bclick_sum%3D940dbf06%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for QuietCoastGoods

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: not accepted

Please contact the seller if you have any problems with your order.

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: A white tote bag with a green and yellow dandelion print. The bag has a label that reads 'organic cotton'.](https://i.etsystatic.com/23705448/r/il/12ee69/5848650785/il_300x300.5848650785_k1kp.jpg)
- ![May include: A white tote bag with a green and yellow dandelion print. The print is in a square shape and is centered on the bag. The bag has two straps.](https://i.etsystatic.com/23705448/r/il/eba061/5800577740/il_300x300.5800577740_5scw.jpg)
- ![May include: A white tote bag with a green and yellow dandelion print. The dandelion is a stylized design with a green stem and leaves and yellow flowers.](https://i.etsystatic.com/23705448/r/il/27d2ef/5848650711/il_300x300.5848650711_ih4g.jpg)
- ![May include: A tote bag with a green and yellow print of dandelions. The print is in a rectangular frame and features multiple dandelions in various stages of bloom. The dandelions are depicted with green stems and leaves.](https://i.etsystatic.com/23705448/r/il/60a382/5848650803/il_300x300.5848650803_m6mp.jpg)
- ![May include: A close-up of a white canvas tote bag with green and yellow printed design. The bag has two white straps and is stitched with white thread.](https://i.etsystatic.com/23705448/r/il/5beb8d/5800577808/il_300x300.5800577808_gu81.jpg)
- ![May include: A white fabric label with the text 'ORGANIC COTTON' printed in black](https://i.etsystatic.com/23705448/r/il/85f86e/5848650597/il_300x300.5848650597_hx38.jpg)