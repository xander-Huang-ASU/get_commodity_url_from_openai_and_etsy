[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?amp;click_sum=eb38ebbb&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;pro=1&amp;sts=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Bags & Purses](https://www.etsy.com/c/bags-and-purses?amp%3Bclick_sum=eb38ebbb&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-0)
- [Totes](https://www.etsy.com/c/bags-and-purses/totes?amp%3Bclick_sum=eb38ebbb&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-1)

Bestseller

This item has had a high sales volume over the past 6 months.



Add to Favorites


- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_794xN.6305969379_16ti.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets](https://i.etsystatic.com/31695446/r/il/e37a2c/6305969165/il_794xN.6305969165_1dwo.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets](https://i.etsystatic.com/31695446/r/il/b827ab/6259002910/il_794xN.6259002910_9l26.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets - Closeup](https://i.etsystatic.com/31695446/r/il/d6dd2a/6257918228/il_794xN.6257918228_t7vw.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets - Closeup](https://i.etsystatic.com/31695446/r/il/02c2e6/6257918270/il_794xN.6257918270_qoms.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets - Closeup](https://i.etsystatic.com/31695446/r/il/dc3d60/6305969295/il_794xN.6305969295_ldbk.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets - Closeup](https://i.etsystatic.com/31695446/r/il/0e11e6/6257918174/il_794xN.6257918174_qxhk.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets -Upgraded Version](https://i.etsystatic.com/31695446/r/il/c6a01a/6305969383/il_794xN.6305969383_p2ty.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets -Upgraded Version](https://i.etsystatic.com/31695446/r/il/88d903/6305969293/il_794xN.6305969293_owu7.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School image 10](https://i.etsystatic.com/31695446/r/il/c9aaa3/6797937301/il_794xN.6797937301_aupr.jpg)

- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_75x75.6305969379_16ti.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets](https://i.etsystatic.com/31695446/r/il/e37a2c/6305969165/il_75x75.6305969165_1dwo.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets](https://i.etsystatic.com/31695446/c/1052/1030/0/0/il/b827ab/6259002910/il_75x75.6259002910_9l26.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets - Closeup](https://i.etsystatic.com/31695446/r/il/d6dd2a/6257918228/il_75x75.6257918228_t7vw.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets - Closeup](https://i.etsystatic.com/31695446/r/il/02c2e6/6257918270/il_75x75.6257918270_qoms.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets - Closeup](https://i.etsystatic.com/31695446/r/il/dc3d60/6305969295/il_75x75.6305969295_ldbk.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets - Closeup](https://i.etsystatic.com/31695446/r/il/0e11e6/6257918174/il_75x75.6257918174_qxhk.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets -Upgraded Version](https://i.etsystatic.com/31695446/r/il/c6a01a/6305969383/il_75x75.6305969383_p2ty.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets -Upgraded Version](https://i.etsystatic.com/31695446/r/il/88d903/6305969293/il_75x75.6305969293_owu7.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School image 10](https://i.etsystatic.com/31695446/r/il/c9aaa3/6797937301/il_75x75.6797937301_aupr.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1716154949%2Fboho-embroidered-floral-tote-bag-in-sage%23report-overlay-trigger)

In 16 carts

Price:$26.00


Original Price:
$37.15


Loading


30% off


•

Limited time sale


# Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School

Made by [TomitomiBoutique](https://www.etsy.com/shop/TomitomiBoutique)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?amp;click_sum=eb38ebbb&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;pro=1&amp;sts=1#reviews)

Arrives soon! Get it by

Nov 13-17


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

Primary color


Select a color

Sage Green ($26.00)

Natural Beige ($26.00)

Please select a color


4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Made by [TomitomiBoutique](https://www.etsy.com/shop/TomitomiBoutique)

- Materials: Embroidered, canva, Cotton, Zipper Closure



We’re excited to introduce a new color option for our Boho Embroidered Floral Tote Bag! Now available in a serene Sage Green and a classic Natural Beige, it has all the same upgrades you love—reinforced canvas straps, a secure zipper closure, a durable interior, and two convenient pockets for extra storage. Choose the one that suits your style, or grab both for versatile, everyday elegance.

Measurements

Width: 17"

Height: 13"

Depth: 4.5"

Strap length: 11.4" from shoulder to bag.

\*In the picture, I'm 5 feet 4 inches tall.

Embrace effortless boho-chic style with our newly upgraded Boho Embroidered Floral Tote Bag, now available in two beautiful colors: Sage Green and Natural Beige. Adorned with delicate Daisy and Lavender embroidery, this tote adds a touch of nature-inspired beauty to any outfit.

Crafted from a soft cotton-linen blend, it’s both lightweight and durable. We've enhanced the design with reinforced canvas straps, a secure zipper closure, and two convenient interior pockets to keep your essentials safe and organized.

This tote is your versatile go-to accessory, perfect for beach days; market runs, or everyday adventures. Treating yourself or gifting someone special is the ideal choice for any occasion.

Elevate your bohemian flair with our Boho Embroidered Floral Tote Bag – now with all the features you’ll love!


## Shipping and return policies

Loading


- Order today to get by

**Nov 13-17**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 14 days


- Free shipping


- Ships from: **Long Island City, NY**


Deliver to United States

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBrazilBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaGabonGambiaGeorgiaGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuineaGuinea-BissauGuyanaHaitiHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth KoreaSpainSri LankaSudanSurinameSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (197)

5.0/5

item average

5.0Item quality

4.9Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Love it

Beautiful

Cute

Fast shipping

Great quality

Gift-worthy

As described


Filter by category


Quality (83)


Appearance (72)


Shipping & Packaging (42)


Description accuracy (25)


Seller service (15)


Sizing & Fit (14)


Ease of use (8)


Comfort (4)


Value (3)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Samantha](https://www.etsy.com/people/t6kd5fkyyocr5vsd?ref=l_review)
Nov 6, 2025


It was beautiful! Loved it!



[Samantha](https://www.etsy.com/people/t6kd5fkyyocr5vsd?ref=l_review)
Nov 6, 2025


5 out of 5 stars
5

This item

[Sign in with Apple user](https://www.etsy.com/people/elrvfqajn2dym51l?ref=l_review)
Nov 6, 2025


Came super fast and is just as pictured! It’s the perfect everyday bag for work. Thank you!



[Sign in with Apple user](https://www.etsy.com/people/elrvfqajn2dym51l?ref=l_review)
Nov 6, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/ce646c/5472179/iusa_75x75.5472179.jpg?version=0)

[KarensCustoms](https://www.etsy.com/people/KarensCustoms?ref=l_review)
Nov 6, 2025


I purchased this as a gift for my MIL - she loves it! It's lovely!



![](https://i.etsystatic.com/iusa/ce646c/5472179/iusa_75x75.5472179.jpg?version=0)

[KarensCustoms](https://www.etsy.com/people/KarensCustoms?ref=l_review)
Nov 6, 2025


5 out of 5 stars
5

This item

[Debbie](https://www.etsy.com/people/r25xzismtssq220m?ref=l_review)
Nov 6, 2025


This tote bag is so nice! It is exactly how it was described and I know I will be using it a lot. It arrived quickly and was well packaged.
This would also be a great gift for friends or family.



![Debbie added a photo of their purchase](https://i.etsystatic.com/iap/bcea92/7364860800/iap_300x300.7364860800_tv74rf5w.jpg?version=0)

[Debbie](https://www.etsy.com/people/r25xzismtssq220m?ref=l_review)
Nov 6, 2025


View all reviews for this item

### Photos from reviews

![Francine added a photo of their purchase](https://i.etsystatic.com/iap/6784f8/7131436059/iap_300x300.7131436059_6xxv4okj.jpg?version=0)

![Samantha added a photo of their purchase](https://i.etsystatic.com/iap/6552d9/7147783375/iap_300x300.7147783375_dc9gaou0.jpg?version=0)

![Elisabeth added a photo of their purchase](https://i.etsystatic.com/iap/46223a/6921787804/iap_300x300.6921787804_rs05ys5s.jpg?version=0)

![mikaela added a photo of their purchase](https://i.etsystatic.com/iap/d98ae1/7168617725/iap_300x300.7168617725_dssanx8s.jpg?version=0)

![molly added a photo of their purchase](https://i.etsystatic.com/iap/714ccb/6510992022/iap_300x300.6510992022_fdafc0rl.jpg?version=0)

![Francine added a photo of their purchase](https://i.etsystatic.com/iap/2c0ce3/7075042498/iap_300x300.7075042498_ny0mg2m7.jpg?version=0)

![Debbie added a photo of their purchase](https://i.etsystatic.com/iap/bcea92/7364860800/iap_300x300.7364860800_tv74rf5w.jpg?version=0)

![Christina added a photo of their purchase](https://i.etsystatic.com/iap/5c1a3e/6860506881/iap_300x300.6860506881_2jvhnd0u.jpg?version=0)

![Ash added a photo of their purchase](https://i.etsystatic.com/iap/515423/6919825938/iap_300x300.6919825938_joalivi1.jpg?version=0)

![Jennette added a photo of their purchase](https://i.etsystatic.com/iap/0d4a90/7393238593/iap_300x300.7393238593_7t1p54og.jpg?version=0)

![Linda added a photo of their purchase](https://i.etsystatic.com/iap/79832f/6877225063/iap_300x300.6877225063_8n2atycl.jpg?version=0)

![Sign added a photo of their purchase](https://i.etsystatic.com/iap/c936a1/7054724500/iap_300x300.7054724500_d2mzc5md.jpg?version=0)

![Kat added a photo of their purchase](https://i.etsystatic.com/iap/5b5e62/6490320800/iap_300x300.6490320800_sy5d9374.jpg?version=0)

![Maddie added a photo of their purchase](https://i.etsystatic.com/iap/f5366f/7175496590/iap_300x300.7175496590_2ai2ga8t.jpg?version=0)

![Linda added a photo of their purchase](https://i.etsystatic.com/iap/3b6b63/6877227229/iap_300x300.6877227229_9cwf6t4x.jpg?version=0)

![Ashley added a photo of their purchase](https://i.etsystatic.com/iap/bf82c0/7108998814/iap_300x300.7108998814_l7ej0iqw.jpg?version=0)

![Meghan added a photo of their purchase](https://i.etsystatic.com/iap/3a6b5f/6670481779/iap_300x300.6670481779_tvuaz0sr.jpg?version=0)

![Mia added a photo of their purchase](https://i.etsystatic.com/iap/0e0a70/7077593265/iap_300x300.7077593265_69iiu04f.jpg?version=0)

![LovelyTiffy added a photo of their purchase](https://i.etsystatic.com/iap/1f7e5f/6685396774/iap_300x300.6685396774_25w65gvc.jpg?version=0)

[![TomitomiBoutique](https://i.etsystatic.com/iusa/001c86/92688636/iusa_75x75.92688636_5pbz.jpg?version=0)](https://www.etsy.com/shop/TomitomiBoutique?ref=shop_profile&listing_id=1716154949)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[TomitomiBoutique](https://www.etsy.com/shop/TomitomiBoutique?ref=shop_profile&listing_id=1716154949)

[Owned by Sally](https://www.etsy.com/shop/TomitomiBoutique?ref=shop_profile&listing_id=1716154949) \|

New York, United States

5.0
(6.3k)


21.6k sales

4 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=524756668&referring_id=1716154949&referring_type=listing&recipient_id=524756668&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo1MjQ3NTY2Njg6MTc2MjgxOTk1OTpmMDBkNmVlMjBiZDQ5NmEzZGRlZjExYTYzZDQ2M2FmNw%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1716154949%2Fboho-embroidered-floral-tote-bag-in-sage%3Famp%253Bclick_sum%3Deb38ebbb%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bpro%3D1%26amp%253Bsts%3D1)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/TomitomiBoutique?ref=lp_mys_mfts)

- [![Tote bag with embroidered flowers |  Flower tote bag with inner pockets | Bridesmaid tote bag | Wedding | Gift For Her | Spring Gift](https://i.etsystatic.com/31695446/r/il/264b54/4488011362/il_340x270.4488011362_ksej.jpg)\\
\\
**Tote bag with embroidered flowers \| Flower tote bag with inner pockets \| Bridesmaid tote bag \| Wedding \| Gift For Her \| Spring Gift**\\
\\
Sale Price $10.00\\
$10.00\\
\\
$14.29\\
Original Price $14.29\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1077843136/tote-bag-with-embroidered-flowers-flower?click_key=be774abc275be936aaca14cda587e787%3ALT8368b952180dd6f429d53fef4eb6ef0a0c0f3db9&click_sum=62ceaf58&ls=r&ref=related-1&pro=1&sts=1&content_source=be774abc275be936aaca14cda587e787%253ALT8368b952180dd6f429d53fef4eb6ef0a0c0f3db9 "Tote bag with embroidered flowers |  Flower tote bag with inner pockets | Bridesmaid tote bag | Wedding | Gift For Her | Spring Gift")




Add to Favorites


- [![Embroidered Floral Corduroy Tote Bag: Soft Everyday Shoulder Bag](https://i.etsystatic.com/31695446/r/il/cfde3a/6786118471/il_340x270.6786118471_rgq8.jpg)\\
\\
**Embroidered Floral Corduroy Tote Bag: Soft Everyday Shoulder Bag**\\
\\
Sale Price $19.00\\
$19.00\\
\\
$27.14\\
Original Price $27.14\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1892522685/embroidered-floral-corduroy-tote-bag?click_key=be774abc275be936aaca14cda587e787%3ALT776ef0f457897428b1394f503c389a7e619d8872&click_sum=a25b6cc7&ls=r&ref=related-2&pro=1&sts=1&content_source=be774abc275be936aaca14cda587e787%253ALT776ef0f457897428b1394f503c389a7e619d8872 "Embroidered Floral Corduroy Tote Bag: Soft Everyday Shoulder Bag")




Add to Favorites


- [![Floral Tote Bag: Elegant Black & Beige Design with Purple Blooms](https://i.etsystatic.com/31695446/c/2024/1609/0/415/il/13505c/5755512300/il_340x270.5755512300_gl2j.jpg)\\
\\
**Floral Tote Bag: Elegant Black & Beige Design with Purple Blooms**\\
\\
Sale Price $22.00\\
$22.00\\
\\
$31.43\\
Original Price $31.43\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1570277456/floral-tote-bag-elegant-black-beige?click_key=be774abc275be936aaca14cda587e787%3ALT23b387246f8b7327179b652de588cf6c73af92d8&click_sum=a1b7aaa8&ls=r&ref=related-3&pro=1&sts=1&content_source=be774abc275be936aaca14cda587e787%253ALT23b387246f8b7327179b652de588cf6c73af92d8 "Floral Tote Bag: Elegant Black & Beige Design with Purple Blooms")




Add to Favorites


- [![Premium Corduroy Tote Bag | Navy Ginger Brown | Everyday Shoulder Bag with Water Bottle Holder Zipper Pocket  Magnetic Snap | Back to School](https://i.etsystatic.com/31695446/r/il/d18bef/6966762964/il_340x270.6966762964_luw7.jpg)\\
\\
**Premium Corduroy Tote Bag \| Navy Ginger Brown \| Everyday Shoulder Bag with Water Bottle Holder Zipper Pocket Magnetic Snap \| Back to School**\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4325536427/premium-corduroy-tote-bag-navy-ginger?click_key=04d288325e49b92397f2cf2f5261e3511405acf6%3A4325536427&click_sum=195062b4&ref=related-4&pro=1&sts=1 "Premium Corduroy Tote Bag | Navy Ginger Brown | Everyday Shoulder Bag with Water Bottle Holder Zipper Pocket  Magnetic Snap | Back to School")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading wedding form

Loading


## Top wedding searches to shop

[![](https://i.etsystatic.com/19757930/c/1333/1333/0/301/il/cfe72f/3482678762/il_300x300.3482678762_pxw3.jpg)\\
Bridesmaid gifts](https://www.etsy.com/search?q=bridesmaid+gifts&mosv=sese&moci=635510339037&mosi=618520640322&featured_listing=1110003408&ref=wedding_recs_lp_bridesmaid_gifts)

[![](https://i.etsystatic.com/19483987/r/il/42cd8d/2512481731/il_300x300.2512481731_8gz7.jpg)\\
Groomsmen gifts](https://www.etsy.com/search?q=groomsmen+gifts&mosv=sese&moci=635510339037&mosi=635510910189&featured_listing=761677858&ref=wedding_recs_lp_groomsmen_gifts)

[![](https://i.etsystatic.com/6748817/c/2000/2000/0/828/il/b140dc/3394740672/il_300x300.3394740672_mong.jpg)\\
Wedding gifts](https://www.etsy.com/search?q=wedding+gifts&mosv=sese&moci=635510339037&mosi=618520762754&featured_listing=1087712798&ref=wedding_recs_lp_wedding_gifts)

[![](https://i.etsystatic.com/5354512/r/il/35af5c/5783958379/il_300x300.5783958379_pio7.jpg)\\
Engagement gifts](https://www.etsy.com/search?q=engagement+gifts&mosv=sese&moci=635510339037&mosi=635511121285&featured_listing=190344599&ref=wedding_recs_lp_engagement_gifts)

Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 10, 2025


[3678 favorites](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?amp%3Bclick_sum=eb38ebbb&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Totes](https://www.etsy.com/c/bags-and-purses/totes?amp%3Bclick_sum=eb38ebbb&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&%3Bsts=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Womens Clothing

[Buy Green Fur Coat Online](https://www.etsy.com/market/green_fur_coat) [Custom 5 Inch Shorts for Sale](https://www.etsy.com/market/custom_5_inch_shorts)

Makeup & Cosmetics

[1940s Nail Polish - US](https://www.etsy.com/market/1940s_nail_polish)

Hats & Caps

[Buy Embroidery Scrub Cap Online](https://www.etsy.com/market/embroidery_scrub_cap)

Home Decor

[Buy Black Lacquer Clock Online](https://www.etsy.com/market/black_lacquer_clock) [Shop Book Fairy Ornament](https://www.etsy.com/market/book_fairy_ornament)

Paper

[Buy Luka Alien Stage Sticker Online](https://www.etsy.com/market/luka_alien_stage_sticker) [Phone Calls Log for Co-parenting - Paper, Stationery & Cards](https://www.etsy.com/listing/1184073036/phone-calls-log-for-co-parenting-parent)

Fabric & Notions

[Shop Bee Quilt Label](https://www.etsy.com/market/bee_quilt_label)

Patterns & How To

[Girl Scout Brownies Cookie Decision Maker Badge Plan Activities - Girl Scout Cookies - Educational Activity - Activities for Children by OnMyHonorDownloads](https://www.etsy.com/listing/1166196323/girl-scout-brownies-cookie-decision)

Drawing & Illustration

[Mill Stream Blue for Sale](https://www.etsy.com/market/mill_stream_blue)

Prints

[Shop Series Of Three Flower Pictures](https://www.etsy.com/market/series_of_three_flower_pictures)

Keychains & Lanyards

[Wooden Anime Keychain for Sale](https://www.etsy.com/market/wooden_anime_keychain)

Costume Accessories

[Theoden Scabbard - US](https://www.etsy.com/market/theoden_scabbard)

Bedding

[Shop Puff Quilts](https://www.etsy.com/market/puff_quilts)

Jewelry Storage

[Shop Resin Heart Dish](https://www.etsy.com/market/resin_heart_dish)

Food & Drink

[NelsonsTea](https://www.etsy.com/shop/NelsonsTea)

Necklaces

[Shop Moissanite Tennis Chain 20](https://www.etsy.com/market/moissanite_tennis_chain_20)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1716154949%2Fboho-embroidered-floral-tote-bag-in-sage%3Famp%253Bclick_sum%3Deb38ebbb%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bpro%3D1%26amp%253Bsts%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgxOTk1OTpkNjViOGUxYzFmZjQzNGUxZGM1YWI1OGU4Y2Q4YjQxMw==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1716154949%2Fboho-embroidered-floral-tote-bag-in-sage%3Famp%253Bclick_sum%3Deb38ebbb%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bpro%3D1%26amp%253Bsts%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?amp;click_sum=eb38ebbb&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;pro=1&amp;sts=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1716154949%2Fboho-embroidered-floral-tote-bag-in-sage%3Famp%253Bclick_sum%3Deb38ebbb%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bpro%3D1%26amp%253Bsts%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for TomitomiBoutique

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: not accepted

Please contact the seller if you have any problems with your order.

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## Seller details

### Business registration number

### Location

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=524756668&referring_id=31695446&referring_type=shop&recipient_id=524756668&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Item in the photo is in **Primary color: Sage Green**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Primary color: Natural Beige**




Select this option








Option selected!













This option is sold out.



Click to zoom

- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_300x300.6305969379_16ti.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets](https://i.etsystatic.com/31695446/r/il/e37a2c/6305969165/il_300x300.6305969165_1dwo.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets](https://i.etsystatic.com/31695446/c/1030/1030/11/0/il/b827ab/6259002910/il_300x300.6259002910_9l26.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets - Closeup](https://i.etsystatic.com/31695446/r/il/d6dd2a/6257918228/il_300x300.6257918228_t7vw.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets - Closeup](https://i.etsystatic.com/31695446/r/il/02c2e6/6257918270/il_300x300.6257918270_qoms.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets - Closeup](https://i.etsystatic.com/31695446/r/il/dc3d60/6305969295/il_300x300.6305969295_ldbk.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets - Closeup](https://i.etsystatic.com/31695446/r/il/0e11e6/6257918174/il_300x300.6257918174_qxhk.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets -Upgraded Version](https://i.etsystatic.com/31695446/r/il/c6a01a/6305969383/il_300x300.6305969383_p2ty.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green or Natural Beige – Daisy and Lavender Design – Upgraded with Zipper Closure & Reinforced Canvas – Hidden Pockets -Upgraded Version](https://i.etsystatic.com/31695446/r/il/88d903/6305969293/il_300x300.6305969293_owu7.jpg)
- ![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School image 10](https://i.etsystatic.com/31695446/r/il/c9aaa3/6797937301/il_300x300.6797937301_aupr.jpg)

- ![](https://i.etsystatic.com/iap/6784f8/7131436059/iap_640x640.7131436059_6xxv4okj.jpg?version=0)

5 out of 5 stars

- Color:

Sage Green


Nice zipper and 2 big pockets inside 😉

![](https://i.etsystatic.com/iusa/c82775/100596819/iusa_75x75.100596819_qsdd.jpg?version=0)

Aug 5, 2025


[Francine Broton](https://www.etsy.com/people/frankilb1)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/6552d9/7147783375/iap_640x640.7147783375_dc9gaou0.jpg?version=0)

5 out of 5 stars

- Color:

Sage Green


The bag is well made and the perfect size. I love the zipper feature as well. Sally’s handwritten note also made it very personal

![](https://i.etsystatic.com/iusa/1e9233/45027475/iusa_75x75.45027475_pgf8.jpg?version=0)

Aug 11, 2025


[Samantha Pellot](https://www.etsy.com/people/SPellot08)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/46223a/6921787804/iap_640x640.6921787804_rs05ys5s.jpg?version=0)

5 out of 5 stars

- Color:

Natural Beige


Amazing! So cute and well made also it has an inner pocket and zipper. She made it to her first farmers market today and carried quite a bit.

![](https://i.etsystatic.com/iusa/61d93a/42193641/iusa_75x75.42193641_o03y.jpg?version=0)

Jun 7, 2025


[Elisabeth Valley](https://www.etsy.com/people/ebether)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/d98ae1/7168617725/iap_640x640.7168617725_dssanx8s.jpg?version=0)

5 out of 5 stars

- Color:

Natural Beige


Extremely quick shipping! Extremely cute bag. Very happy with the quality. Exactly as pictured.

Aug 18, 2025


[mikaela dyer](https://www.etsy.com/people/mikangel013)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/714ccb/6510992022/iap_640x640.6510992022_fdafc0rl.jpg?version=0)

5 out of 5 stars

- Color:

Sage Green


I was looking for a cute bag to put all my bridesmaids gifts in. This is perfect! Feels really well made. Great size.

Dec 17, 2024


[molly harrington](https://www.etsy.com/people/mmharrington)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/2c0ce3/7075042498/iap_640x640.7075042498_ny0mg2m7.jpg?version=0)

5 out of 5 stars

- Color:

Sage Green


Oh I love the zipper in it and the little inside with 2 pockets it’s beautiful look at the beautiful material the color of fabric is amazing

![](https://i.etsystatic.com/iusa/c82775/100596819/iusa_75x75.100596819_qsdd.jpg?version=0)

Aug 2, 2025


[Francine Broton](https://www.etsy.com/people/frankilb1)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/bcea92/7364860800/iap_640x640.7364860800_tv74rf5w.jpg?version=0)

5 out of 5 stars

- Color:

Sage Green


This tote bag is so nice! It is exactly how it was described and I know I will be using it a lot. It arrived quickly and was well packaged.
This would also be a great gift for friends or family.

Nov 6, 2025


[Debbie](https://www.etsy.com/people/r25xzismtssq220m)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/5c1a3e/6860506881/iap_640x640.6860506881_2jvhnd0u.jpg?version=0)

5 out of 5 stars

- Color:

Sage Green


The bag was delivered 2 days after I ordered it which was much faster than expected (and definitely appreciated), I received constant updates on shipping and tracking. The bag isn’t too wide and has SO much space on the inside which is just what I wanted and I LOVE that it has a zipper unlike most totes. Love it, thank you!!

![](https://i.etsystatic.com/iusa/eeec35/92427483/iusa_75x75.92427483_jvfj.jpg?version=0)

Apr 23, 2025


[Christina](https://www.etsy.com/people/oidbdwg6)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/515423/6919825938/iap_640x640.6919825938_joalivi1.jpg?version=0)

5 out of 5 stars

- Color:

Sage Green


Beautiful bag. I saw an ad on instagram and know I had to have it! It’s so well made and well worth the reasonable price I paid for it.

It’s sturdy, has a nice lining and thick straps. I like the size too. It’s the right size to where it looks chic and girly. I would buy more if there were more colors available. 10/10 recommend! 💙

![](https://i.etsystatic.com/iusa/ca0343/103611514/iusa_75x75.103611514_5dvi.jpg?version=0)

Jun 6, 2025


[Ash](https://www.etsy.com/people/id0adsuk)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/0d4a90/7393238593/iap_640x640.7393238593_7t1p54og.jpg?version=0)

5 out of 5 stars

- Color:

Sage Green


This bag is stunning in person. Durable, exceptional quality and did I mention beautiful! I am over the moon happy with my purchase!

![](https://i.etsystatic.com/iusa/9ea7b3/52465803/iusa_75x75.52465803_jpt7.jpg?version=0)

Oct 31, 2025


[Jennette Blaess](https://www.etsy.com/people/jenbless1)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/79832f/6877225063/iap_640x640.6877225063_8n2atycl.jpg?version=0)

5 out of 5 stars

- Color:

Sage Green


This bag is more beautiful in person!! I love it so much. 10/10

![](https://i.etsystatic.com/iusa/25d78b/48005477/iusa_75x75.48005477_ih99.jpg?version=0)

Apr 30, 2025


[Linda Kim](https://www.etsy.com/people/lindakim913)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/c936a1/7054724500/iap_640x640.7054724500_d2mzc5md.jpg?version=0)

5 out of 5 stars

- Color:

Natural Beige


Love this bag!!! Super cute.

Jul 26, 2025


[Sign in with Apple user](https://www.etsy.com/people/mszf7xheaf8bj83m)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/5b5e62/6490320800/iap_640x640.6490320800_sy5d9374.jpg?version=0)

5 out of 5 stars

- Color:

Sage Green


The fabric is so pretty on this, and I love that it closes with a zipper!

![](https://i.etsystatic.com/iusa/79d2b0/67525800/iusa_75x75.67525800_sg9d.jpg?version=0)

Dec 8, 2024


[Kat Wahl](https://www.etsy.com/people/tm1x8cje)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/f5366f/7175496590/iap_640x640.7175496590_2ai2ga8t.jpg?version=0)

5 out of 5 stars

- Color:

Natural Beige


This is such a beautiful item. I bought this for a gift but I love it so much I think I’m going to get one for myself

![](https://i.etsystatic.com/iusa/e08ac5/57473070/iusa_75x75.57473070_34pt.jpg?version=0)

Sep 6, 2025


[Maddie Mueller-Howell](https://www.etsy.com/people/maddyknits)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/3b6b63/6877227229/iap_640x640.6877227229_9cwf6t4x.jpg?version=0)

5 out of 5 stars

- Color:

Natural Beige


The quality is amazing and you can fit so much in this bag. Way too cute!

![](https://i.etsystatic.com/iusa/25d78b/48005477/iusa_75x75.48005477_ih99.jpg?version=0)

Apr 30, 2025


[Linda Kim](https://www.etsy.com/people/lindakim913)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/bf82c0/7108998814/iap_640x640.7108998814_l7ej0iqw.jpg?version=0)

5 out of 5 stars

- Color:

Sage Green


Such a beautiful bag! Love the functionality, and it smelled really good out of the package ☺️

Aug 14, 2025


[Ashley](https://www.etsy.com/people/pa8xhqs19fg5mxct)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/3a6b5f/6670481779/iap_640x640.6670481779_tvuaz0sr.jpg?version=0)

5 out of 5 stars

- Color:

Natural Beige


This is the cutest tote bag! I've already received so many compliments! It arrived in pretty packaging with a personalized thank you note. I can tell the seller truly cares about her customers!

Feb 5, 2025


[Meghan](https://www.etsy.com/people/ztm4sg8q)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/0e0a70/7077593265/iap_640x640.7077593265_69iiu04f.jpg?version=0)

5 out of 5 stars

- Color:

Sage Green


This bag is beautiful! The embroidery is gorgeous and it’s so well made. I absolutely love it!

![](https://i.etsystatic.com/iusa/1441d4/115083796/iusa_75x75.115083796_2toj.jpg?version=0)

Jul 17, 2025


[Mia Caruso](https://www.etsy.com/people/291a7wg2z8fharov)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/1f7e5f/6685396774/iap_640x640.6685396774_25w65gvc.jpg?version=0)

5 out of 5 stars

- Color:

Sage Green


I bought this bag as a gift for my mom. It is so cute and I know she will love it!

![](https://i.etsystatic.com/iusa/a9ee85/6920532/iusa_75x75.6920532.jpg?version=0)

Mar 2, 2025


[LovelyTiffy](https://www.etsy.com/people/LovelyTiffy)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)

Purchased item:

[![Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy | Lavender Design with Zipper Closure Perfect Gift for Her Back to School](https://i.etsystatic.com/31695446/r/il/776cdb/6305969379/il_170x135.6305969379_16ti.jpg)\\
\\
Boho Embroidered Floral Tote Bag in Sage Green Natural Beige Daisy \| Lavender Design with Zipper Closure Perfect Gift for Her Back to School\\
\\
Sale Price $26.00\\
$26.00\\
\\
$37.14\\
Original Price $37.14\\
\\
\\
(30% off)](https://www.etsy.com/listing/1716154949/boho-embroidered-floral-tote-bag-in-sage?ref=ap-listing)