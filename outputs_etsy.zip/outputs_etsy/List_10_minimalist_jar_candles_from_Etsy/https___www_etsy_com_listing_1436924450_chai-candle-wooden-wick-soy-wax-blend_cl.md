[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1436924450/chai-candle-wooden-wick-soy-wax-blend?amp;click_sum=b6ebe015&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;sts=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=b6ebe015&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=b6ebe015&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=b6ebe015&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=b6ebe015&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-3)

Bestseller

This item has had a high sales volume over the past 6 months.



Add to Favorites


- ![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars image 1](https://i.etsystatic.com/39437375/r/il/b8cdc6/7344975899/il_794xN.7344975899_k6zo.jpg)
- ![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars image 2](https://i.etsystatic.com/39437375/r/il/413f52/7349396427/il_794xN.7349396427_as3f.jpg)
- ![May include: A white candle with a black rim in a glass jar. The candle has a star anise, cloves, and other brown spices embedded in the wax.](https://i.etsystatic.com/39437375/r/il/c12516/4774355084/il_794xN.4774355084_9nte.jpg)
- ![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars image 4](https://i.etsystatic.com/39437375/r/il/3d28c8/7349395755/il_794xN.7349395755_m8ct.jpg)
- ![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars image 5](https://i.etsystatic.com/39437375/r/il/74cab6/7349396131/il_794xN.7349396131_osx4.jpg)
- ![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars image 6](https://i.etsystatic.com/39437375/r/il/62e305/7296789330/il_794xN.7296789330_ma6d.jpg)
- ![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars image 7](https://i.etsystatic.com/39437375/r/il/dfef6f/7346505505/il_794xN.7346505505_cm5w.jpg)

- ![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars image 1](https://i.etsystatic.com/39437375/r/il/b8cdc6/7344975899/il_75x75.7344975899_k6zo.jpg)
- ![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars image 2](https://i.etsystatic.com/39437375/r/il/413f52/7349396427/il_75x75.7349396427_as3f.jpg)
- ![May include: A white candle with a black rim in a glass jar. The candle has a star anise, cloves, and other brown spices embedded in the wax.](https://i.etsystatic.com/39437375/r/il/c12516/4774355084/il_75x75.4774355084_9nte.jpg)
- ![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars image 4](https://i.etsystatic.com/39437375/r/il/3d28c8/7349395755/il_75x75.7349395755_m8ct.jpg)
- ![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars image 5](https://i.etsystatic.com/39437375/r/il/74cab6/7349396131/il_75x75.7349396131_osx4.jpg)
- ![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars image 6](https://i.etsystatic.com/39437375/r/il/62e305/7296789330/il_75x75.7296789330_ma6d.jpg)
- ![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars image 7](https://i.etsystatic.com/39437375/r/il/dfef6f/7346505505/il_75x75.7346505505_cm5w.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1436924450%2Fchai-candle-wooden-wick-soy-wax-blend%23report-overlay-trigger)

In 20+ carts

Price:$12.50


Loading


# Chai Candle \| Wooden Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars

[SavvyandStoneCandles](https://www.etsy.com/shop/SavvyandStoneCandles?ref=shop-header-name&listing_id=1436924450&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1436924450/chai-candle-wooden-wick-soy-wax-blend?amp;click_sum=b6ebe015&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;sts=1#reviews)

Arrives soon! Get it by

Nov 14-17


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

Quantity



1234567891011121314151617181920212223242526272829303132333435363738394041424344

4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Buy together, get free shipping

## Buy together, get free shipping

Add 3 items to cart



Loading


[See more items](https://www.etsy.com/listing/1436924450/chai-candle-wooden-wick-soy-wax-blend?amp;click_sum=b6ebe015&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;sts=1#recs_ribbon_container)

![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars](https://i.etsystatic.com/39437375/r/il/b8cdc6/7344975899/il_340x270.7344975899_k6zo.jpg)
This listing

### Chai Candle \| Wooden Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars

$12.50


Add to Favorites


[![Holiday Cookies Candle: Wood Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars](https://i.etsystatic.com/39437375/r/il/375269/7344775327/il_340x270.7344775327_p8pr.jpg)\\
\\
**Holiday Cookies Candle: Wood Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars**\\
\\
$12.50](https://www.etsy.com/listing/1785682376/holiday-cookies-candle-wood-wick-soy-wax?click_key=f7dc21607b5203ab6b5a5b49dfd62ea5%3ALT9c5d6baca1eb2782add164f27305d24ae5b030b1&click_sum=8ff02047&ls=r&ref=listing-free-shipping-bundle-1&sts=1&content_source=f7dc21607b5203ab6b5a5b49dfd62ea5%253ALT9c5d6baca1eb2782add164f27305d24ae5b030b1 "Holiday Cookies Candle: Wood Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars")


Add to Favorites


[![Spiced Orange Candle: Hand-Poured Soy Wax with Wooden Wick (6oz)](https://i.etsystatic.com/39437375/r/il/1cbdbd/6398206369/il_340x270.6398206369_ayk6.jpg)\\
\\
**Spiced Orange Candle: Hand-Poured Soy Wax with Wooden Wick (6oz)**\\
\\
$12.50](https://www.etsy.com/listing/1799879019/spiced-orange-candle-hand-poured-soy-wax?click_key=f7dc21607b5203ab6b5a5b49dfd62ea5%3ALT29d1638af62c9aa1a0bf789a881f7c1d6347e8cc&click_sum=a10dc36c&ls=r&ref=listing-free-shipping-bundle-2&sts=1&content_source=f7dc21607b5203ab6b5a5b49dfd62ea5%253ALT29d1638af62c9aa1a0bf789a881f7c1d6347e8cc "Spiced Orange Candle: Hand-Poured Soy Wax with Wooden Wick (6oz)")


Add to Favorites


![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars](https://i.etsystatic.com/39437375/r/il/b8cdc6/7344975899/il_340x270.7344975899_k6zo.jpg)
This listing

### Chai Candle \| Wooden Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars

$12.50


Add to Favorites


[![Holiday Cookies Candle: Wood Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars](https://i.etsystatic.com/39437375/r/il/375269/7344775327/il_340x270.7344775327_p8pr.jpg)\\
\\
**Holiday Cookies Candle: Wood Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars**\\
\\
$12.50](https://www.etsy.com/listing/1785682376/holiday-cookies-candle-wood-wick-soy-wax?click_key=f7dc21607b5203ab6b5a5b49dfd62ea5%3ALT9c5d6baca1eb2782add164f27305d24ae5b030b1&click_sum=8ff02047&ls=r&ref=listing-free-shipping-bundle-1&sts=1&content_source=f7dc21607b5203ab6b5a5b49dfd62ea5%253ALT9c5d6baca1eb2782add164f27305d24ae5b030b1 "Holiday Cookies Candle: Wood Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars")


Add to Favorites


[![Spiced Orange Candle: Hand-Poured Soy Wax with Wooden Wick (6oz)](https://i.etsystatic.com/39437375/r/il/1cbdbd/6398206369/il_340x270.6398206369_ayk6.jpg)\\
\\
**Spiced Orange Candle: Hand-Poured Soy Wax with Wooden Wick (6oz)**\\
\\
$12.50](https://www.etsy.com/listing/1799879019/spiced-orange-candle-hand-poured-soy-wax?click_key=f7dc21607b5203ab6b5a5b49dfd62ea5%3ALT29d1638af62c9aa1a0bf789a881f7c1d6347e8cc&click_sum=a10dc36c&ls=r&ref=listing-free-shipping-bundle-2&sts=1&content_source=f7dc21607b5203ab6b5a5b49dfd62ea5%253ALT29d1638af62c9aa1a0bf789a881f7c1d6347e8cc "Spiced Orange Candle: Hand-Poured Soy Wax with Wooden Wick (6oz)")


Add to Favorites


![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars](https://i.etsystatic.com/39437375/r/il/b8cdc6/7344975899/il_340x270.7344975899_k6zo.jpg)
This listing

### Chai Candle \| Wooden Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars

$12.50


Add to Favorites


[![Holiday Cookies Candle: Wood Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars](https://i.etsystatic.com/39437375/r/il/375269/7344775327/il_340x270.7344775327_p8pr.jpg)\\
\\
**Holiday Cookies Candle: Wood Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars**\\
\\
$12.50](https://www.etsy.com/listing/1785682376/holiday-cookies-candle-wood-wick-soy-wax?click_key=f7dc21607b5203ab6b5a5b49dfd62ea5%3ALT9c5d6baca1eb2782add164f27305d24ae5b030b1&click_sum=8ff02047&ls=r&ref=listing-free-shipping-bundle-1&sts=1&content_source=f7dc21607b5203ab6b5a5b49dfd62ea5%253ALT9c5d6baca1eb2782add164f27305d24ae5b030b1 "Holiday Cookies Candle: Wood Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars")


Add to Favorites


[![Spiced Orange Candle: Hand-Poured Soy Wax with Wooden Wick (6oz)](https://i.etsystatic.com/39437375/r/il/1cbdbd/6398206369/il_340x270.6398206369_ayk6.jpg)\\
\\
**Spiced Orange Candle: Hand-Poured Soy Wax with Wooden Wick (6oz)**\\
\\
$12.50](https://www.etsy.com/listing/1799879019/spiced-orange-candle-hand-poured-soy-wax?click_key=f7dc21607b5203ab6b5a5b49dfd62ea5%3ALT29d1638af62c9aa1a0bf789a881f7c1d6347e8cc&click_sum=a10dc36c&ls=r&ref=listing-free-shipping-bundle-2&sts=1&content_source=f7dc21607b5203ab6b5a5b49dfd62ea5%253ALT29d1638af62c9aa1a0bf789a881f7c1d6347e8cc "Spiced Orange Candle: Hand-Poured Soy Wax with Wooden Wick (6oz)")


Add to Favorites


## Item details

### Highlights

Made by [SavvyandStoneCandles](https://www.etsy.com/shop/SavvyandStoneCandles)

- Materials: Wax type: Soy


Indulge in the cozy and comforting aroma of our Handmade Chai Tea Soy Wooden Wick Candles!

These luxurious candles are hand-poured with love using premium soy wax and infused with the warm and inviting scent of spiced chai tea. The rich blend of cinnamon, cardamom, ginger, and cloves creates a captivating scent that will transport you to a cozy café or a serene tea room, making your home feel even more inviting and comforting.

Each candle is carefully crafted in small batches, ensuring the highest quality and attention to detail. The eco-friendly soy wax provides a clean and long-lasting burn, with a gentle and subtle scent that lingers in the air, creating a warm and inviting ambiance in any room.

Our Chai Tea Soy Candles are not only designed to delight your senses, but also to elevate your self-care routine.

These candles also make a thoughtful and unique gift for loved ones who appreciate the comforting aroma of chai tea and the warmth of a cozy Fall candle all year around. Share the joy of these handcrafted candles with your friends and family for special occasions or just because!

Top embellished with Star Anise, Cloves, Cinnamon, and Tiger's Eye stone chips.

All candles are individually packaged in a gift box labeled to match the candle fragrance.

Approx. 6 oz Net Wt in an 8 oz. premium black tin with lid.


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-17**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 30 days


- Ships from: **Springfield, OR**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------Puerto RicoUnited States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

## Meet your seller

![Joanna](https://i.etsystatic.com/39437375/r/isla/09624f/71527820/isla_75x75.71527820_emccikh5.jpg)

Joanna

Owner of [SavvyandStoneCandles](https://www.etsy.com/shop/SavvyandStoneCandles?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo3MjgwMzYwNzM6MTc2MjgyMzA3NzoyZWRkN2YzYzZiNWE3N2Q2MTJkZjRkYzg5OWNjNDA2Yg%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1436924450%2Fchai-candle-wooden-wick-soy-wax-blend%3Famp%253Bclick_sum%3Db6ebe015%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bsts%3D1)

[Message Joanna](https://www.etsy.com/messages/new?with_id=728036073&referring_id=1436924450&referring_type=listing&recipient_id=728036073&from_action=contact-seller)

This seller usually responds **within a few hours.**

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (221)

4.9/5

item average

4.9Item quality

4.9Shipping

5.0Customer service

99%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Smells amazing

Love it

Gift-worthy

Beautiful

Well packaged

Fast shipping

Would recommend


Filter by category


Quality (124)


Appearance (64)


Shipping & Packaging (49)


Description accuracy (23)


Seller service (11)


Value (7)


Sizing & Fit (5)


Comfort (2)


Ease of use (1)


Condition (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Paula](https://www.etsy.com/people/vkixygpo?ref=l_review)
Nov 10, 2025


Very nice candle. Arrived in good time. Has a lovely smell.



[Paula](https://www.etsy.com/people/vkixygpo?ref=l_review)
Nov 10, 2025


5 out of 5 stars
5

This item

[Colleen Spellman](https://www.etsy.com/people/33Spellman?ref=l_review)
Nov 9, 2025


I have received so many compliments regarding the smell of this candle. Thank you!



[Colleen Spellman](https://www.etsy.com/people/33Spellman?ref=l_review)
Nov 9, 2025


5 out of 5 stars
5

This item

[Zulma Romero](https://www.etsy.com/people/zmmb2xh6?ref=l_review)
Nov 9, 2025


This scented candle is one of my absolute favorites - it brings back fond memories of my childhood home.



[Zulma Romero](https://www.etsy.com/people/zmmb2xh6?ref=l_review)
Nov 9, 2025


5 out of 5 stars
5

This item

[Katie Gray](https://www.etsy.com/people/mygirlsmother?ref=l_review)
Nov 9, 2025


None at this time thank you



[Katie Gray](https://www.etsy.com/people/mygirlsmother?ref=l_review)
Nov 9, 2025


View all reviews for this item

### Photos from reviews

![Ryan added a photo of their purchase](https://i.etsystatic.com/iap/ae0a12/7344835248/iap_300x300.7344835248_ko7c64zs.jpg?version=0)

![Melissa added a photo of their purchase](https://i.etsystatic.com/iap/cfd490/6500847380/iap_300x300.6500847380_bcuzptys.jpg?version=0)

![Lexi added a photo of their purchase](https://i.etsystatic.com/iap/383581/6665384562/iap_300x300.6665384562_gtllaq4j.jpg?version=0)

![Heather added a photo of their purchase](https://i.etsystatic.com/iap/22118b/6418266088/iap_300x300.6418266088_o9uny1kd.jpg?version=0)

![FlounceDesigns added a photo of their purchase](https://i.etsystatic.com/iap/872909/6531087838/iap_300x300.6531087838_p38xi4z5.jpg?version=0)

![imreal added a photo of their purchase](https://i.etsystatic.com/iap/719681/6641954291/iap_300x300.6641954291_hqf76l0t.jpg?version=0)

![Liz added a photo of their purchase](https://i.etsystatic.com/iap/26e106/5857072679/iap_300x300.5857072679_9g10g6ru.jpg?version=0)

[![SavvyandStoneCandles](https://i.etsystatic.com/iusa/bca685/99299314/iusa_75x75.99299314_ttf8.jpg?version=0)](https://www.etsy.com/shop/SavvyandStoneCandles?ref=shop_profile&listing_id=1436924450)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[SavvyandStoneCandles](https://www.etsy.com/shop/SavvyandStoneCandles?ref=shop_profile&listing_id=1436924450)

[Owned by Joanna](https://www.etsy.com/shop/SavvyandStoneCandles?ref=shop_profile&listing_id=1436924450) \|

Springfield, Oregon

4.9
(1.5k)


6.9k sales

2.5 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=728036073&referring_id=1436924450&referring_type=listing&recipient_id=728036073&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo3MjgwMzYwNzM6MTc2MjgyMzA3NzoyZWRkN2YzYzZiNWE3N2Q2MTJkZjRkYzg5OWNjNDA2Yg%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1436924450%2Fchai-candle-wooden-wick-soy-wax-blend%3Famp%253Bclick_sum%3Db6ebe015%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bsts%3D1)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/SavvyandStoneCandles?ref=lp_mys_mfts)

- [![Holiday Cookies Candle: Wood Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars](https://i.etsystatic.com/39437375/r/il/375269/7344775327/il_340x270.7344775327_p8pr.jpg)\\
\\
**Holiday Cookies Candle: Wood Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars**\\
\\
$12.50\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1785682376/holiday-cookies-candle-wood-wick-soy-wax?click_key=b0570f59a8f710be7c7c473c690ec517%3ALT8165bead8d94b1b16aed69ad3884ba3bb988541c&click_sum=6acf40fb&ls=r&ref=related-1&sts=1&content_source=b0570f59a8f710be7c7c473c690ec517%253ALT8165bead8d94b1b16aed69ad3884ba3bb988541c "Holiday Cookies Candle: Wood Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars")




Add to Favorites


- [![Spiced Orange Candle: Hand-Poured Soy Wax with Wooden Wick (6oz)](https://i.etsystatic.com/39437375/r/il/1cbdbd/6398206369/il_340x270.6398206369_ayk6.jpg)\\
\\
**Spiced Orange Candle: Hand-Poured Soy Wax with Wooden Wick (6oz)**\\
\\
$12.50\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1799879019/spiced-orange-candle-hand-poured-soy-wax?click_key=b0570f59a8f710be7c7c473c690ec517%3ALTc1b482ff2dbac4e3689b7d17bdd5e5af044cb921&click_sum=d7c18d4c&ls=r&ref=related-2&sts=1&content_source=b0570f59a8f710be7c7c473c690ec517%253ALTc1b482ff2dbac4e3689b7d17bdd5e5af044cb921 "Spiced Orange Candle: Hand-Poured Soy Wax with Wooden Wick (6oz)")




Add to Favorites


- [![Halloween Candles | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars](https://i.etsystatic.com/39437375/r/il/516301/7296736990/il_340x270.7296736990_o9ya.jpg)\\
\\
**Halloween Candles \| Wooden Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars**\\
\\
Sale Price $9.37\\
$9.37\\
\\
$12.50\\
Original Price $12.50\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1773403224/halloween-candles-wooden-wick-soy-wax?click_key=b0570f59a8f710be7c7c473c690ec517%3ALT28bb481edddfaf333fd75c60c20ee7ad7b366020&click_sum=1cf4e295&ls=r&ref=related-3&pro=1&sts=1&content_source=b0570f59a8f710be7c7c473c690ec517%253ALT28bb481edddfaf333fd75c60c20ee7ad7b366020 "Halloween Candles | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars")




Add to Favorites


- [![Holly Berry Reindeer Games Candle: 6oz Soy Wax Blend with Wooden Wick](https://i.etsystatic.com/39437375/r/il/ca3451/7296957128/il_340x270.7296957128_gbuj.jpg)\\
\\
**Holly Berry Reindeer Games Candle: 6oz Soy Wax Blend with Wooden Wick**\\
\\
$12.50\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4382921539/holly-berry-reindeer-games-candle-6oz?click_key=82a015a0d4d56a7bd12ae959bd34cb3eb9d4568f%3A4382921539&click_sum=61dd9061&ref=related-4&sts=1 "Holly Berry Reindeer Games Candle: 6oz Soy Wax Blend with Wooden Wick")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 10, 2025


[2782 favorites](https://www.etsy.com/listing/1436924450/chai-candle-wooden-wick-soy-wax-blend/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=b6ebe015&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=b6ebe015&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=b6ebe015&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=b6ebe015&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Home Decor

[Christmas 12 inch Mesh Wreath by LittleTeesTreasures](https://www.etsy.com/listing/1886063132/christmas-12-inch-mesh-wreath) [Gay Table Decor - US](https://www.etsy.com/market/gay_table_decor) [Black Quilted Faux Dupioni Silk Cushion Covers Throw Pillow by HOMEHEARTBRANDSSTORE](https://www.etsy.com/listing/1802491803/black-quilted-faux-dupioni-silk-cushion) [Buy Ghosts Holding Hands Online](https://www.etsy.com/market/ghosts_holding_hands) [Buy Small Barrel Head Online](https://www.etsy.com/market/small_barrel_head) [Killotaya Sri Lanka for Sale](https://www.etsy.com/market/killotaya_sri_lanka) [MAHOGANY TEAKWOOD - Home Decor](https://www.etsy.com/listing/1661393722/mahogany-teakwood-25-oz-708-g-soy-wax) [Vintage Carson Dargon Co House of Lloyd Ceramic Victorian General Store Christmas Village - Home Decor](https://www.etsy.com/listing/1828018562/vintage-carson-dargon-co-house-of-lloyd) [Shop Gifts For Grandma From Grandkids](https://www.etsy.com/market/gifts_for_grandma_from_grandkids) [Shop Eccentric Bedroom Decor](https://www.etsy.com/market/eccentric_bedroom_decor)

Prints

[Shop Singapore Coffee Poster](https://www.etsy.com/market/singapore_coffee_poster)

Spirituality & Religion

[Rare Orange Orthoclase Feldspar Crystal Sphere - Orange Orthoclase - Gemstone Sphere - Healing Sphere - Energy Crystal - Her Christmas Gift by SanaAgateExports](https://www.etsy.com/listing/1254814214/rare-orange-orthoclase-feldspar-crystal)

Shopping

[Shop Halloween Pooh Png](https://www.etsy.com/market/halloween_pooh_png) [Matt Callan - US](https://www.etsy.com/market/matt_callan)

Kitchen & Dining

[Old Willow England for Sale](https://www.etsy.com/market/old_willow_england)

Paper

[Shop Hardhat Nameplates](https://www.etsy.com/market/hardhat_nameplates)

Backpacks

[Shop Purple Book Bag](https://www.etsy.com/market/purple_book_bag)

Gender Neutral Adult Clothing

[Grumpy Cat New Years Celebration Unisex T-shirt by LifeofMyGrumpyCat](https://www.etsy.com/listing/1829048195/grumpy-cat-new-years-celebration-unisex)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1436924450%2Fchai-candle-wooden-wick-soy-wax-blend%3Famp%253Bclick_sum%3Db6ebe015%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bsts%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgyMzA3NzozMTVhNjEzZjQ4MmFmN2I2NmY3NjI4MTYwZTdiY2Q5ZA==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1436924450%2Fchai-candle-wooden-wick-soy-wax-blend%3Famp%253Bclick_sum%3Db6ebe015%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bsts%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1436924450/chai-candle-wooden-wick-soy-wax-blend?amp;click_sum=b6ebe015&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;sts=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1436924450%2Fchai-candle-wooden-wick-soy-wax-blend%3Famp%253Bclick_sum%3Db6ebe015%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bsts%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Seller details

### Business registration number

### Location

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=728036073&referring_id=39437375&referring_type=shop&recipient_id=728036073&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars image 1](https://i.etsystatic.com/39437375/r/il/b8cdc6/7344975899/il_300x300.7344975899_k6zo.jpg)
- ![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars image 2](https://i.etsystatic.com/39437375/r/il/413f52/7349396427/il_300x300.7349396427_as3f.jpg)
- ![May include: A white candle with a black rim in a glass jar. The candle has a star anise, cloves, and other brown spices embedded in the wax.](https://i.etsystatic.com/39437375/r/il/c12516/4774355084/il_300x300.4774355084_9nte.jpg)
- ![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars image 4](https://i.etsystatic.com/39437375/r/il/3d28c8/7349395755/il_300x300.7349395755_m8ct.jpg)
- ![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars image 5](https://i.etsystatic.com/39437375/r/il/74cab6/7349396131/il_300x300.7349396131_osx4.jpg)
- ![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars image 6](https://i.etsystatic.com/39437375/r/il/62e305/7296789330/il_300x300.7296789330_ma6d.jpg)
- ![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars image 7](https://i.etsystatic.com/39437375/r/il/dfef6f/7346505505/il_300x300.7346505505_cm5w.jpg)

- ![](https://i.etsystatic.com/iap/ae0a12/7344835248/iap_640x640.7344835248_ko7c64zs.jpg?version=0)

5 out of 5 stars

Came just as described and shown!

Oct 31, 2025


[Ryan](https://www.etsy.com/people/7p7p2emld2yzui63)

Purchased item:

[![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars](https://i.etsystatic.com/39437375/r/il/b8cdc6/7344975899/il_170x135.7344975899_k6zo.jpg)\\
\\
Chai Candle \| Wooden Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars\\
\\
$12.50](https://www.etsy.com/listing/1436924450/chai-candle-wooden-wick-soy-wax-blend?ref=ap-listing)

Purchased item:

[![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars](https://i.etsystatic.com/39437375/r/il/b8cdc6/7344975899/il_170x135.7344975899_k6zo.jpg)\\
\\
Chai Candle \| Wooden Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars\\
\\
$12.50](https://www.etsy.com/listing/1436924450/chai-candle-wooden-wick-soy-wax-blend?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/cfd490/6500847380/iap_640x640.6500847380_bcuzptys.jpg?version=0)

5 out of 5 stars

The candle itself is quite lovely. Has an amazing scent and cute presentation. I’m gifting it a Christmas gift, but I would like to purchase one for myself.

![](https://i.etsystatic.com/iusa/bbbd45/69069828/iusa_75x75.69069828_lyqh.jpg?version=0)

Dec 12, 2024


[Melissa](https://www.etsy.com/people/k10gfmis)

Purchased item:

[![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars](https://i.etsystatic.com/39437375/r/il/b8cdc6/7344975899/il_170x135.7344975899_k6zo.jpg)\\
\\
Chai Candle \| Wooden Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars\\
\\
$12.50](https://www.etsy.com/listing/1436924450/chai-candle-wooden-wick-soy-wax-blend?ref=ap-listing)

Purchased item:

[![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars](https://i.etsystatic.com/39437375/r/il/b8cdc6/7344975899/il_170x135.7344975899_k6zo.jpg)\\
\\
Chai Candle \| Wooden Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars\\
\\
$12.50](https://www.etsy.com/listing/1436924450/chai-candle-wooden-wick-soy-wax-blend?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/383581/6665384562/iap_640x640.6665384562_gtllaq4j.jpg?version=0)

5 out of 5 stars

Subtle chai cinnamon smell is perfect when I'm meditating. Thank you.

Feb 22, 2025


[Lexi Aagesen](https://www.etsy.com/people/4pn6ulv3iv52uf7z)

Purchased item:

[![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars](https://i.etsystatic.com/39437375/r/il/b8cdc6/7344975899/il_170x135.7344975899_k6zo.jpg)\\
\\
Chai Candle \| Wooden Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars\\
\\
$12.50](https://www.etsy.com/listing/1436924450/chai-candle-wooden-wick-soy-wax-blend?ref=ap-listing)

Purchased item:

[![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars](https://i.etsystatic.com/39437375/r/il/b8cdc6/7344975899/il_170x135.7344975899_k6zo.jpg)\\
\\
Chai Candle \| Wooden Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars\\
\\
$12.50](https://www.etsy.com/listing/1436924450/chai-candle-wooden-wick-soy-wax-blend?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/22118b/6418266088/iap_640x640.6418266088_o9uny1kd.jpg?version=0)

5 out of 5 stars

I'm always worried about buying candles online but the smell is delicious.

Nov 10, 2024


[Heather Brown](https://www.etsy.com/people/zenstitch)

Purchased item:

[![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars](https://i.etsystatic.com/39437375/r/il/b8cdc6/7344975899/il_170x135.7344975899_k6zo.jpg)\\
\\
Chai Candle \| Wooden Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars\\
\\
$12.50](https://www.etsy.com/listing/1436924450/chai-candle-wooden-wick-soy-wax-blend?ref=ap-listing)

Purchased item:

[![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars](https://i.etsystatic.com/39437375/r/il/b8cdc6/7344975899/il_170x135.7344975899_k6zo.jpg)\\
\\
Chai Candle \| Wooden Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars\\
\\
$12.50](https://www.etsy.com/listing/1436924450/chai-candle-wooden-wick-soy-wax-blend?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/872909/6531087838/iap_640x640.6531087838_p38xi4z5.jpg?version=0)

5 out of 5 stars

Super pretty candle. My daughter loved it.

![](https://i.etsystatic.com/iusa/b4d695/73414194/iusa_75x75.73414194_qbta.jpg?version=0)

Dec 29, 2024


[FlounceDesigns](https://www.etsy.com/people/FlounceDesigns)

Purchased item:

[![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars](https://i.etsystatic.com/39437375/r/il/b8cdc6/7344975899/il_170x135.7344975899_k6zo.jpg)\\
\\
Chai Candle \| Wooden Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars\\
\\
$12.50](https://www.etsy.com/listing/1436924450/chai-candle-wooden-wick-soy-wax-blend?ref=ap-listing)

Purchased item:

[![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars](https://i.etsystatic.com/39437375/r/il/b8cdc6/7344975899/il_170x135.7344975899_k6zo.jpg)\\
\\
Chai Candle \| Wooden Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars\\
\\
$12.50](https://www.etsy.com/listing/1436924450/chai-candle-wooden-wick-soy-wax-blend?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/719681/6641954291/iap_640x640.6641954291_hqf76l0t.jpg?version=0)

5 out of 5 stars

The item smells just like chai tea, it's gorgeous, I wish there was a chai vanilla scent option. I would purchase it right up. The shipping was also quite fast, usually things get lost or in some cases get returned when I buy on some sites so I've been hesitant to purchase on Etsy but no problem with shipping thankfully

Jan 24, 2025


[imreal](https://www.etsy.com/people/ye8i91n6)

Purchased item:

[![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars](https://i.etsystatic.com/39437375/r/il/b8cdc6/7344975899/il_170x135.7344975899_k6zo.jpg)\\
\\
Chai Candle \| Wooden Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars\\
\\
$12.50](https://www.etsy.com/listing/1436924450/chai-candle-wooden-wick-soy-wax-blend?ref=ap-listing)

Purchased item:

[![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars](https://i.etsystatic.com/39437375/r/il/b8cdc6/7344975899/il_170x135.7344975899_k6zo.jpg)\\
\\
Chai Candle \| Wooden Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars\\
\\
$12.50](https://www.etsy.com/listing/1436924450/chai-candle-wooden-wick-soy-wax-blend?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/26e106/5857072679/iap_640x640.5857072679_9g10g6ru.jpg?version=0)

5 out of 5 stars

Smells amazing! It just got here ans I can't wait to light It up!

![](https://i.etsystatic.com/iusa/10e949/37392672/iusa_75x75.37392672_gc2s.jpg?version=0)

Mar 2, 2024


[Liz Williams](https://www.etsy.com/people/lizw703)

Purchased item:

[![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars](https://i.etsystatic.com/39437375/r/il/b8cdc6/7344975899/il_170x135.7344975899_k6zo.jpg)\\
\\
Chai Candle \| Wooden Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars\\
\\
$12.50](https://www.etsy.com/listing/1436924450/chai-candle-wooden-wick-soy-wax-blend?ref=ap-listing)

Purchased item:

[![Chai Candle | Wooden Wick | Soy Wax Blend | Gift Boxed | 6oz - FREE SHIPPING over 35 Dollars](https://i.etsystatic.com/39437375/r/il/b8cdc6/7344975899/il_170x135.7344975899_k6zo.jpg)\\
\\
Chai Candle \| Wooden Wick \| Soy Wax Blend \| Gift Boxed \| 6oz - FREE SHIPPING over 35 Dollars\\
\\
$12.50](https://www.etsy.com/listing/1436924450/chai-candle-wooden-wick-soy-wax-blend?ref=ap-listing)