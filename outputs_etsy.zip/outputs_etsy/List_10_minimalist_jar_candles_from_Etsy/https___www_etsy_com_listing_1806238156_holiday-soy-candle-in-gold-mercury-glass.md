[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1806238156/holiday-soy-candle-in-gold-mercury-glass?amp;click_sum=1fe04fd2&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=1fe04fd2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=1fe04fd2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=1fe04fd2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=1fe04fd2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&explicit=1&ref=catnav_breadcrumb-3)


Add to Favorites


- ![Holiday Soy Candle in Gold Mercury Glass - Winter - Christmas - 100% Natural Soy Wax - Nontoxic- Clean -Phthalate Free- Gift - Cotton Wick image 1](https://i.etsystatic.com/11861778/r/il/c67825/7362693862/il_794xN.7362693862_ih25.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1806238156%2Fholiday-soy-candle-in-gold-mercury-glass%23report-overlay-trigger)

Price:$20.00


Loading


# Holiday Soy Candle in Gold Mercury Glass - Winter - Christmas - 100% Natural Soy Wax - Nontoxic- Clean -Phthalate Free- Gift - Cotton Wick

[EarthTonix](https://www.etsy.com/shop/EarthTonix?ref=shop-header-name&listing_id=1806238156&from_page=listing)

[5 out of 5 stars](https://www.etsy.com/listing/1806238156/holiday-soy-candle-in-gold-mercury-glass?amp;click_sum=1fe04fd2&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3#reviews)

Arrives soon! Get it by

Nov 14-18


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Scent


Select an option

Fraser Fir

Gingerbread Latte

Home for the Holiday

Winter Wonderland

White Birch

Please select an option


Quantity



12345678910

4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Buy together, get free shipping

## Buy together, get free shipping

Add both to cart



Loading


[See more items](https://www.etsy.com/listing/1806238156/holiday-soy-candle-in-gold-mercury-glass?amp;click_sum=1fe04fd2&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3#recs_ribbon_container)

![Holiday Soy Candle in Gold Mercury Glass - Winter - Christmas - 100% Natural Soy Wax - Nontoxic- Clean -Phthalate  Free- Gift - Cotton Wick](https://i.etsystatic.com/11861778/r/il/c67825/7362693862/il_340x270.7362693862_ih25.jpg)
This listing

### Holiday Soy Candle in Gold Mercury Glass - Winter - Christmas - 100% Natural Soy Wax - Nontoxic- Clean -Phthalate Free- Gift - Cotton Wick

$20.00


Add to Favorites


[![Bridal Candle Collection-100% Natural Soy Wax infused with Crystals & Botanicals -NonToxic -  Gift for Bridesmaid, MOH, etc - Phthalate Free](https://i.etsystatic.com/11861778/r/il/df1df2/7309497020/il_340x270.7309497020_wytj.jpg)\\
\\
**Bridal Candle Collection-100% Natural Soy Wax infused with Crystals & Botanicals -NonToxic - Gift for Bridesmaid, MOH, etc - Phthalate Free**\\
\\
$22.00](https://www.etsy.com/listing/4390761504/bridal-candle-collection-100-natural-soy?click_key=20e162de6e2063144b1c1530cca53bcd%3ALT724c021da0bd7fd7db3ce6cd3e38b953bdce9822&click_sum=57e7f19c&ls=r&ref=listing-free-shipping-bundle-1&content_source=20e162de6e2063144b1c1530cca53bcd%253ALT724c021da0bd7fd7db3ce6cd3e38b953bdce9822 "Bridal Candle Collection-100% Natural Soy Wax infused with Crystals & Botanicals -NonToxic -  Gift for Bridesmaid, MOH, etc - Phthalate Free")


Add to Favorites


![Holiday Soy Candle in Gold Mercury Glass - Winter - Christmas - 100% Natural Soy Wax - Nontoxic- Clean -Phthalate  Free- Gift - Cotton Wick](https://i.etsystatic.com/11861778/r/il/c67825/7362693862/il_340x270.7362693862_ih25.jpg)
This listing

### Holiday Soy Candle in Gold Mercury Glass - Winter - Christmas - 100% Natural Soy Wax - Nontoxic- Clean -Phthalate Free- Gift - Cotton Wick

$20.00


Add to Favorites


[![Bridal Candle Collection-100% Natural Soy Wax infused with Crystals & Botanicals -NonToxic -  Gift for Bridesmaid, MOH, etc - Phthalate Free](https://i.etsystatic.com/11861778/r/il/df1df2/7309497020/il_340x270.7309497020_wytj.jpg)\\
\\
**Bridal Candle Collection-100% Natural Soy Wax infused with Crystals & Botanicals -NonToxic - Gift for Bridesmaid, MOH, etc - Phthalate Free**\\
\\
$22.00](https://www.etsy.com/listing/4390761504/bridal-candle-collection-100-natural-soy?click_key=20e162de6e2063144b1c1530cca53bcd%3ALT724c021da0bd7fd7db3ce6cd3e38b953bdce9822&click_sum=57e7f19c&ls=r&ref=listing-free-shipping-bundle-1&content_source=20e162de6e2063144b1c1530cca53bcd%253ALT724c021da0bd7fd7db3ce6cd3e38b953bdce9822 "Bridal Candle Collection-100% Natural Soy Wax infused with Crystals & Botanicals -NonToxic -  Gift for Bridesmaid, MOH, etc - Phthalate Free")


Add to Favorites


![Holiday Soy Candle in Gold Mercury Glass - Winter - Christmas - 100% Natural Soy Wax - Nontoxic- Clean -Phthalate  Free- Gift - Cotton Wick](https://i.etsystatic.com/11861778/r/il/c67825/7362693862/il_340x270.7362693862_ih25.jpg)
This listing

### Holiday Soy Candle in Gold Mercury Glass - Winter - Christmas - 100% Natural Soy Wax - Nontoxic- Clean -Phthalate Free- Gift - Cotton Wick

$20.00


Add to Favorites


[![Bridal Candle Collection-100% Natural Soy Wax infused with Crystals & Botanicals -NonToxic -  Gift for Bridesmaid, MOH, etc - Phthalate Free](https://i.etsystatic.com/11861778/r/il/df1df2/7309497020/il_340x270.7309497020_wytj.jpg)\\
\\
**Bridal Candle Collection-100% Natural Soy Wax infused with Crystals & Botanicals -NonToxic - Gift for Bridesmaid, MOH, etc - Phthalate Free**\\
\\
$22.00](https://www.etsy.com/listing/4390761504/bridal-candle-collection-100-natural-soy?click_key=20e162de6e2063144b1c1530cca53bcd%3ALT724c021da0bd7fd7db3ce6cd3e38b953bdce9822&click_sum=57e7f19c&ls=r&ref=listing-free-shipping-bundle-1&content_source=20e162de6e2063144b1c1530cca53bcd%253ALT724c021da0bd7fd7db3ce6cd3e38b953bdce9822 "Bridal Candle Collection-100% Natural Soy Wax infused with Crystals & Botanicals -NonToxic -  Gift for Bridesmaid, MOH, etc - Phthalate Free")


Add to Favorites


## Item details

EARTH TONIX HOLIDAY SOY CANDLES

Festive & Delightful clean scents hand poured in Gold Mercury Glass Jar!

These beauties are perfect for gifting & will fill your space with Holiday Magic!

CHOOSE FROM THE SCENTS BELOW:

•FRASER FIR: LEMON, CEDAR, FIR BALSAM

•WINTER WONDERLAND: PEPPERMINT, EUCALYPTUS, CEDAR LEAF, VANILLA

•GINGERBREAD LATTE: GINGER, NUTMEG, ESPRESSO

•HOME FOR THE HOLIDAYS: ORANGE, CLOVE, PINE

•WHITE BIRCH: EUCALYTUPS, FIR NEEDLE, CEDAR LEAF

5.05 oz net wt

Gold Mercury Glass Jar with Bamboo Lid

Estimated Burn Time: 35+ Hours each

Small Batch and Hand Poured with intention

\*Note: Each candle has unique & intentional botanicals/herbs/mica infused into the wax

Keep your wick trimmed for A long, clean, even burn with strong scent throw!

Designed for Holistic Wellness & Aromatherapy - Clean Ingredients - No Headaches

Vegan, hand made with 100% natural soy wax, cotton wick, high end non-toxic fragrance oils infused with pure essential oils in a reusable glass vessel.

All candles are Phthalate Free, Lead & Zinc Free, Non-Toxic & Meet RIFM and IFRA standards for safety and purity.�

CANDLE CARE & SAFETY:

Always Burn within sight. Keep away from flammable objects.Keep away from children and pets. Remove Botanical Toppings before burning & extinguish any botanicals if they catch fire. Only burn the candle on a level & fire resistant surface. Trim wick to 1/4" before EACH lighting. Keep wick centered. For a long candle life, burn for atleast 2 hours before putting flame out (this creates an even wax pool and no tunneling). Do not burn candle for more than 4 hours at a time. Take care in collecting your crystals - do not touch hot wax. Stop use when only 1/4" of wax remains (Place on a candle warmer to enjoy remaining 1/4" of wax).

Disclaimer: Statements contained have not been evaluated by the Food and Drug Administration. These products are not intended to diagnose, treat , cure or prevent disease or substitute care by a medical practitioner. Earth Tonix, LLC is not responsible for misuse or care of products. All products are intended for adult unless otherwise stated

Use and store out of reach of children and pets. By purchasing buyer is aware and agrees to all policies.


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-18**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges not accepted




But please contact me if you have problems with your order


- Ships from: **Gainesville, FL**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## Meet your seller

![Melinda York](https://i.etsystatic.com/11861778/c/2283/2283/383/400/isla/7012a2/79792089/isla_75x75.79792089_qzsg3zs5.jpg)

Melinda York

Owner of [EarthTonix](https://www.etsy.com/shop/EarthTonix?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyNDQzNDUxODoxNzYyODIzMTc5OjBlNWQwYTJlNDM5YzBjYTM2YjEzZmNlZGZkYWRjMjVl&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1806238156%2Fholiday-soy-candle-in-gold-mercury-glass%3Famp%253Bclick_sum%3D1fe04fd2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3)

[Message Melinda](https://www.etsy.com/messages/new?with_id=24434518&referring_id=1806238156&referring_type=listing&recipient_id=24434518&from_action=contact-seller)

This seller usually responds **within 24 hours.**

## Reviews for this item (5)

5.0/5

item average

5.0Item quality

5.0Shipping

5.0Customer service

100%
Buyers recommend

Loading


Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Katie Drane](https://www.etsy.com/people/kdrane33?ref=l_review)
Dec 23, 2024


These candles are so well made and smell so good!



[Katie Drane](https://www.etsy.com/people/kdrane33?ref=l_review)
Dec 23, 2024


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/4811d2/48758649/iusa_75x75.48758649_6p31.jpg?version=0)

[Britan Ethridge](https://www.etsy.com/people/britan143?ref=l_review)
Dec 21, 2024


Smells amazing and beautifully crafted!



![](https://i.etsystatic.com/iusa/4811d2/48758649/iusa_75x75.48758649_6p31.jpg?version=0)

[Britan Ethridge](https://www.etsy.com/people/britan143?ref=l_review)
Dec 21, 2024


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/4811d2/48758649/iusa_75x75.48758649_6p31.jpg?version=0)

[Britan Ethridge](https://www.etsy.com/people/britan143?ref=l_review)
Dec 21, 2024


Great gift for Christmas! Beautiful and smells great



![](https://i.etsystatic.com/iusa/4811d2/48758649/iusa_75x75.48758649_6p31.jpg?version=0)

[Britan Ethridge](https://www.etsy.com/people/britan143?ref=l_review)
Dec 21, 2024


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/181913/5724056/iusa_75x75.5724056.jpg?version=0)

[Jennifer Jozwiak](https://www.etsy.com/people/heartwoventraditions?ref=l_review)
Dec 16, 2024


Always fantastic and the best candles ever!



![](https://i.etsystatic.com/iusa/181913/5724056/iusa_75x75.5724056.jpg?version=0)

[Jennifer Jozwiak](https://www.etsy.com/people/heartwoventraditions?ref=l_review)
Dec 16, 2024


View all reviews for this item

[![EarthTonix](https://i.etsystatic.com/iusa/eb8e44/38262479/iusa_75x75.38262479_jqb1.jpg?version=0)](https://www.etsy.com/shop/EarthTonix?ref=shop_profile&listing_id=1806238156)

[EarthTonix](https://www.etsy.com/shop/EarthTonix?ref=shop_profile&listing_id=1806238156)

[Owned by Melinda York](https://www.etsy.com/shop/EarthTonix?ref=shop_profile&listing_id=1806238156) \|

Gainesville, Florida

4.9
(1.1k)


6.5k sales

9 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=24434518&referring_id=1806238156&referring_type=listing&recipient_id=24434518&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyNDQzNDUxODoxNzYyODIzMTc5OjBlNWQwYTJlNDM5YzBjYTM2YjEzZmNlZGZkYWRjMjVl&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1806238156%2Fholiday-soy-candle-in-gold-mercury-glass%3Famp%253Bclick_sum%3D1fe04fd2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3)

This seller usually responds **within 24 hours.**

Smooth shippingHas a history of shipping on time with tracking.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/EarthTonix?ref=lp_mys_mfts)

- [![Holiday Soy 3 Wick Candle in Green Jar - Winter - Christmas - 100% Natural Soy Wax - Nontoxic- Clean -Phthalate Free - Holiday Gift](https://i.etsystatic.com/11861778/r/il/cbde6d/7410631049/il_340x270.7410631049_m3p0.jpg)\\
\\
**Holiday Soy 3 Wick Candle in Green Jar - Winter - Christmas - 100% Natural Soy Wax - Nontoxic- Clean -Phthalate Free - Holiday Gift**\\
\\
$44.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4399589879/holiday-soy-3-wick-candle-in-green-jar?click_key=ca42824c30b0ae05ae6255b985aed71b%3ALT31ef44dad1225f21ee2a0d68fa7214b0e9e2bbc6&click_sum=f9b44d36&ls=r&ref=related-1&content_source=ca42824c30b0ae05ae6255b985aed71b%253ALT31ef44dad1225f21ee2a0d68fa7214b0e9e2bbc6 "Holiday Soy 3 Wick Candle in Green Jar - Winter - Christmas - 100% Natural Soy Wax - Nontoxic- Clean -Phthalate Free - Holiday Gift")




Add to Favorites


- [![Santa Mug 2 Wick Soy Candle - Winter - Christmas - 100% Natural Soy Wax - Nontoxic- Clean -Phthalate Free - Holiday Gift - Free Shipping](https://i.etsystatic.com/11861778/r/il/c7522b/7362725506/il_340x270.7362725506_8o8l.jpg)\\
\\
**Santa Mug 2 Wick Soy Candle - Winter - Christmas - 100% Natural Soy Wax - Nontoxic- Clean -Phthalate Free - Holiday Gift - Free Shipping**\\
\\
$44.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4399596191/santa-mug-2-wick-soy-candle-winter?click_key=ca42824c30b0ae05ae6255b985aed71b%3ALT22096c0d38075ac49b10af3734d6fcdef61b8ffc&click_sum=119913ee&ls=r&ref=related-2&content_source=ca42824c30b0ae05ae6255b985aed71b%253ALT22096c0d38075ac49b10af3734d6fcdef61b8ffc "Santa Mug 2 Wick Soy Candle - Winter - Christmas - 100% Natural Soy Wax - Nontoxic- Clean -Phthalate Free - Holiday Gift - Free Shipping")




Add to Favorites


- [![Original Collection - 100% Natural Soy Wax Candles, Wax Melts, Car Diffusers, Room Spray, 10ML Oil - NonToxic - Phthalate Free - SCENTS P-Z](https://i.etsystatic.com/11861778/c/2419/1921/385/859/il/0cb118/5083493814/il_340x270.5083493814_3w07.jpg)\\
\\
**Original Collection - 100% Natural Soy Wax Candles, Wax Melts, Car Diffusers, Room Spray, 10ML Oil - NonToxic - Phthalate Free - SCENTS P-Z**\\
\\
$10.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1297896360/original-collection-100-natural-soy-wax?click_key=ca42824c30b0ae05ae6255b985aed71b%3ALT322c4b8d05a0d6f416035dfa5edb3c8fe77c5442&click_sum=19cda000&ls=r&ref=related-3&content_source=ca42824c30b0ae05ae6255b985aed71b%253ALT322c4b8d05a0d6f416035dfa5edb3c8fe77c5442 "Original Collection - 100% Natural Soy Wax Candles, Wax Melts, Car Diffusers, Room Spray, 10ML Oil - NonToxic - Phthalate Free - SCENTS P-Z")




Add to Favorites


- [![100% Pure Beeswax Celebration Candles - Happy Birthday, Anniversary, New Year, Party - Natural Botanicals & Mica - Number Candles for cake](https://i.etsystatic.com/11861778/r/il/34eb09/5923007204/il_340x270.5923007204_qx2r.jpg)\\
\\
**100% Pure Beeswax Celebration Candles - Happy Birthday, Anniversary, New Year, Party - Natural Botanicals & Mica - Number Candles for cake**\\
\\
$6.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/564858082/100-pure-beeswax-celebration-candles?click_key=ca42824c30b0ae05ae6255b985aed71b%3ALTba782f032de34f08c1d01ace5f185fc324f79d0b&click_sum=916c7e5d&ls=r&ref=related-4&content_source=ca42824c30b0ae05ae6255b985aed71b%253ALTba782f032de34f08c1d01ace5f185fc324f79d0b "100% Pure Beeswax Celebration Candles - Happy Birthday, Anniversary, New Year, Party - Natural Botanicals & Mica - Number Candles for cake")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 5, 2025


[5 favorites](https://www.etsy.com/listing/1806238156/holiday-soy-candle-in-gold-mercury-glass/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=1fe04fd2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=1fe04fd2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=1fe04fd2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=1fe04fd2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&explicit=1&ref=breadcrumb_listing)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1806238156%2Fholiday-soy-candle-in-gold-mercury-glass%3Famp%253Bclick_sum%3D1fe04fd2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgyMzE3OToxMjk4ZGE3YzQyMzAwYzNjOTAxNTU1ZjI2ODU0NmVlMw==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1806238156%2Fholiday-soy-candle-in-gold-mercury-glass%3Famp%253Bclick_sum%3D1fe04fd2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1806238156/holiday-soy-candle-in-gold-mercury-glass?amp;click_sum=1fe04fd2&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1806238156%2Fholiday-soy-candle-in-gold-mercury-glass%3Famp%253Bclick_sum%3D1fe04fd2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for EarthTonix

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 2 days of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom