[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?amp;click_sum=3b1096f4&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;pro=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=3b1096f4&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=3b1096f4&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=3b1096f4&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=3b1096f4&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&explicit=1&ref=catnav_breadcrumb-3)
- [Container Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/container-candles?amp%3Bclick_sum=3b1096f4&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&explicit=1&ref=catnav_breadcrumb-4)

Bestseller

This item has had a high sales volume over the past 6 months.



Add to Favorites


- ![May include: Four glass mason jars with silver lids filled with white soy candles. The labels on the jars read 'Balsam Fir', 'Coffee House', 'Vanilla Bourbon', and 'Vanilla'. All labels have the text 'Mason Jar Candles & Co' and '100% Soy Candle' with the website address 'www.masonjarcandlesco.com'.](https://i.etsystatic.com/14701240/r/il/ae1209/3734218632/il_794xN.3734218632_ciq1.jpg)
- ![May include: Four glass mason jars with black labels and white lids. The labels have the text 'MASON JAR CANDLES & CO.' and the scent names 'BLUE SPRUCE', 'PEPPERMINT', 'BASIL LIME', and 'SEASIDE BREEZE'. Each label also includes the text '100% SOY CANDLE' and the website address 'www.masonjarcandlesco.com'. The jars are arranged in two rows of two, with the top row slightly offset from the bottom row.](https://i.etsystatic.com/14701240/r/il/49ca05/3734216962/il_794xN.3734216962_hq82.jpg)
- ![May include: Four glass mason jars with black labels and silver lids. The labels have the text 'MASON JAR CANDLES & CO.' and the scent of each candle: 'CINNAMON', 'LEMONGRASS', 'LAVENDER', and 'VANILLA'. The candles are arranged on a black metal shelf.](https://i.etsystatic.com/14701240/r/il/8d4eed/3890221226/il_794xN.3890221226_3g10.jpg)

- ![May include: Four glass mason jars with silver lids filled with white soy candles. The labels on the jars read 'Balsam Fir', 'Coffee House', 'Vanilla Bourbon', and 'Vanilla'. All labels have the text 'Mason Jar Candles & Co' and '100% Soy Candle' with the website address 'www.masonjarcandlesco.com'.](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_75x75.3734218632_ciq1.jpg)
- ![May include: Four glass mason jars with black labels and white lids. The labels have the text 'MASON JAR CANDLES & CO.' and the scent names 'BLUE SPRUCE', 'PEPPERMINT', 'BASIL LIME', and 'SEASIDE BREEZE'. Each label also includes the text '100% SOY CANDLE' and the website address 'www.masonjarcandlesco.com'. The jars are arranged in two rows of two, with the top row slightly offset from the bottom row.](https://i.etsystatic.com/14701240/r/il/49ca05/3734216962/il_75x75.3734216962_hq82.jpg)
- ![May include: Four glass mason jars with black labels and silver lids. The labels have the text 'MASON JAR CANDLES & CO.' and the scent of each candle: 'CINNAMON', 'LEMONGRASS', 'LAVENDER', and 'VANILLA'. The candles are arranged on a black metal shelf.](https://i.etsystatic.com/14701240/r/il/8d4eed/3890221226/il_75x75.3890221226_3g10.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F662956492%2Fpick-4-16-oz-100-soy-candles-free%23report-overlay-trigger)

In 13 carts

NowPrice:$44.09


Original Price:
$48.99


Loading


10% off


•

Sale ends on November 30


# Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents

Designed by [MasonJarCandlesCo](https://www.etsy.com/shop/MasonJarCandlesCo)

[5 out of 5 stars](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?amp;click_sum=3b1096f4&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;pro=1#reviews)

Arrives soon! Get it by

Nov 14-19


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Scent


Select an option

Almond Biscotti

Amish Bakery

Apple Cinnamon

Apple Orchard

Autumn Flannel

Baby Powder

Balsam Cedarwood

Balsam Fir

Birthday Cake

Black Amber Lavender

Blue Spruce

Campfire

Cashmere Cedar

Chocolate

Chocolate Mint

Cinnamon

Cinnamon Vanilla

Clean Cotton

Coconut Suntan

Coffee House

Cookies For Santa

Earthwood Mahogany

Fresh Bouquet

Fresh Strawberry

Fruity Loops

Georgia Peach

Happy Holidays

Holiday Gingerbread

Honeysuckle Jasmine

Jingle Bell Punch

Lavender

Lavender Sandalwood

Leaves Be Falling

Lemongrass

Lemon Pound Cake

Lemon Verbena

Mountain Serenade

Nag Champa

Oatmeal Milk & Honey

Patchouli

Peppermint

Peppermint Vanilla

Pine Barrens

Pumpkin Gingerbread

Pumpkin Marshmallow

Pumpkin Spice Cafe

Rose Garden

Salted Caramel

Sandalwood Vanilla

Santas Knutz

Under The Mistletoe

Vanilla

Vanilla Bourbon

Vanilla Buttercream

Vanilla Woods

Winter Fairy

Please select an option


Add personalization
(optional)

- Personalization





If you would like more then one scent, list scent choices here.


















0/256


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Designed by [MasonJarCandlesCo](https://www.etsy.com/shop/MasonJarCandlesCo)

- Materials: Wax type: Soy


Choose up to 4 scents. List scent choices on personalization line.

Mason Jar Candles and Co. 16 oz, 4 pack soy candles are hand poured from 100% soy wax. Our scented soy candles have no additional additives. As the customer, you are getting exactly what you bought. We offer personalized candles that make the perfect custom candle.

Pick 4, 16 oz candles for 48.99. FREE SHIPPING! Choose your scents and message your choices. Orders shipped in 3 to 5 days.

WICKS should be kept trimmed between burnings to 1/8 to 1/4 inch

All of our fragrances are Phthalate free! Phthalates are additives that add flexibility to plastic, so why on Earth would you want them burning in your home? At Mason Jar Candles & Co. you do not have to worry about that!

Each of our mason jar candles is homemade in small batches so that they are given the proper care they deserve. Each fragrance oil comes from one of the best companies in the business because we care about our customers and the products they receive.

Our soy candles are poured with the same ideals that our parents instilled in us from a young age. If you want people to think of you like the best, then you must be the best and at Mason Jar Candles & Co. we know this to be true.

The burn time for each of our soy candles is listed below. Many candle companies give the longest burn time that has been tested. We give the time on the lower end of our results. Longer burn times is just another bonus of soy wax candles.

16 oz candle burn time is approximately ~75 hours.

If you would like a large quantity or would like to customize your order for a special event send us an email at alex \[!at\] masonjarcandlesco.com! We would love to help out with your special day, quantity or would like to customize your order for a special event send us an email at alex \[!at\] masonjarcandlesco.com! We would love to help out with your special day!


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-19**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges not accepted




But please contact me if you have problems with your order


- Free shipping


- Ships from: **Myrtle Beach, SC**


Deliver to United States

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (272)

4.8/5

item average

4.9Item quality

5.0Shipping

4.9Customer service

97%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Smells amazing

Fast shipping

Love it

Great product

Would recommend

Great quality

Well packaged


Filter by category


Quality (159)


Shipping & Packaging (77)


Appearance (31)


Seller service (25)


Value (21)


Description accuracy (14)


Sizing & Fit (3)


Ease of use (2)


Comfort (1)


Condition (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Lauri](https://www.etsy.com/people/fyzfayvr?ref=l_review)
Nov 10, 2025


These are great candles. I have ordered these many times. They smell wonderful and last a long time. They are well packaged also.



[Lauri](https://www.etsy.com/people/fyzfayvr?ref=l_review)
Nov 10, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/56dada/107354199/iusa_75x75.107354199_eu7w.jpg?version=0)

[Stacy Brown](https://www.etsy.com/people/8r5hbc4nej6b0t4g?ref=l_review)
Nov 4, 2025


Very strong intent my son and daughter absolutely loved them. I gave them as a gift and they were perfect. Arrived on time and I would definitely recommend.



![](https://i.etsystatic.com/iusa/56dada/107354199/iusa_75x75.107354199_eu7w.jpg?version=0)

[Stacy Brown](https://www.etsy.com/people/8r5hbc4nej6b0t4g?ref=l_review)
Nov 4, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/d9b909/102651429/iusa_75x75.102651429_qk8s.jpg?version=0)

[Lauri Rapko](https://www.etsy.com/people/b5yxsjoy?ref=l_review)
Nov 4, 2025


Always a pleasure to do business with this vendor.



![](https://i.etsystatic.com/iusa/d9b909/102651429/iusa_75x75.102651429_qk8s.jpg?version=0)

[Lauri Rapko](https://www.etsy.com/people/b5yxsjoy?ref=l_review)
Nov 4, 2025


5 out of 5 stars
5

This item

[Kayla Addington](https://www.etsy.com/people/kaylamccall2?ref=l_review)
Oct 30, 2025


Smells so good! Great gifts!



[Kayla Addington](https://www.etsy.com/people/kaylamccall2?ref=l_review)
Oct 30, 2025


View all reviews for this item

### Photos from reviews

![Kaelie added a photo of their purchase](https://i.etsystatic.com/iap/720532/6996584691/iap_300x300.6996584691_cw4l7mc4.jpg?version=0)

![Ashley added a photo of their purchase](https://i.etsystatic.com/iap/6b2eb2/6439599029/iap_300x300.6439599029_dyddldh2.jpg?version=0)

![Diane added a photo of their purchase](https://i.etsystatic.com/iap/79d8b1/4464787448/iap_300x300.4464787448_1yllzwwu.jpg?version=0)

![Daling added a photo of their purchase](https://i.etsystatic.com/iap/708aab/6060290756/iap_300x300.6060290756_5chqhtpu.jpg?version=0)

![Holly added a photo of their purchase](https://i.etsystatic.com/iap/113519/5765970479/iap_300x300.5765970479_qv4y16e4.jpg?version=0)

![Brooke added a photo of their purchase](https://i.etsystatic.com/iap/ce9f34/6416524496/iap_300x300.6416524496_j9srdtoa.jpg?version=0)

![Virginia added a photo of their purchase](https://i.etsystatic.com/iap/8e04ab/5733702318/iap_300x300.5733702318_d3t5lrrn.jpg?version=0)

![Kaelie added a photo of their purchase](https://i.etsystatic.com/iap/a027f7/7062837445/iap_300x300.7062837445_4a6kathu.jpg?version=0)

![Nia added a photo of their purchase](https://i.etsystatic.com/iap/02f93a/6799533445/iap_300x300.6799533445_kcb53nw8.jpg?version=0)

![linajamero1 added a photo of their purchase](https://i.etsystatic.com/iap/a7a6a0/6966287168/iap_300x300.6966287168_a17br7dr.jpg?version=0)

![Jessica added a photo of their purchase](https://i.etsystatic.com/iap/6dca83/6243411471/iap_300x300.6243411471_ikumpfbw.jpg?version=0)

![Alicia added a photo of their purchase](https://i.etsystatic.com/iap/1328e6/5877291845/iap_300x300.5877291845_ij76q8do.jpg?version=0)

![Marie added a photo of their purchase](https://i.etsystatic.com/iap/fddd97/5939174822/iap_300x300.5939174822_hkhtgkse.jpg?version=0)

![Jerri added a photo of their purchase](https://i.etsystatic.com/iap/48c0ec/7254080557/iap_300x300.7254080557_sf2hwykr.jpg?version=0)

![Jerri added a photo of their purchase](https://i.etsystatic.com/iap/e9e6db/7252646005/iap_300x300.7252646005_stf6f3sv.jpg?version=0)

![Josephine added a photo of their purchase](https://i.etsystatic.com/iap/64561a/6286241641/iap_300x300.6286241641_8f2ba0za.jpg?version=0)

![Alayna added a photo of their purchase](https://i.etsystatic.com/iap/3eb998/6264442446/iap_300x300.6264442446_tk4lvqs8.jpg?version=0)

![Inactive user added a photo of their purchase](https://i.etsystatic.com/iap/867db3/5744398405/iap_300x300.5744398405_77hctcc6.jpg?version=0)

![Daling added a photo of their purchase](https://i.etsystatic.com/iap/b5e530/6111262179/iap_300x300.6111262179_eengxjn7.jpg?version=0)

![Elissa added a photo of their purchase](https://i.etsystatic.com/iap/d9b663/3318932490/iap_300x300.3318932490_9h4fbawk.jpg?version=0)

[![MasonJarCandlesCo](https://i.etsystatic.com/iusa/2dece7/101740744/iusa_75x75.101740744_bbti.jpg?version=0)](https://www.etsy.com/shop/MasonJarCandlesCo?ref=shop_profile&listing_id=662956492)

[MasonJarCandlesCo](https://www.etsy.com/shop/MasonJarCandlesCo?ref=shop_profile&listing_id=662956492)

[Owned by Bob](https://www.etsy.com/shop/MasonJarCandlesCo?ref=shop_profile&listing_id=662956492) \|

United States

4.8
(5.6k)


24.9k sales

8 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=104408874&referring_id=662956492&referring_type=listing&recipient_id=104408874&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoxMDQ0MDg4NzQ6MTc2MjgyMzAxMzoyMGQ2YTUyZDVkODU2YzkzYTAyMmNjMWMyZjM2MmRlYg%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F662956492%2Fpick-4-16-oz-100-soy-candles-free%3Famp%253Bclick_sum%3D3b1096f4%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bpro%3D1)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/MasonJarCandlesCo?ref=lp_mys_mfts)

- [![Pick 4, 8 oz, 100% Soy Candles | Free Shipping | 34.99 | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/3000/2250/0/0/il/2318ed/4314053668/il_340x270.4314053668_5ozf.jpg)\\
\\
**Pick 4, 8 oz, 100% Soy Candles \| Free Shipping \| 34.99 \| Choose up to 4 Scents**\\
\\
Sale Price $31.49\\
$31.49\\
\\
$34.99\\
Original Price $34.99\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1325187274/pick-4-8-oz-100-soy-candles-free?click_key=cad66a533bec9809811b8b99a1e4c2c0%3ALT54d9e176b2ebc5519eacabd3e3209ed3bd66f5da&click_sum=fe9cc5ee&ls=r&ref=related-1&pro=1&content_source=cad66a533bec9809811b8b99a1e4c2c0%253ALT54d9e176b2ebc5519eacabd3e3209ed3bd66f5da "Pick 4, 8 oz, 100% Soy Candles | Free Shipping | 34.99 | Choose up to 4 Scents")




Add to Favorites


- [![Fall Candle/Winter Candle | Soy Candle | Custom Candle | Scented Soy Candles | Wax Melts](https://i.etsystatic.com/14701240/c/3000/2021/0/0/il/3a1eab/3675098616/il_340x270.3675098616_piec.jpg)\\
\\
**Fall Candle/Winter Candle \| Soy Candle \| Custom Candle \| Scented Soy Candles \| Wax Melts**\\
\\
$3.50\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/554557183/fall-candlewinter-candle-soy-candle?click_key=cad66a533bec9809811b8b99a1e4c2c0%3ALTca2bb550ae21ff47b210eeec31ee87ed796d51fb&click_sum=e5a93b80&ls=r&ref=related-2&content_source=cad66a533bec9809811b8b99a1e4c2c0%253ALTca2bb550ae21ff47b210eeec31ee87ed796d51fb "Fall Candle/Winter Candle | Soy Candle | Custom Candle | Scented Soy Candles | Wax Melts")




Add to Favorites


- [![Peppermint Candle | Christmas Candle | Mint Candle | Wax Melt | Soy Candle](https://i.etsystatic.com/14701240/r/il/c82ddc/3706437882/il_340x270.3706437882_fhe4.jpg)\\
\\
**Peppermint Candle \| Christmas Candle \| Mint Candle \| Wax Melt \| Soy Candle**\\
\\
$3.50\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/527465888/peppermint-candle-christmas-candle-mint?click_key=cad66a533bec9809811b8b99a1e4c2c0%3ALTbca74dff7e9fdfa6ebd673fb9a819b74cb2da3f2&click_sum=c9bc148b&ls=r&ref=related-3&content_source=cad66a533bec9809811b8b99a1e4c2c0%253ALTbca74dff7e9fdfa6ebd673fb9a819b74cb2da3f2 "Peppermint Candle | Christmas Candle | Mint Candle | Wax Melt | Soy Candle")




Add to Favorites


- [![Rose Garden | Soy Candles | Valentine&#39;s Candles | Wax Melt | Summer Candle | Rose Candle](https://i.etsystatic.com/14701240/r/il/27f167/3706466728/il_340x270.3706466728_hhor.jpg)\\
\\
**Rose Garden \| Soy Candles \| Valentine's Candles \| Wax Melt \| Summer Candle \| Rose Candle**\\
\\
$3.50\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/767592979/rose-garden-soy-candles-valentines?click_key=36b81a609ed42ce65b1cc047f5a4f0861c1c1a98%3A767592979&click_sum=515ed080&ref=related-4 "Rose Garden | Soy Candles | Valentine's Candles | Wax Melt | Summer Candle | Rose Candle")




Add to Favorites



Loading...

Loading


**Disclaimer:** Button/coin batteries may cause serious injury and even death if swallowed. Items containing button/coin batteries should not be easily accessible without the use of a tool. Sellers are responsible for complying with all applicable labeling, design, testing, packaging, and other safety requirements. Etsy assumes no responsibility for the accuracy or contents of a seller’s listing. If you have questions about button/coin batteries, contact the seller by sending a Message. See Etsy's [Terms of Use](https://www.etsy.com/legal/terms-of-use/?ref=product_safety_banner_info_button_batteries_risk#warranties) for more information.

Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 10, 2025


[525 favorites](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=3b1096f4&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=3b1096f4&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=3b1096f4&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=3b1096f4&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&explicit=1&ref=breadcrumb_listing) [Container Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/container-candles?amp%3Bclick_sum=3b1096f4&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Home Decor

[God's Medium Rose Tile Mural Painting Back Splash Kitchen Home Decor Art - Home Decor](https://www.etsy.com/listing/260906536/gods-medium-rose-tile-mural-painting) [Shop Panoramic Film Print](https://www.etsy.com/market/panoramic_film_print) [Night Sky - Home Decor](https://www.etsy.com/listing/1010121373/night-sky-cloud-15x12x10-led-lights) [Coconut Orange Pineapple Citrus by Eartherella](https://www.etsy.com/listing/4331283620/blue-hawaiian-wax-melts-tarts-coconut) [Little Birdy Free Standing Lace Ornament - Home Decor](https://www.etsy.com/listing/900023578/little-birdy-free-standing-lace-ornament) [Apache Indian Symbols - US](https://www.etsy.com/market/apache_indian_symbols) [Georgia Map Print](https://www.etsy.com/listing/1185674409/georgia-map-print-map-art-the-peach) [Blessed Kaabah Covering Black Cloth](https://www.etsy.com/listing/1361727161/islam-relic-decor-blessed-kaabah) [And into the forest I go to lose my mind and find my soul. Custom Hand Painted Slice Wood. Wood sign. Wood slice Art - Home Decor](https://www.etsy.com/listing/1698450470/and-into-the-forest-i-go-to-lose-my-mind) [1998 Miami Dolphins (NHL) Hallmark Keepsake Christmas Tree Ornament (QSR5096) NIB New in Box](https://www.etsy.com/listing/1877838097/1998-miami-dolphins-nhl-hallmark) [Shop San Jose Road Map](https://www.etsy.com/market/san_jose_road_map)

Rings

[Pear Moissanite Engagement Ring with Hidden Halo & Pave Band 14K White Gold Wedding Ring Pear Shape Ring Promise Ring](https://www.etsy.com/listing/1011898565/pear-moissanite-engagement-ring-with)

Shopping

[Shop Instant Download Boarding Pass](https://www.etsy.com/market/instant_download_boarding_pass)

Earrings

[Handmade Beaded Jewelry by SimpleeAdorned](https://www.etsy.com/listing/715681346/handmade-beaded-jewelry-handmade-dangle)

Electronics Cases

[African Glamourous Black Woman Art Tough Case for iPhone® - Electronics Cases](https://www.etsy.com/listing/1803234194/african-glamourous-black-woman-art-tough)

Fragrances

[Twinscents for Sale](https://www.etsy.com/market/twinscents)

Sculpture

[Buy Alexander Daniel Sculpture Online](https://www.etsy.com/market/alexander_daniel_sculpture)

Necklaces

[Copper Pentacle - US](https://www.etsy.com/market/copper_pentacle)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F662956492%2Fpick-4-16-oz-100-soy-candles-free%3Famp%253Bclick_sum%3D3b1096f4%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bpro%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgyMzAxMzo2Mjk5ZDcwMjA1OWNmMDc3MDQ0M2UwNWIxZTY1MjZhYg==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F662956492%2Fpick-4-16-oz-100-soy-candles-free%3Famp%253Bclick_sum%3D3b1096f4%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bpro%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?amp;click_sum=3b1096f4&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;pro=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F662956492%2Fpick-4-16-oz-100-soy-candles-free%3Famp%253Bclick_sum%3D3b1096f4%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bpro%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for MasonJarCandlesCo

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: not accepted

Please contact the seller if you have any problems with your order.

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## Seller details

### Other details

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=104408874&referring_id=14701240&referring_type=shop&recipient_id=104408874&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: Four glass mason jars with silver lids filled with white soy candles. The labels on the jars read 'Balsam Fir', 'Coffee House', 'Vanilla Bourbon', and 'Vanilla'. All labels have the text 'Mason Jar Candles & Co' and '100% Soy Candle' with the website address 'www.masonjarcandlesco.com'.](https://i.etsystatic.com/14701240/c/1440/1440/0/0/il/ae1209/3734218632/il_300x300.3734218632_ciq1.jpg)
- ![May include: Four glass mason jars with black labels and white lids. The labels have the text 'MASON JAR CANDLES & CO.' and the scent names 'BLUE SPRUCE', 'PEPPERMINT', 'BASIL LIME', and 'SEASIDE BREEZE'. Each label also includes the text '100% SOY CANDLE' and the website address 'www.masonjarcandlesco.com'. The jars are arranged in two rows of two, with the top row slightly offset from the bottom row.](https://i.etsystatic.com/14701240/r/il/49ca05/3734216962/il_300x300.3734216962_hq82.jpg)
- ![May include: Four glass mason jars with black labels and silver lids. The labels have the text 'MASON JAR CANDLES & CO.' and the scent of each candle: 'CINNAMON', 'LEMONGRASS', 'LAVENDER', and 'VANILLA'. The candles are arranged on a black metal shelf.](https://i.etsystatic.com/14701240/r/il/8d4eed/3890221226/il_300x300.3890221226_3g10.jpg)

- ![](https://i.etsystatic.com/iap/720532/6996584691/iap_640x640.6996584691_cw4l7mc4.jpg?version=0)

5 out of 5 stars

- Scent:

Clean Cotton


I love these candles - they are huge, strongly scented, and perfect for rooms that need the air refreshed! The price of these was phenomenal too and they were packaged safely arriving with no damage. I am very happy with these and will be back for more in the future! Awesome price for high-quality candles

![](https://i.etsystatic.com/iusa/bdea0d/83391281/iusa_75x75.83391281_k91q.jpg?version=0)

Jun 17, 2025


[Kaelie C](https://www.etsy.com/people/kconnors88)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/6b2eb2/6439599029/iap_640x640.6439599029_dyddldh2.jpg?version=0)

5 out of 5 stars

- Scent:

Lavender Sandalwood


These are the best candles ever!! I’ve never had a candle burn so clean and even as these ones do (just be sure to trim the wick as instructed). There is no wondering what the scent is as they are exactly what you would expect and there isn’t a lack of scent either, they’re just so perfectly balanced. Finally, knowing that this is a small, family owned business just tops it all off for me. I loved reading their story and how passionate they are about their product.

![](https://i.etsystatic.com/iusa/c076f3/97518967/iusa_75x75.97518967_a8mb.jpg?version=0)

Oct 30, 2024


[Ashley](https://www.etsy.com/people/ashleym1427)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/79d8b1/4464787448/iap_640x640.4464787448_1yllzwwu.jpg?version=0)

5 out of 5 stars

- Scent:

Vanilla Buttercream


THESE ARE THE BEST CANDLES!! This is my 2nd order!! Great scent, long burn!!! Will definitely be ordering again!!!!!

Dec 27, 2022


[Diane](https://www.etsy.com/people/dwenzel0803)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/708aab/6060290756/iap_640x640.6060290756_5chqhtpu.jpg?version=0)

5 out of 5 stars

- Scent:

Rose Garden


10/10!! Above and Beyond Expectations!! Highly Recommended!! Purchased 2 Different Scents of the 4 pack and They Both Smell Wonderful!!! Thank you very much for all your Amazing Hard Work! Y’all have a Beautiful Blessed Day and I’ll be Back. 🙏🌷🌺💐🌹🥀🥰

![](https://i.etsystatic.com/iusa/3373bf/88691368/iusa_75x75.88691368_r2vq.jpg?version=0)

Jun 14, 2024


[Daling Mafnas](https://www.etsy.com/people/simafnasd)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/113519/5765970479/iap_640x640.5765970479_qv4y16e4.jpg?version=0)

5 out of 5 stars

- Scent:

Coconut Paradise


I have burnt 1 candle for almost 8 hours 3 days in a row and it’s only 1/2 burnt down! Amazing! I will never buy candles anywhere else! Smells amazing and lasts a long time. Thank you for making such great quality candles!

Jan 29, 2024


[Holly](https://www.etsy.com/people/s493m8u1tfjsvli1)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/ce9f34/6416524496/iap_640x640.6416524496_j9srdtoa.jpg?version=0)

5 out of 5 stars

- Scent:

Vanilla Pumpkin Pie


The scents are amazing. I will be ordering more!

![](https://i.etsystatic.com/iusa/391bf4/22214902/iusa_75x75.22214902_c6gl.jpg?version=0)

Nov 9, 2024


[Brooke Kruzner](https://www.etsy.com/people/brookelindeman)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/8e04ab/5733702318/iap_640x640.5733702318_d3t5lrrn.jpg?version=0)

5 out of 5 stars

- Scent:

Oatmeal Milk & Honey


I love that these candles are 100 percent soy!! The fragrance is subtle but clean! They burn clean for a long time. I am editing my review to give 5 stars as I have experienced clean burning every night but you have to trim the wick each time you burn the candle. These candles are the cleanest burning, best smelling candles I’ve ever purchased!!!!Maybe I will try the wood wicks when they are back in stock!!!!

Feb 4, 2024


[Virginia](https://www.etsy.com/people/gpbj2384)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/a027f7/7062837445/iap_640x640.7062837445_4a6kathu.jpg?version=0)

5 out of 5 stars

- Scent:

Seaside Breeze


I am very happy with this bundle of candles from this shop - great price and the scent lasts a long time. I put them in my bathroom and they do a wonderful job - the scent carries throughout the house. I will be ordering more in the future when the ones I have currently are all burned up. All of them arrived safely without damage in shipping - I appreciate the time and effort the seller put into packaging them so they arrived that way, thank you! 😊

![](https://i.etsystatic.com/iusa/bdea0d/83391281/iusa_75x75.83391281_k91q.jpg?version=0)

Jul 12, 2025


[Kaelie C](https://www.etsy.com/people/kconnors88)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/02f93a/6799533445/iap_640x640.6799533445_kcb53nw8.jpg?version=0)

5 out of 5 stars

- Scent:

Earthwood Mahogany


Brought these candles as a gift for a friend. She absolutely loved them. Great size as well! Excellent communication with the seller. Will be ordering more candles again!

Mar 28, 2025


[Nia Daniels](https://www.etsy.com/people/fsiawrrc)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/a7a6a0/6966287168/iap_640x640.6966287168_a17br7dr.jpg?version=0)

4 out of 5 stars

- Scent:

Vanilla Buttercream


As described. Smells good. It took a while to get here. The candles were wrapped nicely.

![](https://i.etsystatic.com/iusa/ab4be0/111830572/iusa_75x75.111830572_4eyl.jpg?version=0)

Jun 24, 2025


[linajamero1](https://www.etsy.com/people/linajamero1)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/6dca83/6243411471/iap_640x640.6243411471_ikumpfbw.jpg?version=0)

5 out of 5 stars

- Scent:

Pumpkin Chai


Great candles! I love them and will definitely be restocking from this store front.

I purchased pumpkin chia and it smells amazing!

![](https://i.etsystatic.com/iusa/2bc09c/109125996/iusa_75x75.109125996_g404.jpg?version=0)

Aug 13, 2024


[Jessica Licha](https://www.etsy.com/people/jessicalicha1)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/1328e6/5877291845/iap_640x640.5877291845_ij76q8do.jpg?version=0)

5 out of 5 stars

- Scent:

Black Amber Lavender


My only candles! So good!

![](https://i.etsystatic.com/iusa/c7ecc9/36808007/iusa_75x75.36808007_393k.jpg?version=0)

Mar 9, 2024


[Alicia Newholm](https://www.etsy.com/people/anewholm)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/fddd97/5939174822/iap_640x640.5939174822_hkhtgkse.jpg?version=0)

5 out of 5 stars

- Scent:

Apple Cinnamon


Awesome candles! I used to buy candles from a store in the mall, and I used to make gel candles, so I figure I know a thing about using proper wicks, etc. But no more!

Apr 22, 2024


[Marie Lippman](https://www.etsy.com/people/loeqynqa)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/48c0ec/7254080557/iap_640x640.7254080557_sf2hwykr.jpg?version=0)

5 out of 5 stars

- Scent:

Georgia Peach


All good, smells great. Fast shipping

Sep 17, 2025


[Jerri](https://www.etsy.com/people/0nt0hcrlxzzih7kf)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/e9e6db/7252646005/iap_640x640.7252646005_stf6f3sv.jpg?version=0)

5 out of 5 stars

- Scent:

Lavender


Smell great, fast shipping, very pleased

Sep 16, 2025


[Jerri](https://www.etsy.com/people/0nt0hcrlxzzih7kf)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/64561a/6286241641/iap_640x640.6286241641_8f2ba0za.jpg?version=0)

5 out of 5 stars

- Scent:

Black Amber Lavender


Came very fast and sooner than expected! They smell lovely and we definitely will be buying again!

![](https://i.etsystatic.com/iusa/7635b1/104718045/iusa_75x75.104718045_e1cq.jpg?version=0)

Aug 31, 2024


[Josephine](https://www.etsy.com/people/josephinepetty2)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/3eb998/6264442446/iap_640x640.6264442446_tk4lvqs8.jpg?version=0)

5 out of 5 stars

- Scent:

Apple Orchard


Super nice candles! I normally get headaches from candles and thought I'd give these a shot- they burn nicely and smell great! They also arrived faster than expected.

![](https://i.etsystatic.com/iusa/e2ea42/89382262/iusa_75x75.89382262_2tae.jpg?version=0)

Sep 10, 2024


[Alayna](https://www.etsy.com/people/vtzqmut6)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/867db3/5744398405/iap_640x640.5744398405_77hctcc6.jpg?version=0)

5 out of 5 stars

- Scent:

Lavender


Fantastic!!! The fragrance is PERFECT!!! Not too strong, not too subtle and it burns clean. Simple elegance in presentation (I like a simple label and no wax dye). Best value on Etsy for candles!!!

Jan 22, 2024


Reviewed by Inactive


Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/b5e530/6111262179/iap_640x640.6111262179_eengxjn7.jpg?version=0)

5 out of 5 stars

- Scent:

Amish Bakery


10/10!!! Above and Beyond Expectations!!! Highly Recommended!!! Thank you and your Family for all your Amazing Hard Work! Now I know where to Get My Candles! These Candles are Beautiful with Wonderful Scents. I’ll be back for more of your Beautiful Candles! Again, Thank you and your Beautiful Family for Bringing Us All These Beautiful Candles! Y’all Have a Beautiful Blessed Day! HAPPY FATHER’S DAY!!! 🙏🙏🙏💐🌺🌷🌹🥀🥰

![](https://i.etsystatic.com/iusa/3373bf/88691368/iusa_75x75.88691368_r2vq.jpg?version=0)

Jun 16, 2024


[Daling Mafnas](https://www.etsy.com/people/simafnasd)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/d9b663/3318932490/iap_640x640.3318932490_9h4fbawk.jpg?version=0)

5 out of 5 stars

- Scent:

Vanilla Bourbon


Sep 9, 2021


[Elissa Maynes](https://www.etsy.com/people/elissaemily)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)

Purchased item:

[![Pick 4, 16 oz, 100% Soy Candles | Free Shipping | Choose up to 4 Scents](https://i.etsystatic.com/14701240/c/1440/1144/0/147/il/ae1209/3734218632/il_170x135.3734218632_ciq1.jpg)\\
\\
Pick 4, 16 oz, 100% Soy Candles \| Free Shipping \| Choose up to 4 Scents\\
\\
Sale Price $44.09\\
$44.09\\
\\
$48.99\\
Original Price $48.99\\
\\
\\
(10% off)](https://www.etsy.com/listing/662956492/pick-4-16-oz-100-soy-candles-free?ref=ap-listing)