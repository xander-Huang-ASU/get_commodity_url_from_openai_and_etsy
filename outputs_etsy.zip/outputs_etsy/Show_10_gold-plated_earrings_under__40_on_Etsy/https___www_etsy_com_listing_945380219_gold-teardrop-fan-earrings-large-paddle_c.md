[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/945380219/gold-teardrop-fan-earrings-large-paddle?amp;click_sum=5dbc91bc&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;sts=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Jewelry](https://www.etsy.com/c/jewelry?amp%3Bclick_sum=5dbc91bc&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-0)
- [Earrings](https://www.etsy.com/c/jewelry/earrings?amp%3Bclick_sum=5dbc91bc&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-1)
- [Dangle & Drop Earrings](https://www.etsy.com/c/jewelry/earrings/dangle-earrings?amp%3Bclick_sum=5dbc91bc&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-2)

Sorry, this item is sold out

![](https://i.etsystatic.com/5570970/c/3000/2384/0/192/il/8d5fe6/2853419703/il_680x540.2853419703_cse7.jpg)

Sorry, this item is sold out

[TheBeadCounter](https://www.etsy.com/shop/TheBeadCounter?ref=nla_listing_details)5 out of 5 stars(5,700)5,700 reviews

Gold Teardrop Fan Earrings – Large Paddle Fringe Earrings, Boho Statement Jewelry for Women, Unique Bohemian Gift, Stylish Fashion Accessory


Sold

Let me know when it's back

Loading


Hmm. Something went wrong. Try again?

We'll let the shop know you'd like this to come back, and email you as soon as it does.

[See item details](https://www.etsy.com/listing/945380219/gold-teardrop-fan-earrings-large-paddle?show_sold_out_detail=1)

Let me know when it's back

Loading


Hmm. Something went wrong. Try again?

We'll let the shop know you'd like this to come back, and email you as soon as it does.

[See item details](https://www.etsy.com/listing/945380219/gold-teardrop-fan-earrings-large-paddle?show_sold_out_detail=1)

### Similar items on Etsy

(Results include adsLearn more
Sellers looking to grow their business and reach more interested buyers can use Etsy’s advertising platform to promote their items. You’ll see ad results based on factors like relevancy, and the amount sellers pay per click. [Learn more](https://www.etsy.com/legal/policy/search-advertisement-ranking-disclosures/899478564529).
)

- [![Crystal Gold Fringe Dangle Earrings - Handmade Jewelry - Bride to Be Earrings - Aura Quartz Statement Earrings-Boho Earrings-Unique Earrings](https://i.etsystatic.com/6391254/c/1247/990/374/1158/il/a3053e/5728376407/il_340x270.5728376407_2011.jpg)\\
\\
**Crystal Gold Fringe Dangle Earrings - Handmade Jewelry - Bride to Be Earrings - Aura Quartz Statement Earrings-Boho Earrings-Unique Earrings**\\
\\
ad vertisement by FierceForwardJewelry\\
Advertisement from shop FierceForwardJewelry\\
FierceForwardJewelry\\
From shop FierceForwardJewelry\\
\\
$79.00\\
\\
FREE shipping](https://www.etsy.com/listing/1014231902/crystal-gold-fringe-dangle-earrings?click_key=LT4def72689340d7091ea2a1cd9a79c72050e17247%3A1014231902&click_sum=f17c21b3&ls=a&ref=sold_out_ad-1&frs=1&sts=1 "Crystal Gold Fringe Dangle Earrings - Handmade Jewelry - Bride to Be Earrings - Aura Quartz Statement Earrings-Boho Earrings-Unique Earrings")





Add to Favorites


- [![Hammered Teardrop Dangle Statement Earrings](https://i.etsystatic.com/8187406/r/il/db3156/4733504694/il_340x270.4733504694_2kjx.jpg)\\
\\
**Hammered Teardrop Dangle Statement Earrings**\\
\\
ad vertisement by LauraElizabethJewels\\
Advertisement from shop LauraElizabethJewels\\
LauraElizabethJewels\\
From shop LauraElizabethJewels\\
\\
$165.00\\
\\
FREE shipping](https://www.etsy.com/listing/1427387314/hammered-teardrop-dangle-statement?click_key=LT3dbdc93e42fc7ceacb480e2e671058b7c4fdaaa2%3A1427387314&click_sum=674cae82&ls=a&ref=sold_out_ad-2&frs=1 "Hammered Teardrop Dangle Statement Earrings")





Add to Favorites


- [![Long asymmetric statement earrings with natural Aragonite teardrops and brass leaves. 14k gold-filled ear wire.](https://i.etsystatic.com/37594620/r/il/ab0748/6803713042/il_340x270.6803713042_r06u.jpg)\\
\\
**Long asymmetric statement earrings with natural Aragonite teardrops and brass leaves. 14k gold-filled ear wire.**\\
\\
ad vertisement by KISTofTHEIA\\
Advertisement from shop KISTofTHEIA\\
KISTofTHEIA\\
From shop KISTofTHEIA\\
\\
Sale Price $36.72\\
$36.72\\
\\
$43.20\\
Original Price $43.20\\
\\
\\
(15% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1891346624/long-asymmetric-statement-earrings-with?click_key=LTbb7c3c2675caf1ca94c4c881ca6fa1bbe0ec5189%3A1891346624&click_sum=0ce4286c&ls=a&ref=sold_out_ad-3&pro=1&frs=1&sts=1 "Long asymmetric statement earrings with natural Aragonite teardrops and brass leaves. 14k gold-filled ear wire.")





Add to Favorites


- [![18k Gold Plated Fan Earrings, Asia Inspired Handmade Dangle Earrings](https://i.etsystatic.com/5195449/r/il/52ad95/7192659001/il_340x270.7192659001_jx7c.jpg)\\
\\
**18k Gold Plated Fan Earrings, Asia Inspired Handmade Dangle Earrings**\\
\\
ad vertisement by UrbanMoonJewelry\\
Advertisement from shop UrbanMoonJewelry\\
UrbanMoonJewelry\\
From shop UrbanMoonJewelry\\
\\
$24.00\\
\\
Free shipping eligible](https://www.etsy.com/listing/4358840513/18k-gold-plated-fan-earrings-asia?click_key=LT79bd7e8bda881f454fdad352fa9e4fee1dd5a4c7%3A4358840513&click_sum=ab4934a4&ls=a&ref=sold_out_ad-4&frs=1&sts=1 "18k Gold Plated Fan Earrings, Asia Inspired Handmade Dangle Earrings")





Add to Favorites


- [![14K Gold Teardrop Fringe Earrings | Handmade Yemenite Filigree Jewelry from Israel | Elegant Gold Dangle Earrings | Boho Chic Luxury Gift](https://i.etsystatic.com/31645189/r/il/b6d094/7152442017/il_340x270.7152442017_f92g.jpg)\\
\\
**14K Gold Teardrop Fringe Earrings \| Handmade Yemenite Filigree Jewelry from Israel \| Elegant Gold Dangle Earrings \| Boho Chic Luxury Gift**\\
\\
ad vertisement by UniqueIsraeliJewelry\\
Advertisement from shop UniqueIsraeliJewelry\\
UniqueIsraeliJewelry\\
From shop UniqueIsraeliJewelry\\
\\
Sale Price $1,205.06\\
$1,205.06\\
\\
$1,354.00\\
Original Price $1,354.00\\
\\
\\
(11% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/4351225485/14k-gold-teardrop-fringe-earrings?click_key=LT38f770da4856ac7bc2d72c62836654d45bb28ca1%3A4351225485&click_sum=92d0dd53&ls=a&ref=sold_out_ad-5&pro=1&frs=1 "14K Gold Teardrop Fringe Earrings | Handmade Yemenite Filigree Jewelry from Israel | Elegant Gold Dangle Earrings | Boho Chic Luxury Gift")





Add to Favorites


- [![Gold Teardrop &#39;Dew&#39; Elegant Beaten Brass Minimalist Earrings, Handmade in Cornwall, Plastic Free. Atrisan, Bridal, Ready to Gift.](https://i.etsystatic.com/22317127/r/il/d64e6a/5013783079/il_340x270.5013783079_3uvl.jpg)\\
\\
**Gold Teardrop 'Dew' Elegant Beaten Brass Minimalist Earrings, Handmade in Cornwall, Plastic Free. Atrisan, Bridal, Ready to Gift.**\\
\\
ad vertisement by NicDanning\\
Advertisement from shop NicDanning\\
NicDanning\\
From shop NicDanning\\
\\
$27.45](https://www.etsy.com/listing/1494255124/gold-teardrop-dew-elegant-beaten-brass?click_key=LT3ea7afac72c35939fd81298988ea4c72636413d8%3A1494255124&click_sum=2fbf001e&ls=a&ref=sold_out_ad-6 "Gold Teardrop 'Dew' Elegant Beaten Brass Minimalist Earrings, Handmade in Cornwall, Plastic Free. Atrisan, Bridal, Ready to Gift.")





Add to Favorites


- [![Gold Filigree Drop Delicate Earrings * Gold Dangle Earrings * Feminine * Oriental](https://i.etsystatic.com/12059162/r/il/51e2df/2056915640/il_340x270.2056915640_9fk8.jpg)\\
\\
**Gold Filigree Drop Delicate Earrings \* Gold Dangle Earrings \* Feminine \* Oriental**\\
\\
ad vertisement by CecylDesign\\
Advertisement from shop CecylDesign\\
CecylDesign\\
From shop CecylDesign\\
\\
$17.84\\
\\
Only 3 left](https://www.etsy.com/listing/732954338/gold-filigree-drop-delicate-earrings?click_key=3e68846ab006328364f1da1a690a96cf%3ALT2545e26e9bd05d006e088a29feb70c4e0335098d&click_sum=f75a3278&ls=r&ref=sold_out-1&sca=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALT2545e26e9bd05d006e088a29feb70c4e0335098d "Gold Filigree Drop Delicate Earrings * Gold Dangle Earrings * Feminine * Oriental")





Add to Favorites


- [![Very Light 18k Gold Filled Light Chandelier Dangling Earrings Featuring Lever Back Closure](https://i.etsystatic.com/22912349/r/il/16af7f/3347791751/il_340x270.3347791751_qfv4.jpg)\\
\\
**Very Light 18k Gold Filled Light Chandelier Dangling Earrings Featuring Lever Back Closure**\\
\\
ad vertisement by MilieJewels\\
Advertisement from shop MilieJewels\\
MilieJewels\\
From shop MilieJewels\\
\\
$20.90\\
\\
Eligible orders get 20% off\\
\\
\\
Buy 12 items and get 20% off your order\\
\\
\\
Free shipping eligible](https://www.etsy.com/listing/1075072685/very-light-18k-gold-filled-light?click_key=3e68846ab006328364f1da1a690a96cf%3ALT3b99da3e29f80dd53ec768ceee82b06e8384844e&click_sum=6f490fae&ls=r&ref=sold_out-2&pro=1&frs=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALT3b99da3e29f80dd53ec768ceee82b06e8384844e "Very Light 18k Gold Filled Light Chandelier Dangling Earrings Featuring Lever Back Closure")





Add to Favorites


- [![Gold Long Crystal Leaf Dangle Drop Earrings, Gold Crystal Tassel Drop Earrings, Long Drop Bridal Earring, Wedding Earrings, Pendant Earrings](https://i.etsystatic.com/42349624/r/il/3b37e7/6058450315/il_340x270.6058450315_5xc5.jpg)\\
\\
**Gold Long Crystal Leaf Dangle Drop Earrings, Gold Crystal Tassel Drop Earrings, Long Drop Bridal Earring, Wedding Earrings, Pendant Earrings**\\
\\
ad vertisement by CelsTimelessJewels\\
Advertisement from shop CelsTimelessJewels\\
CelsTimelessJewels\\
From shop CelsTimelessJewels\\
\\
$23.71\\
\\
FREE shipping](https://www.etsy.com/listing/1721879286/gold-long-crystal-leaf-dangle-drop?click_key=3e68846ab006328364f1da1a690a96cf%3ALT064bb88f027c7372041dd2046c2c0723680150a2&click_sum=65510dca&ls=r&ref=sold_out-3&frs=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALT064bb88f027c7372041dd2046c2c0723680150a2 "Gold Long Crystal Leaf Dangle Drop Earrings, Gold Crystal Tassel Drop Earrings, Long Drop Bridal Earring, Wedding Earrings, Pendant Earrings")





Add to Favorites


- [![Bohemian Feather Earrings](https://i.etsystatic.com/58108869/r/il/8a5dfd/6888442112/il_340x270.6888442112_36ed.jpg)\\
\\
**Bohemian Feather Earrings**\\
\\
ad vertisement by redneckhippiejewelry\\
Advertisement from shop redneckhippiejewelry\\
redneckhippiejewelry\\
From shop redneckhippiejewelry\\
\\
$20.00](https://www.etsy.com/listing/4310637863/bohemian-feather-earrings?click_key=3e68846ab006328364f1da1a690a96cf%3ALT046f8c3d1b7bfc321d27afd85a7028ef88c378af&click_sum=7fa75e26&ls=r&ref=sold_out-4&content_source=3e68846ab006328364f1da1a690a96cf%253ALT046f8c3d1b7bfc321d27afd85a7028ef88c378af "Bohemian Feather Earrings")





Add to Favorites


- [![Silver swirl/spiral moss agate drop earrings, boho gift cute](https://i.etsystatic.com/55684145/c/485/485/183/47/il/44d5ca/6458837709/il_340x270.6458837709_skhu.jpg)\\
\\
**Silver swirl/spiral moss agate drop earrings, boho gift cute**\\
\\
ad vertisement by AnphiaDesigns\\
Advertisement from shop AnphiaDesigns\\
AnphiaDesigns\\
From shop AnphiaDesigns\\
\\
$10.30\\
\\
Only 1 available and it's in 6 people's carts](https://www.etsy.com/listing/1807613762/silver-swirlspiral-moss-agate-drop?click_key=3e68846ab006328364f1da1a690a96cf%3ALT6202cbcfcbd4d83ae647b70ef81abc74beb8feb8&click_sum=b98d7a92&ls=r&ref=sold_out-5&cns=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALT6202cbcfcbd4d83ae647b70ef81abc74beb8feb8 "Silver swirl/spiral moss agate drop earrings, boho gift cute")





Add to Favorites


- [![Gold Tassel Earrings: Stainless Steel Herringbone Fringe, 5in Drop](https://i.etsystatic.com/5778065/c/2117/1684/387/180/il/79d282/4980256462/il_340x270.4980256462_r0fg.jpg)\\
\\
**Gold Tassel Earrings: Stainless Steel Herringbone Fringe, 5in Drop**\\
\\
ad vertisement by WonderLightJewelry\\
Advertisement from shop WonderLightJewelry\\
WonderLightJewelry\\
From shop WonderLightJewelry\\
\\
$35.00\\
\\
Eligible orders get 25% off\\
\\
\\
Buy 2 items and get 25% off your order\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1484555648/gold-tassel-earrings-stainless-steel?click_key=3e68846ab006328364f1da1a690a96cf%3ALT241db569a0e5d583198be3046840bbfe948af5bc&click_sum=3000c7d2&ls=r&ref=sold_out-6&pro=1&frs=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALT241db569a0e5d583198be3046840bbfe948af5bc "Gold Tassel Earrings: Stainless Steel Herringbone Fringe, 5in Drop")





Add to Favorites


- [![Boho Dangle Earrings: Ethnic Moon and Stars, Tribal Jewelry](https://i.etsystatic.com/25758102/r/il/72b302/3531892648/il_340x270.3531892648_jtzm.jpg)\\
\\
**Boho Dangle Earrings: Ethnic Moon and Stars, Tribal Jewelry**\\
\\
ad vertisement by DELAartshop\\
Advertisement from shop DELAartshop\\
DELAartshop\\
From shop DELAartshop\\
\\
$14.90\\
\\
Eligible orders get 25% off\\
\\
\\
Buy 2 items and get 25% off your order\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1139748591/boho-dangle-earrings-ethnic-moon-and?click_key=3e68846ab006328364f1da1a690a96cf%3ALT6a7396e6479a4afb34d909eb9f4a158143f5d70f&click_sum=ff042ace&ls=r&ref=sold_out-7&pro=1&frs=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALT6a7396e6479a4afb34d909eb9f4a158143f5d70f "Boho Dangle Earrings: Ethnic Moon and Stars, Tribal Jewelry")





Add to Favorites


- [![Eryn FEATHERED FRINGE EARRINGS/gold fringe earrings/gold tassel earrings/ boho earrings/art deco earrings /silver fringe earrings](https://i.etsystatic.com/14168769/r/il/f0900d/5197127173/il_340x270.5197127173_ezcm.jpg)\\
\\
**Eryn FEATHERED FRINGE EARRINGS/gold fringe earrings/gold tassel earrings/ boho earrings/art deco earrings /silver fringe earrings**\\
\\
ad vertisement by nordymade\\
Advertisement from shop nordymade\\
nordymade\\
From shop nordymade\\
\\
$39.00\\
\\
FREE shipping](https://www.etsy.com/listing/1440949603/eryn-feathered-fringe-earringsgold?click_key=3e68846ab006328364f1da1a690a96cf%3ALT8dcd78f6c91ff1f16dedfedd40d5126fe26d3552&click_sum=da75b7c0&ls=r&ref=sold_out-8&frs=1&sts=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALT8dcd78f6c91ff1f16dedfedd40d5126fe26d3552 "Eryn FEATHERED FRINGE EARRINGS/gold fringe earrings/gold tassel earrings/ boho earrings/art deco earrings /silver fringe earrings")





Add to Favorites


- [![Long Tassel Earrings: 14K Gold Filled or Sterling Silver Dangle](https://i.etsystatic.com/10230423/r/il/8dfa07/1463786399/il_340x270.1463786399_oqa5.jpg)\\
\\
**Long Tassel Earrings: 14K Gold Filled or Sterling Silver Dangle**\\
\\
ad vertisement by GildedSapphireStudio\\
Advertisement from shop GildedSapphireStudio\\
GildedSapphireStudio\\
From shop GildedSapphireStudio\\
\\
Sale Price $26.25\\
$26.25\\
\\
$35.00\\
Original Price $35.00\\
\\
\\
(25% off)\\
\\
\\
\\
Free shipping eligible](https://www.etsy.com/listing/590775763/long-tassel-earrings-14k-gold-filled-or?click_key=3e68846ab006328364f1da1a690a96cf%3ALT77fe188006534261621d44af5e12cca6acde8c4d&click_sum=36d616e4&ls=r&ref=sold_out-9&pro=1&frs=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALT77fe188006534261621d44af5e12cca6acde8c4d "Long Tassel Earrings: 14K Gold Filled or Sterling Silver Dangle")





Add to Favorites


- [![Long Gold Earrings, Geometric Earrings](https://i.etsystatic.com/10301735/c/2170/1726/0/618/il/fc7fdb/5110188704/il_340x270.5110188704_8wep.jpg)\\
\\
**Long Gold Earrings, Geometric Earrings**\\
\\
ad vertisement by HoneyBeeMetals\\
Advertisement from shop HoneyBeeMetals\\
HoneyBeeMetals\\
From shop HoneyBeeMetals\\
\\
$37.00\\
\\
Only 3 available and it's in 11 people's carts](https://www.etsy.com/listing/1513690366/long-gold-earrings-geometric-earrings?click_key=3e68846ab006328364f1da1a690a96cf%3ALTdde2db6b0c594529072a80a11e6312084b4c8555&click_sum=2cae0bd5&ls=r&ref=sold_out-10&cns=1&sts=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALTdde2db6b0c594529072a80a11e6312084b4c8555 "Long Gold Earrings, Geometric Earrings")





Add to Favorites


- [![Gold plated over silver tassel earrings occasional earrings](https://i.etsystatic.com/12839807/r/il/309623/4715790595/il_340x270.4715790595_4ugu.jpg)\\
\\
**Gold plated over silver tassel earrings occasional earrings**\\
\\
ad vertisement by SkyesPurpleCloud\\
Advertisement from shop SkyesPurpleCloud\\
SkyesPurpleCloud\\
From shop SkyesPurpleCloud\\
\\
$39.26\\
\\
FREE shipping](https://www.etsy.com/listing/1221421786/gold-plated-over-silver-tassel-earrings?click_key=3e68846ab006328364f1da1a690a96cf%3ALT1e60e1c8d47bda9b0fb3a2eb03c105dd64dd0083&click_sum=fa610f9f&ls=r&ref=sold_out-11&frs=1&sts=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALT1e60e1c8d47bda9b0fb3a2eb03c105dd64dd0083 "Gold plated over silver tassel earrings occasional earrings")





Add to Favorites


- [![Natural Chakra Earrings, Jasper Drop Earrings, Sea Sediment Drop Earrings, Boho Earrings, Women&#39;s Jewelry, Healing Earrings,  Gifts for her](https://i.etsystatic.com/58036612/r/il/d92573/6892483362/il_340x270.6892483362_34n8.jpg)\\
\\
**Natural Chakra Earrings, Jasper Drop Earrings, Sea Sediment Drop Earrings, Boho Earrings, Women's Jewelry, Healing Earrings, Gifts for her**\\
\\
ad vertisement by LUKASINGBEE\\
Advertisement from shop LUKASINGBEE\\
LUKASINGBEE\\
From shop LUKASINGBEE\\
\\
Sale Price $16.49\\
$16.49\\
\\
$32.99\\
Original Price $32.99\\
\\
\\
(50% off)](https://www.etsy.com/listing/4311352713/natural-chakra-earrings-jasper-drop?click_key=3e68846ab006328364f1da1a690a96cf%3ALT5ad72cf7751e998b68445273464297b097f2db73&click_sum=598ca903&ls=r&ref=sold_out-12&pro=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALT5ad72cf7751e998b68445273464297b097f2db73 "Natural Chakra Earrings, Jasper Drop Earrings, Sea Sediment Drop Earrings, Boho Earrings, Women's Jewelry, Healing Earrings,  Gifts for her")





Add to Favorites


- [![Real BLUE Miniature Queen Anne&#39;s Lace Dangle Earrings - Copper Electroformed](https://i.etsystatic.com/23083596/r/il/88d833/6437274654/il_340x270.6437274654_jx4m.jpg)\\
\\
**Real BLUE Miniature Queen Anne's Lace Dangle Earrings - Copper Electroformed**\\
\\
ad vertisement by ThePoshminaBoutique\\
Advertisement from shop ThePoshminaBoutique\\
ThePoshminaBoutique\\
From shop ThePoshminaBoutique\\
\\
$32.00\\
\\
FREE shipping](https://www.etsy.com/listing/1827521705/real-blue-miniature-queen-annes-lace?click_key=3e68846ab006328364f1da1a690a96cf%3ALTe92d42e711acf7ebc3cf70d55c4c37398a8f53a7&click_sum=d0b26466&ls=r&ref=sold_out-13&frs=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALTe92d42e711acf7ebc3cf70d55c4c37398a8f53a7 "Real BLUE Miniature Queen Anne's Lace Dangle Earrings - Copper Electroformed")





Add to Favorites


- [![Gold Tassel Earrings – Long Statement Fringe Earrings, 24K Gold Plated Dangle Earrings for Women, Elegant Jewelry for Evening & Party Looks](https://i.etsystatic.com/53228476/r/il/db638f/6760944009/il_340x270.6760944009_2yjx.jpg)\\
\\
**Gold Tassel Earrings – Long Statement Fringe Earrings, 24K Gold Plated Dangle Earrings for Women, Elegant Jewelry for Evening & Party Looks**\\
\\
ad vertisement by BismarkJewelry\\
Advertisement from shop BismarkJewelry\\
BismarkJewelry\\
From shop BismarkJewelry\\
\\
Sale Price $24.67\\
$24.67\\
\\
$32.90\\
Original Price $32.90\\
\\
\\
(25% off)\\
\\
\\
\\
Free shipping eligible](https://www.etsy.com/listing/1887689461/gold-tassel-earrings-long-statement?click_key=3e68846ab006328364f1da1a690a96cf%3ALTaf95169ddd51bd49a0ce4f8cfce5c35455a32ee0&click_sum=25fd9529&ls=r&ref=sold_out-14&pro=1&frs=1&sts=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALTaf95169ddd51bd49a0ce4f8cfce5c35455a32ee0 "Gold Tassel Earrings – Long Statement Fringe Earrings, 24K Gold Plated Dangle Earrings for Women, Elegant Jewelry for Evening & Party Looks")





Add to Favorites


- [![Natural Chakra Earrings, Jasper Earrings, Stone Earrings, Boho Earrings, Women&#39;s Jewelry Earrings, Meditation Calm Earrings, Christmas Gifts](https://i.etsystatic.com/52958835/r/il/2274b0/6335304702/il_340x270.6335304702_1dyz.jpg)\\
\\
**Natural Chakra Earrings, Jasper Earrings, Stone Earrings, Boho Earrings, Women's Jewelry Earrings, Meditation Calm Earrings, Christmas Gifts**\\
\\
ad vertisement by LarzyCustomGifts\\
Advertisement from shop LarzyCustomGifts\\
LarzyCustomGifts\\
From shop LarzyCustomGifts\\
\\
Sale Price $16.27\\
$16.27\\
\\
$33.20\\
Original Price $33.20\\
\\
\\
(51% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1792978232/natural-chakra-earrings-jasper-earrings?click_key=3e68846ab006328364f1da1a690a96cf%3ALT8aff94212d1b5e210a2ad5590f55d90df12f29f8&click_sum=df54cf44&ls=r&ref=sold_out-15&pro=1&frs=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALT8aff94212d1b5e210a2ad5590f55d90df12f29f8 "Natural Chakra Earrings, Jasper Earrings, Stone Earrings, Boho Earrings, Women's Jewelry Earrings, Meditation Calm Earrings, Christmas Gifts")





Add to Favorites


- [![Green Amethyst Chandelier Earrings: Sterling Silver Boho Dangle](https://i.etsystatic.com/38859849/r/il/92566d/6583406828/il_340x270.6583406828_s273.jpg)\\
\\
**Green Amethyst Chandelier Earrings: Sterling Silver Boho Dangle**\\
\\
ad vertisement by RGJewellers\\
Advertisement from shop RGJewellers\\
RGJewellers\\
From shop RGJewellers\\
\\
Sale Price $35.20\\
$35.20\\
\\
$64.00\\
Original Price $64.00\\
\\
\\
(45% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1760728943/green-amethyst-chandelier-earrings?click_key=3e68846ab006328364f1da1a690a96cf%3ALTdcb09df887cef582e7a1a6fa14f7107bed3b7004&click_sum=febd8428&ls=r&ref=sold_out-16&pro=1&frs=1&sts=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALTdcb09df887cef582e7a1a6fa14f7107bed3b7004 "Green Amethyst Chandelier Earrings: Sterling Silver Boho Dangle")





Add to Favorites


- [![Gold Cascading Floral Earrings – Autumn Bloom Statement Jewelry, Elegant Wedding Earrings, Fall Jewelry Gift for Her, Anniversary Jewelry Gi](https://i.etsystatic.com/59324006/r/il/86b967/7249758492/il_340x270.7249758492_8d4g.jpg)\\
\\
**Gold Cascading Floral Earrings – Autumn Bloom Statement Jewelry, Elegant Wedding Earrings, Fall Jewelry Gift for Her, Anniversary Jewelry Gi**\\
\\
ad vertisement by MoonlitGemCo\\
Advertisement from shop MoonlitGemCo\\
MoonlitGemCo\\
From shop MoonlitGemCo\\
\\
Sale Price $24.30\\
$24.30\\
\\
$27.00\\
Original Price $27.00\\
\\
\\
(10% off)\\
\\
\\
\\
Free shipping eligible](https://www.etsy.com/listing/4379930272/gold-cascading-floral-earrings-autumn?click_key=3e68846ab006328364f1da1a690a96cf%3ALTe160ea95e27ed92bd3267f449c16fdc0a729b2ab&click_sum=2611f39b&ls=r&ref=sold_out-17&pro=1&frs=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALTe160ea95e27ed92bd3267f449c16fdc0a729b2ab "Gold Cascading Floral Earrings – Autumn Bloom Statement Jewelry, Elegant Wedding Earrings, Fall Jewelry Gift for Her, Anniversary Jewelry Gi")





Add to Favorites


- [![Delicate branch gold wire earrings, lightweight, handmade, dainty, lightweight, dangle, subtle](https://i.etsystatic.com/9090525/r/il/d590de/4425265921/il_340x270.4425265921_pwr5.jpg)\\
\\
**Delicate branch gold wire earrings, lightweight, handmade, dainty, lightweight, dangle, subtle**\\
\\
ad vertisement by Bibliboo\\
Advertisement from shop Bibliboo\\
Bibliboo\\
From shop Bibliboo\\
\\
$11.67](https://www.etsy.com/listing/1137828998/delicate-branch-gold-wire-earrings?click_key=3e68846ab006328364f1da1a690a96cf%3ALT2723cadcb787730421f8888a06fb4c34b1aeb2c2&click_sum=1a5cf980&ls=r&ref=sold_out-18&sts=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALT2723cadcb787730421f8888a06fb4c34b1aeb2c2 "Delicate branch gold wire earrings, lightweight, handmade, dainty, lightweight, dangle, subtle")





Add to Favorites


- [![Elegant Teardrop Earrings: Hammered Gold Filled or Silver Pear-Shaped Drops for Mother&#39;s Day & Everyday Wear](https://i.etsystatic.com/5700448/c/2056/1634/544/325/il/d61044/4261608614/il_340x270.4261608614_k6ge.jpg)\\
\\
**Elegant Teardrop Earrings: Hammered Gold Filled or Silver Pear-Shaped Drops for Mother's Day & Everyday Wear**\\
\\
ad vertisement by VivaRevival\\
Advertisement from shop VivaRevival\\
VivaRevival\\
From shop VivaRevival\\
\\
Sale Price $34.00\\
$34.00\\
\\
$40.00\\
Original Price $40.00\\
\\
\\
(15% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/551993046/elegant-teardrop-earrings-hammered-gold?click_key=LTdf0b3a763d21ccc79380de5b0b488d5707618401%3A551993046&click_sum=f0bb1a87&ls=a&ref=sold_out_ad-7&pro=1&frs=1&sts=1 "Elegant Teardrop Earrings: Hammered Gold Filled or Silver Pear-Shaped Drops for Mother's Day & Everyday Wear")





Add to Favorites


- [![Swiss Blue Topaz Earrings, 24K Gold Vermeil on 925 Sterling Silver, Dangle Drop Earring, December Birthstone, Handmade Jewelry, Gift For Her](https://i.etsystatic.com/24750251/c/2101/2101/73/450/il/b6c61a/6320499654/il_340x270.6320499654_3j9x.jpg)\\
\\
**Swiss Blue Topaz Earrings, 24K Gold Vermeil on 925 Sterling Silver, Dangle Drop Earring, December Birthstone, Handmade Jewelry, Gift For Her**\\
\\
ad vertisement by ElementaJewels\\
Advertisement from shop ElementaJewels\\
ElementaJewels\\
From shop ElementaJewels\\
\\
Sale Price $125.25\\
$125.25\\
\\
$167.00\\
Original Price $167.00\\
\\
\\
(25% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1789899658/swiss-blue-topaz-earrings-24k-gold?click_key=LTeb1986ad42395bb473aa81b83eb8406bb52d14f2%3A1789899658&click_sum=15d73323&ls=a&ref=sold_out_ad-8&pro=1&frs=1 "Swiss Blue Topaz Earrings, 24K Gold Vermeil on 925 Sterling Silver, Dangle Drop Earring, December Birthstone, Handmade Jewelry, Gift For Her")





Add to Favorites


- [![Sculptural Teardrop Earrings: Gold and Silver Plated, Modern Jewelry](https://i.etsystatic.com/34346668/r/il/ff2736/7335923943/il_340x270.7335923943_u0ew.jpg)\\
\\
**Sculptural Teardrop Earrings: Gold and Silver Plated, Modern Jewelry**\\
\\
ad vertisement by JakrisCollection\\
Advertisement from shop JakrisCollection\\
JakrisCollection\\
From shop JakrisCollection\\
\\
$53.00\\
\\
FREE shipping](https://www.etsy.com/listing/4387215546/sculptural-teardrop-earrings-gold-and?click_key=LT87b4220aeff1e84ca96845519a95271c0d7f7d4e%3A4387215546&click_sum=f49dc0a7&ls=a&ref=sold_out_ad-9&frs=1&sts=1 "Sculptural Teardrop Earrings: Gold and Silver Plated, Modern Jewelry")





Add to Favorites


- [![Boho Teardrop Glass Crystal Beaded Dangle Earrings, Bohemian Earrings, Lightweight Crystal Earrings, Statement Earrings, Gold Wire Earrings](https://i.etsystatic.com/12009320/r/il/15c947/6930997452/il_340x270.6930997452_s4r7.jpg)\\
\\
**Boho Teardrop Glass Crystal Beaded Dangle Earrings, Bohemian Earrings, Lightweight Crystal Earrings, Statement Earrings, Gold Wire Earrings**\\
\\
ad vertisement by petitejewel\\
Advertisement from shop petitejewel\\
petitejewel\\
From shop petitejewel\\
\\
$20.90\\
\\
Free shipping eligible](https://www.etsy.com/listing/4316452426/boho-teardrop-glass-crystal-beaded?click_key=LTfe97caf50108937f7e4acb3e094d42fcd707a197%3A4316452426&click_sum=3bbb74fe&ls=a&ref=sold_out_ad-10&frs=1&sts=1 "Boho Teardrop Glass Crystal Beaded Dangle Earrings, Bohemian Earrings, Lightweight Crystal Earrings, Statement Earrings, Gold Wire Earrings")





Add to Favorites


- [![Teardrop Filigree Earrings, Elegant Gold Drop Earrings, Handmade Openwork Jewelry](https://i.etsystatic.com/15447786/c/2400/2400/299/299/il/9f9c76/6722351704/il_340x270.6722351704_gcq9.jpg)\\
\\
**Teardrop Filigree Earrings, Elegant Gold Drop Earrings, Handmade Openwork Jewelry**\\
\\
ad vertisement by TurkishBling\\
Advertisement from shop TurkishBling\\
TurkishBling\\
From shop TurkishBling\\
\\
$45.99\\
\\
FREE shipping](https://www.etsy.com/listing/1889481541/teardrop-filigree-earrings-elegant-gold?click_key=LTf34d039e503224ecdfaf905cca04bc8540c4c511%3A1889481541&click_sum=9c502f03&ls=a&ref=sold_out_ad-11&frs=1&sts=1 "Teardrop Filigree Earrings, Elegant Gold Drop Earrings, Handmade Openwork Jewelry")





Add to Favorites


- [![Gold Beaded Dangle Earrings: 14k Gold-Filled, 24k Gold-Plated Glass Beads](https://i.etsystatic.com/6812631/r/il/bd1f86/7359114323/il_340x270.7359114323_cnb0.jpg)\\
\\
**Gold Beaded Dangle Earrings: 14k Gold-Filled, 24k Gold-Plated Glass Beads**\\
\\
ad vertisement by ShopAiraH\\
Advertisement from shop ShopAiraH\\
ShopAiraH\\
From shop ShopAiraH\\
\\
$132.00](https://www.etsy.com/listing/4391052132/gold-beaded-dangle-earrings-14k-gold?click_key=LT16a94202696fd728d243069adc15aa4473dfa273%3A4391052132&click_sum=503e7491&ls=a&ref=sold_out_ad-12 "Gold Beaded Dangle Earrings: 14k Gold-Filled, 24k Gold-Plated Glass Beads")





Add to Favorites


- [![Canoe Paddle Earrings](https://i.etsystatic.com/7448249/r/il/d82465/414062121/il_340x270.414062121_ew82.jpg)\\
\\
**Canoe Paddle Earrings**\\
\\
ad vertisement by MuskokaJewelry\\
Advertisement from shop MuskokaJewelry\\
MuskokaJewelry\\
From shop MuskokaJewelry\\
\\
$58.67\\
\\
Only 1 available and it's in 1 person's cart](https://www.etsy.com/listing/119966409/canoe-paddle-earrings?click_key=3e68846ab006328364f1da1a690a96cf%3ALT7db48e768c140536fd5224f1c6c0727540a650ee&click_sum=cd08abe7&ls=r&ref=sold_out-19&cns=1&sts=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALT7db48e768c140536fd5224f1c6c0727540a650ee "Canoe Paddle Earrings")





Add to Favorites


- [![Tiny Cute Axolotl Stud Earrings in Sterling Silver, Tiny Earrings - Pet Lover - Cute,  Fun, Whimsical](https://i.etsystatic.com/10967397/r/il/c7170d/6900397229/il_340x270.6900397229_g6df.jpg)\\
\\
**Tiny Cute Axolotl Stud Earrings in Sterling Silver, Tiny Earrings - Pet Lover - Cute, Fun, Whimsical**\\
\\
ad vertisement by SilverRainSilver\\
Advertisement from shop SilverRainSilver\\
SilverRainSilver\\
From shop SilverRainSilver\\
\\
$15.03](https://www.etsy.com/listing/4303497700/tiny-cute-axolotl-stud-earrings-in?click_key=3e68846ab006328364f1da1a690a96cf%3ALT04230f7cc63509ce0d18d0e64019abf7f4b3293f&click_sum=e21d4dd3&ls=r&ref=sold_out-20&bes=1&sts=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALT04230f7cc63509ce0d18d0e64019abf7f4b3293f "Tiny Cute Axolotl Stud Earrings in Sterling Silver, Tiny Earrings - Pet Lover - Cute,  Fun, Whimsical")





Add to Favorites


- [![Custom Leaf Birthstone Earrings, Daily Earring, Diamond Dangle Earrings, Birthday Gift, Grandma Gift for Mom, Christmas Gift for Her](https://i.etsystatic.com/53120861/c/1709/1709/115/0/il/13015b/6778264749/il_340x270.6778264749_6wcf.jpg)\\
\\
**Custom Leaf Birthstone Earrings, Daily Earring, Diamond Dangle Earrings, Birthday Gift, Grandma Gift for Mom, Christmas Gift for Her**\\
\\
ad vertisement by HandmadeTreasuryCo\\
Advertisement from shop HandmadeTreasuryCo\\
HandmadeTreasuryCo\\
From shop HandmadeTreasuryCo\\
\\
Sale Price $24.01\\
$24.01\\
\\
$48.02\\
Original Price $48.02\\
\\
\\
(50% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/1891004185/custom-leaf-birthstone-earrings-daily?click_key=3e68846ab006328364f1da1a690a96cf%3ALT9fa4040d4c5d2228235e22194c48eb842aa0ab5e&click_sum=604f0ed7&ls=r&ref=sold_out-21&pro=1&frs=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALT9fa4040d4c5d2228235e22194c48eb842aa0ab5e "Custom Leaf Birthstone Earrings, Daily Earring, Diamond Dangle Earrings, Birthday Gift, Grandma Gift for Mom, Christmas Gift for Her")





Add to Favorites


- [![Antiqued Silver Teardrop Earrings – Large Paddle Drop Earrings, Fringe Statement Jewelry, Lightweight Dangle Earrings for Everyday Wear](https://i.etsystatic.com/5570970/r/il/73ef16/2890212898/il_340x270.2890212898_a32l.jpg)\\
\\
**Antiqued Silver Teardrop Earrings – Large Paddle Drop Earrings, Fringe Statement Jewelry, Lightweight Dangle Earrings for Everyday Wear**\\
\\
ad vertisement by TheBeadCounter\\
Advertisement from shop TheBeadCounter\\
TheBeadCounter\\
From shop TheBeadCounter\\
\\
Sale Price $32.00\\
$32.00\\
\\
$40.00\\
Original Price $40.00\\
\\
\\
(20% off)\\
\\
\\
\\
Free shipping eligible](https://www.etsy.com/listing/948004628/antiqued-silver-teardrop-earrings-large?click_key=3e68846ab006328364f1da1a690a96cf%3ALT61acfa98dd75ce38bb80245170ca27f0d69f754e&click_sum=b61dfe49&ls=r&ref=sold_out-22&pro=1&frs=1&sts=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALT61acfa98dd75ce38bb80245170ca27f0d69f754e "Antiqued Silver Teardrop Earrings – Large Paddle Drop Earrings, Fringe Statement Jewelry, Lightweight Dangle Earrings for Everyday Wear")





Add to Favorites


- [![Filigree Teardrop Earrings, Handmade Gold Dangle Earrings, Lightweight Openwork Jewelry](https://i.etsystatic.com/15447786/c/2420/2420/108/108/il/76be15/6725161414/il_340x270.6725161414_kpsq.jpg)\\
\\
**Filigree Teardrop Earrings, Handmade Gold Dangle Earrings, Lightweight Openwork Jewelry**\\
\\
ad vertisement by TurkishBling\\
Advertisement from shop TurkishBling\\
TurkishBling\\
From shop TurkishBling\\
\\
$34.99\\
\\
FREE shipping](https://www.etsy.com/listing/1890016573/filigree-teardrop-earrings-handmade-gold?click_key=3e68846ab006328364f1da1a690a96cf%3ALT88df4a19b701efa3f394020a6b9cc1eadbaaa42b&click_sum=7e2994ff&ls=r&ref=sold_out-23&frs=1&sts=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALT88df4a19b701efa3f394020a6b9cc1eadbaaa42b "Filigree Teardrop Earrings, Handmade Gold Dangle Earrings, Lightweight Openwork Jewelry")





Add to Favorites


- [![Boho Alabaster Square Earrings:  Copper Teardrop, Czech Glass Starburst Tile. Best Sellers, More Than 225 Sold!](https://i.etsystatic.com/26356643/c/1509/1509/135/700/il/1c1b68/7114843749/il_340x270.7114843749_50ie.jpg)\\
\\
**Boho Alabaster Square Earrings: Copper Teardrop, Czech Glass Starburst Tile. Best Sellers, More Than 225 Sold!**\\
\\
ad vertisement by BeadgratefulShop\\
Advertisement from shop BeadgratefulShop\\
BeadgratefulShop\\
From shop BeadgratefulShop\\
\\
$29.99\\
\\
Free shipping eligible](https://www.etsy.com/listing/1713325455/boho-alabaster-square-earrings-copper?click_key=3e68846ab006328364f1da1a690a96cf%3ALTc557c4dc8036d44ffea9f768a67c84c7d9b7d3f3&click_sum=88414c2d&ls=r&ref=sold_out-24&frs=1&sts=1&content_source=3e68846ab006328364f1da1a690a96cf%253ALTc557c4dc8036d44ffea9f768a67c84c7d9b7d3f3 "Boho Alabaster Square Earrings:  Copper Teardrop, Czech Glass Starburst Tile. Best Sellers, More Than 225 Sold!")





Add to Favorites



[Shop more similar items](https://www.etsy.com/listing/945380219/similar?page=2&ref=sold_out_more_like_this)

### More from this shop

[See shop](https://www.etsy.com/shop/TheBeadCounter?ref=related)

[![Large Gold Fringe Paddle Earrings – Fun Western Statement Jewelry, Dangle Earrings, Perfect Gift for Mom or Unique Gift Idea](https://i.etsystatic.com/5570970/c/2542/2542/182/120/il/92c08c/7036926098/il_340x270.7036926098_thhv.jpg)\\
\\
**Large Gold Fringe Paddle Earrings – Fun Western Statement Jewelry, Dangle Earrings, Perfect Gift for Mom or Unique Gift Idea**\\
\\
ad vertisement by TheBeadCounter\\
Advertisement from shop TheBeadCounter\\
TheBeadCounter\\
From shop TheBeadCounter\\
\\
Sale Price $32.00\\
$32.00\\
\\
$40.00\\
Original Price $40.00\\
\\
\\
(20% off)\\
\\
\\
\\
Free shipping eligible](https://www.etsy.com/listing/1803700819/large-gold-fringe-paddle-earrings-fun?click_key=1824eb8d77894929f5616601d52cafab5e0acf1a%3A1803700819&click_sum=49ace8cb&ref=related-1&pro=1&frs=1&sts=1 "Large Gold Fringe Paddle Earrings – Fun Western Statement Jewelry, Dangle Earrings, Perfect Gift for Mom or Unique Gift Idea")


Add to Favorites


[![Fringe Boho Earrings – Hammered Silver Paddle Dangles, Geometric Triangle Statement, Lightweight Festival Gift for Her](https://i.etsystatic.com/5570970/c/2564/2564/78/415/il/99e0f4/6317956592/il_340x270.6317956592_71e3.jpg)\\
\\
**Fringe Boho Earrings – Hammered Silver Paddle Dangles, Geometric Triangle Statement, Lightweight Festival Gift for Her**\\
\\
ad vertisement by TheBeadCounter\\
Advertisement from shop TheBeadCounter\\
TheBeadCounter\\
From shop TheBeadCounter\\
\\
Sale Price $32.00\\
$32.00\\
\\
$40.00\\
Original Price $40.00\\
\\
\\
(20% off)\\
\\
\\
\\
Free shipping eligible](https://www.etsy.com/listing/1803692309/fringe-boho-earrings-hammered-silver?click_key=6e2d7db1224fe5a35ce1076f04f9960aad2a5d5b%3A1803692309&click_sum=8e066e5e&ref=related-2&pro=1&frs=1&sts=1 "Fringe Boho Earrings – Hammered Silver Paddle Dangles, Geometric Triangle Statement, Lightweight Festival Gift for Her")


Add to Favorites


[![Gold Circle Fringe Earrings – Statement Boho Earrings, Bohemian & Southwestern Jewelry, Timeless Classic, Perfect Holiday Gift for Her](https://i.etsystatic.com/5570970/r/il/588e26/2806656586/il_340x270.2806656586_swzt.jpg)\\
\\
**Gold Circle Fringe Earrings – Statement Boho Earrings, Bohemian & Southwestern Jewelry, Timeless Classic, Perfect Holiday Gift for Her**\\
\\
ad vertisement by TheBeadCounter\\
Advertisement from shop TheBeadCounter\\
TheBeadCounter\\
From shop TheBeadCounter\\
\\
Sale Price $28.80\\
$28.80\\
\\
$36.00\\
Original Price $36.00\\
\\
\\
(20% off)\\
\\
\\
\\
Free shipping eligible](https://www.etsy.com/listing/931470768/gold-circle-fringe-earrings-statement?click_key=fb416703308fc15763d88dd732fe33d77fe147ae%3A931470768&click_sum=f8201166&ref=related-3&pro=1&frs=1&sts=1 "Gold Circle Fringe Earrings – Statement Boho Earrings, Bohemian & Southwestern Jewelry, Timeless Classic, Perfect Holiday Gift for Her")


Add to Favorites


[![Yellow Jasper Hoop Earrings | Handmade Copper Wire Wrapped Teardrop Dangles | Golden Gemstone Boho Earrings | Light Nickel Free Gift for Her](https://i.etsystatic.com/5570970/r/il/16b402/2763575984/il_340x270.2763575984_4hwv.jpg)\\
\\
**Yellow Jasper Hoop Earrings \| Handmade Copper Wire Wrapped Teardrop Dangles \| Golden Gemstone Boho Earrings \| Light Nickel Free Gift for Her**\\
\\
ad vertisement by TheBeadCounter\\
Advertisement from shop TheBeadCounter\\
TheBeadCounter\\
From shop TheBeadCounter\\
\\
Sale Price $35.20\\
$35.20\\
\\
$44.00\\
Original Price $44.00\\
\\
\\
(20% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/934358883/yellow-jasper-hoop-earrings-handmade?click_key=076ba94af29da1767ad6affa75ea294950850963%3A934358883&click_sum=18cb61d7&ref=related-4&pro=1&frs=1&sts=1 "Yellow Jasper Hoop Earrings | Handmade Copper Wire Wrapped Teardrop Dangles | Golden Gemstone Boho Earrings | Light Nickel Free Gift for Her")


Add to Favorites


[![Gold Circle Fringe Earrings – Boho Fringe Paddle Earrings, Statement Bohemian Jewelry for Women, Unique Southwestern Style Gift](https://i.etsystatic.com/5570970/c/3000/2384/0/423/il/948945/2921924930/il_340x270.2921924930_ehac.jpg)\\
\\
**Gold Circle Fringe Earrings – Boho Fringe Paddle Earrings, Statement Bohemian Jewelry for Women, Unique Southwestern Style Gift**\\
\\
ad vertisement by TheBeadCounter\\
Advertisement from shop TheBeadCounter\\
TheBeadCounter\\
From shop TheBeadCounter\\
\\
Sale Price $28.80\\
$28.80\\
\\
$36.00\\
Original Price $36.00\\
\\
\\
(20% off)\\
\\
\\
\\
FREE shipping](https://www.etsy.com/listing/961732888/gold-circle-fringe-earrings-boho-fringe?click_key=5420e765b6250e80698a56396ac263209236a212%3A961732888&click_sum=bd5952e2&ref=related-5&pro=1&frs=1&sts=1 "Gold Circle Fringe Earrings – Boho Fringe Paddle Earrings, Statement Bohemian Jewelry for Women, Unique Southwestern Style Gift")


Add to Favorites


[![Boho Earrings - Handmade Gold Dangle & Fringe Jewelry, Unique Drop Earrings for Her, Southwestern Statement Gift, Mother&#39;s Day Gift](https://i.etsystatic.com/5570970/r/il/588e26/2806656586/il_340x270.2806656586_swzt.jpg)\\
\\
**Boho Earrings - Handmade Gold Dangle & Fringe Jewelry, Unique Drop Earrings for Her, Southwestern Statement Gift, Mother's Day Gift**\\
\\
ad vertisement by TheBeadCounter\\
Advertisement from shop TheBeadCounter\\
TheBeadCounter\\
From shop TheBeadCounter\\
\\
Sale Price $28.80\\
$28.80\\
\\
$36.00\\
Original Price $36.00\\
\\
\\
(20% off)\\
\\
\\
\\
Free shipping eligible](https://www.etsy.com/listing/1873699460/boho-earrings-handmade-gold-dangle?click_key=de5c599a9cb16d493e60b4e45f55e5c6519d54c1%3A1873699460&click_sum=e4285ed7&ref=related-6&pro=1&frs=1&sts=1 "Boho Earrings - Handmade Gold Dangle & Fringe Jewelry, Unique Drop Earrings for Her, Southwestern Statement Gift, Mother's Day Gift")


Add to Favorites


Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F945380219%2Fgold-teardrop-fan-earrings-large-paddle%3Famp%253Bclick_sum%3D5dbc91bc%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bsts%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgxNTYyNzo4NmE2MGUxYmY0ZDZlNTlkNWJiMTMzZWYxMzg4N2M0OQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F945380219%2Fgold-teardrop-fan-earrings-large-paddle%3Famp%253Bclick_sum%3D5dbc91bc%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bsts%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/945380219/gold-teardrop-fan-earrings-large-paddle?amp;click_sum=5dbc91bc&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;sts=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F945380219%2Fgold-teardrop-fan-earrings-large-paddle%3Famp%253Bclick_sum%3D5dbc91bc%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bsts%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done