[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1567521330/multicolor-watercolor-large-wall-art?amp;click_sum=16333fb8&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;pro=1&amp;sts=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?amp%3Bclick_sum=16333fb8&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-0)
- [Prints](https://www.etsy.com/c/art-and-collectibles/prints?amp%3Bclick_sum=16333fb8&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-1)
- [Giclée](https://www.etsy.com/c/art-and-collectibles/prints/giclee?amp%3Bclick_sum=16333fb8&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-2)


Add to Favorites


- ![May include: Abstract art print with a beige background and colorful circles, stripes, and dots. The print is framed in a light wood frame.](https://i.etsystatic.com/5321870/r/il/fae55b/5413964839/il_794xN.5413964839_k6ot.jpg)
- ![May include: An abstract painting with a layered, textured style. The painting features a variety of colors, including pink, blue, green, orange, and brown. The colors are blended and layered to create a sense of depth and movement. The painting is set against a light beige background.](https://i.etsystatic.com/5321870/r/il/28b3b1/5413619863/il_794xN.5413619863_tuj3.jpg)
- ![May include: Abstract art painting with a beige background and colorful circles and stripes. The painting is framed and hanging on a wall in a room with a glass chair and a brown leather armchair.](https://i.etsystatic.com/5321870/r/il/82ee56/5365472618/il_794xN.5365472618_3z72.jpg)
- ![May include: A large abstract painting with a beige background and colorful circles and stripes. The painting is framed in a gold frame and is hanging on a white wall. The painting is in a living room setting with a brown leather stool and a white couch.](https://i.etsystatic.com/5321870/r/il/97a288/5365468486/il_794xN.5365468486_1wyu.jpg)
- ![May include: Abstract art painting with a beige background and colorful circles and stripes. The painting is framed and hanging on a wall in a room with a white armchair and a wooden side table with a lamp.](https://i.etsystatic.com/5321870/r/il/4372cf/5413623825/il_794xN.5413623825_5i37.jpg)
- ![May include: A framed abstract painting with a beige background and colorful circles and stripes. The painting is hanging on a white wall above a wicker chair and a potted plant.](https://i.etsystatic.com/5321870/r/il/a98000/5365453926/il_794xN.5365453926_e7hu.jpg)
- ![May include: Abstract art print with a light brown background and colorful shapes and dots. The print is framed in a light brown wood frame.](https://i.etsystatic.com/5321870/r/il/ac010c/5365453830/il_794xN.5365453830_2mvo.jpg)

- ![May include: Abstract art print with a beige background and colorful circles, stripes, and dots. The print is framed in a light wood frame.](https://i.etsystatic.com/5321870/c/2884/2292/24/345/il/fae55b/5413964839/il_75x75.5413964839_k6ot.jpg)
- ![May include: An abstract painting with a layered, textured style. The painting features a variety of colors, including pink, blue, green, orange, and brown. The colors are blended and layered to create a sense of depth and movement. The painting is set against a light beige background.](https://i.etsystatic.com/5321870/r/il/28b3b1/5413619863/il_75x75.5413619863_tuj3.jpg)
- ![May include: Abstract art painting with a beige background and colorful circles and stripes. The painting is framed and hanging on a wall in a room with a glass chair and a brown leather armchair.](https://i.etsystatic.com/5321870/c/2369/1883/162/0/il/82ee56/5365472618/il_75x75.5365472618_3z72.jpg)
- ![May include: A large abstract painting with a beige background and colorful circles and stripes. The painting is framed in a gold frame and is hanging on a white wall. The painting is in a living room setting with a brown leather stool and a white couch.](https://i.etsystatic.com/5321870/c/2040/1622/331/340/il/97a288/5365468486/il_75x75.5365468486_1wyu.jpg)
- ![May include: Abstract art painting with a beige background and colorful circles and stripes. The painting is framed and hanging on a wall in a room with a white armchair and a wooden side table with a lamp.](https://i.etsystatic.com/5321870/c/2142/1703/45/100/il/4372cf/5413623825/il_75x75.5413623825_5i37.jpg)
- ![May include: A framed abstract painting with a beige background and colorful circles and stripes. The painting is hanging on a white wall above a wicker chair and a potted plant.](https://i.etsystatic.com/5321870/r/il/a98000/5365453926/il_75x75.5365453926_e7hu.jpg)
- ![May include: Abstract art print with a light brown background and colorful shapes and dots. The print is framed in a light brown wood frame.](https://i.etsystatic.com/5321870/r/il/ac010c/5365453830/il_75x75.5365453830_2mvo.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1567521330%2Fmulticolor-watercolor-large-wall-art%23report-overlay-trigger)

In 5 carts

Price:$38.32+


Original Price:
$47.90+


Loading


**New markdown!**

20% off


•

Limited time sale


# Multicolor watercolor large wall art print, Modern contemporary abstract painting, Statement living room wall decor in light colors

[VictoriAtelier](https://www.etsy.com/shop/VictoriAtelier?ref=shop-header-name&listing_id=1567521330&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1567521330/multicolor-watercolor-large-wall-art?amp;click_sum=16333fb8&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;pro=1&amp;sts=1#reviews)

finished


See in original language


Translate to English


Select an option

Paper rolled in a tube ($38.32 - $274.32)

Canvas rolled in a tube ($85.52 - $330.32)

Streched canvas ready to hang ($195.92 - $358.32)

Please select an option


size


See in original language


Translate to English


Select an option

8"x12" - 20x30cm Vertical ($38.32)

11"x14" - 25x35cm Vertical ($38.32)

11"x17" - 25x42cm Vertical ($48.72)

12"x16" - 30x40cm Vertical ($48.72)

16"x20" - 40x50cm Vertical ($76.72)

16"x24" - 40x60cm Vertical ($85.52 - $195.92)

20"x24" - 50x60cm Vertical ($95.12 - $216.72)

20"x28" - 50x70cm Vertical ($103.92 - $233.52)

20"x35" - 50x90cm Vertical ($121.52)

24"x30" - 60x75cm Vertical ($121.52)

24"x32" - 60x80cm Vertical ($130.32 - $260.72)

24"x36" - 60x90cm Vertical ($139.92 - $276.72)

24"x40" - 60x100cm Vertical ($144.72 - $280.72)

27"x40" - 70x100cm Vertical ($147.92 - $291.92)

30"x40" - 75x100cm Vertical ($153.52 - $305.52)

30"x45" - 75x110cm Vertical ($159.92 - $207.92)

30"x60" - 75x150cm Vertcial ($206.32 - $247.92)

32"x40" - 80x100cm Vertical ($157.52 - $323.92)

32"x48" - 80x120cm Vertical ($184.72 - $222.32)

12"x12" - 30x30cm Square ($48.72)

16"x16 - 40x40cm Square ($67.92)

20"x20" - 50x50cm Square ($85.52 - $195.92)

24"x24" - 60x60cm Square ($103.92 - $239.92)

30"x30" - 75x75cm Square ($148.72 - $287.92)

32"x32" - 80x80cm Square ($155.92 - $297.52)

36"x36" - 90x90cm Square ($175.92 - $326.32)

40"x40" - 100x100cm Square ($184.72 - $358.32)

42"x42" - 105x105cm Square ($197.52)

40"x48" - 100x120cm Vertical ($223.12 - $268.72)

40"x50" - 100x125cm Vertical ($231.12 - $278.32)

40"x60" - 100x150cm Vertical ($274.32 - $330.32)

Please select an option


Add personalization
(optional)

- Personalization





You can choose inches or centimeters, thanks!


















0/256


4 payments of **$9.58** at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Item details

### Highlights

Made by [VictoriAtelier](https://www.etsy.com/shop/VictoriAtelier)

- Materials: archival matte paper, high quality paper, ink



Multicolor watercolor large wall art print, Modern contemporary abstract painting, Statement living room wall decor in light colors

Fine Art giclée print of my abstract painting, created with EPSON pigment inks. Both paper and canvas are 100% cotton, acid free and textured.

FINISH OPTIONS:

Choice of eco-friendly 320 gsm textured watercolour paper or 390 gsm natural cotton canvas

The available sizes can be selected in the drop down box "Size". If you need a custom size please do not hesitate to contact me.

\- Printed art paper with 0.2 inch white border for easy matting, hand signed after production.

\- The rolled canvas includes an additional 2 inch mirror printed border for seamless stretching at your local frame shop.

\- Stretched and ready to hang canvases are stretched on a pinewood frame, ready to hang straight out of the box.

It comes unframed and shipped rolled in a rigid protective tuve, except stretched canvases ready to hang

Perfect for gifts or to hang in your home

SHOP POLICIES and SHIPPING OPTIONS

EXPRESS FREE SHIPPING VIA DHL TO WORLDWIDE

VIEWS OF ROOM MAY NOT BE ACCURATE.

Interior images may not be to scale. Floating frames shown are examples for illustrative purposes only and is not included

All photographs on this site trying paintings visually represent as accurately as possible. There may be slight variations in colors due to differences in lighting and monitors.

MY OTHER ARTWORWS

For more large Giclee prints visit:

[https://www.etsy.com/shop/VictoriAtelier?ref=l2-shopheader-name§ion\_id=22219840](https://www.etsy.com/shop/VictoriAtelier?ref=l2-shopheader-name%C2%A7ion_id=22219840)

View more original artwork at :

[www.etsy.com/es/shop/VictoriAtelier?section\_id=5702002&ref=shopsection\_leftnav\_1](http://www.etsy.com/es/shop/VictoriAtelier?section_id=5702002&ref=shopsection_leftnav_1)

FAQS:

\*What is the difference between paper printing and rolled canvas prints?

The difference is that the paper needs to be framed with glass and the canvas only has to be stretched on wooden bars. Both prints are top quality Giclee with 100% cotton paper or canvas and acid free.

\*On prints, I can't find the size I need for my frame.

As there are many measures, I only have the standard measures easy to find in any frame house. But if you need a special measure, I will be happy to adjust the prints to your frames.

\*Do you sell your prints by downloading images?

No, the prints are printed by me with the Giclée printing system, I make sure that my work is printed in the highest quality, with good papers and canvases.

\*What is a Giclee print?

The Giclée inkjet printing system consists of depositing the pigment in the form of small drops 'pulverizing' the support. It is a very high precision inkjet with pigmented inks. The image is printed in this way, achieving great detail in the shapes, and it can also produce wefts, patterns and continuous tone. In this way an impression is obtained with aspect of manual reproduction imitating traces, brushstrokes, etc.

\*How do you send the original prints and paintings?

All prints and original paintings are sent by the transport company DHL and urgent shipment, so you will receive in a few days at home, once the shipment sent a mail with the tracking number, you can also do the tracking through Etsy.

COPYRIGHT:

Copyright© VICTORIATELIER 2008-2023 All Rights Reserved.

Artworks represented in this listing and any text sequence of this product description is subject to intellectual property owned entirely by VictoriAtelier.


## Shipping and return policies

Loading


- Order today to get by

**Nov 13-26**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges not accepted




But please contact me if you have problems with your order


- Free shipping


- Ships from: **Spain**


Deliver to United States

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## FAQs

What is the difference between paper printing and rolled canvas prints?


The difference is that the paper needs to be framed with glass and the canvas only has to be stretched on wooden bars. Both prints are top quality Giclee with 100% cotton paper or canvas and acid free.


Do you send your canvases stretched?


Normally not, only in some cases within Europe under budget.


On prints, I can't find the size I need for my frame.


As there are many measures, I only have the standard measures easy to find in any frame house. But if you need a special measure, I will be happy to adjust the prints to your frames.


Do you sell your prints by downloading images?


No, the prints are printed by me with the Giclée printing system, I make sure that my work is printed in the highest quality, with good papers and canvases.


What is a Giclee print?


The Giclée inkjet printing system consists of depositing the pigment in the form of small drops 'pulverizing' the support. It is a very high precision inkjet with pigmented inks. The image is printed in this way, achieving great detail in the shapes, and it can also produce wefts, patterns and continuous tone. In this way an impression is obtained with aspect of manual reproduction imitating traces, brushstrokes, etc.


How do you send the original prints and paintings?


All prints and original paintings are sent by the transport company DHL and urgent shipment, so you will receive in a few days at home, once the shipment sent a mail with the tracking number, you can also do the tracking through Etsy.


## Reviews for this item (7)

5.0/5

item average

5.0Item quality

5.0Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Love it

Great quality

Beautiful

Happy customer

Lovely

Stunning

Fast shipping


Filter by category


Appearance (3)


Quality (2)


Description accuracy (1)


Shipping & Packaging (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[sheila](https://www.etsy.com/people/oygj1p1elyj582z3?ref=l_review)
Jul 12, 2025


It is beautiful. I love the colors. It is exactly as pictured. I can’t wait to get this framed. This is my second purchase and I am very pleased.



[sheila](https://www.etsy.com/people/oygj1p1elyj582z3?ref=l_review)
Jul 12, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/0218c3/94875405/iusa_75x75.94875405_jp53.jpg?version=0)

[santorinisilver](https://www.etsy.com/people/santorinisilver?ref=l_review)
May 29, 2025


Really lovely - thank you. Love it!!



![](https://i.etsystatic.com/iusa/0218c3/94875405/iusa_75x75.94875405_jp53.jpg?version=0)

[santorinisilver](https://www.etsy.com/people/santorinisilver?ref=l_review)
May 29, 2025


5 out of 5 stars
5

This item

[Michele Cousino](https://www.etsy.com/people/tr44r4yz52sswg89?ref=l_review)
Mar 10, 2025


Beautiful colors and design.love it!



[Michele Cousino](https://www.etsy.com/people/tr44r4yz52sswg89?ref=l_review)
Mar 10, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/42b8d8/82600335/iusa_75x75.82600335_3t7v.jpg?version=0)

[Amanda Lundquist Tindal](https://www.etsy.com/people/akdenton1?ref=l_review)
Feb 19, 2025


Just stunning!! I love it so much and it’s going to be framed in my living room!!



![](https://i.etsystatic.com/iusa/42b8d8/82600335/iusa_75x75.82600335_3t7v.jpg?version=0)

[Amanda Lundquist Tindal](https://www.etsy.com/people/akdenton1?ref=l_review)
Feb 19, 2025


View all reviews for this item

### Photos from reviews

![Maria added a photo of their purchase](https://i.etsystatic.com/iap/ec3136/5916351162/iap_300x300.5916351162_10uqzz58.jpg?version=0)

[![VictoriAtelier](https://i.etsystatic.com/iusa/f207bd/56049691/iusa_75x75.56049691_kkiu.jpg?version=0)](https://www.etsy.com/shop/VictoriAtelier?ref=shop_profile&listing_id=1567521330)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[VictoriAtelier](https://www.etsy.com/shop/VictoriAtelier?ref=shop_profile&listing_id=1567521330)

[Owned by Victoria](https://www.etsy.com/shop/VictoriAtelier?ref=shop_profile&listing_id=1567521330) \|

Valencia, Spain

4.9
(4k)


19.1k sales

17 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=6008675&referring_id=1567521330&referring_type=listing&recipient_id=6008675&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo2MDA4Njc1OjE3NjI4MDk4NTY6N2ZiMDlmY2IwYzM0OTlmMTU0MWE3MmI1NTcwNjllYjc%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1567521330%2Fmulticolor-watercolor-large-wall-art%3Famp%253Bclick_sum%3D16333fb8%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bpro%3D1%26amp%253Bsts%3D1)

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/VictoriAtelier?ref=lp_mys_mfts)

- [![Abstract painting print, Neutral colors large minimalist abstract art, Modern textured pastel multicolor, Trendy aesthetic large wall art](https://i.etsystatic.com/5321870/r/il/91acc4/7201148483/il_340x270.7201148483_4wq9.jpg)\\
\\
**Abstract painting print, Neutral colors large minimalist abstract art, Modern textured pastel multicolor, Trendy aesthetic large wall art**\\
\\
Sale Price $38.32\\
$38.32\\
\\
$47.90\\
Original Price $47.90\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1651050486/abstract-painting-print-neutral-colors?click_key=06511b0dc9e117c53cc65b46559690a0%3ALTf34df5da48ef1b00874bb36ca57239c38cc42fa9&click_sum=e33d0509&ls=r&ref=related-1&pro=1&sts=1&content_source=06511b0dc9e117c53cc65b46559690a0%253ALTf34df5da48ef1b00874bb36ca57239c38cc42fa9 "Abstract painting print, Neutral colors large minimalist abstract art, Modern textured pastel multicolor, Trendy aesthetic large wall art")




Add to Favorites


- [![Extra large Wall art print, Abstract painting, Bedroom print decor, Modern colorful abstract art, living room wall art](https://i.etsystatic.com/5321870/c/2542/2020/456/152/il/cdfcf6/5145676473/il_340x270.5145676473_m4et.jpg)\\
\\
**Extra large Wall art print, Abstract painting, Bedroom print decor, Modern colorful abstract art, living room wall art**\\
\\
Sale Price $38.32\\
$38.32\\
\\
$47.90\\
Original Price $47.90\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1091517842/extra-large-wall-art-print-abstract?click_key=06511b0dc9e117c53cc65b46559690a0%3ALT123a02362285374d6b66a39954925298e651a009&click_sum=e881c47a&ls=r&ref=related-2&pro=1&sts=1&content_source=06511b0dc9e117c53cc65b46559690a0%253ALT123a02362285374d6b66a39954925298e651a009 "Extra large Wall art print, Abstract painting, Bedroom print decor, Modern colorful abstract art, living room wall art")




Add to Favorites


- [![Modern dark blue abstract wall art print, Large blue and multicolor joyful abstract painting, Bright colorful eclectic wall art](https://i.etsystatic.com/5321870/c/2803/2228/35/371/il/60f229/5587030556/il_340x270.5587030556_b57r.jpg)\\
\\
**Modern dark blue abstract wall art print, Large blue and multicolor joyful abstract painting, Bright colorful eclectic wall art**\\
\\
Sale Price $38.32\\
$38.32\\
\\
$47.90\\
Original Price $47.90\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1632678601/modern-dark-blue-abstract-wall-art-print?click_key=06511b0dc9e117c53cc65b46559690a0%3ALTc0aa1be3e052fc428bb05a42ccbf37c9cd429b70&click_sum=d7ad591a&ls=r&ref=related-3&pro=1&sts=1&content_source=06511b0dc9e117c53cc65b46559690a0%253ALTc0aa1be3e052fc428bb05a42ccbf37c9cd429b70 "Modern dark blue abstract wall art print, Large blue and multicolor joyful abstract painting, Bright colorful eclectic wall art")




Add to Favorites


- [![Abstract painting with light colours, Green beige pink art, Modern contemporary abstract wall art print, Statement living room wall decor](https://i.etsystatic.com/5321870/c/2830/2249/96/326/il/7fa2c0/5364795162/il_340x270.5364795162_61kg.jpg)\\
\\
**Abstract painting with light colours, Green beige pink art, Modern contemporary abstract wall art print, Statement living room wall decor**\\
\\
Sale Price $38.32\\
$38.32\\
\\
$47.90\\
Original Price $47.90\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1567399300/abstract-painting-with-light-colours?click_key=06511b0dc9e117c53cc65b46559690a0%3ALTef384b5e9a46b0eb409c4cd8efb86b3b33332bac&click_sum=626f2e66&ls=r&ref=related-4&pro=1&sts=1&content_source=06511b0dc9e117c53cc65b46559690a0%253ALTef384b5e9a46b0eb409c4cd8efb86b3b33332bac "Abstract painting with light colours, Green beige pink art, Modern contemporary abstract wall art print, Statement living room wall decor")




Add to Favorites



Loading...

Loading


**Disclaimer:** Button/coin batteries may cause serious injury and even death if swallowed. Items containing button/coin batteries should not be easily accessible without the use of a tool. Sellers are responsible for complying with all applicable labeling, design, testing, packaging, and other safety requirements. Etsy assumes no responsibility for the accuracy or contents of a seller’s listing. If you have questions about button/coin batteries, contact the seller by sending a Message. See Etsy's [Terms of Use](https://www.etsy.com/legal/terms-of-use/?ref=product_safety_banner_info_button_batteries_risk#warranties) for more information.

Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Oct 29, 2025


[1580 favorites](https://www.etsy.com/listing/1567521330/multicolor-watercolor-large-wall-art/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?amp%3Bclick_sum=16333fb8&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Prints](https://www.etsy.com/c/art-and-collectibles/prints?amp%3Bclick_sum=16333fb8&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Giclée](https://www.etsy.com/c/art-and-collectibles/prints/giclee?amp%3Bclick_sum=16333fb8&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bpro=1&%3Bsts=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Furniture

[Italian Bombe Chest - US](https://www.etsy.com/market/italian_bombe_chest)

Prints

[Buy Swimming Art Online](https://www.etsy.com/market/swimming_art) [Shop Charleston Landscape](https://www.etsy.com/market/charleston_landscape) [Laser Burn PNG by LaserFocusFiles](https://www.etsy.com/listing/1674446356/laser-burn-png-3d-illusion-laser-cut) [Moody Winter Tree Line Painting by NineLivesPrints](https://www.etsy.com/listing/1737832934/moody-winter-tree-line-painting-vintage) [Shop Golf Quotes For Wall Art](https://www.etsy.com/market/golf_quotes_for_wall_art) [Flower Market Prints](https://www.etsy.com/listing/1051732830/flower-market-prints-digital-download) [Shop Prints from BalancingHome](https://www.etsy.com/shop/BalancingHome) [Larissa travel print - Greece travel poster](https://www.etsy.com/listing/1801901126/larissa-travel-print-greece-travel) [18x24 Spooky Greetings RYTA print of painting Halloween black cat art crescent moon Autumn Fall landscape interior home decor design office by RytasArtWorld](https://www.etsy.com/listing/1615772231/18x24-spooky-greetings-ryta-print-of)

Party Supplies

[Kentucky Derby Flags - US](https://www.etsy.com/market/kentucky_derby_flags) [TheBustedBeeBungalow - US](https://www.etsy.com/shop/TheBustedBeeBungalow)

Bracelets

[Paperclip Evil Eye Bracelet for Sale](https://www.etsy.com/market/paperclip_evil_eye_bracelet)

Bathroom

[Green Bath Curtain Fir Spruce Woodlands by OhanaModernDecor](https://www.etsy.com/listing/1137346308/landscape-shower-curtain-green-bath)

Scarves & Wraps

[Ready to ship Linen scarf for women and men](https://www.etsy.com/listing/1889964879/ready-to-ship-linen-scarf-for-women-and)

Books

[Handmade Glitter Resin Bookmark – Sparkly Epoxy Bookmark with Tassel – Custom Colors – Gift for Book Lovers – Stocking Stuffer - Books](https://www.etsy.com/listing/4325634742/handmade-glitter-resin-bookmark-sparkly)

Shopping

[Athletic Sport Laces for Sale](https://www.etsy.com/market/athletic_sport_laces)

Gender Neutral Adult Clothing

[Shop Gender-Neutral Adult Clothing from EnemyzeroApparel](https://www.etsy.com/shop/EnemyzeroApparel)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1567521330%2Fmulticolor-watercolor-large-wall-art%3Famp%253Bclick_sum%3D16333fb8%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bpro%3D1%26amp%253Bsts%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgwOTg1NjphZmY5MDRhYzUxNjBhNmE1MWVlMDM2NDQzMTAxYzZiZA==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1567521330%2Fmulticolor-watercolor-large-wall-art%3Famp%253Bclick_sum%3D16333fb8%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bpro%3D1%26amp%253Bsts%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1567521330/multicolor-watercolor-large-wall-art?amp;click_sum=16333fb8&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;pro=1&amp;sts=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1567521330%2Fmulticolor-watercolor-large-wall-art%3Famp%253Bclick_sum%3D16333fb8%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bpro%3D1%26amp%253Bsts%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for VictoriAtelier

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 2 days of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


Customs and import taxes

Buyers are responsible for any customs and import taxes that may apply. I'm not responsible for delays due to customs.


## Seller details

### Other details

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=6008675&referring_id=5321870&referring_type=shop&recipient_id=6008675&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: Abstract art print with a beige background and colorful circles, stripes, and dots. The print is framed in a light wood frame.](https://i.etsystatic.com/5321870/c/2884/2884/24/49/il/fae55b/5413964839/il_300x300.5413964839_k6ot.jpg)
- ![May include: An abstract painting with a layered, textured style. The painting features a variety of colors, including pink, blue, green, orange, and brown. The colors are blended and layered to create a sense of depth and movement. The painting is set against a light beige background.](https://i.etsystatic.com/5321870/r/il/28b3b1/5413619863/il_300x300.5413619863_tuj3.jpg)
- ![May include: Abstract art painting with a beige background and colorful circles and stripes. The painting is framed and hanging on a wall in a room with a glass chair and a brown leather armchair.](https://i.etsystatic.com/5321870/c/2333/2333/180/0/il/82ee56/5365472618/il_300x300.5365472618_3z72.jpg)
- ![May include: A large abstract painting with a beige background and colorful circles and stripes. The painting is framed in a gold frame and is hanging on a white wall. The painting is in a living room setting with a brown leather stool and a white couch.](https://i.etsystatic.com/5321870/c/2040/2040/331/131/il/97a288/5365468486/il_300x300.5365468486_1wyu.jpg)
- ![May include: Abstract art painting with a beige background and colorful circles and stripes. The painting is framed and hanging on a wall in a room with a white armchair and a wooden side table with a lamp.](https://i.etsystatic.com/5321870/c/2142/2142/45/0/il/4372cf/5413623825/il_300x300.5413623825_5i37.jpg)
- ![May include: A framed abstract painting with a beige background and colorful circles and stripes. The painting is hanging on a white wall above a wicker chair and a potted plant.](https://i.etsystatic.com/5321870/r/il/a98000/5365453926/il_300x300.5365453926_e7hu.jpg)
- ![May include: Abstract art print with a light brown background and colorful shapes and dots. The print is framed in a light brown wood frame.](https://i.etsystatic.com/5321870/r/il/ac010c/5365453830/il_300x300.5365453830_2mvo.jpg)

- ![](https://i.etsystatic.com/iap/ec3136/5916351162/iap_640x640.5916351162_10uqzz58.jpg?version=0)











5 out of 5 stars





- Finish:

Streched canvas ready to hang

- Size:

40"x40" - 100x100cm Square


It is a wonderful painting and this is my second one. Great quality

![](https://i.etsystatic.com/iusa/8d9f48/85937897/iusa_75x75.85937897_9r6l.jpg?version=0)

Apr 13, 2024


[Maria Michalaki](https://www.etsy.com/people/byl6orrv)

Purchased item:

[![Multicolor watercolor large wall art print, Modern contemporary abstract painting, Statement living room wall decor in light colors](https://i.etsystatic.com/5321870/c/2884/2292/24/345/il/fae55b/5413964839/il_170x135.5413964839_k6ot.jpg)\\
\\
Multicolor watercolor large wall art print, Modern contemporary abstract painting, Statement living room wall decor in light colors\\
\\
Sale Price $38.32\\
$38.32\\
\\
$47.90\\
Original Price $47.90\\
\\
\\
(20% off)](https://www.etsy.com/listing/1567521330/multicolor-watercolor-large-wall-art?ref=ap-listing)

Purchased item:

[![Multicolor watercolor large wall art print, Modern contemporary abstract painting, Statement living room wall decor in light colors](https://i.etsystatic.com/5321870/c/2884/2292/24/345/il/fae55b/5413964839/il_170x135.5413964839_k6ot.jpg)\\
\\
Multicolor watercolor large wall art print, Modern contemporary abstract painting, Statement living room wall decor in light colors\\
\\
Sale Price $38.32\\
$38.32\\
\\
$47.90\\
Original Price $47.90\\
\\
\\
(20% off)](https://www.etsy.com/listing/1567521330/multicolor-watercolor-large-wall-art?ref=ap-listing)