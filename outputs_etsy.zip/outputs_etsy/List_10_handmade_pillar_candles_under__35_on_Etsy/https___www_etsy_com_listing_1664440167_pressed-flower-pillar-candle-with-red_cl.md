[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1664440167/pressed-flower-pillar-candle-with-red?amp;click_sum=a520dfca&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3&amp;sts=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=a520dfca&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=a520dfca&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=a520dfca&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=a520dfca&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-3)
- [Pillar Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/pillar-candles?amp%3Bclick_sum=a520dfca&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-4)


Add to Favorites


- ![May include: White pillar candle with pressed flowers and greenery. The candle has a burgundy rose, pink flowers, and green ferns pressed into the wax.](https://i.etsystatic.com/19818295/r/il/5435c6/5799385993/il_794xN.5799385993_k6p5.jpg)
- ![May include: Two white pillar candles with pressed flowers and greenery. The candle on the left has a pink rose, a burgundy rose, fern, and forget-me-nots. The candle on the right has pink roses. Both candles are on wooden rounds.](https://i.etsystatic.com/19818295/r/il/98b3b4/5751306752/il_794xN.5751306752_1849.jpg)
- ![May include: Two white pillar candles with pressed flowers and greenery embedded in the wax. The candle on the left has a fern, small blue flowers, and pink roses. The candle on the right has pink roses in a heart shape. Both candles are on wooden slices.](https://i.etsystatic.com/19818295/r/il/41159c/5799386339/il_794xN.5799386339_ck08.jpg)
- ![May include: Two white pillar candles with pressed flowers embedded in the wax. The candle on the left has pink and purple flowers and green ferns. The candle on the right has blue and purple flowers and green ferns. Both candles are sitting on wooden rounds.](https://i.etsystatic.com/19818295/r/il/acb959/5799387571/il_794xN.5799387571_jp2o.jpg)
- ![May include: A white pillar candle with pressed flowers and greenery. The candle is on a wooden slice and has a white flower in the background.](https://i.etsystatic.com/19818295/r/il/e4754d/5751306482/il_794xN.5751306482_69qa.jpg)
- ![May include: A white pillar candle with pressed dried flowers and ferns embedded in the wax. The candle is sitting on a wooden slice and a white flower is in the background.](https://i.etsystatic.com/19818295/r/il/c6ea5f/5818131943/il_794xN.5818131943_ocww.jpg)
- ![May include: Two white pillar candles with pressed flowers and greenery embedded in the wax. The candles are on wooden slices and a white flower is in the foreground.](https://i.etsystatic.com/19818295/r/il/bc6a28/5818132085/il_794xN.5818132085_c8oh.jpg)
- ![May include: Three white pillar candles with pressed flowers and greenery. The candles are on a natural wood base and a burlap surface.](https://i.etsystatic.com/19818295/r/il/d63a9b/5799387319/il_794xN.5799387319_no2x.jpg)
- ![May include: Three white pillar candles with pressed flowers and greenery on them. The candles are on wood slices and a burlap surface.](https://i.etsystatic.com/19818295/r/il/3a7844/5818131637/il_794xN.5818131637_ee5m.jpg)
- ![May include: Three white pillar candles with pressed flowers embedded in the wax. The candles are on wooden slices. The flowers are in shades of pink, red, blue, and green.](https://i.etsystatic.com/19818295/r/il/5b9137/5770069756/il_794xN.5770069756_miam.jpg)

- ![May include: White pillar candle with pressed flowers and greenery. The candle has a burgundy rose, pink flowers, and green ferns pressed into the wax.](https://i.etsystatic.com/19818295/r/il/5435c6/5799385993/il_75x75.5799385993_k6p5.jpg)
- ![May include: Two white pillar candles with pressed flowers and greenery. The candle on the left has a pink rose, a burgundy rose, fern, and forget-me-nots. The candle on the right has pink roses. Both candles are on wooden rounds.](https://i.etsystatic.com/19818295/r/il/98b3b4/5751306752/il_75x75.5751306752_1849.jpg)
- ![May include: Two white pillar candles with pressed flowers and greenery embedded in the wax. The candle on the left has a fern, small blue flowers, and pink roses. The candle on the right has pink roses in a heart shape. Both candles are on wooden slices.](https://i.etsystatic.com/19818295/r/il/41159c/5799386339/il_75x75.5799386339_ck08.jpg)
- ![May include: Two white pillar candles with pressed flowers embedded in the wax. The candle on the left has pink and purple flowers and green ferns. The candle on the right has blue and purple flowers and green ferns. Both candles are sitting on wooden rounds.](https://i.etsystatic.com/19818295/r/il/acb959/5799387571/il_75x75.5799387571_jp2o.jpg)
- ![May include: A white pillar candle with pressed flowers and greenery. The candle is on a wooden slice and has a white flower in the background.](https://i.etsystatic.com/19818295/r/il/e4754d/5751306482/il_75x75.5751306482_69qa.jpg)
- ![May include: A white pillar candle with pressed dried flowers and ferns embedded in the wax. The candle is sitting on a wooden slice and a white flower is in the background.](https://i.etsystatic.com/19818295/r/il/c6ea5f/5818131943/il_75x75.5818131943_ocww.jpg)
- ![May include: Two white pillar candles with pressed flowers and greenery embedded in the wax. The candles are on wooden slices and a white flower is in the foreground.](https://i.etsystatic.com/19818295/r/il/bc6a28/5818132085/il_75x75.5818132085_c8oh.jpg)
- ![May include: Three white pillar candles with pressed flowers and greenery. The candles are on a natural wood base and a burlap surface.](https://i.etsystatic.com/19818295/r/il/d63a9b/5799387319/il_75x75.5799387319_no2x.jpg)
- ![May include: Three white pillar candles with pressed flowers and greenery on them. The candles are on wood slices and a burlap surface.](https://i.etsystatic.com/19818295/r/il/3a7844/5818131637/il_75x75.5818131637_ee5m.jpg)
- ![May include: Three white pillar candles with pressed flowers embedded in the wax. The candles are on wooden slices. The flowers are in shades of pink, red, blue, and green.](https://i.etsystatic.com/19818295/r/il/5b9137/5770069756/il_75x75.5770069756_miam.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1664440167%2Fpressed-flower-pillar-candle-with-red%23report-overlay-trigger)

Low in stock, only 1 left

Price:$38.00


Loading


# Pressed Flower Pillar Candle with Red Roses, 6 x 3 inches, Botanical Pillar Candles, Pressed Flower Decor and Gifts, Wedding Pillar Candles

[Wolfatthedoorcreates](https://www.etsy.com/shop/Wolfatthedoorcreates)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1664440167/pressed-flower-pillar-candle-with-red?amp;click_sum=a520dfca&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3&amp;sts=1#reviews)

Arrives soon! Get it by

Nov 14-17


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

- Width: 3 inches



Height: 6 inches


Standard size 6 inch by 3 inch white pillar candle with red rose and other pressed flowers and botanicals grown in my garden. Flowers on front and back of the candle (as pictured), making it beautiful at every angle. All candles are shipped with a set of matches.

The process of making these candles begins with growing the flowers in my garden in the Santa Cruz mountains in California. From there, I pick and hand press all the flowers and leaves, apply them to the candles, and then seal the flowers into the candles by dipping them in a beeswax and paraffin candle wax.

These candles burn beautifully and will lighten up your table, mantle, altar, events, and more. I have been making these candles for over 25 years and many people tell me they have displayed their candles for years and years.

Candle is unscented. Custom candles and sets of pillars and tapers available upon request. Every candle is handmade and unique. No two are alike.


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-17**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges not accepted




But please contact me if you have problems with your order


- Ships from: **Watsonville, CA**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Be the first to review this item

No reviews yet. See what customers say about other items from this shop.


Read reviews for other items


[![Wolfatthedoorcreates](https://i.etsystatic.com/iusa/7a242d/68804128/iusa_75x75.68804128_b7a6.jpg?version=0)](https://www.etsy.com/shop/Wolfatthedoorcreates?ref=shop_profile&listing_id=1664440167)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[Wolfatthedoorcreates](https://www.etsy.com/shop/Wolfatthedoorcreates?ref=shop_profile&listing_id=1664440167)

[Owned by Stacey Cooper](https://www.etsy.com/shop/Wolfatthedoorcreates?ref=shop_profile&listing_id=1664440167) \|

United States

5.0
(237)


852 sales

6 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=207101420&referring_id=1664440167&referring_type=listing&recipient_id=207101420&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyMDcxMDE0MjA6MTc2MjgyNjkxNTozMWUxNGZhMTBiMmU0MDUyNzE5MGM1NDNkOWNiYTRmMA%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1664440167%2Fpressed-flower-pillar-candle-with-red%3Famp%253Bclick_sum%3Da520dfca%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bsts%3D1)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## All reviews from this shop (237)

Show all

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Why are these reviews shown?

All reviews are from verified buyers. Reviews are shown automatically based on factors like recency, whether they include comments, your chosen language, and whether the rating reflects the typical experience with the shop.

## More from this shop

[Visit shop](https://www.etsy.com/shop/Wolfatthedoorcreates?ref=lp_mys_mfts)

- [![Pressed Flower Pillar Candle: 3-Inch Botanical Candle](https://i.etsystatic.com/19818295/r/il/1d643a/6621515728/il_340x270.6621515728_sm9u.jpg)\\
\\
**Pressed Flower Pillar Candle: 3-Inch Botanical Candle**\\
\\
$20.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1855463702/pressed-flower-pillar-candle-3-inch?click_key=92d5a00f0cb5a3aef7a4d2d357992e8a%3ALT92b55715754a1f02554c3aee79cd972efbb9f587&click_sum=f810588c&ls=r&ref=related-1&sts=1&content_source=92d5a00f0cb5a3aef7a4d2d357992e8a%253ALT92b55715754a1f02554c3aee79cd972efbb9f587 "Pressed Flower Pillar Candle: 3-Inch Botanical Candle")




Add to Favorites


- [![Pressed Flower Pillar Candle, 4 x 4 in, Botanical Pillar Candles, Floral Candle Centerpiece, Floral Wedding Pillar Candle, Nature Decor](https://i.etsystatic.com/19818295/r/il/1ec2b2/4852174443/il_340x270.4852174443_onoa.jpg)\\
\\
**Pressed Flower Pillar Candle, 4 x 4 in, Botanical Pillar Candles, Floral Candle Centerpiece, Floral Wedding Pillar Candle, Nature Decor**\\
\\
$38.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1443946800/pressed-flower-pillar-candle-4-x-4-in?click_key=92d5a00f0cb5a3aef7a4d2d357992e8a%3ALTc069a1c4dad8fa9aa180b26b60f67ffcec40ec55&click_sum=039327fb&ls=r&ref=related-2&sts=1&content_source=92d5a00f0cb5a3aef7a4d2d357992e8a%253ALTc069a1c4dad8fa9aa180b26b60f67ffcec40ec55 "Pressed Flower Pillar Candle, 4 x 4 in, Botanical Pillar Candles, Floral Candle Centerpiece, Floral Wedding Pillar Candle, Nature Decor")




Add to Favorites


- [![Pressed Flower Pillar Candle - 6 in x 3 in](https://i.etsystatic.com/19818295/r/il/53f53a/5486749707/il_340x270.5486749707_4l3c.jpg)\\
\\
**Pressed Flower Pillar Candle - 6 in x 3 in**\\
\\
$35.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1582152146/pressed-flower-pillar-candle-6-in-x-3-in?click_key=92d5a00f0cb5a3aef7a4d2d357992e8a%3ALT5c5e3cb5c0f641236670cc0c171bb2ef25c756a2&click_sum=f0abe0bd&ls=r&ref=related-3&sts=1&content_source=92d5a00f0cb5a3aef7a4d2d357992e8a%253ALT5c5e3cb5c0f641236670cc0c171bb2ef25c756a2 "Pressed Flower Pillar Candle - 6 in x 3 in")




Add to Favorites


- [![Pressed Flower Tall Pillar Candle - 3 inch by 9 inch](https://i.etsystatic.com/19818295/r/il/927bbb/7237691851/il_340x270.7237691851_5bji.jpg)\\
\\
**Pressed Flower Tall Pillar Candle - 3 inch by 9 inch**\\
\\
$45.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4367615491/pressed-flower-tall-pillar-candle-3-inch?click_key=92d5a00f0cb5a3aef7a4d2d357992e8a%3ALT96aac234767207306b375f7fa11c02b42215ef16&click_sum=9adb0781&ls=r&ref=related-4&sts=1&content_source=92d5a00f0cb5a3aef7a4d2d357992e8a%253ALT96aac234767207306b375f7fa11c02b42215ef16 "Pressed Flower Tall Pillar Candle - 3 inch by 9 inch")




Add to Favorites



Loading...

Loading


**Disclaimer:** Button/coin batteries may cause serious injury and even death if swallowed. Items containing button/coin batteries should not be easily accessible without the use of a tool. Sellers are responsible for complying with all applicable labeling, design, testing, packaging, and other safety requirements. Etsy assumes no responsibility for the accuracy or contents of a seller’s listing. If you have questions about button/coin batteries, contact the seller by sending a Message. See Etsy's [Terms of Use](https://www.etsy.com/legal/terms-of-use/?ref=product_safety_banner_info_button_batteries_risk#warranties) for more information.

Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading wedding form

Loading


## Top wedding searches to shop

[![](https://i.etsystatic.com/19757930/c/1333/1333/0/301/il/cfe72f/3482678762/il_300x300.3482678762_pxw3.jpg)\\
Bridesmaid gifts](https://www.etsy.com/search?q=bridesmaid+gifts&mosv=sese&moci=635510339037&mosi=618520640322&featured_listing=1110003408&ref=wedding_recs_lp_bridesmaid_gifts)

[![](https://i.etsystatic.com/19483987/r/il/42cd8d/2512481731/il_300x300.2512481731_8gz7.jpg)\\
Groomsmen gifts](https://www.etsy.com/search?q=groomsmen+gifts&mosv=sese&moci=635510339037&mosi=635510910189&featured_listing=761677858&ref=wedding_recs_lp_groomsmen_gifts)

[![](https://i.etsystatic.com/6748817/c/2000/2000/0/828/il/b140dc/3394740672/il_300x300.3394740672_mong.jpg)\\
Wedding gifts](https://www.etsy.com/search?q=wedding+gifts&mosv=sese&moci=635510339037&mosi=618520762754&featured_listing=1087712798&ref=wedding_recs_lp_wedding_gifts)

[![](https://i.etsystatic.com/5354512/r/il/35af5c/5783958379/il_300x300.5783958379_pio7.jpg)\\
Engagement gifts](https://www.etsy.com/search?q=engagement+gifts&mosv=sese&moci=635510339037&mosi=635511121285&featured_listing=190344599&ref=wedding_recs_lp_engagement_gifts)

Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 5, 2025


[One favorite](https://www.etsy.com/listing/1664440167/pressed-flower-pillar-candle-with-red/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=a520dfca&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=a520dfca&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=a520dfca&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=a520dfca&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Pillar Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/pillar-candles?amp%3Bclick_sum=a520dfca&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=breadcrumb_listing)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1664440167%2Fpressed-flower-pillar-candle-with-red%3Famp%253Bclick_sum%3Da520dfca%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bsts%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgyNjkxNToxMmIyNDllOTcyNDlkODgxZjBiMmFiYWQzNTQ0MTM1Mg==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1664440167%2Fpressed-flower-pillar-candle-with-red%3Famp%253Bclick_sum%3Da520dfca%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bsts%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1664440167/pressed-flower-pillar-candle-with-red?amp;click_sum=a520dfca&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3&amp;sts=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1664440167%2Fpressed-flower-pillar-candle-with-red%3Famp%253Bclick_sum%3Da520dfca%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bsts%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for Wolfatthedoorcreates

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: not accepted

Please contact the seller if you have any problems with your order.

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## Seller details

### Other details

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=207101420&referring_id=19818295&referring_type=shop&recipient_id=207101420&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: White pillar candle with pressed flowers and greenery. The candle has a burgundy rose, pink flowers, and green ferns pressed into the wax.](https://i.etsystatic.com/19818295/r/il/5435c6/5799385993/il_300x300.5799385993_k6p5.jpg)
- ![May include: Two white pillar candles with pressed flowers and greenery. The candle on the left has a pink rose, a burgundy rose, fern, and forget-me-nots. The candle on the right has pink roses. Both candles are on wooden rounds.](https://i.etsystatic.com/19818295/r/il/98b3b4/5751306752/il_300x300.5751306752_1849.jpg)
- ![May include: Two white pillar candles with pressed flowers and greenery embedded in the wax. The candle on the left has a fern, small blue flowers, and pink roses. The candle on the right has pink roses in a heart shape. Both candles are on wooden slices.](https://i.etsystatic.com/19818295/r/il/41159c/5799386339/il_300x300.5799386339_ck08.jpg)
- ![May include: Two white pillar candles with pressed flowers embedded in the wax. The candle on the left has pink and purple flowers and green ferns. The candle on the right has blue and purple flowers and green ferns. Both candles are sitting on wooden rounds.](https://i.etsystatic.com/19818295/r/il/acb959/5799387571/il_300x300.5799387571_jp2o.jpg)
- ![May include: A white pillar candle with pressed flowers and greenery. The candle is on a wooden slice and has a white flower in the background.](https://i.etsystatic.com/19818295/r/il/e4754d/5751306482/il_300x300.5751306482_69qa.jpg)
- ![May include: A white pillar candle with pressed dried flowers and ferns embedded in the wax. The candle is sitting on a wooden slice and a white flower is in the background.](https://i.etsystatic.com/19818295/r/il/c6ea5f/5818131943/il_300x300.5818131943_ocww.jpg)
- ![May include: Two white pillar candles with pressed flowers and greenery embedded in the wax. The candles are on wooden slices and a white flower is in the foreground.](https://i.etsystatic.com/19818295/r/il/bc6a28/5818132085/il_300x300.5818132085_c8oh.jpg)
- ![May include: Three white pillar candles with pressed flowers and greenery. The candles are on a natural wood base and a burlap surface.](https://i.etsystatic.com/19818295/r/il/d63a9b/5799387319/il_300x300.5799387319_no2x.jpg)
- ![May include: Three white pillar candles with pressed flowers and greenery on them. The candles are on wood slices and a burlap surface.](https://i.etsystatic.com/19818295/r/il/3a7844/5818131637/il_300x300.5818131637_ee5m.jpg)
- ![May include: Three white pillar candles with pressed flowers embedded in the wax. The candles are on wooden slices. The flowers are in shades of pink, red, blue, and green.](https://i.etsystatic.com/19818295/r/il/5b9137/5770069756/il_300x300.5770069756_miam.jpg)

Scroll previousScroll next