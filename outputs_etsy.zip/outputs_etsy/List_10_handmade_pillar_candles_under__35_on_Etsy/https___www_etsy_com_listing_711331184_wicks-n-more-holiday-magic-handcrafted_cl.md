[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/711331184/wicks-n-more-holiday-magic-handcrafted?amp;click_sum=3c46552f&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;sts=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=3c46552f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=3c46552f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=3c46552f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=3c46552f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-3)
- [Pillar Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/pillar-candles?amp%3Bclick_sum=3c46552f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-4)


Add to Favorites


- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 1](https://i.etsystatic.com/19242992/r/il/e2088f/5501206094/il_794xN.5501206094_5r4a.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 2](https://i.etsystatic.com/19242992/r/il/f7bb44/5501210160/il_794xN.5501210160_8mad.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 3](https://i.etsystatic.com/19242992/r/il/eb0508/5549317021/il_794xN.5549317021_hna8.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 4](https://i.etsystatic.com/19242992/r/il/6e5551/4434947215/il_794xN.4434947215_lsy4.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 5](https://i.etsystatic.com/19242992/r/il/9009c8/4434949433/il_794xN.4434949433_td6r.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 6](https://i.etsystatic.com/19242992/r/il/d444f7/4434948913/il_794xN.4434948913_kx13.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 7](https://i.etsystatic.com/19242992/r/il/82ff3f/5549315249/il_794xN.5549315249_dsls.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 8](https://i.etsystatic.com/19242992/r/il/1b0772/5501208888/il_794xN.5501208888_q14t.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 9](https://i.etsystatic.com/19242992/r/il/204ce8/2051291925/il_794xN.2051291925_jhii.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 10](https://i.etsystatic.com/19242992/r/il/ec400f/5501211510/il_794xN.5501211510_4rfs.jpg)

- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 1](https://i.etsystatic.com/19242992/r/il/e2088f/5501206094/il_75x75.5501206094_5r4a.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 2](https://i.etsystatic.com/19242992/r/il/f7bb44/5501210160/il_75x75.5501210160_8mad.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 3](https://i.etsystatic.com/19242992/r/il/eb0508/5549317021/il_75x75.5549317021_hna8.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 4](https://i.etsystatic.com/19242992/r/il/6e5551/4434947215/il_75x75.4434947215_lsy4.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 5](https://i.etsystatic.com/19242992/r/il/9009c8/4434949433/il_75x75.4434949433_td6r.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 6](https://i.etsystatic.com/19242992/r/il/d444f7/4434948913/il_75x75.4434948913_kx13.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 7](https://i.etsystatic.com/19242992/r/il/82ff3f/5549315249/il_75x75.5549315249_dsls.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 8](https://i.etsystatic.com/19242992/r/il/1b0772/5501208888/il_75x75.5501208888_q14t.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 9](https://i.etsystatic.com/19242992/r/il/204ce8/2051291925/il_75x75.2051291925_jhii.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 10](https://i.etsystatic.com/19242992/r/il/ec400f/5501211510/il_75x75.5501211510_4rfs.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F711331184%2Fwicks-n-more-holiday-magic-handcrafted%23report-overlay-trigger)

In 7 carts

Price:$26.00+


Loading


# Wicks n More Holiday Magic Handcrafted Scented Pillar Candle

Made by [WicksnMoreCandles](https://www.etsy.com/shop/WicksnMoreCandles)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/711331184/wicks-n-more-holiday-magic-handcrafted?amp;click_sum=3c46552f&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;sts=1#reviews)

Ships from Mississippi

Arrives soon! Get it by

Nov 17-20


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Size


Select an option

3x3 inches ($26.00)

3x4 inches ($28.00)

3x6 inches ($31.00)

4x4 inches ($36.00)

4x6 inches ($46.00)

Please select an option


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Made by [WicksnMoreCandles](https://www.etsy.com/shop/WicksnMoreCandles)

- Ships from Mississippi! Shorter shipping distances are

kinder to the planet

Ordering items closer to you is more likely to reduce your purchase's carbon footprint.


- Materials: Wax type: Paraffin


"Holiday Magic" hand-crafted pillar candle from Wicks n More Candle Co.

An all time Wicks n More best seller. Its traditional holiday red and green colors brighten your festive gatherings and its rich scents of mixed holiday spices are sure to be memorable for all.

The proprietary fragrance combination of apple, cinnamon, clove and a touch of vanilla combine to make this perfect holiday fragrance sure to please.

Each of our candles are hand poured in our factory located in Northeast Mississippi and we are proud to offer a quality American made product from start to finish. Candles are sold individually so that you can choose the size and quantity that works best for you.

Variations in color and finish are inherent to the handmade process. Slight imperfections are to be expected and reflect the unique character of each individual candle.


## Shipping and return policies

Loading


- Order today to get by

**Nov 17-20**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges not accepted




But please contact me if you have problems with your order


- Free shipping


- Ships from: **Tupelo, MS**


Deliver to United States

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (59)

5.0/5

item average

5.0Item quality

4.8Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Beautiful

Smells amazing

Fast shipping

Well packaged

Love it

Great quality

Looks great


Filter by category


Appearance (35)


Quality (24)


Shipping & Packaging (14)


Description accuracy (6)


Seller service (4)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Abby Zimmerman](https://www.etsy.com/people/AbbynMinnie?ref=l_review)
Oct 31, 2025


Beautiful candles with a wonderful scent! Can't wait to put these out for the holidays!



[Abby Zimmerman](https://www.etsy.com/people/AbbynMinnie?ref=l_review)
Oct 31, 2025


5 out of 5 stars
5

This item

[Abby Zimmerman](https://www.etsy.com/people/AbbynMinnie?ref=l_review)
Oct 31, 2025


Beautiful candles with a wonderful scent! Can't wait to put these out for the holidays!



[Abby Zimmerman](https://www.etsy.com/people/AbbynMinnie?ref=l_review)
Oct 31, 2025


5 out of 5 stars
5

This item

[Abby Zimmerman](https://www.etsy.com/people/AbbynMinnie?ref=l_review)
Oct 31, 2025


Beautiful candles with a wonderful scent! Can't wait to put these out for the holidays!



[Abby Zimmerman](https://www.etsy.com/people/AbbynMinnie?ref=l_review)
Oct 31, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/94c3a9/26580344/iusa_75x75.26580344_foqk.jpg?version=0)

[Kathy Konen](https://www.etsy.com/people/kmk706?ref=l_review)
Oct 7, 2025


The candle looks great and it SMELLS great too.



![](https://i.etsystatic.com/iusa/94c3a9/26580344/iusa_75x75.26580344_foqk.jpg?version=0)

[Kathy Konen](https://www.etsy.com/people/kmk706?ref=l_review)
Oct 7, 2025


View all reviews for this item

### Photos from reviews

![Georgeann added a photo of their purchase](https://i.etsystatic.com/iap/33ac78/5600522768/iap_300x300.5600522768_enydh3nj.jpg?version=0)

![Quipquot added a photo of their purchase](https://i.etsystatic.com/iap/20344c/4465266068/iap_300x300.4465266068_syoamc1a.jpg?version=0)

![Jill added a photo of their purchase](https://i.etsystatic.com/iap/aeb19c/3565404148/iap_300x300.3565404148_1ozm3z60.jpg?version=0)

![Roland added a photo of their purchase](https://i.etsystatic.com/iap/f08c00/3558310073/iap_300x300.3558310073_31eivv30.jpg?version=0)

![martie added a photo of their purchase](https://i.etsystatic.com/iap/353b54/2737058884/iap_300x300.2737058884_8kszm4dp.jpg?version=0)

[![WicksnMoreCandles](https://i.etsystatic.com/iusa/4d6e17/111363569/iusa_75x75.111363569_khhs.jpg?version=0)](https://www.etsy.com/shop/WicksnMoreCandles?ref=shop_profile&listing_id=711331184)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[WicksnMoreCandles](https://www.etsy.com/shop/WicksnMoreCandles?ref=shop_profile&listing_id=711331184)

[Owned by Shane](https://www.etsy.com/shop/WicksnMoreCandles?ref=shop_profile&listing_id=711331184) \|

Tupelo, Mississippi

4.9
(1.2k)


5.7k sales

6 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=198363071&referring_id=711331184&referring_type=listing&recipient_id=198363071&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoxOTgzNjMwNzE6MTc2MjgyNTQ2MDpiYTI1OTQxMDNhNWY2MTA5ZGJiMTRmYjRmOTc1MTg0Zg%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F711331184%2Fwicks-n-more-holiday-magic-handcrafted%3Famp%253Bclick_sum%3D3c46552f%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bsts%3D1)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/WicksnMoreCandles?ref=lp_mys_mfts)

- [![Wicks n More Red Scented Hand-Crafted Pillar Candle](https://i.etsystatic.com/19242992/r/il/bf6a3c/4387566034/il_340x270.4387566034_hfx9.jpg)\\
\\
**Wicks n More Red Scented Hand-Crafted Pillar Candle**\\
\\
$26.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/672215502/wicks-n-more-red-scented-hand-crafted?click_key=4906c4ff7c59eaebbcf0dd64ac609109%3ALT5a3660ac7c2c432e8a1f85539b623a2b297fac13&click_sum=9855cfe5&ls=r&ref=related-1&sts=1&content_source=4906c4ff7c59eaebbcf0dd64ac609109%253ALT5a3660ac7c2c432e8a1f85539b623a2b297fac13 "Wicks n More Red Scented Hand-Crafted Pillar Candle")




Add to Favorites


- [![Wicks n More Warmest Wishes Hand-Crafted Scented Pillar Candle](https://i.etsystatic.com/19242992/c/2048/1627/0/201/il/ef6966/2203081629/il_340x270.2203081629_11qi.jpg)\\
\\
**Wicks n More Warmest Wishes Hand-Crafted Scented Pillar Candle**\\
\\
$26.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/686072947/wicks-n-more-warmest-wishes-hand-crafted?click_key=4906c4ff7c59eaebbcf0dd64ac609109%3ALTd06a2d94ef2ae06f4c2630a52f9e845b6b35e89c&click_sum=50ebdc00&ls=r&ref=related-2&sts=1&content_source=4906c4ff7c59eaebbcf0dd64ac609109%253ALTd06a2d94ef2ae06f4c2630a52f9e845b6b35e89c "Wicks n More Warmest Wishes Hand-Crafted Scented Pillar Candle")




Add to Favorites


- [![Wicks n More Evergreen Hand-Crafted Scented Pillar Candle](https://i.etsystatic.com/19242992/r/il/7c90d4/5501214350/il_340x270.5501214350_h7wh.jpg)\\
\\
**Wicks n More Evergreen Hand-Crafted Scented Pillar Candle**\\
\\
$26.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/686037909/wicks-n-more-evergreen-hand-crafted?click_key=4906c4ff7c59eaebbcf0dd64ac609109%3ALT34a531364abdc95d012432298e893a0ee0f4b498&click_sum=358f5573&ls=r&ref=related-3&sts=1&content_source=4906c4ff7c59eaebbcf0dd64ac609109%253ALT34a531364abdc95d012432298e893a0ee0f4b498 "Wicks n More Evergreen Hand-Crafted Scented Pillar Candle")




Add to Favorites


- [![Wicks n More Linen Crisp Hand-Crafted Scented Pillar Candle](https://i.etsystatic.com/19242992/r/il/bf274d/3977101525/il_340x270.3977101525_qtva.jpg)\\
\\
**Wicks n More Linen Crisp Hand-Crafted Scented Pillar Candle**\\
\\
$26.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/681372625/wicks-n-more-linen-crisp-hand-crafted?click_key=6e966dd23a297ef0b806c4272f828debaaca72ee%3A681372625&click_sum=4842e7c9&ref=related-4&sts=1 "Wicks n More Linen Crisp Hand-Crafted Scented Pillar Candle")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 10, 2025


[286 favorites](https://www.etsy.com/listing/711331184/wicks-n-more-holiday-magic-handcrafted/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=3c46552f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=3c46552f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=3c46552f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=3c46552f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Pillar Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/pillar-candles?amp%3Bclick_sum=3c46552f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Home Decor

[Custom Martha's Vineyard Ornament - Home Decor](https://www.etsy.com/listing/4300658356/custom-marthas-vineyard-ornament-faux) [Shop Sea Glass Framed Pictures](https://www.etsy.com/market/sea_glass_framed_pictures) [Lorikeet Ceramic Tile by FlyingCreatureTiles](https://www.etsy.com/listing/265565200/lorikeet-ceramic-tile-rainbow-sun) [Buy Ireland Photo Frame Online](https://www.etsy.com/market/ireland_photo_frame) [Shop Home Decor from UpGreat](https://www.etsy.com/shop/UpGreat) [Shop 2ft Ceramic Santa](https://www.etsy.com/market/2ft_ceramic_santa) [Shop Terracotta Picture Frames](https://www.etsy.com/market/terracotta_picture_frames) [Turquoise Doily Christmas Ornament - Home Decor](https://www.etsy.com/listing/1350311079/turquoise-doily-christmas-ornament-white) [Fantasy Beach Scene](https://www.etsy.com/listing/1823865229/fantasy-beach-scene-inspired-comic-art) [Shop Pug Pugnacious](https://www.etsy.com/market/pug_pugnacious) [Small Table Flower Arrangement for Sale](https://www.etsy.com/market/small_table_flower_arrangement)

Books

[Enemies to lovers - Bookmark](https://www.etsy.com/listing/1865089163/enemies-to-lovers-bookmark-gift-for-book) [I Hate It Here Lined Spiral Notebook - Books](https://www.etsy.com/listing/1839673339/i-hate-it-here-lined-spiral-notebook)

Outdoor & Garden

[Shop Whiskey Bottle Hummingbird Feeder](https://www.etsy.com/market/whiskey_bottle_hummingbird_feeder)

Totes

[Shop Arabic Tote Bags](https://www.etsy.com/market/arabic_tote_bags)

Collectibles

[7 Gingerbread Christmas Ornaments](https://www.etsy.com/listing/1200062851/7-gingerbread-christmas-ornaments-o)

Rings

[Green Malachite Ring in Brass by SinghHandmadeDesigns](https://www.etsy.com/listing/4320352597/green-malachite-ring-in-brass-oval-stone)

Shopping

[Buy Chelby Online](https://www.etsy.com/market/chelby)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F711331184%2Fwicks-n-more-holiday-magic-handcrafted%3Famp%253Bclick_sum%3D3c46552f%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bsts%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgyNTQ2MDoyZDc2ODk2NDcyZjU4OWEwZDQ0OGQ5YTc1YTIzNTI5Mw==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F711331184%2Fwicks-n-more-holiday-magic-handcrafted%3Famp%253Bclick_sum%3D3c46552f%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bsts%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/711331184/wicks-n-more-holiday-magic-handcrafted?amp;click_sum=3c46552f&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;sts=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F711331184%2Fwicks-n-more-holiday-magic-handcrafted%3Famp%253Bclick_sum%3D3c46552f%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bsts%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for WicksnMoreCandles

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 12 hours of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## Seller details

### Business registration number

### Location

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=198363071&referring_id=19242992&referring_type=shop&recipient_id=198363071&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 1](https://i.etsystatic.com/19242992/r/il/e2088f/5501206094/il_300x300.5501206094_5r4a.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 2](https://i.etsystatic.com/19242992/r/il/f7bb44/5501210160/il_300x300.5501210160_8mad.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 3](https://i.etsystatic.com/19242992/r/il/eb0508/5549317021/il_300x300.5549317021_hna8.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 4](https://i.etsystatic.com/19242992/r/il/6e5551/4434947215/il_300x300.4434947215_lsy4.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 5](https://i.etsystatic.com/19242992/r/il/9009c8/4434949433/il_300x300.4434949433_td6r.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 6](https://i.etsystatic.com/19242992/r/il/d444f7/4434948913/il_300x300.4434948913_kx13.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 7](https://i.etsystatic.com/19242992/r/il/82ff3f/5549315249/il_300x300.5549315249_dsls.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 8](https://i.etsystatic.com/19242992/r/il/1b0772/5501208888/il_300x300.5501208888_q14t.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 9](https://i.etsystatic.com/19242992/r/il/204ce8/2051291925/il_300x300.2051291925_jhii.jpg)
- ![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle image 10](https://i.etsystatic.com/19242992/r/il/ec400f/5501211510/il_300x300.5501211510_4rfs.jpg)

- ![](https://i.etsystatic.com/iap/33ac78/5600522768/iap_640x640.5600522768_enydh3nj.jpg?version=0)

5 out of 5 stars

- Size:

3x4 inches


Beautiful! High quality! Shipping packaging was excellent to protect the candle. Burns beautifully and the recommendations enclosed on us were super helpful.

Dec 16, 2023


[Georgeann Brophy](https://www.etsy.com/people/gcbrophy)

Purchased item:

[![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle](https://i.etsystatic.com/19242992/r/il/e2088f/5501206094/il_170x135.5501206094_5r4a.jpg)\\
\\
Wicks n More Holiday Magic Handcrafted Scented Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/711331184/wicks-n-more-holiday-magic-handcrafted?ref=ap-listing)

Purchased item:

[![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle](https://i.etsystatic.com/19242992/r/il/e2088f/5501206094/il_170x135.5501206094_5r4a.jpg)\\
\\
Wicks n More Holiday Magic Handcrafted Scented Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/711331184/wicks-n-more-holiday-magic-handcrafted?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/20344c/4465266068/iap_640x640.4465266068_syoamc1a.jpg?version=0)

5 out of 5 stars

- Size:

3x6 inches


Amazing product - design, quality and a very well-crafted candle that burns properly!

![](https://i.etsystatic.com/iusa/3e47f2/7909339/iusa_75x75.7909339.jpg?version=0)

Dec 27, 2022


[Quipquot](https://www.etsy.com/people/Quipquot)

Purchased item:

[![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle](https://i.etsystatic.com/19242992/r/il/e2088f/5501206094/il_170x135.5501206094_5r4a.jpg)\\
\\
Wicks n More Holiday Magic Handcrafted Scented Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/711331184/wicks-n-more-holiday-magic-handcrafted?ref=ap-listing)

Purchased item:

[![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle](https://i.etsystatic.com/19242992/r/il/e2088f/5501206094/il_170x135.5501206094_5r4a.jpg)\\
\\
Wicks n More Holiday Magic Handcrafted Scented Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/711331184/wicks-n-more-holiday-magic-handcrafted?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/aeb19c/3565404148/iap_640x640.3565404148_1ozm3z60.jpg?version=0)

5 out of 5 stars

- Size:

3x4 inches


Colorful, delightfully scented pillar candle, just as described. It has graced the center of my Advent wreath for many days, looks great, and burns nicely without dripping. Fast reliable shipping too. Many thanks and blessings for a very happy New Year!

![](https://i.etsystatic.com/iusa/7a452f/25082778/iusa_75x75.25082778_nlyv.jpg?version=0)

Dec 31, 2021


[Jill Sophia](https://www.etsy.com/people/Littleway)

Purchased item:

[![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle](https://i.etsystatic.com/19242992/r/il/e2088f/5501206094/il_170x135.5501206094_5r4a.jpg)\\
\\
Wicks n More Holiday Magic Handcrafted Scented Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/711331184/wicks-n-more-holiday-magic-handcrafted?ref=ap-listing)

Purchased item:

[![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle](https://i.etsystatic.com/19242992/r/il/e2088f/5501206094/il_170x135.5501206094_5r4a.jpg)\\
\\
Wicks n More Holiday Magic Handcrafted Scented Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/711331184/wicks-n-more-holiday-magic-handcrafted?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/f08c00/3558310073/iap_640x640.3558310073_31eivv30.jpg?version=0)

5 out of 5 stars

- Size:

4x6 inches


Looks even better in person than online!

Dec 2, 2021


[Roland Bullock](https://www.etsy.com/people/rbullock856)

Purchased item:

[![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle](https://i.etsystatic.com/19242992/r/il/e2088f/5501206094/il_170x135.5501206094_5r4a.jpg)\\
\\
Wicks n More Holiday Magic Handcrafted Scented Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/711331184/wicks-n-more-holiday-magic-handcrafted?ref=ap-listing)

Purchased item:

[![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle](https://i.etsystatic.com/19242992/r/il/e2088f/5501206094/il_170x135.5501206094_5r4a.jpg)\\
\\
Wicks n More Holiday Magic Handcrafted Scented Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/711331184/wicks-n-more-holiday-magic-handcrafted?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/353b54/2737058884/iap_640x640.2737058884_8kszm4dp.jpg?version=0)

5 out of 5 stars

- Size:

3x4 inches


This is absolutely gorgeous and elegant, just was I was looking for

Dec 15, 2020


[martie](https://www.etsy.com/people/jc2cztth)

Purchased item:

[![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle](https://i.etsystatic.com/19242992/r/il/e2088f/5501206094/il_170x135.5501206094_5r4a.jpg)\\
\\
Wicks n More Holiday Magic Handcrafted Scented Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/711331184/wicks-n-more-holiday-magic-handcrafted?ref=ap-listing)

Purchased item:

[![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle](https://i.etsystatic.com/19242992/r/il/e2088f/5501206094/il_170x135.5501206094_5r4a.jpg)\\
\\
Wicks n More Holiday Magic Handcrafted Scented Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/711331184/wicks-n-more-holiday-magic-handcrafted?ref=ap-listing)