[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/667531976/handcrafted-cinnamon-apple-spice-pillar?amp;click_sum=99bc16d9&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;sts=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=99bc16d9&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=99bc16d9&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=99bc16d9&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=99bc16d9&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-3)
- [Pillar Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/pillar-candles?amp%3Bclick_sum=99bc16d9&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-4)


Add to Favorites


- ![May include: Two pillar candles with a green, orange, and brown layered design. The candles are on a wooden surface with a fall-themed background. The text 'Amish Harvest' is at the top of the image. The text 'Wicks 'N More Candle Company' is at the bottom of the image.](https://i.etsystatic.com/19242992/r/il/b2b531/5295158465/il_794xN.5295158465_8108.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![May include: Two large, three-wick candles on a wooden tray. The candles are layered in shades of green, orange, and brown. The candles are labeled 'Amish Harvest' and are from 'Wicks N' More Candle Company'.](https://i.etsystatic.com/19242992/r/il/aa5d9c/5246978140/il_794xN.5246978140_ci4h.jpg)
- ![May include: A green, brown, and orange pillar candle with a white wick.](https://i.etsystatic.com/19242992/r/il/1d5b12/3915453344/il_794xN.3915453344_i4s5.jpg)
- ![May include: A cylindrical candle with a green, orange, and red color scheme. The candle is lit and has a warm glow.](https://i.etsystatic.com/19242992/r/il/2c8e82/3962958845/il_794xN.3962958845_mkje.jpg)
- ![May include: A black and white circular stamp with the text 'Made in USA' repeated three times. The stamp has three stars in the center.](https://i.etsystatic.com/19242992/r/il/23ba98/3885894208/il_794xN.3885894208_hwc4.jpg)
- ![May include: A three-layered candle with a green, orange, and brown color scheme. The candle is 6 inches tall and 3 inches wide. 3' --> 6'](https://i.etsystatic.com/19242992/r/il/4a8225/5295164001/il_794xN.5295164001_q55y.jpg)

- ![May include: Two pillar candles with a green, orange, and brown layered design. The candles are on a wooden surface with a fall-themed background. The text 'Amish Harvest' is at the top of the image. The text 'Wicks 'N More Candle Company' is at the bottom of the image.](https://i.etsystatic.com/19242992/r/il/b2b531/5295158465/il_75x75.5295158465_8108.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/IMG_2042_tsgq27.jpg)

- ![May include: Two large, three-wick candles on a wooden tray. The candles are layered in shades of green, orange, and brown. The candles are labeled 'Amish Harvest' and are from 'Wicks N' More Candle Company'.](https://i.etsystatic.com/19242992/r/il/aa5d9c/5246978140/il_75x75.5246978140_ci4h.jpg)
- ![May include: A green, brown, and orange pillar candle with a white wick.](https://i.etsystatic.com/19242992/r/il/1d5b12/3915453344/il_75x75.3915453344_i4s5.jpg)
- ![May include: A cylindrical candle with a green, orange, and red color scheme. The candle is lit and has a warm glow.](https://i.etsystatic.com/19242992/r/il/2c8e82/3962958845/il_75x75.3962958845_mkje.jpg)
- ![May include: A black and white circular stamp with the text 'Made in USA' repeated three times. The stamp has three stars in the center.](https://i.etsystatic.com/19242992/r/il/23ba98/3885894208/il_75x75.3885894208_hwc4.jpg)
- ![May include: A three-layered candle with a green, orange, and brown color scheme. The candle is 6 inches tall and 3 inches wide. 3' --> 6'](https://i.etsystatic.com/19242992/r/il/4a8225/5295164001/il_75x75.5295164001_q55y.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F667531976%2Fhandcrafted-cinnamon-apple-spice-pillar%23report-overlay-trigger)

In 8 carts

Price:$26.00+


Loading


# Handcrafted Cinnamon Apple Spice Pillar Candle

[WicksnMoreCandles](https://www.etsy.com/shop/WicksnMoreCandles?ref=shop-header-name&listing_id=667531976&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/667531976/handcrafted-cinnamon-apple-spice-pillar?amp;click_sum=99bc16d9&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;sts=1#reviews)

Ships from Mississippi

Arrives soon! Get it by

Nov 17-20


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Size


Select an option

3x3 inches ($26.00)

3x4 inches ($28.00)

3x6 inches ($31.00)

4x4 inches ($36.00)

4x6 inches ($46.00)

Please select an option


4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Item details

### Highlights

Made by [WicksnMoreCandles](https://www.etsy.com/shop/WicksnMoreCandles)

- Ships from Mississippi! Shorter shipping distances are

kinder to the planet

Ordering items closer to you is more likely to reduce your purchase's carbon footprint.


- Materials: Mottling wax



"Amish Harvest" hand-crafted pillar candles from Wicks N' More Candle Co.

This candle features beautifully blended colors of rust, light to darker browns and rich olive tones to coordinate and complement your fall and holiday events. The perfect blend of cinnamon and apple makes this candle a year round top seller.

Each of our candles are hand poured in our factory located in Northeast Mississippi and we are proud to offer a quality American made product from start to finish. Candles are sold individually so that you can choose the size and quantity that works best for you. Candles are sized with the width first and height second. For example, a 3x6 is 3" wide and 6" tall.

Variations in color and finish are inherent to the handmade process. Slight imperfections are to be expected and reflect the unique character of each individual candle.


## Shipping and return policies

Loading


- Order today to get by

**Nov 17-20**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges not accepted




But please contact me if you have problems with your order


- Free shipping


- Ships from: **Tupelo, MS**


Deliver to United States

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (68)

4.6/5

item average

5.0Item quality

5.0Shipping

5.0Customer service

86%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Beautiful

Smells amazing

Fast shipping

Would recommend

Great quality

Love it

Well packaged


Filter by category


Appearance (28)


Quality (26)


Shipping & Packaging (11)


Seller service (6)


Value (3)


Description accuracy (2)


Condition (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Denise](https://www.etsy.com/people/ilml7j7xzjf2a2p5?ref=l_review)
Nov 7, 2025


They smell great too! Very pretty colors!



[Denise](https://www.etsy.com/people/ilml7j7xzjf2a2p5?ref=l_review)
Nov 7, 2025


5 out of 5 stars
5

This item

[Cheri](https://www.etsy.com/people/fnix4ndn2g9cmh19?ref=l_review)
Oct 30, 2025


This candle smells so good! My postal carrier was sniffing the box when she came to my door. Wonderful gift for friends or family.



[Cheri](https://www.etsy.com/people/fnix4ndn2g9cmh19?ref=l_review)
Oct 30, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/b7b39a/70373595/iusa_75x75.70373595_hsdb.jpg?version=0)

[Darlene Johnson](https://www.etsy.com/people/darlenejohnson599?ref=l_review)
Aug 2, 2025


Smells heavenly. Will order again!



![](https://i.etsystatic.com/iusa/b7b39a/70373595/iusa_75x75.70373595_hsdb.jpg?version=0)

[Darlene Johnson](https://www.etsy.com/people/darlenejohnson599?ref=l_review)
Aug 2, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/63ce51/83914504/iusa_75x75.83914504_hx7q.jpg?version=0)

[Latoya Banks](https://www.etsy.com/people/bankslatoya?ref=l_review)
May 5, 2025


Thanks I love the candles



![](https://i.etsystatic.com/iusa/63ce51/83914504/iusa_75x75.83914504_hx7q.jpg?version=0)

[Latoya Banks](https://www.etsy.com/people/bankslatoya?ref=l_review)
May 5, 2025


View all reviews for this item

### Photos from reviews

![Pamela added a photo of their purchase](https://i.etsystatic.com/iap/ceaaa0/6387784483/iap_300x300.6387784483_1iha1snr.jpg?version=0)

![Mickeemse added a photo of their purchase](https://i.etsystatic.com/iap/07420e/6639892287/iap_300x300.6639892287_scbx03ys.jpg?version=0)

![Cindy added a photo of their purchase](https://i.etsystatic.com/iap/300f30/5948822311/iap_300x300.5948822311_qkf03aaw.jpg?version=0)

![Tom added a photo of their purchase](https://i.etsystatic.com/iap/475cce/5993677839/iap_300x300.5993677839_drnzpa68.jpg?version=0)

![Katerina added a photo of their purchase](https://i.etsystatic.com/iap/7537c2/4221123817/iap_300x300.4221123817_6zziird9.jpg?version=0)

![Renee' added a photo of their purchase](https://i.etsystatic.com/iap/c04246/4092420912/iap_300x300.4092420912_tt8zpa6l.jpg?version=0)

![Jan added a photo of their purchase](https://i.etsystatic.com/iap/fa3b46/2556893230/iap_300x300.2556893230_g6xcs01c.jpg?version=0)

![Jan added a photo of their purchase](https://i.etsystatic.com/iap/4182bf/2556857662/iap_300x300.2556857662_mp6yahjk.jpg?version=0)

[![WicksnMoreCandles](https://i.etsystatic.com/iusa/4d6e17/111363569/iusa_75x75.111363569_khhs.jpg?version=0)](https://www.etsy.com/shop/WicksnMoreCandles?ref=shop_profile&listing_id=667531976)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[WicksnMoreCandles](https://www.etsy.com/shop/WicksnMoreCandles?ref=shop_profile&listing_id=667531976)

[Owned by Shane](https://www.etsy.com/shop/WicksnMoreCandles?ref=shop_profile&listing_id=667531976) \|

Tupelo, Mississippi

4.9
(1.2k)


5.7k sales

6 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=198363071&referring_id=667531976&referring_type=listing&recipient_id=198363071&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoxOTgzNjMwNzE6MTc2MjgyNjU3MjozZGQyNDAxMzc4MTA4MWFjNmYxYTQ0MjUzYmY3Y2JmNQ%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F667531976%2Fhandcrafted-cinnamon-apple-spice-pillar%3Famp%253Bclick_sum%3D99bc16d9%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bsts%3D1)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/WicksnMoreCandles?ref=lp_mys_mfts)

- [![Wicks n More Warmest Wishes Hand-Crafted Scented Pillar Candle](https://i.etsystatic.com/19242992/c/2048/1627/0/201/il/ef6966/2203081629/il_340x270.2203081629_11qi.jpg)\\
\\
**Wicks n More Warmest Wishes Hand-Crafted Scented Pillar Candle**\\
\\
$26.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/686072947/wicks-n-more-warmest-wishes-hand-crafted?click_key=96b827c1bd5c6eb10f0b220684d6e546%3ALT8c8b6ecae8bebaca82143ffbc6c3a7211d3752aa&click_sum=4e809ffd&ls=r&ref=related-1&sts=1&content_source=96b827c1bd5c6eb10f0b220684d6e546%253ALT8c8b6ecae8bebaca82143ffbc6c3a7211d3752aa "Wicks n More Warmest Wishes Hand-Crafted Scented Pillar Candle")




Add to Favorites


- [![Wicks n More Red Scented Hand-Crafted Pillar Candle](https://i.etsystatic.com/19242992/r/il/bf6a3c/4387566034/il_340x270.4387566034_hfx9.jpg)\\
\\
**Wicks n More Red Scented Hand-Crafted Pillar Candle**\\
\\
$26.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/672215502/wicks-n-more-red-scented-hand-crafted?click_key=96b827c1bd5c6eb10f0b220684d6e546%3ALTffabb7a011fd9be9370f663dc206629670fc8abe&click_sum=bda72c4d&ls=r&ref=related-2&sts=1&content_source=96b827c1bd5c6eb10f0b220684d6e546%253ALTffabb7a011fd9be9370f663dc206629670fc8abe "Wicks n More Red Scented Hand-Crafted Pillar Candle")




Add to Favorites


- [![Wicks n More Caramel Apple Hand-Crafted Scented Pillar Candle](https://i.etsystatic.com/19242992/r/il/562185/4928528313/il_340x270.4928528313_o46w.jpg)\\
\\
**Wicks n More Caramel Apple Hand-Crafted Scented Pillar Candle**\\
\\
$26.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/686033107/wicks-n-more-caramel-apple-hand-crafted?click_key=96b827c1bd5c6eb10f0b220684d6e546%3ALTbc9a36f23132e537181f460a9f42eca310eae971&click_sum=d6b04772&ls=r&ref=related-3&sts=1&content_source=96b827c1bd5c6eb10f0b220684d6e546%253ALTbc9a36f23132e537181f460a9f42eca310eae971 "Wicks n More Caramel Apple Hand-Crafted Scented Pillar Candle")




Add to Favorites


- [![Wicks n More Holiday Magic Handcrafted Scented Pillar Candle](https://i.etsystatic.com/19242992/r/il/e2088f/5501206094/il_340x270.5501206094_5r4a.jpg)\\
\\
**Wicks n More Holiday Magic Handcrafted Scented Pillar Candle**\\
\\
$26.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/711331184/wicks-n-more-holiday-magic-handcrafted?click_key=670d6edbf0769e9f939ed807619a467db0f303c1%3A711331184&click_sum=bcb1aa96&ref=related-4&sts=1 "Wicks n More Holiday Magic Handcrafted Scented Pillar Candle")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 2, 2025


[313 favorites](https://www.etsy.com/listing/667531976/handcrafted-cinnamon-apple-spice-pillar/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=99bc16d9&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=99bc16d9&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=99bc16d9&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=99bc16d9&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Pillar Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/pillar-candles?amp%3Bclick_sum=99bc16d9&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Home Decor

[Winter Tabletop - US](https://www.etsy.com/market/winter_tabletop) [Buy Silver Candelabra Online](https://www.etsy.com/market/silver_candelabra) [Bold Chicken Wall Decor](https://www.etsy.com/listing/4309330102/colorful-rooster-art-print-bold-chicken) [Tank by AdamsCraftyCreations](https://www.etsy.com/listing/579698973/tank) [Buy Napoleon Iii Vase Online](https://www.etsy.com/market/napoleon_iii_vase) [Artificial Finger Succulent Seashell Arrangement by KamakDesigns](https://www.etsy.com/listing/1587843391/faux-finger-succulent-shell-planter) [Set of 2 1950's Chalk Ware Dutch Girl & Boy Couple Kitchen Wall Hangings by Shagsvintage](https://www.etsy.com/listing/4333894470/set-of-2-1950s-chalk-ware-dutch-girl-boy) [Buy Christmas Mailbox Topper Online](https://www.etsy.com/market/christmas_mailbox_topper) [Moon and Stars Custom Ornament - Home Decor](https://www.etsy.com/listing/1452858678/moon-and-stars-custom-ornament) [Macrame Leaf Wall Hanging by LemonLeafMacrame](https://www.etsy.com/listing/1882648903/macrame-leaf-wall-hanging-macrame-wall) [Metal Block Numbers for Sale](https://www.etsy.com/market/metal_block_numbers)

Collectibles

[Shop Parker Cannon](https://www.etsy.com/market/parker_cannon)

Kitchen & Dining

[Mood Coffee Mug: Bad Day? Good Day? Stressed? Happy? Coffee Lover Gift](https://www.etsy.com/listing/4321262546/mood-coffee-mug-bad-day-good-day)

Bracelets

[Buy Morgan Wallen Bracelet Stack Online](https://www.etsy.com/market/morgan_wallen_bracelet_stack)

Sunglasses & Eyewear

[Mhuffdesigns for Sale](https://www.etsy.com/market/mhuffdesigns)

Toys

[Shop Invader Zim Costume For Kid](https://www.etsy.com/market/invader_zim_costume_for_kid)

Floor & Rugs

[9.6 x 2.3 ft. by ACEMRUG](https://www.etsy.com/listing/1185520946/runner-rug-turkish-rug-vintage-rug-96-x)

Necklaces

[A rather cool vintage paste turquoise orb pendant by bijouxvintagelon](https://www.etsy.com/listing/4326017627/a-rather-cool-vintage-paste-turquoise)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F667531976%2Fhandcrafted-cinnamon-apple-spice-pillar%3Famp%253Bclick_sum%3D99bc16d9%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bsts%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgyNjU3MjoyNWFhNTY0ZWU0YjM5NDBmOTgzZTU5MWE0OTM5NjUzYQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F667531976%2Fhandcrafted-cinnamon-apple-spice-pillar%3Famp%253Bclick_sum%3D99bc16d9%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bsts%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/667531976/handcrafted-cinnamon-apple-spice-pillar?amp;click_sum=99bc16d9&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;sts=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F667531976%2Fhandcrafted-cinnamon-apple-spice-pillar%3Famp%253Bclick_sum%3D99bc16d9%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bsts%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for WicksnMoreCandles

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 12 hours of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## Seller details

### Business registration number

### Location

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=198363071&referring_id=19242992&referring_type=shop&recipient_id=198363071&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![May include: Two pillar candles with a green, orange, and brown layered design. The candles are on a wooden surface with a fall-themed background. The text 'Amish Harvest' is at the top of the image. The text 'Wicks 'N More Candle Company' is at the bottom of the image.](https://i.etsystatic.com/19242992/r/il/b2b531/5295158465/il_300x300.5295158465_8108.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/IMG_2042_tsgq27.jpg)

- ![May include: Two large, three-wick candles on a wooden tray. The candles are layered in shades of green, orange, and brown. The candles are labeled 'Amish Harvest' and are from 'Wicks N' More Candle Company'.](https://i.etsystatic.com/19242992/r/il/aa5d9c/5246978140/il_300x300.5246978140_ci4h.jpg)
- ![May include: A green, brown, and orange pillar candle with a white wick.](https://i.etsystatic.com/19242992/r/il/1d5b12/3915453344/il_300x300.3915453344_i4s5.jpg)
- ![May include: A cylindrical candle with a green, orange, and red color scheme. The candle is lit and has a warm glow.](https://i.etsystatic.com/19242992/r/il/2c8e82/3962958845/il_300x300.3962958845_mkje.jpg)
- ![May include: A black and white circular stamp with the text 'Made in USA' repeated three times. The stamp has three stars in the center.](https://i.etsystatic.com/19242992/r/il/23ba98/3885894208/il_300x300.3885894208_hwc4.jpg)
- ![May include: A three-layered candle with a green, orange, and brown color scheme. The candle is 6 inches tall and 3 inches wide. 3' --> 6'](https://i.etsystatic.com/19242992/r/il/4a8225/5295164001/il_300x300.5295164001_q55y.jpg)

- ![](https://i.etsystatic.com/iap/ceaaa0/6387784483/iap_640x640.6387784483_1iha1snr.jpg?version=0)

5 out of 5 stars

- Size:

4x6 inches


Very beautiful candle which I placed on my fireplace mantel

![](https://i.etsystatic.com/iusa/27180d/107110589/iusa_75x75.107110589_s5i9.jpg?version=0)

Oct 10, 2024


[Pamela Langham](https://www.etsy.com/people/pamh007)

Purchased item:

[![Handcrafted Cinnamon Apple Spice Pillar Candle](https://i.etsystatic.com/19242992/r/il/b2b531/5295158465/il_170x135.5295158465_8108.jpg)\\
\\
Handcrafted Cinnamon Apple Spice Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/667531976/handcrafted-cinnamon-apple-spice-pillar?ref=ap-listing)

Purchased item:

[![Handcrafted Cinnamon Apple Spice Pillar Candle](https://i.etsystatic.com/19242992/r/il/b2b531/5295158465/il_170x135.5295158465_8108.jpg)\\
\\
Handcrafted Cinnamon Apple Spice Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/667531976/handcrafted-cinnamon-apple-spice-pillar?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/07420e/6639892287/iap_640x640.6639892287_scbx03ys.jpg?version=0)

5 out of 5 stars

- Size:

3x6 inches


Beautiful candles wrapped with such care for shipping. I almost done want to burn them they are so gorgeous!!

![](https://i.etsystatic.com/iusa/75de23/52363208/iusa_75x75.52363208_ipl7.jpg?version=0)

Jan 23, 2025


[Mickeemse](https://www.etsy.com/people/Mickeemse)

Purchased item:

[![Handcrafted Cinnamon Apple Spice Pillar Candle](https://i.etsystatic.com/19242992/r/il/b2b531/5295158465/il_170x135.5295158465_8108.jpg)\\
\\
Handcrafted Cinnamon Apple Spice Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/667531976/handcrafted-cinnamon-apple-spice-pillar?ref=ap-listing)

Purchased item:

[![Handcrafted Cinnamon Apple Spice Pillar Candle](https://i.etsystatic.com/19242992/r/il/b2b531/5295158465/il_170x135.5295158465_8108.jpg)\\
\\
Handcrafted Cinnamon Apple Spice Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/667531976/handcrafted-cinnamon-apple-spice-pillar?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/300f30/5948822311/iap_640x640.5948822311_qkf03aaw.jpg?version=0)

5 out of 5 stars

- Size:

3x3 inches


My candles are beautiful and match perfectly. Great quality also.

![](https://i.etsystatic.com/iusa/937fb1/81487821/iusa_75x75.81487821_o9ai.jpg?version=0)

Apr 6, 2024


[Cindy](https://www.etsy.com/people/as88j5qe)

Purchased item:

[![Handcrafted Cinnamon Apple Spice Pillar Candle](https://i.etsystatic.com/19242992/r/il/b2b531/5295158465/il_170x135.5295158465_8108.jpg)\\
\\
Handcrafted Cinnamon Apple Spice Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/667531976/handcrafted-cinnamon-apple-spice-pillar?ref=ap-listing)

Purchased item:

[![Handcrafted Cinnamon Apple Spice Pillar Candle](https://i.etsystatic.com/19242992/r/il/b2b531/5295158465/il_170x135.5295158465_8108.jpg)\\
\\
Handcrafted Cinnamon Apple Spice Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/667531976/handcrafted-cinnamon-apple-spice-pillar?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/475cce/5993677839/iap_640x640.5993677839_drnzpa68.jpg?version=0)

5 out of 5 stars

- Size:

3x6 inches


Beautifully crafted candles .. gorgeous colors .. love in my space

Apr 25, 2024


[Tom Cummins](https://www.etsy.com/people/tomcummins1)

Purchased item:

[![Handcrafted Cinnamon Apple Spice Pillar Candle](https://i.etsystatic.com/19242992/r/il/b2b531/5295158465/il_170x135.5295158465_8108.jpg)\\
\\
Handcrafted Cinnamon Apple Spice Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/667531976/handcrafted-cinnamon-apple-spice-pillar?ref=ap-listing)

Purchased item:

[![Handcrafted Cinnamon Apple Spice Pillar Candle](https://i.etsystatic.com/19242992/r/il/b2b531/5295158465/il_170x135.5295158465_8108.jpg)\\
\\
Handcrafted Cinnamon Apple Spice Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/667531976/handcrafted-cinnamon-apple-spice-pillar?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/7537c2/4221123817/iap_640x640.4221123817_6zziird9.jpg?version=0)

4 out of 5 stars

- Size:

3x4 inches


These candles are stunning. My only drawback is the smell! The smell is too strong! This is only my second day having them out but the smell is too much! Hopefully after awhile it will calm down.

![](https://i.etsystatic.com/iusa/f36fa4/98649357/iusa_75x75.98649357_4mkf.jpg?version=0)

Sep 17, 2022


[Katerina Lekatsas](https://www.etsy.com/people/katerinalekatsas)

Purchased item:

[![Handcrafted Cinnamon Apple Spice Pillar Candle](https://i.etsystatic.com/19242992/r/il/b2b531/5295158465/il_170x135.5295158465_8108.jpg)\\
\\
Handcrafted Cinnamon Apple Spice Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/667531976/handcrafted-cinnamon-apple-spice-pillar?ref=ap-listing)

Purchased item:

[![Handcrafted Cinnamon Apple Spice Pillar Candle](https://i.etsystatic.com/19242992/r/il/b2b531/5295158465/il_170x135.5295158465_8108.jpg)\\
\\
Handcrafted Cinnamon Apple Spice Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/667531976/handcrafted-cinnamon-apple-spice-pillar?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/c04246/4092420912/iap_640x640.4092420912_tt8zpa6l.jpg?version=0)

5 out of 5 stars

- Size:

4x6 inches


Candles turned out beautiful! They smell great too. Packing was excellent and they arrived faster then I expected.

Aug 18, 2022


[Renee' Kerr](https://www.etsy.com/people/redrenee78)

Purchased item:

[![Handcrafted Cinnamon Apple Spice Pillar Candle](https://i.etsystatic.com/19242992/r/il/b2b531/5295158465/il_170x135.5295158465_8108.jpg)\\
\\
Handcrafted Cinnamon Apple Spice Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/667531976/handcrafted-cinnamon-apple-spice-pillar?ref=ap-listing)

Purchased item:

[![Handcrafted Cinnamon Apple Spice Pillar Candle](https://i.etsystatic.com/19242992/r/il/b2b531/5295158465/il_170x135.5295158465_8108.jpg)\\
\\
Handcrafted Cinnamon Apple Spice Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/667531976/handcrafted-cinnamon-apple-spice-pillar?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/fa3b46/2556893230/iap_640x640.2556893230_g6xcs01c.jpg?version=0)

5 out of 5 stars

- Size:

4x4 inches


A closer picture of one of the perfect candles i purchased

Sep 28, 2020


[Jan Riopelle](https://www.etsy.com/people/janriopelle)

Purchased item:

[![Handcrafted Cinnamon Apple Spice Pillar Candle](https://i.etsystatic.com/19242992/r/il/b2b531/5295158465/il_170x135.5295158465_8108.jpg)\\
\\
Handcrafted Cinnamon Apple Spice Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/667531976/handcrafted-cinnamon-apple-spice-pillar?ref=ap-listing)

Purchased item:

[![Handcrafted Cinnamon Apple Spice Pillar Candle](https://i.etsystatic.com/19242992/r/il/b2b531/5295158465/il_170x135.5295158465_8108.jpg)\\
\\
Handcrafted Cinnamon Apple Spice Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/667531976/handcrafted-cinnamon-apple-spice-pillar?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/4182bf/2556857662/iap_640x640.2556857662_mp6yahjk.jpg?version=0)

5 out of 5 stars

- Size:

3x6 inches


Purchased 4 candles and not only are they beautiful, they smell amazing. The customer service I received was impeccable - will definitely be making more purchases and recommending to friends and family

See in original language


Translated by [Microsoft](http://aka.ms/MicrosoftTranslatorAttribution)

Purchased 4 candles and not only are they beautiful, they smell amazing. The customer service I received was impeccable - will definitely be making more purchases and recommending to friends and family


Sep 28, 2020


[Jan Riopelle](https://www.etsy.com/people/janriopelle)

Purchased item:

[![Handcrafted Cinnamon Apple Spice Pillar Candle](https://i.etsystatic.com/19242992/r/il/b2b531/5295158465/il_170x135.5295158465_8108.jpg)\\
\\
Handcrafted Cinnamon Apple Spice Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/667531976/handcrafted-cinnamon-apple-spice-pillar?ref=ap-listing)

Purchased item:

[![Handcrafted Cinnamon Apple Spice Pillar Candle](https://i.etsystatic.com/19242992/r/il/b2b531/5295158465/il_170x135.5295158465_8108.jpg)\\
\\
Handcrafted Cinnamon Apple Spice Pillar Candle\\
\\
$26.00](https://www.etsy.com/listing/667531976/handcrafted-cinnamon-apple-spice-pillar?ref=ap-listing)