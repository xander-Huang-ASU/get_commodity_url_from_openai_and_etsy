[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?amp;click_sum=733e523f&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=733e523f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=733e523f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=733e523f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=733e523f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=catnav_breadcrumb-3)

Etsy’s Pick

Etsy’s Picks are hand selected by our style experts to highlight items from shops that have shown quality, reliability and style.

[Discover More](https://www.etsy.com/featured/hub/etsy-picks?ref=listing_etsys_pick_signal)


Add to Favorites


- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_794xN.7406327307_ttiq.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/b0794e/7358425410/il_794xN.7358425410_2drn.jpg)
- ![Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/2bb236/7358412974/il_794xN.7358412974_myn5.jpg)
- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/6f53e5/7358419714/il_794xN.7358419714_3glq.jpg)
- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/6d44bb/7358409928/il_794xN.7358409928_lz4o.jpg)
- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/070772/7358418862/il_794xN.7358418862_tjnd.jpg)
- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/ec72ca/7358412234/il_794xN.7358412234_7x5g.jpg)
- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/be551c/7406339089/il_794xN.7406339089_rjor.jpg)
- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/a0f2b5/7406340437/il_794xN.7406340437_m9tp.jpg)
- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/1a7799/7358411042/il_794xN.7358411042_6b5l.jpg)

- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_75x75.7406327307_ttiq.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/IMG_2397_ic2apw.jpg)

- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/b0794e/7358425410/il_75x75.7358425410_2drn.jpg)
- ![Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/2bb236/7358412974/il_75x75.7358412974_myn5.jpg)
- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/6f53e5/7358419714/il_75x75.7358419714_3glq.jpg)
- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/6d44bb/7358409928/il_75x75.7358409928_lz4o.jpg)
- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/070772/7358418862/il_75x75.7358418862_tjnd.jpg)
- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/ec72ca/7358412234/il_75x75.7358412234_7x5g.jpg)
- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/be551c/7406339089/il_75x75.7406339089_rjor.jpg)
- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/a0f2b5/7406340437/il_75x75.7406340437_m9tp.jpg)
- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/1a7799/7358411042/il_75x75.7358411042_6b5l.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F825676258%2Fset-of-four-aromatherapy-tealight%23report-overlay-trigger)

In 20+ carts

Price:$22.00


Loading


# Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift

[meganspantry](https://www.etsy.com/shop/meganspantry?ref=shop-header-name&listing_id=825676258&from_page=listing)

[5 out of 5 stars](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?amp;click_sum=733e523f&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2#reviews)

Arrives soon! Get it by

Nov 14-17


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

You can only make an offer when buying a single item


Add to cart



Loading


## Buy together, get free shipping

## Buy together, get free shipping

Add both to cart



Loading


[See more items](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?amp;click_sum=733e523f&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2#recs_ribbon_container)

![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_340x270.7406327307_ttiq.jpg)
This listing

### Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift

$22.00


Add to Favorites


[![Aromatherapy Bath Salt Sampler Gift Set: Essential Oil Spa Soak](https://i.etsystatic.com/22716784/r/il/768724/6385338678/il_340x270.6385338678_2k2j.jpg)\\
\\
**Aromatherapy Bath Salt Sampler Gift Set: Essential Oil Spa Soak**\\
\\
$16.00](https://www.etsy.com/listing/853114911/aromatherapy-bath-salt-sampler-gift-set?click_key=8d875a2b5981731e4280b9448adf53ee%3ALTa5a2b9e3aa99b4abbe39c5fa53c3fd175e8714ab&click_sum=9a9e778e&ls=r&ref=listing-free-shipping-bundle-1&content_source=8d875a2b5981731e4280b9448adf53ee%253ALTa5a2b9e3aa99b4abbe39c5fa53c3fd175e8714ab "Aromatherapy Bath Salt Sampler Gift Set: Essential Oil Spa Soak")


Add to Favorites


![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_340x270.7406327307_ttiq.jpg)
This listing

### Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift

$22.00


Add to Favorites


[![Aromatherapy Bath Salt Sampler Gift Set: Essential Oil Spa Soak](https://i.etsystatic.com/22716784/r/il/768724/6385338678/il_340x270.6385338678_2k2j.jpg)\\
\\
**Aromatherapy Bath Salt Sampler Gift Set: Essential Oil Spa Soak**\\
\\
$16.00](https://www.etsy.com/listing/853114911/aromatherapy-bath-salt-sampler-gift-set?click_key=8d875a2b5981731e4280b9448adf53ee%3ALTa5a2b9e3aa99b4abbe39c5fa53c3fd175e8714ab&click_sum=9a9e778e&ls=r&ref=listing-free-shipping-bundle-1&content_source=8d875a2b5981731e4280b9448adf53ee%253ALTa5a2b9e3aa99b4abbe39c5fa53c3fd175e8714ab "Aromatherapy Bath Salt Sampler Gift Set: Essential Oil Spa Soak")


Add to Favorites


![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_340x270.7406327307_ttiq.jpg)
This listing

### Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift

$22.00


Add to Favorites


[![Aromatherapy Bath Salt Sampler Gift Set: Essential Oil Spa Soak](https://i.etsystatic.com/22716784/r/il/768724/6385338678/il_340x270.6385338678_2k2j.jpg)\\
\\
**Aromatherapy Bath Salt Sampler Gift Set: Essential Oil Spa Soak**\\
\\
$16.00](https://www.etsy.com/listing/853114911/aromatherapy-bath-salt-sampler-gift-set?click_key=8d875a2b5981731e4280b9448adf53ee%3ALTa5a2b9e3aa99b4abbe39c5fa53c3fd175e8714ab&click_sum=9a9e778e&ls=r&ref=listing-free-shipping-bundle-1&content_source=8d875a2b5981731e4280b9448adf53ee%253ALTa5a2b9e3aa99b4abbe39c5fa53c3fd175e8714ab "Aromatherapy Bath Salt Sampler Gift Set: Essential Oil Spa Soak")


Add to Favorites


## Item details

### Highlights

Made by [meganspantry](https://www.etsy.com/shop/meganspantry)

- Materials: Wax type: Soy


- Sustainable features: vegan. Items may include additional materials or use methods that aren't considered sustainable features on our site. [Learn more](https://help.etsy.com/hc/articles/15532793357847)

- Width: 2.5 inches

Height: 1.25 inches

Elevate everyday rituals or give the perfect wellness gift with Megan’s Pantry Aromatherapy Candles. This thoughtfully curated collection includes four 1 oz wooden tealight candles, each hand-poured in small batches using pure soy wax, therapeutic-grade essential oils, and topped with real botanicals.

Housed in reusable wooden pinch bowls treated with eco-safe flame retardant, these natural candles are both beautiful and sustainable. Perfect for gifting or enjoying as a personal set of calming scents.

Includes one of each signature scent:

Serenity – Lavender & eucalyptus with lavender petals; soothing and serene

Joy – Orange & grapefruit with lemon peel; bright and mood-lifting

Grace – Rosemary & palmarosa with rose petals; elegant and grounding

Peace – Eucalyptus, grapefruit, and rosemary with jasmine; fresh and harmonious

📏 Each candle measures approximately 2.5" wide x 1.25" tall.

🌿 Clean Ingredients You Can Trust:

100% soy wax + essential oils

Vegan and cruelty-free

No artificial fragrances

Paraben- and phthalate-free

Hand-poured with intention in small batches

🎁 Perfect for:

Relaxation or spa gifts

Holiday gifts under $50

Thank you or hostess gifts

Bridesmaid or wedding party gifts

Corporate wellness gifts

Housewarming or birthday presents

⚠️ Due to the natural wood and oil content, minor wax or oil seepage may occur. Always place candles on a non-porous surface, such as porcelain. Each bowl is treated with a biodegradable, non-toxic & eco-friendly flame retardant. Please review our candle safety tips on our website https://shopmeganspantry.com/pages/candle-safety-tips

✨ Thoughtful. Natural. Elevated. Give the gift of aromatherapy with this beautiful and intentional set.

\*\*DO NOT LEAVE LIT CANDLES UNATTENDED\*\* Please practice candle safety when in use. Trim wicks to 1/4" before each use.

Set of two (2) of one (1) selected scent is available here:

[https://www.etsy.com/listing/839570119/set-of-two-aromatherapy-soy-candles-one](https://www.etsy.com/listing/839570119/aromatherapy-wooden-tealight-candles-set)

A gift set of six (6) candles with gift packaging is available here:

[https://www.etsy.com/listing/825682960/gift-set-of-six-aromatherapy-soy-candles](https://www.etsy.com/listing/825682960/gift-set-of-6-tealight-candles-with)

Free US shipping on orders over $35!


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-17**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges not accepted




But please contact me if you have problems with your order


- Ships from: **Albuquerque, NM**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (1.3k)

4.8/5

item average

4.7Item quality

4.8Shipping

4.9Customer service

94%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Smells amazing

Gift-worthy

Love it

Cute

Fast shipping

Beautiful

Great product


Filter by category


Quality (485)


Appearance (272)


Shipping & Packaging (192)


Description accuracy (112)


Sizing & Fit (66)


Seller service (40)


Value (26)


Condition (12)


Comfort (6)


Ease of use (4)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/105dbc/65431153/iusa_75x75.65431153_bzde.jpg?version=0)

[Katelyn Malo](https://www.etsy.com/people/kitkatxtaktik?ref=l_review)
Nov 8, 2025


These are small, but perfect for little gifts. Great quality and smell glorious. Excited to give them for Christmas gifts!



![](https://i.etsystatic.com/iusa/105dbc/65431153/iusa_75x75.65431153_bzde.jpg?version=0)

[Katelyn Malo](https://www.etsy.com/people/kitkatxtaktik?ref=l_review)
Nov 8, 2025


5 out of 5 stars
5

This item

[Sandra Recker](https://www.etsy.com/people/wpq9i9x4k6g9twh9?ref=l_review)
Nov 7, 2025


Very nice. Just. Love the soaps



[Sandra Recker](https://www.etsy.com/people/wpq9i9x4k6g9twh9?ref=l_review)
Nov 7, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/4d5fb3/94562406/iusa_75x75.94562406_md31.jpg?version=0)

[Liz Kohler Brown](https://www.etsy.com/people/sefo0vtp2tusma26?ref=l_review)
Nov 7, 2025


Love them and they smell so good!



![](https://i.etsystatic.com/iusa/4d5fb3/94562406/iusa_75x75.94562406_md31.jpg?version=0)

[Liz Kohler Brown](https://www.etsy.com/people/sefo0vtp2tusma26?ref=l_review)
Nov 7, 2025


5 out of 5 stars
5

This item

[Brenda Schramm](https://www.etsy.com/people/brendawoodyard?ref=l_review)
Nov 1, 2025


These are so cute! Smell absolutely amazing!! Thank you



[Brenda Schramm](https://www.etsy.com/people/brendawoodyard?ref=l_review)
Nov 1, 2025


View all reviews for this item

### Photos from reviews

![Melissa added a photo of their purchase](https://i.etsystatic.com/iap/f58c91/6523362018/iap_300x300.6523362018_aufh0m9h.jpg?version=0)

![Canitria added a photo of their purchase](https://i.etsystatic.com/iap/005259/6524907021/iap_300x300.6524907021_s3k7x9fy.jpg?version=0)

![Jessica added a photo of their purchase](https://i.etsystatic.com/iap/5bdaf5/5084406883/iap_300x300.5084406883_tekxl046.jpg?version=0)

![Diane added a photo of their purchase](https://i.etsystatic.com/iap/042e60/6565148975/iap_300x300.6565148975_ebtn5ivs.jpg?version=0)

![Shellie added a photo of their purchase](https://i.etsystatic.com/iap/d617eb/4951417072/iap_300x300.4951417072_b9ophe7y.jpg?version=0)

![Stacyann added a photo of their purchase](https://i.etsystatic.com/iap/25db27/7108585058/iap_300x300.7108585058_i2i031m1.jpg?version=0)

![angie8gomez added a photo of their purchase](https://i.etsystatic.com/iap/8d7c79/6723012008/iap_300x300.6723012008_hir3duju.jpg?version=0)

![Mary added a photo of their purchase](https://i.etsystatic.com/iap/6e74fe/6848735599/iap_300x300.6848735599_gzdj693p.jpg?version=0)

![Janet added a photo of their purchase](https://i.etsystatic.com/iap/c2fea3/6943636691/iap_300x300.6943636691_sxs2auy3.jpg?version=0)

![Suzanne added a photo of their purchase](https://i.etsystatic.com/iap/aebc0d/4581018161/iap_300x300.4581018161_pwt4bv9e.jpg?version=0)

![Janelle added a photo of their purchase](https://i.etsystatic.com/iap/52a7c4/6754784396/iap_300x300.6754784396_5zmyj0l0.jpg?version=0)

![Lauri added a photo of their purchase](https://i.etsystatic.com/iap/4ec998/6517568289/iap_300x300.6517568289_rwh1anxs.jpg?version=0)

![Joanna added a photo of their purchase](https://i.etsystatic.com/iap/c75f6b/6680822335/iap_300x300.6680822335_he3ehhr3.jpg?version=0)

![Tiff added a photo of their purchase](https://i.etsystatic.com/iap/705d62/7289749926/iap_300x300.7289749926_67pbrwg8.jpg?version=0)

![Katie added a photo of their purchase](https://i.etsystatic.com/iap/77c9c3/4507016492/iap_300x300.4507016492_oew0nmdb.jpg?version=0)

![melissa added a photo of their purchase](https://i.etsystatic.com/iap/5740ba/5661283107/iap_300x300.5661283107_dxhm75fb.jpg?version=0)

![Jacqui added a photo of their purchase](https://i.etsystatic.com/iap/e6f970/6177830053/iap_300x300.6177830053_1l3e1535.jpg?version=0)

![Elizabeth added a photo of their purchase](https://i.etsystatic.com/iap/4b793e/6611849561/iap_300x300.6611849561_czvlofxt.jpg?version=0)

![Sharina added a photo of their purchase](https://i.etsystatic.com/iap/c7063c/5610846710/iap_300x300.5610846710_2y7jmxjt.jpg?version=0)

![Lorri added a photo of their purchase](https://i.etsystatic.com/iap/62a9eb/6907684627/iap_300x300.6907684627_knpwnwyn.jpg?version=0)

[![meganspantry](https://i.etsystatic.com/iusa/8abf5e/101484538/iusa_75x75.101484538_sy08.jpg?version=0)](https://www.etsy.com/shop/meganspantry?ref=shop_profile&listing_id=825676258)

[meganspantry](https://www.etsy.com/shop/meganspantry?ref=shop_profile&listing_id=825676258)

[Owned by Megan](https://www.etsy.com/shop/meganspantry?ref=shop_profile&listing_id=825676258) \|

Albuquerque, New Mexico

4.8
(3.3k)


16.3k sales

5 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=281332274&referring_id=825676258&referring_type=listing&recipient_id=281332274&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyODEzMzIyNzQ6MTc2MjgyMzMxNjo1N2VhOWMzMjk3NTczOGY1ZmY1OTJlZGM5ZjBlNGY4MQ%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F825676258%2Fset-of-four-aromatherapy-tealight%3Famp%253Bclick_sum%3D733e523f%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/meganspantry?ref=lp_mys_mfts)

- [![Aromatherapy Wooden Tealight Candles | Set of 2 | Essential Oil Soy Candles | Hand-Poured Vegan | Reusable Bowl | Toxin-Free Luxury Gift](https://i.etsystatic.com/22716784/r/il/8fe514/7406235715/il_340x270.7406235715_k4r7.jpg)\\
\\
**Aromatherapy Wooden Tealight Candles \| Set of 2 \| Essential Oil Soy Candles \| Hand-Poured Vegan \| Reusable Bowl \| Toxin-Free Luxury Gift**\\
\\
$12.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/839570119/aromatherapy-wooden-tealight-candles-set?click_key=a4d155ddacbbe79dfc925180bd97d4b5%3ALT716d260b38ed3dc4bbf612aaf154e4bace37df51&click_sum=ee7ba7d1&ls=r&ref=related-1&content_source=a4d155ddacbbe79dfc925180bd97d4b5%253ALT716d260b38ed3dc4bbf612aaf154e4bace37df51 "Aromatherapy Wooden Tealight Candles | Set of 2 | Essential Oil Soy Candles | Hand-Poured Vegan | Reusable Bowl | Toxin-Free Luxury Gift")




Add to Favorites


- [![Gift Set of 6 Tealight Candles with Dried Botanicals - Scented with Pure Essential Oils](https://i.etsystatic.com/22716784/c/1919/1525/287/196/il/d919cf/4624691446/il_340x270.4624691446_hy39.jpg)\\
\\
**Gift Set of 6 Tealight Candles with Dried Botanicals - Scented with Pure Essential Oils**\\
\\
$41.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/825682960/gift-set-of-6-tealight-candles-with?click_key=a4d155ddacbbe79dfc925180bd97d4b5%3ALT1898ecde8738fd1b151a295e07582f25f7875322&click_sum=3947fbfc&ls=r&ref=related-2&content_source=a4d155ddacbbe79dfc925180bd97d4b5%253ALT1898ecde8738fd1b151a295e07582f25f7875322 "Gift Set of 6 Tealight Candles with Dried Botanicals - Scented with Pure Essential Oils")




Add to Favorites


- [![Bath Soak for Aromatherapy and Relaxation - Essential Oil Bath Salts (2oz)](https://i.etsystatic.com/22716784/r/il/959ee2/4995070791/il_340x270.4995070791_f1jk.jpg)\\
\\
**Bath Soak for Aromatherapy and Relaxation - Essential Oil Bath Salts (2oz)**\\
\\
$4.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1491234227/bath-soak-for-aromatherapy-and?click_key=a4d155ddacbbe79dfc925180bd97d4b5%3ALTfd65bd0347aa922cbbf153a6e375fcce58cd3a7e&click_sum=825c7fa0&ls=r&ref=related-3&content_source=a4d155ddacbbe79dfc925180bd97d4b5%253ALTfd65bd0347aa922cbbf153a6e375fcce58cd3a7e "Bath Soak for Aromatherapy and Relaxation - Essential Oil Bath Salts (2oz)")




Add to Favorites


- [![Ceremonial Grade Matcha Tea | Premium Japanese Green Tea Powder | Matcha Latte Blend | Small Batch Artisan Tea | Megan’s Pantry](https://i.etsystatic.com/22716784/r/il/e3d39e/7346995844/il_340x270.7346995844_qezy.jpg)\\
\\
**Ceremonial Grade Matcha Tea \| Premium Japanese Green Tea Powder \| Matcha Latte Blend \| Small Batch Artisan Tea \| Megan’s Pantry**\\
\\
$14.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1511676958/ceremonial-grade-matcha-tea-o-premium?click_key=6b6d5e0d550e60a3d5caf1739f883595f484fbb6%3A1511676958&click_sum=ff4004c3&ref=related-4 "Ceremonial Grade Matcha Tea | Premium Japanese Green Tea Powder | Matcha Latte Blend | Small Batch Artisan Tea | Megan’s Pantry")




Add to Favorites



Loading...

Loading


**Disclaimer:** Button/coin batteries may cause serious injury and even death if swallowed. Items containing button/coin batteries should not be easily accessible without the use of a tool. Sellers are responsible for complying with all applicable labeling, design, testing, packaging, and other safety requirements. Etsy assumes no responsibility for the accuracy or contents of a seller’s listing. If you have questions about button/coin batteries, contact the seller by sending a Message. See Etsy's [Terms of Use](https://www.etsy.com/legal/terms-of-use/?ref=product_safety_banner_info_button_batteries_risk#warranties) for more information.

Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 10, 2025


[16865 favorites](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=733e523f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=733e523f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=733e523f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=733e523f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Prints

[Buy Gallery Wall Online](https://www.etsy.com/market/gallery_wall)

Home Decor

[Buy Washington State Ornament Online](https://www.etsy.com/market/washington_state_ornament) [Shop Paper Tapestry Art](https://www.etsy.com/market/paper_tapestry_art) [Christian D Larson for Sale](https://www.etsy.com/market/christian_d_larson) [20 X 28 Scripture Wall Art for Sale](https://www.etsy.com/market/20_x_28_scripture_wall_art) [Woodland Snowman Ceramics for Sale](https://www.etsy.com/market/woodland_snowman_ceramics) [Shop Holiday Wreaths For Front Door](https://www.etsy.com/market/holiday_wreaths_for_front_door) [Shop Extra Large Gold Tray](https://www.etsy.com/market/extra_large_gold_tray) [Flapper Bat - US](https://www.etsy.com/market/flapper_bat) [Wood Arch Decal for Sale](https://www.etsy.com/market/wood_arch_decal) [Buy Funny Insect Sign Online](https://www.etsy.com/market/funny_insect_sign) [Mewar Painting for Sale](https://www.etsy.com/market/mewar_painting) [Shop Footed Iron Bowl](https://www.etsy.com/market/footed_iron_bowl) [Buy Vintage Metal Icicles Online](https://www.etsy.com/market/vintage_metal_icicles)

Invitations & Paper

[Shop Nautical Escorts Cards For Wedding](https://www.etsy.com/market/nautical_escorts_cards_for_wedding)

Keychains & Lanyards

[Shop Badge Reel Medical Student](https://www.etsy.com/market/badge_reel_medical_student)

Shopping

[1950's Whisky Bottle for Sale](https://www.etsy.com/market/1950%27s_whisky_bottle) [Shop Starburst Face](https://www.etsy.com/market/starburst_face)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F825676258%2Fset-of-four-aromatherapy-tealight%3Famp%253Bclick_sum%3D733e523f%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgyMzMxNjoyMmFmODM1YjQxYWM5Y2MzMzQxYjUyZDEwNTgyNzE0Zg==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F825676258%2Fset-of-four-aromatherapy-tealight%3Famp%253Bclick_sum%3D733e523f%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?amp;click_sum=733e523f&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F825676258%2Fset-of-four-aromatherapy-tealight%3Famp%253Bclick_sum%3D733e523f%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for meganspantry

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: not accepted

Please contact the seller if you have any problems with your order.

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## Seller details

### Business registration number

### Location

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=281332274&referring_id=22716784&referring_type=shop&recipient_id=281332274&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_300x300.7406327307_ttiq.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/IMG_2397_ic2apw.jpg)

- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/b0794e/7358425410/il_300x300.7358425410_2drn.jpg)
- ![Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/2bb236/7358412974/il_300x300.7358412974_myn5.jpg)
- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/6f53e5/7358419714/il_300x300.7358419714_3glq.jpg)
- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/6d44bb/7358409928/il_300x300.7358409928_lz4o.jpg)
- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/070772/7358418862/il_300x300.7358418862_tjnd.jpg)
- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/ec72ca/7358412234/il_300x300.7358412234_7x5g.jpg)
- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/be551c/7406339089/il_300x300.7406339089_rjor.jpg)
- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/a0f2b5/7406340437/il_300x300.7406340437_m9tp.jpg)
- ![Set of four one ounce aromatherapy candles in a wooden cup reusable eco friendly sustainable pure soy and essential oil candle lavender eucalyptus orange grapefruit rosemary palmarosa essential oils and custom oil blends for calm gift relax spa gift Set of four essential oil soy tealight candles from Megan’s Pantry in reusable wooden bowls, adorned with botanicals—natural, eco-friendly aromatherapy gift set.](https://i.etsystatic.com/22716784/r/il/1a7799/7358411042/il_300x300.7358411042_6b5l.jpg)

- ![](https://i.etsystatic.com/iap/f58c91/6523362018/iap_640x640.6523362018_aufh0m9h.jpg?version=0)

5 out of 5 stars

Super cute! I got a set of 4 to add to some gifts for friends. Smell nice and the shipping was fast/got here before Christmas. She also had everything very neatly packaged.
I love the aesthetic of the wooden bowl/container and that it’s low waste when you’re done with the candle.

![](https://i.etsystatic.com/iusa/7d571d/96741820/iusa_75x75.96741820_fhu4.jpg?version=0)

Dec 24, 2024


[Melissa](https://www.etsy.com/people/gioe7wsj)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/005259/6524907021/iap_640x640.6524907021_s3k7x9fy.jpg?version=0)

4 out of 5 stars

Candles are small but they smell good.

Dec 2, 2024


[Canitria Cook](https://www.etsy.com/people/lu5za0oh1v978k4l)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/5bdaf5/5084406883/iap_640x640.5084406883_tekxl046.jpg?version=0)

4 out of 5 stars

Cute little candles, they're obviously small and it's easy to use the entire candle in one sitting but I love the reusable bowl after it's done! They also smell amazing even inside the box!

![](https://i.etsystatic.com/iusa/edcca3/75580832/iusa_75x75.75580832_6tj7.jpg?version=0)

Jun 26, 2023


[Jessica Miller](https://www.etsy.com/people/2j87ofak)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/042e60/6565148975/iap_640x640.6565148975_ebtn5ivs.jpg?version=0)

5 out of 5 stars

All of the scents are really great! Subtle and natural smelling. Beautifully crafted candles. These will make perfect stocking stuffers for my daughters- thank you!

Dec 20, 2024


[Diane Gravino](https://www.etsy.com/people/dmgravino)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/d617eb/4951417072/iap_640x640.4951417072_b9ophe7y.jpg?version=0)

5 out of 5 stars

The candles were smaller than I expected, however, that was my fault for not reading the description where it clearly states their size. They came exactly as advertised, looked cute, and smelled great!

May 29, 2023


[Shellie White](https://www.etsy.com/people/whitesl94)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/25db27/7108585058/iap_640x640.7108585058_i2i031m1.jpg?version=0)

4 out of 5 stars

They are really really tiny, though they were bigger, a little disappointed with the size. So far they smell really good and they arrived fast.

Aug 14, 2025


[Stacyann Williams](https://www.etsy.com/people/47i5hcysdjqotnlh)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/8d7c79/6723012008/iap_640x640.6723012008_hir3duju.jpg?version=0)

5 out of 5 stars

Beautiful candles! Smell so good!

![](https://i.etsystatic.com/iusa/f72657/102293181/iusa_75x75.102293181_bvhz.jpg?version=0)

Mar 17, 2025


[angie8gomez](https://www.etsy.com/people/angie8gomez)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/6e74fe/6848735599/iap_640x640.6848735599_gzdj693p.jpg?version=0)

5 out of 5 stars

I absolutely love the candles!

Apr 18, 2025


[Mary Keaton](https://www.etsy.com/people/pk48ywmg)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/c2fea3/6943636691/iap_640x640.6943636691_sxs2auy3.jpg?version=0)

5 out of 5 stars

They're perfect when you don't want a lot of candle.

May 28, 2025


[Janet McAllister](https://www.etsy.com/people/cyknxn5qxt9xxuz1)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/aebc0d/4581018161/iap_640x640.4581018161_pwt4bv9e.jpg?version=0)

5 out of 5 stars

Love ❤️ these candles!!! Wonderful aroma!!! Thank you again!!!❤️❤️❤️❤️❤️

Jan 17, 2023


[Suzanne](https://www.etsy.com/people/uhqty1sn)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/52a7c4/6754784396/iap_640x640.6754784396_5zmyj0l0.jpg?version=0)

5 out of 5 stars

They were small, but that’s what they were described, but in person it felt smaller. But I love how it used only essential oils. No added fragrances. It was for a gift.

![](https://i.etsystatic.com/iusa/c52eab/28926251/iusa_75x75.28926251_keso.jpg?version=0)

Mar 30, 2025


[Janelle Schumacher](https://www.etsy.com/people/janelleschumacher)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/4ec998/6517568289/iap_640x640.6517568289_rwh1anxs.jpg?version=0)

5 out of 5 stars

As described... they smell amazing and are so pretty!

Nov 29, 2024


[Lauri](https://www.etsy.com/people/peoxlv2f)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/c75f6b/6680822335/iap_640x640.6680822335_he3ehhr3.jpg?version=0)

5 out of 5 stars

Owner of shop was quick to respond. Very friendly, helpful and polite. The candles are beautiful (as described) they smell amazing! Thank you. I highly recommend shop!

Feb 9, 2025


[Joanna A](https://www.etsy.com/people/jalejo0410)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/705d62/7289749926/iap_640x640.7289749926_67pbrwg8.jpg?version=0)

5 out of 5 stars

They are a lot smaller than they appear. These were a gift for my mom and she loves them.

Oct 15, 2025


[Tiff Cline](https://www.etsy.com/people/gj6fd9r96cj5hwrx)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/77c9c3/4507016492/iap_640x640.4507016492_oew0nmdb.jpg?version=0)

5 out of 5 stars

They came in so quickly - and they smell AMAZING!! They look exactly like the picture. Thank you so much!!

![](https://i.etsystatic.com/iusa/9aed8c/63944866/iusa_75x75.63944866_mn1w.jpg?version=0)

Jan 10, 2023


[Katie Brown](https://www.etsy.com/people/rqyolh2f)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/5740ba/5661283107/iap_640x640.5661283107_dxhm75fb.jpg?version=0)

5 out of 5 stars

Excellent customer service. Beautiful little votives that smell amazing.
Thank you

Dec 21, 2023


[melissa dodd](https://www.etsy.com/people/doddme73)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/e6f970/6177830053/iap_640x640.6177830053_1l3e1535.jpg?version=0)

5 out of 5 stars

They arrived incredibly fast and they look and smell great!

![](https://i.etsystatic.com/iusa/f36674/40554505/iusa_75x75.40554505_3fi9.jpg?version=0)

Jul 16, 2024


[Jacqui Aguirre](https://www.etsy.com/people/jacquiaguirre1)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/4b793e/6611849561/iap_640x640.6611849561_czvlofxt.jpg?version=0)

5 out of 5 stars

So cute and little but they smell so fresh! Love that they are handmade!

![](https://i.etsystatic.com/iusa/9f500c/83454934/iusa_75x75.83454934_qomr.jpg?version=0)

Jan 12, 2025


[Elizabeth Wilson](https://www.etsy.com/people/ebw81808)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/c7063c/5610846710/iap_640x640.5610846710_2y7jmxjt.jpg?version=0)

4 out of 5 stars

Purchased as a gift. I sat them on my dresser, still inside the box and forgot about them. For days I was trying to figure out what that amazing fragrance was. It was the candles!! I can only imagine what they smell like lit. Will purchase some for myself

Dec 20, 2023


[Sharina Straughn](https://www.etsy.com/people/xpdc12x11yo5ncz0)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/62a9eb/6907684627/iap_640x640.6907684627_knpwnwyn.jpg?version=0)

3 out of 5 stars

The candles were so small and did not even last a day. They were quite pricey for that.

May 13, 2025


[Lorri](https://www.etsy.com/people/eb9wreldpbdgr2ho)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)

Purchased item:

[![Set of Four Aromatherapy Tealight Candles | One Ounce Wooden Bowl Candle with Dried Flowers | Essential Oil Infused | Wellness Gift](https://i.etsystatic.com/22716784/r/il/f3ea30/7406327307/il_170x135.7406327307_ttiq.jpg)\\
\\
Set of Four Aromatherapy Tealight Candles \| One Ounce Wooden Bowl Candle with Dried Flowers \| Essential Oil Infused \| Wellness Gift\\
\\
$22.00](https://www.etsy.com/listing/825676258/set-of-four-aromatherapy-tealight?ref=ap-listing)