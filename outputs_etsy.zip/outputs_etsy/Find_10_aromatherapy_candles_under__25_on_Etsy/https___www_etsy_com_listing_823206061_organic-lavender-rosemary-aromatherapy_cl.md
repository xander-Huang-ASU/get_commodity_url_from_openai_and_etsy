[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?amp;click_sum=802b6154&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=802b6154&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=802b6154&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=802b6154&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=802b6154&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&explicit=1&ref=catnav_breadcrumb-3)
- [Container Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/container-candles?amp%3Bclick_sum=802b6154&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&explicit=1&ref=catnav_breadcrumb-4)


Add to Favorites


- ![May include: A brown glass jar candle with a white wax top. The jar has a brown paper label that reads 'Botanical Garden', 'Lavender + Lemon', 'Sandalwood + Rosemary', 'All Natural', and 'Hand Poured in California'. The candle is decorated with dried lavender, rosemary, and purple crystals.](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_794xN.2405646525_alug.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![May include: Two brown glass candle jars with white wax and purple and red crystals. The jars have brown paper labels with the text 'Botanical Garden' and 'La Provence' and the scents 'Lavender + Lemon' and 'Sandalwood + Rosemary'. The labels also state 'All Natural' and 'Hand Poured in California'. The candles are on a white surface with a brown ribbon and a sprig of rosemary.](https://i.etsystatic.com/22361469/r/il/047164/2613918604/il_794xN.2613918604_rhaz.jpg)
- ![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift- image 3](https://i.etsystatic.com/22361469/r/il/240c5c/2612466661/il_794xN.2612466661_f6f4.jpg)
- ![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift- image 4](https://i.etsystatic.com/22361469/r/il/f6cbd0/4171236947/il_794xN.4171236947_klr0.jpg)
- ![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift- image 5](https://i.etsystatic.com/22361469/r/il/7f0fe8/2612466633/il_794xN.2612466633_elvp.jpg)
- ![May include: A brown glass candle jar with a natural cotton wick, amethyst crystals, and organic botanicals. The label reads 'Botanical Garden - La Provence - Lavender + Lemon Sandalwood + Rosemary - All Natural - Hand Poured in California' and features a logo with the word 'MADGE'.](https://i.etsystatic.com/22361469/r/il/1fffe2/2661576799/il_794xN.2661576799_6x7a.jpg)
- ![May include: A brown glass candle jar with a white label that reads 'Botanical Garden Lavender + Lemon Sandalwood + Rosemary - All Natural - Hand Poured in California'. The candle jar is sitting on a wooden surface with a sprig of rosemary in the foreground. The candle jar has a white wax top with two purple amethyst crystals on top.](https://i.etsystatic.com/22361469/r/il/559c7e/2362070054/il_794xN.2362070054_p743.jpg)
- ![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift- image 8](https://i.etsystatic.com/22361469/r/il/d0f8ea/4126956968/il_794xN.4126956968_gh09.jpg)
- ![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift- image 9](https://i.etsystatic.com/22361469/r/il/adaf4e/5683574686/il_794xN.5683574686_knb0.jpg)
- ![May include: A brown glass candle jar with a white candle inside. The label on the jar reads 'Botanical Garden - La Provence - Lavender + Lemon Sandalwood + Rosemary - All Natural - Hand Poured in California.'](https://i.etsystatic.com/22361469/r/il/d7c317/5821622528/il_794xN.5821622528_43fs.jpg)

- ![May include: A brown glass jar candle with a white wax top. The jar has a brown paper label that reads 'Botanical Garden', 'Lavender + Lemon', 'Sandalwood + Rosemary', 'All Natural', and 'Hand Poured in California'. The candle is decorated with dried lavender, rosemary, and purple crystals.](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_75x75.2405646525_alug.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/video_3_gxtjno.jpg)

- ![May include: Two brown glass candle jars with white wax and purple and red crystals. The jars have brown paper labels with the text 'Botanical Garden' and 'La Provence' and the scents 'Lavender + Lemon' and 'Sandalwood + Rosemary'. The labels also state 'All Natural' and 'Hand Poured in California'. The candles are on a white surface with a brown ribbon and a sprig of rosemary.](https://i.etsystatic.com/22361469/r/il/047164/2613918604/il_75x75.2613918604_rhaz.jpg)
- ![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift- image 3](https://i.etsystatic.com/22361469/r/il/240c5c/2612466661/il_75x75.2612466661_f6f4.jpg)
- ![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift- image 4](https://i.etsystatic.com/22361469/r/il/f6cbd0/4171236947/il_75x75.4171236947_klr0.jpg)
- ![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift- image 5](https://i.etsystatic.com/22361469/r/il/7f0fe8/2612466633/il_75x75.2612466633_elvp.jpg)
- ![May include: A brown glass candle jar with a natural cotton wick, amethyst crystals, and organic botanicals. The label reads 'Botanical Garden - La Provence - Lavender + Lemon Sandalwood + Rosemary - All Natural - Hand Poured in California' and features a logo with the word 'MADGE'.](https://i.etsystatic.com/22361469/r/il/1fffe2/2661576799/il_75x75.2661576799_6x7a.jpg)
- ![May include: A brown glass candle jar with a white label that reads 'Botanical Garden Lavender + Lemon Sandalwood + Rosemary - All Natural - Hand Poured in California'. The candle jar is sitting on a wooden surface with a sprig of rosemary in the foreground. The candle jar has a white wax top with two purple amethyst crystals on top.](https://i.etsystatic.com/22361469/r/il/559c7e/2362070054/il_75x75.2362070054_p743.jpg)
- ![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift- image 8](https://i.etsystatic.com/22361469/r/il/d0f8ea/4126956968/il_75x75.4126956968_gh09.jpg)
- ![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift- image 9](https://i.etsystatic.com/22361469/r/il/adaf4e/5683574686/il_75x75.5683574686_knb0.jpg)
- ![May include: A brown glass candle jar with a white candle inside. The label on the jar reads 'Botanical Garden - La Provence - Lavender + Lemon Sandalwood + Rosemary - All Natural - Hand Poured in California.'](https://i.etsystatic.com/22361469/r/il/d7c317/5821622528/il_75x75.5821622528_43fs.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F823206061%2Forganic-lavender-rosemary-aromatherapy%23report-overlay-trigger)

5 views in the last 24 hours

Price:$18.00+


Loading


# Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-

[MadgeCandleStore](https://www.etsy.com/shop/MadgeCandleStore?ref=shop-header-name&listing_id=823206061&from_page=listing)

[5 out of 5 stars](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?amp;click_sum=802b6154&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1#reviews)

Ships from California

Arrives soon! Get it by

Nov 14-24


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

Style


Select an option

With Dry Flowers ($20.00 - $28.00)

Plain ($18.00 - $22.99)

Please select an option


Jars


Select an option

Amber Jar 9oz ($22.99 - $28.00)

Amber Jar 4oz ($18.00 - $20.00)

Please select an option


Quantity



12345678910111213141516171819202122232425262728293031323334

You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Designed by [MadgeCandleStore](https://www.etsy.com/shop/MadgeCandleStore)

- Ships from California! Shorter shipping distances are

kinder to the planet

Ordering items closer to you is more likely to reduce your purchase's carbon footprint.


- Materials: Wax type: Soy


- Volume: 9 fluid ounces

- Gift wrapping available

See details![](https://i.etsystatic.com/igwp/e87178/4532825295/igwp_300xN.4532825295_cb3d3stt.jpg?version=0)

Why us? - Because we only make HEALTHY candles!!

Madge Candle is proudly now invited to be in the top 10 most visited art museums in the United Stateds - De Young Museum Store in San Francisco!!

❤️ALL NATURAL!!!

💜NON- ARTIFICIAL FRAGRANCE!

💚ALLERGY FREE!!!

🤎PREMIUM AROMATHERAPY CANDLE -- SLOW BURN! IT SMELLS SO GOOD!!

PLEASE NOTE:

\- We do NOT design power strong fake scent candles! Please read before purchase. This is the difference between essential oil

candles & fragrance oil candles!

9oz JAR CAN BURN UP TO 65-80 HOURS!

100% Natural Soy Wax Candles with Top Pure Essential Oil & Organic California Botanicals.

Aromatherapy Relaxing Candles.

\- Botanical Garden - La Provence :

Lavender + Rosemary + Lemon + Sandalwood

Amethyst Crystal Stones

\- Ingredients:

100% Soy Wax

Pure Essential Oil

Organic California Dried Flowers

Amethyst Crystal Stones

\- Comes in:

9 oz Glass Jar with lid

\- Elegant Packaging

Each Order comes with elegant packaging.

Clients can customize his/her own messages attach to the candle jar.

\- Handle Time:

Ordered candle will be blended & created in one day when you place the order so that it can keep the fresh scent.

\- Please note: 100% Essential oil with soy wax won’t smell as strong as a Fragrance oil.

Chemical fragrance brews are a mixture of many fragrance ingredients. They cause a wide range of health issues, from headaches and dizziness to asthma, and are even linked to some types of cancer. We focus on making healthier candles & we care about nature & the environment we live in.

\- We do NOT recommend using this candle in a windy area.


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-24**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 14 days


- Ships from: **Richmond, CA**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------CanadaPuerto RicoSaint Pierre and MiquelonUnited States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (345)

4.8/5

item average

4.9Item quality

4.7Shipping

4.4Customer service

93%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Smells amazing

Beautiful

Well packaged

Love it

Gift-worthy

Would recommend

Lovely


Filter by category


Quality (127)


Shipping & Packaging (112)


Appearance (76)


Seller service (28)


Description accuracy (9)


Comfort (7)


Value (6)


Ease of use (1)


Sizing & Fit (1)


Condition (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/f4d35c/23923483/iusa_75x75.23923483_mgh1.jpg?version=0)

[pinkshoes81](https://www.etsy.com/people/pinkshoes81?ref=l_review)
Jul 27, 2025


Great as always! I order these candles on repeat



![](https://i.etsystatic.com/iusa/f4d35c/23923483/iusa_75x75.23923483_mgh1.jpg?version=0)

[pinkshoes81](https://www.etsy.com/people/pinkshoes81?ref=l_review)
Jul 27, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/e59724/23503393/iusa_75x75.23503393_6tzp.jpg?version=0)

[mrsjscott22](https://www.etsy.com/people/mrsjscott22?ref=l_review)
Jul 5, 2025


I loved the scent of this candle! I will definitely be ordering more!



![](https://i.etsystatic.com/iusa/e59724/23503393/iusa_75x75.23503393_6tzp.jpg?version=0)

[mrsjscott22](https://www.etsy.com/people/mrsjscott22?ref=l_review)
Jul 5, 2025


5 out of 5 stars
5

This item

[Ezea](https://www.etsy.com/people/bahq8brk?ref=l_review)
Mar 11, 2025


Would highly recommend this seller. The candles burn evenly and have a light smell that still fills s room. Perfect for anyone with sensitivities to perfumes



[Ezea](https://www.etsy.com/people/bahq8brk?ref=l_review)
Mar 11, 2025


5 out of 5 stars
5

This item

[Noah](https://www.etsy.com/people/npw6e3oydqenjemh?ref=l_review)
Mar 4, 2025


great smell plus free gems



[Noah](https://www.etsy.com/people/npw6e3oydqenjemh?ref=l_review)
Mar 4, 2025


View all reviews for this item

### Photos from reviews

![pinkshoes81 added a photo of their purchase](https://i.etsystatic.com/iap/f7d938/4769446371/iap_300x300.4769446371_2y9r7s0n.jpg?version=0)

![Aven added a photo of their purchase](https://i.etsystatic.com/iap/88c0de/4424188652/iap_300x300.4424188652_3xfkhzm7.jpg?version=0)

![Ayesha added a photo of their purchase](https://i.etsystatic.com/iap/d3847f/4301621069/iap_300x300.4301621069_lc4zv22a.jpg?version=0)

![Whitney added a photo of their purchase](https://i.etsystatic.com/iap/6f9005/4203525605/iap_300x300.4203525605_dw07tdmn.jpg?version=0)

![Tiffany added a photo of their purchase](https://i.etsystatic.com/iap/1abd0c/4079976556/iap_300x300.4079976556_nf96mj5l.jpg?version=0)

![pinkshoes81 added a photo of their purchase](https://i.etsystatic.com/iap/873636/4031303924/iap_300x300.4031303924_8g44xlrp.jpg?version=0)

![lily added a photo of their purchase](https://i.etsystatic.com/iap/c39e51/3700420086/iap_300x300.3700420086_pq1fmkn2.jpg?version=0)

![Millie added a photo of their purchase](https://i.etsystatic.com/iap/a7da4e/3653345568/iap_300x300.3653345568_o4iflsih.jpg?version=0)

![Shaunna added a photo of their purchase](https://i.etsystatic.com/iap/56e30b/3628090772/iap_300x300.3628090772_77zgizmu.jpg?version=0)

![Tina added a photo of their purchase](https://i.etsystatic.com/iap/d1ab49/3603747671/iap_300x300.3603747671_ex2ha74e.jpg?version=0)

![Violet added a photo of their purchase](https://i.etsystatic.com/iap/204825/3600660683/iap_300x300.3600660683_ej1cmycm.jpg?version=0)

![lauralinnea added a photo of their purchase](https://i.etsystatic.com/iap/723fb8/3595366745/iap_300x300.3595366745_4v97hbhi.jpg?version=0)

![stephanie added a photo of their purchase](https://i.etsystatic.com/iap/aedf52/3470936316/iap_300x300.3470936316_bk9kfrbk.jpg?version=0)

![Ayesha added a photo of their purchase](https://i.etsystatic.com/iap/297756/3453449040/iap_300x300.3453449040_5gwno7pu.jpg?version=0)

![hinh515 added a photo of their purchase](https://i.etsystatic.com/iap/c7de1d/3277984095/iap_300x300.3277984095_b7k5ra18.jpg?version=0)

![ttompkins3 added a photo of their purchase](https://i.etsystatic.com/iap/c2e1de/3140693638/iap_300x300.3140693638_3pxzxwif.jpg?version=0)

![Yinhsu added a photo of their purchase](https://i.etsystatic.com/iap/3dd098/3145283619/iap_300x300.3145283619_81838uzq.jpg?version=0)

![Bella added a photo of their purchase](https://i.etsystatic.com/iap/b48108/3053387763/iap_300x300.3053387763_suk1buyi.jpg?version=0)

![Anna added a photo of their purchase](https://i.etsystatic.com/iap/7e802c/3005552406/iap_300x300.3005552406_rq8ej4n5.jpg?version=0)

![Natasha added a photo of their purchase](https://i.etsystatic.com/iap/d9c1c9/3003610666/iap_300x300.3003610666_8eg9giwr.jpg?version=0)

[![MadgeCandleStore](https://i.etsystatic.com/iusa/2efb7d/79621050/iusa_75x75.79621050_4mg7.jpg?version=0)](https://www.etsy.com/shop/MadgeCandleStore?ref=shop_profile&listing_id=823206061)

[MadgeCandleStore](https://www.etsy.com/shop/MadgeCandleStore?ref=shop_profile&listing_id=823206061)

[Owned by Maggie L. Usselton](https://www.etsy.com/shop/MadgeCandleStore?ref=shop_profile&listing_id=823206061) \|

Richmond, California

4.8
(1.7k)


8k sales

5 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=276886741&referring_id=823206061&referring_type=listing&recipient_id=276886741&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyNzY4ODY3NDE6MTc2MjgyMzI3NzplZWMyZmQ3MDIzMjk4N2JlYTkyMTEzZWQ3YjYwNTA4Yg%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F823206061%2Forganic-lavender-rosemary-aromatherapy%3Famp%253Bclick_sum%3D802b6154%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1)

This seller usually responds **within a few hours.**

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/MadgeCandleStore?ref=lp_mys_mfts)

- [![Eucalyptus Aromatherapy Soy Candle: Organic Botanicals & Essential Oils](https://i.etsystatic.com/22361469/r/il/b1d425/4104952335/il_340x270.4104952335_5nr1.jpg)\\
\\
**Eucalyptus Aromatherapy Soy Candle: Organic Botanicals & Essential Oils**\\
\\
$16.50\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1280014453/eucalyptus-aromatherapy-soy-candle?click_key=b52fbb1123fb61215ce3e25532690e32%3ALTb5397fa2b0ebab99b0e5665895865d89c7395ee9&click_sum=502798ff&ls=r&ref=related-1&content_source=b52fbb1123fb61215ce3e25532690e32%253ALTb5397fa2b0ebab99b0e5665895865d89c7395ee9 "Eucalyptus Aromatherapy Soy Candle: Organic Botanicals & Essential Oils")




Add to Favorites


- [![Organic Cypress Pine Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/16cdbe/4076352402/il_340x270.4076352402_b0y1.jpg)\\
\\
**Organic Cypress Pine Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-**\\
\\
$16.50\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/910789847/organic-cypress-pine-aromatherapy-soy?click_key=b52fbb1123fb61215ce3e25532690e32%3ALTa8240395b88c4b56a0cfc9ab0208cb19c940b63d&click_sum=cfe08cc2&ls=r&ref=related-2&content_source=b52fbb1123fb61215ce3e25532690e32%253ALTa8240395b88c4b56a0cfc9ab0208cb19c940b63d "Organic Cypress Pine Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-")




Add to Favorites


- [![Jasmine Rose Aromatherapy Soy Candle: Organic Dried Flowers, Essential Oil](https://i.etsystatic.com/22361469/r/il/379152/2308460960/il_340x270.2308460960_du70.jpg)\\
\\
**Jasmine Rose Aromatherapy Soy Candle: Organic Dried Flowers, Essential Oil**\\
\\
$18.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/765855862/jasmine-rose-aromatherapy-soy-candle?click_key=b52fbb1123fb61215ce3e25532690e32%3ALT5eee756cff4d43bccd7928469523fba34f55e963&click_sum=d56d9e3f&ls=r&ref=related-3&content_source=b52fbb1123fb61215ce3e25532690e32%253ALT5eee756cff4d43bccd7928469523fba34f55e963 "Jasmine Rose Aromatherapy Soy Candle: Organic Dried Flowers, Essential Oil")




Add to Favorites


- [![Cedarwood Rosemary Soy Candle: Aromatherapy Essential Oil, Dried Flowers](https://i.etsystatic.com/22361469/r/il/f4ebef/4105036121/il_340x270.4105036121_t8sn.jpg)\\
\\
**Cedarwood Rosemary Soy Candle: Aromatherapy Essential Oil, Dried Flowers**\\
\\
$18.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/828107872/cedarwood-rosemary-soy-candle?click_key=b52fbb1123fb61215ce3e25532690e32%3ALTcbc6625f3804b568dc84c910f7c37ea0281b330f&click_sum=8babb3d7&ls=r&ref=related-4&content_source=b52fbb1123fb61215ce3e25532690e32%253ALTcbc6625f3804b568dc84c910f7c37ea0281b330f "Cedarwood Rosemary Soy Candle: Aromatherapy Essential Oil, Dried Flowers")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 8, 2025


[2100 favorites](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=802b6154&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=802b6154&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=802b6154&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=802b6154&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&explicit=1&ref=breadcrumb_listing) [Container Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/container-candles?amp%3Bclick_sum=802b6154&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Home Decor

[Ny Giants Wreath for Sale](https://www.etsy.com/market/ny_giants_wreath) [Ironwoman for Sale](https://www.etsy.com/market/ironwoman) [Vintage KB Italy Ruby Red Bell cherubs and chariot Scene Gold Handle And Accents 5 3/4” by FLANAGANCOLLECTIBLES](https://www.etsy.com/listing/1754093868/vintage-kb-italy-ruby-red-bell-cherubs) [Christmas Door Hanger - Home Decor](https://www.etsy.com/listing/1797196804/christmas-door-hanger-holly-jolly-door) [Minimalist - Peel and Stick Removable and Prepasted Smooth Wallpaper by JacksonsWovens](https://www.etsy.com/listing/1870550073/sage-striped-wallpaper-pencil-stripes) [Taekwondo Medals for Sale](https://www.etsy.com/market/taekwondo_medals) [VALENTINES GNOME](https://www.etsy.com/listing/1151666268/valentines-gnome-amigurumi-home-decor) [Crescent Moon Printable Wall Decor](https://www.etsy.com/listing/1192576819/dark-moon-printable-wall-art-crescent) [Jmu Nutcracker - US](https://www.etsy.com/market/jmu_nutcracker) [Laser cut](https://www.etsy.com/listing/1763325639/laser-cut-wall-hanging-work-of-art-multi)

Luggage & Travel

[Beer League Baseball Stainless Steel Tumbler - Luggage & Travel](https://www.etsy.com/listing/1269117376/beer-league-baseball-stainless-steel)

Beads Gems & Cabochons

[15pcs Clock charms Bronze tone Lovely Clock Irregular Oval Charm Pendant 22x13mm](https://www.etsy.com/listing/701103272/15pcs-clock-charms-bronze-tone-lovely)

Shopping

[Tiny Solid Gold Chain Necklace for Sale](https://www.etsy.com/market/tiny_solid_gold_chain_necklace) [Tin Can For Candle - US](https://www.etsy.com/market/tin_can_for_candle)

Floral Arranging Supplies

[Yellow Rose Garland for Sale](https://www.etsy.com/market/yellow_rose_garland)

Suit & Tie Accessories

[Oasis Wedding Necktie by MenLauTies](https://www.etsy.com/listing/734696962/oasis-wedding-necktie-mens-oasis)

Brooches Pins & Clips

[Gucci Shoe Charm - US](https://www.etsy.com/market/gucci_shoe_charm)

Sculpture

[Shop Life Size Gorilla Statue](https://www.etsy.com/market/life_size_gorilla_statue)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F823206061%2Forganic-lavender-rosemary-aromatherapy%3Famp%253Bclick_sum%3D802b6154%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgyMzI3NzowNjdhZDdkOGRhMDU0YzQ0YjM0YjYxN2M2NzQ4NDJkOQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F823206061%2Forganic-lavender-rosemary-aromatherapy%3Famp%253Bclick_sum%3D802b6154%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?amp;click_sum=802b6154&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F823206061%2Forganic-lavender-rosemary-aromatherapy%3Famp%253Bclick_sum%3D802b6154%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Seller details

### Business registration number

### Location

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=276886741&referring_id=22361469&referring_type=shop&recipient_id=276886741&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![May include: A brown glass jar candle with a white wax top. The jar has a brown paper label that reads 'Botanical Garden', 'Lavender + Lemon', 'Sandalwood + Rosemary', 'All Natural', and 'Hand Poured in California'. The candle is decorated with dried lavender, rosemary, and purple crystals.](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_300x300.2405646525_alug.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/video_3_gxtjno.jpg)

- ![May include: Two brown glass candle jars with white wax and purple and red crystals. The jars have brown paper labels with the text 'Botanical Garden' and 'La Provence' and the scents 'Lavender + Lemon' and 'Sandalwood + Rosemary'. The labels also state 'All Natural' and 'Hand Poured in California'. The candles are on a white surface with a brown ribbon and a sprig of rosemary.](https://i.etsystatic.com/22361469/r/il/047164/2613918604/il_300x300.2613918604_rhaz.jpg)
- ![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift- image 3](https://i.etsystatic.com/22361469/r/il/240c5c/2612466661/il_300x300.2612466661_f6f4.jpg)
- ![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift- image 4](https://i.etsystatic.com/22361469/r/il/f6cbd0/4171236947/il_300x300.4171236947_klr0.jpg)
- ![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift- image 5](https://i.etsystatic.com/22361469/r/il/7f0fe8/2612466633/il_300x300.2612466633_elvp.jpg)
- ![May include: A brown glass candle jar with a natural cotton wick, amethyst crystals, and organic botanicals. The label reads 'Botanical Garden - La Provence - Lavender + Lemon Sandalwood + Rosemary - All Natural - Hand Poured in California' and features a logo with the word 'MADGE'.](https://i.etsystatic.com/22361469/r/il/1fffe2/2661576799/il_300x300.2661576799_6x7a.jpg)
- ![May include: A brown glass candle jar with a white label that reads 'Botanical Garden Lavender + Lemon Sandalwood + Rosemary - All Natural - Hand Poured in California'. The candle jar is sitting on a wooden surface with a sprig of rosemary in the foreground. The candle jar has a white wax top with two purple amethyst crystals on top.](https://i.etsystatic.com/22361469/r/il/559c7e/2362070054/il_300x300.2362070054_p743.jpg)
- ![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift- image 8](https://i.etsystatic.com/22361469/r/il/d0f8ea/4126956968/il_300x300.4126956968_gh09.jpg)
- ![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift- image 9](https://i.etsystatic.com/22361469/r/il/adaf4e/5683574686/il_300x300.5683574686_knb0.jpg)
- ![May include: A brown glass candle jar with a white candle inside. The label on the jar reads 'Botanical Garden - La Provence - Lavender + Lemon Sandalwood + Rosemary - All Natural - Hand Poured in California.'](https://i.etsystatic.com/22361469/r/il/d7c317/5821622528/il_300x300.5821622528_43fs.jpg)

- ![](https://i.etsystatic.com/iap/f7d938/4769446371/iap_640x640.4769446371_2y9r7s0n.jpg?version=0)

5 out of 5 stars

- Label Choices:

Original Madge label

- Jars:

Amber Jar 9oz


I will never buy candles anywhere else..think this is my 3rd or 4th reorder. Smell is lovely but not overpowering and visually they’re just darling

![](https://i.etsystatic.com/iusa/f4d35c/23923483/iusa_75x75.23923483_mgh1.jpg?version=0)

Mar 14, 2023


[pinkshoes81](https://www.etsy.com/people/pinkshoes81)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/88c0de/4424188652/iap_640x640.4424188652_3xfkhzm7.jpg?version=0)

5 out of 5 stars

- Label Choices:

Original Madge label

- Jars:

Amber Jar 9oz


Why is it so perfect?

![](https://i.etsystatic.com/iusa/72a8f6/69390836/iusa_75x75.69390836_f2p4.jpg?version=0)

Dec 10, 2022


[Aven Candlelight](https://www.etsy.com/people/zkcdrqxn)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/d3847f/4301621069/iap_640x640.4301621069_lc4zv22a.jpg?version=0)

5 out of 5 stars

- Label Choices:

Original Madge label

- Jars:

Amber Jar 9oz


My favorite of all scents.. A beautiful lavender.. I just love love how fragrant this candle is and how it can fill the room with lavender scent.. A gift to myself when I done with all of the older Madge Candles.. I have them all and like to stock up..

Edited to add picture of using it..

![](https://i.etsystatic.com/iusa/24f28a/90135631/iusa_75x75.90135631_c7sn.jpg?version=0)

Oct 15, 2022


[Ayesha Shoaib](https://www.etsy.com/people/ComfyJoey)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/6f9005/4203525605/iap_640x640.4203525605_dw07tdmn.jpg?version=0)

5 out of 5 stars

- Label Choices:

Original Madge label

- Jars:

Amber Jar 9oz


This candle is the best part of my self care.

Sep 11, 2022


[Whitney Hayes](https://www.etsy.com/people/bg7s1imc3wgbbdz0)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/1abd0c/4079976556/iap_640x640.4079976556_nf96mj5l.jpg?version=0)

5 out of 5 stars

- Label Choices:

Original Madge label

- Jars:

Amber Jar 9oz


This is my second purchase of these candles. They come so beautifully packaged and they are almost too pretty to light. But they have a lovely light clean scent and I will continue to purchase. Thank you Madge!

Aug 13, 2022


[Tiffany B](https://www.etsy.com/people/tiffanybahri)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/873636/4031303924/iap_640x640.4031303924_8g44xlrp.jpg?version=0)

5 out of 5 stars

- Label Choices:

Original Madge label

- Jars:

Amber Jar 9oz


Second time ordering - so beautiful and even better quality.

![](https://i.etsystatic.com/iusa/f4d35c/23923483/iusa_75x75.23923483_mgh1.jpg?version=0)

Jul 23, 2022


[pinkshoes81](https://www.etsy.com/people/pinkshoes81)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/c39e51/3700420086/iap_640x640.3700420086_pq1fmkn2.jpg?version=0)

5 out of 5 stars

This was my second purchase. Their products and packing are professional and really great! I will order again!

![](https://i.etsystatic.com/iusa/b318ce/92986560/iusa_75x75.92986560_dlnu.jpg?version=0)

Feb 27, 2022


[lily](https://www.etsy.com/people/5d1zqw4yzfut458h)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/a7da4e/3653345568/iap_640x640.3653345568_o4iflsih.jpg?version=0)

5 out of 5 stars

These candles are AMAZING! They smell wonderful and they are beautiful. The packaging is lovely and the seller put an impressive amount of effort into every detail. I bought these for myself but they are perfect as a gift too. It got all the way down to Puerto Rico very quickly and I will be buying again! Highly recommended!

![](https://i.etsystatic.com/iusa/a74628/112848875/iusa_75x75.112848875_fe57.jpg?version=0)

Feb 7, 2022


[Millie M. Villafane](https://www.etsy.com/people/hemwgfqb)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/56e30b/3628090772/iap_640x640.3628090772_77zgizmu.jpg?version=0)

5 out of 5 stars

I was really excited to receive this and it didn’t disappoint. The packaging was pretty and the candle looks and smells just as pretty. Thank you.

Jan 27, 2022


[Shaunna Schukis](https://www.etsy.com/people/ky117kmw)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/d1ab49/3603747671/iap_640x640.3603747671_ex2ha74e.jpg?version=0)

5 out of 5 stars

Very beautiful…smells like a spa

![](https://i.etsystatic.com/iusa/e4554f/25731219/iusa_75x75.25731219_qvs5.jpg?version=0)

Dec 27, 2021


[Tina Pazos](https://www.etsy.com/people/tpazos35)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/204825/3600660683/iap_640x640.3600660683_ej1cmycm.jpg?version=0)

5 out of 5 stars

Stunning candles inside and out. Packaged and made with such care ,thought and the best ingredients. Our second year purchasing these beauties from Madge for the holidays.🌟 (\*\*\* seller is so kind\*\*\*.)

![](https://i.etsystatic.com/iusa/c4db9b/56199156/iusa_75x75.56199156_p8di.jpg?version=0)

Dec 24, 2021


[Violet](https://www.etsy.com/people/fv43xbng)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/723fb8/3595366745/iap_640x640.3595366745_4v97hbhi.jpg?version=0)

5 out of 5 stars

Superior customer service. The seller was so helpful! I love the candle packaging and appreciate that they are made with essential oils not fragrance oils. The scent is fresh and clean. Thank you so much!

Dec 21, 2021


[lauralinnea](https://www.etsy.com/people/ricls5z5)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/aedf52/3470936316/iap_640x640.3470936316_bk9kfrbk.jpg?version=0)

5 out of 5 stars

The candles look and smell great! It was well packaged and delivered fast. A perfect gift for the holidays.

Nov 15, 2021


[stephanie cirka](https://www.etsy.com/people/stephaniecirka)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/297756/3453449040/iap_640x640.3453449040_5gwno7pu.jpg?version=0)

5 out of 5 stars

What can I say.. The candle looks exactly as pictured and is the cutest candle ever.. Love the scent.. Was packaged with love and so much of care.. My daughter loves her gift.. Thank you ♡♡♡

![](https://i.etsystatic.com/iusa/24f28a/90135631/iusa_75x75.90135631_c7sn.jpg?version=0)

Nov 8, 2021


[Ayesha Shoaib](https://www.etsy.com/people/ComfyJoey)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/c7de1d/3277984095/iap_640x640.3277984095_b7k5ra18.jpg?version=0)

5 out of 5 stars

I’m loving this lavender! You could tell a lot of thought went into Maggie’s candles, from the presentation to the hand picked flowers and how each scent was chosen. She was able to send me a separate box as I purchased a few candles for a gift. I’ll be returning for more candles in the future, so will my friends!

![](https://i.etsystatic.com/iusa/4e35b7/112948456/iusa_75x75.112948456_jwxm.jpg?version=0)

Jul 27, 2021


[hinh515](https://www.etsy.com/people/hinh515)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/c2e1de/3140693638/iap_640x640.3140693638_3pxzxwif.jpg?version=0)

5 out of 5 stars

Such a cute candle. I am burning it now after cleaning and the entire house smells lovely! 10/10 WILL repurchase.

Jun 11, 2021


[ttompkins3](https://www.etsy.com/people/ttompkins3)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/3dd098/3145283619/iap_640x640.3145283619_81838uzq.jpg?version=0)

5 out of 5 stars

Love the candles, and the communication, to the moon and back! <3 Thank you for creating such loving products! <3<3<3

![](https://i.etsystatic.com/iusa/5c6af9/89523515/iusa_75x75.89523515_4iwz.jpg?version=0)

May 21, 2021


[Yinhsu Liu](https://www.etsy.com/people/yliu39)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/b48108/3053387763/iap_640x640.3053387763_suk1buyi.jpg?version=0)

5 out of 5 stars

This candle not only smells amazing but also looks very presentable. The packaging it came with was so beautiful and I love everything about it! Will be purchasing again.

![](https://i.etsystatic.com/iusa/e0f256/99729579/iusa_75x75.99729579_nd4l.jpg?version=0)

Apr 10, 2021


[Bella](https://www.etsy.com/people/exafb16q58v78prn)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/7e802c/3005552406/iap_640x640.3005552406_rq8ej4n5.jpg?version=0)

5 out of 5 stars

Ohhh my goodness, this smells amazing and the packaging is amazing. I can definitely tell this was made and shipped with care. Thank you so much for an amazing candle. I was worried about it shipping from CA all the way to FL it made it and didn’t melt.. Thank you again. I’ll be ordering more very soon..

See in original language


Translated by [Microsoft](http://aka.ms/MicrosoftTranslatorAttribution)

Ohhh my goodness, this smells amazing and the packaging is amazing. I can definitely tell this was made and shipped with care. Thank you so much for an amazing candle. I was worried about it shipping from CA all the way to FL it made it and didn’t melt.. Thank you again. I’ll be ordering more very soon..


![](https://i.etsystatic.com/iusa/440bd1/66417365/iusa_75x75.66417365_zvvx.jpg?version=0)

Apr 10, 2021


[Anna Duncan](https://www.etsy.com/people/annaduncan907)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/d9c1c9/3003610666/iap_640x640.3003610666_8eg9giwr.jpg?version=0)

5 out of 5 stars

Smells beautifully! Love it!

Apr 9, 2021


[Natasha Keys](https://www.etsy.com/people/natashakeys)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)

Purchased item:

[![Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-](https://i.etsystatic.com/22361469/r/il/c9abaa/2405646525/il_170x135.2405646525_alug.jpg)\\
\\
Organic Lavender Rosemary Aromatherapy Soy Candle-All Natural-100% Essential Oil-Organic Dry Flowers-Long Lasting 9oz-Gift-\\
\\
$18.00](https://www.etsy.com/listing/823206061/organic-lavender-rosemary-aromatherapy?ref=ap-listing)