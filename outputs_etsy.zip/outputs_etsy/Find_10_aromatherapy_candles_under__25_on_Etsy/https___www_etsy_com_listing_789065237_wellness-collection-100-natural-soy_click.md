[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/789065237/wellness-collection-100-natural-soy?amp;click_sum=64c36436&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=64c36436&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=64c36436&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=64c36436&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=64c36436&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&explicit=1&ref=catnav_breadcrumb-3)

Bestseller

This item has had a high sales volume over the past 6 months.



Add to Favorites


- ![May include: A close-up image of multiple amber glass candle jars with white wax and various natural ingredients, including small green and brown pieces, and larger orange and brown pieces. The candles are arranged in a circular pattern with the tops of the jars facing the viewer.](https://i.etsystatic.com/11861778/r/il/b0b125/5921188054/il_794xN.5921188054_baqm.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free image 2](https://i.etsystatic.com/11861778/r/il/b2c3b7/3635099336/il_794xN.3635099336_pvso.jpg)
- ![May include: A brown glass jar candle with a white label that reads 'HEAL', 'LEMONGRASS - GERANIUM - PEPPERMINT', 'INFUSED WITH CLEAR QUARTZ', 'HAND CRAFTED WITH INTENTION', 'TO HEAL THE MIND, BODY & SOUL', 'NATURE BASED WELLNESS'.](https://i.etsystatic.com/11861778/r/il/e1b91a/5054818383/il_794xN.5054818383_7w3o.jpg)
- ![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free image 4](https://i.etsystatic.com/11861778/r/il/f5b3a9/4706032163/il_794xN.4706032163_o4gp.jpg)
- ![May include: Two candle jars with gold lids and labels that read 'Mindfulness' in brown text. The candle jars are on a woven straw surface. The candle jar on the left has a brown label with the text 'Mindfulness, Bergamot - Orange Blossom - Vanilla Infused with Citrine, Fluorite & Rose Quartz, Hand Crafted with Intention to Inspire Presence, Gratitude & Compassion for Yourself & Others, Earth Tonik, Nature Based Wellness.' The candle jar on the right has a gold label with the text 'Mindfulness, Wellness Collection, 50-Hour Burn Time, 100% Natural Soy Wax, Infused with Natural Botanicals & Healing Crystals, Earth Tonik, Nature Based Wellness, Small Batch-Hand Poured in Gainesville, FL, Etsy & Instagram @earthtonik.'](https://i.etsystatic.com/11861778/r/il/44b3a5/5006589330/il_794xN.5006589330_rfow.jpg)
- ![May include: A clear glass bottle with a brown wooden lid and a string hanging from the lid. The bottle is filled with a clear liquid and small white and pink stones. The bottle is labeled 'El Tr](https://i.etsystatic.com/11861778/r/il/e72497/5921187508/il_794xN.5921187508_kv2j.jpg)
- ![May include: A brown glass bottle with a black cap. The bottle is labeled 'Carth Touif Nature Based Wellness Moon Dance Sea Salt - Cedarwood - Patchouli' and has instructions for use: 'Add 10-12 drops to water in an electric diffuser. Add 10-12 drops onto a hanging clay or wood diffuser. Natural - Phthalate Free Premium Fragrance Oil 10 ML.'](https://i.etsystatic.com/11861778/r/il/169f25/6006444875/il_794xN.6006444875_6teh.jpg)
- ![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free image 8](https://i.etsystatic.com/11861778/r/il/146841/7209010453/il_794xN.7209010453_swio.jpg)
- ![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free image 9](https://i.etsystatic.com/11861778/r/il/9a3a35/7161021984/il_794xN.7161021984_m33l.jpg)
- ![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free image 10](https://i.etsystatic.com/11861778/r/il/dd1539/7310506784/il_794xN.7310506784_e8fg.jpg)

- ![May include: A close-up image of multiple amber glass candle jars with white wax and various natural ingredients, including small green and brown pieces, and larger orange and brown pieces. The candles are arranged in a circular pattern with the tops of the jars facing the viewer.](https://i.etsystatic.com/11861778/r/il/b0b125/5921188054/il_75x75.5921188054_baqm.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/VID_54321022_232620_501_1_kc4fzn.jpg)

- ![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free image 2](https://i.etsystatic.com/11861778/r/il/b2c3b7/3635099336/il_75x75.3635099336_pvso.jpg)
- ![May include: A brown glass jar candle with a white label that reads 'HEAL', 'LEMONGRASS - GERANIUM - PEPPERMINT', 'INFUSED WITH CLEAR QUARTZ', 'HAND CRAFTED WITH INTENTION', 'TO HEAL THE MIND, BODY & SOUL', 'NATURE BASED WELLNESS'.](https://i.etsystatic.com/11861778/r/il/e1b91a/5054818383/il_75x75.5054818383_7w3o.jpg)
- ![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free image 4](https://i.etsystatic.com/11861778/r/il/f5b3a9/4706032163/il_75x75.4706032163_o4gp.jpg)
- ![May include: Two candle jars with gold lids and labels that read 'Mindfulness' in brown text. The candle jars are on a woven straw surface. The candle jar on the left has a brown label with the text 'Mindfulness, Bergamot - Orange Blossom - Vanilla Infused with Citrine, Fluorite & Rose Quartz, Hand Crafted with Intention to Inspire Presence, Gratitude & Compassion for Yourself & Others, Earth Tonik, Nature Based Wellness.' The candle jar on the right has a gold label with the text 'Mindfulness, Wellness Collection, 50-Hour Burn Time, 100% Natural Soy Wax, Infused with Natural Botanicals & Healing Crystals, Earth Tonik, Nature Based Wellness, Small Batch-Hand Poured in Gainesville, FL, Etsy & Instagram @earthtonik.'](https://i.etsystatic.com/11861778/r/il/44b3a5/5006589330/il_75x75.5006589330_rfow.jpg)
- ![May include: A clear glass bottle with a brown wooden lid and a string hanging from the lid. The bottle is filled with a clear liquid and small white and pink stones. The bottle is labeled 'El Tr](https://i.etsystatic.com/11861778/r/il/e72497/5921187508/il_75x75.5921187508_kv2j.jpg)
- ![May include: A brown glass bottle with a black cap. The bottle is labeled 'Carth Touif Nature Based Wellness Moon Dance Sea Salt - Cedarwood - Patchouli' and has instructions for use: 'Add 10-12 drops to water in an electric diffuser. Add 10-12 drops onto a hanging clay or wood diffuser. Natural - Phthalate Free Premium Fragrance Oil 10 ML.'](https://i.etsystatic.com/11861778/r/il/169f25/6006444875/il_75x75.6006444875_6teh.jpg)
- ![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free image 8](https://i.etsystatic.com/11861778/r/il/146841/7209010453/il_75x75.7209010453_swio.jpg)
- ![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free image 9](https://i.etsystatic.com/11861778/r/il/9a3a35/7161021984/il_75x75.7161021984_m33l.jpg)
- ![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free image 10](https://i.etsystatic.com/11861778/r/il/dd1539/7310506784/il_75x75.7310506784_e8fg.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F789065237%2Fwellness-collection-100-natural-soy%23report-overlay-trigger)

In 14 carts

Price:$10.00+


Loading


# Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free

Made by [EarthTonix](https://www.etsy.com/shop/EarthTonix)

[5 out of 5 stars](https://www.etsy.com/listing/789065237/wellness-collection-100-natural-soy?amp;click_sum=64c36436&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3#reviews)

Arrives soon! Get it by

Nov 17-19


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Scent


Select an option

ABUNDANCE

BOOST MOOD

BREATHE

CALM

CLARITY

COMPASSION

ENERGY

FOCUS

FREE SPIRIT

GENTLENESS

GRATITUDE

GROUNDED

HARMONY

HEAL

INVIGORATE

MERCURY RETROGRADE

MINDFULNESS

PATIENCE

PEACE

PRESENCE

REST

SACRED SAGE

SELF LOVE

SOL SISTER

STILLNESS

STRENGTH

VISUALIZE

WISDOM

YOU GLOW GIRL

Please select an option


Volume


Select an option

9 oz Cande ($22.00)

16 oz Candle ($44.00)

Wax Melts ($10.00)

Car Diffuser ($16.00)

10 ML Fragrance Oil ($14.00)

4 oz Room Mist ($16.00)

Please select an option


Quantity



1234567891011121314151617181920

4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Buy together, get free shipping

## Buy together, get free shipping

Add both to cart



Loading


[See more items](https://www.etsy.com/listing/789065237/wellness-collection-100-natural-soy?amp;click_sum=64c36436&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3#recs_ribbon_container)

![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic -  Phthalate Free](https://i.etsystatic.com/11861778/r/il/b0b125/5921188054/il_340x270.5921188054_baqm.jpg)
This listing

### Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free

$10.00


Add to Favorites


[![Cauldron Candles - 100% Soy Candle infused with Crystals, Herbs, Botanicals & Magic - Fall - Halloween -Witchy- Pumpkin-Spell- Free Shipping](https://i.etsystatic.com/11861778/r/il/ffd673/3255231188/il_340x270.3255231188_hv7f.jpg)\\
\\
**Cauldron Candles - 100% Soy Candle infused with Crystals, Herbs, Botanicals & Magic - Fall - Halloween -Witchy- Pumpkin-Spell- Free Shipping**\\
\\
$36.00](https://www.etsy.com/listing/872594799/cauldron-candles-100-soy-candle-infused?click_key=74bd062b5acc69198e257ac74b4e0a88%3ALTb6160edc53d7b94e01af4e2b82c689587672d458&click_sum=9ac70657&ls=r&ref=listing-free-shipping-bundle-1&content_source=74bd062b5acc69198e257ac74b4e0a88%253ALTb6160edc53d7b94e01af4e2b82c689587672d458 "Cauldron Candles - 100% Soy Candle infused with Crystals, Herbs, Botanicals & Magic - Fall - Halloween -Witchy- Pumpkin-Spell- Free Shipping")


Add to Favorites


![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic -  Phthalate Free](https://i.etsystatic.com/11861778/r/il/b0b125/5921188054/il_340x270.5921188054_baqm.jpg)
This listing

### Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free

$10.00


Add to Favorites


[![Cauldron Candles - 100% Soy Candle infused with Crystals, Herbs, Botanicals & Magic - Fall - Halloween -Witchy- Pumpkin-Spell- Free Shipping](https://i.etsystatic.com/11861778/r/il/ffd673/3255231188/il_340x270.3255231188_hv7f.jpg)\\
\\
**Cauldron Candles - 100% Soy Candle infused with Crystals, Herbs, Botanicals & Magic - Fall - Halloween -Witchy- Pumpkin-Spell- Free Shipping**\\
\\
$36.00](https://www.etsy.com/listing/872594799/cauldron-candles-100-soy-candle-infused?click_key=74bd062b5acc69198e257ac74b4e0a88%3ALTb6160edc53d7b94e01af4e2b82c689587672d458&click_sum=9ac70657&ls=r&ref=listing-free-shipping-bundle-1&content_source=74bd062b5acc69198e257ac74b4e0a88%253ALTb6160edc53d7b94e01af4e2b82c689587672d458 "Cauldron Candles - 100% Soy Candle infused with Crystals, Herbs, Botanicals & Magic - Fall - Halloween -Witchy- Pumpkin-Spell- Free Shipping")


Add to Favorites


![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic -  Phthalate Free](https://i.etsystatic.com/11861778/r/il/b0b125/5921188054/il_340x270.5921188054_baqm.jpg)
This listing

### Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free

$10.00


Add to Favorites


[![Cauldron Candles - 100% Soy Candle infused with Crystals, Herbs, Botanicals & Magic - Fall - Halloween -Witchy- Pumpkin-Spell- Free Shipping](https://i.etsystatic.com/11861778/r/il/ffd673/3255231188/il_340x270.3255231188_hv7f.jpg)\\
\\
**Cauldron Candles - 100% Soy Candle infused with Crystals, Herbs, Botanicals & Magic - Fall - Halloween -Witchy- Pumpkin-Spell- Free Shipping**\\
\\
$36.00](https://www.etsy.com/listing/872594799/cauldron-candles-100-soy-candle-infused?click_key=74bd062b5acc69198e257ac74b4e0a88%3ALTb6160edc53d7b94e01af4e2b82c689587672d458&click_sum=9ac70657&ls=r&ref=listing-free-shipping-bundle-1&content_source=74bd062b5acc69198e257ac74b4e0a88%253ALTb6160edc53d7b94e01af4e2b82c689587672d458 "Cauldron Candles - 100% Soy Candle infused with Crystals, Herbs, Botanicals & Magic - Fall - Halloween -Witchy- Pumpkin-Spell- Free Shipping")


Add to Favorites


## Item details

### Highlights

Made by [EarthTonix](https://www.etsy.com/shop/EarthTonix)

- Materials: Wax type: Soy


The Earth Tonix Wellness Collection

Scent Blends inspired by Holistic Health

Small Batch and Hand Crafted with intention

OPTIONS:

9 oz Soy Candle - 7.25 oz net wt

Amber glass jar with gold aluminum lid

Estimated Burn Time: 50+ Hours

16 oz Soy Candle - 16 oz net wt

Amber glass jar with natural cork lid

Estimated Burn Time: 110+ Hours

Scented Wax Melts - 2.7 oz net wt

Packaging made from recycled material

For no waste, Please also recycle after use

Estimated Scent Time: 50-70 Hours of Scent

Glass & Wood Hanging Car Diffuser (includes crystals)

TO USE: REMOVE WOODEN LID. THEN, CAREFULLY REMOVE PLASTIC CAP (TAKE CARE NOT TO SPILL). REPLACE WOODEN LID TIGHTLY. BRIEFLY FLIP THE BOTTLE UPSIDE DOWN TO SATURATE THE WOODEN LID IN OIL. HANG FROM REARVIEW MIRROR & REPEAT FLIP AS NEEDED.(ALSO GREAT FOR CLOSETS, OFFICE, BATHROOM, OR ANY SMALL SPACE)

10 ML Pure Premium Fragrance Oil (no crystals)

USE 2-10 DROPS TO WATER IN AN ELECTRIC DIFFUSER

ADD 1-2 DROPS ON A HANGING CLAY, FELT OR WOOD DIFFUSER

ADD 1-5 DROPS PER OZ OF CARRIER OIL FOR USE ON SKIN

ADD 1-5 DROPS TO SOAKING SALTS & ADD TO BATH

DO NOT USE ON SKIN WITHOUT DILUTING & TEST ON SMALL PATCH

4 oz Non Toxic Room Mist in amber glass bottle (infused with crystals)

Shake well & lightly mist the air in your space. Great for the moments that need a quick scent burst (after cooking, before company arrives, etc). The beautiful non toxic scent will linger for hours!

\*not intended for use on body\*

A Long, clean, even burn with strong scent throw!

Clean ingredients - no headaches - Aromatherapy for everyone!

Vegan, Made with 100% Natural USA Grown Soy Wax, Cotton Wick, High End Non-Toxic Fragrance Oils Infused with Pure Essential Oils in a Reusable Glass Jar.

Each is adorned with Natural & Intentional Healing Crystals & Botanicals.

Designed for Holistic Wellness & Aromatherapy.

All candles are Phthalate Free, Lead & Zinc Free, Non-Toxic & Meet RIFM and IFRA standards for safety and purity.

SCENT CHOICES:

ABUNDANCE: (Previously named Happy Daze)

SCENT NOTES: LIME, BASIL, MANDARIN

CRYSTAL INFUSED WITH: CARNELIAN & AMAZONITE

USE: EMBRACE PLAYFULNESS & CONFIDENCE TO LIVE LIFE TO THE FULLEST

BOOST MOOD:

SCENT NOTES: GRAPEFRUIT, LEMON, GERANIUM

CRYSTAL INFUSED WITH: CITRINE, AMETHYST & CARNELIAN

USE: UNWIND TENSION & ANXIETY, BALANCE EMOTIONS, EMBRACE POSITIVITY

BREATHE:

SCENT NOTES: EUCALYPTUS, PEPPERMINT, PATCHOULI

CRYSTAL INFUSED WITH: HOWLITE

USE: REDUCES ANXIETY, TENSION & STRESS

CALM:

SCENT NOTES: BERGAMOT, CUCUMBER, BAMBOO

CRYSTAL INFUSED WITH: BLACK TOURMALINE, AMETHYST, AMAZONITE

USE: PROTECTION FROM NEGATIVITY, STRESS, & ANXIETY

CLARITY:

SCENT NOTES: EUCALYPTUS, LAVENDER, CEDARWOOD

INFUSED WITH: FLUORITE

USE: PROMOTES PEACEFUL THINKING & CLEAR FOCUS

COMPASSION:

SCENT NOTES: CARDAMOM, ROSE, PEPPERCORN

CRYSTAL INFUSED WITH: ROSE QUARTZ & LAPIS LAZULI

USE: TO ENCOURAGE KINDNESS, UNCONDITIONAL LOVE & EMPATHY

ENERGY:

SCENT NOTES: SAFFRON, GINGER, PATCHOULI

CRYSTAL INFUSED WITH: CARNELIAN

USE: PROVIDES ENERGY & A WELLNESS BOOST

FOCUS:

SCENT NOTES: EUCALYPTUS, FIR NEEDLE, ROSEMARY

CRYSTAL INFUSED WITH: FLUORITE

USE: BOOSTS CONCENTRATION & MEMORY

FREE SPIRIT:

SCENT NOTES: GRAPEFRUIT, ORANGE, RED CURRANT

CRYSTAL INFUSED WITH: CITRINE

USE: INSPIRES HAPPINESS, COURAGE, CREATIVITY

GENTLENESS:

SCENT NOTES: SPEARMINT, EUCALYPTUS, LAVENDER, CEDARWOOD

CRYSTAL INFUSED WITH: AMETHYST, CLEAR QUARTZ & ROSE QUARTZ

USE: TO INSPIRE CALMNESS, COMPASSION & KINDNESS TOWARD OTHERS & ONESELF

GRATITUDE:

SCENT NOTES: FIR NEEDLE, RED CURRANT, JUNIPER

CRYSTAL INFUSED WITH: ROSE QUARTZ & PICTURE JASPER

USE: HARMONY, BALANCE, POSITIVITY, APPRECIATION & LOVE

GROUNDED:

SCENT NOTES: LAVENDER, ROSEMARY, SAGE, SANDALWOOD

CRYSTAL INFUSED WITH: TIGERS EYE & PICTURE JASPER

USE: TO INSPIRE CALM & CLEAR THINKING, STABILITY & RESILIENCE

HARMONY:

SCENT NOTES: JUNIPER, GERaNIUM, CYPRESS, CEDAR

CRYSTAL INFUSED WITH: AMAZONITE & MOONSTONE

USE: TO MOTIVATE BALANCE & ALIGNMENT, LEADING TO A SENSE OF INNER PEACE & WELL BEING

HEAL:

SCENT NOTES: LEMONGRASS, GERANIUM, PEPPERMINT

CRYSTAL INFUSED WITH: CLEAR QUARTZ

USE: HEAL THE MIND, BODY & SOUL

INVIGORATE:

SCENT NOTES: EUCALYPTUS, LAVENDER, LEMONGRASS, BLACK PEPPER, CEDARWOOD

CRYSTAL INFUSED WITH: CARNELIAN & CITRINE

USE: REFRESH ENERGY & INSPIRE STRENGTH

MERCURY RETROGRADE:

SCENT NOTES: GRAPE, GERANIUM, PATCHOULI

CRYSTAL INFUSED WITH: AMAZONITE, BLACK TOURMALINE, LAPIS LAZULI & LABRADORITE

USE: LETTING GO OF FEAR & ANXIETY, SUPPORTS HONEST COMMUNICATION, INSPIRES EMOTIONAL STABILITY & CLARITY

MINDFULNESS:

SCENT NOTES: BERGAMOT, ORANGE BLOSSOM, VANILLA

CRYSTAL INFUSED WITH: CITRINE, FLUORITE, ROSE QUARTZ

USE: TO INSPIRE PRESENCE, GRATITUDE & COMPASSION FOR YOURSELF & OTHERS

PATIENCE:

SCENT NOTES: BERGAMOT, VETIVER, PATCHOULI

CRYSTAL INFUSED WITH: HOWLITE & GREEN AVENTURINE

USE: CALMS AN OVERACTIVE MIND, REDUCES ANXIOUS OR IRRITABLE THOUGHTS, INSPIRES PATIENCE

PEACE:

SCENT NOTES: PEACH, GARDENIA, MANGO

CRYSTAL INFUSED WITH: AMAZONITE, CITRINE & SUNSTONE

USE: MOTIVATES HOPE, OPTIMISM, CLARITY, JOY & HARMONY

PRESENCE:

SCENT NOTES: GRAPEFRUIT, CARDAMOM, ROSE, GINGER

CRYSTAL INFUSED WITH: CITRINE

USE: TO ENCOURAGE LIVING & BEING IN THE MOMENT

REST:

SCENT NOTES:LAVENDER, LEMON, CEDARWOOD

CRYSTAL INFUSED WITH: AMETHYST

USE: RELAXING ENERGY & ENHANCES SLEEP

SACRED SAGE:

SCENT NOTES: CEDARWOOD, LAVENDER, WHITE SAGE

CRYSTAL INFUSED WITH: CLEAR QUARTZ

USE: CLEARS NEGATIVE ENERGY & PROMOTES HEALING

SELF LOVE:

SCENT NOTES: SWEET ORANGE, ROSE, AMBER

CRYSTAL INFUSED WITH: LABRADORITE & ROSE QUARTZ

USE: ENCOURAGES LOVE & INNER HEALING

SOL SISTER:

SCENT NOTES: GRAPEFRUIT, BUCHU LEAF, BERGAMOT

CRYSTAL INFUSED WITH: SUNSTONE

USE: RADIATE LIGHT, HAPPINESS, OPTIMISM, WISDOM & CREATIVITY

STILLNESS:

SCENT NOTES: LAVENDER, VIOLET, ELEMI, SANDALWOOD

CRYSTALS INFUSED WITH: AMETHYST & AQUAMARINE

USE: PROMOTES PEACE, REST & TRANQUILITY, ALLOWING A DEEPER CONNECTION TO ONESELF & THE DIVINE

STRENGTH:

SCENT NOTES: CARDAMOM, LEMONGRASS, AMBER, PATCHOULI

CRYSTALS INFUSED WITH: RED JASPER & CARNELIAN

USE: ENCOURAGES STABILITY, ENDURANCE, COURAGE & VITALITY TO MOVE FORWARD & ACHIEVE GOALS

VISUALIZE:

SCEN NOTES: LIME, COCONUT, VETIVER

CRYSTAL INFUSED WITH: FLUORITE & LABRADORITE

USE: TO PROMOTE CALM & CLEAR THINKING TO EXPLORE DESIRES, INNER POWER & SELF GROWTH

WISDOM:

SCENT NOTES: BERGAMOT, FIG, SANDALWOOD

CRYSTAL INFUSED WITH: AMETHYST & LAPIS LAZULI

USE: TO ENCOURAGE INTUITION, KNOWLEDGE & DEEPER CONNECTION

YOU GLOW GIRL:

SCENT NOTES: BERGAMOT, GINGER, WHITE TEA

CRYSTAL INFUSED WITH: FLUORITE & CARNELIAN

USE: FOCUS, ENDURANCE & MOTIVATION

CANDLE CARE & SAFETY:

Always Burn within sight. Keep away from flammable objects.Keep away from children and pets. Remove Botanical Toppings before burning & extinguish any botanicals if they catch fire. Only burn the candle on a level & fire resistant surface. Trim wick to 1/4" before EACH lighting. Keep wick centered. For a long candle life, burn for atleast 2 hours before putting flame out (this creates an even wax pool and no tunneling). Do not burn candle for more than 4 hours at a time. Take care in collecting your crystals - do not touch hot wax. Stop use when only 1/4" of wax remains (Place on a candle warmer to enjoy remaining 1/4" of wax).

Disclaimer: Statements contained have not been evaluated by the Food and Drug Administration. These products are not intended to diagnose, treat , cure or prevent disease or substitute care by a medical practitioner. Earth Tonix, LLC is not responsible for misuse or care of products. All products are intended for adult unless otherwise stated

Use and store out of reach of children and pets. By purchasing buyer is aware and agrees to all policies.


## Shipping and return policies

Loading


- Order today to get by

**Nov 17-19**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges not accepted




But please contact me if you have problems with your order


- Ships from: **Gainesville, FL**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## Meet your seller

![Melinda York](https://i.etsystatic.com/11861778/c/2283/2283/383/400/isla/7012a2/79792089/isla_75x75.79792089_qzsg3zs5.jpg)

Melinda York

Owner of [EarthTonix](https://www.etsy.com/shop/EarthTonix?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyNDQzNDUxODoxNzYyODIzMzcyOjQ3NWYyNzZiMTVhMzk5YjZlNzg5MDBmOTAyOTM1ZTMx&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F789065237%2Fwellness-collection-100-natural-soy%3Famp%253Bclick_sum%3D64c36436%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3)

[Message Melinda](https://www.etsy.com/messages/new?with_id=24434518&referring_id=789065237&referring_type=listing&recipient_id=24434518&from_action=contact-seller)

This seller usually responds **within 24 hours.**

## Reviews for this item (147)

5.0/5

item average

5.0Item quality

5.0Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Love it

Smells amazing

Would recommend

Great product

Fast shipping

Gift-worthy

Beautiful


Filter by category


Quality (59)


Appearance (28)


Seller service (18)


Shipping & Packaging (17)


Value (7)


Comfort (3)


Condition (2)


Ease of use (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[dalila balleza](https://www.etsy.com/people/balleza241?ref=l_review)
Oct 25, 2025


I just placed my 3rd order for the breathe candle since my mom loves them. We’ve burned through 4 candles and have even give them as gifts. We can’t get enough!



[dalila balleza](https://www.etsy.com/people/balleza241?ref=l_review)
Oct 25, 2025


5 out of 5 stars
5

This item

[Lillian Vazquez Ratcliffe](https://www.etsy.com/people/lapcarlson?ref=l_review)
Oct 12, 2025


Smells so good and looks beautiful



[Lillian Vazquez Ratcliffe](https://www.etsy.com/people/lapcarlson?ref=l_review)
Oct 12, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/8b769c/95048705/iusa_75x75.95048705_3bp4.jpg?version=0)

[Sage](https://www.etsy.com/people/cocoacarbone?ref=l_review)
Jul 10, 2025


I left this one for last because it's my favorite! The perfect blend to promote peace and balance, it makes my room feel like a spiritual spa. I moved from California to Florida for 6 months to live with a man... Well, I currently live in California, so you can tell how that went. And let me tell you, one of the only good things that came from that experience was stumbling across Earth Tonix😉



![](https://i.etsystatic.com/iusa/8b769c/95048705/iusa_75x75.95048705_3bp4.jpg?version=0)

[Sage](https://www.etsy.com/people/cocoacarbone?ref=l_review)
Jul 10, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/8b769c/95048705/iusa_75x75.95048705_3bp4.jpg?version=0)

[Sage](https://www.etsy.com/people/cocoacarbone?ref=l_review)
Jul 10, 2025


I bought the 2oz to test the fragrance and also because I definitely need a boost of confidence right now in my life. It's no surprise that this is another beautiful fragrance blend, feminine, soft, and clean!



![](https://i.etsystatic.com/iusa/8b769c/95048705/iusa_75x75.95048705_3bp4.jpg?version=0)

[Sage](https://www.etsy.com/people/cocoacarbone?ref=l_review)
Jul 10, 2025


View all reviews for this item

### Photos from reviews

![Mary added a photo of their purchase](https://i.etsystatic.com/iap/56391b/6838124832/iap_300x300.6838124832_j9r0ecrs.jpg?version=0)

![jada added a photo of their purchase](https://i.etsystatic.com/iap/93d294/3129145200/iap_300x300.3129145200_5x25dsex.jpg?version=0)

![Kelli added a photo of their purchase](https://i.etsystatic.com/iap/23c2a8/3137531693/iap_300x300.3137531693_jua12mhd.jpg?version=0)

![katiewiatt added a photo of their purchase](https://i.etsystatic.com/iap/fe4805/2789128282/iap_300x300.2789128282_mirn82ns.jpg?version=0)

![Courtney added a photo of their purchase](https://i.etsystatic.com/iap/ad9164/2555010140/iap_300x300.2555010140_8nj3t1gu.jpg?version=0)

![Alika added a photo of their purchase](https://i.etsystatic.com/iap/fdc640/2535806729/iap_300x300.2535806729_2e3d1ctj.jpg?version=0)

![Palmer added a photo of their purchase](https://i.etsystatic.com/iap/e2e047/2351778176/iap_300x300.2351778176_8a001pfv.jpg?version=0)

![brittneysherman72 added a photo of their purchase](https://i.etsystatic.com/iap/1d101d/2344303839/iap_300x300.2344303839_fcy126ng.jpg?version=0)

[![EarthTonix](https://i.etsystatic.com/iusa/eb8e44/38262479/iusa_75x75.38262479_jqb1.jpg?version=0)](https://www.etsy.com/shop/EarthTonix?ref=shop_profile&listing_id=789065237)

[EarthTonix](https://www.etsy.com/shop/EarthTonix?ref=shop_profile&listing_id=789065237)

[Owned by Melinda York](https://www.etsy.com/shop/EarthTonix?ref=shop_profile&listing_id=789065237) \|

Gainesville, Florida

4.9
(1.1k)


6.5k sales

9 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=24434518&referring_id=789065237&referring_type=listing&recipient_id=24434518&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyNDQzNDUxODoxNzYyODIzMzcyOjQ3NWYyNzZiMTVhMzk5YjZlNzg5MDBmOTAyOTM1ZTMx&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F789065237%2Fwellness-collection-100-natural-soy%3Famp%253Bclick_sum%3D64c36436%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3)

This seller usually responds **within 24 hours.**

Smooth shippingHas a history of shipping on time with tracking.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/EarthTonix?ref=lp_mys_mfts)

- [![Original Collection - 100% Natural Soy Wax Candles, Wax Melts, Car Diffusers, Room Spray, 10ML Oil - NonToxic - Phthalate Free - SCENTS P-Z](https://i.etsystatic.com/11861778/c/2419/1921/385/859/il/0cb118/5083493814/il_340x270.5083493814_3w07.jpg)\\
\\
**Original Collection - 100% Natural Soy Wax Candles, Wax Melts, Car Diffusers, Room Spray, 10ML Oil - NonToxic - Phthalate Free - SCENTS P-Z**\\
\\
$10.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1297896360/original-collection-100-natural-soy-wax?click_key=3d2a456105b6d7246b7d5a84641c8165%3ALTe95600c1cf9bfe5f00efb5dc388615bc8986ebd7&click_sum=f60ff5e6&ls=r&ref=related-1&content_source=3d2a456105b6d7246b7d5a84641c8165%253ALTe95600c1cf9bfe5f00efb5dc388615bc8986ebd7 "Original Collection - 100% Natural Soy Wax Candles, Wax Melts, Car Diffusers, Room Spray, 10ML Oil - NonToxic - Phthalate Free - SCENTS P-Z")




Add to Favorites


- [![Santa Mug 2 Wick Soy Candle - Winter - Christmas - 100% Natural Soy Wax - Nontoxic- Clean -Phthalate Free - Holiday Gift - Free Shipping](https://i.etsystatic.com/11861778/r/il/c7522b/7362725506/il_340x270.7362725506_8o8l.jpg)\\
\\
**Santa Mug 2 Wick Soy Candle - Winter - Christmas - 100% Natural Soy Wax - Nontoxic- Clean -Phthalate Free - Holiday Gift - Free Shipping**\\
\\
$44.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4399596191/santa-mug-2-wick-soy-candle-winter?click_key=3d2a456105b6d7246b7d5a84641c8165%3ALTfdf11c136a442bb1b4e5fd6926f9c4730678a854&click_sum=fbb0bd2a&ls=r&ref=related-2&content_source=3d2a456105b6d7246b7d5a84641c8165%253ALTfdf11c136a442bb1b4e5fd6926f9c4730678a854 "Santa Mug 2 Wick Soy Candle - Winter - Christmas - 100% Natural Soy Wax - Nontoxic- Clean -Phthalate Free - Holiday Gift - Free Shipping")




Add to Favorites


- [![Aromatherapy Essential Oil Mists - Home, Linen and Body Mist - Skin Safe - Cleanse Air & Energy - 100% Natural - Pure - Alcohol Free - 4 oz](https://i.etsystatic.com/11861778/r/il/a5ec94/5315242700/il_340x270.5315242700_8o1v.jpg)\\
\\
**Aromatherapy Essential Oil Mists - Home, Linen and Body Mist - Skin Safe - Cleanse Air & Energy - 100% Natural - Pure - Alcohol Free - 4 oz**\\
\\
$12.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/563117722/aromatherapy-essential-oil-mists-home?click_key=3d2a456105b6d7246b7d5a84641c8165%3ALTfae2135bdf76dd73a7ff018e94d1d5561128aac5&click_sum=d0606bd3&ls=r&ref=related-3&content_source=3d2a456105b6d7246b7d5a84641c8165%253ALTfae2135bdf76dd73a7ff018e94d1d5561128aac5 "Aromatherapy Essential Oil Mists - Home, Linen and Body Mist - Skin Safe - Cleanse Air & Energy - 100% Natural - Pure - Alcohol Free - 4 oz")




Add to Favorites


- [![100% Pure Therapeutic Grade Essential Oil Blends - Holistic - Natural - Healing - Calm - Diffuser -  Nontoxic Home - Vegan - Aromatherapy](https://i.etsystatic.com/11861778/r/il/e06784/4357134746/il_340x270.4357134746_rgew.jpg)\\
\\
**100% Pure Therapeutic Grade Essential Oil Blends - Holistic - Natural - Healing - Calm - Diffuser - Nontoxic Home - Vegan - Aromatherapy**\\
\\
$12.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/689389688/100-pure-therapeutic-grade-essential-oil?click_key=3d2a456105b6d7246b7d5a84641c8165%3ALT1f8db1597a3cc058ae55d7c9d5289c07f336457c&click_sum=b4090bed&ls=r&ref=related-4&content_source=3d2a456105b6d7246b7d5a84641c8165%253ALT1f8db1597a3cc058ae55d7c9d5289c07f336457c "100% Pure Therapeutic Grade Essential Oil Blends - Holistic - Natural - Healing - Calm - Diffuser -  Nontoxic Home - Vegan - Aromatherapy")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading wedding form

Loading


## Top wedding searches to shop

[![](https://i.etsystatic.com/19757930/c/1333/1333/0/301/il/cfe72f/3482678762/il_300x300.3482678762_pxw3.jpg)\\
Bridesmaid gifts](https://www.etsy.com/search?q=bridesmaid+gifts&mosv=sese&moci=635510339037&mosi=618520640322&featured_listing=1110003408&ref=wedding_recs_lp_bridesmaid_gifts)

[![](https://i.etsystatic.com/19483987/r/il/42cd8d/2512481731/il_300x300.2512481731_8gz7.jpg)\\
Groomsmen gifts](https://www.etsy.com/search?q=groomsmen+gifts&mosv=sese&moci=635510339037&mosi=635510910189&featured_listing=761677858&ref=wedding_recs_lp_groomsmen_gifts)

[![](https://i.etsystatic.com/6748817/c/2000/2000/0/828/il/b140dc/3394740672/il_300x300.3394740672_mong.jpg)\\
Wedding gifts](https://www.etsy.com/search?q=wedding+gifts&mosv=sese&moci=635510339037&mosi=618520762754&featured_listing=1087712798&ref=wedding_recs_lp_wedding_gifts)

[![](https://i.etsystatic.com/5354512/r/il/35af5c/5783958379/il_300x300.5783958379_pio7.jpg)\\
Engagement gifts](https://www.etsy.com/search?q=engagement+gifts&mosv=sese&moci=635510339037&mosi=635511121285&featured_listing=190344599&ref=wedding_recs_lp_engagement_gifts)

Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 7, 2025


[219 favorites](https://www.etsy.com/listing/789065237/wellness-collection-100-natural-soy/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=64c36436&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=64c36436&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=64c36436&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=64c36436&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Pet Clothing Accessories & Shoes

[Greyhound Dog Scarf for Sale](https://www.etsy.com/market/greyhound_dog_scarf)

Home Decor

[Beautiful Colorful Wood Letter Door Hanger by SimplyShabbybyBella1](https://www.etsy.com/listing/215518494/beautiful-colorful-wood-letter-door) [Ganesha Wood for Sale](https://www.etsy.com/market/ganesha_wood) [Buy Homco 5101 Online](https://www.etsy.com/market/homco_5101) [Buy Finnish Crafts Online](https://www.etsy.com/market/finnish_crafts) [Christmas design on white Clay ornaments or gift tags by BlessItBySheila](https://www.etsy.com/listing/1329384004/christmas-design-on-white-clay-ornaments) [Malibu California Sunset Beach Scented Soy Candle by ColleensOutpost](https://www.etsy.com/listing/1794904521/malibu-california-sunset-beach-scented) [Design Gifts Inc. Soapstone Trinket Box Butterfly Floral Carved Stone Octagon](https://www.etsy.com/listing/4329482458/design-gifts-inc-soapstone-trinket-box) [Travertine for Sale](https://www.etsy.com/market/travertine) [Vintage Art Deco black amethyst trophy vase with silver overlay](https://www.etsy.com/listing/1115056675/vintage-art-deco-black-amethyst-trophy) [Fox Mulder prayer candle by Blackestnight](https://www.etsy.com/listing/1561253178/fox-mulder-prayer-candle) [Summer Breeze 8oz amber jar](https://www.etsy.com/listing/1825199040/summer-breeze-8oz-amber-jar) [Alaska Candle by CleverCrowCreative](https://www.etsy.com/listing/1667434053/alaska-candle-anchorage-ak-juneau-ak) [Buy Photography Wall Sign Online](https://www.etsy.com/market/photography_wall_sign)

Fabric & Notions

[Animal print fabric for Mask - Fabric & Notions](https://www.etsy.com/listing/823382695/safari-animal-prints-by-yard-animal)

Beads Gems & Cabochons

[Premium Vape Charm - Beads, Gems & Cabochons](https://www.etsy.com/listing/1592922649/premium-vape-charm-ecig-charm-stoner)

Girls Clothing

[Baby Girl Dress Special Occasion - Girls' Clothing](https://www.etsy.com/listing/1697543949/purple-mermaid-costumemermaid-dress-baby)

Gender Neutral Adult Clothing

[Comfort Colors Shirt by BBZCOLLECTION](https://www.etsy.com/listing/4329648792/comfort-colors-shirtsalty-shirtbeach)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F789065237%2Fwellness-collection-100-natural-soy%3Famp%253Bclick_sum%3D64c36436%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgyMzM3MjpiZjQ5OGM4ZjQzZDE0NDA1OGMyN2E5ODUyNDQ2YmY2ZQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F789065237%2Fwellness-collection-100-natural-soy%3Famp%253Bclick_sum%3D64c36436%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/789065237/wellness-collection-100-natural-soy?amp;click_sum=64c36436&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F789065237%2Fwellness-collection-100-natural-soy%3Famp%253Bclick_sum%3D64c36436%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for EarthTonix

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 2 days of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![May include: A close-up image of multiple amber glass candle jars with white wax and various natural ingredients, including small green and brown pieces, and larger orange and brown pieces. The candles are arranged in a circular pattern with the tops of the jars facing the viewer.](https://i.etsystatic.com/11861778/r/il/b0b125/5921188054/il_300x300.5921188054_baqm.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/VID_54321022_232620_501_1_kc4fzn.jpg)

- ![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free image 2](https://i.etsystatic.com/11861778/r/il/b2c3b7/3635099336/il_300x300.3635099336_pvso.jpg)
- ![May include: A brown glass jar candle with a white label that reads 'HEAL', 'LEMONGRASS - GERANIUM - PEPPERMINT', 'INFUSED WITH CLEAR QUARTZ', 'HAND CRAFTED WITH INTENTION', 'TO HEAL THE MIND, BODY & SOUL', 'NATURE BASED WELLNESS'.](https://i.etsystatic.com/11861778/r/il/e1b91a/5054818383/il_300x300.5054818383_7w3o.jpg)
- ![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free image 4](https://i.etsystatic.com/11861778/r/il/f5b3a9/4706032163/il_300x300.4706032163_o4gp.jpg)
- ![May include: Two candle jars with gold lids and labels that read 'Mindfulness' in brown text. The candle jars are on a woven straw surface. The candle jar on the left has a brown label with the text 'Mindfulness, Bergamot - Orange Blossom - Vanilla Infused with Citrine, Fluorite & Rose Quartz, Hand Crafted with Intention to Inspire Presence, Gratitude & Compassion for Yourself & Others, Earth Tonik, Nature Based Wellness.' The candle jar on the right has a gold label with the text 'Mindfulness, Wellness Collection, 50-Hour Burn Time, 100% Natural Soy Wax, Infused with Natural Botanicals & Healing Crystals, Earth Tonik, Nature Based Wellness, Small Batch-Hand Poured in Gainesville, FL, Etsy & Instagram @earthtonik.'](https://i.etsystatic.com/11861778/r/il/44b3a5/5006589330/il_300x300.5006589330_rfow.jpg)
- ![May include: A clear glass bottle with a brown wooden lid and a string hanging from the lid. The bottle is filled with a clear liquid and small white and pink stones. The bottle is labeled 'El Tr](https://i.etsystatic.com/11861778/r/il/e72497/5921187508/il_300x300.5921187508_kv2j.jpg)
- ![May include: A brown glass bottle with a black cap. The bottle is labeled 'Carth Touif Nature Based Wellness Moon Dance Sea Salt - Cedarwood - Patchouli' and has instructions for use: 'Add 10-12 drops to water in an electric diffuser. Add 10-12 drops onto a hanging clay or wood diffuser. Natural - Phthalate Free Premium Fragrance Oil 10 ML.'](https://i.etsystatic.com/11861778/r/il/169f25/6006444875/il_300x300.6006444875_6teh.jpg)
- ![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free image 8](https://i.etsystatic.com/11861778/r/il/146841/7209010453/il_300x300.7209010453_swio.jpg)
- ![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free image 9](https://i.etsystatic.com/11861778/r/il/9a3a35/7161021984/il_300x300.7161021984_m33l.jpg)
- ![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free image 10](https://i.etsystatic.com/11861778/r/il/dd1539/7310506784/il_300x300.7310506784_e8fg.jpg)

- ![](https://i.etsystatic.com/iap/56391b/6838124832/iap_640x640.6838124832_j9r0ecrs.jpg?version=0)

5 out of 5 stars

- Scent:

GENTLENESS

- Volume:

1 oz Tester


These candles are a wonderful gift item. The non-toxic fragrances are lovely, and very thoughtfully crafted. Buying the smaller sizes also a good way to discover your favorite scent (mine is “Peace”); very lovely item. Also a very helpful and kind seller. I made a mistake initially with my order and the seller very kindly and quickly made a correction. Highly recommend.

![](https://i.etsystatic.com/iusa/b5c37e/94000396/iusa_75x75.94000396_4fj6.jpg?version=0)

May 4, 2025


[Mary](https://www.etsy.com/people/carouba)

Purchased item:

[![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic -  Phthalate Free](https://i.etsystatic.com/11861778/r/il/b0b125/5921188054/il_170x135.5921188054_baqm.jpg)\\
\\
Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free\\
\\
$10.00](https://www.etsy.com/listing/789065237/wellness-collection-100-natural-soy?ref=ap-listing)

Purchased item:

[![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic -  Phthalate Free](https://i.etsystatic.com/11861778/r/il/b0b125/5921188054/il_170x135.5921188054_baqm.jpg)\\
\\
Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free\\
\\
$10.00](https://www.etsy.com/listing/789065237/wellness-collection-100-natural-soy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/93d294/3129145200/iap_640x640.3129145200_5x25dsex.jpg?version=0)

5 out of 5 stars

- Scent:

BLOOM


i found this shop through a locally owned business in my area and i completely fell in love with her products. i first purchased one of the wellness candles from said business. i searched for this shop on etsy and was shock by how many products she had. needless to say i could’ve spent my whole paycheck on this shop alone. but i stopped myself and just purchased another wellness candle (bloom) and two of her therapeutic aromatherapy sprays (moon mist and enchanted forest) which have amazing smells. i bought the moon mist (a calming pillow mist) to see if it would actually help me get a nights rest. i have two anxiety disorders and suffer with ptsd so falling asleep is difficult for me but the aroma from this mist helped me go to sleep perfectly. as for the enchanted forest, it’s more earthy scented, reminds me of tea tree oil :)

Jun 5, 2021


[jada corbin](https://www.etsy.com/people/fqmm75fv2696crp6)

Purchased item:

[![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic -  Phthalate Free](https://i.etsystatic.com/11861778/r/il/b0b125/5921188054/il_170x135.5921188054_baqm.jpg)\\
\\
Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free\\
\\
$10.00](https://www.etsy.com/listing/789065237/wellness-collection-100-natural-soy?ref=ap-listing)

Purchased item:

[![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic -  Phthalate Free](https://i.etsystatic.com/11861778/r/il/b0b125/5921188054/il_170x135.5921188054_baqm.jpg)\\
\\
Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free\\
\\
$10.00](https://www.etsy.com/listing/789065237/wellness-collection-100-natural-soy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/23c2a8/3137531693/iap_640x640.3137531693_jua12mhd.jpg?version=0)

5 out of 5 stars

- Scent:

CALM


As always, in love with my order! 💜

![](https://i.etsystatic.com/iusa/56fe83/36144668/iusa_75x75.36144668_c8pi.jpg?version=0)

May 18, 2021


[Kelli Diermyer](https://www.etsy.com/people/kdiermyer)

Purchased item:

[![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic -  Phthalate Free](https://i.etsystatic.com/11861778/r/il/b0b125/5921188054/il_170x135.5921188054_baqm.jpg)\\
\\
Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free\\
\\
$10.00](https://www.etsy.com/listing/789065237/wellness-collection-100-natural-soy?ref=ap-listing)

Purchased item:

[![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic -  Phthalate Free](https://i.etsystatic.com/11861778/r/il/b0b125/5921188054/il_170x135.5921188054_baqm.jpg)\\
\\
Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free\\
\\
$10.00](https://www.etsy.com/listing/789065237/wellness-collection-100-natural-soy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/fe4805/2789128282/iap_640x640.2789128282_mirn82ns.jpg?version=0)

5 out of 5 stars

- Scent:

BREATHE


I love these candles. They have such a wonderful scent and are not overpowering. Many candles give me headaches but not these. I highly recommend them. Bonus-the order shipped quickly!

Jan 12, 2021


[katiewiatt](https://www.etsy.com/people/katiewiatt)

Purchased item:

[![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic -  Phthalate Free](https://i.etsystatic.com/11861778/r/il/b0b125/5921188054/il_170x135.5921188054_baqm.jpg)\\
\\
Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free\\
\\
$10.00](https://www.etsy.com/listing/789065237/wellness-collection-100-natural-soy?ref=ap-listing)

Purchased item:

[![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic -  Phthalate Free](https://i.etsystatic.com/11861778/r/il/b0b125/5921188054/il_170x135.5921188054_baqm.jpg)\\
\\
Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free\\
\\
$10.00](https://www.etsy.com/listing/789065237/wellness-collection-100-natural-soy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/ad9164/2555010140/iap_640x640.2555010140_8nj3t1gu.jpg?version=0)

5 out of 5 stars

- Scent:

CALM


My absolute favorite candle! My husband’s allergies are always triggered by candles and these don’t make him sneeze! Not to mention Melinda is such a sweet person so you know your candle was made with love :)

Sep 27, 2020


[Courtney Sterling](https://www.etsy.com/people/lhp2lz3l)

Purchased item:

[![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic -  Phthalate Free](https://i.etsystatic.com/11861778/r/il/b0b125/5921188054/il_170x135.5921188054_baqm.jpg)\\
\\
Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free\\
\\
$10.00](https://www.etsy.com/listing/789065237/wellness-collection-100-natural-soy?ref=ap-listing)

Purchased item:

[![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic -  Phthalate Free](https://i.etsystatic.com/11861778/r/il/b0b125/5921188054/il_170x135.5921188054_baqm.jpg)\\
\\
Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free\\
\\
$10.00](https://www.etsy.com/listing/789065237/wellness-collection-100-natural-soy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/fdc640/2535806729/iap_640x640.2535806729_2e3d1ctj.jpg?version=0)

5 out of 5 stars

- Scent:

GRATITUDE


My morning ritual is complete!! Love the smell of gratitude candle and the gratitude journal looks so special.

Aug 25, 2020


[Alika Ray](https://www.etsy.com/people/AlikaJRay)

Purchased item:

[![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic -  Phthalate Free](https://i.etsystatic.com/11861778/r/il/b0b125/5921188054/il_170x135.5921188054_baqm.jpg)\\
\\
Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free\\
\\
$10.00](https://www.etsy.com/listing/789065237/wellness-collection-100-natural-soy?ref=ap-listing)

Purchased item:

[![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic -  Phthalate Free](https://i.etsystatic.com/11861778/r/il/b0b125/5921188054/il_170x135.5921188054_baqm.jpg)\\
\\
Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free\\
\\
$10.00](https://www.etsy.com/listing/789065237/wellness-collection-100-natural-soy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/e2e047/2351778176/iap_640x640.2351778176_8a001pfv.jpg?version=0)

5 out of 5 stars

- Scent:

MOON DANCE


Melinda was great in helping me pick scents that set the tone I wanted in my new home. Highly recommend ordering from earthtonix I’m not for customer service than for the high quality I found in each product! I’ll be ordering again soon.

![](https://i.etsystatic.com/iusa/2f7e1b/107706851/iusa_75x75.107706851_be9z.jpg?version=0)

Jun 8, 2020


[Palmer Payne](https://www.etsy.com/people/csahyamn)

Purchased item:

[![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic -  Phthalate Free](https://i.etsystatic.com/11861778/r/il/b0b125/5921188054/il_170x135.5921188054_baqm.jpg)\\
\\
Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free\\
\\
$10.00](https://www.etsy.com/listing/789065237/wellness-collection-100-natural-soy?ref=ap-listing)

Purchased item:

[![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic -  Phthalate Free](https://i.etsystatic.com/11861778/r/il/b0b125/5921188054/il_170x135.5921188054_baqm.jpg)\\
\\
Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free\\
\\
$10.00](https://www.etsy.com/listing/789065237/wellness-collection-100-natural-soy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/1d101d/2344303839/iap_640x640.2344303839_fcy126ng.jpg?version=0)

5 out of 5 stars

- Scent:

BREATHE


Loving these wellness candles! They smell awesome and really help when I’m feeling stressed ❤️

May 5, 2020


[brittneysherman72](https://www.etsy.com/people/brittneysherman72)

Purchased item:

[![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic -  Phthalate Free](https://i.etsystatic.com/11861778/r/il/b0b125/5921188054/il_170x135.5921188054_baqm.jpg)\\
\\
Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free\\
\\
$10.00](https://www.etsy.com/listing/789065237/wellness-collection-100-natural-soy?ref=ap-listing)

Purchased item:

[![Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic -  Phthalate Free](https://i.etsystatic.com/11861778/r/il/b0b125/5921188054/il_170x135.5921188054_baqm.jpg)\\
\\
Wellness Collection - 100% Natural Soy Crystal Infused Candles, Wax Melts, Car Diffusers, Spray, 10ML Pure Oil - Non Toxic - Phthalate Free\\
\\
$10.00](https://www.etsy.com/listing/789065237/wellness-collection-100-natural-soy?ref=ap-listing)