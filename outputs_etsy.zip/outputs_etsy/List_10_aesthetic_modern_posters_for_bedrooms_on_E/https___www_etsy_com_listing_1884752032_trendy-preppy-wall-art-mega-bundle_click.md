[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1884752032/trendy-preppy-wall-art-mega-bundle?amp;click_sum=f7203cd7&amp;ls=a&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=List+10+aesthetic+modern+posters+for+bedrooms+on+Etsy&amp;ref=search_grid-381638-1-1&amp;sr_prefetch=1&amp;pf_from=search&amp;pro=1&amp;pop=1&amp;sts=1&amp;dd=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?amp%3Bclick_sum=f7203cd7&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=List+10+aesthetic+modern+posters+for+bedrooms+on+Etsy&%3Bref=search_grid-381638-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bpop=1&%3Bsts=1&%3Bdd=1&explicit=1&ref=catnav_breadcrumb-0)
- [Prints](https://www.etsy.com/c/art-and-collectibles/prints?amp%3Bclick_sum=f7203cd7&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=List+10+aesthetic+modern+posters+for+bedrooms+on+Etsy&%3Bref=search_grid-381638-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bpop=1&%3Bsts=1&%3Bdd=1&explicit=1&ref=catnav_breadcrumb-1)
- [Digital Prints](https://www.etsy.com/c/art-and-collectibles/prints/digital-prints?amp%3Bclick_sum=f7203cd7&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=List+10+aesthetic+modern+posters+for+bedrooms+on+Etsy&%3Bref=search_grid-381638-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bpop=1&%3Bsts=1&%3Bdd=1&explicit=1&ref=catnav_breadcrumb-2)

Bestseller

This item has had a high sales volume over the past 6 months.



Add to Favorites


- ![pink preppy retro vintage trendy wall art leopard prints coastal cowgirl posters coastal art prints dorm bedroom kitchen bar cart bathroom wall decor digital download](https://i.etsystatic.com/47708967/r/il/551603/6818667321/il_794xN.6818667321_f4v5.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![May include: A collage of 18 vintage-style posters with a coastal theme. The posters feature various images of beaches, palm trees, surfboards, and waves. The posters are all in a light blue, white, and pink color scheme. The text on the posters includes the words 'The Coastal', 'Surf Up', 'Meet Me at the Beach', and 'Forever Summer Vacation'. The posters are arranged in a grid pattern on a white background.](https://i.etsystatic.com/47708967/r/il/7b7f4c/6818670389/il_794xN.6818670389_jflz.jpg)
- ![trendy preppy pink wall art coastal cowgirl prints](https://i.etsystatic.com/47708967/r/il/ab3483/6737439604/il_794xN.6737439604_g4b0.jpg)
- ![May include: A wall gallery with framed prints featuring various designs including a pair of red high heels on a checkerboard, a pair of lips with leopard print, a playing card with black hearts, a pink cherry, a pink bow with the word 'Cowgirl', and a pink print with the word 'HELLO'.](https://i.etsystatic.com/47708967/r/il/f5ed5f/6758015462/il_794xN.6758015462_p7ce.jpg)
- ![Leopard Wall Art](https://i.etsystatic.com/47708967/r/il/42957b/6737440200/il_794xN.6737440200_n5zr.jpg)
- ![Vintage Gallery Wall Set](https://i.etsystatic.com/47708967/r/il/4a19ca/6744952072/il_794xN.6744952072_szws.jpg)
- ![May include: A wall gallery of eight framed prints with pink and white themes. The prints feature illustrations of a woman with a frog, a playing card, cherries, a heart-shaped sunglasses, a bottle of champagne, strawberries, and a ticket with the text 'Welcome to Self Love Club'. The prints are framed in gold frames and are arranged in a grid pattern on a pink wall.](https://i.etsystatic.com/47708967/r/il/5e7f46/6429305166/il_794xN.6429305166_3b46.jpg)
- ![May include: Six framed prints with gold frames. The prints are all different designs. The top left print is a white background with black hearts and the number 7. The top middle print is a black and white checkered background with red high heels and a disco ball. The top right print is a white background with a black ace of spades and a martini glass. The bottom left print is a white background with black text that says 'A Love Letter.' The bottom middle print is a white background with black hearts and matchsticks. The bottom right print is a pink background with black text that says 'GUEST CHECK' and 'TELL ME WHEN'.](https://i.etsystatic.com/47708967/r/il/17f150/6429305066/il_794xN.6429305066_b8ow.jpg)
- ![May include: Five pink and gold framed prints with illustrations of cocktails and drinks. The prints include a champagne bottle pouring into a pyramid of champagne glasses, a pink cocktail with a strawberry garnish, a bottle of champagne with a bow, two hands clinking champagne glasses, and a pink cocktail with the text 'Strawberry Daiquiri' and '1902'.](https://i.etsystatic.com/47708967/r/il/edb9db/6477401211/il_794xN.6477401211_r3av.jpg)
- ![May include: Six framed posters with different designs and colors. The posters have a gold frame and are hung on a pink wall. The posters feature illustrations of coffee, pasta, noodles, and a family dinner party. The text on the posters includes 'Coffee Lovers', 'Pasta Lover Club', 'Noodles', 'Family Dinner Party', 'Consumed Daily 7PM-10PM', and 'Jan Wife Que Wanderfal Fandy Diner'.](https://i.etsystatic.com/47708967/r/il/b2eeb2/6429304916/il_794xN.6429304916_e2lh.jpg)

- ![pink preppy retro vintage trendy wall art leopard prints coastal cowgirl posters coastal art prints dorm bedroom kitchen bar cart bathroom wall decor digital download](https://i.etsystatic.com/47708967/c/2970/2970/14/14/il/551603/6818667321/il_75x75.6818667321_f4v5.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/pink_cowgirl_m_fkavk7.jpg)

- ![May include: A collage of 18 vintage-style posters with a coastal theme. The posters feature various images of beaches, palm trees, surfboards, and waves. The posters are all in a light blue, white, and pink color scheme. The text on the posters includes the words 'The Coastal', 'Surf Up', 'Meet Me at the Beach', and 'Forever Summer Vacation'. The posters are arranged in a grid pattern on a white background.](https://i.etsystatic.com/47708967/r/il/7b7f4c/6818670389/il_75x75.6818670389_jflz.jpg)
- ![trendy preppy pink wall art coastal cowgirl prints](https://i.etsystatic.com/47708967/r/il/ab3483/6737439604/il_75x75.6737439604_g4b0.jpg)
- ![May include: A wall gallery with framed prints featuring various designs including a pair of red high heels on a checkerboard, a pair of lips with leopard print, a playing card with black hearts, a pink cherry, a pink bow with the word 'Cowgirl', and a pink print with the word 'HELLO'.](https://i.etsystatic.com/47708967/r/il/f5ed5f/6758015462/il_75x75.6758015462_p7ce.jpg)
- ![Leopard Wall Art](https://i.etsystatic.com/47708967/r/il/42957b/6737440200/il_75x75.6737440200_n5zr.jpg)
- ![Vintage Gallery Wall Set](https://i.etsystatic.com/47708967/r/il/4a19ca/6744952072/il_75x75.6744952072_szws.jpg)
- ![May include: A wall gallery of eight framed prints with pink and white themes. The prints feature illustrations of a woman with a frog, a playing card, cherries, a heart-shaped sunglasses, a bottle of champagne, strawberries, and a ticket with the text 'Welcome to Self Love Club'. The prints are framed in gold frames and are arranged in a grid pattern on a pink wall.](https://i.etsystatic.com/47708967/r/il/5e7f46/6429305166/il_75x75.6429305166_3b46.jpg)
- ![May include: Six framed prints with gold frames. The prints are all different designs. The top left print is a white background with black hearts and the number 7. The top middle print is a black and white checkered background with red high heels and a disco ball. The top right print is a white background with a black ace of spades and a martini glass. The bottom left print is a white background with black text that says 'A Love Letter.' The bottom middle print is a white background with black hearts and matchsticks. The bottom right print is a pink background with black text that says 'GUEST CHECK' and 'TELL ME WHEN'.](https://i.etsystatic.com/47708967/r/il/17f150/6429305066/il_75x75.6429305066_b8ow.jpg)
- ![May include: Five pink and gold framed prints with illustrations of cocktails and drinks. The prints include a champagne bottle pouring into a pyramid of champagne glasses, a pink cocktail with a strawberry garnish, a bottle of champagne with a bow, two hands clinking champagne glasses, and a pink cocktail with the text 'Strawberry Daiquiri' and '1902'.](https://i.etsystatic.com/47708967/r/il/edb9db/6477401211/il_75x75.6477401211_r3av.jpg)
- ![May include: Six framed posters with different designs and colors. The posters have a gold frame and are hung on a pink wall. The posters feature illustrations of coffee, pasta, noodles, and a family dinner party. The text on the posters includes 'Coffee Lovers', 'Pasta Lover Club', 'Noodles', 'Family Dinner Party', 'Consumed Daily 7PM-10PM', and 'Jan Wife Que Wanderfal Fandy Diner'.](https://i.etsystatic.com/47708967/r/il/b2eeb2/6429304916/il_75x75.6429304916_e2lh.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1884752032%2Ftrendy-preppy-wall-art-mega-bundle%23report-overlay-trigger)

In 20+ carts

Price:$8.00


Original Price:
$16.00


Loading


50% off


•

Limited time sale


# Trendy Preppy Wall Art Mega Bundle: Coquette Retro, Kitchen, Bathroom Prints (Digital Download)

[VenusArtPosters](https://www.etsy.com/shop/VenusArtPosters?ref=shop-header-name&listing_id=1884752032&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1884752032/trendy-preppy-wall-art-mega-bundle?amp;click_sum=f7203cd7&amp;ls=a&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=List+10+aesthetic+modern+posters+for+bedrooms+on+Etsy&amp;ref=search_grid-381638-1-1&amp;sr_prefetch=1&amp;pf_from=search&amp;pro=1&amp;pop=1&amp;sts=1&amp;dd=1#reviews)

4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Item details

### Highlights

Made by [VenusArtPosters](https://www.etsy.com/shop/VenusArtPosters)

- Digital download


- Digital file type(s): 1 PDF


Hi, Welcome to VenusArtPosters!

\\* This 60000+ Whole Shop trendy Preppy Pink Wall Art Leopard Prints and Coastal Cowgirl coastal beachy mega Bundle, Coquette Retro Vintage digital wall art set is designed for lovers of unique and aesthetic decor. Featuring pastel pink tones, romantic details, and retro vibes, these digital prints add elegance to your bedroom, dorm Kitchen, Bathroom, Bar Cart or gallery wall!

📌Easy Download!

Each print is high-resolution at 300 DPI, ready for easy download and printing in the size you prefer. Perfect for creating a personalized gallery wall, this set also makes a unique gift for fans of preppy decor and retro design.

📌Highlights:

60000 + piece comprehensive set

Leopard Prints,

Coastal Wall Art, Beach, Surf, Summer

Coastal Cowgirl,

Vintage Mega Bundle,

Preppy, pink, coquette, and retro-themed designs

Movies, Travel, Flowers, TV Frame Art and more...

High-quality digital files for easy printing

Ideal for bedroom, dorm room, or kitchen wall decor

Add a nostalgic touch to your walls and create your own preppy pink gallery! Instantly download, print, and decorate."

Discover our wall art collection of instantly downloadable, digital files on VenusArtPosters. Embrace the artistic vibes with our unique collection of digital prints. Enhance your space or create stunning crafts with these eye-catching designs These high-quality prints are available in a variety of retro, fashion, newspaper, psychedelic, aura, funky, line art, and many other artistic styles

These are prints create a dynamic, eye-catching display that will be sure to impress you and your guests.

Whether you have a modern or traditional home, this design prints will add a touch of personality and character to any room.

✔️Order this design prints today and see the difference it makes in your home or office.

📌FEATURES:

Only digital files included.

\- No physical item will be shipped.

\- Instantly downloadable digital files

\- The image above shows you what the design looks like after printed and framed.

\- Colors may vary slightly depending on the resolution of your screen.

\- Printing results will also vary depending on your printer.

\- Purchases are for PERSONAL USE only. You may not reproduce or re-sell in either print or digital form.

\- All copyrights belong to VenusArtPosters

✔️HOW DOES IT WORK?

When you purchase the list, ETSY will provide the link to instantly download the file after the payment has been successfully processed. Click the link to download and save the file printing. It's that simple!

 --To access your digital file(s), go to Your Account > Purchases and Reviews (https://www.etsy.com/your/purchases) and look for the order.

To the right of the order, click Download Files. This goes to the Downloads page for all the files attached to your order.

--For the most visually stunning final results we recommend to use thick high-quality paper (150lb / 200gsm or (300 )heavier) for printing.

📌IMPORTANT!

Please note that these are digital files only, no physical product will be shipped to you and that due to the nature of digital products, no refunds or exchanges can be provided.

📌SIZES;

\\* DOWNLOAD LINK INCLUDING THE FOLLOWING FILES.

ISO PAPER

"A5, A4, A3, A2, A1, 5x7 Ratio

CM : 10X14 , 20x28, 30x42, 50x70cm.

📌Please click below to see all my designs collection;

[http://www.etsy.com/shop/VenusArtPosters](http://www.etsy.com/shop/VenusArtPosters)

📌I don't accept returns, exchanges or cancellations.

If you have any questions or concerns, please don't hesitate to CONTACT ME.

IT IS MY GOAL ALL MY CUSTOMERS TO BE 100% SATISFIED!🥰🌺

Thank you for visiting VenusArtPosters!

Best Wishes!🍀

VENUS💕


## Delivery

Instant Download

Your files will be available to download once payment is confirmed.
[Here's how.](https://www.etsy.com/help/article/3949)

Instant download items don’t accept returns, exchanges or cancellations. Please contact the seller about any problems with your order.

## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

View additional shop policies

## Reviews for this item (16)

4.4/5

item average

4.7Item quality

5.0Shipping

5.0Customer service

71%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Love it

Great price

Great quality

Easy to use

Fast shipping

Responsive seller

Beautiful


Filter by category


Value (4)


Quality (3)


Seller service (2)


Appearance (2)


Description accuracy (1)


Ease of use (1)


Shipping & Packaging (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Johanna Uus](https://www.etsy.com/people/f9e9x5wh0z50mvm5?ref=l_review)
Oct 27, 2025


Very cool pictures, love it!



[Johanna Uus](https://www.etsy.com/people/f9e9x5wh0z50mvm5?ref=l_review)
Oct 27, 2025


5 out of 5 stars
5

This item

[Haley](https://www.etsy.com/people/fcdvyoxw?ref=l_review)
Oct 20, 2025


loved them all! good price for the amount of posters you get.



[Haley](https://www.etsy.com/people/fcdvyoxw?ref=l_review)
Oct 20, 2025


4 out of 5 stars
4

This item

![](https://i.etsystatic.com/iusa/c40188/85197280/iusa_75x75.85197280_ohz5.jpg?version=0)

[Chrisi](https://www.etsy.com/people/chrisifit?ref=l_review)
Oct 14, 2025


While this definitely provides you with 60000+ images they are not organized very well and its almost impossible to find what you’re looking for.



![](https://i.etsystatic.com/iusa/c40188/85197280/iusa_75x75.85197280_ohz5.jpg?version=0)

[Chrisi](https://www.etsy.com/people/chrisifit?ref=l_review)
Oct 14, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/7ec3fe/72581733/iusa_75x75.72581733_38xa.jpg?version=0)

[Hope Ozment](https://www.etsy.com/people/Hope1894?ref=l_review)
Sep 18, 2025


Loved all the many many images I get to pick through.



![](https://i.etsystatic.com/iusa/7ec3fe/72581733/iusa_75x75.72581733_38xa.jpg?version=0)

[Hope Ozment](https://www.etsy.com/people/Hope1894?ref=l_review)
Sep 18, 2025


![](https://i.etsystatic.com/iusa/0aed66/102971517/iusa_75x75.102971517_oapz.jpg?version=0)

Response from Venus

Thank you, enjoy it!!



View all reviews for this item

### Photos from reviews

![Tracy added a photo of their purchase](https://i.etsystatic.com/iap/aad6b6/7230678351/iap_300x300.7230678351_e7byandn.jpg?version=0)

[![VenusArtPosters](https://i.etsystatic.com/iusa/0aed66/102971517/iusa_75x75.102971517_oapz.jpg?version=0)](https://www.etsy.com/shop/VenusArtPosters?ref=shop_profile&listing_id=1884752032)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[VenusArtPosters](https://www.etsy.com/shop/VenusArtPosters?ref=shop_profile&listing_id=1884752032)

[Owned by Venus](https://www.etsy.com/shop/VenusArtPosters?ref=shop_profile&listing_id=1884752032) \|

United States

4.9
(409)


7.2k sales

2 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=849531084&referring_id=1884752032&referring_type=listing&recipient_id=849531084&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo4NDk1MzEwODQ6MTc2MjgxMDMyODo2MDA2MDJiOTNkYzdlMTJlNmY1NzM3MmY5OTMwZDNiMw%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1884752032%2Ftrendy-preppy-wall-art-mega-bundle%3Famp%253Bclick_sum%3Df7203cd7%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DList%2B10%2Baesthetic%2Bmodern%2Bposters%2Bfor%2Bbedrooms%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-381638-1-1%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bpop%3D1%26amp%253Bsts%3D1%26amp%253Bdd%3D1)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## All reviews from this shop (409)

Show all

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

## More from this shop

[Visit shop](https://www.etsy.com/shop/VenusArtPosters?ref=lp_mys_mfts)

- [![Trendy Preppy Wall Art Prints, Coquette Retro Mega Bundle, Dorm Wall Decor (Digital Download)](https://i.etsystatic.com/47708967/r/il/79fced/7024016164/il_340x270.7024016164_lzl5.jpg)\\
\\
Digital download\\
\\
\\
**Trendy Preppy Wall Art Prints, Coquette Retro Mega Bundle, Dorm Wall Decor (Digital Download)**\\
\\
Sale Price $7.50\\
$7.50\\
\\
$15.00\\
Original Price $15.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4336249896/trendy-preppy-wall-art-prints-coquette?click_key=94983c972daf88fd64540d05c2e220fb%3ALT7d799f94b0c28ffb43bb46fdaf83372beaccbfb3&click_sum=f86b303d&ls=r&ref=related-1&pro=1&sts=1&dd=1&content_source=94983c972daf88fd64540d05c2e220fb%253ALT7d799f94b0c28ffb43bb46fdaf83372beaccbfb3 "Trendy Preppy Wall Art Prints, Coquette Retro Mega Bundle, Dorm Wall Decor (Digital Download)")




Add to Favorites


- [![300+ Trendy Preppy Pink Wall Art, Coquette Retro Prints, Entire Shop Aesthetic Unique Poster for Bedroom Dorm Kitchen Vintage Gallery Wall](https://i.etsystatic.com/47708967/r/il/29507d/6566051982/il_340x270.6566051982_xnjc.jpg)\\
\\
Digital download\\
\\
\\
**300+ Trendy Preppy Pink Wall Art, Coquette Retro Prints, Entire Shop Aesthetic Unique Poster for Bedroom Dorm Kitchen Vintage Gallery Wall**\\
\\
Sale Price $7.50\\
$7.50\\
\\
$15.00\\
Original Price $15.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1858279489/300-trendy-preppy-pink-wall-art-coquette?click_key=94983c972daf88fd64540d05c2e220fb%3ALT67857bad90d6e7266c00d1df89206e5620bdd47e&click_sum=928f4ab9&ls=r&ref=related-2&pro=1&sts=1&dd=1&content_source=94983c972daf88fd64540d05c2e220fb%253ALT67857bad90d6e7266c00d1df89206e5620bdd47e "300+ Trendy Preppy Pink Wall Art, Coquette Retro Prints, Entire Shop Aesthetic Unique Poster for Bedroom Dorm Kitchen Vintage Gallery Wall")




Add to Favorites


- [![Trendy Preppy Wall Art Mega Bundle: Leopard, Coastal Cowgirl, Retro, Vintage (Digital Download)](https://i.etsystatic.com/47708967/r/il/611717/6806023257/il_340x270.6806023257_f4v5.jpg)\\
\\
Digital download\\
\\
\\
**Trendy Preppy Wall Art Mega Bundle: Leopard, Coastal Cowgirl, Retro, Vintage (Digital Download)**\\
\\
Sale Price $7.50\\
$7.50\\
\\
$15.00\\
Original Price $15.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1878213310/trendy-preppy-wall-art-mega-bundle?click_key=94983c972daf88fd64540d05c2e220fb%3ALTdd4baef26e1e77ac87223accd2dcfd1ad114defc&click_sum=71560d8c&ls=r&ref=related-3&pro=1&sts=1&dd=1&content_source=94983c972daf88fd64540d05c2e220fb%253ALTdd4baef26e1e77ac87223accd2dcfd1ad114defc "Trendy Preppy Wall Art Mega Bundle: Leopard, Coastal Cowgirl, Retro, Vintage (Digital Download)")




Add to Favorites


- [![Pink Coastal Cowgirl Print Set: Trendy Dorm Wall Art (Digital Download)](https://i.etsystatic.com/47708967/c/2528/2528/0/0/il/e3eb6a/6683462810/il_340x270.6683462810_i5l7.jpg)\\
\\
Digital download\\
\\
\\
**Pink Coastal Cowgirl Print Set: Trendy Dorm Wall Art (Digital Download)**\\
\\
Sale Price $5.50\\
$5.50\\
\\
$11.00\\
Original Price $11.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1866784376/pink-coastal-cowgirl-print-set-trendy?click_key=8002cc3e5b81ee0ad54a07ccabe686c86e56eb68%3A1866784376&click_sum=db448182&ref=related-4&pro=1&sts=1&dd=1 "Pink Coastal Cowgirl Print Set: Trendy Dorm Wall Art (Digital Download)")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 10, 2025


[451 favorites](https://www.etsy.com/listing/1884752032/trendy-preppy-wall-art-mega-bundle/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?amp%3Bclick_sum=f7203cd7&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=List+10+aesthetic+modern+posters+for+bedrooms+on+Etsy&%3Bref=search_grid-381638-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bpop=1&%3Bsts=1&%3Bdd=1&explicit=1&ref=breadcrumb_listing) [Prints](https://www.etsy.com/c/art-and-collectibles/prints?amp%3Bclick_sum=f7203cd7&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=List+10+aesthetic+modern+posters+for+bedrooms+on+Etsy&%3Bref=search_grid-381638-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bpop=1&%3Bsts=1&%3Bdd=1&explicit=1&ref=breadcrumb_listing) [Digital Prints](https://www.etsy.com/c/art-and-collectibles/prints/digital-prints?amp%3Bclick_sum=f7203cd7&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=List+10+aesthetic+modern+posters+for+bedrooms+on+Etsy&%3Bref=search_grid-381638-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bpop=1&%3Bsts=1&%3Bdd=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Patterns & How To

[Shop Needle Felting Mold](https://www.etsy.com/market/needle_felting_mold) [Womens Wide Leg Overall Pattern - US](https://www.etsy.com/market/womens_wide_leg_overall_pattern)

Furniture

[Buy Mcm Rattan Furniture Online](https://www.etsy.com/market/mcm_rattan_furniture)

Prints

[Ghost Spider Heat Transfer - US](https://www.etsy.com/market/ghost_spider_heat_transfer) [Horseshoe Crab Art Print – Ocean Lover Gift by TurningRocksOfficial](https://www.etsy.com/listing/1859412791/horseshoe-crab-art-print-ocean-lover) [The Heavens Declare His Glory Wall Art](https://www.etsy.com/listing/1906478167/the-heavens-declare-his-glory-wall-art) [Chicago Cubs Png - US](https://www.etsy.com/market/chicago_cubs_png) [Ten Things That Require Zero Talent for Sale](https://www.etsy.com/market/ten_things_that_require_zero_talent) [Skeleton Art by MedPapers](https://www.etsy.com/listing/734648254/skeleton-art-human-anatomy-art-print) [Nordland - US](https://www.etsy.com/market/nordland) [2024 Map of Paint Creek Lake Ohio Highland and Ross County - Prints](https://www.etsy.com/listing/1701287921/2024-map-of-paint-creek-lake-ohio)

Food & Drink

[Coffee Scoop One Tablespoon Green Handcrafted Wood Handle - Food & Drink](https://www.etsy.com/listing/1853689050/coffee-scoop-one-tablespoon-green)

Party Supplies

[Tootsie Pop Turkey - US](https://www.etsy.com/market/tootsie_pop_turkey)

Brooches Pins & Clips

[Adorable dog vintage style brooch](https://www.etsy.com/listing/1861441493/adorable-dog-vintage-style-brooch)

Pet Carriers & Houses

[Skull Hide Geckos for Sale](https://www.etsy.com/market/skull_hide_geckos)

Shopping

[Shop Heart Design Macbook Case](https://www.etsy.com/market/heart_design_macbook_case) [Buy Opium Archive Online](https://www.etsy.com/market/opium_archive)

Art & Collectibles

[Pinckney Island - Art & Collectibles](https://www.etsy.com/listing/769693851/pinckney-island-wildlife-refuge-marsh)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1884752032%2Ftrendy-preppy-wall-art-mega-bundle%3Famp%253Bclick_sum%3Df7203cd7%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DList%2B10%2Baesthetic%2Bmodern%2Bposters%2Bfor%2Bbedrooms%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-381638-1-1%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bpop%3D1%26amp%253Bsts%3D1%26amp%253Bdd%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgxMDMyODozYWU0Mzc0YWVmMzQ3YzdjMDI5YzVlZDRmOTA2OWU0Mg==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1884752032%2Ftrendy-preppy-wall-art-mega-bundle%3Famp%253Bclick_sum%3Df7203cd7%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DList%2B10%2Baesthetic%2Bmodern%2Bposters%2Bfor%2Bbedrooms%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-381638-1-1%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bpop%3D1%26amp%253Bsts%3D1%26amp%253Bdd%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1884752032/trendy-preppy-wall-art-mega-bundle?amp;click_sum=f7203cd7&amp;ls=a&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=List+10+aesthetic+modern+posters+for+bedrooms+on+Etsy&amp;ref=search_grid-381638-1-1&amp;sr_prefetch=1&amp;pf_from=search&amp;pro=1&amp;pop=1&amp;sts=1&amp;dd=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1884752032%2Ftrendy-preppy-wall-art-mega-bundle%3Famp%253Bclick_sum%3Df7203cd7%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DList%2B10%2Baesthetic%2Bmodern%2Bposters%2Bfor%2Bbedrooms%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-381638-1-1%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bpop%3D1%26amp%253Bsts%3D1%26amp%253Bdd%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for VenusArtPosters

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![pink preppy retro vintage trendy wall art leopard prints coastal cowgirl posters coastal art prints dorm bedroom kitchen bar cart bathroom wall decor digital download](https://i.etsystatic.com/47708967/c/2970/2970/14/14/il/551603/6818667321/il_300x300.6818667321_f4v5.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/pink_cowgirl_m_fkavk7.jpg)

- ![May include: A collage of 18 vintage-style posters with a coastal theme. The posters feature various images of beaches, palm trees, surfboards, and waves. The posters are all in a light blue, white, and pink color scheme. The text on the posters includes the words 'The Coastal', 'Surf Up', 'Meet Me at the Beach', and 'Forever Summer Vacation'. The posters are arranged in a grid pattern on a white background.](https://i.etsystatic.com/47708967/r/il/7b7f4c/6818670389/il_300x300.6818670389_jflz.jpg)
- ![trendy preppy pink wall art coastal cowgirl prints](https://i.etsystatic.com/47708967/r/il/ab3483/6737439604/il_300x300.6737439604_g4b0.jpg)
- ![May include: A wall gallery with framed prints featuring various designs including a pair of red high heels on a checkerboard, a pair of lips with leopard print, a playing card with black hearts, a pink cherry, a pink bow with the word 'Cowgirl', and a pink print with the word 'HELLO'.](https://i.etsystatic.com/47708967/r/il/f5ed5f/6758015462/il_300x300.6758015462_p7ce.jpg)
- ![Leopard Wall Art](https://i.etsystatic.com/47708967/r/il/42957b/6737440200/il_300x300.6737440200_n5zr.jpg)
- ![Vintage Gallery Wall Set](https://i.etsystatic.com/47708967/r/il/4a19ca/6744952072/il_300x300.6744952072_szws.jpg)
- ![May include: A wall gallery of eight framed prints with pink and white themes. The prints feature illustrations of a woman with a frog, a playing card, cherries, a heart-shaped sunglasses, a bottle of champagne, strawberries, and a ticket with the text 'Welcome to Self Love Club'. The prints are framed in gold frames and are arranged in a grid pattern on a pink wall.](https://i.etsystatic.com/47708967/r/il/5e7f46/6429305166/il_300x300.6429305166_3b46.jpg)
- ![May include: Six framed prints with gold frames. The prints are all different designs. The top left print is a white background with black hearts and the number 7. The top middle print is a black and white checkered background with red high heels and a disco ball. The top right print is a white background with a black ace of spades and a martini glass. The bottom left print is a white background with black text that says 'A Love Letter.' The bottom middle print is a white background with black hearts and matchsticks. The bottom right print is a pink background with black text that says 'GUEST CHECK' and 'TELL ME WHEN'.](https://i.etsystatic.com/47708967/r/il/17f150/6429305066/il_300x300.6429305066_b8ow.jpg)
- ![May include: Five pink and gold framed prints with illustrations of cocktails and drinks. The prints include a champagne bottle pouring into a pyramid of champagne glasses, a pink cocktail with a strawberry garnish, a bottle of champagne with a bow, two hands clinking champagne glasses, and a pink cocktail with the text 'Strawberry Daiquiri' and '1902'.](https://i.etsystatic.com/47708967/r/il/edb9db/6477401211/il_300x300.6477401211_r3av.jpg)
- ![May include: Six framed posters with different designs and colors. The posters have a gold frame and are hung on a pink wall. The posters feature illustrations of coffee, pasta, noodles, and a family dinner party. The text on the posters includes 'Coffee Lovers', 'Pasta Lover Club', 'Noodles', 'Family Dinner Party', 'Consumed Daily 7PM-10PM', and 'Jan Wife Que Wanderfal Fandy Diner'.](https://i.etsystatic.com/47708967/r/il/b2eeb2/6429304916/il_300x300.6429304916_e2lh.jpg)

Scroll previousScroll next

- ![](https://i.etsystatic.com/iap/aad6b6/7230678351/iap_640x640.7230678351_e7byandn.jpg?version=0)











5 out of 5 stars



Quick and easy and so many options for college phase. #Dorm


















Sep 9, 2025




[Tracy Simmons](https://www.etsy.com/people/islanddem41)













Purchased item:

[![Trendy Preppy Wall Art Mega Bundle: Coquette Retro, Kitchen, Bathroom Prints (Digital Download)](https://i.etsystatic.com/47708967/c/2970/2970/14/14/il/551603/6818667321/il_170x135.6818667321_f4v5.jpg)\\
\\
Trendy Preppy Wall Art Mega Bundle: Coquette Retro, Kitchen, Bathroom Prints (Digital Download)\\
\\
Sale Price $8.00\\
$8.00\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(50% off)](https://www.etsy.com/listing/1884752032/trendy-preppy-wall-art-mega-bundle?ref=ap-listing)





Purchased item:

[![Trendy Preppy Wall Art Mega Bundle: Coquette Retro, Kitchen, Bathroom Prints (Digital Download)](https://i.etsystatic.com/47708967/c/2970/2970/14/14/il/551603/6818667321/il_170x135.6818667321_f4v5.jpg)\\
\\
Trendy Preppy Wall Art Mega Bundle: Coquette Retro, Kitchen, Bathroom Prints (Digital Download)\\
\\
Sale Price $8.00\\
$8.00\\
\\
$16.00\\
Original Price $16.00\\
\\
\\
(50% off)](https://www.etsy.com/listing/1884752032/trendy-preppy-wall-art-mega-bundle?ref=ap-listing)