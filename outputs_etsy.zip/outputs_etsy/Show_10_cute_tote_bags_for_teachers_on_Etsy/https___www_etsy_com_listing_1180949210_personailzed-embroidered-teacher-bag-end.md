[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1180949210/personailzed-embroidered-teacher-bag-end?amp;click_sum=d93daa72&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Bags & Purses](https://www.etsy.com/c/bags-and-purses?amp%3Bclick_sum=d93daa72&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=catnav_breadcrumb-0)
- [Totes](https://www.etsy.com/c/bags-and-purses/totes?amp%3Bclick_sum=d93daa72&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=catnav_breadcrumb-1)


Add to Favorites


- ![May include: A white canvas tote bag with black trim and handles. The bag has an embroidered design of two red apples and two yellow pencils. The text 'Ms Williams' is embroidered below the design. The bag is a teacher tote bag.](https://i.etsystatic.com/8428750/r/il/0d16e7/3730465702/il_794xN.3730465702_kcjs.jpg)
- ![May include: A white canvas tote bag with black trim. The bag has two red apples, two yellow pencils with pink erasers, and the text 'Ms. Williams' embroidered on it.](https://i.etsystatic.com/8428750/r/il/b117d2/3778051491/il_794xN.3778051491_gm8i.jpg)
- ![May include: A beige canvas tote bag with black straps and a black bottom. The bag has a front pocket. The bag is 22 inches long, 16 inches high, and 6 inches wide. The strap drop length is 11 inches. The front pocket is 8 inches high and 8 inches wide.](https://i.etsystatic.com/8428750/r/il/ed562c/3730465892/il_794xN.3730465892_hbdf.jpg)
- ![Personailzed Embroidered Teacher Bag/ End of year teachers gift/ Thank you gift for Teacher/ Teacher tote bag/ Personalized teachers bag image 4](https://i.etsystatic.com/8428750/r/il/5cdd8f/6541513436/il_794xN.6541513436_2p93.jpg)
- ![Personailzed Embroidered Teacher Bag/ End of year teachers gift/ Thank you gift for Teacher/ Teacher tote bag/ Personalized teachers bag image 5](https://i.etsystatic.com/8428750/r/il/69f85d/6589630853/il_794xN.6589630853_6gzp.jpg)
- ![Personailzed Embroidered Teacher Bag/ End of year teachers gift/ Thank you gift for Teacher/ Teacher tote bag/ Personalized teachers bag image 6](https://i.etsystatic.com/8428750/r/il/ac839e/6541513528/il_794xN.6541513528_rwfr.jpg)
- ![Personailzed Embroidered Teacher Bag/ End of year teachers gift/ Thank you gift for Teacher/ Teacher tote bag/ Personalized teachers bag image 7](https://i.etsystatic.com/8428750/r/il/f6503b/3778051933/il_794xN.3778051933_iwuh.jpg)
- ![Personailzed Embroidered Teacher Bag/ End of year teachers gift/ Thank you gift for Teacher/ Teacher tote bag/ Personalized teachers bag image 8](https://i.etsystatic.com/8428750/r/il/5f8db8/3778057321/il_794xN.3778057321_5hi3.jpg)

- ![May include: A white canvas tote bag with black trim and handles. The bag has an embroidered design of two red apples and two yellow pencils. The text 'Ms Williams' is embroidered below the design. The bag is a teacher tote bag.](https://i.etsystatic.com/8428750/r/il/0d16e7/3730465702/il_75x75.3730465702_kcjs.jpg)
- ![May include: A white canvas tote bag with black trim. The bag has two red apples, two yellow pencils with pink erasers, and the text 'Ms. Williams' embroidered on it.](https://i.etsystatic.com/8428750/r/il/b117d2/3778051491/il_75x75.3778051491_gm8i.jpg)
- ![May include: A beige canvas tote bag with black straps and a black bottom. The bag has a front pocket. The bag is 22 inches long, 16 inches high, and 6 inches wide. The strap drop length is 11 inches. The front pocket is 8 inches high and 8 inches wide.](https://i.etsystatic.com/8428750/r/il/ed562c/3730465892/il_75x75.3730465892_hbdf.jpg)
- ![Personailzed Embroidered Teacher Bag/ End of year teachers gift/ Thank you gift for Teacher/ Teacher tote bag/ Personalized teachers bag image 4](https://i.etsystatic.com/8428750/r/il/5cdd8f/6541513436/il_75x75.6541513436_2p93.jpg)
- ![Personailzed Embroidered Teacher Bag/ End of year teachers gift/ Thank you gift for Teacher/ Teacher tote bag/ Personalized teachers bag image 5](https://i.etsystatic.com/8428750/r/il/69f85d/6589630853/il_75x75.6589630853_6gzp.jpg)
- ![Personailzed Embroidered Teacher Bag/ End of year teachers gift/ Thank you gift for Teacher/ Teacher tote bag/ Personalized teachers bag image 6](https://i.etsystatic.com/8428750/r/il/ac839e/6541513528/il_75x75.6541513528_rwfr.jpg)
- ![Personailzed Embroidered Teacher Bag/ End of year teachers gift/ Thank you gift for Teacher/ Teacher tote bag/ Personalized teachers bag image 7](https://i.etsystatic.com/8428750/r/il/f6503b/3778051933/il_75x75.3778051933_iwuh.jpg)
- ![Personailzed Embroidered Teacher Bag/ End of year teachers gift/ Thank you gift for Teacher/ Teacher tote bag/ Personalized teachers bag image 8](https://i.etsystatic.com/8428750/r/il/5f8db8/3778057321/il_75x75.3778057321_5hi3.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1180949210%2Fpersonailzed-embroidered-teacher-bag-end%23report-overlay-trigger)

Price:$29.99


Loading


# Personailzed Embroidered Teacher Bag/ End of year teachers gift/ Thank you gift for Teacher/ Teacher tote bag/ Personalized teachers bag

Designed by [theCraftyVirgo](https://www.etsy.com/shop/theCraftyVirgo)

[5 out of 5 stars](https://www.etsy.com/listing/1180949210/personailzed-embroidered-teacher-bag-end?amp;click_sum=d93daa72&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2#reviews)

Ships from Georgia

Bag Trim Color


Select an option

Orange

Natural (no color)

Black

Khaki

Mint

Navy

Pink

Purple

Red

Royal

Please select an option


Add personalization


- Personalization





please include the following:



1\. Name of Teacher (please check spelling!!)

2\. Thread color for Teachers Name (Please see photos for Thread Color options) Default is Black

3\. Font Choice (Please see photos for Font Name Options) Default is Poppy


















0/256


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Designed by [theCraftyVirgo](https://www.etsy.com/shop/theCraftyVirgo)

- Ships from Georgia! Shorter shipping distances are

kinder to the planet

Ordering items closer to you is more likely to reduce your purchase's carbon footprint.


The school year is almost over and what a super cute way to say “Thank You” to your child’s teacher than with this beautiful Personalized Embroidered Canvas Tote. This tote has been designed with a school theme (2 apples and 2 pencils) and a teacher’s name. The bright polyester thread truly brings this design to life.

My mom is an educator, and she brings home papers to grade and book to create lesson plans with all the time. This bag is perfect for all the book, papers, and work a teacher takes home from school daily. This bag features a spacious inside with an outer pocked. It is made out of 14 oz cotton canvas and measures 22” x 16” x 6” and is offered in a natural canvas color with 8 beautiful trim options. Please note: some of the trim options colors above the outer pocket have been changed by the manufacture to a natural canvass trim, this is beyond my control as I don’t make these bags.

How to order:

From the drop-down menu please select the color trimmed bag

In the Personalization area please include the following:

1\. Name of Teacher (please check spelling, as I copy and paste what is sent to me)

2\. Thread color (Please see photos for Thread Color options) Black is the default Thread

3\. Font Name (Please see photos for Font Name Options) Poppy is the default Font

Please check the spelling of the name. I am not responsible for miss spelled names.

\*COLOR DISCREPANCIES\*

Please understand that all computer and mobile devices portray colors differently. Some make items appear darker and some lighter. If you are unsure of which color option will best fit your needs, contact me and I will do my best to meet your expectations. Once you place your order, I am not responsible for shading discrepancies.

This listing if for one personalized bag only, all other items in the photo are not included in the listing and are for photo purposes only.

Please message me with any questions that you may have!

Thank you for supporting my small business!


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-Dec 4**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges not accepted




But please contact me if you have problems with your order


- Ships from: **Decatur, GA**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## Reviews for this item (6)

5.0/5

item average

5.0Item quality

5.0Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Great product

Love it

Perfect size

Perfect addition

Responsive seller

Beautiful

Exactly what I wanted


Filter by category


Sizing & Fit (3)


Quality (2)


Seller service (1)


Description accuracy (1)


Appearance (1)


Value (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Keri Sargent](https://www.etsy.com/people/kerimallory?ref=l_review)
May 20, 2025


My sister just became a teacher...it's perfect! Thank you.



[Keri Sargent](https://www.etsy.com/people/kerimallory?ref=l_review)
May 20, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/725d4b/112130714/iusa_75x75.112130714_2a2c.jpg?version=0)

[Emma Craig](https://www.etsy.com/people/6gbcbvnq?ref=l_review)
Dec 18, 2024


Seller answered inquiries quickly and product came out great!



![](https://i.etsystatic.com/iusa/725d4b/112130714/iusa_75x75.112130714_2a2c.jpg?version=0)

[Emma Craig](https://www.etsy.com/people/6gbcbvnq?ref=l_review)
Dec 18, 2024


5 out of 5 stars
5

This item

[Maggie Little](https://www.etsy.com/people/pxh4qiodmu9j1gzw?ref=l_review)
Dec 18, 2024


This is exactly what I was hoping for! The embroidery is beautiful and the bag has lots of room for all my teacher materials. Love!



[Maggie Little](https://www.etsy.com/people/pxh4qiodmu9j1gzw?ref=l_review)
Dec 18, 2024


5 out of 5 stars
5

This item

[lotross1](https://www.etsy.com/people/lotross1?ref=l_review)
Nov 11, 2024


Great Bag! It was even bigger than I thought.



[lotross1](https://www.etsy.com/people/lotross1?ref=l_review)
Nov 11, 2024


View all reviews for this item

[![theCraftyVirgo](https://i.etsystatic.com/iusa/86a1d8/23314938/iusa_75x75.23314938_h5cj.jpg?version=0)](https://www.etsy.com/shop/theCraftyVirgo?ref=shop_profile&listing_id=1180949210)

[theCraftyVirgo](https://www.etsy.com/shop/theCraftyVirgo?ref=shop_profile&listing_id=1180949210)

[Owned by Travis Williams](https://www.etsy.com/shop/theCraftyVirgo?ref=shop_profile&listing_id=1180949210) \|

Atlanta, Georgia

5.0
(2k)


10.4k sales

12 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=34740461&referring_id=1180949210&referring_type=listing&recipient_id=34740461&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDozNDc0MDQ2MToxNzYyODIwNzY2OjkxOWQyMTNkMWU2MGZlYzY5NGE0NGI0MzRlNjYwODhj&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1180949210%2Fpersonailzed-embroidered-teacher-bag-end%3Famp%253Bclick_sum%3Dd93daa72%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2)

This seller usually responds **within a few hours.**

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

Loading recommendations

Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Aug 7, 2025


[83 favorites](https://www.etsy.com/listing/1180949210/personailzed-embroidered-teacher-bag-end/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?amp%3Bclick_sum=d93daa72&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=breadcrumb_listing) [Totes](https://www.etsy.com/c/bags-and-purses/totes?amp%3Bclick_sum=d93daa72&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Earrings

[Sloth Earrings](https://www.etsy.com/listing/1756395338/sloth-earrings)

Painting

[Magical Spell Illustration Decor Witchcraft Mystic Bookshop Witchcore Painting](https://www.etsy.com/listing/4321220847/wizard-spellbook-print-fantasy-witch)

Storage & Organization

[Towel Rack With Hooks for Sale](https://www.etsy.com/market/towel_rack_with_hooks)

Necklaces

[Dichroic Glass Pendant - Steampunk Jewelry - Fused Glass Pendant - Dichroic Jewelry - Fused Glass Jewelry - Necklaces](https://www.etsy.com/listing/247833616/dichroic-glass-pendant-steampunk-jewelry)

Brooches Pins & Clips

[Shop Shamrock Brooch](https://www.etsy.com/market/shamrock_brooch)

Watches

[Aaa Watch for Sale](https://www.etsy.com/market/aaa_watch) [Apple Watch Band (38mm / 40mm / 41mm / 42mm / 49mm)](https://www.etsy.com/listing/1112993728/cute-dinosaurs-print-apple-watch-band)

Knives & Cutting Tools

[Custom Handmade D2 Steel Fixed Blade Knife with Kydex sheath (G10 Handle) - Knives & Cutting Tools](https://www.etsy.com/listing/570024033/custom-handmade-d2-steel-fixed-blade)

Kitchen & Dining

[1960s Sunbeam Percolator - Kitchen & Dining](https://www.etsy.com/listing/842151103/1960s-sunbeam-percolator)

Keychains & Lanyards

[RMTstudios](https://www.etsy.com/shop/RMTstudios)

Gender Neutral Adult Clothing

[Alaska Cruise Shirts](https://www.etsy.com/listing/1448805635/alaska-cruise-shirts-matching-group)

Bracelets

[14K Yellow Gold Handmade Scarab Bracelet With Oval Shaped Genuine Gemstones by Karatcaratjewelry](https://www.etsy.com/listing/925664034/14k-yellow-gold-handmade-scarab-bracelet) [Buy Nazo Jewelry Online](https://www.etsy.com/market/nazo_jewelry)

Handbags

[Cigar Box Handles for Sale](https://www.etsy.com/market/cigar_box_handles)

Outdoor & Garden

[Set of 10 Indoor Woodstove Fireplace Fire Starters](https://www.etsy.com/listing/1364453873/victorian-christmas-firestarters-set-of)

Rings

[Diamond Compass Ring - US](https://www.etsy.com/market/diamond_compass_ring)

Hair Accessories

[Spiderweb bows hair clips](https://www.etsy.com/listing/82700245/spiderweb-bows-hair-clips)

Girls Clothing

[Buy Girls Beach Cover Up Online](https://www.etsy.com/market/girls_beach_cover_up)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1180949210%2Fpersonailzed-embroidered-teacher-bag-end%3Famp%253Bclick_sum%3Dd93daa72%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgyMDc2Njo0ZTc0YTY2Yjg2ZTY0NWJhMThkNDI2N2Y0Njc0ODY3Mw==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1180949210%2Fpersonailzed-embroidered-teacher-bag-end%3Famp%253Bclick_sum%3Dd93daa72%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1180949210/personailzed-embroidered-teacher-bag-end?amp;click_sum=d93daa72&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1180949210%2Fpersonailzed-embroidered-teacher-bag-end%3Famp%253Bclick_sum%3Dd93daa72%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for theCraftyVirgo

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 24 hours of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: A white canvas tote bag with black trim and handles. The bag has an embroidered design of two red apples and two yellow pencils. The text 'Ms Williams' is embroidered below the design. The bag is a teacher tote bag.](https://i.etsystatic.com/8428750/r/il/0d16e7/3730465702/il_300x300.3730465702_kcjs.jpg)
- ![May include: A white canvas tote bag with black trim. The bag has two red apples, two yellow pencils with pink erasers, and the text 'Ms. Williams' embroidered on it.](https://i.etsystatic.com/8428750/r/il/b117d2/3778051491/il_300x300.3778051491_gm8i.jpg)
- ![May include: A beige canvas tote bag with black straps and a black bottom. The bag has a front pocket. The bag is 22 inches long, 16 inches high, and 6 inches wide. The strap drop length is 11 inches. The front pocket is 8 inches high and 8 inches wide.](https://i.etsystatic.com/8428750/r/il/ed562c/3730465892/il_300x300.3730465892_hbdf.jpg)
- ![Personailzed Embroidered Teacher Bag/ End of year teachers gift/ Thank you gift for Teacher/ Teacher tote bag/ Personalized teachers bag image 4](https://i.etsystatic.com/8428750/r/il/5cdd8f/6541513436/il_300x300.6541513436_2p93.jpg)
- ![Personailzed Embroidered Teacher Bag/ End of year teachers gift/ Thank you gift for Teacher/ Teacher tote bag/ Personalized teachers bag image 5](https://i.etsystatic.com/8428750/r/il/69f85d/6589630853/il_300x300.6589630853_6gzp.jpg)
- ![Personailzed Embroidered Teacher Bag/ End of year teachers gift/ Thank you gift for Teacher/ Teacher tote bag/ Personalized teachers bag image 6](https://i.etsystatic.com/8428750/r/il/ac839e/6541513528/il_300x300.6541513528_rwfr.jpg)
- ![Personailzed Embroidered Teacher Bag/ End of year teachers gift/ Thank you gift for Teacher/ Teacher tote bag/ Personalized teachers bag image 7](https://i.etsystatic.com/8428750/r/il/f6503b/3778051933/il_300x300.3778051933_iwuh.jpg)
- ![Personailzed Embroidered Teacher Bag/ End of year teachers gift/ Thank you gift for Teacher/ Teacher tote bag/ Personalized teachers bag image 8](https://i.etsystatic.com/8428750/r/il/5f8db8/3778057321/il_300x300.3778057321_5hi3.jpg)