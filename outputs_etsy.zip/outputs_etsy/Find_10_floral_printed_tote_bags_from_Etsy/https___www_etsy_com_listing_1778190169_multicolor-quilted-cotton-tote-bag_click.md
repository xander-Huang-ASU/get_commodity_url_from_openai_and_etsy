[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1778190169/multicolor-quilted-cotton-tote-bag?amp;click_sum=b00749c2&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3&amp;pro=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Bags & Purses](https://www.etsy.com/c/bags-and-purses?amp%3Bclick_sum=b00749c2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bpro=1&explicit=1&ref=catnav_breadcrumb-0)
- [Handbags](https://www.etsy.com/c/bags-and-purses/handbags?amp%3Bclick_sum=b00749c2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bpro=1&explicit=1&ref=catnav_breadcrumb-1)
- [Shoulder Bags](https://www.etsy.com/c/bags-and-purses/handbags/shoulder-bags?amp%3Bclick_sum=b00749c2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bpro=1&explicit=1&ref=catnav_breadcrumb-2)

Bestseller

This item has had a high sales volume over the past 6 months.



Add to Favorites


- ![May include: A large tote bag with a pink and orange floral print. The bag has a white and pink striped handle. The bag is sitting on a green grassy surface next to a silver laptop computer.](https://i.etsystatic.com/45443924/r/il/a45dd0/6255021378/il_794xN.6255021378_lf29.jpg)
- ![Multicolor Quilted Cotton Tote Bag: Handblock Print, Travel Friendly Parrot green](https://i.etsystatic.com/45443924/r/il/e1e0e7/6821807371/il_794xN.6821807371_sw26.jpg)
- ![May include: A pink and green floral tote bag with white and pink striped straps. The bag is made of quilted fabric and has a floral print. The bag is sitting on a green grassy surface.](https://i.etsystatic.com/45443924/r/il/7c7bfb/6301767589/il_794xN.6301767589_cxkv.jpg)
- ![May include: A yellow and white floral tote bag with a quilted design. The bag has two long straps and is made of cotton fabric.](https://i.etsystatic.com/45443924/r/il/52698c/6303071311/il_794xN.6303071311_sjz0.jpg)
- ![May include: A red and white floral tote bag with a laptop computer on the grass. The tote bag has a white floral pattern on a red background. The laptop is silver and has a black screen.](https://i.etsystatic.com/45443924/r/il/ab1156/6303072475/il_794xN.6303072475_4ifx.jpg)
- ![May include: A blue and white tote bag with a floral pattern. The bag has two handles and is sitting on a green grassy surface. A silver laptop computer is in front of the bag.](https://i.etsystatic.com/45443924/r/il/db5244/6255023834/il_794xN.6255023834_jri4.jpg)
- ![May include: A teal blue tote bag with a white floral pattern. The bag has a white stitched trim and two white straps.](https://i.etsystatic.com/45443924/r/il/738c65/6303075547/il_794xN.6303075547_oqyc.jpg)
- ![May include: A pink and white striped tote bag with a floral print pocket. The pocket has a black phone inside.](https://i.etsystatic.com/45443924/r/il/3a19d3/6244784157/il_794xN.6244784157_botj.jpg)
- ![May include: A pink and orange tote bag with a white floral pattern. The bag has a white and orange striped handle and is holding a silver laptop computer.](https://i.etsystatic.com/45443924/r/il/13fd5c/6303076555/il_794xN.6303076555_mpk6.jpg)
- ![May include: A blue and white tote bag with a floral pattern. The bag has a white trim and is made of a thick fabric. The bag is large enough to hold a laptop computer.](https://i.etsystatic.com/45443924/r/il/2c1e96/6255028738/il_794xN.6255028738_c3zf.jpg)

- ![May include: A large tote bag with a pink and orange floral print. The bag has a white and pink striped handle. The bag is sitting on a green grassy surface next to a silver laptop computer.](https://i.etsystatic.com/45443924/r/il/a45dd0/6255021378/il_75x75.6255021378_lf29.jpg)
- ![Multicolor Quilted Cotton Tote Bag: Handblock Print, Travel Friendly Parrot green](https://i.etsystatic.com/45443924/r/il/e1e0e7/6821807371/il_75x75.6821807371_sw26.jpg)
- ![May include: A pink and green floral tote bag with white and pink striped straps. The bag is made of quilted fabric and has a floral print. The bag is sitting on a green grassy surface.](https://i.etsystatic.com/45443924/r/il/7c7bfb/6301767589/il_75x75.6301767589_cxkv.jpg)
- ![May include: A yellow and white floral tote bag with a quilted design. The bag has two long straps and is made of cotton fabric.](https://i.etsystatic.com/45443924/r/il/52698c/6303071311/il_75x75.6303071311_sjz0.jpg)
- ![May include: A red and white floral tote bag with a laptop computer on the grass. The tote bag has a white floral pattern on a red background. The laptop is silver and has a black screen.](https://i.etsystatic.com/45443924/r/il/ab1156/6303072475/il_75x75.6303072475_4ifx.jpg)
- ![May include: A blue and white tote bag with a floral pattern. The bag has two handles and is sitting on a green grassy surface. A silver laptop computer is in front of the bag.](https://i.etsystatic.com/45443924/r/il/db5244/6255023834/il_75x75.6255023834_jri4.jpg)
- ![May include: A teal blue tote bag with a white floral pattern. The bag has a white stitched trim and two white straps.](https://i.etsystatic.com/45443924/r/il/738c65/6303075547/il_75x75.6303075547_oqyc.jpg)
- ![May include: A pink and white striped tote bag with a floral print pocket. The pocket has a black phone inside.](https://i.etsystatic.com/45443924/r/il/3a19d3/6244784157/il_75x75.6244784157_botj.jpg)
- ![May include: A pink and orange tote bag with a white floral pattern. The bag has a white and orange striped handle and is holding a silver laptop computer.](https://i.etsystatic.com/45443924/r/il/13fd5c/6303076555/il_75x75.6303076555_mpk6.jpg)
- ![May include: A blue and white tote bag with a floral pattern. The bag has a white trim and is made of a thick fabric. The bag is large enough to hold a laptop computer.](https://i.etsystatic.com/45443924/r/il/2c1e96/6255028738/il_75x75.6255028738_c3zf.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1778190169%2Fmulticolor-quilted-cotton-tote-bag%23report-overlay-trigger)

In 20+ carts

NowPrice:$20.00+


Original Price:
$40.00+


Loading


50% off


•

Sale ends in 4 days


# Multicolor Quilted Cotton Tote Bag: Handblock Print, Travel Friendly

[HeartofhomeIN](https://www.etsy.com/shop/HeartofhomeIN?ref=shop-header-name&listing_id=1778190169&from_page=listing)

[4.5 out of 5 stars](https://www.etsy.com/listing/1778190169/multicolor-quilted-cotton-tote-bag?amp;click_sum=b00749c2&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3&amp;pro=1#reviews)

Returns & exchanges accepted

Sizes


Select an option

14X14 Inch ($20.00)

16X16 Inch ($22.50)

18X18 Inch ($27.50)

20X20 Inch ($30.00)

Please select an option


Colour


Select an option

Parrot green

Rose Pink

Orange

red

Royal blue

Please select an option


Add personalization


- Personalization





Please leave mobile contact number in the box for hassle free delivery and tracking.kindly do not share any personalization here this is just for contact number.


















0/15


Quantity



1234567891011121314151617181920212223242526272829303132333435363738394041424344454647484950515253

You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Made by [HeartofhomeIN](https://www.etsy.com/shop/HeartofhomeIN)

- Materials: Primary fabric type: Cotton


This exquisite quilted tote bag is crafted from 100% pure cotton fabric, making it not only stylish but also eco-friendly. Available in a beautiful Multicolor , this bag is printed by skillful artisans using traditional handblock techniques, ensuring each piece is unique. The use of cotton fabric helps reduce environmental impact, offering a sustainable alternative to plastic bags.

The bag is thoughtfully designed with cross quilting, adding durability and a soft, luxurious feel. The interior is lined with pure cotton fabric, ensuring a premium quality finish inside and out. This tote is perfect for carrying your essentials, whether you're heading to the beach, running quick errands, or transporting your favorite artist supplies.

The versatile design includes two straps, allowing you to wear it comfortably over your shoulder or carry it as a handbag. The quilting consists of three layers: cotton fabric, surgical cotton, and a cotton lining, providing strength and a plush texture.

Features:

Material: 100% Cotton Fabric

Available Colors: Multicolor with Handblock Print

Available Sizes: Custom sizes available to meet your needs

Quilting: 3 layers - Cotton fabric + surgical cotton + cotton lining

Interior: Pure cotton fabric with a square pocket inside

Straps: Dual-purpose straps for shoulder or hand carry

Care Instructions: Washable on a cold, delicate cycle separately

Eco-Friendly: A sustainable alternative to plastic bags

Please note, the reverse side of the bags in this batch features stylish stripes or prints, adding to their unique charm. We strive to capture the true colors in our photography, though slight variations may occur depending on your screen resolution.

This tote bag comes folded in a flat pack for easy shipping. It makes a thoughtful, sustainable gift for friends and family or a perfect personal accessory for your day-to-day adventures.

For bulk orders, custom sizes, or other requests, feel free to message us. We offer shipping upgrades to meet your needs.


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-Dec 5**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 30 days


- Ships from: **India**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

## Meet your seller

![THE HEART OF HOME](https://i.etsystatic.com/45443924/r/isla/794edb/72017580/isla_75x75.72017580_9oqr289a.jpg)

THE HEART OF HOME

Owner of [HeartofhomeIN](https://www.etsy.com/shop/HeartofhomeIN?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo4MTQwNDY0MjQ6MTc2MjgyMDY5ODo4NzY3Nzc2YjYyMmYzNGYxYjZiMjliZjAzZGJkYTA3OQ%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1778190169%2Fmulticolor-quilted-cotton-tote-bag%3Famp%253Bclick_sum%3Db00749c2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bpro%3D1)

[Message THE HEART OF HOME](https://www.etsy.com/messages/new?with_id=814046424&referring_id=1778190169&referring_type=listing&recipient_id=814046424&from_action=contact-seller)

This seller usually responds **within a few hours.**

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (36)

4.9/5

item average

4.9Item quality

4.7Shipping

4.6Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Beautiful

Very well made

Love it

Great quality

Would recommend

Well packaged

Perfect size


Filter by category


Quality (19)


Appearance (13)


Shipping & Packaging (10)


Description accuracy (7)


Sizing & Fit (5)


Seller service (4)


Comfort (2)


Value (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Carlie Morgan](https://www.etsy.com/people/hl6a2tab0bpyjvfp?ref=l_review)
Sep 19, 2025


The bag is BEAUTIFUL & I have received so many compliments! The size I got is perfect for my daily school bag as a teacher. It fits everything I need and supports the weight. I will be buying more in different sizes!



[Carlie Morgan](https://www.etsy.com/people/hl6a2tab0bpyjvfp?ref=l_review)
Sep 19, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/1555a0/72146315/iusa_75x75.72146315_pleh.jpg?version=0)

[Madison Willis](https://www.etsy.com/people/pxbrmxa3?ref=l_review)
Sep 1, 2025


Absolutely LOVE this bag! Everything is just as it’s pictured. It’s so beautifully made and the quality is amazing. I recommend highly!



![Madison Willis added a photo of their purchase](https://i.etsystatic.com/iap/650c01/7208751541/iap_300x300.7208751541_n71j0is8.jpg?version=0)

![](https://i.etsystatic.com/iusa/1555a0/72146315/iusa_75x75.72146315_pleh.jpg?version=0)

[Madison Willis](https://www.etsy.com/people/pxbrmxa3?ref=l_review)
Sep 1, 2025


5 out of 5 stars
5

This item

[Bethan](https://www.etsy.com/people/xlgboaz98xo452wj?ref=l_review)
Aug 30, 2025


Beautiful item, it’s made a lovely birthday present. Thank you!



[Bethan](https://www.etsy.com/people/xlgboaz98xo452wj?ref=l_review)
Aug 30, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/be53bc/49587620/iusa_75x75.49587620_euzn.jpg?version=0)

[Linda Ferraro](https://www.etsy.com/people/lindaeferraro?ref=l_review)
Aug 26, 2025


Beautiful and beautifully made! Thank you!



![](https://i.etsystatic.com/iusa/be53bc/49587620/iusa_75x75.49587620_euzn.jpg?version=0)

[Linda Ferraro](https://www.etsy.com/people/lindaeferraro?ref=l_review)
Aug 26, 2025


View all reviews for this item

### Photos from reviews

![Madison added a photo of their purchase](https://i.etsystatic.com/iap/650c01/7208751541/iap_300x300.7208751541_n71j0is8.jpg?version=0)

![Karin added a photo of their purchase](https://i.etsystatic.com/iap/c29ffd/6781973044/iap_300x300.6781973044_b6mst4d3.jpg?version=0)

[![HeartofhomeIN](https://i.etsystatic.com/iusa/f85774/105472313/iusa_75x75.105472313_bh1l.jpg?version=0)](https://www.etsy.com/shop/HeartofhomeIN?ref=shop_profile&listing_id=1778190169)

[HeartofhomeIN](https://www.etsy.com/shop/HeartofhomeIN?ref=shop_profile&listing_id=1778190169)

[Owned by THE HEART OF HOME](https://www.etsy.com/shop/HeartofhomeIN?ref=shop_profile&listing_id=1778190169) \|

Jaipur, India

4.6
(207)


1.3k sales

2 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=814046424&referring_id=1778190169&referring_type=listing&recipient_id=814046424&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo4MTQwNDY0MjQ6MTc2MjgyMDY5ODo4NzY3Nzc2YjYyMmYzNGYxYjZiMjliZjAzZGJkYTA3OQ%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1778190169%2Fmulticolor-quilted-cotton-tote-bag%3Famp%253Bclick_sum%3Db00749c2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bpro%3D1)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

## More from this shop

[Visit shop](https://www.etsy.com/shop/HeartofhomeIN?ref=lp_mys_mfts)

- [![Large Orange pink Cotton Quilted Duffle Bags Block print Gifts Handmade Colorful Travel night Travel Gym Yoga Luggage pocket 18x9x9 inches](https://i.etsystatic.com/45443924/r/il/cb2032/6614615104/il_340x270.6614615104_l6t7.jpg)\\
\\
**Large Orange pink Cotton Quilted Duffle Bags Block print Gifts Handmade Colorful Travel night Travel Gym Yoga Luggage pocket 18x9x9 inches**\\
\\
Sale Price $25.00\\
$25.00\\
\\
$50.00\\
Original Price $50.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1854071006/large-orange-pink-cotton-quilted-duffle?click_key=f1f76f6deb066599800947c6afa24259%3ALTfb64de2cdfd0e003402959c8d6712b7f1a07024a&click_sum=74612e9a&ls=r&ref=related-1&pro=1&content_source=f1f76f6deb066599800947c6afa24259%253ALTfb64de2cdfd0e003402959c8d6712b7f1a07024a "Large Orange pink Cotton Quilted Duffle Bags Block print Gifts Handmade Colorful Travel night Travel Gym Yoga Luggage pocket 18x9x9 inches")




Add to Favorites


- [![Handmade Limerick Green Floral Quilted Duffle Bag: Cotton Travel Gym Bag](https://i.etsystatic.com/45443924/r/il/1230bc/6614601196/il_340x270.6614601196_euwe.jpg)\\
\\
**Handmade Limerick Green Floral Quilted Duffle Bag: Cotton Travel Gym Bag**\\
\\
Sale Price $20.00\\
$20.00\\
\\
$40.00\\
Original Price $40.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1868264957/handmade-limerick-green-floral-quilted?click_key=f1f76f6deb066599800947c6afa24259%3ALTb0000cf6f69b52bc5a64077b3adb0b75b50db8c9&click_sum=be85d100&ls=r&ref=related-2&pro=1&content_source=f1f76f6deb066599800947c6afa24259%253ALTb0000cf6f69b52bc5a64077b3adb0b75b50db8c9 "Handmade Limerick Green Floral Quilted Duffle Bag: Cotton Travel Gym Bag")




Add to Favorites


- [![Large royal blue Cotton Quilted Duffle Bags Block print Gifts Handmade Colorful Travel night Travel Gym Yoga Luggage pocket 18x9x9 inches](https://i.etsystatic.com/45443924/r/il/9922b2/6662594373/il_340x270.6662594373_98jx.jpg)\\
\\
**Large royal blue Cotton Quilted Duffle Bags Block print Gifts Handmade Colorful Travel night Travel Gym Yoga Luggage pocket 18x9x9 inches**\\
\\
Sale Price $25.00\\
$25.00\\
\\
$50.00\\
Original Price $50.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1868246323/large-royal-blue-cotton-quilted-duffle?click_key=f1f76f6deb066599800947c6afa24259%3ALTdc025b0d20bbd868dd0ccf861312641fed38afe1&click_sum=8003c1f0&ls=r&ref=related-3&pro=1&content_source=f1f76f6deb066599800947c6afa24259%253ALTdc025b0d20bbd868dd0ccf861312641fed38afe1 "Large royal blue Cotton Quilted Duffle Bags Block print Gifts Handmade Colorful Travel night Travel Gym Yoga Luggage pocket 18x9x9 inches")




Add to Favorites


- [![Hand Block Printed Floral Cotton Napkins: Stone Blue Elegant Dining Decor](https://i.etsystatic.com/45443924/r/il/6f662c/5306570501/il_340x270.5306570501_b6tn.jpg)\\
\\
**Hand Block Printed Floral Cotton Napkins: Stone Blue Elegant Dining Decor**\\
\\
Sale Price $27.00\\
$27.00\\
\\
$54.00\\
Original Price $54.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1526703584/hand-block-printed-floral-cotton-napkins?click_key=83b0094f481bac895c5620198f0ede04c8dd65d7%3A1526703584&click_sum=d7b47061&ref=related-4&pro=1 "Hand Block Printed Floral Cotton Napkins: Stone Blue Elegant Dining Decor")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 10, 2025


[965 favorites](https://www.etsy.com/listing/1778190169/multicolor-quilted-cotton-tote-bag/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?amp%3Bclick_sum=b00749c2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bpro=1&explicit=1&ref=breadcrumb_listing) [Handbags](https://www.etsy.com/c/bags-and-purses/handbags?amp%3Bclick_sum=b00749c2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bpro=1&explicit=1&ref=breadcrumb_listing) [Shoulder Bags](https://www.etsy.com/c/bags-and-purses/handbags/shoulder-bags?amp%3Bclick_sum=b00749c2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bpro=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Bracelets

[Buy Be Yourself Jewelry Online](https://www.etsy.com/market/be_yourself_jewelry)

Party Supplies

[Link Pinata - US](https://www.etsy.com/market/link_pinata)

Bathroom

[Custom Beach Towel - Bathroom Decor, Linens & Hardware](https://www.etsy.com/listing/1404575812/bachelorette-party-favors-custom-beach) [Shop Terrazzo Vanity Top](https://www.etsy.com/market/terrazzo_vanity_top)

Findings

[Oval Flat Tassel Cap - US](https://www.etsy.com/market/oval_flat_tassel_cap)

Kitchen & Dining

[Antique Baronet - US](https://www.etsy.com/market/antique_baronet) [Capybara Coffee Mug for Sale](https://www.etsy.com/market/capybara_coffee_mug)

Prints

[MinicPortrait](https://www.etsy.com/shop/MinicPortrait)

Shopping

[Buy Acu Plate Online](https://www.etsy.com/market/acu_plate)

Womens Shoes

[Broken-in Dirty Dr. Martens Chunky Sole Sueded Leather Booties US Ladies size 6 by BlackbirdSedona](https://www.etsy.com/listing/1469964175/broken-in-dirty-dr-martens-chunky-sole)

Fiber Arts

[Needlepointers for Sale](https://www.etsy.com/market/needlepointers)

Fabric & Notions

[Grain Sack Fabric by the Yard - Ticking Fabric - French Country - Cottage Farmhouse Style - Blue Stripes - 54" Wide- - 1 to 12 YD. Cuts](https://www.etsy.com/listing/767548409/grain-sack-fabric-by-the-yard-ticking)

Drawing & Illustration

[Original Vintage 1937 John James Audubon Birds of America Bookplate Print Bird Print 345 Baldpate 346 Pacific Loon - Drawing & Illustration](https://www.etsy.com/listing/161313985/original-vintage-1937-john-james-audubon)

Handbags

[Sage Green Small Handbag for Sale](https://www.etsy.com/market/sage_green_small_handbag)

Gender Neutral Adult Clothing

[Gay Bussy - US](https://www.etsy.com/market/gay_bussy) [Not All Classrooms Have Four Walls by SweetOneStudio](https://www.etsy.com/listing/1557167534/not-all-classrooms-have-four-walls)

Patterns & How To

[Buy Scottish Flag Cross Stitch Pattern Online](https://www.etsy.com/market/scottish_flag_cross_stitch_pattern)

Toys

[Lunchbox notes for school kids](https://www.etsy.com/listing/1766021464/lunchbox-notes-for-school-kids)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1778190169%2Fmulticolor-quilted-cotton-tote-bag%3Famp%253Bclick_sum%3Db00749c2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bpro%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgyMDY5ODplNjIyZTQ2ZjhiMWY5OTY1NjZiMmM5YTE5ZDc2Y2M2Yw==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1778190169%2Fmulticolor-quilted-cotton-tote-bag%3Famp%253Bclick_sum%3Db00749c2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bpro%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1778190169/multicolor-quilted-cotton-tote-bag?amp;click_sum=b00749c2&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3&amp;pro=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1778190169%2Fmulticolor-quilted-cotton-tote-bag%3Famp%253Bclick_sum%3Db00749c2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bpro%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Seller details

### Business registration number

### Location

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=814046424&referring_id=45443924&referring_type=shop&recipient_id=814046424&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Item in the photo is in **Colour: Orange**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Colour: Parrot green**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Colour: Rose Pink**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Colour: Mustard**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Colour: red**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Colour: Royal blue**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Colour: Sea green**




Select this option








Option selected!













This option is sold out.



Click to zoom

- ![May include: A large tote bag with a pink and orange floral print. The bag has a white and pink striped handle. The bag is sitting on a green grassy surface next to a silver laptop computer.](https://i.etsystatic.com/45443924/r/il/a45dd0/6255021378/il_300x300.6255021378_lf29.jpg)
- ![Multicolor Quilted Cotton Tote Bag: Handblock Print, Travel Friendly Parrot green](https://i.etsystatic.com/45443924/r/il/e1e0e7/6821807371/il_300x300.6821807371_sw26.jpg)
- ![May include: A pink and green floral tote bag with white and pink striped straps. The bag is made of quilted fabric and has a floral print. The bag is sitting on a green grassy surface.](https://i.etsystatic.com/45443924/r/il/7c7bfb/6301767589/il_300x300.6301767589_cxkv.jpg)
- ![May include: A yellow and white floral tote bag with a quilted design. The bag has two long straps and is made of cotton fabric.](https://i.etsystatic.com/45443924/r/il/52698c/6303071311/il_300x300.6303071311_sjz0.jpg)
- ![May include: A red and white floral tote bag with a laptop computer on the grass. The tote bag has a white floral pattern on a red background. The laptop is silver and has a black screen.](https://i.etsystatic.com/45443924/r/il/ab1156/6303072475/il_300x300.6303072475_4ifx.jpg)
- ![May include: A blue and white tote bag with a floral pattern. The bag has two handles and is sitting on a green grassy surface. A silver laptop computer is in front of the bag.](https://i.etsystatic.com/45443924/r/il/db5244/6255023834/il_300x300.6255023834_jri4.jpg)
- ![May include: A teal blue tote bag with a white floral pattern. The bag has a white stitched trim and two white straps.](https://i.etsystatic.com/45443924/r/il/738c65/6303075547/il_300x300.6303075547_oqyc.jpg)
- ![May include: A pink and white striped tote bag with a floral print pocket. The pocket has a black phone inside.](https://i.etsystatic.com/45443924/r/il/3a19d3/6244784157/il_300x300.6244784157_botj.jpg)
- ![May include: A pink and orange tote bag with a white floral pattern. The bag has a white and orange striped handle and is holding a silver laptop computer.](https://i.etsystatic.com/45443924/r/il/13fd5c/6303076555/il_300x300.6303076555_mpk6.jpg)
- ![May include: A blue and white tote bag with a floral pattern. The bag has a white trim and is made of a thick fabric. The bag is large enough to hold a laptop computer.](https://i.etsystatic.com/45443924/r/il/2c1e96/6255028738/il_300x300.6255028738_c3zf.jpg)

- ![](https://i.etsystatic.com/iap/650c01/7208751541/iap_640x640.7208751541_n71j0is8.jpg?version=0)

5 out of 5 stars

- Sizes:

18X18 Inch

- Colour:

Orange


Absolutely LOVE this bag! Everything is just as it’s pictured. It’s so beautifully made and the quality is amazing. I recommend highly!

![](https://i.etsystatic.com/iusa/1555a0/72146315/iusa_75x75.72146315_pleh.jpg?version=0)

Sep 1, 2025


[Madison Willis](https://www.etsy.com/people/pxbrmxa3)

Purchased item:

[![Multicolor Quilted Cotton Tote Bag: Handblock Print, Travel Friendly](https://i.etsystatic.com/45443924/r/il/a45dd0/6255021378/il_170x135.6255021378_lf29.jpg)\\
\\
Multicolor Quilted Cotton Tote Bag: Handblock Print, Travel Friendly\\
\\
Sale Price $20.00\\
$20.00\\
\\
$40.00\\
Original Price $40.00\\
\\
\\
(50% off)](https://www.etsy.com/listing/1778190169/multicolor-quilted-cotton-tote-bag?ref=ap-listing)

Purchased item:

[![Multicolor Quilted Cotton Tote Bag: Handblock Print, Travel Friendly](https://i.etsystatic.com/45443924/r/il/a45dd0/6255021378/il_170x135.6255021378_lf29.jpg)\\
\\
Multicolor Quilted Cotton Tote Bag: Handblock Print, Travel Friendly\\
\\
Sale Price $20.00\\
$20.00\\
\\
$40.00\\
Original Price $40.00\\
\\
\\
(50% off)](https://www.etsy.com/listing/1778190169/multicolor-quilted-cotton-tote-bag?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/c29ffd/6781973044/iap_640x640.6781973044_b6mst4d3.jpg?version=0)

5 out of 5 stars

- Sizes:

16X16 Inch

- Colour:

Orange


Super nice bag, beautiful colorful fabric!

See in original language


Translated by Google


Super mooie tas, mooie kleurige stof!


![](https://i.etsystatic.com/iusa/769438/36539310/iusa_75x75.36539310_ky9k.jpg?version=0)

Apr 10, 2025


[Karin Kool](https://www.etsy.com/people/karinkool319)

Purchased item:

[![Multicolor Quilted Cotton Tote Bag: Handblock Print, Travel Friendly](https://i.etsystatic.com/45443924/r/il/a45dd0/6255021378/il_170x135.6255021378_lf29.jpg)\\
\\
Multicolor Quilted Cotton Tote Bag: Handblock Print, Travel Friendly\\
\\
Sale Price $20.00\\
$20.00\\
\\
$40.00\\
Original Price $40.00\\
\\
\\
(50% off)](https://www.etsy.com/listing/1778190169/multicolor-quilted-cotton-tote-bag?ref=ap-listing)

Purchased item:

[![Multicolor Quilted Cotton Tote Bag: Handblock Print, Travel Friendly](https://i.etsystatic.com/45443924/r/il/a45dd0/6255021378/il_170x135.6255021378_lf29.jpg)\\
\\
Multicolor Quilted Cotton Tote Bag: Handblock Print, Travel Friendly\\
\\
Sale Price $20.00\\
$20.00\\
\\
$40.00\\
Original Price $40.00\\
\\
\\
(50% off)](https://www.etsy.com/listing/1778190169/multicolor-quilted-cotton-tote-bag?ref=ap-listing)