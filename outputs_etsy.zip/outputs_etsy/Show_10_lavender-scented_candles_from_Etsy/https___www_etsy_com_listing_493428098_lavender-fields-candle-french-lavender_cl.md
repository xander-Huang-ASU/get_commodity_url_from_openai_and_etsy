[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/493428098/lavender-fields-candle-french-lavender?amp;click_sum=55b9df25&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3&amp;pro=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=55b9df25&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bpro=1&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=55b9df25&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bpro=1&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=55b9df25&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bpro=1&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=55b9df25&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bpro=1&explicit=1&ref=catnav_breadcrumb-3)
- [Container Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/container-candles?amp%3Bclick_sum=55b9df25&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bpro=1&explicit=1&ref=catnav_breadcrumb-4)

Etsy’s Pick

Etsy’s Picks are hand selected by our style experts to highlight items from shops that have shown quality, reliability and style.

[Discover More](https://www.etsy.com/featured/hub/etsy-picks?ref=listing_etsys_pick_signal)


Add to Favorites


- ![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California image 1](https://i.etsystatic.com/13880851/r/il/c201c2/6922345799/il_794xN.6922345799_7e1v.jpg)
- ![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California image 2](https://i.etsystatic.com/13880851/r/il/a2ca73/6874368542/il_794xN.6874368542_99pv.jpg)
- ![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California image 3](https://i.etsystatic.com/13880851/r/il/0a123e/6922345883/il_794xN.6922345883_k5y2.jpg)
- ![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California image 4](https://i.etsystatic.com/13880851/r/il/d937ac/6748533681/il_794xN.6748533681_79mr.jpg)
- ![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California image 5](https://i.etsystatic.com/13880851/r/il/c59600/6748533683/il_794xN.6748533683_f4hd.jpg)
- ![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California image 6](https://i.etsystatic.com/13880851/r/il/1994c1/6874368326/il_794xN.6874368326_d724.jpg)

- ![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California image 1](https://i.etsystatic.com/13880851/r/il/c201c2/6922345799/il_75x75.6922345799_7e1v.jpg)
- ![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California image 2](https://i.etsystatic.com/13880851/r/il/a2ca73/6874368542/il_75x75.6874368542_99pv.jpg)
- ![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California image 3](https://i.etsystatic.com/13880851/r/il/0a123e/6922345883/il_75x75.6922345883_k5y2.jpg)
- ![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California image 4](https://i.etsystatic.com/13880851/r/il/d937ac/6748533681/il_75x75.6748533681_79mr.jpg)
- ![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California image 5](https://i.etsystatic.com/13880851/r/il/c59600/6748533683/il_75x75.6748533683_f4hd.jpg)
- ![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California image 6](https://i.etsystatic.com/13880851/r/il/1994c1/6874368326/il_75x75.6874368326_d724.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F493428098%2Flavender-fields-candle-french-lavender%23report-overlay-trigger)

In 6 carts

NowPrice:$19.50+


Original Price:
$26.00+


Loading


25% off


•

Sale ends on November 21


# Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California

[HazelCandleCo](https://www.etsy.com/shop/HazelCandleCo?ref=shop-header-name&listing_id=493428098&from_page=listing)

[5 out of 5 stars](https://www.etsy.com/listing/493428098/lavender-fields-candle-french-lavender?amp;click_sum=55b9df25&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3&amp;pro=1#reviews)

Arrives soon! Get it by

Nov 14-22


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

Size


Select an option

Standard Single Wick ($19.50)

XL double Wick ($28.50)

Please select an option


Quantity



1234567891011121314151617181920212223242526272829303132333435363738394041424344454647484950515253545556575859606162636465666768697071727374

4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Buy together, get free shipping

## Buy together, get free shipping

Add both to cart



Loading


[See more items](https://www.etsy.com/listing/493428098/lavender-fields-candle-french-lavender?amp;click_sum=55b9df25&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3&amp;pro=1#recs_ribbon_container)

![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California](https://i.etsystatic.com/13880851/r/il/c201c2/6922345799/il_340x270.6922345799_7e1v.jpg)
This listing

### Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California

Sale Price $19.50
$19.50

$26.00
Original Price $26.00


(25% off)




Add to Favorites


[![California Pine & Spruce Scented Soy Candle - Nature-Inspired Gift for Outdoor Lovers Eco Friendly](https://i.etsystatic.com/13880851/r/il/7df35a/6874347142/il_340x270.6874347142_qi6o.jpg)\\
\\
**California Pine & Spruce Scented Soy Candle - Nature-Inspired Gift for Outdoor Lovers Eco Friendly**\\
\\
Sale Price $19.50\\
$19.50\\
\\
$26.00\\
Original Price $26.00\\
\\
\\
(25% off)](https://www.etsy.com/listing/473979538/california-pine-spruce-scented-soy?click_key=0908b5fbc75bca74287d1d29ce100073%3ALT9cc48e29c5fb9be27a5ff831b5be712615daf5aa&click_sum=509e5044&ls=r&ref=listing-free-shipping-bundle-1&pro=1&content_source=0908b5fbc75bca74287d1d29ce100073%253ALT9cc48e29c5fb9be27a5ff831b5be712615daf5aa "California Pine & Spruce Scented Soy Candle - Nature-Inspired Gift for Outdoor Lovers Eco Friendly")


Add to Favorites


![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California](https://i.etsystatic.com/13880851/r/il/c201c2/6922345799/il_340x270.6922345799_7e1v.jpg)
This listing

### Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California

Sale Price $19.50
$19.50

$26.00
Original Price $26.00


(25% off)




Add to Favorites


[![California Pine & Spruce Scented Soy Candle - Nature-Inspired Gift for Outdoor Lovers Eco Friendly](https://i.etsystatic.com/13880851/r/il/7df35a/6874347142/il_340x270.6874347142_qi6o.jpg)\\
\\
**California Pine & Spruce Scented Soy Candle - Nature-Inspired Gift for Outdoor Lovers Eco Friendly**\\
\\
Sale Price $19.50\\
$19.50\\
\\
$26.00\\
Original Price $26.00\\
\\
\\
(25% off)](https://www.etsy.com/listing/473979538/california-pine-spruce-scented-soy?click_key=0908b5fbc75bca74287d1d29ce100073%3ALT9cc48e29c5fb9be27a5ff831b5be712615daf5aa&click_sum=509e5044&ls=r&ref=listing-free-shipping-bundle-1&pro=1&content_source=0908b5fbc75bca74287d1d29ce100073%253ALT9cc48e29c5fb9be27a5ff831b5be712615daf5aa "California Pine & Spruce Scented Soy Candle - Nature-Inspired Gift for Outdoor Lovers Eco Friendly")


Add to Favorites


![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California](https://i.etsystatic.com/13880851/r/il/c201c2/6922345799/il_340x270.6922345799_7e1v.jpg)
This listing

### Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California

Sale Price $19.50
$19.50

$26.00
Original Price $26.00


(25% off)




Add to Favorites


[![California Pine & Spruce Scented Soy Candle - Nature-Inspired Gift for Outdoor Lovers Eco Friendly](https://i.etsystatic.com/13880851/r/il/7df35a/6874347142/il_340x270.6874347142_qi6o.jpg)\\
\\
**California Pine & Spruce Scented Soy Candle - Nature-Inspired Gift for Outdoor Lovers Eco Friendly**\\
\\
Sale Price $19.50\\
$19.50\\
\\
$26.00\\
Original Price $26.00\\
\\
\\
(25% off)](https://www.etsy.com/listing/473979538/california-pine-spruce-scented-soy?click_key=0908b5fbc75bca74287d1d29ce100073%3ALT9cc48e29c5fb9be27a5ff831b5be712615daf5aa&click_sum=509e5044&ls=r&ref=listing-free-shipping-bundle-1&pro=1&content_source=0908b5fbc75bca74287d1d29ce100073%253ALT9cc48e29c5fb9be27a5ff831b5be712615daf5aa "California Pine & Spruce Scented Soy Candle - Nature-Inspired Gift for Outdoor Lovers Eco Friendly")


Add to Favorites


## Item details

### Highlights

Designed by [HazelCandleCo](https://www.etsy.com/shop/HazelCandleCo)

- Materials: all natural soy wax, essential oils, cotton core wick, real lavender buds, recycled glass jar, aluminum lid



- Gift wrapping available

See details![](https://i.etsystatic.com/igwp/6f63ad/1502894933/igwp_300xN.1502894933_syjvlzwd.jpg?version=0)

Gift wrapping by HazelCandleCo

Candles are individually boxed, wrapped in craft brown wrapping paper and tied with a white and red tulle.

A peaceful escape in bloom.

Inspired by wild meadows bathed in golden light, Lavender Fields blends the relaxing scent of French lavender with crisp bergamot and soft citrus notes. It’s floral, clean, and calming — a perfect way to wind down and create a serene atmosphere at home.

Scent Profile:

Top: French lavender, bergamot

Base: Lemon peel, citrus, violet

Why You’ll Love It:

\- Calming, spa-like floral fragrance

\- 100% natural soy-coconut wax blend

\- Non-toxic · Phthalate-free · Clean burning

\- Cotton wick — no additives or dyes

\- Burn time: 50 hours (7.5oz) / 80 hours (16oz)

\- Hand-poured in California

Crafted with Intention:

We don’t do overpowering or artificial. We craft candles to bring real scents — and real calm — into your space. Lavender Fields is your moment of stillness, bottled.

Perfect for:

Self-care routines · Sleep support · Housewarming gifts · Bathroom/spa decor · Everyday relaxation


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-22**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 14 days


- Ships from: **Campbell, CA**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## FAQs

Wholesale availability


Yes, email us for wholesale info: wholesale@hazelcandleco.com


Custom and personalized orders


We offer a wide variety of private label options, please email hello@hazelcandleco.com for more info


Sizing details


Our regular candles are 7.5 ounces of all natural US grown soy wax in an 8 ounce recycled and reusable glass jar.


Care instructions


Always trim the wick to a 1/4" before lighting, this prevents a large flame and soot on the glass.

Allow the wax to melt right to the outer edge of the jar, this will prevent tunneling and creates a memory burn and ensures your candle burns evenly throughout its life.

You can reuse your candle jar by putting it in the freezer overnight. The last of the wax and wick base should pop right out. Wash with warm water ad you have a cute jar to use as you'd like!


Shipping


Free shipping on all orders over $35


## Meet your seller

![Henry Cooper](https://i.etsystatic.com/13880851/r/isla/e8dd7e/77100010/isla_75x75.77100010_jpxrltfc.jpg)

Henry Cooper

Owner of [HazelCandleCo](https://www.etsy.com/shop/HazelCandleCo?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo5NTE4ODM3NDoxNzYyODI1NDE0OmVmZjM1YmI4YjYxNmQzZGUzMDI1NTk1N2VhYzAzM2M5&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F493428098%2Flavender-fields-candle-french-lavender%3Famp%253Bclick_sum%3D55b9df25%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bpro%3D1)

[Message Henry](https://www.etsy.com/messages/new?with_id=95188374&referring_id=493428098&referring_type=listing&recipient_id=95188374&from_action=contact-seller)

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (222)

5.0/5

item average

5.0Item quality

5.0Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Smells amazing

Love it

Fast shipping

Would recommend

Gift-worthy

Great product

Lovely


Filter by category


Quality (107)


Appearance (47)


Shipping & Packaging (45)


Seller service (18)


Description accuracy (10)


Comfort (5)


Value (5)


Ease of use (3)


Condition (2)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[goodmansc](https://www.etsy.com/people/goodmansc?ref=l_review)
Nov 2, 2025


This is the 2nd batch of candles I have purchased from Hazel. They smell wonderful and are very long-lasting, at least with a candle lamp.



[goodmansc](https://www.etsy.com/people/goodmansc?ref=l_review)
Nov 2, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/ce644c/66010399/iusa_75x75.66010399_j7r2.jpg?version=0)

[chance grey](https://www.etsy.com/people/ybf6ippd?ref=l_review)
May 31, 2025


I love this candle so much



![](https://i.etsystatic.com/iusa/ce644c/66010399/iusa_75x75.66010399_j7r2.jpg?version=0)

[chance grey](https://www.etsy.com/people/ybf6ippd?ref=l_review)
May 31, 2025


5 out of 5 stars
5

This item

[Nikki Wallace](https://www.etsy.com/people/125mansfield?ref=l_review)
Mar 13, 2025


Smells great and arrived quickly



[Nikki Wallace](https://www.etsy.com/people/125mansfield?ref=l_review)
Mar 13, 2025


5 out of 5 stars
5

This item

[Lorraine Ambrosecchio](https://www.etsy.com/people/CTLAshop1925?ref=l_review)
Feb 22, 2025


I love the scent. I’m very happy with my purchase!



[Lorraine Ambrosecchio](https://www.etsy.com/people/CTLAshop1925?ref=l_review)
Feb 22, 2025


View all reviews for this item

### Photos from reviews

![Erica added a photo of their purchase](https://i.etsystatic.com/iap/90ee20/4712381908/iap_300x300.4712381908_jje112lr.jpg?version=0)

![Mikayla added a photo of their purchase](https://i.etsystatic.com/iap/6a67f5/2988517015/iap_300x300.2988517015_t456iclg.jpg?version=0)

![Rachel added a photo of their purchase](https://i.etsystatic.com/iap/5720be/2870524112/iap_300x300.2870524112_216deuj8.jpg?version=0)

![shalena added a photo of their purchase](https://i.etsystatic.com/iap/f547c5/2326351617/iap_300x300.2326351617_9v8u2vbo.jpg?version=0)

![Sophie added a photo of their purchase](https://i.etsystatic.com/iap/3ad78d/1508604680/iap_300x300.1508604680_l014k8us.jpg?version=0)

![bonnie added a photo of their purchase](https://i.etsystatic.com/iap/b3d12c/1294276423/iap_300x300.1294276423_ato4kdsg.jpg?version=0)

[![HazelCandleCo](https://i.etsystatic.com/iusa/2ef54e/112402197/iusa_75x75.112402197_owbx.jpg?version=0)](https://www.etsy.com/shop/HazelCandleCo?ref=shop_profile&listing_id=493428098)

[HazelCandleCo](https://www.etsy.com/shop/HazelCandleCo?ref=shop_profile&listing_id=493428098)

[Owned by Henry Cooper](https://www.etsy.com/shop/HazelCandleCo?ref=shop_profile&listing_id=493428098) \|

United States

5.0
(4.4k)


21.2k sales

9 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=95188374&referring_id=493428098&referring_type=listing&recipient_id=95188374&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo5NTE4ODM3NDoxNzYyODI1NDE0OmVmZjM1YmI4YjYxNmQzZGUzMDI1NTk1N2VhYzAzM2M5&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F493428098%2Flavender-fields-candle-french-lavender%3Famp%253Bclick_sum%3D55b9df25%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bpro%3D1)

Smooth shippingHas a history of shipping on time with tracking.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/HazelCandleCo?ref=lp_mys_mfts)

- [![California Pine & Spruce Scented Soy Candle - Nature-Inspired Gift for Outdoor Lovers Eco Friendly](https://i.etsystatic.com/13880851/r/il/7df35a/6874347142/il_340x270.6874347142_qi6o.jpg)\\
\\
**California Pine & Spruce Scented Soy Candle - Nature-Inspired Gift for Outdoor Lovers Eco Friendly**\\
\\
Sale Price $19.50\\
$19.50\\
\\
$26.00\\
Original Price $26.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/473979538/california-pine-spruce-scented-soy?click_key=2c60960f22f7a5a75ba7d4763bd2cf54%3ALTa72446a562520c9554fed3b70a7c11b3ce48ca0c&click_sum=b04f5f79&ls=r&ref=related-1&pro=1&content_source=2c60960f22f7a5a75ba7d4763bd2cf54%253ALTa72446a562520c9554fed3b70a7c11b3ce48ca0c "California Pine & Spruce Scented Soy Candle - Nature-Inspired Gift for Outdoor Lovers Eco Friendly")




Add to Favorites


- [![Coffee Candle with Hazelnut & Cocoa Aroma - California-Made Kitchen Ambiance Handcrafted Soy Wax Morning Brew](https://i.etsystatic.com/13880851/r/il/9ab7b9/6874359416/il_340x270.6874359416_4n6n.jpg)\\
\\
**Coffee Candle with Hazelnut & Cocoa Aroma - California-Made Kitchen Ambiance Handcrafted Soy Wax Morning Brew**\\
\\
Sale Price $19.50\\
$19.50\\
\\
$26.00\\
Original Price $26.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/504638130/coffee-candle-with-hazelnut-cocoa-aroma?click_key=2c60960f22f7a5a75ba7d4763bd2cf54%3ALTdacb043a4dcdbe2b7b5778771dcc1c7048601572&click_sum=65abf349&ls=r&ref=related-2&pro=1&content_source=2c60960f22f7a5a75ba7d4763bd2cf54%253ALTdacb043a4dcdbe2b7b5778771dcc1c7048601572 "Coffee Candle with Hazelnut & Cocoa Aroma - California-Made Kitchen Ambiance Handcrafted Soy Wax Morning Brew")




Add to Favorites


- [![Best Sellers Discovery Set / scent sample pack / 4, 4oz candles / gift set / soy candles / gift box candles](https://i.etsystatic.com/13880851/r/il/459e97/6399987416/il_340x270.6399987416_i8k8.jpg)\\
\\
**Best Sellers Discovery Set / scent sample pack / 4, 4oz candles / gift set / soy candles / gift box candles**\\
\\
Sale Price $39.00\\
$39.00\\
\\
$52.00\\
Original Price $52.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1379104228/best-sellers-discovery-set-scent-sample?click_key=2c60960f22f7a5a75ba7d4763bd2cf54%3ALT8990bba8261e6afc2e8e5caaa1d1a7e907f419bb&click_sum=71789621&ls=r&ref=related-3&pro=1&content_source=2c60960f22f7a5a75ba7d4763bd2cf54%253ALT8990bba8261e6afc2e8e5caaa1d1a7e907f419bb "Best Sellers Discovery Set / scent sample pack / 4, 4oz candles / gift set / soy candles / gift box candles")




Add to Favorites


- [![Fall Scent Sample Set / 4, 4oz candles / gift set / fall candles / discovery set / soy candles handmade / gift box](https://i.etsystatic.com/13880851/r/il/a50716/7152234799/il_340x270.7152234799_plk7.jpg)\\
\\
**Fall Scent Sample Set / 4, 4oz candles / gift set / fall candles / discovery set / soy candles handmade / gift box**\\
\\
Sale Price $39.00\\
$39.00\\
\\
$52.00\\
Original Price $52.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1292025489/fall-scent-sample-set-4-4oz-candles-gift?click_key=3f21610d759a0170d0a15ec0d602b6697df8841d%3A1292025489&click_sum=547442a3&ref=related-4&pro=1 "Fall Scent Sample Set / 4, 4oz candles / gift set / fall candles / discovery set / soy candles handmade / gift box")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 9, 2025


[2725 favorites](https://www.etsy.com/listing/493428098/lavender-fields-candle-french-lavender/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=55b9df25&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bpro=1&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=55b9df25&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bpro=1&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=55b9df25&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bpro=1&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=55b9df25&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bpro=1&explicit=1&ref=breadcrumb_listing) [Container Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/container-candles?amp%3Bclick_sum=55b9df25&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bpro=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Home Decor

[Red Violet Pillow for Sale](https://www.etsy.com/market/red_violet_pillow) [Just Wear a Mask Sign - FREE SHIPPING! Business Reopening Signs - Home Decor](https://www.etsy.com/listing/802875624/x2-whatever-just-wear-a-mask-sign-free) [Shop Eiffel Tower Bookend](https://www.etsy.com/market/eiffel_tower_bookend) [Neon Peach Light - US](https://www.etsy.com/market/neon_peach_light) [Shop Armenian Egg](https://www.etsy.com/market/armenian_egg) [Small Ceramic Tiles for Sale](https://www.etsy.com/market/small_ceramic_tiles) [Buy Oaxaca Ornament Online](https://www.etsy.com/market/oaxaca_ornament) [Christmas red - Home Decor](https://www.etsy.com/listing/1350183745/christmas-red-gold-and-silver-grapevine)

Sculpture

[Brass Carved Lord Ganesha with Stonework Statue by Suncitygift](https://www.etsy.com/listing/1681794377/brass-carved-lord-ganesha-with-stonework)

Electronics Cases

[Shop Stripe Monogram Phone Case](https://www.etsy.com/market/stripe_monogram_phone_case)

Handbags

[Cats in Black Clutch Purse](https://www.etsy.com/listing/501939920/cats-in-black-clutch-purse-cat-lover) [Suede Messenger Bag With Guitar Strap - US](https://www.etsy.com/market/suede_messenger_bag_with_guitar_strap)

Necklaces

[Shop Yuta Ring Necklace](https://www.etsy.com/market/yuta_ring_necklace)

Beads Gems & Cabochons

[Gold Heart Charms - Beads, Gems & Cabochons](https://www.etsy.com/listing/976684949/gold-heart-charms-love-heart-charms-22k)

Gender Neutral Kids Clothing

[RG Leotard competition rhythmic gymnastics leotard figure ice skating dress acrobatics suit Rock'n' Roll Showdance Sportacrobatics twirling - Gender-Neutral Kids' Clothing](https://www.etsy.com/listing/874099974/rg-leotard-competition-rhythmic)

Accessories

[Shop Veil With Color](https://www.etsy.com/market/veil_with_color)

Kitchen & Dining

[Cincinnati Great American Ball Park Stadium vintage styled blueprint ceramic coffee mug. Baseball sports memorabilia and gift ideas for men.](https://www.etsy.com/listing/952472984/cincinnati-great-american-ball-park)

Womens Clothing

[Shop Kirby Bra](https://www.etsy.com/market/kirby_bra)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F493428098%2Flavender-fields-candle-french-lavender%3Famp%253Bclick_sum%3D55b9df25%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bpro%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgyNTQxNDo0ZTI0ZTUyN2ViM2RkNGUwN2U2ZDhlZjZiYTg1MDk2Yg==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F493428098%2Flavender-fields-candle-french-lavender%3Famp%253Bclick_sum%3D55b9df25%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bpro%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/493428098/lavender-fields-candle-french-lavender?amp;click_sum=55b9df25&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3&amp;pro=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F493428098%2Flavender-fields-candle-french-lavender%3Famp%253Bclick_sum%3D55b9df25%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bpro%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for HazelCandleCo

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 12 hours of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## Seller details

### Other details

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=95188374&referring_id=13880851&referring_type=shop&recipient_id=95188374&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California image 1](https://i.etsystatic.com/13880851/r/il/c201c2/6922345799/il_300x300.6922345799_7e1v.jpg)
- ![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California image 2](https://i.etsystatic.com/13880851/r/il/a2ca73/6874368542/il_300x300.6874368542_99pv.jpg)
- ![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California image 3](https://i.etsystatic.com/13880851/r/il/0a123e/6922345883/il_300x300.6922345883_k5y2.jpg)
- ![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California image 4](https://i.etsystatic.com/13880851/r/il/d937ac/6748533681/il_300x300.6748533681_79mr.jpg)
- ![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California image 5](https://i.etsystatic.com/13880851/r/il/c59600/6748533683/il_300x300.6748533683_f4hd.jpg)
- ![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California image 6](https://i.etsystatic.com/13880851/r/il/1994c1/6874368326/il_300x300.6874368326_d724.jpg)

- ![](https://i.etsystatic.com/iap/90ee20/4712381908/iap_640x640.4712381908_jje112lr.jpg?version=0)

5 out of 5 stars

- Size:

Regular


Nice strong lavender scent with real lavender buds in the wax. Plus I love the reusable frosted glass jar with lid.

![](https://i.etsystatic.com/iusa/c94c96/100709027/iusa_75x75.100709027_qo5p.jpg?version=0)

Mar 11, 2023


[Erica Li](https://www.etsy.com/people/lapomegranate)

Purchased item:

[![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California](https://i.etsystatic.com/13880851/r/il/c201c2/6922345799/il_170x135.6922345799_7e1v.jpg)\\
\\
Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California\\
\\
Sale Price $19.50\\
$19.50\\
\\
$26.00\\
Original Price $26.00\\
\\
\\
(25% off)](https://www.etsy.com/listing/493428098/lavender-fields-candle-french-lavender?ref=ap-listing)

Purchased item:

[![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California](https://i.etsystatic.com/13880851/r/il/c201c2/6922345799/il_170x135.6922345799_7e1v.jpg)\\
\\
Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California\\
\\
Sale Price $19.50\\
$19.50\\
\\
$26.00\\
Original Price $26.00\\
\\
\\
(25% off)](https://www.etsy.com/listing/493428098/lavender-fields-candle-french-lavender?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/6a67f5/2988517015/iap_640x640.2988517015_t456iclg.jpg?version=0)

5 out of 5 stars

- Size:

Regular


I grow lavender during the summer and it smells just like that. I will 100% be buying more. Also packaging is great!

![](https://i.etsystatic.com/iusa/6a53d6/58682826/iusa_75x75.58682826_ii7i.jpg?version=0)

Mar 14, 2021


[Mikayla Brummett](https://www.etsy.com/people/mikaylabrummett)

Purchased item:

[![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California](https://i.etsystatic.com/13880851/r/il/c201c2/6922345799/il_170x135.6922345799_7e1v.jpg)\\
\\
Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California\\
\\
Sale Price $19.50\\
$19.50\\
\\
$26.00\\
Original Price $26.00\\
\\
\\
(25% off)](https://www.etsy.com/listing/493428098/lavender-fields-candle-french-lavender?ref=ap-listing)

Purchased item:

[![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California](https://i.etsystatic.com/13880851/r/il/c201c2/6922345799/il_170x135.6922345799_7e1v.jpg)\\
\\
Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California\\
\\
Sale Price $19.50\\
$19.50\\
\\
$26.00\\
Original Price $26.00\\
\\
\\
(25% off)](https://www.etsy.com/listing/493428098/lavender-fields-candle-french-lavender?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/5720be/2870524112/iap_640x640.2870524112_216deuj8.jpg?version=0)

5 out of 5 stars

- Size:

Regular


Just bought 4 more. Great lavender smell. Not perfume-y but natural and real lavender. Love it.

![](https://i.etsystatic.com/iusa/2e90d8/106442113/iusa_75x75.106442113_qbqw.jpg?version=0)

Feb 13, 2021


[Rachel Shaw](https://www.etsy.com/people/shaw99)

Purchased item:

[![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California](https://i.etsystatic.com/13880851/r/il/c201c2/6922345799/il_170x135.6922345799_7e1v.jpg)\\
\\
Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California\\
\\
Sale Price $19.50\\
$19.50\\
\\
$26.00\\
Original Price $26.00\\
\\
\\
(25% off)](https://www.etsy.com/listing/493428098/lavender-fields-candle-french-lavender?ref=ap-listing)

Purchased item:

[![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California](https://i.etsystatic.com/13880851/r/il/c201c2/6922345799/il_170x135.6922345799_7e1v.jpg)\\
\\
Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California\\
\\
Sale Price $19.50\\
$19.50\\
\\
$26.00\\
Original Price $26.00\\
\\
\\
(25% off)](https://www.etsy.com/listing/493428098/lavender-fields-candle-french-lavender?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/f547c5/2326351617/iap_640x640.2326351617_9v8u2vbo.jpg?version=0)

5 out of 5 stars

- Size:

Regular


Beautiful, natural scent. Exactly what I was hoping for.

![](https://i.etsystatic.com/iusa/82b056/44492241/iusa_75x75.44492241_hptj.jpg?version=0)

Apr 24, 2020


[shalena m](https://www.etsy.com/people/ariesflies)

Purchased item:

[![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California](https://i.etsystatic.com/13880851/r/il/c201c2/6922345799/il_170x135.6922345799_7e1v.jpg)\\
\\
Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California\\
\\
Sale Price $19.50\\
$19.50\\
\\
$26.00\\
Original Price $26.00\\
\\
\\
(25% off)](https://www.etsy.com/listing/493428098/lavender-fields-candle-french-lavender?ref=ap-listing)

Purchased item:

[![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California](https://i.etsystatic.com/13880851/r/il/c201c2/6922345799/il_170x135.6922345799_7e1v.jpg)\\
\\
Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California\\
\\
Sale Price $19.50\\
$19.50\\
\\
$26.00\\
Original Price $26.00\\
\\
\\
(25% off)](https://www.etsy.com/listing/493428098/lavender-fields-candle-french-lavender?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/3ad78d/1508604680/iap_640x640.1508604680_l014k8us.jpg?version=0)

5 out of 5 stars

- Lid Color:

Black


SMELLS SO SO GOOD! Love the lavender pieces and a nice even burn. Definitely will be purchasing again. 🌸❤️

![](https://i.etsystatic.com/iusa/10f74b/35226800/iusa_75x75.35226800_q6h1.jpg?version=0)

May 20, 2018


[Sophie Sexton](https://www.etsy.com/people/sophiesexton)

Purchased item:

[![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California](https://i.etsystatic.com/13880851/r/il/c201c2/6922345799/il_170x135.6922345799_7e1v.jpg)\\
\\
Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California\\
\\
Sale Price $19.50\\
$19.50\\
\\
$26.00\\
Original Price $26.00\\
\\
\\
(25% off)](https://www.etsy.com/listing/493428098/lavender-fields-candle-french-lavender?ref=ap-listing)

Purchased item:

[![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California](https://i.etsystatic.com/13880851/r/il/c201c2/6922345799/il_170x135.6922345799_7e1v.jpg)\\
\\
Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California\\
\\
Sale Price $19.50\\
$19.50\\
\\
$26.00\\
Original Price $26.00\\
\\
\\
(25% off)](https://www.etsy.com/listing/493428098/lavender-fields-candle-french-lavender?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/b3d12c/1294276423/iap_640x640.1294276423_ato4kdsg.jpg?version=0)

5 out of 5 stars

- Lid Color:

Black


Nice candles.

![](https://i.etsystatic.com/iusa/0515ee/29569602/iusa_75x75.29569602_kdhd.jpg?version=0)

Jul 19, 2017


[bonnie newcomb](https://www.etsy.com/people/foxglove86)

Purchased item:

[![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California](https://i.etsystatic.com/13880851/r/il/c201c2/6922345799/il_170x135.6922345799_7e1v.jpg)\\
\\
Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California\\
\\
Sale Price $19.50\\
$19.50\\
\\
$26.00\\
Original Price $26.00\\
\\
\\
(25% off)](https://www.etsy.com/listing/493428098/lavender-fields-candle-french-lavender?ref=ap-listing)

Purchased item:

[![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California](https://i.etsystatic.com/13880851/r/il/c201c2/6922345799/il_170x135.6922345799_7e1v.jpg)\\
\\
Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California\\
\\
Sale Price $19.50\\
$19.50\\
\\
$26.00\\
Original Price $26.00\\
\\
\\
(25% off)](https://www.etsy.com/listing/493428098/lavender-fields-candle-french-lavender?ref=ap-listing)