[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1823405290/lavender-lace-scented-luxury?amp;click_sum=148d6183&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=148d6183&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=148d6183&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=148d6183&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=148d6183&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=catnav_breadcrumb-3)
- [Container Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/container-candles?amp%3Bclick_sum=148d6183&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=catnav_breadcrumb-4)


Add to Favorites


- ![Lavender & Lace Scented Luxury Aromatherapy Soy Wax Candle ~ Lavender Essential Oil 10cl image 1](https://i.etsystatic.com/56381837/r/il/3beede/6742360173/il_794xN.6742360173_gm4t.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![Lavender & Lace Scented Luxury Aromatherapy Soy Wax Candle ~ Lavender Essential Oil 10cl image 2](https://i.etsystatic.com/56381837/r/il/641e9d/6742360399/il_794xN.6742360399_humw.jpg)
- ![Lavender & Lace Scented Luxury Aromatherapy Soy Wax Candle ~ Lavender Essential Oil 10cl image 3](https://i.etsystatic.com/56381837/r/il/eba540/6742360557/il_794xN.6742360557_c7yi.jpg)
- ![Lavender & Lace Scented Luxury Aromatherapy Soy Wax Candle ~ Lavender Essential Oil 10cl image 4](https://i.etsystatic.com/56381837/r/il/a52ba4/6694321434/il_794xN.6694321434_id5d.jpg)

- ![Lavender & Lace Scented Luxury Aromatherapy Soy Wax Candle ~ Lavender Essential Oil 10cl image 1](https://i.etsystatic.com/56381837/r/il/3beede/6742360173/il_75x75.6742360173_gm4t.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/copy_6DDF6F6B-8668-4FE3-BE3E-89FB89D7C244_hpbrms.jpg)

- ![Lavender & Lace Scented Luxury Aromatherapy Soy Wax Candle ~ Lavender Essential Oil 10cl image 2](https://i.etsystatic.com/56381837/r/il/641e9d/6742360399/il_75x75.6742360399_humw.jpg)
- ![Lavender & Lace Scented Luxury Aromatherapy Soy Wax Candle ~ Lavender Essential Oil 10cl image 3](https://i.etsystatic.com/56381837/r/il/eba540/6742360557/il_75x75.6742360557_c7yi.jpg)
- ![Lavender & Lace Scented Luxury Aromatherapy Soy Wax Candle ~ Lavender Essential Oil 10cl image 4](https://i.etsystatic.com/56381837/r/il/a52ba4/6694321434/il_75x75.6694321434_id5d.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1823405290%2Flavender-lace-scented-luxury%23report-overlay-trigger)

Low in stock, only 7 left

Price:$12.36


Loading


# Lavender & Lace Scented Luxury Aromatherapy Soy Wax Candle ~ Lavender Essential Oil 10cl

Made by [WhyteWicks](https://www.etsy.com/shop/WhyteWicks)

[5 out of 5 stars](https://www.etsy.com/listing/1823405290/lavender-lace-scented-luxury?amp;click_sum=148d6183&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2#reviews)

Quantity



1234567

4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Made by [WhyteWicks](https://www.etsy.com/shop/WhyteWicks)

- Materials: Wax type: Soy


- Sustainable features: vegan. Items may include additional materials or use methods that aren't considered sustainable features on our site. [Learn more](https://help.etsy.com/hc/articles/15532793357847)

Luxury Soy Wax Candle

Lavender & Lace

Immerse yourself in the soothing scent of our Lavender & Lace candle, handcrafted with pure lavender essential oil. This luxurious candle fills your space with a soft, herbal aroma, known for its calming and stress-relieving properties.

Hand-poured with care, it offers a clean, even burn for approximately 20-25 hours, creating a peaceful atmosphere perfect for relaxation, meditation, or unwinding after a long day.

Housed in a 10cl glass jar, this candle makes a thoughtful gift or a beautiful addition to any home.

Candle Details:

• Burn Time: Approx. 20-25 hours

• Wax Type: 100% Natural Soy Wax

• Wick: Organic Cotton

At Whyte Wicks, our candles are eco-friendly, vegan, and non-toxic. Made with high-quality soy wax, organic cotton wicks, and pure essential oils, they are free from harmful chemicals, ensuring a clean, sustainable, and long-lasting burn.


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-Dec 1**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges not accepted




But please contact me if you have problems with your order


- Ships from: **United Kingdom**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

## Be the first to review this item

No reviews yet. See what customers say about other items from this shop.


Read reviews for other items


[![WhyteWicks](https://i.etsystatic.com/iusa/e48b10/114064365/iusa_75x75.114064365_6cvr.jpg?version=0)](https://www.etsy.com/shop/WhyteWicks?ref=shop_profile&listing_id=1823405290)

[WhyteWicks](https://www.etsy.com/shop/WhyteWicks?ref=shop_profile&listing_id=1823405290)

[Owned by Whyte Wicks](https://www.etsy.com/shop/WhyteWicks?ref=shop_profile&listing_id=1823405290) \|

Belfast, United Kingdom

5.0
(11)


54 sales

11 months on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=1016905801&referring_id=1823405290&referring_type=listing&recipient_id=1016905801&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoxMDE2OTA1ODAxOjE3NjI4MjUzNDk6YWI3OTJlZGQwMTc1NTIzZjkxNDllOWYwMDA4YzUyYTU%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1823405290%2Flavender-lace-scented-luxury%3Famp%253Bclick_sum%3D148d6183%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2)

This seller usually responds **within 24 hours.**

## All reviews from this shop (11)

Show all

Absolutely beautiful wax melts! The scent is long-lasting and fills the room without being overpowering. The quality is outstanding, and the packaging is lovely. I especially love Timeless Grace (inspired by Lady Million)—it smells exactly like the original! Customer service was excellent, with friendly communication and prompt responses. My order arrived right on time, carefully packaged. I would highly recommend Whyte Wicks to anyone looking for high-quality, luxurious wax melts. Will definitely be purchasing again!

![Sarah added a photo of their purchase](https://i.etsystatic.com/iap/31463a/6638435336/iap_300x300.6638435336_37l6kyij.jpg?version=0)

![](https://i.etsystatic.com/iusa/73af76/90182517/iusa_75x75.90182517_mw2k.jpg?version=0)

SarahFeb 11, 2025

Purchased: [Timeless Grace inspired by Lady Million Highly Scented Luxury Soy Wax Melts ~ Natural, Vegan & Cruelty Free, Hand-poured in Northern IrelandOpens a new tab](https://www.etsy.com/listing/1852292858/lady-millionaire-soy-wax-melt-bar-neroli?ref=mys_shop_reviews)

Make a nice gifts, will look great placed in any room and looks safe and sturdy so will not slip over. Very happy with purchase.

shirleyNov 3, 2025

Purchased: [Clear Ribbed Glass Pillar Candle Holder: Elegant Centerpiece TrayOpens a new tab](https://www.etsy.com/listing/4305029432/clear-ribbed-glass-pillar-candle-holder?ref=mys_shop_reviews)

Wow, these melts smell absolutely divine! A strong scent which lasts so well.

n4yn0mOct 16, 2025

Purchased: [Pumpkin Spice Soy Wax Melts: Cinnamon, Clove, Nutmeg ScentOpens a new tab](https://www.etsy.com/listing/4361590951/pumpkin-spice-soy-wax-melts-cinnamon?ref=mys_shop_reviews)

This is really a lovely item

CaroleSep 27, 2025

Purchased: [Matte Ceramic Dragonfly Wax WarmerOpens a new tab](https://www.etsy.com/listing/1853489752/matte-ceramic-dragonfly-wax-warmer?ref=mys_shop_reviews)

Good item. Very happy with it

MarisaAug 10, 2025

Purchased: [Botanic Garden Scented Candle \| Soy Wax \| Essential Oils \| Ribbed Glass Jar with Lid \| 60g - Hand-poured Northern Ireland \| Calm & FreshOpens a new tab](https://www.etsy.com/listing/1891570670/botanic-garden-scented-luxury-soy-wax?ref=mys_shop_reviews)

Lovely way to scent your home.

oraigneJul 23, 2025

Purchased: [Pastel House Oil Burner Wax WarmerOpens a new tab](https://www.etsy.com/listing/1853493268/pastel-house-oil-burner-wax-warmer?ref=mys_shop_reviews)

Why are these reviews shown?

All reviews are from verified buyers. Reviews are shown automatically based on factors like recency, whether they include comments, your chosen language, and whether the rating reflects the typical experience with the shop.

## More from this shop

[Visit shop](https://www.etsy.com/shop/WhyteWicks?ref=lp_mys_mfts)

- [![Rose Geranium Essential Oil Aromatherapy Scented Luxury Soy Wax Candle](https://i.etsystatic.com/56381837/r/il/dba5f2/6694303478/il_340x270.6694303478_fyou.jpg)\\
\\
**Rose Geranium Essential Oil Aromatherapy Scented Luxury Soy Wax Candle**\\
\\
$19.23\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1837609275/rose-geranium-essential-oil-aromatherapy?click_key=e408cd1242ebda50935c4357b1b94ef2%3ALT6de32557a0ac3db1161d4853e2609439a5187a48&click_sum=18791ba1&ls=r&ref=related-1&content_source=e408cd1242ebda50935c4357b1b94ef2%253ALT6de32557a0ac3db1161d4853e2609439a5187a48 "Rose Geranium Essential Oil Aromatherapy Scented Luxury Soy Wax Candle")




Add to Favorites


- [![Clear Ribbed Glass Pillar Candle Holder: Elegant Centerpiece Tray](https://i.etsystatic.com/56381837/r/il/a52a2c/6907953773/il_340x270.6907953773_77db.jpg)\\
\\
**Clear Ribbed Glass Pillar Candle Holder: Elegant Centerpiece Tray**\\
\\
$8.23\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4305029432/clear-ribbed-glass-pillar-candle-holder?click_key=e408cd1242ebda50935c4357b1b94ef2%3ALTe2efb7585eed701eb0aae249cc7ba9b6ff0e7fea&click_sum=dfe841b5&ls=r&ref=related-2&content_source=e408cd1242ebda50935c4357b1b94ef2%253ALTe2efb7585eed701eb0aae249cc7ba9b6ff0e7fea "Clear Ribbed Glass Pillar Candle Holder: Elegant Centerpiece Tray")




Add to Favorites


- [![Clementine & Cinnamon – White Christmas Bauble Candle (Approx. 18cl / 180g) Handcrafted Luxury Gift](https://i.etsystatic.com/56381837/r/il/a51b77/7373592966/il_340x270.7373592966_onpy.jpg)\\
\\
**Clementine & Cinnamon – White Christmas Bauble Candle (Approx. 18cl / 180g) Handcrafted Luxury Gift**\\
\\
$54.96\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4401331852/clementine-cinnamon-white-christmas?click_key=e408cd1242ebda50935c4357b1b94ef2%3ALT16bd432fe3bed0fbe4723fbcba429fced8eac7e5&click_sum=c1f1b91d&ls=r&ref=related-3&content_source=e408cd1242ebda50935c4357b1b94ef2%253ALT16bd432fe3bed0fbe4723fbcba429fced8eac7e5 "Clementine & Cinnamon – White Christmas Bauble Candle (Approx. 18cl / 180g) Handcrafted Luxury Gift")




Add to Favorites


- [![Christmas Tree – Green Speckled Vogue Candle (Approx. 22cl / 220g)  Handcrafted Luxury Gift](https://i.etsystatic.com/56381837/r/il/d80d2c/7380227558/il_340x270.7380227558_l6kh.jpg)\\
\\
**Christmas Tree – Green Speckled Vogue Candle (Approx. 22cl / 220g) Handcrafted Luxury Gift**\\
\\
$41.22\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4402374221/christmas-tree-green-speckled-vogue?click_key=a2b144e1a6e4bd930ca066a1c2670e158d596eb6%3A4402374221&click_sum=c3c9b789&ref=related-4 "Christmas Tree – Green Speckled Vogue Candle (Approx. 22cl / 220g)  Handcrafted Luxury Gift")




Add to Favorites



## You may also like

Including ads
Learn more
Sellers looking to grow their business and reach more interested buyers can use Etsy’s advertising platform to promote their items. You’ll see ad results based on factors like relevancy, and the amount sellers pay per click. [Learn more](https://www.etsy.com/legal/policy/search-advertisement-ranking-disclosures/899478564529).


[See more](https://www.etsy.com/r/similar/1823405290?ref=internal_similar_listing_bot)

- [![Lavender Scented Blended Soy Candle - Lavendar Scented Soy Candle - Homemade Candle](https://i.etsystatic.com/7977799/r/il/c73f63/3971945767/il_340x270.3971945767_22cd.jpg)\\
\\
**Lavender Scented Blended Soy Candle - Lavendar Scented Soy Candle - Homemade Candle**\\
\\
$11.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/150479684/lavender-scented-blended-soy-candle?click_key=62c83e9b1f0a0c4b6ad64015461a82bc%3ALT0181f1992c38a04a6d234340919352e50aaf723c&click_sum=2012bf8c&ls=r&ref=internal-recs-393772-1&content_source=62c83e9b1f0a0c4b6ad64015461a82bc%253ALT0181f1992c38a04a6d234340919352e50aaf723c "Lavender Scented Blended Soy Candle - Lavendar Scented Soy Candle - Homemade Candle")




Add to Favorites


- [![Lavender Vegan Soy Wax Candle](https://i.etsystatic.com/14707774/r/il/1b7650/3713304684/il_340x270.3713304684_b8e9.jpg)\\
\\
**Lavender Vegan Soy Wax Candle**\\
\\
$20.50\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/538800062/lavender-vegan-soy-wax-candle?click_key=62c83e9b1f0a0c4b6ad64015461a82bc%3ALT4c3055bbc7ce07299696e6eed6c7de7e7028df9c&click_sum=6fb7ccf6&ls=r&ref=internal-recs-393772-2&content_source=62c83e9b1f0a0c4b6ad64015461a82bc%253ALT4c3055bbc7ce07299696e6eed6c7de7e7028df9c "Lavender Vegan Soy Wax Candle")




Add to Favorites


- [![Lavender Botanical Aromatherapy Soy Candle, All Natural-100% Essential Oil](https://i.etsystatic.com/25465169/r/il/f7e5cd/2854347551/il_340x270.2854347551_p2kf.jpg)\\
\\
**Lavender Botanical Aromatherapy Soy Candle, All Natural-100% Essential Oil**\\
\\
$32.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/868166558/lavender-botanical-aromatherapy-soy?click_key=62c83e9b1f0a0c4b6ad64015461a82bc%3ALTc97e45439c8ac0589fb934ebeb5c09a8298f57f8&click_sum=815519c0&ls=r&ref=internal-recs-393772-3&sts=1&content_source=62c83e9b1f0a0c4b6ad64015461a82bc%253ALTc97e45439c8ac0589fb934ebeb5c09a8298f57f8 "Lavender Botanical Aromatherapy Soy Candle, All Natural-100% Essential Oil")




Add to Favorites


- [![Lavender Essential Oil Candle, Spring Candle, Scented Candle, Lavender Candle, Gift For Her](https://i.etsystatic.com/17124662/r/il/723553/2393450835/il_340x270.2393450835_rkjj.jpg)\\
\\
**Lavender Essential Oil Candle, Spring Candle, Scented Candle, Lavender Candle, Gift For Her**\\
\\
$10.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/763098357/lavender-essential-oil-candle-spring?click_key=62c83e9b1f0a0c4b6ad64015461a82bc%3ALTcf13ff609acae91310aa4ff569421ee9d42857cf&click_sum=29019d46&ls=r&ref=internal-recs-393772-4&content_source=62c83e9b1f0a0c4b6ad64015461a82bc%253ALTcf13ff609acae91310aa4ff569421ee9d42857cf "Lavender Essential Oil Candle, Spring Candle, Scented Candle, Lavender Candle, Gift For Her")




Add to Favorites


- [![Lavender - 8oz Jar - Herbal Scented - Soy Wax - Natural Scented Candle - Hand Poured - Oriental Candle - Home Decor - Aromatherapy Candle](https://i.etsystatic.com/10311868/r/il/6ba171/5207146826/il_340x270.5207146826_wr19.jpg)\\
\\
**Lavender - 8oz Jar - Herbal Scented - Soy Wax - Natural Scented Candle - Hand Poured - Oriental Candle - Home Decor - Aromatherapy Candle**\\
\\
$16.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/758700889/lavender-8oz-jar-herbal-scented-soy-wax?click_key=62c83e9b1f0a0c4b6ad64015461a82bc%3ALTc48765ca3b8fd58f40c124984e71608ee0b705f5&click_sum=1158270d&ls=r&ref=internal-recs-393772-5&content_source=62c83e9b1f0a0c4b6ad64015461a82bc%253ALTc48765ca3b8fd58f40c124984e71608ee0b705f5 "Lavender - 8oz Jar - Herbal Scented - Soy Wax - Natural Scented Candle - Hand Poured - Oriental Candle - Home Decor - Aromatherapy Candle")




Add to Favorites


- [![Lilac scented candle, lilac candle, floral soy candle, clean burning, spring scented, soy wax candle, lilac scent, fresh scent, housewarming](https://i.etsystatic.com/27686047/r/il/65a05b/5828647851/il_340x270.5828647851_8evc.jpg)\\
\\
**Lilac scented candle, lilac candle, floral soy candle, clean burning, spring scented, soy wax candle, lilac scent, fresh scent, housewarming**\\
\\
$9.50\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1246159037/lilac-scented-candle-lilac-candle-floral?click_key=62c83e9b1f0a0c4b6ad64015461a82bc%3ALT55a1fa916e90f3badb6d7000717b08079a7b259e&click_sum=c9277783&ls=r&ref=internal-recs-393772-6&content_source=62c83e9b1f0a0c4b6ad64015461a82bc%253ALT55a1fa916e90f3badb6d7000717b08079a7b259e "Lilac scented candle, lilac candle, floral soy candle, clean burning, spring scented, soy wax candle, lilac scent, fresh scent, housewarming")




Add to Favorites



[![Lavender Soy Candle: Luxury Hand-Poured Relaxation Spa Gift](https://i.etsystatic.com/44641323/r/il/e02148/7262224267/il_340x270.7262224267_lkjp.jpg)\\
\\
**Lavender Soy Candle: Luxury Hand-Poured Relaxation Spa Gift**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
LukaCandleStudioLLC\\
From shop LukaCandleStudioLLC\\
\\
$39.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4327230947/lavender-soy-candle-luxury-hand-poured?click_key=LTaf5a260ef4493b35ba482a81a7b2bff070ee27cb%3A4327230947&click_sum=6527860e&ls=a&ref=internal-recs-393771-1 "Lavender Soy Candle: Luxury Hand-Poured Relaxation Spa Gift")


Add to Favorites


[![Lavender Sage Soy Candle – Herbal Candle with Lavender & Sage – Scented Soy Wax Candle](https://i.etsystatic.com/14457409/r/il/c4dc71/7069203266/il_340x270.7069203266_amu5.jpg)\\
\\
**Lavender Sage Soy Candle – Herbal Candle with Lavender & Sage – Scented Soy Wax Candle**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
GrandCandlesCo\\
From shop GrandCandlesCo\\
\\
Sale Price $9.71\\
$9.71\\
\\
$12.95\\
Original Price $12.95\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/921930480/lavender-sage-soy-candle-herbal-candle?click_key=LTf47f79bd73689b1b092c6d33c1c8019711c90f1b%3A921930480&click_sum=78256267&ls=a&ref=internal-recs-393771-2&pro=1 "Lavender Sage Soy Candle – Herbal Candle with Lavender & Sage – Scented Soy Wax Candle")


Add to Favorites


[![Floral Candle Set: Surprise Garden Scent, Wedding/luxury gift 4 oz](https://i.etsystatic.com/60270329/r/il/0effb5/7228470154/il_340x270.7228470154_d2af.jpg)\\
\\
**Floral Candle Set: Surprise Garden Scent, Wedding/luxury gift 4 oz**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
PetalandAshcandles\\
From shop PetalandAshcandles\\
\\
$15.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4375374301/floral-candle-set-surprise-garden-scent?click_key=LT295410f051135b7080b7ab82f050b6b88c82b6a3%3A4375374301&click_sum=7212865f&ls=a&ref=internal-recs-393771-3 "Floral Candle Set: Surprise Garden Scent, Wedding/luxury gift 4 oz")


Add to Favorites


[![Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California](https://i.etsystatic.com/13880851/r/il/c201c2/6922345799/il_340x270.6922345799_7e1v.jpg)\\
\\
**Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
HazelCandleCo\\
From shop HazelCandleCo\\
\\
Sale Price $19.50\\
$19.50\\
\\
$26.00\\
Original Price $26.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/493428098/lavender-fields-candle-french-lavender?click_key=LT6f5abefea8cbdaa6ef169102d006c7046cc32d21%3A493428098&click_sum=0f98e184&ls=a&ref=internal-recs-393771-4&pro=1 "Lavender Fields Candle – French Lavender & Citrus – Calming Soy Wax Candle – Spa Gift – Eco Friendly – Handcrafted in California")


Add to Favorites


[![Sage & Lavender Candle: Hand Poured 100% Soy Wax, 9oz](https://i.etsystatic.com/21587017/r/il/f9283e/3195415898/il_340x270.3195415898_ffdp.jpg)\\
\\
**Sage & Lavender Candle: Hand Poured 100% Soy Wax, 9oz**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
SerenityScentCo\\
From shop SerenityScentCo\\
\\
$15.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/805741486/sage-lavender-candle-hand-poured-100-soy?click_key=LT8459194636cb3c3011f34cfcf962f324b34b6b44%3A805741486&click_sum=3f3ae4b9&ls=a&ref=internal-recs-393771-5 "Sage & Lavender Candle: Hand Poured 100% Soy Wax, 9oz")


Add to Favorites


[![Lavender Chamomile Soy Candle: Calming Aromatherapy, Organic Herbs](https://i.etsystatic.com/54181361/r/il/2cce01/6369911483/il_340x270.6369911483_riv4.jpg)\\
\\
**Lavender Chamomile Soy Candle: Calming Aromatherapy, Organic Herbs**\\
\\
ad vertisement by Etsy seller\\
Advertisement from Etsy seller\\
AshCoalCandles\\
From shop AshCoalCandles\\
\\
$17.95\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1790253414/lavender-chamomile-soy-candle-calming?click_key=LTb0d2b792133268a99d1a2d2f012047ab9d52e3d7%3A1790253414&click_sum=e2c04533&ls=a&ref=internal-recs-393771-6&sts=1 "Lavender Chamomile Soy Candle: Calming Aromatherapy, Organic Herbs")


Add to Favorites


GIFTS

Browse by interest for the best gifts!

[Shop now](https://www.etsy.com/gift-mode?ref=listing_suggested_personas_related)

[The \\
\\
Candle Collector \\
\\
![The <br /> Candle Collector](https://i.etsystatic.com/ij/a968b5/5644592699/ij_300x300.5644592699_ccknze5o.jpg?version=0)](https://www.etsy.com/gift-mode/persona/the-candle-collector?ref=listing_suggested_personas_related) [The \\
\\
Wellness Enthusiast \\
\\
![The <br /> Wellness Enthusiast](https://i.etsystatic.com/ij/a370f3/5644306831/ij_300x300.5644306831_6xmfz2ww.jpg?version=0)](https://www.etsy.com/gift-mode/persona/the-wellness-enthusiast?ref=listing_suggested_personas_related) [The \\
\\
Self Care Enthusiast \\
\\
![The <br /> Self Care Enthusiast](https://i.etsystatic.com/ij/d4d017/5598707646/ij_300x300.5598707646_prhkmh0d.jpg?version=0)](https://www.etsy.com/gift-mode/persona/the-self-care-enthusiast?ref=listing_suggested_personas_related) [The \\
\\
New Parent \\
\\
![The <br /> New Parent](https://i.etsystatic.com/ij/14cd2d/5646689747/ij_300x300.5646689747_37qe5dkc.jpg?version=0)](https://www.etsy.com/gift-mode/persona/the-new-parent?ref=listing_suggested_personas_related) [The \\
\\
Zen Seeker \\
\\
![The <br /> Zen Seeker](https://i.etsystatic.com/ij/f6e057/5593289116/ij_300x300.5593289116_ipylhe2q.jpg?version=0)](https://www.etsy.com/gift-mode/persona/the-zen-seeker?ref=listing_suggested_personas_related)

[Shop now](https://www.etsy.com/gift-mode?ref=listing_suggested_personas_related)

## Explore related searches

![](https://i.etsystatic.com/55223649/r/il/086ef2/7344820457/il_75x75.7344820457_jgeh.jpg)

220g Candle


![](https://i.etsystatic.com/35558980/r/il/a45e6c/7241332875/il_75x75.7241332875_9hvj.jpg)

Candles in West Sussex


![](https://i.etsystatic.com/58874401/r/il/3dd6d1/7335016885/il_75x75.7335016885_j1j1.jpg)

Vegan Candle


![](https://i.etsystatic.com/39437375/r/il/c168d3/7087755078/il_75x75.7087755078_oyi8.jpg)

Lavender and Vanilla Candle


![](https://i.etsystatic.com/58356002/r/il/80e7e9/6891616367/il_75x75.6891616367_9gqb.jpg)

60g Candle


![](https://i.etsystatic.com/24692904/r/il/b80394/7097278493/il_75x75.7097278493_b44q.jpg)

Allergy Friendly Candle


![](https://i.etsystatic.com/34894545/r/il/631287/6420703417/il_75x75.6420703417_brdj.jpg)

Heliotrope Candle


![](https://i.etsystatic.com/53087844/r/il/b983b1/7398717847/il_75x75.7398717847_hmet.jpg)

Organic Soy Wax Candles


![](https://i.etsystatic.com/31640941/r/il/b1589e/6935460116/il_75x75.6935460116_iixn.jpg)

Wild Mint Candle


![](https://i.etsystatic.com/24951730/c/2083/2083/916/730/il/d719d4/7318072934/il_75x75.7318072934_nigl.jpg)

Natural Lavender Candle


![](https://i.etsystatic.com/14701240/r/il/36028f/3734243683/il_75x75.3734243683_1w5g.jpg)

Aromatherapy Candle Lavender


![](https://i.etsystatic.com/5827725/c/2594/2061/0/144/il/8cdac1/2823634862/il_75x75.2823634862_hhi2.jpg)

Relax and Unwind Candles


## Explore more related searches

[St.eval Candle](https://www.etsy.com/market/st.eval_candle?ref=lp_queries_internal_bottom-13)

[Calming Scented Candles](https://www.etsy.com/market/calming_scented_candles?ref=lp_queries_internal_bottom-14)

[Natural Aromatherapy Candle](https://www.etsy.com/market/natural_aromatherapy_candle?ref=lp_queries_internal_bottom-15)

[Natural.candles](https://www.etsy.com/market/natural.candles?ref=lp_queries_internal_bottom-16)

[220g Scented Candles](https://www.etsy.com/market/220g_scented_candles?ref=lp_queries_internal_bottom-17)

[Large Sleep Candle](https://www.etsy.com/market/large_sleep_candle?ref=lp_queries_internal_bottom-18)

[Lavender Candle Soy](https://www.etsy.com/market/lavender_candle_soy?ref=lp_queries_internal_bottom-19)

[Candles Honeysuckle](https://www.etsy.com/market/candles_honeysuckle?ref=lp_queries_internal_bottom-20)

[120ml Candle](https://www.etsy.com/market/120ml_candle?ref=lp_queries_internal_bottom-21)

[Duftkerzen](https://www.etsy.com/market/duftkerzen?ref=lp_queries_internal_bottom-22)

[Lavender and Patchouli Candle](https://www.etsy.com/market/lavender_and_patchouli_candle?ref=lp_queries_internal_bottom-23)

Listed on Oct 2, 2025


[One favorite](https://www.etsy.com/listing/1823405290/lavender-lace-scented-luxury/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=148d6183&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=148d6183&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=148d6183&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=148d6183&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=breadcrumb_listing) [Container Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/container-candles?amp%3Bclick_sum=148d6183&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&explicit=1&ref=breadcrumb_listing)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1823405290%2Flavender-lace-scented-luxury%3Famp%253Bclick_sum%3D148d6183%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgyNTM0OTo1MGVhZmI1ZDdmNzRmYmJmODY0Y2E3ZWFjZDMwMmVlYQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1823405290%2Flavender-lace-scented-luxury%3Famp%253Bclick_sum%3D148d6183%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1823405290/lavender-lace-scented-luxury?amp;click_sum=148d6183&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1823405290%2Flavender-lace-scented-luxury%3Famp%253Bclick_sum%3D148d6183%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![Lavender & Lace Scented Luxury Aromatherapy Soy Wax Candle ~ Lavender Essential Oil 10cl image 1](https://i.etsystatic.com/56381837/r/il/3beede/6742360173/il_300x300.6742360173_gm4t.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/copy_6DDF6F6B-8668-4FE3-BE3E-89FB89D7C244_hpbrms.jpg)

- ![Lavender & Lace Scented Luxury Aromatherapy Soy Wax Candle ~ Lavender Essential Oil 10cl image 2](https://i.etsystatic.com/56381837/r/il/641e9d/6742360399/il_300x300.6742360399_humw.jpg)
- ![Lavender & Lace Scented Luxury Aromatherapy Soy Wax Candle ~ Lavender Essential Oil 10cl image 3](https://i.etsystatic.com/56381837/r/il/eba540/6742360557/il_300x300.6742360557_c7yi.jpg)
- ![Lavender & Lace Scented Luxury Aromatherapy Soy Wax Candle ~ Lavender Essential Oil 10cl image 4](https://i.etsystatic.com/56381837/r/il/a52ba4/6694321434/il_300x300.6694321434_id5d.jpg)

## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


Regions Etsy does business in:

[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)

[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)

[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)

[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)

[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)

[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)

[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)

[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)

[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)

[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)

[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)

[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)

[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)

[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)

[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)

[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)

[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)

[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)

[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)

[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)

[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)

[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)

[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)

[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)

[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)

[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)

[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)

Got it

Scroll previousScroll next