[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?amp;click_sum=7c8ec1f8&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3&amp;sts=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?amp%3Bclick_sum=7c8ec1f8&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-0)
- [Mixed Media & Collage](https://www.etsy.com/c/art-and-collectibles/mixed-media-and-collage?amp%3Bclick_sum=7c8ec1f8&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-1)
- [Paint & Canvas](https://www.etsy.com/c/art-and-collectibles/mixed-media-and-collage/paint-and-canvas?amp%3Bclick_sum=7c8ec1f8&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-2)

Bestseller

This item has had a high sales volume over the past 6 months.



Add to Favorites


- ![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios image 1](https://i.etsystatic.com/20866273/r/il/79497b/3277940388/il_794xN.3277940388_dx8e.jpg)
- ![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios image 2](https://i.etsystatic.com/20866273/r/il/d0d85f/3619911717/il_794xN.3619911717_9e0h.jpg)
- ![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios image 3](https://i.etsystatic.com/20866273/r/il/ea2648/3619911787/il_794xN.3619911787_jh0t.jpg)
- ![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios image 4](https://i.etsystatic.com/20866273/r/il/be9a11/3325561301/il_794xN.3325561301_r4bf.jpg)
- ![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios image 5](https://i.etsystatic.com/20866273/r/il/87febc/3277870418/il_794xN.3277870418_qh28.jpg)
- ![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios image 6](https://i.etsystatic.com/20866273/r/il/0ba1f1/3325561491/il_794xN.3325561491_hw8g.jpg)
- ![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios image 7](https://i.etsystatic.com/20866273/r/il/b22ba1/5280369858/il_794xN.5280369858_s9e1.jpg)

- ![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios image 1](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_75x75.3277940388_dx8e.jpg)
- ![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios image 2](https://i.etsystatic.com/20866273/r/il/d0d85f/3619911717/il_75x75.3619911717_9e0h.jpg)
- ![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios image 3](https://i.etsystatic.com/20866273/r/il/ea2648/3619911787/il_75x75.3619911787_jh0t.jpg)
- ![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios image 4](https://i.etsystatic.com/20866273/r/il/be9a11/3325561301/il_75x75.3325561301_r4bf.jpg)
- ![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios image 5](https://i.etsystatic.com/20866273/r/il/87febc/3277870418/il_75x75.3277870418_qh28.jpg)
- ![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios image 6](https://i.etsystatic.com/20866273/r/il/0ba1f1/3325561491/il_75x75.3325561491_hw8g.jpg)
- ![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios image 7](https://i.etsystatic.com/20866273/r/il/b22ba1/5280369858/il_75x75.5280369858_s9e1.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1071241123%2Fbotanical-intaglio-art-on-5x7-or-6x6%23report-overlay-trigger)

In demand. 4 people bought this in the last 24 hours.

Price:$15.00+


Loading


# Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios

[Bungalow1904](https://www.etsy.com/shop/Bungalow1904?ref=shop-header-name&listing_id=1071241123&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?amp;click_sum=7c8ec1f8&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3&amp;sts=1#reviews)

Ships from South Carolina

Returns accepted

Primary color


Select a color

White

Gray

Khaki-Greige

Sea Salt -Light Blue

Navy

N/A - intaglio only

Please select a color


Style


Select an option

Horizontal 5X7" ($45.00)

Vertical 5X7" ($45.00)

6X6" ($45.00)

Intaglio Only w/Gold ($18.00)

Intaglio Only -plain ($15.00)

Please select an option


Add personalization


- Personalization





Please enter the corresponding number for the intaglio design you would like below. Numbers can be found in the photos.


















0/20


Quantity



123456789101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869

4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Item details

### Highlights

Designed by [Bungalow1904](https://www.etsy.com/shop/Bungalow1904)

- Ships from South Carolina! Shorter shipping distances are

kinder to the planet

Ordering items closer to you is more likely to reduce your purchase's carbon footprint.


- Materials: plaster, canvas



- Depth: 1.5 inches

 -Hand poured plaster intaglios are gilded on the edges and mounted on 5X7 or 6X6 inch painted canvas. A modern way to use classic botanicals.

-The extra 1.5" depth of these canvases makes displaying a breeze. Stands unassisted or easily hangs from a nail.

-Fully finished canvas sides and a gilded border make framing optional.

-Intaglio Only option only includes the plaster piece with a choice to add the gold accents seen in the photos - No canvas included.

-I've chosen a selection of easy to use neutrals. Looking for something custom? Send me a message before ordering. I can probably match your Benjamin Moore or Valspar shade for a small custom fee.

Fits Beautifully on a 10" brass faux-bamboo easel (not included;smaller sizes not suitable):

[https://www.etsy.com/listing/937712931](https://www.etsy.com/listing/937712931)

To browse other original art and chinoiserie inspired home decor:

[https://www.etsy.com/shop/Bungalow1904](https://www.etsy.com/shop/Bungalow1904)

--Background and Inspiration--

For the wealthy of the 17th - 19th centuries, embarking on a "Grand Tour" of major European destinations and cultural sites was considered a rite of passage for the well-educated. These tours lasted for months or even years and, in a time when taking photos wasn't an option, plaster intaglios made popular souvenirs. The lightweight medallions were made by local artisans to sell to tourists and would depict portraiture, renowned architecture, and Greek and Roman mythology. Once home, travelers mounted the intaglios collected on their tour in a scrapbook or frame to remember (and show off!) their amazing travels.

With Bungalow 1904's intaglios, I aim to blend the materials and aesthetic of those original plaster reliefs with designs that reflect my own personal taste. Art that is Classic + Fresh, Elegant + Fun, every piece represents a modern artisan drawing inspiration from the timeless work of craftsmen that lived hundreds of years ago.

I create these imaginative intaglios by using a mix of modern & vintage objects and materials to create molds, hand pour each casting and carefully finish each medallion. Intaglios are then mounted onto painted and gilded canvas and the completed work is signed on the back.

If you would like to inquire about customization or carrying my work in your retail venue, please feel free to message me.

--Details--

This listing is for one piece of mixed media art, measuring either 5X7" or 6X6" and 1.5" deep. Easel is not included.

Please note that the artwork in the photographs may not be the exact piece you will recieve and some minor differences are to be expected. Colors may appear differently on your monitor or device than the piece in person. Photographs are watermarked - no logos or text will be on the finished piece.

All images, designs, and creations are Copyright Bungalow 1904. All rights reserved. Any attempt to copy, reproduce, distribute, or sell my artwork and designs, copy my text or use my photographs in any way will result in copyright infringement and I will report.


## Shipping and return policies

Loading


- Order today to get by

**Nov 18-Dec 1**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 14 days


- Ships from: **Inman, SC**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## Reviews for this item (126)

5.0/5

item average

5.0Item quality

4.9Shipping

4.9Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Beautiful

Great quality

Love it

Fast shipping

As described

Gift-worthy

Very pretty


Filter by category


Quality (46)


Appearance (34)


Shipping & Packaging (21)


Description accuracy (14)


Seller service (11)


Ease of use (3)


Value (3)


Sizing & Fit (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

4 out of 5 stars
4

This item

[tvq8bfpk](https://www.etsy.com/people/tvq8bfpk?ref=l_review)
Nov 5, 2025


Pretty. Lily of Valley floral detail very nice.



[tvq8bfpk](https://www.etsy.com/people/tvq8bfpk?ref=l_review)
Nov 5, 2025


5 out of 5 stars
5

This item

[Lucretia](https://www.etsy.com/people/brjtvb71?ref=l_review)
Oct 28, 2025


It came as described and worked beautifully in the art project I had planned ed for it.



[Lucretia](https://www.etsy.com/people/brjtvb71?ref=l_review)
Oct 28, 2025


5 out of 5 stars
5

This item

[Lucretia](https://www.etsy.com/people/brjtvb71?ref=l_review)
Oct 28, 2025


It came as described and worked beautifully in the art project I had planned ed for it.



[Lucretia](https://www.etsy.com/people/brjtvb71?ref=l_review)
Oct 28, 2025


5 out of 5 stars
5

This item

[Lucretia](https://www.etsy.com/people/brjtvb71?ref=l_review)
Oct 28, 2025


It was just as described and worked beautifully in an art project .



[Lucretia](https://www.etsy.com/people/brjtvb71?ref=l_review)
Oct 28, 2025


View all reviews for this item

### Photos from reviews

![Tiffany added a photo of their purchase](https://i.etsystatic.com/iap/d8c798/7206680299/iap_300x300.7206680299_99b15xzx.jpg?version=0)

![Shelley added a photo of their purchase](https://i.etsystatic.com/iap/9ec7f9/6933337080/iap_300x300.6933337080_eugh0bw6.jpg?version=0)

![liindsgreen added a photo of their purchase](https://i.etsystatic.com/iap/84c360/7318766725/iap_300x300.7318766725_2w4btcfw.jpg?version=0)

![Aprile added a photo of their purchase](https://i.etsystatic.com/iap/1715e0/7043003027/iap_300x300.7043003027_j6vb9vlo.jpg?version=0)

![Elisabeth added a photo of their purchase](https://i.etsystatic.com/iap/551df1/6738534288/iap_300x300.6738534288_azbhyqgv.jpg?version=0)

![BEth added a photo of their purchase](https://i.etsystatic.com/iap/656ca2/6696193249/iap_300x300.6696193249_4vqzk8wh.jpg?version=0)

![HumbledbyHome added a photo of their purchase](https://i.etsystatic.com/iap/040a60/6840388055/iap_300x300.6840388055_lyf27a6h.jpg?version=0)

![Emily added a photo of their purchase](https://i.etsystatic.com/iap/71eee7/5908149740/iap_300x300.5908149740_1q4d1z6c.jpg?version=0)

![nyc2308 added a photo of their purchase](https://i.etsystatic.com/iap/f76e6a/4843999911/iap_300x300.4843999911_c4i0g69v.jpg?version=0)

![Amanda added a photo of their purchase](https://i.etsystatic.com/iap/f7cf02/5168761685/iap_300x300.5168761685_j9l14sbi.jpg?version=0)

![Caroline added a photo of their purchase](https://i.etsystatic.com/iap/3e947f/4440392371/iap_300x300.4440392371_dq1cd6a8.jpg?version=0)

![Carly added a photo of their purchase](https://i.etsystatic.com/iap/b483ba/4753986125/iap_300x300.4753986125_d1jvrfrh.jpg?version=0)

![Sarah added a photo of their purchase](https://i.etsystatic.com/iap/2a98fd/4069092429/iap_300x300.4069092429_a352eszv.jpg?version=0)

![alison added a photo of their purchase](https://i.etsystatic.com/iap/e39113/3628214262/iap_300x300.3628214262_ho1x6dqp.jpg?version=0)

![Lynne added a photo of their purchase](https://i.etsystatic.com/iap/a1e2df/3606736744/iap_300x300.3606736744_qhsu19br.jpg?version=0)

![alison added a photo of their purchase](https://i.etsystatic.com/iap/10fb0e/3448251763/iap_300x300.3448251763_qijd9xpi.jpg?version=0)

[![Bungalow1904](https://i.etsystatic.com/iusa/ae5355/68102880/iusa_75x75.68102880_pq6r.jpg?version=0)](https://www.etsy.com/shop/Bungalow1904?ref=shop_profile&listing_id=1071241123)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[Bungalow1904](https://www.etsy.com/shop/Bungalow1904?ref=shop_profile&listing_id=1071241123)

[Owned by Sasha](https://www.etsy.com/shop/Bungalow1904?ref=shop_profile&listing_id=1071241123) \|

Inman, South Carolina

5.0
(672)


3.9k sales

6 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=227979184&referring_id=1071241123&referring_type=listing&recipient_id=227979184&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyMjc5NzkxODQ6MTc2MjgxMDIxMjozYThiYjM3YjQyZDU2MmUyNDBjNWMyOGExM2M1Y2IwMg%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1071241123%2Fbotanical-intaglio-art-on-5x7-or-6x6%3Famp%253Bclick_sum%3D7c8ec1f8%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bsts%3D1)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/Bungalow1904?ref=lp_mys_mfts)

- [![Coastal Intaglio Art on 6X6 or 5X7 Canvas, Coral, Shells or Sand Dollar plaster medallions on blue or neutral paintings for beach home decor](https://i.etsystatic.com/20866273/r/il/bb6324/3110428468/il_340x270.3110428468_ilpb.jpg)\\
\\
**Coastal Intaglio Art on 6X6 or 5X7 Canvas, Coral, Shells or Sand Dollar plaster medallions on blue or neutral paintings for beach home decor**\\
\\
$15.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1026208727/coastal-intaglio-art-on-6x6-or-5x7?click_key=1558f43f6555d23a2f12d40be1b37eaf%3ALT1bd676cc1e2d0b5e54dd2969b69dec9a3143388b&click_sum=5ac5f212&ls=r&ref=related-1&sts=1&content_source=1558f43f6555d23a2f12d40be1b37eaf%253ALT1bd676cc1e2d0b5e54dd2969b69dec9a3143388b "Coastal Intaglio Art on 6X6 or 5X7 Canvas, Coral, Shells or Sand Dollar plaster medallions on blue or neutral paintings for beach home decor")




Add to Favorites


- [![Modern Insects Intaglio Art, Plaster medallions on canvas, botanical art, scarab, grasshopper, bee, dragonfly, cicada, butterfly, spider](https://i.etsystatic.com/20866273/r/il/00bb52/3152931378/il_340x270.3152931378_apxc.jpg)\\
\\
**Modern Insects Intaglio Art, Plaster medallions on canvas, botanical art, scarab, grasshopper, bee, dragonfly, cicada, butterfly, spider**\\
\\
$45.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1025124951/modern-insects-intaglio-art-plaster?click_key=1558f43f6555d23a2f12d40be1b37eaf%3ALT72f3423bf8413f234af972fdcfce34bb3b2c4e94&click_sum=efae47e7&ls=r&ref=related-2&sts=1&content_source=1558f43f6555d23a2f12d40be1b37eaf%253ALT72f3423bf8413f234af972fdcfce34bb3b2c4e94 "Modern Insects Intaglio Art, Plaster medallions on canvas, botanical art, scarab, grasshopper, bee, dragonfly, cicada, butterfly, spider")




Add to Favorites


- [![Chinoiserie pagoda plaster Intaglio art on 5X7 or 6x6 extra deep canvas, mixed media wall hangings and bookshelf styling](https://i.etsystatic.com/20866273/c/2702/2148/138/254/il/43d2db/3157321813/il_340x270.3157321813_tnit.jpg)\\
\\
**Chinoiserie pagoda plaster Intaglio art on 5X7 or 6x6 extra deep canvas, mixed media wall hangings and bookshelf styling**\\
\\
$15.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1003466916/chinoiserie-pagoda-plaster-intaglio-art?click_key=1558f43f6555d23a2f12d40be1b37eaf%3ALT151f1849797fc290750e4a3b58fa1b2bdda8b3cb&click_sum=d70f8f4d&ls=r&ref=related-3&sts=1&content_source=1558f43f6555d23a2f12d40be1b37eaf%253ALT151f1849797fc290750e4a3b58fa1b2bdda8b3cb "Chinoiserie pagoda plaster Intaglio art on 5X7 or 6x6 extra deep canvas, mixed media wall hangings and bookshelf styling")




Add to Favorites


- [![Ceramic Magnolia Flower Hanging Ornament, Mississippi and Louisiana State Flower](https://i.etsystatic.com/20866273/c/3000/2384/0/89/il/64431c/3954620396/il_340x270.3954620396_e05t.jpg)\\
\\
**Ceramic Magnolia Flower Hanging Ornament, Mississippi and Louisiana State Flower**\\
\\
$55.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1240298838/ceramic-magnolia-flower-hanging-ornament?click_key=35aae1af89333a980115ebcbbe80f459497fd1f0%3A1240298838&click_sum=ddbc24ef&ref=related-4&sts=1 "Ceramic Magnolia Flower Hanging Ornament, Mississippi and Louisiana State Flower")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 10, 2025


[3486 favorites](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?amp%3Bclick_sum=7c8ec1f8&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Mixed Media & Collage](https://www.etsy.com/c/art-and-collectibles/mixed-media-and-collage?amp%3Bclick_sum=7c8ec1f8&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Paint & Canvas](https://www.etsy.com/c/art-and-collectibles/mixed-media-and-collage/paint-and-canvas?amp%3Bclick_sum=7c8ec1f8&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Gender Neutral Adult Clothing

[Dare Hoodie - US](https://www.etsy.com/market/dare_hoodie) [Buy Squirt Es4 Online](https://www.etsy.com/market/squirt_es4)

Patches & Pins

[Musashi Inspired Manga Enamel Pin by AviianStudios](https://www.etsy.com/listing/1420205660/vgb-invincible-under-the-sun-unrivaled)

Womens Clothing

[White Fuzzy Sweater - US](https://www.etsy.com/market/white_fuzzy_sweater) [Nepal Clothing Women for Sale](https://www.etsy.com/market/nepal_clothing_women)

Bathroom

[Wooden Tub for Sale](https://www.etsy.com/market/wooden_tub)

Home Decor

[No Junk Mail Sign - US](https://www.etsy.com/market/no_junk_mail_sign) [Rustic Mantel Decor - US](https://www.etsy.com/market/rustic_mantel_decor)

Furniture

[Effezeta Chairs for Sale](https://www.etsy.com/market/effezeta_chairs)

Collectibles

[Super Conductor Coin - US](https://www.etsy.com/market/super_conductor_coin) [Glass Egg Candy Dish for Sale](https://www.etsy.com/market/glass_egg_candy_dish)

Canvas & Surfaces

[Buy Pumpkin Rub On Transfer Online](https://www.etsy.com/market/pumpkin_rub_on_transfer)

Kitchen & Dining

[Hb Glass - US](https://www.etsy.com/market/hb_glass)

Necklaces

[Shop Necklaces from MirayaDesignZ](https://www.etsy.com/shop/MirayaDesignZ)

Party Supplies

[Buy Barrel Of Monkey Cutouts Online](https://www.etsy.com/market/barrel_of_monkey_cutouts)

Drawing & Illustration

[Cabana Home Plans - US](https://www.etsy.com/market/cabana_home_plans)

Paper

[Dungeons And Dragons Pregnancy Announcement for Sale](https://www.etsy.com/market/dungeons_and_dragons_pregnancy_announcement)

Toys

[Buy Botox Stress Ball Online](https://www.etsy.com/market/botox_stress_ball)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1071241123%2Fbotanical-intaglio-art-on-5x7-or-6x6%3Famp%253Bclick_sum%3D7c8ec1f8%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bsts%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgxMDIxMjpiMjdiNjRjODkyYzQ4NWI5YTc3M2QwYjQ0NDExYmU5Mw==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1071241123%2Fbotanical-intaglio-art-on-5x7-or-6x6%3Famp%253Bclick_sum%3D7c8ec1f8%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bsts%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?amp;click_sum=7c8ec1f8&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3&amp;sts=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1071241123%2Fbotanical-intaglio-art-on-5x7-or-6x6%3Famp%253Bclick_sum%3D7c8ec1f8%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bsts%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for Bungalow1904

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 12 hours of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios image 1](https://i.etsystatic.com/20866273/c/3000/3000/0/0/il/79497b/3277940388/il_300x300.3277940388_dx8e.jpg)
- ![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios image 2](https://i.etsystatic.com/20866273/r/il/d0d85f/3619911717/il_300x300.3619911717_9e0h.jpg)
- ![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios image 3](https://i.etsystatic.com/20866273/r/il/ea2648/3619911787/il_300x300.3619911787_jh0t.jpg)
- ![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios image 4](https://i.etsystatic.com/20866273/r/il/be9a11/3325561301/il_300x300.3325561301_r4bf.jpg)
- ![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios image 5](https://i.etsystatic.com/20866273/r/il/87febc/3277870418/il_300x300.3277870418_qh28.jpg)
- ![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios image 6](https://i.etsystatic.com/20866273/r/il/0ba1f1/3325561491/il_300x300.3325561491_hw8g.jpg)
- ![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios image 7](https://i.etsystatic.com/20866273/r/il/b22ba1/5280369858/il_300x300.5280369858_s9e1.jpg)

- ![](https://i.etsystatic.com/iap/d8c798/7206680299/iap_640x640.7206680299_99b15xzx.jpg?version=0)

5 out of 5 stars

- Color:

N/A - intaglio only

- Style:

Intaglio Only w/Gold


Love these intaglios! These came out perfect!

Aug 31, 2025


[Tiffany Hebert](https://www.etsy.com/people/tiffanyhebert26)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/9ec7f9/6933337080/iap_640x640.6933337080_eugh0bw6.jpg?version=0)

5 out of 5 stars

- Color:

Sea Salt -Light Blue

- Style:

6X6"


Beautiful!! Exactly as I pictured it.

Jun 11, 2025


[Shelley Brown](https://www.etsy.com/people/shelleybrown22)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/84c360/7318766725/iap_640x640.7318766725_2w4btcfw.jpg?version=0)

5 out of 5 stars

- Color:

N/A - intaglio only

- Style:

Intaglio Only w/Gold


My daughters nursery theme is vintage floral (hydrangeas). I was looking for artwork to hang that wouldn’t clash with the hydrangea print wallpaper. These work perfectly and came in as described. I got two of the hydrangea with gold then put them in this frame from Michael’s with my own cardstock. Would buy this again. The product came a day later than originally quoted so that’s the reason for 4 star shipping. They were packed with care though.

![](https://i.etsystatic.com/iusa/fa13d9/35251269/iusa_75x75.35251269_77rb.jpg?version=0)

Oct 9, 2025


[liindsgreen](https://www.etsy.com/people/liindsgreen)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/1715e0/7043003027/iap_640x640.7043003027_j6vb9vlo.jpg?version=0)

5 out of 5 stars

- Color:

N/A - intaglio only

- Style:

Intaglio Only w/Gold


Beautiful intaglio. Really nice size. Great relief. Very happy.

Jul 5, 2025


[Aprile Wisner](https://www.etsy.com/people/aprile77)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/551df1/6738534288/iap_640x640.6738534288_azbhyqgv.jpg?version=0)

5 out of 5 stars

- Color:

White

- Style:

Intaglio Only w/Gold


These are beautiful intaglios! I used them in my baby girl’s nursery and they completed the look perfectly.

Mar 23, 2025


[Elisabeth Hankins](https://www.etsy.com/people/echankins)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/656ca2/6696193249/iap_640x640.6696193249_4vqzk8wh.jpg?version=0)

5 out of 5 stars

- Color:

Sea Salt -Light Blue

- Style:

6X6"


Artist was very helpful and shipping very timely

Feb 15, 2025


[BEth Ann Rosenebrg](https://www.etsy.com/people/bainroswell)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/040a60/6840388055/iap_640x640.6840388055_lyf27a6h.jpg?version=0)

5 out of 5 stars

- Color:

N/A - intaglio only

- Style:

Intaglio Only -plain


I ordered the intaglio without gold edging to create my own canvas for our entryway. I love it and have shared it on Instagram @mymodernmanor. 10/10!

![](https://i.etsystatic.com/iusa/ad2607/77903739/iusa_75x75.77903739_novd.jpg?version=0)

Apr 14, 2025


[HumbledbyHome](https://www.etsy.com/people/HumbledbyHome)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/71eee7/5908149740/iap_640x640.5908149740_1q4d1z6c.jpg?version=0)

5 out of 5 stars

- Color:

N/A - intaglio only

- Style:

Intaglio Only -plain


I wanted to try and DIY my own intaglio art for my home. The pendants are so beautiful!

![](https://i.etsystatic.com/iusa/a4c498/114288687/iusa_75x75.114288687_2n88.jpg?version=0)

Apr 9, 2024


[Emily Meador](https://www.etsy.com/people/emilykerrick)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/f76e6a/4843999911/iap_640x640.4843999911_c4i0g69v.jpg?version=0)

5 out of 5 stars

- Size:

6X6 inches

- Color:

Sea Salt -Light Blue


Absolutely stunning! I have purchased multiple times and am always love my items!

Apr 6, 2023


[nyc2308](https://www.etsy.com/people/nyc2308)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/f7cf02/5168761685/iap_640x640.5168761685_j9l14sbi.jpg?version=0)

5 out of 5 stars

- Size:

6X6 inches

- Color:

White


Absolutely Beautiful. I love them.

Jul 24, 2023


[Amanda Ramey](https://www.etsy.com/people/abramey3)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/3e947f/4440392371/iap_640x640.4440392371_dq1cd6a8.jpg?version=0)

5 out of 5 stars

- Size:

6X6 inches

- Color:

Sea Salt -Light Blue


I bought the hydrangea intaglios for my bridesmaids gifts and kept one for myself. The arrival time was as expected and I’m very happy with my purchase!

Nov 29, 2022


[Caroline Chapman](https://www.etsy.com/people/carochap)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/b483ba/4753986125/iap_640x640.4753986125_d1jvrfrh.jpg?version=0)

5 out of 5 stars

- Size:

6X6 inches

- Color:

Sea Salt -Light Blue


![](https://i.etsystatic.com/iusa/4d46e8/100209153/iusa_75x75.100209153_k9ob.jpg?version=0)

Mar 9, 2023


[Carly Bledsoe](https://www.etsy.com/people/carlyfisher1)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/2a98fd/4069092429/iap_640x640.4069092429_a352eszv.jpg?version=0)

5 out of 5 stars

- Size:

6X6 inches

- Color:

Sea Salt -Light Blue


I cannot begin to describe the beautiful and elegance of my new botanical intaglio art. I've hung them in my foyer where they look perfect (so perfect I need to order two more!). I've sent pics to my friends and they are now ordering as well. Thanks, Bungalow 104, for your lovely work, careful packaging and swift delivery!

Jul 19, 2022


[Sarah Elliott](https://www.etsy.com/people/sarahmarshallelliot)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/e39113/3628214262/iap_640x640.3628214262_ho1x6dqp.jpg?version=0)

5 out of 5 stars

- Size:

6X6 inches

- Color:

Sea Salt -Light Blue


Quick shipping and high quality piece!

Jan 27, 2022


[alison](https://www.etsy.com/people/tdlwjuju)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/a1e2df/3606736744/iap_640x640.3606736744_qhsu19br.jpg?version=0)

5 out of 5 stars

- Size:

6X6 inches

- Color:

White


I love, love, love these! I wanted the look of intaglios but needed something floral for the space....these are a perfect combination! Shipping was fast too! Will definitely order more in the future! Thank you!

Jan 18, 2022


[Lynne Bischof](https://www.etsy.com/people/lynnebischof)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/10fb0e/3448251763/iap_640x640.3448251763_qijd9xpi.jpg?version=0)

5 out of 5 stars

- Size:

6X6 inches

- Color:

White


Oct 16, 2021


[alison](https://www.etsy.com/people/tdlwjuju)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)

Purchased item:

[![Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios](https://i.etsystatic.com/20866273/c/3000/2384/0/76/il/79497b/3277940388/il_170x135.3277940388_dx8e.jpg)\\
\\
Botanical Intaglio Art on 5X7 or 6X6 Canvas, Plaster medallions of Magnolia hydrangea orchid lotus flower, Modern Grand Tour Intaglios\\
\\
$15.00](https://www.etsy.com/listing/1071241123/botanical-intaglio-art-on-5x7-or-6x6?ref=ap-listing)