[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?amp;click_sum=af51e5c9&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;sts=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Jewelry](https://www.etsy.com/c/jewelry?amp%3Bclick_sum=af51e5c9&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-0)
- [Earrings](https://www.etsy.com/c/jewelry/earrings?amp%3Bclick_sum=af51e5c9&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-1)
- [Threader Earrings](https://www.etsy.com/c/jewelry/earrings/threader-earrings?amp%3Bclick_sum=af51e5c9&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-2)

Bestseller

This item has had a high sales volume over the past 6 months.



Add to Favorites


- ![May include: Close-up view of three pairs of small, hammered metal hoop earrings displayed on a white ceramic dish. Each pair is shown in a different metallic color: silver, rose gold, and gold. The earrings have a simple, minimalist design, with a slightly irregular, hammered texture.  The hoops are open at the top, and appear to be crafted from a thin gauge of metal. The image showcases the subtle variations in color and texture of the earrings.](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_794xN.5072824089_7or0.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver image 2](https://i.etsystatic.com/9687561/r/il/80239f/6710176743/il_794xN.6710176743_e6bx.jpg)
- ![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver image 3](https://i.etsystatic.com/9687561/r/il/cefbc7/7289158525/il_794xN.7289158525_eqh0.jpg)
- ![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver image 4](https://i.etsystatic.com/9687561/r/il/e06b68/7241118740/il_794xN.7241118740_bvsi.jpg)
- ![May include: Close-up view of an assortment of small, minimalist hoop earrings displayed on a white square dish. The hoops are in silver, rose gold, and gold finishes, showcasing a variety of metallic hues. Each earring features a simple, half-circle design, crafted with delicate, thin metal. The earrings are small and understated, ideal for everyday wear or as subtle accents.](https://i.etsystatic.com/9687561/r/il/985f16/5024601756/il_794xN.5024601756_1rdi.jpg)
- ![May include: A pair of minimalist hammered sterling silver hoop earrings.  These small, simple earrings feature a slightly textured, curved, open-hoop design. The hoops are crafted from smooth, polished silver metal, giving them a subtle, elegant look.  These delicate earrings are perfect for everyday wear or special occasions. The earrings are shown on a white background.](https://i.etsystatic.com/9687561/r/il/e63552/5477601514/il_794xN.5477601514_s4qz.jpg)
- ![May include: A pair of gold hammered open hoop earrings.  These minimalist earrings have a simple, slightly irregular, curved shape. The hoops are crafted from 14k gold and feature a textured, hammered finish. The earrings are shown against a plain white background.](https://i.etsystatic.com/9687561/r/il/ef0e07/5525708029/il_794xN.5525708029_ec7l.jpg)
- ![May include: Rose gold hammered open half-circle earrings. These minimalist earrings have a simple, modern design.  The smooth, slightly textured metal creates a subtle, elegant look. The earrings are shown on a white background.](https://i.etsystatic.com/9687561/r/il/ae5493/5525549131/il_794xN.5525549131_for1.jpg)
- ![May include: Close-up view of two hammered silver ear cuffs. One cuff is shown closed, the other open.  The text 'Closed' appears above the closed cuff and 'Open' above the open cuff. Both cuffs have a simple, curved design.  These minimalist silver ear cuffs are ideal for everyday wear.](https://i.etsystatic.com/9687561/r/il/5d964d/6092643061/il_794xN.6092643061_qdi8.jpg)
- ![May include: Close-up view of gold half hoop earrings displayed in a silver tin with a mandala design on the lid.  The earrings are presented on a gray card with the logo 'Laura B Elements.'  Accompanying cards provide care instructions and details about the handcrafted jewelry, emphasizing its unique and lasting quality. The text on the cards includes 'Laura B Elements,' 'Care,' and 'Love.' ](https://i.etsystatic.com/9687561/r/il/7bf5d3/5226418660/il_794xN.5226418660_6ntc.jpg)

- ![May include: Close-up view of three pairs of small, hammered metal hoop earrings displayed on a white ceramic dish. Each pair is shown in a different metallic color: silver, rose gold, and gold. The earrings have a simple, minimalist design, with a slightly irregular, hammered texture.  The hoops are open at the top, and appear to be crafted from a thin gauge of metal. The image showcases the subtle variations in color and texture of the earrings.](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_75x75.5072824089_7or0.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/file_nklqjm.jpg)

- ![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver image 2](https://i.etsystatic.com/9687561/r/il/80239f/6710176743/il_75x75.6710176743_e6bx.jpg)
- ![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver image 3](https://i.etsystatic.com/9687561/r/il/cefbc7/7289158525/il_75x75.7289158525_eqh0.jpg)
- ![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver image 4](https://i.etsystatic.com/9687561/r/il/e06b68/7241118740/il_75x75.7241118740_bvsi.jpg)
- ![May include: Close-up view of an assortment of small, minimalist hoop earrings displayed on a white square dish. The hoops are in silver, rose gold, and gold finishes, showcasing a variety of metallic hues. Each earring features a simple, half-circle design, crafted with delicate, thin metal. The earrings are small and understated, ideal for everyday wear or as subtle accents.](https://i.etsystatic.com/9687561/r/il/985f16/5024601756/il_75x75.5024601756_1rdi.jpg)
- ![May include: A pair of minimalist hammered sterling silver hoop earrings.  These small, simple earrings feature a slightly textured, curved, open-hoop design. The hoops are crafted from smooth, polished silver metal, giving them a subtle, elegant look.  These delicate earrings are perfect for everyday wear or special occasions. The earrings are shown on a white background.](https://i.etsystatic.com/9687561/r/il/e63552/5477601514/il_75x75.5477601514_s4qz.jpg)
- ![May include: A pair of gold hammered open hoop earrings.  These minimalist earrings have a simple, slightly irregular, curved shape. The hoops are crafted from 14k gold and feature a textured, hammered finish. The earrings are shown against a plain white background.](https://i.etsystatic.com/9687561/r/il/ef0e07/5525708029/il_75x75.5525708029_ec7l.jpg)
- ![May include: Rose gold hammered open half-circle earrings. These minimalist earrings have a simple, modern design.  The smooth, slightly textured metal creates a subtle, elegant look. The earrings are shown on a white background.](https://i.etsystatic.com/9687561/r/il/ae5493/5525549131/il_75x75.5525549131_for1.jpg)
- ![May include: Close-up view of two hammered silver ear cuffs. One cuff is shown closed, the other open.  The text 'Closed' appears above the closed cuff and 'Open' above the open cuff. Both cuffs have a simple, curved design.  These minimalist silver ear cuffs are ideal for everyday wear.](https://i.etsystatic.com/9687561/r/il/5d964d/6092643061/il_75x75.6092643061_qdi8.jpg)
- ![May include: Close-up view of gold half hoop earrings displayed in a silver tin with a mandala design on the lid.  The earrings are presented on a gray card with the logo 'Laura B Elements.'  Accompanying cards provide care instructions and details about the handcrafted jewelry, emphasizing its unique and lasting quality. The text on the cards includes 'Laura B Elements,' 'Care,' and 'Love.' ](https://i.etsystatic.com/9687561/r/il/7bf5d3/5226418660/il_75x75.5226418660_6ntc.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1036210721%2Ftiny-d-sleeper-earrings-10mm-or-12mm-ear%23report-overlay-trigger)

In 20+ carts

Price:$14.00+


Loading


# Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver

[LauraBElements](https://www.etsy.com/shop/LauraBElements?ref=shop-header-name&listing_id=1036210721&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?amp;click_sum=af51e5c9&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;sts=1#reviews)

Arrives soon! Get it by

Nov 14-17


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

Material


Select an option

Argentium Silver

14k Gold filled

14k Rose gold filled

Please select an option


Style


Select an option

10mm pair ($28.00)

10mm Left ($14.00)

10mm Right ($14.00)

12mm Pair ($28.00)

12mm Left ($14.00)

12mm Right ($14.00)

Please select an option


Quantity



123456789101112131415161718192021222324252627282930313233343536

You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Buy together, get free shipping

## Buy together, get free shipping

Add both to cart



Loading


[See more items](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?amp;click_sum=af51e5c9&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;sts=1#recs_ribbon_container)

![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_340x270.5072824089_7or0.jpg)
This listing

### Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver

$14.00


Add to Favorites


[![Tiny D Open Hoops: 10mm or 12mm Ear Hugging Half Circle Backless Sleeper Earrings, Handcrafted in 14k Gold Fill, and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/a974a2/6668512587/il_340x270.6668512587_rbru.jpg)\\
\\
**Tiny D Open Hoops: 10mm or 12mm Ear Hugging Half Circle Backless Sleeper Earrings, Handcrafted in 14k Gold Fill, and Argentium 940 Silver**\\
\\
$28.00](https://www.etsy.com/listing/1869345833/tiny-d-open-hoops-10mm-or-12mm-ear?click_key=36e982f29ea15eb855a6c51106fc34c3%3ALT086def4ef4582566b7c24fa5a0a1739331b28623&click_sum=cd8f7dd8&ls=r&ref=listing-free-shipping-bundle-1&sts=1&content_source=36e982f29ea15eb855a6c51106fc34c3%253ALT086def4ef4582566b7c24fa5a0a1739331b28623 "Tiny D Open Hoops: 10mm or 12mm Ear Hugging Half Circle Backless Sleeper Earrings, Handcrafted in 14k Gold Fill, and Argentium 940 Silver")


Add to Favorites


![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_340x270.5072824089_7or0.jpg)
This listing

### Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver

$14.00


Add to Favorites


[![Tiny D Open Hoops: 10mm or 12mm Ear Hugging Half Circle Backless Sleeper Earrings, Handcrafted in 14k Gold Fill, and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/a974a2/6668512587/il_340x270.6668512587_rbru.jpg)\\
\\
**Tiny D Open Hoops: 10mm or 12mm Ear Hugging Half Circle Backless Sleeper Earrings, Handcrafted in 14k Gold Fill, and Argentium 940 Silver**\\
\\
$28.00](https://www.etsy.com/listing/1869345833/tiny-d-open-hoops-10mm-or-12mm-ear?click_key=36e982f29ea15eb855a6c51106fc34c3%3ALT086def4ef4582566b7c24fa5a0a1739331b28623&click_sum=cd8f7dd8&ls=r&ref=listing-free-shipping-bundle-1&sts=1&content_source=36e982f29ea15eb855a6c51106fc34c3%253ALT086def4ef4582566b7c24fa5a0a1739331b28623 "Tiny D Open Hoops: 10mm or 12mm Ear Hugging Half Circle Backless Sleeper Earrings, Handcrafted in 14k Gold Fill, and Argentium 940 Silver")


Add to Favorites


![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_340x270.5072824089_7or0.jpg)
This listing

### Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver

$14.00


Add to Favorites


[![Tiny D Open Hoops: 10mm or 12mm Ear Hugging Half Circle Backless Sleeper Earrings, Handcrafted in 14k Gold Fill, and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/a974a2/6668512587/il_340x270.6668512587_rbru.jpg)\\
\\
**Tiny D Open Hoops: 10mm or 12mm Ear Hugging Half Circle Backless Sleeper Earrings, Handcrafted in 14k Gold Fill, and Argentium 940 Silver**\\
\\
$28.00](https://www.etsy.com/listing/1869345833/tiny-d-open-hoops-10mm-or-12mm-ear?click_key=36e982f29ea15eb855a6c51106fc34c3%3ALT086def4ef4582566b7c24fa5a0a1739331b28623&click_sum=cd8f7dd8&ls=r&ref=listing-free-shipping-bundle-1&sts=1&content_source=36e982f29ea15eb855a6c51106fc34c3%253ALT086def4ef4582566b7c24fa5a0a1739331b28623 "Tiny D Open Hoops: 10mm or 12mm Ear Hugging Half Circle Backless Sleeper Earrings, Handcrafted in 14k Gold Fill, and Argentium 940 Silver")


Add to Favorites


## Item details

### Highlights

Made by [LauraBElements](https://www.etsy.com/shop/LauraBElements)

- Materials: Rose gold, Silver, Yellow gold

- Sustainable features: recycled metal. Items may include additional materials or use methods that aren't considered sustainable features on our site. [Learn more](https://help.etsy.com/hc/articles/15532793357847)

- Location: Earlobe

- Closure: Threader

- Style: Minimalist

- Length: 1/2 Inches


- Made to Order


Little half circle D shaped ear hugging hoops hammered down one side and thread through the earlobe. Backless everyday live in 24/7 style earrings, comfortable enough to sleep in. Adjustable by squeezing the ends together for a snug fit. Hand formed from 19 gauge wire, slightly thicker than traditional ear wires. This gives you a little bolder look and helps to keep their form while inserting and removing. Modern minimalist capsule wardrobe must-have. Two sizes to choose from for multiple piercings you can make a fun ear stack.

Choose from 1/2" (12mm) standard, or 3/8" (10mm) for second piercing or small, thin, low pierced earlobes for a snugger look. Shown in the 1/2" on video. Picture with two on are both sizes with the 3/8" in the top piercing.

14k gold or rose gold filled, or Argentium silver (935 non-tarnishing silver) making these a great option for sensitive skin. Hypoallergenic and nickle free. \*shop other sizes with my shop link below.

Comes wrapped in a hand stamped metal tin ready for gift giving and storing in when not being worn. Complete with polishing cloth and instructions on how to care for your new jewelry.

SHOP MY COLLECTION

[https://laurabelements.etsy.com](https://laurabelements.etsy.com/)

I use 100% USA SOURCED RECYCLED METALS

Each piece is handmade so there may be slight variations in size, texture, and detail making it uniquely yours. You will always receive a carefully crafted piece of jewelry created by Laura in her Seattle area studio.

SHIPPING DETAILS

All orders ship from my Washington studio via First-class USPS service with tracking. Priority mail upgrades are available for $8

CONTACT ME

any questions??? Feel free to contact me 7 days a week

100% SMILE GUARANTEE

Top quality materials, excellent craftsmanship and customer satisfaction is my standard practice. I want you 100% happy with your purchase from Laura B Elements. If it isn’t exactly what you expected please message me for a full refund or easy exchange.

Thanks so much for stopping by Laura B Elements

WHAT IS GOLD FILL

It is a genuine layer of gold or silver permanently bonded onto its base metal with heat and pressure. The bond produced is a permanent one. It is far superior to plating, has much more value, and the finish can last many years if cared for. People with sensitive skin can wear gold filled jewelry.

WHAT IS ARGENTIUM SILVER

It was developed specifically to combat the tarnish that occurs as silver oxidizes when it comes into contact with air, which is a major drawback for all who love silver. It contains a greater amount of pure silver (935 which contains 93.5% pure silver) making it more expensive than sterling silver, tarnish resistance and more durable.


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-17**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 14 days


- Ships from: **Woodinville, WA**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## Reviews for this item (797)

4.9/5

item average

5.0Item quality

4.9Shipping

4.9Customer service

98%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Love it

Cute

Comfortable

Beautiful

Fast shipping

Great quality

Well packaged


Filter by category


Appearance (211)


Comfort (199)


Shipping & Packaging (167)


Quality (170)


Description accuracy (103)


Sizing & Fit (74)


Ease of use (69)


Seller service (54)


Value (10)


Condition (5)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Mary-Grace Borck-Wells](https://www.etsy.com/people/gcf78ki3yel8vxa7?ref=l_review)
Nov 10, 2025


Thought my order was lost and reached out to Laura. She immediately got back to me. Once I got my package, the hoops are perfect and the packaging is thoughtful. Perfect!



[Mary-Grace Borck-Wells](https://www.etsy.com/people/gcf78ki3yel8vxa7?ref=l_review)
Nov 10, 2025


5 out of 5 stars
5

This item

[Sara Berwald](https://www.etsy.com/people/d7zfx75k8e0ivm76?ref=l_review)
Nov 10, 2025


My ears are highly sensitive (legit cannot wear anything for some reason), but I can wear these! I can wear them all day and even sleep on them! I’m buying more so I can stack my piercings.



[Sara Berwald](https://www.etsy.com/people/d7zfx75k8e0ivm76?ref=l_review)
Nov 10, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/53eef4/35230756/iusa_75x75.35230756_i5q3.jpg?version=0)

[harley colquhoun](https://www.etsy.com/people/harleyann2639?ref=l_review)
Nov 9, 2025


beautiful and lightweight, exactly what i was looking for



![](https://i.etsystatic.com/iusa/53eef4/35230756/iusa_75x75.35230756_i5q3.jpg?version=0)

[harley colquhoun](https://www.etsy.com/people/harleyann2639?ref=l_review)
Nov 9, 2025


5 out of 5 stars
5

This item

[MAureen](https://www.etsy.com/people/134yjgb2ne712kxv?ref=l_review)
Nov 8, 2025


I love these earrings, they are perfect
Easy to put on and feel weightless. good quality too.



[MAureen](https://www.etsy.com/people/134yjgb2ne712kxv?ref=l_review)
Nov 8, 2025


View all reviews for this item

### Photos from reviews

![starr added a photo of their purchase](https://i.etsystatic.com/iap/a38572/7324590442/iap_300x300.7324590442_sl2miotg.jpg?version=0)

![ktimpson added a photo of their purchase](https://i.etsystatic.com/iap/3e1d58/7181502558/iap_300x300.7181502558_3gerznx8.jpg?version=0)

![Ashley added a photo of their purchase](https://i.etsystatic.com/iap/cd3181/7132321194/iap_300x300.7132321194_oziekwrk.jpg?version=0)

![Annabelle added a photo of their purchase](https://i.etsystatic.com/iap/0d8442/7409785623/iap_300x300.7409785623_anwljg4g.jpg?version=0)

![L added a photo of their purchase](https://i.etsystatic.com/iap/2de543/7352893961/iap_300x300.7352893961_5mzohy22.jpg?version=0)

![Amanda added a photo of their purchase](https://i.etsystatic.com/iap/a6ba49/7060687844/iap_300x300.7060687844_wiv5faew.jpg?version=0)

![Dawn added a photo of their purchase](https://i.etsystatic.com/iap/79b731/6715831874/iap_300x300.6715831874_oz9f0e50.jpg?version=0)

![Patty added a photo of their purchase](https://i.etsystatic.com/iap/4df0c7/5915708221/iap_300x300.5915708221_o5bd51jy.jpg?version=0)

![Christina added a photo of their purchase](https://i.etsystatic.com/iap/a84796/7076257940/iap_300x300.7076257940_nfi24zck.jpg?version=0)

![Sue added a photo of their purchase](https://i.etsystatic.com/iap/c82702/6644760983/iap_300x300.6644760983_807ho6l1.jpg?version=0)

![aleecehayes added a photo of their purchase](https://i.etsystatic.com/iap/5e7164/7020250103/iap_300x300.7020250103_36p93adw.jpg?version=0)

![Kate added a photo of their purchase](https://i.etsystatic.com/iap/5f95eb/7298118209/iap_300x300.7298118209_5mko2keu.jpg?version=0)

![SambacCandidum added a photo of their purchase](https://i.etsystatic.com/iap/639209/6441060615/iap_300x300.6441060615_1rzzgbca.jpg?version=0)

![Allyson added a photo of their purchase](https://i.etsystatic.com/iap/068c7c/7316749450/iap_300x300.7316749450_65q0eubw.jpg?version=0)

![berebecca added a photo of their purchase](https://i.etsystatic.com/iap/1acad3/6636146139/iap_300x300.6636146139_3ioid06g.jpg?version=0)

![maileeturner added a photo of their purchase](https://i.etsystatic.com/iap/7e22df/7208045518/iap_300x300.7208045518_o960e7dd.jpg?version=0)

![Fyote added a photo of their purchase](https://i.etsystatic.com/iap/1c1e07/7323321441/iap_300x300.7323321441_35l7k3yk.jpg?version=0)

![Sydni added a photo of their purchase](https://i.etsystatic.com/iap/33fb7f/7358959292/iap_300x300.7358959292_joi06z8z.jpg?version=0)

![Karin added a photo of their purchase](https://i.etsystatic.com/iap/7a3c21/7231890160/iap_300x300.7231890160_93bcw6pr.jpg?version=0)

![Lori added a photo of their purchase](https://i.etsystatic.com/iap/2ad43a/6561349463/iap_300x300.6561349463_223ut4ca.jpg?version=0)

[![LauraBElements](https://i.etsystatic.com/iusa/962bbf/61633020/iusa_75x75.61633020_9nm7.jpg?version=0)](https://www.etsy.com/shop/LauraBElements?ref=shop_profile&listing_id=1036210721)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[LauraBElements](https://www.etsy.com/shop/LauraBElements?ref=shop_profile&listing_id=1036210721)

[Owned by Laura Bradford](https://www.etsy.com/shop/LauraBElements?ref=shop_profile&listing_id=1036210721) \|

Snohomish, Washington

4.9
(2.6k)


9.8k sales

11 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=50135835&referring_id=1036210721&referring_type=listing&recipient_id=50135835&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo1MDEzNTgzNToxNzYyODE4MzcwOjhmY2I1ZjRhMGMxYWExNjJhZjY4MjM4MThiZjEwMDU2&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1036210721%2Ftiny-d-sleeper-earrings-10mm-or-12mm-ear%3Famp%253Bclick_sum%3Daf51e5c9%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bsts%3D1)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/LauraBElements?ref=lp_mys_mfts)

- [![Tiny Horseshoe Sleeper Earrings: 14mm Arch Ear Hugging Open Hoops, Handcrafted Everyday Minimalist Jewelry](https://i.etsystatic.com/9687561/r/il/79693e/6716227485/il_340x270.6716227485_kxkw.jpg)\\
\\
**Tiny Horseshoe Sleeper Earrings: 14mm Arch Ear Hugging Open Hoops, Handcrafted Everyday Minimalist Jewelry**\\
\\
$14.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1864716282/tiny-horseshoe-sleeper-earrings-14mm?click_key=1b60f498a377d114c8915cbb21b4aee0%3ALTb70cedc00a53dbdaaf28919df59a7bd3323a8bfe&click_sum=e515fcb8&ls=r&ref=related-1&sts=1&content_source=1b60f498a377d114c8915cbb21b4aee0%253ALTb70cedc00a53dbdaaf28919df59a7bd3323a8bfe "Tiny Horseshoe Sleeper Earrings: 14mm Arch Ear Hugging Open Hoops, Handcrafted Everyday Minimalist Jewelry")




Add to Favorites


- [![Tiny D Open Hoops: 10mm or 12mm Ear Hugging Half Circle Backless Sleeper Earrings, Handcrafted in 14k Gold Fill, and Argentium 940 Silver](https://i.etsystatic.com/9687561/r/il/a974a2/6668512587/il_340x270.6668512587_rbru.jpg)\\
\\
**Tiny D Open Hoops: 10mm or 12mm Ear Hugging Half Circle Backless Sleeper Earrings, Handcrafted in 14k Gold Fill, and Argentium 940 Silver**\\
\\
$28.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1869345833/tiny-d-open-hoops-10mm-or-12mm-ear?click_key=1b60f498a377d114c8915cbb21b4aee0%3ALTa2fc1f26d8dfff06c0000fc69dfd39e4018798ef&click_sum=d1dad390&ls=r&ref=related-2&sts=1&content_source=1b60f498a377d114c8915cbb21b4aee0%253ALTa2fc1f26d8dfff06c0000fc69dfd39e4018798ef "Tiny D Open Hoops: 10mm or 12mm Ear Hugging Half Circle Backless Sleeper Earrings, Handcrafted in 14k Gold Fill, and Argentium 940 Silver")




Add to Favorites


- [![Tiny Ribbon Open Hoops: 12mm Crisscross Sleeper Earrings, 1/2 inch Teardrop hoops, Handcrafted Jewelry in 14k Gold Fill and Argentium Silver](https://i.etsystatic.com/9687561/r/il/f82101/5844057545/il_340x270.5844057545_d2s6.jpg)\\
\\
**Tiny Ribbon Open Hoops: 12mm Crisscross Sleeper Earrings, 1/2 inch Teardrop hoops, Handcrafted Jewelry in 14k Gold Fill and Argentium Silver**\\
\\
$14.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1385996913/tiny-ribbon-open-hoops-12mm-crisscross?click_key=1b60f498a377d114c8915cbb21b4aee0%3ALT5f062cf9a69bd5f7c1aedb7036e5c75652ca0eb3&click_sum=b9bcb46c&ls=r&ref=related-3&sts=1&content_source=1b60f498a377d114c8915cbb21b4aee0%253ALT5f062cf9a69bd5f7c1aedb7036e5c75652ca0eb3 "Tiny Ribbon Open Hoops: 12mm Crisscross Sleeper Earrings, 1/2 inch Teardrop hoops, Handcrafted Jewelry in 14k Gold Fill and Argentium Silver")




Add to Favorites


- [![Pear shaped wire hoop earrings, 45mm round teardrop hoops, minimalist statement hoops, everyday earrings in Gold filled or Argentium silver](https://i.etsystatic.com/9687561/r/il/d7fc7f/6969913709/il_340x270.6969913709_hjde.jpg)\\
\\
**Pear shaped wire hoop earrings, 45mm round teardrop hoops, minimalist statement hoops, everyday earrings in Gold filled or Argentium silver**\\
\\
$38.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4316609731/pear-shaped-wire-hoop-earrings-45mm?click_key=d15efd75fc4228a1e02e32f320b7a434449b8b64%3A4316609731&click_sum=a346b080&ref=related-4&sts=1 "Pear shaped wire hoop earrings, 45mm round teardrop hoops, minimalist statement hoops, everyday earrings in Gold filled or Argentium silver")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 10, 2025


[9418 favorites](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Jewelry](https://www.etsy.com/c/jewelry?amp%3Bclick_sum=af51e5c9&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Earrings](https://www.etsy.com/c/jewelry/earrings?amp%3Bclick_sum=af51e5c9&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Threader Earrings](https://www.etsy.com/c/jewelry/earrings/threader-earrings?amp%3Bclick_sum=af51e5c9&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bsts=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Shopping

[Buy Custom His And Hers Sweater Online](https://www.etsy.com/market/custom_his_and_hers_sweater) [Rivendell Play Mat Magic Tcg - US](https://www.etsy.com/market/rivendell_play_mat_magic_tcg)

Patterns & How To

[Mitten Quilt Block for Sale](https://www.etsy.com/market/mitten_quilt_block)

Knives & Cutting Tools

[Buy Work Sharp Professional Precision Adjust Stones Online](https://www.etsy.com/market/work_sharp_professional_precision_adjust_stones)

Accessories

[Buy Montana Wildflower Bouquet Online](https://www.etsy.com/market/montana_wildflower_bouquet)

Brooches Pins & Clips

[Shop Shrug Clip](https://www.etsy.com/market/shrug_clip)

Suit & Tie Accessories

[Buy Nail Tie Clip Online](https://www.etsy.com/market/nail_tie_clip)

Earrings

[Buy 16g Surgical Steel Cartilage Online](https://www.etsy.com/market/16g_surgical_steel_cartilage) [Buy Chic Ear Cuff Online](https://www.etsy.com/market/chic_ear_cuff) [Ear cuff - Single Ring Beaded earring cuff no piercing required - sterling silver](https://www.etsy.com/listing/777575798/ear-cuff-single-ring-beaded-earring-cuff) [Steampunk Earrings Jewelry Hippie Festival Earrings Chains Steampunk Accessories Boho Earring Cyberpunk Gothic Shell Gold Earrings New Shell](https://www.etsy.com/listing/1472681674/steampunk-earrings-jewelry-hippie)

Baby & Child Care

[Eat sleep repeat baby bib - Baby & Child Care](https://www.etsy.com/listing/1190399445/eat-sleep-repeat-baby-bib)

Kitchen Supplies

[Congrats Cake Topper - US](https://www.etsy.com/market/congrats_cake_topper)

Dolls & Miniatures

[1:12 Dollhouse miniature Eagle Lady gold-filled picture](https://www.etsy.com/listing/1107595167/112-dollhouse-miniature-eagle-lady-gold)

Closures & Fasteners

[Boots With Rivets - US](https://www.etsy.com/market/boots_with_rivets)

Curtains & Window Treatments

[Cute Sheer Curtains - US](https://www.etsy.com/market/cute_sheer_curtains)

Hair Accessories

[Buy Embroidery Hair Bow Online](https://www.etsy.com/market/embroidery_hair_bow)

Necklaces

[Sterling Silver Our Lady of Guadalupe Medal](https://www.etsy.com/listing/264675111/sterling-silver-our-lady-of-guadalupe)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1036210721%2Ftiny-d-sleeper-earrings-10mm-or-12mm-ear%3Famp%253Bclick_sum%3Daf51e5c9%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bsts%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgxODM3MDo5NGRhNDgxNGQ2OTdlZjU1OTkzODYyNDcwZDg0MGQ2Yg==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1036210721%2Ftiny-d-sleeper-earrings-10mm-or-12mm-ear%3Famp%253Bclick_sum%3Daf51e5c9%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bsts%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1036210721/tiny-d-sleeper-earrings-10mm-or-12mm-ear?amp;click_sum=af51e5c9&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;sts=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1036210721%2Ftiny-d-sleeper-earrings-10mm-or-12mm-ear%3Famp%253Bclick_sum%3Daf51e5c9%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bsts%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for LauraBElements

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: not accepted

Please contact the seller if you have any problems with your order.

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading


- Item in the photo is in **Material: Argentium Silver**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Material: 14k Gold filled**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Material: 14k Rose gold filled**




Select this option








Option selected!













This option is sold out.



Click to zoom

- ![May include: Close-up view of three pairs of small, hammered metal hoop earrings displayed on a white ceramic dish. Each pair is shown in a different metallic color: silver, rose gold, and gold. The earrings have a simple, minimalist design, with a slightly irregular, hammered texture.  The hoops are open at the top, and appear to be crafted from a thin gauge of metal. The image showcases the subtle variations in color and texture of the earrings.](https://i.etsystatic.com/9687561/r/il/e72fc0/5072824089/il_300x300.5072824089_7or0.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/file_nklqjm.jpg)

- ![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver image 2](https://i.etsystatic.com/9687561/r/il/80239f/6710176743/il_300x300.6710176743_e6bx.jpg)
- ![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver image 3](https://i.etsystatic.com/9687561/r/il/cefbc7/7289158525/il_300x300.7289158525_eqh0.jpg)
- ![Tiny D Sleeper Earrings: 10mm or 12mm Ear Hugging Half Hoops, Handcrafted Everyday Jewelry in 14k Gold Fill and Argentium 940 Silver image 4](https://i.etsystatic.com/9687561/r/il/e06b68/7241118740/il_300x300.7241118740_bvsi.jpg)
- ![May include: Close-up view of an assortment of small, minimalist hoop earrings displayed on a white square dish. The hoops are in silver, rose gold, and gold finishes, showcasing a variety of metallic hues. Each earring features a simple, half-circle design, crafted with delicate, thin metal. The earrings are small and understated, ideal for everyday wear or as subtle accents.](https://i.etsystatic.com/9687561/r/il/985f16/5024601756/il_300x300.5024601756_1rdi.jpg)
- ![May include: A pair of minimalist hammered sterling silver hoop earrings.  These small, simple earrings feature a slightly textured, curved, open-hoop design. The hoops are crafted from smooth, polished silver metal, giving them a subtle, elegant look.  These delicate earrings are perfect for everyday wear or special occasions. The earrings are shown on a white background.](https://i.etsystatic.com/9687561/r/il/e63552/5477601514/il_300x300.5477601514_s4qz.jpg)
- ![May include: A pair of gold hammered open hoop earrings.  These minimalist earrings have a simple, slightly irregular, curved shape. The hoops are crafted from 14k gold and feature a textured, hammered finish. The earrings are shown against a plain white background.](https://i.etsystatic.com/9687561/r/il/ef0e07/5525708029/il_300x300.5525708029_ec7l.jpg)
- ![May include: Rose gold hammered open half-circle earrings. These minimalist earrings have a simple, modern design.  The smooth, slightly textured metal creates a subtle, elegant look. The earrings are shown on a white background.](https://i.etsystatic.com/9687561/r/il/ae5493/5525549131/il_300x300.5525549131_for1.jpg)
- ![May include: Close-up view of two hammered silver ear cuffs. One cuff is shown closed, the other open.  The text 'Closed' appears above the closed cuff and 'Open' above the open cuff. Both cuffs have a simple, curved design.  These minimalist silver ear cuffs are ideal for everyday wear.](https://i.etsystatic.com/9687561/r/il/5d964d/6092643061/il_300x300.6092643061_qdi8.jpg)
- ![May include: Close-up view of gold half hoop earrings displayed in a silver tin with a mandala design on the lid.  The earrings are presented on a gray card with the logo 'Laura B Elements.'  Accompanying cards provide care instructions and details about the handcrafted jewelry, emphasizing its unique and lasting quality. The text on the cards includes 'Laura B Elements,' 'Care,' and 'Love.' ](https://i.etsystatic.com/9687561/r/il/7bf5d3/5226418660/il_300x300.5226418660_6ntc.jpg)