[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1769365473/better-late-than-ugly-audrey-hepburn?amp;click_sum=987012e3&amp;ls=s&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=Find+10+aesthetic+dorm+posters+on+Etsy&amp;ref=search_grid-537162-1-2&amp;sr_prefetch=1&amp;pf_from=search&amp;pro=1&amp;pop=1&amp;content_source=380eb05d-f8a5-4402-80db-7221526b7b32%253ALT9d1ccb24769ef2dd63f72283efac1f6599717c02#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=987012e3&%3Bls=s&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+aesthetic+dorm+posters+on+Etsy&%3Bref=search_grid-537162-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bpop=1&%3Bcontent_source=380eb05d-f8a5-4402-80db-7221526b7b32%253ALT9d1ccb24769ef2dd63f72283efac1f6599717c02&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=987012e3&%3Bls=s&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+aesthetic+dorm+posters+on+Etsy&%3Bref=search_grid-537162-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bpop=1&%3Bcontent_source=380eb05d-f8a5-4402-80db-7221526b7b32%253ALT9d1ccb24769ef2dd63f72283efac1f6599717c02&explicit=1&ref=catnav_breadcrumb-1)
- [Wall Decor](https://www.etsy.com/c/home-and-living/home-decor/wall-decor?amp%3Bclick_sum=987012e3&%3Bls=s&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+aesthetic+dorm+posters+on+Etsy&%3Bref=search_grid-537162-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bpop=1&%3Bcontent_source=380eb05d-f8a5-4402-80db-7221526b7b32%253ALT9d1ccb24769ef2dd63f72283efac1f6599717c02&explicit=1&ref=catnav_breadcrumb-2)

Bestseller

This item has had a high sales volume over the past 6 months.



Add to Favorites


- ![May include: A black and white newspaper style print with the headline 'She Speaks Daily' and the subheading 'New Study Finds: BETTER LATE THAN UGLY'. The image shows a woman wearing sunglasses and a white towel on her head applying lipstick.](https://i.etsystatic.com/22158960/r/il/ecb83c/6156163356/il_794xN.6156163356_thix.jpg)
- ![May include: A black and white newspaper print with the headline 'She Speaks Daily' and the subheading 'New Study Finds: BETTER LATE THAN UGLY'. The image shows a woman wearing sunglasses and a towel on her head, applying lipstick with a brush.](https://i.etsystatic.com/22158960/r/il/7aa430/6204238883/il_794xN.6204238883_499p.jpg)
- ![May include: A black and white newspaper print with the headline 'She Speaks Daily' and the subheading 'New Study Finds: BETTER LATE THAN UGLY'. The image shows a woman wearing sunglasses and a white towel on her head, applying lipstick.](https://i.etsystatic.com/22158960/r/il/bda91d/6156163358/il_794xN.6156163358_tpmf.jpg)
- ![Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor image 4](https://i.etsystatic.com/22158960/r/il/de35ad/5791353623/il_794xN.5791353623_fqaw.jpg)

- ![May include: A black and white newspaper style print with the headline 'She Speaks Daily' and the subheading 'New Study Finds: BETTER LATE THAN UGLY'. The image shows a woman wearing sunglasses and a white towel on her head applying lipstick.](https://i.etsystatic.com/22158960/r/il/ecb83c/6156163356/il_75x75.6156163356_thix.jpg)
- ![May include: A black and white newspaper print with the headline 'She Speaks Daily' and the subheading 'New Study Finds: BETTER LATE THAN UGLY'. The image shows a woman wearing sunglasses and a towel on her head, applying lipstick with a brush.](https://i.etsystatic.com/22158960/r/il/7aa430/6204238883/il_75x75.6204238883_499p.jpg)
- ![May include: A black and white newspaper print with the headline 'She Speaks Daily' and the subheading 'New Study Finds: BETTER LATE THAN UGLY'. The image shows a woman wearing sunglasses and a white towel on her head, applying lipstick.](https://i.etsystatic.com/22158960/r/il/bda91d/6156163358/il_75x75.6156163358_tpmf.jpg)
- ![Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor image 4](https://i.etsystatic.com/22158960/r/il/de35ad/5791353623/il_75x75.5791353623_fqaw.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1769365473%2Fbetter-late-than-ugly-audrey-hepburn%23report-overlay-trigger)

In 12 carts

NowPrice:$11.19+


Original Price:
$15.99+


Loading


30% off


•

Sale ends on December 1


# Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor

Designed by [PoppyBerryPrints](https://www.etsy.com/shop/PoppyBerryPrints)

[5 out of 5 stars](https://www.etsy.com/listing/1769365473/better-late-than-ugly-audrey-hepburn?amp;click_sum=987012e3&amp;ls=s&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=Find+10+aesthetic+dorm+posters+on+Etsy&amp;ref=search_grid-537162-1-2&amp;sr_prefetch=1&amp;pf_from=search&amp;pro=1&amp;pop=1&amp;content_source=380eb05d-f8a5-4402-80db-7221526b7b32%253ALT9d1ccb24769ef2dd63f72283efac1f6599717c02#reviews)

Arrives soon! Get it by

Nov 14-19


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

Sizes


Select an option

4" x 6" ($11.19)

5" x 7" ($11.19)

8" x 12" ($12.59)

10" x 15" ($12.59)

11" x 14" ($13.29)

12" x 18" ($13.99)

16" x 20" ($14.69)

18" x 24" ($18.54)

20" x 30" ($19.59)

24" x 36" ($23.09)

Please select an option


Quantity



12345678910111213141516171819202122232425262728293031323334353637383940414243444546474849505152535455565758596061626364656667686970717273747576777879808182838485868788899091

4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Buy together, get free shipping

## Buy together, get free shipping

Add 4 items to cart



Loading


[See more items](https://www.etsy.com/listing/1769365473/better-late-than-ugly-audrey-hepburn?amp;click_sum=987012e3&amp;ls=s&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=Find+10+aesthetic+dorm+posters+on+Etsy&amp;ref=search_grid-537162-1-2&amp;sr_prefetch=1&amp;pf_from=search&amp;pro=1&amp;pop=1&amp;content_source=380eb05d-f8a5-4402-80db-7221526b7b32%253ALT9d1ccb24769ef2dd63f72283efac1f6599717c02#recs_ribbon_container)

![Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor](https://i.etsystatic.com/22158960/r/il/ecb83c/6156163356/il_340x270.6156163356_thix.jpg)
This listing

### Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor

Sale Price $11.19
$11.19

$15.99
Original Price $15.99


(30% off)




Add to Favorites


[![Funny Wall Art Decor, Women Searches For Where Men Get the Audacity, Newspapers Print, Magazine Cover, Girls Room decor, Photo Print](https://i.etsystatic.com/22158960/r/il/a3fc87/5849277036/il_340x270.5849277036_7w72.jpg)\\
\\
**Funny Wall Art Decor, Women Searches For Where Men Get the Audacity, Newspapers Print, Magazine Cover, Girls Room decor, Photo Print**\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
(30% off)](https://www.etsy.com/listing/1683851860/funny-wall-art-decor-women-searches-for?click_key=4426b38a4df5798a2f8b712b25366122%3ALT06f7d3afd8fc10072334ca169978d44ac855f1b5&click_sum=3559ea7f&ls=r&ref=listing-free-shipping-bundle-1&pro=1&content_source=4426b38a4df5798a2f8b712b25366122%253ALT06f7d3afd8fc10072334ca169978d44ac855f1b5 "Funny Wall Art Decor, Women Searches For Where Men Get the Audacity, Newspapers Print, Magazine Cover, Girls Room decor, Photo Print")


Add to Favorites


[![Audrey Hepburn Print, No Desire To Be Low Maintenance, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor](https://i.etsystatic.com/22158960/r/il/772dc3/6698501479/il_340x270.6698501479_3kj3.jpg)\\
\\
**Audrey Hepburn Print, No Desire To Be Low Maintenance, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor**\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
(30% off)](https://www.etsy.com/listing/1861309328/audrey-hepburn-print-no-desire-to-be-low?click_key=4426b38a4df5798a2f8b712b25366122%3ALTa5d6b5fa0226ac4322bad818e3339cab843ed0eb&click_sum=4c13f6f6&ls=r&ref=listing-free-shipping-bundle-2&pro=1&content_source=4426b38a4df5798a2f8b712b25366122%253ALTa5d6b5fa0226ac4322bad818e3339cab843ed0eb "Audrey Hepburn Print, No Desire To Be Low Maintenance, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor")


Add to Favorites


[![Brigitte Bardot Bathtub Print, Bathroom Poster, Black and White Wall Art, Vintage Print, Photography Prints Old Hollywood Photo, Unframed](https://i.etsystatic.com/22158960/r/il/7c9c6b/5851991693/il_340x270.5851991693_mtl0.jpg)\\
\\
**Brigitte Bardot Bathtub Print, Bathroom Poster, Black and White Wall Art, Vintage Print, Photography Prints Old Hollywood Photo, Unframed**\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
(30% off)](https://www.etsy.com/listing/1673535620/brigitte-bardot-bathtub-print-bathroom?click_key=4426b38a4df5798a2f8b712b25366122%3ALT297f496cf099089994d19bb5ce11aa81c125e121&click_sum=db108348&ls=r&ref=listing-free-shipping-bundle-3&pro=1&content_source=4426b38a4df5798a2f8b712b25366122%253ALT297f496cf099089994d19bb5ce11aa81c125e121 "Brigitte Bardot Bathtub Print, Bathroom Poster, Black and White Wall Art, Vintage Print, Photography Prints Old Hollywood Photo, Unframed")


Add to Favorites


![Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor](https://i.etsystatic.com/22158960/r/il/ecb83c/6156163356/il_340x270.6156163356_thix.jpg)
This listing

### Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor

Sale Price $11.19
$11.19

$15.99
Original Price $15.99


(30% off)




Add to Favorites


[![Funny Wall Art Decor, Women Searches For Where Men Get the Audacity, Newspapers Print, Magazine Cover, Girls Room decor, Photo Print](https://i.etsystatic.com/22158960/r/il/a3fc87/5849277036/il_340x270.5849277036_7w72.jpg)\\
\\
**Funny Wall Art Decor, Women Searches For Where Men Get the Audacity, Newspapers Print, Magazine Cover, Girls Room decor, Photo Print**\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
(30% off)](https://www.etsy.com/listing/1683851860/funny-wall-art-decor-women-searches-for?click_key=4426b38a4df5798a2f8b712b25366122%3ALT06f7d3afd8fc10072334ca169978d44ac855f1b5&click_sum=3559ea7f&ls=r&ref=listing-free-shipping-bundle-1&pro=1&content_source=4426b38a4df5798a2f8b712b25366122%253ALT06f7d3afd8fc10072334ca169978d44ac855f1b5 "Funny Wall Art Decor, Women Searches For Where Men Get the Audacity, Newspapers Print, Magazine Cover, Girls Room decor, Photo Print")


Add to Favorites


[![Audrey Hepburn Print, No Desire To Be Low Maintenance, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor](https://i.etsystatic.com/22158960/r/il/772dc3/6698501479/il_340x270.6698501479_3kj3.jpg)\\
\\
**Audrey Hepburn Print, No Desire To Be Low Maintenance, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor**\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
(30% off)](https://www.etsy.com/listing/1861309328/audrey-hepburn-print-no-desire-to-be-low?click_key=4426b38a4df5798a2f8b712b25366122%3ALTa5d6b5fa0226ac4322bad818e3339cab843ed0eb&click_sum=4c13f6f6&ls=r&ref=listing-free-shipping-bundle-2&pro=1&content_source=4426b38a4df5798a2f8b712b25366122%253ALTa5d6b5fa0226ac4322bad818e3339cab843ed0eb "Audrey Hepburn Print, No Desire To Be Low Maintenance, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor")


Add to Favorites


[![Brigitte Bardot Bathtub Print, Bathroom Poster, Black and White Wall Art, Vintage Print, Photography Prints Old Hollywood Photo, Unframed](https://i.etsystatic.com/22158960/r/il/7c9c6b/5851991693/il_340x270.5851991693_mtl0.jpg)\\
\\
**Brigitte Bardot Bathtub Print, Bathroom Poster, Black and White Wall Art, Vintage Print, Photography Prints Old Hollywood Photo, Unframed**\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
(30% off)](https://www.etsy.com/listing/1673535620/brigitte-bardot-bathtub-print-bathroom?click_key=4426b38a4df5798a2f8b712b25366122%3ALT297f496cf099089994d19bb5ce11aa81c125e121&click_sum=db108348&ls=r&ref=listing-free-shipping-bundle-3&pro=1&content_source=4426b38a4df5798a2f8b712b25366122%253ALT297f496cf099089994d19bb5ce11aa81c125e121 "Brigitte Bardot Bathtub Print, Bathroom Poster, Black and White Wall Art, Vintage Print, Photography Prints Old Hollywood Photo, Unframed")


Add to Favorites


![Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor](https://i.etsystatic.com/22158960/r/il/ecb83c/6156163356/il_340x270.6156163356_thix.jpg)
This listing

### Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor

Sale Price $11.19
$11.19

$15.99
Original Price $15.99


(30% off)




Add to Favorites


[![Funny Wall Art Decor, Women Searches For Where Men Get the Audacity, Newspapers Print, Magazine Cover, Girls Room decor, Photo Print](https://i.etsystatic.com/22158960/r/il/a3fc87/5849277036/il_340x270.5849277036_7w72.jpg)\\
\\
**Funny Wall Art Decor, Women Searches For Where Men Get the Audacity, Newspapers Print, Magazine Cover, Girls Room decor, Photo Print**\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
(30% off)](https://www.etsy.com/listing/1683851860/funny-wall-art-decor-women-searches-for?click_key=4426b38a4df5798a2f8b712b25366122%3ALT06f7d3afd8fc10072334ca169978d44ac855f1b5&click_sum=3559ea7f&ls=r&ref=listing-free-shipping-bundle-1&pro=1&content_source=4426b38a4df5798a2f8b712b25366122%253ALT06f7d3afd8fc10072334ca169978d44ac855f1b5 "Funny Wall Art Decor, Women Searches For Where Men Get the Audacity, Newspapers Print, Magazine Cover, Girls Room decor, Photo Print")


Add to Favorites


[![Audrey Hepburn Print, No Desire To Be Low Maintenance, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor](https://i.etsystatic.com/22158960/r/il/772dc3/6698501479/il_340x270.6698501479_3kj3.jpg)\\
\\
**Audrey Hepburn Print, No Desire To Be Low Maintenance, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor**\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
(30% off)](https://www.etsy.com/listing/1861309328/audrey-hepburn-print-no-desire-to-be-low?click_key=4426b38a4df5798a2f8b712b25366122%3ALTa5d6b5fa0226ac4322bad818e3339cab843ed0eb&click_sum=4c13f6f6&ls=r&ref=listing-free-shipping-bundle-2&pro=1&content_source=4426b38a4df5798a2f8b712b25366122%253ALTa5d6b5fa0226ac4322bad818e3339cab843ed0eb "Audrey Hepburn Print, No Desire To Be Low Maintenance, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor")


Add to Favorites


[![Brigitte Bardot Bathtub Print, Bathroom Poster, Black and White Wall Art, Vintage Print, Photography Prints Old Hollywood Photo, Unframed](https://i.etsystatic.com/22158960/r/il/7c9c6b/5851991693/il_340x270.5851991693_mtl0.jpg)\\
\\
**Brigitte Bardot Bathtub Print, Bathroom Poster, Black and White Wall Art, Vintage Print, Photography Prints Old Hollywood Photo, Unframed**\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
(30% off)](https://www.etsy.com/listing/1673535620/brigitte-bardot-bathtub-print-bathroom?click_key=4426b38a4df5798a2f8b712b25366122%3ALT297f496cf099089994d19bb5ce11aa81c125e121&click_sum=db108348&ls=r&ref=listing-free-shipping-bundle-3&pro=1&content_source=4426b38a4df5798a2f8b712b25366122%253ALT297f496cf099089994d19bb5ce11aa81c125e121 "Brigitte Bardot Bathtub Print, Bathroom Poster, Black and White Wall Art, Vintage Print, Photography Prints Old Hollywood Photo, Unframed")


Add to Favorites


## Item details

### Highlights

Designed by [PoppyBerryPrints](https://www.etsy.com/shop/PoppyBerryPrints)

Introducing our stunning collection of vintage photo prints, the perfect solution for elevating your home decor effortlessly. With our prints, you can transform any space with ease. Simply buy, frame, and decorate to your heart's content.

\*\*These are unframed, pyhysical prints\*\*

Each of our prints are produced to only the highest archival standards. They are printed with archival pigment inks with a commercial grade, inkjet printer, using acid-free, archival paper. This process will significantly enrich the brilliance, quality, and longevity of your print. Your purchase will sustain it's beauty and quality for many decades to come.

Giclee Print: Giclee (French for 'to spray') is a printing process where millions of ink droplets are sprayed onto a high-quality paper. The smooth transitions of color gradients make giclee prints appear much more realistic than other prints.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Shipping:

We aim to ship our items out within 3-5 days of your order. In most cases we are more than happy to rush ship something, just send us a message first and we can see what we can do!

Please keep the following upgrades in mind when checking out:

STANDARD MAIL: Normally around 4-5 days

PRIORITY MAIL: Normally around 2-3 days

EXPRESS: Normally around 1-2 days

We are also able to ship UPS if you would like to pay that upgrade - Just send us a message!

Please keep in mind that once we drop the mail off, it is out of our hands and there is unfortunately nothing we can do if there is a mail delay.


### Production partners

PoppyBerryPrints makes this item with help from


A Printer, United States


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-19**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 30 days


- Ships from: **Kissimmee, FL**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## FAQs

What is your turnaround time?


Our current processing time is 1-3 business days.

Please keep the following mail times in mind when ordering in time for your need by date:

Standard Shipping: 3-5 Business Days

Priority Shipping: 1-3 Business Days

Express Shipping: 1-2 Business Days

In regards to Thursday shipping, your order must be received before 10:00 am CST, otherwise it will ship on the following Monday.

If you have an approaching need by date we would be more than happy to work with you!


Can I cancel my order?


Due to how quick we ship, you have a 6 hour period to cancel your order. After that 6 hour period we unfortunately cannot cancel your order.


## Meet your sellers

![Poppy Berry Prints](https://i.etsystatic.com/22158960/r/isla/1155f1/69560927/isla_75x75.69560927_slfvbxjj.jpg)

Poppy Berry Prints

Owner of [PoppyBerryPrints](https://www.etsy.com/shop/PoppyBerryPrints?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyNzIwODg0ODk6MTc2MjgxNTU2MzplYTE4NzIyOWYwZjViYWU5ODhlMjlkZGE4ZWM2NzFjMQ%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1769365473%2Fbetter-late-than-ugly-audrey-hepburn%3Famp%253Bclick_sum%3D987012e3%26amp%253Bls%3Ds%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DFind%2B10%2Baesthetic%2Bdorm%2Bposters%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-537162-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bpop%3D1%26amp%253Bcontent_source%3D380eb05d-f8a5-4402-80db-7221526b7b32%25253ALT9d1ccb24769ef2dd63f72283efac1f6599717c02)

[Message Poppy Berry Prints](https://www.etsy.com/messages/new?with_id=272088489&referring_id=1769365473&referring_type=listing&recipient_id=272088489&from_action=contact-seller)

This seller usually responds **within a few hours.**

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (83)

4.7/5

item average

4.9Item quality

4.9Shipping

4.7Customer service

95%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Love it

Great quality

As described

Fast shipping

Cute

Great product

Would recommend


Filter by category


Quality (27)


Description accuracy (18)


Appearance (16)


Shipping & Packaging (12)


Seller service (5)


Condition (4)


Value (4)


Sizing & Fit (3)


Ease of use (2)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[joyweinrich](https://www.etsy.com/people/joyweinrich?ref=l_review)
Nov 7, 2025


Great condition, fast delivery...great service



[joyweinrich](https://www.etsy.com/people/joyweinrich?ref=l_review)
Nov 7, 2025


5 out of 5 stars
5

This item

[Rod](https://www.etsy.com/people/73sfjs2vv990qpun?ref=l_review)
Nov 3, 2025


Looks fantastic. Will be a great addition to my daughters place



[Rod](https://www.etsy.com/people/73sfjs2vv990qpun?ref=l_review)
Nov 3, 2025


5 out of 5 stars
5

This item

[Kate](https://www.etsy.com/people/smbynci3?ref=l_review)
Nov 2, 2025


Love it. Ordered with frame.



[Kate](https://www.etsy.com/people/smbynci3?ref=l_review)
Nov 2, 2025


5 out of 5 stars
5

This item

[Teri Bahr](https://www.etsy.com/people/1oix5xtw?ref=l_review)
Oct 17, 2025


Very good quality and came earlier than expected.



[Teri Bahr](https://www.etsy.com/people/1oix5xtw?ref=l_review)
Oct 17, 2025


View all reviews for this item

### Photos from reviews

![Lizabeth added a photo of their purchase](https://i.etsystatic.com/iap/362d30/6760337085/iap_300x300.6760337085_9tdnocdx.jpg?version=0)

![Carli added a photo of their purchase](https://i.etsystatic.com/iap/dc0bb7/6275924641/iap_300x300.6275924641_tqb6s2dm.jpg?version=0)

![Hannah added a photo of their purchase](https://i.etsystatic.com/iap/fd600e/6835653323/iap_300x300.6835653323_648k77nm.jpg?version=0)

![Tricia added a photo of their purchase](https://i.etsystatic.com/iap/3f9003/6562742800/iap_300x300.6562742800_k9l6cssi.jpg?version=0)

![Zina added a photo of their purchase](https://i.etsystatic.com/iap/16e0c4/6861098207/iap_300x300.6861098207_3porev4n.jpg?version=0)

![Lauren added a photo of their purchase](https://i.etsystatic.com/iap/5f36af/6729001675/iap_300x300.6729001675_gtsm8trb.jpg?version=0)

[![PoppyBerryPrints](https://i.etsystatic.com/iusa/c621c8/105135415/iusa_75x75.105135415_to0w.jpg?version=0)](https://www.etsy.com/shop/PoppyBerryPrints?ref=shop_profile&listing_id=1769365473)

[PoppyBerryPrints](https://www.etsy.com/shop/PoppyBerryPrints?ref=shop_profile&listing_id=1769365473)

[Owned by Poppy Berry Prints](https://www.etsy.com/shop/PoppyBerryPrints?ref=shop_profile&listing_id=1769365473) \|

Florida, United States

4.8
(893)


5.3k sales

5 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=272088489&referring_id=1769365473&referring_type=listing&recipient_id=272088489&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoyNzIwODg0ODk6MTc2MjgxNTU2MzplYTE4NzIyOWYwZjViYWU5ODhlMjlkZGE4ZWM2NzFjMQ%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1769365473%2Fbetter-late-than-ugly-audrey-hepburn%3Famp%253Bclick_sum%3D987012e3%26amp%253Bls%3Ds%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DFind%2B10%2Baesthetic%2Bdorm%2Bposters%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-537162-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bpop%3D1%26amp%253Bcontent_source%3D380eb05d-f8a5-4402-80db-7221526b7b32%25253ALT9d1ccb24769ef2dd63f72283efac1f6599717c02)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/PoppyBerryPrints?ref=lp_mys_mfts)

- [![Funny Wall Art Decor, Women Searches For Where Men Get the Audacity, Newspapers Print, Magazine Cover, Girls Room decor, Photo Print](https://i.etsystatic.com/22158960/r/il/a3fc87/5849277036/il_340x270.5849277036_7w72.jpg)\\
\\
**Funny Wall Art Decor, Women Searches For Where Men Get the Audacity, Newspapers Print, Magazine Cover, Girls Room decor, Photo Print**\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1683851860/funny-wall-art-decor-women-searches-for?click_key=8ef2964aeff41500951230dd90707a25%3ALT309d7e1a47627c78e19eb8d1a47286af06f0855d&click_sum=0a996f7d&ls=r&ref=related-1&pro=1&content_source=8ef2964aeff41500951230dd90707a25%253ALT309d7e1a47627c78e19eb8d1a47286af06f0855d "Funny Wall Art Decor, Women Searches For Where Men Get the Audacity, Newspapers Print, Magazine Cover, Girls Room decor, Photo Print")




Add to Favorites


- [![Audrey Hepburn Print, No Desire To Be Low Maintenance, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor](https://i.etsystatic.com/22158960/r/il/772dc3/6698501479/il_340x270.6698501479_3kj3.jpg)\\
\\
**Audrey Hepburn Print, No Desire To Be Low Maintenance, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor**\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1861309328/audrey-hepburn-print-no-desire-to-be-low?click_key=8ef2964aeff41500951230dd90707a25%3ALT3ec8b54fcab67471c5d53426f205f76bea1201e9&click_sum=8c445584&ls=r&ref=related-2&pro=1&content_source=8ef2964aeff41500951230dd90707a25%253ALT3ec8b54fcab67471c5d53426f205f76bea1201e9 "Audrey Hepburn Print, No Desire To Be Low Maintenance, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor")




Add to Favorites


- [![Brigitte Bardot Bathtub Print, Bathroom Poster, Black and White Wall Art, Vintage Print, Photography Prints Old Hollywood Photo, Unframed](https://i.etsystatic.com/22158960/r/il/7c9c6b/5851991693/il_340x270.5851991693_mtl0.jpg)\\
\\
**Brigitte Bardot Bathtub Print, Bathroom Poster, Black and White Wall Art, Vintage Print, Photography Prints Old Hollywood Photo, Unframed**\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1673535620/brigitte-bardot-bathtub-print-bathroom?click_key=8ef2964aeff41500951230dd90707a25%3ALT52d3df1c63dcd01a8d39f03589b595279bd0682a&click_sum=886921f6&ls=r&ref=related-3&pro=1&content_source=8ef2964aeff41500951230dd90707a25%253ALT52d3df1c63dcd01a8d39f03589b595279bd0682a "Brigitte Bardot Bathtub Print, Bathroom Poster, Black and White Wall Art, Vintage Print, Photography Prints Old Hollywood Photo, Unframed")




Add to Favorites


- [![Audrey Hepburn Lipstick Print, Black and White Wall Art, Vintage Print, Photography Prints, Museum Quality Photo, Feminist Print, Unframed](https://i.etsystatic.com/22158960/c/3000/2382/0/247/il/4e065c/5803628814/il_340x270.5803628814_a99j.jpg)\\
\\
**Audrey Hepburn Lipstick Print, Black and White Wall Art, Vintage Print, Photography Prints, Museum Quality Photo, Feminist Print, Unframed**\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1687654999/audrey-hepburn-lipstick-print-black-and?click_key=97c3763a2fba668653821f340804c92646b5e415%3A1687654999&click_sum=9929e9b4&ref=related-4&pro=1 "Audrey Hepburn Lipstick Print, Black and White Wall Art, Vintage Print, Photography Prints, Museum Quality Photo, Feminist Print, Unframed")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 9, 2025


[9195 favorites](https://www.etsy.com/listing/1769365473/better-late-than-ugly-audrey-hepburn/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=987012e3&%3Bls=s&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+aesthetic+dorm+posters+on+Etsy&%3Bref=search_grid-537162-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bpop=1&%3Bcontent_source=380eb05d-f8a5-4402-80db-7221526b7b32%253ALT9d1ccb24769ef2dd63f72283efac1f6599717c02&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=987012e3&%3Bls=s&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+aesthetic+dorm+posters+on+Etsy&%3Bref=search_grid-537162-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bpop=1&%3Bcontent_source=380eb05d-f8a5-4402-80db-7221526b7b32%253ALT9d1ccb24769ef2dd63f72283efac1f6599717c02&explicit=1&ref=breadcrumb_listing) [Wall Decor](https://www.etsy.com/c/home-and-living/home-decor/wall-decor?amp%3Bclick_sum=987012e3&%3Bls=s&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+aesthetic+dorm+posters+on+Etsy&%3Bref=search_grid-537162-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bpop=1&%3Bcontent_source=380eb05d-f8a5-4402-80db-7221526b7b32%253ALT9d1ccb24769ef2dd63f72283efac1f6599717c02&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Home Decor

[Vladimir Mika for Sale](https://www.etsy.com/market/vladimir_mika) [8 5x11 Red Frame for Sale](https://www.etsy.com/market/8_5x11_red_frame) [Longaberger 1999 - US](https://www.etsy.com/market/longaberger_1999) [Buy Brass Mirror Online](https://www.etsy.com/market/brass_mirror) [Gifts For A Financial Advisor - US](https://www.etsy.com/market/gifts_for_a_financial_advisor) [French Trumeau mirror Louis XVI antic trumeau mirror. french fireplace mirror Fireplace trumeau mirror style LOUIS XVI french antique mirror - Home Decor](https://www.etsy.com/listing/710346708/french-trumeau-mirror-louis-xvi-antic) [Shop Playboy Leds](https://www.etsy.com/market/playboy_leds) [Shop Farmhouse Valentine](https://www.etsy.com/market/farmhouse_valentine) [Metal Tile Wall Art for Sale](https://www.etsy.com/market/metal_tile_wall_art) [36 Inch Metal Outdoor Wall Art - US](https://www.etsy.com/market/36_inch_metal_outdoor_wall_art) [Shop Personalized Ham Radio](https://www.etsy.com/market/personalized_ham_radio) [Landshark Beer Signs - US](https://www.etsy.com/market/landshark_beer_signs) [Buy Purple Delft Tile Online](https://www.etsy.com/market/purple_delft_tile)

Toys

[Montessori Felt Book - US](https://www.etsy.com/market/montessori_felt_book)

Paper

[Shop Paper, Stationery & Cards from SisterPaperCoShop](https://www.etsy.com/shop/SisterPaperCoShop) [Zx10r Sticker - US](https://www.etsy.com/market/zx10r_sticker)

Womens Clothing

[Buy Dominatrix Starter Online](https://www.etsy.com/market/dominatrix_starter)

Fiber Arts

[Xoxo Needlepoint Candy Bars for Sale](https://www.etsy.com/market/xoxo_needlepoint_candy_bars)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1769365473%2Fbetter-late-than-ugly-audrey-hepburn%3Famp%253Bclick_sum%3D987012e3%26amp%253Bls%3Ds%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DFind%2B10%2Baesthetic%2Bdorm%2Bposters%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-537162-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bpop%3D1%26amp%253Bcontent_source%3D380eb05d-f8a5-4402-80db-7221526b7b32%25253ALT9d1ccb24769ef2dd63f72283efac1f6599717c02&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgxNTU2MzpkNjhjYzkyNzMxNjE4YTY0MjgzYzViNWQ5NjhmYTA2NQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1769365473%2Fbetter-late-than-ugly-audrey-hepburn%3Famp%253Bclick_sum%3D987012e3%26amp%253Bls%3Ds%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DFind%2B10%2Baesthetic%2Bdorm%2Bposters%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-537162-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bpop%3D1%26amp%253Bcontent_source%3D380eb05d-f8a5-4402-80db-7221526b7b32%25253ALT9d1ccb24769ef2dd63f72283efac1f6599717c02) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1769365473/better-late-than-ugly-audrey-hepburn?amp;click_sum=987012e3&amp;ls=s&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=Find+10+aesthetic+dorm+posters+on+Etsy&amp;ref=search_grid-537162-1-2&amp;sr_prefetch=1&amp;pf_from=search&amp;pro=1&amp;pop=1&amp;content_source=380eb05d-f8a5-4402-80db-7221526b7b32%253ALT9d1ccb24769ef2dd63f72283efac1f6599717c02#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1769365473%2Fbetter-late-than-ugly-audrey-hepburn%3Famp%253Bclick_sum%3D987012e3%26amp%253Bls%3Ds%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DFind%2B10%2Baesthetic%2Bdorm%2Bposters%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-537162-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bpop%3D1%26amp%253Bcontent_source%3D380eb05d-f8a5-4402-80db-7221526b7b32%25253ALT9d1ccb24769ef2dd63f72283efac1f6599717c02)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for PoppyBerryPrints

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: not accepted

Please contact the seller if you have any problems with your order.

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## Seller details

### Business registration number

### Location

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=272088489&referring_id=22158960&referring_type=shop&recipient_id=272088489&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: A black and white newspaper style print with the headline 'She Speaks Daily' and the subheading 'New Study Finds: BETTER LATE THAN UGLY'. The image shows a woman wearing sunglasses and a white towel on her head applying lipstick.](https://i.etsystatic.com/22158960/r/il/ecb83c/6156163356/il_300x300.6156163356_thix.jpg)
- ![May include: A black and white newspaper print with the headline 'She Speaks Daily' and the subheading 'New Study Finds: BETTER LATE THAN UGLY'. The image shows a woman wearing sunglasses and a towel on her head, applying lipstick with a brush.](https://i.etsystatic.com/22158960/r/il/7aa430/6204238883/il_300x300.6204238883_499p.jpg)
- ![May include: A black and white newspaper print with the headline 'She Speaks Daily' and the subheading 'New Study Finds: BETTER LATE THAN UGLY'. The image shows a woman wearing sunglasses and a white towel on her head, applying lipstick.](https://i.etsystatic.com/22158960/r/il/bda91d/6156163358/il_300x300.6156163358_tpmf.jpg)
- ![Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor image 4](https://i.etsystatic.com/22158960/r/il/de35ad/5791353623/il_300x300.5791353623_fqaw.jpg)

- ![](https://i.etsystatic.com/iap/362d30/6760337085/iap_640x640.6760337085_9tdnocdx.jpg?version=0)

5 out of 5 stars

- Sizes:

16" x 20"


Item was just like the description and I was very pleased with the final look.

Mar 13, 2025


[Lizabeth M Eden](https://www.etsy.com/people/lackeyliz1)

Purchased item:

[![Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor](https://i.etsystatic.com/22158960/r/il/ecb83c/6156163356/il_170x135.6156163356_thix.jpg)\\
\\
Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
(30% off)](https://www.etsy.com/listing/1769365473/better-late-than-ugly-audrey-hepburn?ref=ap-listing)

Purchased item:

[![Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor](https://i.etsystatic.com/22158960/r/il/ecb83c/6156163356/il_170x135.6156163356_thix.jpg)\\
\\
Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
(30% off)](https://www.etsy.com/listing/1769365473/better-late-than-ugly-audrey-hepburn?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/dc0bb7/6275924641/iap_640x640.6275924641_tqb6s2dm.jpg?version=0)

5 out of 5 stars

- Sizes:

10" x 15"


This is so perfect for the vision I had in my head

Aug 27, 2024


[Carli Stewart](https://www.etsy.com/people/cstewart3158)

Purchased item:

[![Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor](https://i.etsystatic.com/22158960/r/il/ecb83c/6156163356/il_170x135.6156163356_thix.jpg)\\
\\
Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
(30% off)](https://www.etsy.com/listing/1769365473/better-late-than-ugly-audrey-hepburn?ref=ap-listing)

Purchased item:

[![Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor](https://i.etsystatic.com/22158960/r/il/ecb83c/6156163356/il_170x135.6156163356_thix.jpg)\\
\\
Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
(30% off)](https://www.etsy.com/listing/1769365473/better-late-than-ugly-audrey-hepburn?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/fd600e/6835653323/iap_640x640.6835653323_648k77nm.jpg?version=0)

5 out of 5 stars

- Sizes:

16" x 20"


Perfect for my wall 10/10

Apr 12, 2025


[Hannah McBirney](https://www.etsy.com/people/meltinginnevada)

Purchased item:

[![Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor](https://i.etsystatic.com/22158960/r/il/ecb83c/6156163356/il_170x135.6156163356_thix.jpg)\\
\\
Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
(30% off)](https://www.etsy.com/listing/1769365473/better-late-than-ugly-audrey-hepburn?ref=ap-listing)

Purchased item:

[![Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor](https://i.etsystatic.com/22158960/r/il/ecb83c/6156163356/il_170x135.6156163356_thix.jpg)\\
\\
Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
(30% off)](https://www.etsy.com/listing/1769365473/better-late-than-ugly-audrey-hepburn?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/3f9003/6562742800/iap_640x640.6562742800_k9l6cssi.jpg?version=0)

5 out of 5 stars

- Sizes:

16" x 20"


Looks great in my bathroom!

Jan 12, 2025


[Tricia Belanger](https://www.etsy.com/people/f2mu7xrum6jarjjv)

Purchased item:

[![Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor](https://i.etsystatic.com/22158960/r/il/ecb83c/6156163356/il_170x135.6156163356_thix.jpg)\\
\\
Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
(30% off)](https://www.etsy.com/listing/1769365473/better-late-than-ugly-audrey-hepburn?ref=ap-listing)

Purchased item:

[![Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor](https://i.etsystatic.com/22158960/r/il/ecb83c/6156163356/il_170x135.6156163356_thix.jpg)\\
\\
Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
(30% off)](https://www.etsy.com/listing/1769365473/better-late-than-ugly-audrey-hepburn?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/16e0c4/6861098207/iap_640x640.6861098207_3porev4n.jpg?version=0)

5 out of 5 stars

- Sizes:

18" x 24"


Great print, would highly recommend!

![](https://i.etsystatic.com/iusa/ab26e9/66163373/iusa_75x75.66163373_gcyy.jpg?version=0)

Apr 23, 2025


[Zina Kukharenka](https://www.etsy.com/people/uaoyez9z)

Purchased item:

[![Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor](https://i.etsystatic.com/22158960/r/il/ecb83c/6156163356/il_170x135.6156163356_thix.jpg)\\
\\
Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
(30% off)](https://www.etsy.com/listing/1769365473/better-late-than-ugly-audrey-hepburn?ref=ap-listing)

Purchased item:

[![Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor](https://i.etsystatic.com/22158960/r/il/ecb83c/6156163356/il_170x135.6156163356_thix.jpg)\\
\\
Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
(30% off)](https://www.etsy.com/listing/1769365473/better-late-than-ugly-audrey-hepburn?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/5f36af/6729001675/iap_640x640.6729001675_gtsm8trb.jpg?version=0)

5 out of 5 stars

- Sizes:

11" x 14"


Love it so much!!

![](https://i.etsystatic.com/iusa/13c87b/112777221/iusa_75x75.112777221_boce.jpg?version=0)

Feb 28, 2025


[Lauren Cabrera](https://www.etsy.com/people/lzw1zokb)

Purchased item:

[![Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor](https://i.etsystatic.com/22158960/r/il/ecb83c/6156163356/il_170x135.6156163356_thix.jpg)\\
\\
Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
(30% off)](https://www.etsy.com/listing/1769365473/better-late-than-ugly-audrey-hepburn?ref=ap-listing)

Purchased item:

[![Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor](https://i.etsystatic.com/22158960/r/il/ecb83c/6156163356/il_170x135.6156163356_thix.jpg)\\
\\
Better Late Than Ugly, Audrey Hepburn Lipstick Print, Trendy Newspaper Print, Funny Wall Art Decor, Women Empowerment, Girls Room decor\\
\\
Sale Price $11.19\\
$11.19\\
\\
$15.99\\
Original Price $15.99\\
\\
\\
(30% off)](https://www.etsy.com/listing/1769365473/better-late-than-ugly-audrey-hepburn?ref=ap-listing)