[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1406358019/dainty-pearl-stud-earrings-by-caitlyn?amp;click_sum=4e479b0c&amp;ls=a&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=List+10+minimalist+pearl+stud+earrings+from+Etsy&amp;ref=search_grid-718053-1-1&amp;sr_prefetch=1&amp;pf_from=search&amp;pro=1&amp;frs=1&amp;pop=1&amp;sts=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Jewelry](https://www.etsy.com/c/jewelry?amp%3Bclick_sum=4e479b0c&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=List+10+minimalist+pearl+stud+earrings+from+Etsy&%3Bref=search_grid-718053-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bfrs=1&%3Bpop=1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-0)
- [Earrings](https://www.etsy.com/c/jewelry/earrings?amp%3Bclick_sum=4e479b0c&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=List+10+minimalist+pearl+stud+earrings+from+Etsy&%3Bref=search_grid-718053-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bfrs=1&%3Bpop=1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-1)
- [Stud Earrings](https://www.etsy.com/c/jewelry/earrings/stud-earrings?amp%3Bclick_sum=4e479b0c&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=List+10+minimalist+pearl+stud+earrings+from+Etsy&%3Bref=search_grid-718053-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bfrs=1&%3Bpop=1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-2)

Etsy’s Pick

Etsy’s Picks are hand selected by our style experts to highlight items from shops that have shown quality, reliability and style.

[Discover More](https://www.etsy.com/featured/hub/etsy-picks?ref=listing_etsys_pick_signal)


Add to Favorites


- ![May include: A pair of small, round pearl earrings in a silver setting.](https://i.etsystatic.com/10204022/r/il/5668fb/4648000456/il_794xN.4648000456_3mmm.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![May include: Two small pearl earrings with gold posts. The pearls are white and round. The earrings are on a textured, light brown surface.](https://i.etsystatic.com/10204022/r/il/581666/4637216728/il_794xN.4637216728_p93p.jpg)
- ![May include: A close-up of a person's ear with a small, round, silver stud earring.](https://i.etsystatic.com/10204022/r/il/e6f530/4637215682/il_794xN.4637215682_c806.jpg)
- ![May include: Three pairs of pearl stud earrings on a white square pedestal. The earrings are gold and have small white pearls.](https://i.etsystatic.com/10204022/r/il/072a9f/4637182638/il_794xN.4637182638_28z6.jpg)
- ![May include: A gold ring with a small pearl on the side.](https://i.etsystatic.com/10204022/r/il/8fb610/4637215532/il_794xN.4637215532_ffmw.jpg)
- ![May include: Two small white pearl earrings on a dried brown stem.](https://i.etsystatic.com/10204022/r/il/444a0f/4637238018/il_794xN.4637238018_pw1h.jpg)
- ![May include: A woman with long brown hair wearing a light beige shirt and small diamond stud earrings.](https://i.etsystatic.com/10204022/r/il/0e5959/4637191234/il_794xN.4637191234_drp8.jpg)
- ![May include: Two small pearl earrings with gold posts on a brown surface.](https://i.etsystatic.com/10204022/r/il/c578af/4637198244/il_794xN.4637198244_qj56.jpg)
- ![May include: A close-up of a person's ear with a small, round, white pearl stud earring.](https://i.etsystatic.com/10204022/r/il/d6c2d1/4647681478/il_794xN.4647681478_9vsl.jpg)
- ![Dainty Pearl Stud Earrings by Caitlyn Minimalist • Everyday Pearl Jewelry • Minimalist Stacking Earrings • Bridesmaid Proposal Gifts • ER316 image 10](https://i.etsystatic.com/10204022/r/il/4d7bd6/6705631686/il_794xN.6705631686_411z.jpg)

- ![May include: A pair of small, round pearl earrings in a silver setting.](https://i.etsystatic.com/10204022/c/1377/1094/771/635/il/5668fb/4648000456/il_75x75.4648000456_3mmm.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/JAN20_4_c9mosh.jpg)

- ![May include: Two small pearl earrings with gold posts. The pearls are white and round. The earrings are on a textured, light brown surface.](https://i.etsystatic.com/10204022/r/il/581666/4637216728/il_75x75.4637216728_p93p.jpg)
- ![May include: A close-up of a person's ear with a small, round, silver stud earring.](https://i.etsystatic.com/10204022/r/il/e6f530/4637215682/il_75x75.4637215682_c806.jpg)
- ![May include: Three pairs of pearl stud earrings on a white square pedestal. The earrings are gold and have small white pearls.](https://i.etsystatic.com/10204022/r/il/072a9f/4637182638/il_75x75.4637182638_28z6.jpg)
- ![May include: A gold ring with a small pearl on the side.](https://i.etsystatic.com/10204022/r/il/8fb610/4637215532/il_75x75.4637215532_ffmw.jpg)
- ![May include: Two small white pearl earrings on a dried brown stem.](https://i.etsystatic.com/10204022/c/1500/1192/801/762/il/444a0f/4637238018/il_75x75.4637238018_pw1h.jpg)
- ![May include: A woman with long brown hair wearing a light beige shirt and small diamond stud earrings.](https://i.etsystatic.com/10204022/r/il/0e5959/4637191234/il_75x75.4637191234_drp8.jpg)
- ![May include: Two small pearl earrings with gold posts on a brown surface.](https://i.etsystatic.com/10204022/r/il/c578af/4637198244/il_75x75.4637198244_qj56.jpg)
- ![May include: A close-up of a person's ear with a small, round, white pearl stud earring.](https://i.etsystatic.com/10204022/r/il/d6c2d1/4647681478/il_75x75.4647681478_9vsl.jpg)
- ![Dainty Pearl Stud Earrings by Caitlyn Minimalist • Everyday Pearl Jewelry • Minimalist Stacking Earrings • Bridesmaid Proposal Gifts • ER316 image 10](https://i.etsystatic.com/10204022/r/il/4d7bd6/6705631686/il_75x75.6705631686_411z.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1406358019%2Fdainty-pearl-stud-earrings-by-caitlyn%23report-overlay-trigger)

In 6 carts

Price:$17.62


Original Price:
$23.50


Loading


25% off


# Dainty Pearl Stud Earrings by Caitlyn Minimalist • Everyday Pearl Jewelry • Minimalist Stacking Earrings • Bridesmaid Proposal Gifts • ER316

Made by [CaitlynMinimalist](https://www.etsy.com/shop/CaitlynMinimalist)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1406358019/dainty-pearl-stud-earrings-by-caitlyn?amp;click_sum=4e479b0c&amp;ls=a&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=List+10+minimalist+pearl+stud+earrings+from+Etsy&amp;ref=search_grid-718053-1-1&amp;sr_prefetch=1&amp;pf_from=search&amp;pro=1&amp;frs=1&amp;pop=1&amp;sts=1#reviews)

Arrives soon! Get it by

Nov 13-20


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

FINISH


Select an option

18K GOLD

STERLING SILVER

Please select an option


Quantity



123456789101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899100101102103104105106107108109110111112113114115116117118119120121122123124125126127128129130131132133134135136137138139140141142143144145146147148149150151152153154155156157158159160161162163164165166167168169170171172173174175176177178179180181182183184185186187188189190191192193194195196197198199200201202203204205206207208209210211212213214215216217218219220221222223224225226227228229230231232233234235236237238239240241242243244245246247248249250251252253254255256257258259260261262263264265266267268269270271272273274275276277278279280281282283284285286287288289290291292293294295296297298299300301302303304305306307308309310311312313314315316317318319320321322323324325326327328329330331332333334335336337338339340341342343344345346347348349350351352353354355356357358359360361362363364365366367368369370371372373374375376377378379380381382383384385386387388389390391392393394395396397398399400401402403404405406407408409410411412413414415416417418419420421422423424425426427428429430431432433434435436437438439440441442443444445446447448449450451452453454455456457458459460461462463464465466467468469470471472473474475476477478479480481482483484485486487488489490491492493494495496497498499500501502503504505506507508509510511512513514515516517518519520521522523524525526527528529530531532533534535536537538539540541542543544545546547548549550551552553554555556557558559560561562563564565566567568569570571572573574575576577578579580581582583584585586587588589590591592593594595596597598599600601602603604605606607608609610611612613614615616617618619620621622623624625626627628629630631632633634635636637638639640641642643644645646647648649650651652653654655656657658659660661662663664665666667668669670671672673674675676677678679680681682683684685686687688689690691692693694695696697698699700701702703704705706707708709710711712713714715716717718719720721722723724725726727728729730731732733734735736737738739740741742743744745746747748749750751752753754755756757758759760761762763764765766767768769770771772773774775776777778779780781782783784785786787788789790791792793794795796797798799800801802803804805806807808809810811812813814815816817818819820821822823824825826827828829830831832833834835836837838839840841842843844845846847848849850851852853854855856857858859860861862863864865866867868869870871872873874875876877878879880881882883884885886887888889890891892893894895896897898899900901902903904905906907908909910911912913914915916917918919920921922923924925926927928929930931932933934935936937938939940941942943944945946947948949950951952953954955956957958959960961962963

You can only make an offer when buying a single item


Add to cart



Loading


## Buy together, get 40% off

![Dainty Pearl Stud Earrings by Caitlyn Minimalist • Everyday Pearl Jewelry • Minimalist Stacking Earrings • Bridesmaid Proposal Gifts • ER316](https://i.etsystatic.com/10204022/c/1377/1094/771/635/il/5668fb/4648000456/il_340x270.4648000456_3mmm.jpg)
This listing

### Dainty Pearl Stud Earrings by Caitlyn Minimalist • Everyday Pearl Jewelry • Minimalist Stacking Earrings • Bridesmaid Proposal Gifts • ER316

Sale Price $14.10
$14.10

$23.50
Original Price $23.50


40% off "buy together" offer


Add to Favorites


[![Huggie Earrings by Caitlyn Minimalist • Most Favorited Huggie Hoop Earrings • Perfect Addition to Any Stack, Everyday Earrings • ER007](https://i.etsystatic.com/10204022/c/2542/2020/228/336/il/face59/5223845674/il_340x270.5223845674_4e07.jpg)\\
\\
**Huggie Earrings by Caitlyn Minimalist • Most Favorited Huggie Hoop Earrings • Perfect Addition to Any Stack, Everyday Earrings • ER007**\\
\\
Sale Price $12.30\\
$12.30\\
\\
$20.50\\
Original Price $20.50\\
\\
\\
40% off "buy together" offer](https://www.etsy.com/listing/845499603/huggie-earrings-by-caitlyn-minimalist?click_key=652e2bb21a518befd7ab40585d3ed3e4bd8b9e01%3A845499603&click_sum=1742a8aa&ref=lp_mix_and_match_bundle-2&pro=1&sts=1&mnm=1 "Huggie Earrings by Caitlyn Minimalist • Most Favorited Huggie Hoop Earrings • Perfect Addition to Any Stack, Everyday Earrings • ER007")


Add to Favorites


[![Tiny Diamond Studs by Caitlyn Minimalist • Dainty Gold Stud Earrings • Everyday Jewelry • Perfect for Earring Stacks • Gifts for Mom • ER124](https://i.etsystatic.com/10204022/c/2068/1644/548/671/il/799397/3414619262/il_340x270.3414619262_salk.jpg)\\
\\
**Tiny Diamond Studs by Caitlyn Minimalist • Dainty Gold Stud Earrings • Everyday Jewelry • Perfect for Earring Stacks • Gifts for Mom • ER124**\\
\\
Sale Price $14.10\\
$14.10\\
\\
$23.50\\
Original Price $23.50\\
\\
\\
40% off "buy together" offer](https://www.etsy.com/listing/1006317585/tiny-diamond-studs-by-caitlyn-minimalist?click_key=a7a2bc913d0243983a2b6f3a487c6a3972a3ea76%3A1006317585&click_sum=f2949d86&ref=lp_mix_and_match_bundle-3&pro=1&sts=1&mnm=1 "Tiny Diamond Studs by Caitlyn Minimalist • Dainty Gold Stud Earrings • Everyday Jewelry • Perfect for Earring Stacks • Gifts for Mom • ER124")


Add to Favorites


![Dainty Pearl Stud Earrings by Caitlyn Minimalist • Everyday Pearl Jewelry • Minimalist Stacking Earrings • Bridesmaid Proposal Gifts • ER316](https://i.etsystatic.com/10204022/c/1377/1094/771/635/il/5668fb/4648000456/il_340x270.4648000456_3mmm.jpg)
This listing

### Dainty Pearl Stud Earrings by Caitlyn Minimalist • Everyday Pearl Jewelry • Minimalist Stacking Earrings • Bridesmaid Proposal Gifts • ER316

Sale Price $14.10
$14.10

$23.50
Original Price $23.50


40% off "buy together" offer


Add to Favorites


[![Huggie Earrings by Caitlyn Minimalist • Most Favorited Huggie Hoop Earrings • Perfect Addition to Any Stack, Everyday Earrings • ER007](https://i.etsystatic.com/10204022/c/2542/2020/228/336/il/face59/5223845674/il_340x270.5223845674_4e07.jpg)\\
\\
**Huggie Earrings by Caitlyn Minimalist • Most Favorited Huggie Hoop Earrings • Perfect Addition to Any Stack, Everyday Earrings • ER007**\\
\\
Sale Price $12.30\\
$12.30\\
\\
$20.50\\
Original Price $20.50\\
\\
\\
40% off "buy together" offer](https://www.etsy.com/listing/845499603/huggie-earrings-by-caitlyn-minimalist?click_key=652e2bb21a518befd7ab40585d3ed3e4bd8b9e01%3A845499603&click_sum=1742a8aa&ref=lp_mix_and_match_bundle-2&pro=1&sts=1&mnm=1 "Huggie Earrings by Caitlyn Minimalist • Most Favorited Huggie Hoop Earrings • Perfect Addition to Any Stack, Everyday Earrings • ER007")


Add to Favorites


[![Tiny Diamond Studs by Caitlyn Minimalist • Dainty Gold Stud Earrings • Everyday Jewelry • Perfect for Earring Stacks • Gifts for Mom • ER124](https://i.etsystatic.com/10204022/c/2068/1644/548/671/il/799397/3414619262/il_340x270.3414619262_salk.jpg)\\
\\
**Tiny Diamond Studs by Caitlyn Minimalist • Dainty Gold Stud Earrings • Everyday Jewelry • Perfect for Earring Stacks • Gifts for Mom • ER124**\\
\\
Sale Price $14.10\\
$14.10\\
\\
$23.50\\
Original Price $23.50\\
\\
\\
40% off "buy together" offer](https://www.etsy.com/listing/1006317585/tiny-diamond-studs-by-caitlyn-minimalist?click_key=a7a2bc913d0243983a2b6f3a487c6a3972a3ea76%3A1006317585&click_sum=f2949d86&ref=lp_mix_and_match_bundle-3&pro=1&sts=1&mnm=1 "Tiny Diamond Studs by Caitlyn Minimalist • Dainty Gold Stud Earrings • Everyday Jewelry • Perfect for Earring Stacks • Gifts for Mom • ER124")


Add to Favorites


![Dainty Pearl Stud Earrings by Caitlyn Minimalist • Everyday Pearl Jewelry • Minimalist Stacking Earrings • Bridesmaid Proposal Gifts • ER316](https://i.etsystatic.com/10204022/c/1377/1094/771/635/il/5668fb/4648000456/il_340x270.4648000456_3mmm.jpg)
This listing

### Dainty Pearl Stud Earrings by Caitlyn Minimalist • Everyday Pearl Jewelry • Minimalist Stacking Earrings • Bridesmaid Proposal Gifts • ER316

Sale Price $14.10
$14.10

$23.50
Original Price $23.50


40% off "buy together" offer


Add to Favorites


[![Huggie Earrings by Caitlyn Minimalist • Most Favorited Huggie Hoop Earrings • Perfect Addition to Any Stack, Everyday Earrings • ER007](https://i.etsystatic.com/10204022/c/2542/2020/228/336/il/face59/5223845674/il_340x270.5223845674_4e07.jpg)\\
\\
**Huggie Earrings by Caitlyn Minimalist • Most Favorited Huggie Hoop Earrings • Perfect Addition to Any Stack, Everyday Earrings • ER007**\\
\\
Sale Price $12.30\\
$12.30\\
\\
$20.50\\
Original Price $20.50\\
\\
\\
40% off "buy together" offer](https://www.etsy.com/listing/845499603/huggie-earrings-by-caitlyn-minimalist?click_key=b9e24d751d71c9d8075c101776818968542c3636%3A845499603&click_sum=a5959252&ref=lp_mix_and_match_bundle-2&pro=1&sts=1&mnm=1 "Huggie Earrings by Caitlyn Minimalist • Most Favorited Huggie Hoop Earrings • Perfect Addition to Any Stack, Everyday Earrings • ER007")


Add to Favorites


[![Tiny Diamond Studs by Caitlyn Minimalist • Dainty Gold Stud Earrings • Everyday Jewelry • Perfect for Earring Stacks • Gifts for Mom • ER124](https://i.etsystatic.com/10204022/c/2068/1644/548/671/il/799397/3414619262/il_340x270.3414619262_salk.jpg)\\
\\
**Tiny Diamond Studs by Caitlyn Minimalist • Dainty Gold Stud Earrings • Everyday Jewelry • Perfect for Earring Stacks • Gifts for Mom • ER124**\\
\\
Sale Price $14.10\\
$14.10\\
\\
$23.50\\
Original Price $23.50\\
\\
\\
40% off "buy together" offer](https://www.etsy.com/listing/1006317585/tiny-diamond-studs-by-caitlyn-minimalist?click_key=1b2dfa12c1e9829a8d607190f064d018f16ac1aa%3A1006317585&click_sum=0e5bfe6f&ref=lp_mix_and_match_bundle-3&pro=1&sts=1&mnm=1 "Tiny Diamond Studs by Caitlyn Minimalist • Dainty Gold Stud Earrings • Everyday Jewelry • Perfect for Earring Stacks • Gifts for Mom • ER124")


Add to Favorites


Original value: $67.50


New total: $40.50


Add all to cart



Loading


## Item details

### Highlights

Made by [CaitlynMinimalist](https://www.etsy.com/shop/CaitlynMinimalist)

- Materials: Silver, Yellow gold

- Gemstone: Pearl

- Location: Cartilage, Earlobe, Tragus

- Closure: Push back

- Style: Minimalist

- Gift wrapping available

See details![](https://i.etsystatic.com/igwp/278218/6131896570/igwp_300xN.6131896570_t23r22ok.jpg?version=0)

Gift wrapping by CaitlynMinimalist

Your items will packed in gift boxes and wrapped with ribbon ♡ Ordering multiple? Leave a note at checkout and we'll label each box with its name.

P E A R L ∙ S T U D ∙ E A R R I N G S

These delicate pearl stud earrings are easy to pair and stack with other pieces in your collection. Wear in the first piercing for a minimalist look or mix and match in multiple piercings to create your own unique set.

• Material: High Quality Solid 925 Sterling Silver

• Finish: Sterling Silver ∙ 18K Gold

• Featuring ~3.5mm Pearl Stud Earrings \| Sold as a Pair

O T H E R ∙ I N F O R M A T I O N

• All items are nicely packaged Ready to Gift in elegant, reusable and recyclable jewelry boxes ♡

• Gift Wrapping with ribbon is available at check out ♡ Ordering multiple pieces? Leave a note at checkout and we'll discreetly label each box with its name.

• Have any questions or need advice on your custom design? Feel free to contact us. We are fast to reply :)

T U R N ∙ A R O U N D ∙ T I M E

• This design is ready to ship in 1 - 2 business days. If you have custom made items in your cart, your order will be separated into two shipments (for U.S. orders only). Our turnaround time is about 6 - 9 business days for custom made designs. This can change during peak seasons. Please check our home page for the most current times.

M O R E ∙ F R O M ∙ U S

[https://www.etsy.com/shop/CaitlynMinimalist](https://www.etsy.com/shop/CaitlynMinimalist)

IG: @CaitlynMinimalist

Thank you so much for visiting and hope you enjoy shopping with us ♡

Kate ♡

\-\-\--------------------------------------------

• All images are copyrighted by CaitlynMinimalist. All rights reserved •


## Shipping and return policies

Loading


- Order today to get by

**Nov 13-20**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 14 days


- Free shipping


- Ships from: **Irvine, CA**


Deliver to United States

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------ArgentinaAustraliaAustriaBelgiumBrazilCanadaChileChinaColombiaCosta RicaCroatiaCyprusCzech RepublicDenmarkEstoniaFinlandFranceGeorgiaGermanyGreeceGreenlandGuamHong KongHungaryIcelandIndonesiaIrelandIsraelItalyJapanLatviaLiechtensteinLithuaniaLuxembourgMacaoMalaysiaMaldivesMaltaMartiniqueMexicoMoldovaMoroccoNew CaledoniaNew ZealandNorwayPhilippinesPolandPortugalPuerto RicoQatarRomaniaSaudi ArabiaSerbiaSingaporeSlovakiaSloveniaSouth AfricaSouth KoreaSpainSwedenSwitzerlandTaiwanThailandThe NetherlandsTürkiyeUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsU.S. Virgin IslandsVietnam

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## FAQs

► HOW TO SEND AN IMAGE


1st Method:

• Send your image of Handwriting, Drawing and Fingerprints by contacting us from our Etsy storefront or directly from your order receipt found in your purchase history.

• Simply attach and send the image(s) in the message thread.

2nd Method:

• An email attachment with the file can also be sent to our email address at caitlynminimalist.etsy@gmail.com

• To help speed up the process: Contact us from the same email used to login to your Etsy account and include your order number in the subject line so that we can link the images to your order

More tips:

• Images can be sent before or after your order is placed

• We accept most file types- JPG, JPEG, PNG or PDF files are preferred.


► IMAGE GUIDELINES FOR CUSTOM JEWELRY


• For the best results, it is ideal to provide a high quality image that is in-focus and in good lighting conditions.

• We typically don’t have set design or character limits, as every piece of custom text, handwriting and drawing is unique to each order

• We are able to crop out any unwanted text surrounding the handwriting and we can even take individual words and letters and create phrases with them. We can also combine multiple images of handwriting for one piece of jewelry.

Feel free to send us your image/personalization request before ordering. We can let you know if it will work on your jewelry or if we recommend adjustments for the best results

• We accept designs in ANY language, writing style (cursive, print, etc) or drawing


► MEASURE & SIZE GUIDE


• BRACELETS \| We recommend ordering a size that is roughly 1/2 inch - 1 inch larger than one’s actual wrist size for a comfortable fit. Our chain bracelets come with an 1” extension piece so the fit can be adjusted further

• NECKLACES \| All lengths are measured in inches and include the CHARM + CHAIN combined to equal the length you choose. Our chain necklaces also come with an 1” extension piece so the fit can be adjusted further

• RINGS \| We create all our rings true to standard US sizing. For the most accurate fit, we suggest having your fingers sized. You can visit a local jeweler to have your desired finger sized or you can measure with a physical ring sizer, which is available for purchase (https://etsy.me/3DR8v9Q)


► PROCESSING TIME & STATUS


All of our pieces are handmade with care and well worth the wait. Please be advised that expedited shipping speeds up transit times only and does not speed up our processing times found below:

• Ready-to-ship items are processed + shipped in 1 business day. RTS items are shipped out first if ordered with any custom-made items (for U.S Orders only).

• Custom-made items are made to order and processed + shipped within 6 to 9 business days. An item that is “made-to-order” is denoted in the listings detail section

ᴘʀᴏᴄᴇꜱꜱɪɴɢ ᴛɪᴍᴇ \+ ᴛʀᴀɴꜱɪᴛ ᴛɪᴍᴇ = ᴇꜱᴛɪᴍᴀᴛᴇᴅ ᴅᴀᴛᴇ ᴏꜰ ᴀʀʀɪᴠᴀʟ

You can find your order’s current status by visiting your purchase history when logged into your account.


► MATERIAL & JEWELRY CARE


Almost all of our items are created with 925 solid sterling silver. Our gold products are crafted with a finish of 18K gold over our solid 925 solid sterling silver base. We don’t use any nickel in our silver so our jewelry is safe on most sensitive skin.

We recommend taking your jewelry off when you’re about to come in contact with water (showering, swimming, washing hands, etc) for the best care of your piece. When you are not wearing your jewelry, we recommend storing your jewelry in airtight storage, like your Caitlyn Minimalist pouch & gift box which is provided with every item.


► RETURN & WARRANTY POLICY


All of our items are covered by a 90-day quality guarantee!

Returns are accepted within 14 days from delivery for store credit or exchange. Items are to be in mint condition and in original packaging. Buyers are responsible for return shipping costs. To start a return, please contact our team within the return window.

Please note, items marked 'Final Sale' are not eligible for return. Exchanges also cannot be returned a second time.

Our jewelry is designed with high-quality materials and made to last. If you have any concerns, we're here to help—just reach out! ♡


► Why did I only receive some of the items in my order?


We ship out all ready to ship designs in your order first for U.S. orders. Made-to-order designs will ship separately according to current turnaround estimates. Your shipping confirmation email will show every piece in your order, however, it won’t be reflective of what’s in your first package!

For any other concerns, feel free to email us, we are here to help :)

\\_\\_\\_\_\_\_\_\_\_\_\_\_\_\_\_

Have any more questions? Feel free to contact us here: https://etsy.me/3vEmQmi

CaitlynMinimalist.com

Jewelry Crafted with Love 🤍


## Reviews for this item (605)

4.9/5

item average

4.9Item quality

4.9Shipping

4.9Customer service

98%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Love it

Beautiful

Dainty

Cute

Great quality

Fast shipping

As described


Filter by category


Appearance (215)


Quality (108)


Shipping & Packaging (84)


Description accuracy (82)


Sizing & Fit (55)


Comfort (36)


Seller service (33)


Value (12)


Ease of use (3)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/e10ab3/71040561/iusa_75x75.71040561_r1km.jpg?version=0)

[Georgia Carpenter](https://www.etsy.com/people/georgiacarpenter?ref=l_review)
Nov 1, 2025


Dainty and delicate!! Just as I had hoped for! I love them!



![](https://i.etsystatic.com/iusa/e10ab3/71040561/iusa_75x75.71040561_r1km.jpg?version=0)

[Georgia Carpenter](https://www.etsy.com/people/georgiacarpenter?ref=l_review)
Nov 1, 2025


5 out of 5 stars
5

This item

[ann](https://www.etsy.com/people/lfmi7ongjsxlgemg?ref=l_review)
Oct 31, 2025


Excellent product and great service



[ann](https://www.etsy.com/people/lfmi7ongjsxlgemg?ref=l_review)
Oct 31, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/7d5a24/108120332/iusa_75x75.108120332_fbfn.jpg?version=0)

[Leanna Prather](https://www.etsy.com/people/leannaprather?ref=l_review)
Oct 30, 2025


Beautiful and perfect for what I need them for!



![](https://i.etsystatic.com/iusa/7d5a24/108120332/iusa_75x75.108120332_fbfn.jpg?version=0)

[Leanna Prather](https://www.etsy.com/people/leannaprather?ref=l_review)
Oct 30, 2025


5 out of 5 stars
5

This item

[M. Harvey](https://www.etsy.com/people/jdillard410?ref=l_review)
Oct 29, 2025


Beautiful jewelry! Love this seller and the craftsmanship!



[M. Harvey](https://www.etsy.com/people/jdillard410?ref=l_review)
Oct 29, 2025


View all reviews for this item

### Photos from reviews

![Ruthy added a photo of their purchase](https://i.etsystatic.com/iap/caee2b/4821136056/iap_300x300.4821136056_26g0q1j6.jpg?version=0)

![Stephanie added a photo of their purchase](https://i.etsystatic.com/iap/0c581e/5843753695/iap_300x300.5843753695_oew11f9y.jpg?version=0)

![jmsatterfield2012 added a photo of their purchase](https://i.etsystatic.com/iap/4265d3/6051366152/iap_300x300.6051366152_7slhjyvj.jpg?version=0)

![Ginni added a photo of their purchase](https://i.etsystatic.com/iap/ca4636/5707365605/iap_300x300.5707365605_nxvr4upp.jpg?version=0)

![Emma added a photo of their purchase](https://i.etsystatic.com/iap/f0cf11/7269750799/iap_300x300.7269750799_8zrvurlj.jpg?version=0)

![Bailey added a photo of their purchase](https://i.etsystatic.com/iap/a7d421/5942007524/iap_300x300.5942007524_tjbvq7rz.jpg?version=0)

![Anca added a photo of their purchase](https://i.etsystatic.com/iap/3b9b0c/6428041984/iap_300x300.6428041984_nwc9t49a.jpg?version=0)

![Ashley added a photo of their purchase](https://i.etsystatic.com/iap/f00343/7224277676/iap_300x300.7224277676_6n82w7yf.jpg?version=0)

![Marianne added a photo of their purchase](https://i.etsystatic.com/iap/ddcb1f/5502384683/iap_300x300.5502384683_edzl7tfm.jpg?version=0)

![Sara added a photo of their purchase](https://i.etsystatic.com/iap/e22ffd/5542697633/iap_300x300.5542697633_q9jhn4k3.jpg?version=0)

![Jonathan added a photo of their purchase](https://i.etsystatic.com/iap/38c183/6185078923/iap_300x300.6185078923_iy3baqpz.jpg?version=0)

![Makaylah added a photo of their purchase](https://i.etsystatic.com/iap/3b5847/5637037191/iap_300x300.5637037191_26yn5y7a.jpg?version=0)

![Taylor added a photo of their purchase](https://i.etsystatic.com/iap/f1ac21/5840053502/iap_300x300.5840053502_5v0kyxm8.jpg?version=0)

![Emilie added a photo of their purchase](https://i.etsystatic.com/iap/ce6af3/6839577939/iap_300x300.6839577939_1wwz6l1n.jpg?version=0)

![Brooke added a photo of their purchase](https://i.etsystatic.com/iap/d2ada2/6912291442/iap_300x300.6912291442_xgerc8ia.jpg?version=0)

![Jennifer added a photo of their purchase](https://i.etsystatic.com/iap/e1baa8/5763004705/iap_300x300.5763004705_c6cvcamt.jpg?version=0)

![Vicky added a photo of their purchase](https://i.etsystatic.com/iap/5efbc1/6693377688/iap_300x300.6693377688_o6cxm83b.jpg?version=0)

![Elise added a photo of their purchase](https://i.etsystatic.com/iap/083a9e/5142817213/iap_300x300.5142817213_pwfajeva.jpg?version=0)

![Lori added a photo of their purchase](https://i.etsystatic.com/iap/f4d22a/6330924879/iap_300x300.6330924879_cbsf03jo.jpg?version=0)

![Kenzie added a photo of their purchase](https://i.etsystatic.com/iap/dcfa36/6836429109/iap_300x300.6836429109_9wrhmjhg.jpg?version=0)

[![CaitlynMinimalist](https://i.etsystatic.com/iusa/5f7177/111800322/iusa_75x75.111800322_ictu.jpg?version=0)](https://www.etsy.com/shop/CaitlynMinimalist?ref=shop_profile&listing_id=1406358019)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[CaitlynMinimalist](https://www.etsy.com/shop/CaitlynMinimalist?ref=shop_profile&listing_id=1406358019)

[Owned by Kate Kim](https://www.etsy.com/shop/CaitlynMinimalist?ref=shop_profile&listing_id=1406358019) \|

Los Angeles, California

4.8
(711.3k)


3.6M sales

11 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=55496650&referring_id=1406358019&referring_type=listing&recipient_id=55496650&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo1NTQ5NjY1MDoxNzYyODE1NzYxOjIxNDg1NTgwOTNiZGYyOWM2YTdiOTdkYzM5MDIzNmEx&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1406358019%2Fdainty-pearl-stud-earrings-by-caitlyn%3Famp%253Bclick_sum%3D4e479b0c%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DList%2B10%2Bminimalist%2Bpearl%2Bstud%2Bearrings%2Bfrom%2BEtsy%26amp%253Bref%3Dsearch_grid-718053-1-1%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bfrs%3D1%26amp%253Bpop%3D1%26amp%253Bsts%3D1)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

Loading recommendations

Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading


- Loading









Loading



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading wedding form

Loading


## Top wedding searches to shop

[![](https://i.etsystatic.com/19757930/c/1333/1333/0/301/il/cfe72f/3482678762/il_300x300.3482678762_pxw3.jpg)\\
Bridesmaid gifts](https://www.etsy.com/search?q=bridesmaid+gifts&mosv=sese&moci=635510339037&mosi=618520640322&featured_listing=1110003408&ref=wedding_recs_lp_bridesmaid_gifts)

[![](https://i.etsystatic.com/19483987/r/il/42cd8d/2512481731/il_300x300.2512481731_8gz7.jpg)\\
Groomsmen gifts](https://www.etsy.com/search?q=groomsmen+gifts&mosv=sese&moci=635510339037&mosi=635510910189&featured_listing=761677858&ref=wedding_recs_lp_groomsmen_gifts)

[![](https://i.etsystatic.com/6748817/c/2000/2000/0/828/il/b140dc/3394740672/il_300x300.3394740672_mong.jpg)\\
Wedding gifts](https://www.etsy.com/search?q=wedding+gifts&mosv=sese&moci=635510339037&mosi=618520762754&featured_listing=1087712798&ref=wedding_recs_lp_wedding_gifts)

[![](https://i.etsystatic.com/5354512/r/il/35af5c/5783958379/il_300x300.5783958379_pio7.jpg)\\
Engagement gifts](https://www.etsy.com/search?q=engagement+gifts&mosv=sese&moci=635510339037&mosi=635511121285&featured_listing=190344599&ref=wedding_recs_lp_engagement_gifts)

Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 10, 2025


[4660 favorites](https://www.etsy.com/listing/1406358019/dainty-pearl-stud-earrings-by-caitlyn/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Jewelry](https://www.etsy.com/c/jewelry?amp%3Bclick_sum=4e479b0c&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=List+10+minimalist+pearl+stud+earrings+from+Etsy&%3Bref=search_grid-718053-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bfrs=1&%3Bpop=1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Earrings](https://www.etsy.com/c/jewelry/earrings?amp%3Bclick_sum=4e479b0c&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=List+10+minimalist+pearl+stud+earrings+from+Etsy&%3Bref=search_grid-718053-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bfrs=1&%3Bpop=1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Stud Earrings](https://www.etsy.com/c/jewelry/earrings/stud-earrings?amp%3Bclick_sum=4e479b0c&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=List+10+minimalist+pearl+stud+earrings+from+Etsy&%3Bref=search_grid-718053-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bfrs=1&%3Bpop=1&%3Bsts=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Sports & Outdoor Games

[Sturgeon Spearing for Sale](https://www.etsy.com/market/sturgeon_spearing)

Patches & Pins

[H60 USCG Flight Mechanic Embroidered Patch - misprints](https://www.etsy.com/listing/1341646422/h60-uscg-flight-mechanic-embroidered)

Kitchen & Dining

[Gandalf Goblet for Sale](https://www.etsy.com/market/gandalf_goblet) [Buy Groomsmen Coasters Online](https://www.etsy.com/market/groomsmen_coasters)

Gender Neutral Adult Clothing

[Rather Be Hunting for Sale](https://www.etsy.com/market/rather_be_hunting)

Toys

[Nightbringer Yasuo for Sale](https://www.etsy.com/market/nightbringer_yasuo)

Sculpture

[Hand Carved Rooster for Sale](https://www.etsy.com/market/hand_carved_rooster)

Bathroom

[Shop Elongated Wood Toilet Seat](https://www.etsy.com/market/elongated_wood_toilet_seat)

Fragrances

[Buy Avon Gentleman Talc Online](https://www.etsy.com/market/avon_gentleman_talc)

Riding & Farm Animals

[2lb Horse Fake Tail for Sale](https://www.etsy.com/market/2lb_horse_fake_tail)

Womens Clothing

[Puff Sleeve Maxi for Sale](https://www.etsy.com/market/puff_sleeve_maxi)

Drawing & Illustration

[Buy Inner Peace Svg Online](https://www.etsy.com/market/inner_peace_svg)

Hats & Caps

[Buy Panama Mola Hat Online](https://www.etsy.com/market/panama_mola_hat)

Earrings

[Anna Elsa Earrings for Sale](https://www.etsy.com/market/anna_elsa_earrings)

Bedding

[Buy Sheridan Sheets Online](https://www.etsy.com/market/sheridan_sheets)

Canvas & Surfaces

[Buy Boo Dripping Online](https://www.etsy.com/market/boo_dripping) [Shop Woodland Png](https://www.etsy.com/market/woodland_png)

Blanks

[Elegant White Pearl Flower Hair Claw Clips by ConorDesignArt](https://www.etsy.com/listing/1633372149/elegant-white-pearl-flower-hair-claw)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1406358019%2Fdainty-pearl-stud-earrings-by-caitlyn%3Famp%253Bclick_sum%3D4e479b0c%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DList%2B10%2Bminimalist%2Bpearl%2Bstud%2Bearrings%2Bfrom%2BEtsy%26amp%253Bref%3Dsearch_grid-718053-1-1%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bfrs%3D1%26amp%253Bpop%3D1%26amp%253Bsts%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgxNTc2MTowMzk0NTBiMGI1MzUwMWE5NzJmNWFhM2VhOThmNTcxZg==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1406358019%2Fdainty-pearl-stud-earrings-by-caitlyn%3Famp%253Bclick_sum%3D4e479b0c%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DList%2B10%2Bminimalist%2Bpearl%2Bstud%2Bearrings%2Bfrom%2BEtsy%26amp%253Bref%3Dsearch_grid-718053-1-1%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bfrs%3D1%26amp%253Bpop%3D1%26amp%253Bsts%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1406358019/dainty-pearl-stud-earrings-by-caitlyn?amp;click_sum=4e479b0c&amp;ls=a&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=List+10+minimalist+pearl+stud+earrings+from+Etsy&amp;ref=search_grid-718053-1-1&amp;sr_prefetch=1&amp;pf_from=search&amp;pro=1&amp;frs=1&amp;pop=1&amp;sts=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1406358019%2Fdainty-pearl-stud-earrings-by-caitlyn%3Famp%253Bclick_sum%3D4e479b0c%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DList%2B10%2Bminimalist%2Bpearl%2Bstud%2Bearrings%2Bfrom%2BEtsy%26amp%253Bref%3Dsearch_grid-718053-1-1%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bfrs%3D1%26amp%253Bpop%3D1%26amp%253Bsts%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for CaitlynMinimalist

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 12 hours of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## Seller details

### Business registration number

### Location

### Other details

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=55496650&referring_id=10204022&referring_type=shop&recipient_id=55496650&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Item in the photo is in **FINISH: 18K GOLD**




Select this option








Option selected!













This option is sold out.


- Loading


- Item in the photo is in **FINISH: STERLING SILVER**




Select this option








Option selected!













This option is sold out.



Click to zoom

- ![May include: A pair of small, round pearl earrings in a silver setting.](https://i.etsystatic.com/10204022/c/1377/1377/771/494/il/5668fb/4648000456/il_300x300.4648000456_3mmm.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/JAN20_4_c9mosh.jpg)

- ![May include: Two small pearl earrings with gold posts. The pearls are white and round. The earrings are on a textured, light brown surface.](https://i.etsystatic.com/10204022/r/il/581666/4637216728/il_300x300.4637216728_p93p.jpg)
- ![May include: A close-up of a person's ear with a small, round, silver stud earring.](https://i.etsystatic.com/10204022/r/il/e6f530/4637215682/il_300x300.4637215682_c806.jpg)
- ![May include: Three pairs of pearl stud earrings on a white square pedestal. The earrings are gold and have small white pearls.](https://i.etsystatic.com/10204022/r/il/072a9f/4637182638/il_300x300.4637182638_28z6.jpg)
- ![May include: A gold ring with a small pearl on the side.](https://i.etsystatic.com/10204022/r/il/8fb610/4637215532/il_300x300.4637215532_ffmw.jpg)
- ![May include: Two small white pearl earrings on a dried brown stem.](https://i.etsystatic.com/10204022/c/1500/1500/801/608/il/444a0f/4637238018/il_300x300.4637238018_pw1h.jpg)
- ![May include: A woman with long brown hair wearing a light beige shirt and small diamond stud earrings.](https://i.etsystatic.com/10204022/r/il/0e5959/4637191234/il_300x300.4637191234_drp8.jpg)
- ![May include: Two small pearl earrings with gold posts on a brown surface.](https://i.etsystatic.com/10204022/r/il/c578af/4637198244/il_300x300.4637198244_qj56.jpg)
- ![May include: A close-up of a person's ear with a small, round, white pearl stud earring.](https://i.etsystatic.com/10204022/r/il/d6c2d1/4647681478/il_300x300.4647681478_9vsl.jpg)
- ![Dainty Pearl Stud Earrings by Caitlyn Minimalist • Everyday Pearl Jewelry • Minimalist Stacking Earrings • Bridesmaid Proposal Gifts • ER316 image 10](https://i.etsystatic.com/10204022/r/il/4d7bd6/6705631686/il_300x300.6705631686_411z.jpg)