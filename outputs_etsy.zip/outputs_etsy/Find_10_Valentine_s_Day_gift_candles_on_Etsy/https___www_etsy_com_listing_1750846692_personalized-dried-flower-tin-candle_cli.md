[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?amp%3Bclick_sum=43b75d47&amp%3Bls=a&amp%3Bga_order=most_relevant&amp%3Bga_search_type=all&amp%3Bga_view_type=gallery&amp%3Bga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&amp%3Bref=search_grid-611062-1-1&amp%3Bsr_prefetch=1&amp%3Bpf_from=search&amp%3Bpro=1&amp%3Bfrs=1&amp%3Bpop=1&amp%3Bsts=1&logging_key=LT9c7e06d1be3957fe81058f221f8545c049858229%3A1750846692#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?amp%3Bclick_sum=43b75d47&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&%3Bref=search_grid-611062-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bfrs=1&%3Bpop=1&%3Bsts=1&logging_key=LT9c7e06d1be3957fe81058f221f8545c049858229%3A1750846692&explicit=1&ref=catnav_breadcrumb-0)
- [Party Supplies](https://www.etsy.com/c/paper-and-party-supplies/party-supplies?amp%3Bclick_sum=43b75d47&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&%3Bref=search_grid-611062-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bfrs=1&%3Bpop=1&%3Bsts=1&logging_key=LT9c7e06d1be3957fe81058f221f8545c049858229%3A1750846692&explicit=1&ref=catnav_breadcrumb-1)
- [Party Favors & Games](https://www.etsy.com/c/paper-and-party-supplies/party-supplies/party-favors-and-games?amp%3Bclick_sum=43b75d47&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&%3Bref=search_grid-611062-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bfrs=1&%3Bpop=1&%3Bsts=1&logging_key=LT9c7e06d1be3957fe81058f221f8545c049858229%3A1750846692&explicit=1&ref=catnav_breadcrumb-2)
- [Party Favors](https://www.etsy.com/c/paper-and-party-supplies/party-supplies/party-favors-and-games/party-favors?amp%3Bclick_sum=43b75d47&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&%3Bref=search_grid-611062-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bfrs=1&%3Bpop=1&%3Bsts=1&logging_key=LT9c7e06d1be3957fe81058f221f8545c049858229%3A1750846692&explicit=1&ref=catnav_breadcrumb-3)

Etsy’s Pick

Etsy’s Picks are hand selected by our style experts to highlight items from shops that have shown quality, reliability and style.

[Discover More](https://www.etsy.com/featured/hub/etsy-picks?ref=listing_etsys_pick_signal)


Add to Favorites


- ![The image features charming tin round cases, each poured with soy wax. These candles have an elegant look, showcasing a smooth and even surface. Embedded within the wax are a mixture of dried flowers, adding a a touch of nature to the candles.](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_794xN.6138837100_lysd.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![Each tin case is topped with a personalized sticker on the lid. The sticker is circular and features a custom design, displaying a name or a short message in an elegant, cursive font.](https://i.etsystatic.com/44944312/r/il/8873b3/6186946755/il_794xN.6186946755_1zm3.jpg)
- ![May include: Nine different label designs for various occasions. The designs include a floral wreath with the text 'E & R', a black and gold crest with the text 'Lily & Harry', a Halloween-themed design with a house and bats, a watercolor floral design with the text 'Claudia & Aary', a floral design with the text 'Tom & Jane', a floral design with the text 'Lily & Jamie', a simple design with a green leaf and the text 'Alice Nelson', a geometric design with the text 'katie & robert', and a design with a butterfly and the text 'Tom & Jane'.](https://i.etsystatic.com/44944312/r/il/fa5c2f/6186946753/il_794xN.6186946753_1tma.jpg)
- ![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower image 4](https://i.etsystatic.com/44944312/r/il/d5c3ef/7357854029/il_794xN.7357854029_5d90.jpg)
- ![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower image 5](https://i.etsystatic.com/44944312/r/il/abe67c/6394351576/il_794xN.6394351576_lwbi.jpg)
- ![May include: Two small white candle tins with gold lids. The candles are white and have dried flowers and leaves embedded in the wax. One candle is lit and has a small flame. The lid of one candle tin has a floral design and the text 'Thank you for helping me grow'.](https://i.etsystatic.com/44944312/r/il/6763cb/6186946701/il_794xN.6186946701_9z2o.jpg)
- ![May include: A white candle with dried flowers and leaves embedded in the wax. The candle is in a round tin with a gold rim. The lid of the tin has a floral design and the text 'Thank you for helping me grow! Oliver'.](https://i.etsystatic.com/44944312/r/il/18e8fa/6138837126/il_794xN.6138837126_ejf8.jpg)
- ![May include: A white candle with dried flowers and herbs inside a gold and white tin. The lid of the tin has a floral design and the words 'Thank you' printed on it. The candle is surrounded by dried rose buds.](https://i.etsystatic.com/44944312/r/il/be0ff0/6186946709/il_794xN.6186946709_l2rm.jpg)
- ![May include: A collection of small white candle jars with gold lids. The candles have a white wax base with dried flowers and gold beads embedded in the wax. The jars are arranged in rows on a wooden surface. Some of the jars have lids with a floral design and the words 'Thank you' printed on them.](https://i.etsystatic.com/44944312/r/il/a59262/6186946663/il_794xN.6186946663_m1zx.jpg)
- ![May include: A lit candle with a gold rimmed glass jar. The candle is surrounded by dried flowers and leaves. The jar has a white label with gold lettering that reads 'Thank you for helping me grow! Oliver'.](https://i.etsystatic.com/44944312/r/il/40e9c5/6138837172/il_794xN.6138837172_soa8.jpg)
- ![May include: A lit candle in a white tin with a gold rim. The candle is surrounded by dried flowers and greenery. The tin has a floral design and the text 'Thank you for helping me grow! Oliver'.](https://i.etsystatic.com/44944312/r/il/28fc1b/6186946683/il_794xN.6186946683_q41a.jpg)

- ![The image features charming tin round cases, each poured with soy wax. These candles have an elegant look, showcasing a smooth and even surface. Embedded within the wax are a mixture of dried flowers, adding a a touch of nature to the candles.](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_75x75.6138837100_lysd.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/7c5d-1257-42fb-9869-faf85bb76899_epw99c.jpg)

- ![Each tin case is topped with a personalized sticker on the lid. The sticker is circular and features a custom design, displaying a name or a short message in an elegant, cursive font.](https://i.etsystatic.com/44944312/r/il/8873b3/6186946755/il_75x75.6186946755_1zm3.jpg)
- ![May include: Nine different label designs for various occasions. The designs include a floral wreath with the text 'E & R', a black and gold crest with the text 'Lily & Harry', a Halloween-themed design with a house and bats, a watercolor floral design with the text 'Claudia & Aary', a floral design with the text 'Tom & Jane', a floral design with the text 'Lily & Jamie', a simple design with a green leaf and the text 'Alice Nelson', a geometric design with the text 'katie & robert', and a design with a butterfly and the text 'Tom & Jane'.](https://i.etsystatic.com/44944312/r/il/fa5c2f/6186946753/il_75x75.6186946753_1tma.jpg)
- ![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower image 4](https://i.etsystatic.com/44944312/r/il/d5c3ef/7357854029/il_75x75.7357854029_5d90.jpg)
- ![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower image 5](https://i.etsystatic.com/44944312/r/il/abe67c/6394351576/il_75x75.6394351576_lwbi.jpg)
- ![May include: Two small white candle tins with gold lids. The candles are white and have dried flowers and leaves embedded in the wax. One candle is lit and has a small flame. The lid of one candle tin has a floral design and the text 'Thank you for helping me grow'.](https://i.etsystatic.com/44944312/r/il/6763cb/6186946701/il_75x75.6186946701_9z2o.jpg)
- ![May include: A white candle with dried flowers and leaves embedded in the wax. The candle is in a round tin with a gold rim. The lid of the tin has a floral design and the text 'Thank you for helping me grow! Oliver'.](https://i.etsystatic.com/44944312/r/il/18e8fa/6138837126/il_75x75.6138837126_ejf8.jpg)
- ![May include: A white candle with dried flowers and herbs inside a gold and white tin. The lid of the tin has a floral design and the words 'Thank you' printed on it. The candle is surrounded by dried rose buds.](https://i.etsystatic.com/44944312/r/il/be0ff0/6186946709/il_75x75.6186946709_l2rm.jpg)
- ![May include: A collection of small white candle jars with gold lids. The candles have a white wax base with dried flowers and gold beads embedded in the wax. The jars are arranged in rows on a wooden surface. Some of the jars have lids with a floral design and the words 'Thank you' printed on them.](https://i.etsystatic.com/44944312/r/il/a59262/6186946663/il_75x75.6186946663_m1zx.jpg)
- ![May include: A lit candle with a gold rimmed glass jar. The candle is surrounded by dried flowers and leaves. The jar has a white label with gold lettering that reads 'Thank you for helping me grow! Oliver'.](https://i.etsystatic.com/44944312/r/il/40e9c5/6138837172/il_75x75.6138837172_soa8.jpg)
- ![May include: A lit candle in a white tin with a gold rim. The candle is surrounded by dried flowers and greenery. The tin has a floral design and the text 'Thank you for helping me grow! Oliver'.](https://i.etsystatic.com/44944312/r/il/28fc1b/6186946683/il_75x75.6186946683_q41a.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1750846692%2Fpersonalized-dried-flower-tin-candle%23report-overlay-trigger)

In 18 carts

Price:$34.98+


Original Price:
$58.30+


Loading


**New markdown!**

40% off


•

Limited time sale


# Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower

Made by [favors4ever](https://www.etsy.com/shop/favors4ever)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?amp%3Bclick_sum=43b75d47&amp%3Bls=a&amp%3Bga_order=most_relevant&amp%3Bga_search_type=all&amp%3Bga_view_type=gallery&amp%3Bga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&amp%3Bref=search_grid-611062-1-1&amp%3Bsr_prefetch=1&amp%3Bpf_from=search&amp%3Bpro=1&amp%3Bfrs=1&amp%3Bpop=1&amp%3Bsts=1&logging_key=LT9c7e06d1be3957fe81058f221f8545c049858229%3A1750846692#reviews)

Arrives soon! Get it by

Nov 17-21


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

QUANTITY OF CANDLES


Select an option

5 CANDLES ($34.98)

10 CANDLES ($49.99)

15 CANDLES ($72.60)

20 CANDLES ($89.40)

25 Lids ($45.00)

25 CANDLES ($107.40)

30 CANDLES ($119.40)

35 CANDLES ($138.00)

40 CANDLES ($156.00)

45 CANDLES ($173.40)

50 CANDLES ($189.60)

60 CANDLES ($221.40)

65 CANDLES ($237.60)

70 CANDLES ($247.20)

80 CANDLES ($282.00)

90 CANDLES ($309.00)

100 CANDLES ($340.80)

110 CANDLES ($372.00)

135 CANDLES ($453.60)

140 CANDLES ($469.80)

150 CANDLES ($503.40)

160 CANDLES ($534.00)

170 CANDLES ($570.00)

200 CANDLES ($672.00)

250 CANDLES ($774.96)

290 CANDLES ($930.00)

Please select an option


Label Model


Select an option

1

2

3

4

5

6

7

8

9

11 (CHRISTMAS)

12 (CHRISTMAS)

13 (CHRISTMAS)

14 (CHRISTMAS)

15 (CHRISTMAS)

16 (CHRISTMAS)

17 (CHRISTMAS)

18 (CHRISTMAS)

19 (CHRISTMAS)

Please select an option


Add personalization


- Personalization





Please enter

1\. Your phone number (required for shipping purposes)

2\. Names, date or any other message to be printed on the labels

3\. Wick Type (String or Wood wick)


















0/256


4 payments of **$8.74** at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Made by [favors4ever](https://www.etsy.com/shop/favors4ever)

- Materials: natural soy wax



Elevate your special events with our Personalized Tin Candle with Embedded Dried Flowers in Bulk. These exquisite candles are perfect for christmas, holidays, winters, weddings, bridal showers, baby showers, birthdays, and other memorable celebrations. Each candle is thoughtfully handcrafted and poured with high-quality scented soy wax, ensuring a clean and long-lasting burn.

Encased in elegant tin round cases, each candle features a delightful blend of dried flowers embedded within the wax. The delicate hues of pink, purple, and yellow flowers add a touch of natural beauty and charm. The tin case is topped with a personalized sticker on the lid, allowing you to customize each candle with a name, date, or short message in an elegant cursive font, making them unique keepsakes for your guests.

Our scented soy wax candles not only create a warm and inviting atmosphere but also serve as a beautiful reminder of your special day. Available in bulk, these personalized candles are the perfect favors to show appreciation to your guests while adding a sophisticated touch to your event decor.

Make your celebrations unforgettable with our Personalized Tin Candles with Embedded Dried Flowers. Order in bulk for a charming and thoughtful addition to your weddings, bridal showers, baby showers, birthdays, and more.

Features:

Diameter: 7.5 cm

Height: 3.5 cm

Weight: Approximately 90 grams

Premium Soy Wax: Our candles are made from 100% natural soy wax, ensuring a clean and eco-friendly burn that’s gentle on the environment.

Scented Delight: Each candle is infused with a subtle yet captivating fragrance, creating a warm and inviting ambiance.

Personalized Touch: Customize your candles with names, monograms, or special messages, making each favor uniquely yours.

Bulk Availability: Perfect for large gatherings, these candles are available in bulk quantities, ensuring all your guests receive a beautiful and memorable favor.

Versatile Occasions: Ideal for weddings, bridal showers, birthdays, or any special event where you want to leave a lasting impression.

Why Choose Our Scented Soy Candles?

Our Elegant Scented Soy Candles are more than just beautiful decor; they’re a heartfelt way to thank your guests and create lasting memories. The combination of soothing scents and the natural beauty of dried flowers makes these candles a cherished keepsake for any occasion.

Perfect for Gifting:

Weddings: Give your guests a token of your appreciation with these elegant candles.

Bridal Showers: Add a touch of sophistication to your bridal shower with personalized favors.

Birthdays: Celebrate special milestones with unique and thoughtful gifts.

Candle Safety Instructions

To ensure a safe and enjoyable experience with our candles, please follow these guidelines:

Burning Location:

Place the candle on a heat-resistant surface, away from flammable materials, drafts, and anything that could catch fire.

Keep candles away from children, pets, and curtains.

Burn Time:

Do not burn the candle for more than 1-2 hours at a time. Allow the candle to cool and solidify before relighting.

Never leave a burning candle unattended.

Wick Position:

Our candles have a wick positioned away from the center to prevent floral buds and green leaves from catching fire. Ensure the candle is on a flat surface so it burns evenly.

Extinguishing:

Use a snuffer to extinguish the candle instead of blowing it out to prevent wax splatter.

Make sure the wick is upright and centered after extinguishing to prepare it for the next use.

Container Safety:

Do not touch or move the candle while it is burning or if the wax is still liquid.

Storage:

Store candles in a cool, dry place and out of direct sunlight to maintain their quality.

By following these safety tips, you can enjoy our candles safely and to their fullest potential!

Please note that the colors shown in the images may not perfectly match the actual colors of the product. Variations in lighting, screen settings, and photography can cause slight differences in color. We strive to present our products as accurately as possible, but actual colors may vary slightly from what is depicted in the images. Thank you for your understanding.


## Shipping and return policies

Loading


- Order today to get by

**Nov 17-21**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 30 days


- Free shipping


- Ships from: **Türkiye**


Deliver to United States

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------CanadaFranceGermanyGreeceIrelandItalyPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AlbaniaAndorraAustriaBelgiumBosnia and HerzegovinaBulgariaCanadaCroatiaCyprusCzech RepublicDenmarkEstoniaFinlandFranceGermanyGibraltarGreeceHoly See (Vatican City State)HungaryIcelandIrelandItalyKosovoLatviaLiechtensteinLithuaniaLuxembourgMacedoniaMaltaMoldovaMonacoMontenegroNorwayPolandPortugalRomaniaSan MarinoSerbiaSlovakiaSloveniaSpainSwedenSwitzerlandThe NetherlandsTürkiyeUkraineUnited KingdomUnited States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (421)

4.9/5

item average

4.9Item quality

4.9Shipping

4.9Customer service

98%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Smells amazing

Beautiful

Fast shipping

As described

Would recommend

Love it

Perfect for wedding


Filter by category


Quality (154)


Shipping & Packaging (117)


Appearance (98)


Description accuracy (66)


Seller service (52)


Value (12)


Sizing & Fit (4)


Condition (3)


Ease of use (2)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Raksha Bantwal](https://www.etsy.com/people/915532lj6mbd1h5d?ref=l_review)
Nov 10, 2025


The candle smells really good, and the package arrived earlier than expected. However, I was a bit disappointed with the size — the box and quantity are much smaller than what the website pictures suggest. The images are a bit misleading. It’s quite pricey considering the small amount you receive.



![Raksha Bantwal added a photo of their purchase](https://i.etsystatic.com/iap/1677e8/7381408542/iap_300x300.7381408542_kbmz88rx.jpg?version=0)

[Raksha Bantwal](https://www.etsy.com/people/915532lj6mbd1h5d?ref=l_review)
Nov 10, 2025


5 out of 5 stars
5

This item

[mahrokh salamzadeh](https://www.etsy.com/people/mahrokh16?ref=l_review)
Nov 8, 2025


They are so cute! And smell great. Exactly as described. fast shipping as well.



[mahrokh salamzadeh](https://www.etsy.com/people/mahrokh16?ref=l_review)
Nov 8, 2025


5 out of 5 stars
5

This item

[Stella Arlovic](https://www.etsy.com/people/dwi7dr82qiwhnucm?ref=l_review)
Nov 6, 2025


The quality is great and the candles smell beautiful



[Stella Arlovic](https://www.etsy.com/people/dwi7dr82qiwhnucm?ref=l_review)
Nov 6, 2025


5 out of 5 stars
5

This item

[fike02](https://www.etsy.com/people/fike02?ref=l_review)
Nov 5, 2025


I am so impressed with how pretty, wonderful aroma and fast shipping on my candles. They are going to make a wonderful favor for my wedding.



![fike02 added a photo of their purchase](https://i.etsystatic.com/iap/71c47b/7409546493/iap_300x300.7409546493_luu8t1at.jpg?version=0)

[fike02](https://www.etsy.com/people/fike02?ref=l_review)
Nov 5, 2025


View all reviews for this item

### Photos from reviews

![fike02 added a photo of their purchase](https://i.etsystatic.com/iap/71c47b/7409546493/iap_300x300.7409546493_luu8t1at.jpg?version=0)

![zeal added a photo of their purchase](https://i.etsystatic.com/iap/f4a012/7245415350/iap_300x300.7245415350_2ts8lwc3.jpg?version=0)

![Erika added a photo of their purchase](https://i.etsystatic.com/iap/a9dd98/7211311699/iap_300x300.7211311699_ryyblr51.jpg?version=0)

![Amanda added a photo of their purchase](https://i.etsystatic.com/iap/352156/7092522010/iap_300x300.7092522010_f67y7nc8.jpg?version=0)

![Sandra added a photo of their purchase](https://i.etsystatic.com/iap/bdaa82/7229704855/iap_300x300.7229704855_rjiqfx2r.jpg?version=0)

![Vashista added a photo of their purchase](https://i.etsystatic.com/iap/3a19a5/7384978769/iap_300x300.7384978769_6omtak55.jpg?version=0)

![Patricia added a photo of their purchase](https://i.etsystatic.com/iap/f80cae/7157738148/iap_300x300.7157738148_54lckob5.jpg?version=0)

![Bev added a photo of their purchase](https://i.etsystatic.com/iap/d9f20b/7164981809/iap_300x300.7164981809_ju1r5lav.jpg?version=0)

![Sign added a photo of their purchase](https://i.etsystatic.com/iap/2f0a35/7122324416/iap_300x300.7122324416_k512nxu6.jpg?version=0)

![Loukeena added a photo of their purchase](https://i.etsystatic.com/iap/b1429a/7181678061/iap_300x300.7181678061_r46mldkk.jpg?version=0)

![Lisa added a photo of their purchase](https://i.etsystatic.com/iap/acc407/7148692879/iap_300x300.7148692879_lzjeic40.jpg?version=0)

![Medha added a photo of their purchase](https://i.etsystatic.com/iap/208d22/7009632216/iap_300x300.7009632216_jhfuf6l9.jpg?version=0)

![Oriol added a photo of their purchase](https://i.etsystatic.com/iap/bb4a84/6923241765/iap_300x300.6923241765_jr7n5lat.jpg?version=0)

![Patti added a photo of their purchase](https://i.etsystatic.com/iap/a4f62f/7135156867/iap_300x300.7135156867_510oe6st.jpg?version=0)

![Carmen added a photo of their purchase](https://i.etsystatic.com/iap/67f443/6977586829/iap_300x300.6977586829_q2be4chm.jpg?version=0)

![Giuseppina added a photo of their purchase](https://i.etsystatic.com/iap/6fbd22/7258198989/iap_300x300.7258198989_fzpo3w13.jpg?version=0)

![Elizabeth added a photo of their purchase](https://i.etsystatic.com/iap/7ff095/7068787441/iap_300x300.7068787441_lxawe2zz.jpg?version=0)

![Sign added a photo of their purchase](https://i.etsystatic.com/iap/f32cfc/7031580886/iap_300x300.7031580886_acaznpsi.jpg?version=0)

![Isabelle added a photo of their purchase](https://i.etsystatic.com/iap/695c20/7076918185/iap_300x300.7076918185_b3kk1b53.jpg?version=0)

![Abby added a photo of their purchase](https://i.etsystatic.com/iap/030b45/7057885384/iap_300x300.7057885384_tvdlpbhz.jpg?version=0)

[![favors4ever](https://i.etsystatic.com/iusa/e9beef/101261238/iusa_75x75.101261238_jsd3.jpg?version=0)](https://www.etsy.com/shop/favors4ever?ref=shop_profile&listing_id=1750846692)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[favors4ever](https://www.etsy.com/shop/favors4ever?ref=shop_profile&listing_id=1750846692)

[Owned by pxlvf2sm3skwwohk](https://www.etsy.com/shop/favors4ever?ref=shop_profile&listing_id=1750846692) \|

Istanbul, Türkiye

4.9
(476)


2.1k sales

2 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=807299375&referring_id=1750846692&referring_type=listing&recipient_id=807299375&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo4MDcyOTkzNzU6MTc2MjgyNDI4Nzo1MWVkNjdlYzU1YTRjYTY3NzY4ZGE0NmNlNjQyMjg5OA%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1750846692%2Fpersonalized-dried-flower-tin-candle%3Famp%253Bclick_sum%3D43b75d47%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DFind%2B10%2BValentine%25E2%2580%2599s%2BDay%2Bgift%2Bcandles%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-611062-1-1%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bfrs%3D1%26amp%253Bpop%3D1%26amp%253Bsts%3D1%26logging_key%3DLT9c7e06d1be3957fe81058f221f8545c049858229%253A1750846692)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/favors4ever?ref=lp_mys_mfts)

- [![Scented Soy Candle Favors: Dried Flower Arrangements, Personalized Wedding Gifts](https://i.etsystatic.com/44944312/r/il/300bce/6186071181/il_340x270.6186071181_1iig.jpg)\\
\\
**Scented Soy Candle Favors: Dried Flower Arrangements, Personalized Wedding Gifts**\\
\\
Sale Price $53.40\\
$53.40\\
\\
$89.00\\
Original Price $89.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1764844991/scented-soy-candle-favors-dried-flower?click_key=1039dd43f6ef9bdb044ab0d991ef12b9%3ALTbffc8e90af188ec4ae491ed1597d6cf3dcf79822&click_sum=bbb24d18&ls=r&ref=related-1&pro=1&sts=1&content_source=1039dd43f6ef9bdb044ab0d991ef12b9%253ALTbffc8e90af188ec4ae491ed1597d6cf3dcf79822 "Scented Soy Candle Favors: Dried Flower Arrangements, Personalized Wedding Gifts")




Add to Favorites


- [![Scented Soy Candle with Personalized Label, Wedding Favor Gift Box](https://i.etsystatic.com/44944312/r/il/2ba984/6946258945/il_340x270.6946258945_r2yh.jpg)\\
\\
**Scented Soy Candle with Personalized Label, Wedding Favor Gift Box**\\
\\
Sale Price $55.20\\
$55.20\\
\\
$92.00\\
Original Price $92.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4312524423/scented-soy-candle-with-personalized?click_key=1039dd43f6ef9bdb044ab0d991ef12b9%3ALT4b8ed6352c8b17401090482ad363b32116b387da&click_sum=b7c8641c&ls=r&ref=related-2&pro=1&sts=1&content_source=1039dd43f6ef9bdb044ab0d991ef12b9%253ALT4b8ed6352c8b17401090482ad363b32116b387da "Scented Soy Candle with Personalized Label, Wedding Favor Gift Box")




Add to Favorites


- [![Coffee Bliss Soy Candle: Orange & Cinnamon, Personalized Favors](https://i.etsystatic.com/44944312/r/il/372bd9/6139755422/il_340x270.6139755422_lcfg.jpg)\\
\\
**Coffee Bliss Soy Candle: Orange & Cinnamon, Personalized Favors**\\
\\
Sale Price $55.80\\
$55.80\\
\\
$93.00\\
Original Price $93.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1751053458/coffee-bliss-soy-candle-orange-cinnamon?click_key=1039dd43f6ef9bdb044ab0d991ef12b9%3ALTdf73d02b1f5c3bee7fb617a9132b5e8d90de0b18&click_sum=b25188a5&ls=r&ref=related-3&pro=1&sts=1&content_source=1039dd43f6ef9bdb044ab0d991ef12b9%253ALTdf73d02b1f5c3bee7fb617a9132b5e8d90de0b18 "Coffee Bliss Soy Candle: Orange & Cinnamon, Personalized Favors")




Add to Favorites


- [![Personalized Evil Eye Bead Bracelet Favors: Elegant Organza Bag](https://i.etsystatic.com/44944312/r/il/8abdd6/6187166280/il_340x270.6187166280_bl31.jpg)\\
\\
**Personalized Evil Eye Bead Bracelet Favors: Elegant Organza Bag**\\
\\
Sale Price $48.96\\
$48.96\\
\\
$81.60\\
Original Price $81.60\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1761953508/personalized-evil-eye-bead-bracelet?click_key=40acd65a55a3d74e3efcacdf176068f434610228%3A1761953508&click_sum=532f6fd4&ref=related-4&pro=1&sts=1 "Personalized Evil Eye Bead Bracelet Favors: Elegant Organza Bag")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading wedding form

Loading


## Top wedding searches to shop

[![](https://i.etsystatic.com/19757930/c/1333/1333/0/301/il/cfe72f/3482678762/il_300x300.3482678762_pxw3.jpg)\\
Bridesmaid gifts](https://www.etsy.com/search?q=bridesmaid+gifts&mosv=sese&moci=635510339037&mosi=618520640322&featured_listing=1110003408&ref=wedding_recs_lp_bridesmaid_gifts)

[![](https://i.etsystatic.com/19483987/r/il/42cd8d/2512481731/il_300x300.2512481731_8gz7.jpg)\\
Groomsmen gifts](https://www.etsy.com/search?q=groomsmen+gifts&mosv=sese&moci=635510339037&mosi=635510910189&featured_listing=761677858&ref=wedding_recs_lp_groomsmen_gifts)

[![](https://i.etsystatic.com/6748817/c/2000/2000/0/828/il/b140dc/3394740672/il_300x300.3394740672_mong.jpg)\\
Wedding gifts](https://www.etsy.com/search?q=wedding+gifts&mosv=sese&moci=635510339037&mosi=618520762754&featured_listing=1087712798&ref=wedding_recs_lp_wedding_gifts)

[![](https://i.etsystatic.com/5354512/r/il/35af5c/5783958379/il_300x300.5783958379_pio7.jpg)\\
Engagement gifts](https://www.etsy.com/search?q=engagement+gifts&mosv=sese&moci=635510339037&mosi=635511121285&featured_listing=190344599&ref=wedding_recs_lp_engagement_gifts)

Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 10, 2025


[9594 favorites](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?amp%3Bclick_sum=43b75d47&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&%3Bref=search_grid-611062-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bfrs=1&%3Bpop=1&%3Bsts=1&logging_key=LT9c7e06d1be3957fe81058f221f8545c049858229%3A1750846692&explicit=1&ref=breadcrumb_listing) [Party Supplies](https://www.etsy.com/c/paper-and-party-supplies/party-supplies?amp%3Bclick_sum=43b75d47&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&%3Bref=search_grid-611062-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bfrs=1&%3Bpop=1&%3Bsts=1&logging_key=LT9c7e06d1be3957fe81058f221f8545c049858229%3A1750846692&explicit=1&ref=breadcrumb_listing) [Party Favors & Games](https://www.etsy.com/c/paper-and-party-supplies/party-supplies/party-favors-and-games?amp%3Bclick_sum=43b75d47&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&%3Bref=search_grid-611062-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bfrs=1&%3Bpop=1&%3Bsts=1&logging_key=LT9c7e06d1be3957fe81058f221f8545c049858229%3A1750846692&explicit=1&ref=breadcrumb_listing) [Party Favors](https://www.etsy.com/c/paper-and-party-supplies/party-supplies/party-favors-and-games/party-favors?amp%3Bclick_sum=43b75d47&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&%3Bref=search_grid-611062-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Bfrs=1&%3Bpop=1&%3Bsts=1&logging_key=LT9c7e06d1be3957fe81058f221f8545c049858229%3A1750846692&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Paper

[Buy Bible Verse Reels Online](https://www.etsy.com/market/bible_verse_reels) [Luau 2 Year Birthday for Sale](https://www.etsy.com/market/luau_2_year_birthday)

Gifts & Mementos

[Donut favor bag by PlumGroveDesign](https://www.etsy.com/listing/644597985/donut-favor-bag-donut-mind-if-i-do) [Tie the Knot Necklace](https://www.etsy.com/listing/271916184/tie-the-knot-necklace-flower-girl-gift)

Home Decor

[Paris Ornament - Optional engraving - Stainless steel - Made in USA by CraftMetalBoutique](https://www.etsy.com/listing/1707454027/paris-ornament-optional-engraving)

Keychains & Lanyards

[Persona 5 Sword - US](https://www.etsy.com/market/persona_5_sword)

Patterns & How To

[Buy Crochet Sweater Size 5 Yarn Online](https://www.etsy.com/market/crochet_sweater_size_5_yarn)

Shopping

[Womens Bling Sparkle Top for Sale](https://www.etsy.com/market/womens_bling_sparkle_top) [Surreal Bubbles Art for Sale](https://www.etsy.com/market/surreal_bubbles_art)

Prints

[God's Grand Plan Coloring Page & Gospel Presentation -- Creation - Prints](https://www.etsy.com/listing/1269539125/gods-grand-plan-coloring-page-gospel)

Suit & Tie Accessories

[Vintage Swank MCM Diamond Cut Etched Star Rectangular Gold Tone Cufflinks - Suit & Tie Accessories](https://www.etsy.com/listing/1831519957/vintage-swank-mcm-diamond-cut-etched)

Spirituality & Religion

[Shop Baby Girl Mezuzah](https://www.etsy.com/market/baby_girl_mezuzah)

Womens Clothing

[Tropical Flower Graphic Tee - Women's Clothing](https://www.etsy.com/listing/4324725854/pink-hibiscus-crop-top-tropical-flower)

Gender Neutral Adult Clothing

[AJ 4 Rare Air Dirty Love Skull 3D T-Shirt by LionWardrobeWorks](https://www.etsy.com/listing/4341588664/aj-4-rare-air-dirty-love-skull-3d-t)

Games & Puzzles

[aarontrotter](https://www.etsy.com/shop/aarontrotter)

Photography

[Buy Antique Daguerreotype Twin Boys Online](https://www.etsy.com/market/antique_daguerreotype_twin_boys)

Bedding

[Shop Cozy Blanket By Haley](https://www.etsy.com/market/cozy_blanket_by_haley)

Patches & Pins

[Buy Nap Pin Online](https://www.etsy.com/market/nap_pin)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1750846692%2Fpersonalized-dried-flower-tin-candle%3Famp%253Bclick_sum%3D43b75d47%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DFind%2B10%2BValentine%25E2%2580%2599s%2BDay%2Bgift%2Bcandles%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-611062-1-1%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bfrs%3D1%26amp%253Bpop%3D1%26amp%253Bsts%3D1%26logging_key%3DLT9c7e06d1be3957fe81058f221f8545c049858229%253A1750846692&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgyNDI4Nzo0YmFiOThiMjJiYWYzOWFhYzA5NTg3MmU4MzZmZjE2OQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1750846692%2Fpersonalized-dried-flower-tin-candle%3Famp%253Bclick_sum%3D43b75d47%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DFind%2B10%2BValentine%25E2%2580%2599s%2BDay%2Bgift%2Bcandles%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-611062-1-1%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bfrs%3D1%26amp%253Bpop%3D1%26amp%253Bsts%3D1%26logging_key%3DLT9c7e06d1be3957fe81058f221f8545c049858229%253A1750846692) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?amp%3Bclick_sum=43b75d47&amp%3Bls=a&amp%3Bga_order=most_relevant&amp%3Bga_search_type=all&amp%3Bga_view_type=gallery&amp%3Bga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&amp%3Bref=search_grid-611062-1-1&amp%3Bsr_prefetch=1&amp%3Bpf_from=search&amp%3Bpro=1&amp%3Bfrs=1&amp%3Bpop=1&amp%3Bsts=1&logging_key=LT9c7e06d1be3957fe81058f221f8545c049858229%3A1750846692#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1750846692%2Fpersonalized-dried-flower-tin-candle%3Famp%253Bclick_sum%3D43b75d47%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DFind%2B10%2BValentine%25E2%2580%2599s%2BDay%2Bgift%2Bcandles%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-611062-1-1%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Bfrs%3D1%26amp%253Bpop%3D1%26amp%253Bsts%3D1%26logging_key%3DLT9c7e06d1be3957fe81058f221f8545c049858229%253A1750846692)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

On


Saved

Done

## Shop policies for favors4ever

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 12 hours of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


Customs and import taxes

Buyers are responsible for any customs and import taxes that may apply. I'm not responsible for delays due to customs.


## Seller details

### Business registration number

### Location

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=807299375&referring_id=44944312&referring_type=shop&recipient_id=807299375&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![The image features charming tin round cases, each poured with soy wax. These candles have an elegant look, showcasing a smooth and even surface. Embedded within the wax are a mixture of dried flowers, adding a a touch of nature to the candles.](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_300x300.6138837100_lysd.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/7c5d-1257-42fb-9869-faf85bb76899_epw99c.jpg)

- ![Each tin case is topped with a personalized sticker on the lid. The sticker is circular and features a custom design, displaying a name or a short message in an elegant, cursive font.](https://i.etsystatic.com/44944312/r/il/8873b3/6186946755/il_300x300.6186946755_1zm3.jpg)
- ![May include: Nine different label designs for various occasions. The designs include a floral wreath with the text 'E & R', a black and gold crest with the text 'Lily & Harry', a Halloween-themed design with a house and bats, a watercolor floral design with the text 'Claudia & Aary', a floral design with the text 'Tom & Jane', a floral design with the text 'Lily & Jamie', a simple design with a green leaf and the text 'Alice Nelson', a geometric design with the text 'katie & robert', and a design with a butterfly and the text 'Tom & Jane'.](https://i.etsystatic.com/44944312/r/il/fa5c2f/6186946753/il_300x300.6186946753_1tma.jpg)
- ![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower image 4](https://i.etsystatic.com/44944312/r/il/d5c3ef/7357854029/il_300x300.7357854029_5d90.jpg)
- ![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower image 5](https://i.etsystatic.com/44944312/r/il/abe67c/6394351576/il_300x300.6394351576_lwbi.jpg)
- ![May include: Two small white candle tins with gold lids. The candles are white and have dried flowers and leaves embedded in the wax. One candle is lit and has a small flame. The lid of one candle tin has a floral design and the text 'Thank you for helping me grow'.](https://i.etsystatic.com/44944312/r/il/6763cb/6186946701/il_300x300.6186946701_9z2o.jpg)
- ![May include: A white candle with dried flowers and leaves embedded in the wax. The candle is in a round tin with a gold rim. The lid of the tin has a floral design and the text 'Thank you for helping me grow! Oliver'.](https://i.etsystatic.com/44944312/r/il/18e8fa/6138837126/il_300x300.6138837126_ejf8.jpg)
- ![May include: A white candle with dried flowers and herbs inside a gold and white tin. The lid of the tin has a floral design and the words 'Thank you' printed on it. The candle is surrounded by dried rose buds.](https://i.etsystatic.com/44944312/r/il/be0ff0/6186946709/il_300x300.6186946709_l2rm.jpg)
- ![May include: A collection of small white candle jars with gold lids. The candles have a white wax base with dried flowers and gold beads embedded in the wax. The jars are arranged in rows on a wooden surface. Some of the jars have lids with a floral design and the words 'Thank you' printed on them.](https://i.etsystatic.com/44944312/r/il/a59262/6186946663/il_300x300.6186946663_m1zx.jpg)
- ![May include: A lit candle with a gold rimmed glass jar. The candle is surrounded by dried flowers and leaves. The jar has a white label with gold lettering that reads 'Thank you for helping me grow! Oliver'.](https://i.etsystatic.com/44944312/r/il/40e9c5/6138837172/il_300x300.6138837172_soa8.jpg)
- ![May include: A lit candle in a white tin with a gold rim. The candle is surrounded by dried flowers and greenery. The tin has a floral design and the text 'Thank you for helping me grow! Oliver'.](https://i.etsystatic.com/44944312/r/il/28fc1b/6186946683/il_300x300.6186946683_q41a.jpg)

- ![](https://i.etsystatic.com/iap/71c47b/7409546493/iap_640x640.7409546493_luu8t1at.jpg?version=0)

5 out of 5 stars

- QUANTITY OF CANDLES:

30 CANDLES

- Label Model:

6


I am so impressed with how pretty, wonderful aroma and fast shipping on my candles. They are going to make a wonderful favor for my wedding.

Nov 5, 2025


[fike02](https://www.etsy.com/people/fike02)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/f4a012/7245415350/iap_640x640.7245415350_2ts8lwc3.jpg?version=0)

5 out of 5 stars

- QUANTITY OF CANDLES:

20 CANDLES

- Label Model:

8


Loved the candles. The fragrance is great. Great item for favors.

![](https://i.etsystatic.com/iusa/a145d9/34142501/iusa_75x75.34142501_5ihr.jpg?version=0)

Oct 1, 2025


[zeal shah](https://www.etsy.com/people/zealshah)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/a9dd98/7211311699/iap_640x640.7211311699_ryyblr51.jpg?version=0)

5 out of 5 stars

- QUANTITY OF CANDLES:

10 CANDLES

- Label Model:

5


I bought 45-10 candles in two orders, they are super scented, the inside decoration is gorgeous and the sticker on the package is perfect for our wedding theme.

See in original language


Translated by Google


Ho comprato 45-10 candele in due ordini, sono super profumate il decoro interno e stupendo e l'adesivo sulla confezione perfetto per il nostro tema del matrimonio.


Sep 2, 2025


[Erika Dubini](https://www.etsy.com/people/ffsqiwbnqiloowc7)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/352156/7092522010/iap_640x640.7092522010_f67y7nc8.jpg?version=0)

5 out of 5 stars

- QUANTITY OF CANDLES:

10 CANDLES

- Label Model:

5


These are absolutely perfect and SO cute. I can't wait to give them to guests when they come for our friends engagement party we are throwing for them 🪷

![](https://i.etsystatic.com/iusa/7c9ae8/114199724/iusa_75x75.114199724_979t.jpg?version=0)

Aug 8, 2025


[Amanda](https://www.etsy.com/people/npfgal9j)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/bdaa82/7229704855/iap_640x640.7229704855_rjiqfx2r.jpg?version=0)

5 out of 5 stars

- QUANTITY OF CANDLES:

20 CANDLES

- Label Model:

8


Thank you so much! I love these wonderful candles. I ordered them for my daughter’s bautism, they smell amazing! Also, I’m very grateful for the extra name stickers you put in there! I highly recommend this product. P.s it’s sooo cute!

![](https://i.etsystatic.com/iusa/0c5796/37248573/iusa_75x75.37248573_6po7.jpg?version=0)

Sep 8, 2025


[Sandra Macias](https://www.etsy.com/people/sandramacias2)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/3a19a5/7384978769/iap_640x640.7384978769_6omtak55.jpg?version=0)

5 out of 5 stars

- QUANTITY OF CANDLES:

40 CANDLES

- Label Model:

5


I love these candles. They smell great and nice floral scent. I love the dried flowers on top gives nice look. Item was packed well and no damage .

Oct 29, 2025


[Vashista](https://www.etsy.com/people/1swjkf9y6mjbefpc)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/f80cae/7157738148/iap_640x640.7157738148_54lckob5.jpg?version=0)

4 out of 5 stars

- QUANTITY OF CANDLES:

50 CANDLES

- Label Model:

1


The shop owner was super helpful and customized the candles so nicely for my sister’s baby shower. Thank you! If you have time, order the different scents to test out and choose something you like - I didn’t have to time to do so and didn’t love the scent I chose

Aug 31, 2025


[Patricia Ben-Zvi](https://www.etsy.com/people/pattybenzvi)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/d9f20b/7164981809/iap_640x640.7164981809_ju1r5lav.jpg?version=0)

5 out of 5 stars

- QUANTITY OF CANDLES:

30 CANDLES

- Label Model:

1


Excellent! Beautiful candles and lovely customized label. Thank you! Will order again for sure.

![](https://i.etsystatic.com/iusa/40053d/91920481/iusa_75x75.91920481_mjor.jpg?version=0)

Aug 17, 2025


[Bev Macon](https://www.etsy.com/people/msbeverlymacon)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/2f0a35/7122324416/iap_640x640.7122324416_k512nxu6.jpg?version=0)

5 out of 5 stars

- QUANTITY OF CANDLES:

15 CANDLES

- Label Model:

7


Beautiful candles. Perfect gift for wedding retirement and see you later parties! Oh my guests loved them.

Aug 19, 2025


[Sign in with Apple user](https://www.etsy.com/people/xoz7qx8f062iw460)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/b1429a/7181678061/iap_640x640.7181678061_r46mldkk.jpg?version=0)

5 out of 5 stars

- QUANTITY OF CANDLES:

15 CANDLES

- Label Model:

6


Came as described, smells good and are too cute 🥰, can't wait to give these out as wedding favors! Kept one or two for myself lol

Aug 23, 2025


[Loukeena](https://www.etsy.com/people/5uruc6s79mg3jsti)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/acc407/7148692879/iap_640x640.7148692879_lzjeic40.jpg?version=0)

5 out of 5 stars

- QUANTITY OF CANDLES:

30 CANDLES

- Label Model:

8


The candles are beautiful. I am surprised by how quickly they arrived since they came from overseas.

![](https://i.etsystatic.com/iusa/f3f29d/81108708/iusa_75x75.81108708_arpf.jpg?version=0)

Aug 11, 2025


[Lisa Achilles](https://www.etsy.com/people/lisaachilles)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/208d22/7009632216/iap_640x640.7009632216_jhfuf6l9.jpg?version=0)

5 out of 5 stars

- QUANTITY OF CANDLES:

25 CANDLES

- Label Model:

8


The candles are very cute!!!! worth every penny. Great job

Jul 10, 2025


[Medha Reddy](https://www.etsy.com/people/stwojwnd)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/bb4a84/6923241765/iap_640x640.6923241765_jr7n5lat.jpg?version=0)

5 out of 5 stars

- QUANTITY OF CANDLES:

25 CANDLES

- Label Model:

4


A product that smells very good, the size is ideal, neither big nor small, ideal for a wedding gift.
We ordered over 40 and all the candles are of the same excellent quality.
If I were to get married again with my wife's permission, I wouldn't hesitate to buy them again.

See in original language


Translated by Google


Un producto que huele muy bien, el tamaño es idóneo, ni grande ni pequeño, ideal para regalar en una boda.
Pedimos más de 40 y todas las velas tienen la misma excelente calidad.
Si me casase otra vez con permiso de mi mujer no dudaria en volver a comprarlas.


![](https://i.etsystatic.com/iusa/404bf2/74703291/iusa_75x75.74703291_sqo3.jpg?version=0)

May 20, 2025


[Oriol Nieto](https://www.etsy.com/people/dh9vnmat)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/a4f62f/7135156867/iap_640x640.7135156867_510oe6st.jpg?version=0)

5 out of 5 stars

- QUANTITY OF CANDLES:

45 CANDLES

- Label Model:

5


Item matched the description and came exactly as pictured! Beautiful label and candle. Very nice scent.

Aug 6, 2025


[Patti](https://www.etsy.com/people/lw07x9pl9o6hlot9)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/67f443/6977586829/iap_640x640.6977586829_q2be4chm.jpg?version=0)

5 out of 5 stars

- QUANTITY OF CANDLES:

40 CANDLES

- Label Model:

5


Absolutely satisfied. The candles are jewels, very scented, I love them 😍
The seller was very helpful and at my request he also sent me a preview of the print I had chosen. The packaging was also perfect. Top service 🤩

See in original language


Translated by Google


Assolutamente soddisfatta. Le candele sono dei bijoux, molto profumate, le adoro 😍
Il venditore è stato molto presente e su mia richiesta mi ha mandato anche l'anteprima della stampa che avevo scelto. Anche l'imballaggio, perfetto. Servizio top 🤩


Jun 10, 2025


[Carmen](https://www.etsy.com/people/ywgmk7sx9jgtzwnh)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/6fbd22/7258198989/iap_640x640.7258198989_fzpo3w13.jpg?version=0)

5 out of 5 stars

- QUANTITY OF CANDLES:

20 CANDLES

- Label Model:

8


Product as described, excellent quality.

See in original language


Translated by Google


Prodotto come descritto, di ottima qualità.


Sep 18, 2025


[Giuseppina Cirillo](https://www.etsy.com/people/aiubhfrwtvpkmjnw)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/7ff095/7068787441/iap_640x640.7068787441_lxawe2zz.jpg?version=0)

5 out of 5 stars

- QUANTITY OF CANDLES:

100 CANDLES

- Label Model:

8


Love the candles! Very cute and packaged very well! Love the detail and quality of the candle looks very fancy.

Jul 15, 2025


[Elizabeth Hunt](https://www.etsy.com/people/xqxvmicwf2tfne9o)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/f32cfc/7031580886/iap_640x640.7031580886_acaznpsi.jpg?version=0)

4 out of 5 stars

- QUANTITY OF CANDLES:

25 CANDLES

- Label Model:

8


I received the order, however the quality of the label is not good. I don't smell the scent of the candle much. The size I thought they would be a little bigger

See in original language


Translated by Google


J’ai bien reçu la commande, par contre la qualité de l’étiquette n’est pas bonne.Je ne sens pas bcp l’odeur à la chandelle.La grandeur je croyais qu’elles seraient un petit plus grandes


![](https://i.etsystatic.com/iusa/d111f4/112187457/iusa_75x75.112187457_l95m.jpg?version=0)

Jul 18, 2025


[Sign in with Apple user](https://www.etsy.com/people/acyl0ln58q7bxgux)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/695c20/7076918185/iap_640x640.7076918185_b3kk1b53.jpg?version=0)

4 out of 5 stars

- QUANTITY OF CANDLES:

10 CANDLES

- Label Model:

6


Item corresponded to the description and met all expectations

See in original language


Translated by Google


Artikel entsprach der Beschreibung und erfüllt alle Erwartungen


Jul 17, 2025


[Isabelle H](https://www.etsy.com/people/g9dmndco8oo4mc7u)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/030b45/7057885384/iap_640x640.7057885384_tvdlpbhz.jpg?version=0)

5 out of 5 stars

- QUANTITY OF CANDLES:

50 CANDLES

- Label Model:

5


Beautiful candles & fast delivery

Jul 27, 2025


[Abby Aragon](https://www.etsy.com/people/abbyaragon)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)

Purchased item:

[![Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower](https://i.etsystatic.com/44944312/r/il/456a11/6138837100/il_170x135.6138837100_lysd.jpg)\\
\\
Personalized Dried Flower Tin Candle Favors: Scented Soy Wax, Bulk Wedding Shower\\
\\
Sale Price $34.98\\
$34.98\\
\\
$58.30\\
Original Price $58.30\\
\\
\\
(40% off)](https://www.etsy.com/listing/1750846692/personalized-dried-flower-tin-candle?ref=ap-listing)