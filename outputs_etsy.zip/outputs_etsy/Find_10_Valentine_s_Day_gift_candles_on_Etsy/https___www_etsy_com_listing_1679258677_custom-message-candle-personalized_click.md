[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1679258677/custom-message-candle-personalized?amp;click_sum=4e81257a&amp;ls=a&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&amp;ref=search_grid-611062-1-2&amp;sr_prefetch=1&amp;pf_from=search&amp;pro=1&amp;etp=1&amp;sts=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=4e81257a&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&%3Bref=search_grid-611062-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Betp=1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=4e81257a&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&%3Bref=search_grid-611062-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Betp=1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=4e81257a&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&%3Bref=search_grid-611062-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Betp=1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=4e81257a&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&%3Bref=search_grid-611062-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Betp=1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-3)
- [Container Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/container-candles?amp%3Bclick_sum=4e81257a&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&%3Bref=search_grid-611062-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Betp=1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-4)

Etsy’s Pick

Etsy’s Picks are hand selected by our style experts to highlight items from shops that have shown quality, reliability and style.

[Discover More](https://www.etsy.com/featured/hub/etsy-picks?ref=listing_etsys_pick_signal)


Add to Favorites


- ![a series of photos showing different types of teas](https://i.etsystatic.com/32386840/r/il/bc5470/7341050642/il_794xN.7341050642_k0b5.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![The image is a screenshot of a text conversation with two chat bubbles, each containing a person's face and a candle. The conversation appears to be about the candle's size and features, with one person asking about the candle's size and the other person responding with information about the candle.](https://i.etsystatic.com/32386840/r/il/d89456/7388988995/il_794xN.7388988995_7kl8.jpg)
- ![The image is a product description for a "Build Your Own Box" gift. It features a candle, a curated gift box, a greeting card, and a hand holding a greeting card. The product description includes the product name, the "Build Your Own Box" link, and the greeting card. The image does not contain any redundancy or vague descriptions.](https://i.etsystatic.com/32386840/r/il/fbcc5b/7341050808/il_794xN.7341050808_9z28.jpg)
- ![The image is a collage of various items related to sleep and relaxation, including a green tea cup, a gold-colored eye mask, pink socks, a pink candle, and tea bags.](https://i.etsystatic.com/32386840/r/il/eab6a1/7341050872/il_794xN.7341050872_rq76.jpg)
- ![The image is a collage of various items, including a vegan leather notebook, a 4 oz travel candle, a gold metal tray, a pen, a candle, and a pair of scissors.](https://i.etsystatic.com/32386840/r/il/80ee3a/7341050940/il_794xN.7341050940_bkcm.jpg)
- ![The image is a collage of various beauty and personal care items, including a pair of pink socks, a golden metal tray, a pair of scissors, a gold-colored eye mask, a rose and mint tea bag, a satin sleeping mask, a rose and mint tea bag, a free embroidered duffel bag, a white tea candle, a candle of your choice, a personalized bag, and a travel candle.](https://i.etsystatic.com/32386840/r/il/0a7789/7341051018/il_794xN.7341051018_jxuo.jpg)
- ![A candle labeled "CANDLE OF YOUR CHOICE" in a pink and orange color scheme, with dimensions and weight information provided.](https://i.etsystatic.com/32386840/r/il/d1f82b/7341051100/il_794xN.7341051100_hhk3.jpg)
- ![The image is a close-up of white soy wax chunks, with text above them stating that the product is made with 100% soy wax and is vegan, free of parabens, paraffin, dye, and cruelty-free.](https://i.etsystatic.com/32386840/r/il/9ac5e8/7341051192/il_794xN.7341051192_uqun.jpg)
- ![A collage of images featuring a person cooking in a kitchen, with the text "We make everything in our own studio" surrounding the images.](https://i.etsystatic.com/32386840/r/il/3c52df/7341051262/il_794xN.7341051262_9l30.jpg)
- ![The image is a collage of four different images, each depicting a different scent or product. The first image shows a bouquet of pink flowers, the second image features a glass of champagne, the third image shows a person relaxing in a bathtub, and the fourth image depicts a tropical beach scene with palm trees and a sunset.](https://i.etsystatic.com/32386840/r/il/ae5f15/7341051354/il_794xN.7341051354_2w7o.jpg)
- ![a collage of nine greeting cards, each held by a hand. The cards feature various messages and designs, such as "Thank you", "Greeting card", "Will you be my bridesmaid?", "Happy birthday", and "Cheers". The cards are arranged in a grid format, with three rows and three columns.](https://i.etsystatic.com/32386840/r/il/1a3672/7341051416/il_794xN.7341051416_6c7l.jpg)
- ![The image is a collage of three photos featuring two women sitting together, with a third photo of a candle in the background.](https://i.etsystatic.com/32386840/r/il/268bfa/7341051500/il_794xN.7341051500_76lp.jpg)
- ![a five-star review of a candle, with a rating of over 8,000+ stars. The review describes the candle as fantastic for a friend's gift, highly recommended, and the company's customer service as beyond impeccable. The review also mentions an unpleasant experience with the company's delivery service and their understanding and helpfulness in finding a solution.](https://i.etsystatic.com/32386840/r/il/9de361/7341051576/il_794xN.7341051576_nz0n.jpg)
- ![a series of questions and answers related to candles, including their size, wax type, and wick type.](https://i.etsystatic.com/32386840/r/il/ef2834/7341051620/il_794xN.7341051620_3zpf.jpg)
- ![The image is a product description for candles, with a focus on customization options. It provides information about how to customize a candle label and offers the option to make white-label candles. The image also mentions that the company can offer custom scents and packaging, and encourages customers to learn more.](https://i.etsystatic.com/32386840/r/il/43d31e/7341051670/il_794xN.7341051670_rj3b.jpg)
- ![a Shipping FAQ that provides information about shipping orders. It includes details about shipping times, priority, and shipping options. The image does not contain any text that describes the image in detail, and it does not include any phrases that might be considered redundancy or vague wording.](https://i.etsystatic.com/32386840/r/il/27344b/7341051724/il_794xN.7341051724_1pm8.jpg)
- ![Wholesale FAQ](https://i.etsystatic.com/32386840/r/il/46fe0d/7388989935/il_794xN.7388989935_ilvc.jpg)

- ![a series of photos showing different types of teas](https://i.etsystatic.com/32386840/r/il/bc5470/7341050642/il_75x75.7341050642_k0b5.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/USD%7Cen-US%7CUS_484b14e46a7f1b8a2988801056865dae.jpg)

- ![The image is a screenshot of a text conversation with two chat bubbles, each containing a person's face and a candle. The conversation appears to be about the candle's size and features, with one person asking about the candle's size and the other person responding with information about the candle.](https://i.etsystatic.com/32386840/r/il/d89456/7388988995/il_75x75.7388988995_7kl8.jpg)
- ![The image is a product description for a "Build Your Own Box" gift. It features a candle, a curated gift box, a greeting card, and a hand holding a greeting card. The product description includes the product name, the "Build Your Own Box" link, and the greeting card. The image does not contain any redundancy or vague descriptions.](https://i.etsystatic.com/32386840/r/il/fbcc5b/7341050808/il_75x75.7341050808_9z28.jpg)
- ![The image is a collage of various items related to sleep and relaxation, including a green tea cup, a gold-colored eye mask, pink socks, a pink candle, and tea bags.](https://i.etsystatic.com/32386840/r/il/eab6a1/7341050872/il_75x75.7341050872_rq76.jpg)
- ![The image is a collage of various items, including a vegan leather notebook, a 4 oz travel candle, a gold metal tray, a pen, a candle, and a pair of scissors.](https://i.etsystatic.com/32386840/r/il/80ee3a/7341050940/il_75x75.7341050940_bkcm.jpg)
- ![The image is a collage of various beauty and personal care items, including a pair of pink socks, a golden metal tray, a pair of scissors, a gold-colored eye mask, a rose and mint tea bag, a satin sleeping mask, a rose and mint tea bag, a free embroidered duffel bag, a white tea candle, a candle of your choice, a personalized bag, and a travel candle.](https://i.etsystatic.com/32386840/r/il/0a7789/7341051018/il_75x75.7341051018_jxuo.jpg)
- ![A candle labeled "CANDLE OF YOUR CHOICE" in a pink and orange color scheme, with dimensions and weight information provided.](https://i.etsystatic.com/32386840/r/il/d1f82b/7341051100/il_75x75.7341051100_hhk3.jpg)
- ![The image is a close-up of white soy wax chunks, with text above them stating that the product is made with 100% soy wax and is vegan, free of parabens, paraffin, dye, and cruelty-free.](https://i.etsystatic.com/32386840/r/il/9ac5e8/7341051192/il_75x75.7341051192_uqun.jpg)
- ![A collage of images featuring a person cooking in a kitchen, with the text "We make everything in our own studio" surrounding the images.](https://i.etsystatic.com/32386840/r/il/3c52df/7341051262/il_75x75.7341051262_9l30.jpg)
- ![The image is a collage of four different images, each depicting a different scent or product. The first image shows a bouquet of pink flowers, the second image features a glass of champagne, the third image shows a person relaxing in a bathtub, and the fourth image depicts a tropical beach scene with palm trees and a sunset.](https://i.etsystatic.com/32386840/r/il/ae5f15/7341051354/il_75x75.7341051354_2w7o.jpg)
- ![a collage of nine greeting cards, each held by a hand. The cards feature various messages and designs, such as "Thank you", "Greeting card", "Will you be my bridesmaid?", "Happy birthday", and "Cheers". The cards are arranged in a grid format, with three rows and three columns.](https://i.etsystatic.com/32386840/r/il/1a3672/7341051416/il_75x75.7341051416_6c7l.jpg)
- ![The image is a collage of three photos featuring two women sitting together, with a third photo of a candle in the background.](https://i.etsystatic.com/32386840/r/il/268bfa/7341051500/il_75x75.7341051500_76lp.jpg)
- ![a five-star review of a candle, with a rating of over 8,000+ stars. The review describes the candle as fantastic for a friend's gift, highly recommended, and the company's customer service as beyond impeccable. The review also mentions an unpleasant experience with the company's delivery service and their understanding and helpfulness in finding a solution.](https://i.etsystatic.com/32386840/r/il/9de361/7341051576/il_75x75.7341051576_nz0n.jpg)
- ![a series of questions and answers related to candles, including their size, wax type, and wick type.](https://i.etsystatic.com/32386840/r/il/ef2834/7341051620/il_75x75.7341051620_3zpf.jpg)
- ![The image is a product description for candles, with a focus on customization options. It provides information about how to customize a candle label and offers the option to make white-label candles. The image also mentions that the company can offer custom scents and packaging, and encourages customers to learn more.](https://i.etsystatic.com/32386840/r/il/43d31e/7341051670/il_75x75.7341051670_rj3b.jpg)
- ![a Shipping FAQ that provides information about shipping orders. It includes details about shipping times, priority, and shipping options. The image does not contain any text that describes the image in detail, and it does not include any phrases that might be considered redundancy or vague wording.](https://i.etsystatic.com/32386840/r/il/27344b/7341051724/il_75x75.7341051724_1pm8.jpg)
- ![Wholesale FAQ](https://i.etsystatic.com/32386840/r/il/46fe0d/7388989935/il_75x75.7388989935_ilvc.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1679258677%2Fcustom-message-candle-personalized%23report-overlay-trigger)

In 14 carts

Price:$12.95+


Original Price:
$25.90+


Loading


**New markdown!**

50% off


•

Limited time sale


# Custom Message Candle Personalized Handmade Gift Funny Unique Party Favor Care Package For Partner Friend Spouse Made in California P001B

[JamesWax](https://www.etsy.com/shop/JamesWax?ref=shop-header-name&listing_id=1679258677&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1679258677/custom-message-candle-personalized?amp;click_sum=4e81257a&amp;ls=a&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&amp;ref=search_grid-611062-1-2&amp;sr_prefetch=1&amp;pf_from=search&amp;pro=1&amp;etp=1&amp;sts=1#reviews)

Ships from California

Arrives soon! Get it by

Nov 14-17


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns & exchanges accepted

Pick Your Favorite Scent


Select an option

01\. Rose + Patchouli ($17.95 - $66.95)

02\. Mimosa + Pineapple ($17.95 - $66.95)

03\. White Tea + Jasmine ($17.95 - $66.95)

04\. Coconut + Orange ($17.95 - $66.95)

00\. Unscented ($12.95 - $61.95)

Please select an option


Choose Gift Option — Scroll Photos


Select an option

Candle Only (9oz • 40Hr Burn Time) ($12.95 - $17.95)

Candle + Pink Box ($13.95 - $18.95)

Candle + Sip & Sleep Gift Box ($31.95 - $36.95)

Candle + Write & Light Gift Box ($51.95 - $56.95)

Candle + Pamper & Glow Gift Box ($61.95 - $66.95)

Please select an option


Add personalization


- Personalization





Type your desired label message in the personalization box EXACTLY as you want it to appear—we’ll copy it directly onto the label for your custom candle.



Questions? Just reach out, and we’ll help right away! 😊


















0/256


Quantity



123456789101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899100101102103104105106107108109110111112113114115116117118119120121122123124125126127128129130131132133134135136137138139140141142143144145146147148149150151152153154155156157158159160161162163164165166167168169170171172173174175176177178179180181182183184185186187188189190191192193194195196197198199200201202203204205206207208209210211212213214215216217218219220221222223224225226227228229230231232233234235236237238239240241242243244245246247248249250251252253254255256257258259260261262263264265266267268269270271272273274275276277278279280281282283284285286287288289290291292293294295296297298299300301302303304305306307308309310311312313314315316317318319320321322323324325326327328329330331332333334335336337338339340341342343344345346347348349350351352353354355356357358359360361362363364365366367368369370371372373374375376377378379380381382383384385386387388389390391392393394395396397398399400401402403404405406407408409410411412413414415416417418419420421422423424425426427428429430431432433434435436437438439440441442443444445446447448449450451452453454455456457458459460461462463464465466467468469470471472473474475476477478479480481482483484485486487488489490491492493494495496497498499500501502503504505506507508509510511512513514515516517518519520521522523524525526527528529530531532533534535536537538539540541542543544545546547548549550551552553554555556557558559560561562563564565566567568569570571572573574575576577578579580581582583584585586587588589590591592593594595596597598599600601602603604605606607608609610611612613614615616617618619620621622623624625626627628629630631632633634635636637638639640641642643644645646647648649650651652653654655656657658659660661662663664665666667668669670671672673674675676677678679680681682683684685686687688689690691692693694695696697698699700701702703704705706707708709710711712713714715716717718719720721722723724725726727728729730731732733734735736737738739740741742743744745746747748749750751752

4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Buy together, get free shipping

## Buy together, get free shipping

Add 3 items to cart



Loading


[See more items](https://www.etsy.com/listing/1679258677/custom-message-candle-personalized?amp;click_sum=4e81257a&amp;ls=a&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&amp;ref=search_grid-611062-1-2&amp;sr_prefetch=1&amp;pf_from=search&amp;pro=1&amp;etp=1&amp;sts=1#recs_ribbon_container)

![Custom Message Candle Personalized Handmade Gift Funny Unique Party Favor Care Package For Partner Friend Spouse Made in California P001B](https://i.etsystatic.com/32386840/r/il/bc5470/7341050642/il_340x270.7341050642_k0b5.jpg)
This listing

### Custom Message Candle Personalized Handmade Gift Funny Unique Party Favor Care Package For Partner Friend Spouse Made in California P001B

Sale Price $12.95
$12.95

$25.90
Original Price $25.90


(50% off)




Add to Favorites


[![Personalized Message Candle Funny Unique Custom Gift Surprise 100% Soy Candle Made in California Handmade For Friend Wife Husband P001](https://i.etsystatic.com/32386840/r/il/de2283/7389083349/il_340x270.7389083349_toer.jpg)\\
\\
**Personalized Message Candle Funny Unique Custom Gift Surprise 100% Soy Candle Made in California Handmade For Friend Wife Husband P001**\\
\\
Sale Price $12.95\\
$12.95\\
\\
$25.90\\
Original Price $25.90\\
\\
\\
(50% off)](https://www.etsy.com/listing/1499335630/personalized-message-candle-funny-unique?click_key=17021a034346263e3f0653975f0fbb7d%3ALT81e863f6de0c80e042d8162c96140776bfe8178e&click_sum=a9a2dc85&ls=r&ref=listing-free-shipping-bundle-1&pro=1&sts=1&content_source=17021a034346263e3f0653975f0fbb7d%253ALT81e863f6de0c80e042d8162c96140776bfe8178e "Personalized Message Candle Funny Unique Custom Gift Surprise 100% Soy Candle Made in California Handmade For Friend Wife Husband P001")


Add to Favorites


[![Custom Message Candle Personalized Smells Like Your Message Candle Funny Handmade Unique Birthday Holiday Care Package Parent Friend P010](https://i.etsystatic.com/32386840/r/il/3cb594/7341105054/il_340x270.7341105054_1ti1.jpg)\\
\\
**Custom Message Candle Personalized Smells Like Your Message Candle Funny Handmade Unique Birthday Holiday Care Package Parent Friend P010**\\
\\
Sale Price $12.95\\
$12.95\\
\\
$25.90\\
Original Price $25.90\\
\\
\\
(50% off)](https://www.etsy.com/listing/1677788605/custom-message-candle-personalized?click_key=17021a034346263e3f0653975f0fbb7d%3ALT806425aa2534dbdf8381be70a1f45e4ed31dbf3f&click_sum=b874a656&ls=r&ref=listing-free-shipping-bundle-2&pro=1&sts=1&content_source=17021a034346263e3f0653975f0fbb7d%253ALT806425aa2534dbdf8381be70a1f45e4ed31dbf3f "Custom Message Candle Personalized Smells Like Your Message Candle Funny Handmade Unique Birthday Holiday Care Package Parent Friend P010")


Add to Favorites


![Custom Message Candle Personalized Handmade Gift Funny Unique Party Favor Care Package For Partner Friend Spouse Made in California P001B](https://i.etsystatic.com/32386840/r/il/bc5470/7341050642/il_340x270.7341050642_k0b5.jpg)
This listing

### Custom Message Candle Personalized Handmade Gift Funny Unique Party Favor Care Package For Partner Friend Spouse Made in California P001B

Sale Price $12.95
$12.95

$25.90
Original Price $25.90


(50% off)




Add to Favorites


[![Personalized Message Candle Funny Unique Custom Gift Surprise 100% Soy Candle Made in California Handmade For Friend Wife Husband P001](https://i.etsystatic.com/32386840/r/il/de2283/7389083349/il_340x270.7389083349_toer.jpg)\\
\\
**Personalized Message Candle Funny Unique Custom Gift Surprise 100% Soy Candle Made in California Handmade For Friend Wife Husband P001**\\
\\
Sale Price $12.95\\
$12.95\\
\\
$25.90\\
Original Price $25.90\\
\\
\\
(50% off)](https://www.etsy.com/listing/1499335630/personalized-message-candle-funny-unique?click_key=17021a034346263e3f0653975f0fbb7d%3ALT81e863f6de0c80e042d8162c96140776bfe8178e&click_sum=a9a2dc85&ls=r&ref=listing-free-shipping-bundle-1&pro=1&sts=1&content_source=17021a034346263e3f0653975f0fbb7d%253ALT81e863f6de0c80e042d8162c96140776bfe8178e "Personalized Message Candle Funny Unique Custom Gift Surprise 100% Soy Candle Made in California Handmade For Friend Wife Husband P001")


Add to Favorites


[![Custom Message Candle Personalized Smells Like Your Message Candle Funny Handmade Unique Birthday Holiday Care Package Parent Friend P010](https://i.etsystatic.com/32386840/r/il/3cb594/7341105054/il_340x270.7341105054_1ti1.jpg)\\
\\
**Custom Message Candle Personalized Smells Like Your Message Candle Funny Handmade Unique Birthday Holiday Care Package Parent Friend P010**\\
\\
Sale Price $12.95\\
$12.95\\
\\
$25.90\\
Original Price $25.90\\
\\
\\
(50% off)](https://www.etsy.com/listing/1677788605/custom-message-candle-personalized?click_key=17021a034346263e3f0653975f0fbb7d%3ALT806425aa2534dbdf8381be70a1f45e4ed31dbf3f&click_sum=b874a656&ls=r&ref=listing-free-shipping-bundle-2&pro=1&sts=1&content_source=17021a034346263e3f0653975f0fbb7d%253ALT806425aa2534dbdf8381be70a1f45e4ed31dbf3f "Custom Message Candle Personalized Smells Like Your Message Candle Funny Handmade Unique Birthday Holiday Care Package Parent Friend P010")


Add to Favorites


![Custom Message Candle Personalized Handmade Gift Funny Unique Party Favor Care Package For Partner Friend Spouse Made in California P001B](https://i.etsystatic.com/32386840/r/il/bc5470/7341050642/il_340x270.7341050642_k0b5.jpg)
This listing

### Custom Message Candle Personalized Handmade Gift Funny Unique Party Favor Care Package For Partner Friend Spouse Made in California P001B

Sale Price $12.95
$12.95

$25.90
Original Price $25.90


(50% off)




Add to Favorites


[![Personalized Message Candle Funny Unique Custom Gift Surprise 100% Soy Candle Made in California Handmade For Friend Wife Husband P001](https://i.etsystatic.com/32386840/r/il/de2283/7389083349/il_340x270.7389083349_toer.jpg)\\
\\
**Personalized Message Candle Funny Unique Custom Gift Surprise 100% Soy Candle Made in California Handmade For Friend Wife Husband P001**\\
\\
Sale Price $12.95\\
$12.95\\
\\
$25.90\\
Original Price $25.90\\
\\
\\
(50% off)](https://www.etsy.com/listing/1499335630/personalized-message-candle-funny-unique?click_key=17021a034346263e3f0653975f0fbb7d%3ALT81e863f6de0c80e042d8162c96140776bfe8178e&click_sum=a9a2dc85&ls=r&ref=listing-free-shipping-bundle-1&pro=1&sts=1&content_source=17021a034346263e3f0653975f0fbb7d%253ALT81e863f6de0c80e042d8162c96140776bfe8178e "Personalized Message Candle Funny Unique Custom Gift Surprise 100% Soy Candle Made in California Handmade For Friend Wife Husband P001")


Add to Favorites


[![Custom Message Candle Personalized Smells Like Your Message Candle Funny Handmade Unique Birthday Holiday Care Package Parent Friend P010](https://i.etsystatic.com/32386840/r/il/3cb594/7341105054/il_340x270.7341105054_1ti1.jpg)\\
\\
**Custom Message Candle Personalized Smells Like Your Message Candle Funny Handmade Unique Birthday Holiday Care Package Parent Friend P010**\\
\\
Sale Price $12.95\\
$12.95\\
\\
$25.90\\
Original Price $25.90\\
\\
\\
(50% off)](https://www.etsy.com/listing/1677788605/custom-message-candle-personalized?click_key=17021a034346263e3f0653975f0fbb7d%3ALT806425aa2534dbdf8381be70a1f45e4ed31dbf3f&click_sum=b874a656&ls=r&ref=listing-free-shipping-bundle-2&pro=1&sts=1&content_source=17021a034346263e3f0653975f0fbb7d%253ALT806425aa2534dbdf8381be70a1f45e4ed31dbf3f "Custom Message Candle Personalized Smells Like Your Message Candle Funny Handmade Unique Birthday Holiday Care Package Parent Friend P010")


Add to Favorites


## Item details

### Highlights

Made by [JamesWax](https://www.etsy.com/shop/JamesWax)

- Ships from California! Shorter shipping distances are

kinder to the planet

Ordering items closer to you is more likely to reduce your purchase's carbon footprint.


- Materials: All Natural Soy Wax, Premium Essential Oil, Phthalate Free Fragrance Oil, Cotton Wick, Reusable Glass Jar, Personalized Label, Biodegradable Packaging



- Sustainable features: recycled glass, upcycled, vegan. Items may include additional materials or use methods that aren't considered sustainable features on our site. [Learn more](https://help.etsy.com/hc/articles/15532793357847)

G I F T ∙ B O X ∙ O P T I O N S 🎁

We started as a candle shop — now we’ve created gift boxes for every kind of moment.

Choose from ready-made sets or \*\*Build Your Own Box\*\* for a completely custom experience.

🌙 S I P ∙ & ∙ S L E E P ∙ B O X ($48+ VALUE)

Picture this: Candle flickering on your nightstand. Steam rising from herbal tea in your clever folding cup. Fuzzy socks warming cold feet under covers. Silk mask ready to shut out the world.

This isn’t just products — it’s your new 9pm routine that actually helps you rest.

💌 \*\*Best for:\*\* The friend who’s “tired but wired,” exhausted parents, anyone who needs permission to slow down

🗣️ \*\*Customer says:\*\* “She texted me a photo of everything set up on her nightstand — uses it every single night now.”

✍️ W R I T E ∙ & ∙ L I G H T ∙ B O X ($68+ VALUE)

Transform any corner into a creative haven. Golden tray anchors your desk setup. Personalized candle casts warm light over your vegan leather notebook. Travel candle perfect for hotel desks or kitchen table work sessions. Wick trimmer standing ready like a tiny sculpture.

This is what an intentional workspace looks like.

💌 \*\*Best for:\*\* Home office warriors, diary devotees, teachers grading papers by candlelight

🗣️ \*\*Customer says:\*\* “The golden tray changed her whole desk vibe — she sends me photos of her morning writing setup.”

✨ P A M P E R ∙ & ∙ G L O W ∙ B O X ($91+ VALUE)

Open this box and watch their face. Golden tray catching light. Two candles creating layers of glow. Sheet mask promising Sunday spa vibes. Monogrammed toiletry bag ready for their next trip. Socks and mask waiting for tonight.

Everything displayed like a personal boutique. This is the gift that photographs itself.

💌 \*\*Best for:\*\* Milestone birthdays, the friend who never treats herself, when you need them to know they matter

🗣️ \*\*Customer says:\*\* “She literally gasped when she opened it — now she has the tray on her vanity with the candles displayed like art.”

✍️ B U I L D ∙ Y O U R ∙ O W N ∙ B O X

Want total control? Start with a Candle + Pink Box, then \*\*add exactly what you know they’ll love\*\*.

The most personal way to send a gift that feels one-of-a-kind.

\*\*Link to Build Your Own Box\*\* \[http://JamesWax.etsy.com/?section\_id=55396965\](http://jameswax.etsy.com/?section\_id=55396965)

💌 G R E E T I N G ∙ C A R D S

Choose a printed card with your own message — or leave it blank \*\*to handwrite your note yourself\*\*.

\*\*Link to Greeting Cards list\*\* \[http://JamesWax.etsy.com/?section\_id=55381304\](http://jameswax.etsy.com/?section\_id=55381304)

✏️ C U S T O M I Z E ∙ Y O U R ∙ L A B E L

Make it personal!

Order directly here:

\*\*www.etsy.com/listing/1499335630\*\*

Be sure to include \*\*EXACTLY\*\* how you want the label to appear in the personalization box.

🚚 S H I P P I N G ∙ O P T I O N S

We ship fast from \*\*Southern California\*\* — all orders leave our studio within 1 business day.

\- \*\*Standard Ground (2-6 Business Days)\*\* – Free over $35

\- \*\*Priority USPS (+$5)\*\* – Arrives faster, usually 1-3 business days

\- \*\*FedEx Second Day Air\*\* – Highly recommended for East Coast orders and time-sensitive gifts. It’s the best way to ensure your package arrives exactly when you need it.

🕯️ C A N D L E ∙ Q U A L I T Y

Only \*\*3% of candles worldwide\*\* meet this safety standard.

\- \*\*100% California-sourced soy wax\*\*

\- Lead-free cotton wicks

\- Fragrance oils with \*\*no H351 or H361 substances\*\*

\- Vegan & cruelty-free — always

🛍️ A B O U T ∙ U S

We’re a \*\*small but mighty team\*\*, hand-pouring every candle in our Southern California studio.

Every order gets our full attention — because we know these gifts represent special moments in your life.

When you shop with us, you’re supporting actual makers, not a factory.

♻️ C A N D L E ∙ C A R E ∙ T I P S

\- Trim wick to \*\*1/4”\*\* before each burn

\- Let wax melt across the entire surface on the first burn to prevent tunneling

\- Burn for no more than 4 hours at a time

\- Stop burning when 1/4” of wax remains and clean jar for reuse

🔄 R E T U R N S ∙ & ∙ F R E E ∙ E X C H A N G E

\- If your candle arrives damaged or incorrect, we’ll fix it immediately — just send us a photo.

\- If you don’t love the scent, we offer \*\*one free exchange\*\* — no stress, no hassle.

✨ M O R E ∙ F R O M ∙ U S

Explore more of our collections:

[https://www.etsy.com/shop/JamesWax](https://www.etsy.com/shop/JamesWax)

✨ O U R ∙ S I S T E R ∙ B R A N D S

[https://www.etsy.com/shop/InkNWaxCandle](https://www.etsy.com/shop/InkNWaxCandle)

Minimalist-inspired candle designs for a sleek, modern aesthetic. 📐

[https://www.etsy.com/shop/TipsyApartment](https://www.etsy.com/shop/TipsyApartment)

Vintage-designed labels that bring timeless charm to your space. 🕰️

[https://www.etsy.com/shop/TallCupofCandle](https://www.etsy.com/shop/TallCupofCandle)

Coffee-inspired candles with warm tones for cozy vibes. ☕

[https://www.etsy.com/shop/BulldogTango](https://www.etsy.com/shop/BulldogTango)

Bright and bold old-school designs that stand out. 🎨

[https://www.etsy.com/shop/WicknWord](https://www.etsy.com/shop/WicknWord)

Dictionary-inspired candles for the word lovers. 📖

[https://www.etsy.com/shop/BirthdateGlow](https://www.etsy.com/shop/BirthdateGlow)

Zodiac-inspired candles for every birthday, with 366 unique designs. ✨

F A Q ✨

\|\| \*\*How fast do you ship?\*\* \|\|

We ship all orders within \*\*1 business day\*\* because we know you’re excited to get your candles!

Standard shipping usually arrives in 2-5 business days.

Priority USPS is available for +$5 (1-3 business days).

FedEx Second Day Air is highly recommended for East Coast orders or when you need it quickly.

\|\| \*\*Can I track my order?\*\* \|\|

Of course! Once your order ships, you’ll receive a tracking number so you can follow your package every step of the way.

\|\| \*\*What if my candle arrives damaged or I receive the wrong item?\*\* \|\|

Just send us a photo, and we’ll send a replacement right away — no hassle, no stress.

\|\| \*\*What are the candles made of?\*\* \|\|

Every candle is made with love using:

\- 100% California-sourced soy wax

\- Essential oil-infused fragrance oils

\- Lead-free cotton wicks

\- Reusable glass jars

\|\| \*\*Which scent should I gift?\*\* \|\|

If you’re not sure what to pick, \*\*Mimosa Pineapple\*\* is our best seller — bright, fresh, and universally loved!

\|\| \*\*Do you offer bulk or custom orders?\*\* \|\|

Yes! We create custom candles for weddings, corporate events, and special occasions.

Send us a message for a \*\*personalized quote\*\* and bulk discount.

\|\| \*\*Do you offer local pickup?\*\* \|\|

For orders of \*\*12 candles or more\*\*, we offer free local pickup from our Southern California studio.

Message us before placing your order to arrange a pickup time.

\|\| \*\*Can I exchange if I don’t like the scent?\*\* \|\|

Absolutely! We offer \*\*one free exchange\*\*, so you can shop with confidence.

Thank you so much for supporting our small business.

Have questions? Feel free to send us a message — we’re here to help and make your experience perfect.

Erica ♡


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-17**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 7 days


- Ships from: **Orange, CA**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## FAQs

🚚 How fast do you ship, and do you ship internationally?


We ship all orders within one business day because we know you’re excited to get your candles! Standard shipping usually arrives in 2 to 5 business days. If you need it faster, we offer express shipping for $5 (1 to 3 business days) or even overnight shipping. International shipping starts at $24.95. If you need more details, just reach out—we’re happy to help!


📦 What if my candle arrives damaged or incorrect?


We’re so sorry if this happens! Just send us a picture of the damaged or incorrect item, and we’ll send you a replacement right away.


🕯️ What are the candles made of, and where are they made?


Every candle is made with love using 100% California-sourced soy wax, essential oil-infused fragrance oils, lead-free cotton wicks, and glass jars. All of our candles are hand-poured in-house at our cozy studio in Orange County, California, by our small, hardworking team.


🌸 What type of fragrance oil do you use, and which scents are the strongest?


We use essential oil-infused fragrance oils that are non-toxic, paraben-free, and phthalate-free—some of the cleanest options available. For bold scents, we recommend Mimosa Pineapple or Coconut Orange. Prefer something softer? White Tea and Jasmine or Rose Patchouli are lovely lighter options.


📏 What size are the candles, and how long do they burn?


We offer one large 9oz size! Each candle measures 2.86 inches wide by 3.35 inches tall and burns for 40 to 50 hours—plenty of time to enjoy the glow and fragrance.


✍️ Can I customize my candle?


Yes! You can personalize your candle by selecting “Yes” for a customized label and typing in your message exactly as you’d like it to appear.


🎁 Do you offer gift wrapping?


Yes! We have a limited supply of adorable pink gift boxes. If you’d like your candle gift-wrapped, just let us know, and we’ll confirm availability. A small fee applies for this extra touch.


🎉 Do you offer custom orders, bulk orders, or discounts?


Absolutely! Whether you’re planning a corporate event, giving out holiday gifts, or ordering in bulk, we’d love to help. We also offer discounts for larger orders. Send us a message or email us at hello@jameswax.com, and we’ll provide a custom quote.


🤝 Do you offer pick up service?


Yes! If you’re ordering 12 candles or more, we’re happy to offer local pickup from our Orange County studio. Just send us a message before placing your order to coordinate.


🔄 What is your return and exchange policy?


If your candle arrives in less-than-perfect condition, we’ll take care of it—just let us know. If you change your mind about your order, we charge a small restocking fee plus shipping costs. We also offer one free exchange if you’re not happy with your scent—just reach out, and we’ll make it right!


## Meet your seller

![Erica](https://i.etsystatic.com/32386840/r/isla/025b6f/71484661/isla_75x75.71484661_59f3393y.jpg)

Erica

Owner of [JamesWax](https://www.etsy.com/shop/JamesWax?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo1NDc2Mjk0NzU6MTc2MjgyNDM2NToxZGNiYjg3YTIxZjFjYTgyNTFmYTNjODk0ZDM4MzYzZQ%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1679258677%2Fcustom-message-candle-personalized%3Famp%253Bclick_sum%3D4e81257a%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DFind%2B10%2BValentine%25E2%2580%2599s%2BDay%2Bgift%2Bcandles%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-611062-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Betp%3D1%26amp%253Bsts%3D1)

[Message Erica](https://www.etsy.com/messages/new?with_id=547629475&referring_id=1679258677&referring_type=listing&recipient_id=547629475&from_action=contact-seller)

This seller usually responds **within a few hours.**

## Reviews for this item (34)

5.0/5

item average

5.0Item quality

5.0Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Would recommend

Fast shipping

Smells amazing

Great quality

Gift-worthy

Love it

Unique


Filter by category


Quality (17)


Shipping & Packaging (11)


Seller service (8)


Appearance (6)


Description accuracy (3)


Value (2)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

[Julia MK](https://www.etsy.com/people/juliakniedler?ref=l_review)
Oct 28, 2025


Would absolutely recommend purchasing from this seller- this was exactly what I was looking for to gift someone special!



[Julia MK](https://www.etsy.com/people/juliakniedler?ref=l_review)
Oct 28, 2025


5 out of 5 stars
5

This item

[Veydra van de Leur](https://www.etsy.com/people/veydra?ref=l_review)
Sep 18, 2025


Great product. I will definitely order again.



[Veydra van de Leur](https://www.etsy.com/people/veydra?ref=l_review)
Sep 18, 2025


5 out of 5 stars
5

This item

[Abbi](https://www.etsy.com/people/AbbiJZ7797?ref=l_review)
Sep 10, 2025


The candles smell and look great and arrived just on time!



[Abbi](https://www.etsy.com/people/AbbiJZ7797?ref=l_review)
Sep 10, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/3dc51c/93607626/iusa_75x75.93607626_4knt.jpg?version=0)

[Mady Biagas](https://www.etsy.com/people/madybiagas?ref=l_review)
Aug 4, 2025


I love this candle! Exactly what I wanted and it smells wonderful!



![](https://i.etsystatic.com/iusa/3dc51c/93607626/iusa_75x75.93607626_4knt.jpg?version=0)

[Mady Biagas](https://www.etsy.com/people/madybiagas?ref=l_review)
Aug 4, 2025


View all reviews for this item

### Photos from reviews

![laura added a photo of their purchase](https://i.etsystatic.com/iap/51b9ff/6456357422/iap_300x300.6456357422_30wkxrjc.jpg?version=0)

[![JamesWax](https://i.etsystatic.com/iusa/60c498/111926589/iusa_75x75.111926589_ic8m.jpg?version=0)](https://www.etsy.com/shop/JamesWax?ref=shop_profile&listing_id=1679258677)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[JamesWax](https://www.etsy.com/shop/JamesWax?ref=shop_profile&listing_id=1679258677)

[Owned by Erica](https://www.etsy.com/shop/JamesWax?ref=shop_profile&listing_id=1679258677) \|

Irvine, California

4.9
(9k)


67k sales

4 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=547629475&referring_id=1679258677&referring_type=listing&recipient_id=547629475&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo1NDc2Mjk0NzU6MTc2MjgyNDM2NToxZGNiYjg3YTIxZjFjYTgyNTFmYTNjODk0ZDM4MzYzZQ%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1679258677%2Fcustom-message-candle-personalized%3Famp%253Bclick_sum%3D4e81257a%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DFind%2B10%2BValentine%25E2%2580%2599s%2BDay%2Bgift%2Bcandles%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-611062-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Betp%3D1%26amp%253Bsts%3D1)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/JamesWax?ref=lp_mys_mfts)

- [![Personalized Message Candle Funny Unique Custom Gift Surprise 100% Soy Candle Made in California Handmade For Friend Wife Husband P001](https://i.etsystatic.com/32386840/r/il/de2283/7389083349/il_340x270.7389083349_toer.jpg)\\
\\
**Personalized Message Candle Funny Unique Custom Gift Surprise 100% Soy Candle Made in California Handmade For Friend Wife Husband P001**\\
\\
Sale Price $12.95\\
$12.95\\
\\
$25.90\\
Original Price $25.90\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1499335630/personalized-message-candle-funny-unique?click_key=604c6536b44d4c9a76678e3be4323155%3ALT23aa0307e2bef62315cde6627b63a6bf62172e45&click_sum=cf414f95&ls=r&ref=related-1&pro=1&sts=1&content_source=604c6536b44d4c9a76678e3be4323155%253ALT23aa0307e2bef62315cde6627b63a6bf62172e45 "Personalized Message Candle Funny Unique Custom Gift Surprise 100% Soy Candle Made in California Handmade For Friend Wife Husband P001")




Add to Favorites


- [![Custom Message Candle Personalized Smells Like Your Message Candle Funny Handmade Unique Birthday Holiday Care Package Parent Friend P010](https://i.etsystatic.com/32386840/r/il/3cb594/7341105054/il_340x270.7341105054_1ti1.jpg)\\
\\
**Custom Message Candle Personalized Smells Like Your Message Candle Funny Handmade Unique Birthday Holiday Care Package Parent Friend P010**\\
\\
Sale Price $12.95\\
$12.95\\
\\
$25.90\\
Original Price $25.90\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1677788605/custom-message-candle-personalized?click_key=604c6536b44d4c9a76678e3be4323155%3ALTa090e2f540996ca0994a77fc87970f0252022a2e&click_sum=d20cfac6&ls=r&ref=related-2&pro=1&sts=1&content_source=604c6536b44d4c9a76678e3be4323155%253ALTa090e2f540996ca0994a77fc87970f0252022a2e "Custom Message Candle Personalized Smells Like Your Message Candle Funny Handmade Unique Birthday Holiday Care Package Parent Friend P010")




Add to Favorites


- [![New Home Gift My Own F*cking Place Personalized Candle Funny Custom Unique New Apartment Welcome Home Housewarming First Home Handmade L087](https://i.etsystatic.com/32386840/r/il/e0de1e/7389003687/il_340x270.7389003687_aou0.jpg)\\
\\
**New Home Gift My Own F\*cking Place Personalized Candle Funny Custom Unique New Apartment Welcome Home Housewarming First Home Handmade L087**\\
\\
Sale Price $10.95\\
$10.95\\
\\
$21.90\\
Original Price $21.90\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1774235025/new-home-gift-my-own-fcking-place?click_key=604c6536b44d4c9a76678e3be4323155%3ALTdffaba49ecb6bd183c31b32b161ac8d2aa70c186&click_sum=0234128c&ls=r&ref=related-3&pro=1&sts=1&content_source=604c6536b44d4c9a76678e3be4323155%253ALTdffaba49ecb6bd183c31b32b161ac8d2aa70c186 "New Home Gift My Own F*cking Place Personalized Candle Funny Custom Unique New Apartment Welcome Home Housewarming First Home Handmade L087")




Add to Favorites


- [![Nurse Practitioner Gift Badass Nurse Practitioner Custom Candle Funny Unique Handmade New NP Nursing Grads Graduate Nursing School F444B](https://i.etsystatic.com/32386840/r/il/1c638c/7341126378/il_340x270.7341126378_5xkp.jpg)\\
\\
**Nurse Practitioner Gift Badass Nurse Practitioner Custom Candle Funny Unique Handmade New NP Nursing Grads Graduate Nursing School F444B**\\
\\
Sale Price $10.95\\
$10.95\\
\\
$21.90\\
Original Price $21.90\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1706726209/nurse-practitioner-gift-badass-nurse?click_key=67ce42a0bd4c5af6d729d9bf36cffc61d1c23532%3A1706726209&click_sum=1613f309&ref=related-4&pro=1&sts=1 "Nurse Practitioner Gift Badass Nurse Practitioner Custom Candle Funny Unique Handmade New NP Nursing Grads Graduate Nursing School F444B")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 10, 2025


[84 favorites](https://www.etsy.com/listing/1679258677/custom-message-candle-personalized/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=4e81257a&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&%3Bref=search_grid-611062-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Betp=1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=4e81257a&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&%3Bref=search_grid-611062-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Betp=1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=4e81257a&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&%3Bref=search_grid-611062-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Betp=1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=4e81257a&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&%3Bref=search_grid-611062-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Betp=1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Container Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/container-candles?amp%3Bclick_sum=4e81257a&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&%3Bref=search_grid-611062-1-2&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bpro=1&%3Betp=1&%3Bsts=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Shopping

[Shawls Curtains - US](https://www.etsy.com/market/shawls_curtains)

Home Decor

[Harlequin Reindeer for Sale](https://www.etsy.com/market/harlequin_reindeer) [Buy Vintage Crochet Stockings Online](https://www.etsy.com/market/vintage_crochet_stockings) [Regifting Christmas for Sale](https://www.etsy.com/market/regifting_christmas) [Key West Wooden Gifts - US](https://www.etsy.com/market/key_west_wooden_gifts) [Halle Gift for Sale](https://www.etsy.com/market/halle_gift) [Shop Silver Oak Decor](https://www.etsy.com/market/silver_oak_decor) [Hallmark Toy Ornaments - US](https://www.etsy.com/market/hallmark_toy_ornaments) [Ice Cream Cart Decals - US](https://www.etsy.com/market/ice_cream_cart_decals) [Resin Plaque Sign Wall Hanging Round Shape Black Red Green Lock You Hold The Key To My Heart Glitter (1018plaq) by BreathtakingBeadzz](https://www.etsy.com/listing/1757965027/resin-plaque-sign-wall-hanging-round) [Striped kilim pillow - Home Decor](https://www.etsy.com/listing/1741515351/bohemian-kilim-pillow-case-striped-kilim) [Lake Como Boat Artwork by JoshWilsonPrints](https://www.etsy.com/listing/1083596613/lake-como-boat-artwork-dolce-far-niente) [Pet Lovers Gift Dog Owner and Pet Ornament Personalized Dog Memorial Ornament Golden Retriever Ornament Pet Christmas Gift for Dog Owner - Home Decor](https://www.etsy.com/listing/1627183007/pet-lovers-gift-dog-owner-and-pet) [Shop Scottish Bagpiper Figurines](https://www.etsy.com/market/scottish_bagpiper_figurines)

Electronics Cases

[Botanical Pumpkin Phone Cases - Electronics Cases](https://www.etsy.com/listing/1768216472/clear-fall-phone-case-botanical-pumpkin)

Toys

[Buy Grizz Plush Online](https://www.etsy.com/market/grizz_plush)

Drawing & Illustration

[Shop Barndominium Floor Plans 3 Bedroom Garage](https://www.etsy.com/market/barndominium_floor_plans_3_bedroom_garage)

Raw Materials

[Glass Tube Bottle for Sale](https://www.etsy.com/market/glass_tube_bottle)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1679258677%2Fcustom-message-candle-personalized%3Famp%253Bclick_sum%3D4e81257a%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DFind%2B10%2BValentine%25E2%2580%2599s%2BDay%2Bgift%2Bcandles%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-611062-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Betp%3D1%26amp%253Bsts%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgyNDM2NTozYTcxZjljOGRkOTk5MTBkY2VkODhlNjA1NjQ1YjQ5OA==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1679258677%2Fcustom-message-candle-personalized%3Famp%253Bclick_sum%3D4e81257a%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DFind%2B10%2BValentine%25E2%2580%2599s%2BDay%2Bgift%2Bcandles%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-611062-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Betp%3D1%26amp%253Bsts%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1679258677/custom-message-candle-personalized?amp;click_sum=4e81257a&amp;ls=a&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=Find+10+Valentine%E2%80%99s+Day+gift+candles+on+Etsy&amp;ref=search_grid-611062-1-2&amp;sr_prefetch=1&amp;pf_from=search&amp;pro=1&amp;etp=1&amp;sts=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1679258677%2Fcustom-message-candle-personalized%3Famp%253Bclick_sum%3D4e81257a%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DFind%2B10%2BValentine%25E2%2580%2599s%2BDay%2Bgift%2Bcandles%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-611062-1-2%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bpro%3D1%26amp%253Betp%3D1%26amp%253Bsts%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for JamesWax

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: not accepted

Please contact the seller if you have any problems with your order.

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![a series of photos showing different types of teas](https://i.etsystatic.com/32386840/r/il/bc5470/7341050642/il_300x300.7341050642_k0b5.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/USD%7Cen-US%7CUS_484b14e46a7f1b8a2988801056865dae.jpg)

- ![The image is a screenshot of a text conversation with two chat bubbles, each containing a person's face and a candle. The conversation appears to be about the candle's size and features, with one person asking about the candle's size and the other person responding with information about the candle.](https://i.etsystatic.com/32386840/r/il/d89456/7388988995/il_300x300.7388988995_7kl8.jpg)
- ![The image is a product description for a "Build Your Own Box" gift. It features a candle, a curated gift box, a greeting card, and a hand holding a greeting card. The product description includes the product name, the "Build Your Own Box" link, and the greeting card. The image does not contain any redundancy or vague descriptions.](https://i.etsystatic.com/32386840/r/il/fbcc5b/7341050808/il_300x300.7341050808_9z28.jpg)
- ![The image is a collage of various items related to sleep and relaxation, including a green tea cup, a gold-colored eye mask, pink socks, a pink candle, and tea bags.](https://i.etsystatic.com/32386840/r/il/eab6a1/7341050872/il_300x300.7341050872_rq76.jpg)
- ![The image is a collage of various items, including a vegan leather notebook, a 4 oz travel candle, a gold metal tray, a pen, a candle, and a pair of scissors.](https://i.etsystatic.com/32386840/r/il/80ee3a/7341050940/il_300x300.7341050940_bkcm.jpg)
- ![The image is a collage of various beauty and personal care items, including a pair of pink socks, a golden metal tray, a pair of scissors, a gold-colored eye mask, a rose and mint tea bag, a satin sleeping mask, a rose and mint tea bag, a free embroidered duffel bag, a white tea candle, a candle of your choice, a personalized bag, and a travel candle.](https://i.etsystatic.com/32386840/r/il/0a7789/7341051018/il_300x300.7341051018_jxuo.jpg)
- ![A candle labeled "CANDLE OF YOUR CHOICE" in a pink and orange color scheme, with dimensions and weight information provided.](https://i.etsystatic.com/32386840/r/il/d1f82b/7341051100/il_300x300.7341051100_hhk3.jpg)
- ![The image is a close-up of white soy wax chunks, with text above them stating that the product is made with 100% soy wax and is vegan, free of parabens, paraffin, dye, and cruelty-free.](https://i.etsystatic.com/32386840/r/il/9ac5e8/7341051192/il_300x300.7341051192_uqun.jpg)
- ![A collage of images featuring a person cooking in a kitchen, with the text "We make everything in our own studio" surrounding the images.](https://i.etsystatic.com/32386840/r/il/3c52df/7341051262/il_300x300.7341051262_9l30.jpg)
- ![The image is a collage of four different images, each depicting a different scent or product. The first image shows a bouquet of pink flowers, the second image features a glass of champagne, the third image shows a person relaxing in a bathtub, and the fourth image depicts a tropical beach scene with palm trees and a sunset.](https://i.etsystatic.com/32386840/r/il/ae5f15/7341051354/il_300x300.7341051354_2w7o.jpg)
- ![a collage of nine greeting cards, each held by a hand. The cards feature various messages and designs, such as "Thank you", "Greeting card", "Will you be my bridesmaid?", "Happy birthday", and "Cheers". The cards are arranged in a grid format, with three rows and three columns.](https://i.etsystatic.com/32386840/r/il/1a3672/7341051416/il_300x300.7341051416_6c7l.jpg)
- ![The image is a collage of three photos featuring two women sitting together, with a third photo of a candle in the background.](https://i.etsystatic.com/32386840/r/il/268bfa/7341051500/il_300x300.7341051500_76lp.jpg)
- ![a five-star review of a candle, with a rating of over 8,000+ stars. The review describes the candle as fantastic for a friend's gift, highly recommended, and the company's customer service as beyond impeccable. The review also mentions an unpleasant experience with the company's delivery service and their understanding and helpfulness in finding a solution.](https://i.etsystatic.com/32386840/r/il/9de361/7341051576/il_300x300.7341051576_nz0n.jpg)
- ![a series of questions and answers related to candles, including their size, wax type, and wick type.](https://i.etsystatic.com/32386840/r/il/ef2834/7341051620/il_300x300.7341051620_3zpf.jpg)
- ![The image is a product description for candles, with a focus on customization options. It provides information about how to customize a candle label and offers the option to make white-label candles. The image also mentions that the company can offer custom scents and packaging, and encourages customers to learn more.](https://i.etsystatic.com/32386840/r/il/43d31e/7341051670/il_300x300.7341051670_rj3b.jpg)
- ![a Shipping FAQ that provides information about shipping orders. It includes details about shipping times, priority, and shipping options. The image does not contain any text that describes the image in detail, and it does not include any phrases that might be considered redundancy or vague wording.](https://i.etsystatic.com/32386840/r/il/27344b/7341051724/il_300x300.7341051724_1pm8.jpg)
- ![Wholesale FAQ](https://i.etsystatic.com/32386840/r/il/46fe0d/7388989935/il_300x300.7388989935_ilvc.jpg)

- ![](https://i.etsystatic.com/iap/51b9ff/6456357422/iap_640x640.6456357422_30wkxrjc.jpg?version=0)











5 out of 5 stars





- Signature Scents:

03\. White Tea + Jasmine

- Need a Custom Label?:

Yes, Customize My Label!


I cannot recommend these candles enough - so cute, such quick service, and the smell is amazing. My friend said, "I'm never going to burn this, it is SO CUTE!" Hopefully, she does - because it smells so good too! Order all in smell: 3. White Tea + Jasmine.

![](https://i.etsystatic.com/iusa/30f7ec/101257108/iusa_75x75.101257108_dzm4.jpg?version=0)

Nov 24, 2024


[laura k](https://www.etsy.com/people/of0e7lct)

Purchased item:

[![Custom Message Candle Personalized Handmade Gift Funny Unique Party Favor Care Package For Partner Friend Spouse Made in California P001B](https://i.etsystatic.com/32386840/r/il/bc5470/7341050642/il_170x135.7341050642_k0b5.jpg)\\
\\
Custom Message Candle Personalized Handmade Gift Funny Unique Party Favor Care Package For Partner Friend Spouse Made in California P001B\\
\\
Sale Price $12.95\\
$12.95\\
\\
$25.90\\
Original Price $25.90\\
\\
\\
(50% off)](https://www.etsy.com/listing/1679258677/custom-message-candle-personalized?ref=ap-listing)

Purchased item:

[![Custom Message Candle Personalized Handmade Gift Funny Unique Party Favor Care Package For Partner Friend Spouse Made in California P001B](https://i.etsystatic.com/32386840/r/il/bc5470/7341050642/il_170x135.7341050642_k0b5.jpg)\\
\\
Custom Message Candle Personalized Handmade Gift Funny Unique Party Favor Care Package For Partner Friend Spouse Made in California P001B\\
\\
Sale Price $12.95\\
$12.95\\
\\
$25.90\\
Original Price $25.90\\
\\
\\
(50% off)](https://www.etsy.com/listing/1679258677/custom-message-candle-personalized?ref=ap-listing)