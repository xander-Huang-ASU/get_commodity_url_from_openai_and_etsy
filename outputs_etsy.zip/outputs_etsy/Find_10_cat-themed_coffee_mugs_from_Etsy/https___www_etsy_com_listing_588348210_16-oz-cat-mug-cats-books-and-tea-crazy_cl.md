[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/588348210/16-oz-cat-mug-cats-books-and-tea-crazy?amp;click_sum=d61cdda8&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3&amp;sts=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Shop Local\\
\\
New](https://www.etsy.com/search/shops?ref=global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=d61cdda8&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-0)
- [Kitchen & Dining](https://www.etsy.com/c/home-and-living/kitchen-and-dining?amp%3Bclick_sum=d61cdda8&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-1)
- [Drink & Barware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware?amp%3Bclick_sum=d61cdda8&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-2)
- [Drinkware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware?amp%3Bclick_sum=d61cdda8&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-3)
- [Mugs](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/mugs?amp%3Bclick_sum=d61cdda8&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-4)

Etsy’s Pick

Etsy’s Picks are hand selected by our style experts to highlight items from shops that have shown quality, reliability and style.

[Discover More](https://www.etsy.com/featured/hub/etsy-picks?ref=listing_etsys_pick_signal)


Add to Favorites


- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug Sky](https://i.etsystatic.com/8161260/r/il/e0dc07/7295077396/il_794xN.7295077396_fzu8.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 2](https://i.etsystatic.com/8161260/r/il/c7fc80/7343024605/il_794xN.7343024605_kujx.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 3](https://i.etsystatic.com/8161260/r/il/3ab996/7295077392/il_794xN.7295077392_3un1.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 4](https://i.etsystatic.com/8161260/r/il/6ebceb/7295077390/il_794xN.7295077390_2rj3.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug Rain](https://i.etsystatic.com/8161260/r/il/bb8db8/7343024617/il_794xN.7343024617_py4o.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 6](https://i.etsystatic.com/8161260/r/il/a9746d/7343024611/il_794xN.7343024611_gdru.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug Ironstone](https://i.etsystatic.com/8161260/r/il/29b0e2/7343024619/il_794xN.7343024619_n4hx.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 8](https://i.etsystatic.com/8161260/r/il/1aca5b/7343024623/il_794xN.7343024623_ovl4.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 9](https://i.etsystatic.com/8161260/r/il/9e2823/7343024613/il_794xN.7343024613_c7vd.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug Birch](https://i.etsystatic.com/8161260/r/il/6ee491/7343024615/il_794xN.7343024615_eujm.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 11](https://i.etsystatic.com/8161260/r/il/57577b/7343024609/il_794xN.7343024609_sarx.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug Purple](https://i.etsystatic.com/8161260/r/il/1fe280/7295077402/il_794xN.7295077402_i0is.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 13](https://i.etsystatic.com/8161260/r/il/c88cfe/7343024625/il_794xN.7343024625_cqhf.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 14](https://i.etsystatic.com/8161260/r/il/54267e/7295077386/il_794xN.7295077386_h5b7.jpg)

- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug Sky](https://i.etsystatic.com/8161260/r/il/e0dc07/7295077396/il_75x75.7295077396_fzu8.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 2](https://i.etsystatic.com/8161260/r/il/c7fc80/7343024605/il_75x75.7343024605_kujx.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 3](https://i.etsystatic.com/8161260/r/il/3ab996/7295077392/il_75x75.7295077392_3un1.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 4](https://i.etsystatic.com/8161260/r/il/6ebceb/7295077390/il_75x75.7295077390_2rj3.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug Rain](https://i.etsystatic.com/8161260/r/il/bb8db8/7343024617/il_75x75.7343024617_py4o.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 6](https://i.etsystatic.com/8161260/r/il/a9746d/7343024611/il_75x75.7343024611_gdru.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug Ironstone](https://i.etsystatic.com/8161260/r/il/29b0e2/7343024619/il_75x75.7343024619_n4hx.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 8](https://i.etsystatic.com/8161260/r/il/1aca5b/7343024623/il_75x75.7343024623_ovl4.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 9](https://i.etsystatic.com/8161260/r/il/9e2823/7343024613/il_75x75.7343024613_c7vd.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug Birch](https://i.etsystatic.com/8161260/r/il/6ee491/7343024615/il_75x75.7343024615_eujm.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 11](https://i.etsystatic.com/8161260/r/il/57577b/7343024609/il_75x75.7343024609_sarx.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug Purple](https://i.etsystatic.com/8161260/r/il/1fe280/7295077402/il_75x75.7295077402_i0is.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 13](https://i.etsystatic.com/8161260/r/il/c88cfe/7343024625/il_75x75.7343024625_cqhf.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 14](https://i.etsystatic.com/8161260/r/il/54267e/7295077386/il_75x75.7295077386_h5b7.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F588348210%2F16-oz-cat-mug-cats-books-and-tea-crazy%23report-overlay-trigger)

6 views in the last 24 hours

Price:$53.00


Loading


# 16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug

[MesireeCeramics](https://www.etsy.com/shop/MesireeCeramics?ref=shop-header-name&listing_id=588348210&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/588348210/16-oz-cat-mug-cats-books-and-tea-crazy?amp;click_sum=d61cdda8&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3&amp;sts=1#reviews)

Arrives soon! Get it by

Nov 14-22


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns accepted

Primary color


Select a color

Ironstone

Purple

Birch

Rain \[Sold out\]

Sky

Please select a color


From **$18/month**, or 4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Item details

### Highlights

Made by [MesireeCeramics](https://www.etsy.com/shop/MesireeCeramics)

- Materials: Ceramic


- Capacity: 16 fluid ounces

\*\*\*You will receive the exact mug pictured in the color you order\*\*\*

Care

• Food, Microwave and Dishwasher safe. Yes. Really!

Variation

• Handmade, wheel thrown, hand carved. No two are 100% alike, please allow for minor variances in design and shape.

• Handedness – if you have strong opinions, contact us!

• Glaze color – Our glazes are dynamic; no two mugs will turn out the same. They will be darker/lighter, with highlights/lowlights, drips, streaks, and movement.

• We do our best to accurately depict our mugs in photos, but they may appear differently on different screens.

• Feel free to contact us for a picture of your specific mug before ordering if you have any concerns!

Shipping

• We ship all our mugs individually. It is simply the safest way to ship them.

• We ship our mugs in heavy indented kraft paper. It's recycled, recyclable and does an admirable job of protecting our pottery on its journey through post.

Returns

• Please make sure to inspect your item upon receipt, even if it is a gift. We only accept returns within the 14 days after delivery. If any of our ware is damaged when you receive it or you are unhappy with it please let us know immediately and we'll take care of you!

• Shipping fees on returns or exchanges that are not related to damaged or flawed items are the buyer’s responsibility per the standard Etsy policy.

Custom Orders

• We’re sorry, but we do not accept custom orders.


## Shipping and return policies

Loading


- Order today to get by

**Nov 14-22**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 14 days


- Ships from: **Howell, MI**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaNew ZealandThe NetherlandsUnited KingdomUnited States\-\-\--------American SamoaAustraliaCanadaChristmas IslandCocos (Keeling) IslandsCook IslandsFijiFinlandFrench PolynesiaGuamKiribatiMarshall IslandsMicronesia, Federated States ofNauruNew CaledoniaNew ZealandNiueNorfolk IslandNorthern Mariana IslandsPalauPapua New GuineaPuerto RicoSaint Pierre and MiquelonSamoaSolomon IslandsThe NetherlandsTimor-LesteTokelauTongaTuvaluUnited KingdomUnited StatesVanuatuWallis and Futuna

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## FAQs

Custom and personalized orders


We do not do any custom orders as our show schedule is too busy to accommodate them.

However, we do take Made to Order mug orders for our existing designs and current glazes from January through September (the holiday season is just too busy to juggle special orders). It costs $5 more and can take up to 2-3 months to complete. If you are interested please send us a message.


Care instructions


All our mugs are food, microwave and dishwasher safe. Good for hot or cold beverages. Lead free. Use them the same as you would any normal coffee mug.


Trades


This is our full time day job. Unfortunately, we can't do any trades, we have to pay the bills.


Variations (Color, Handedness, Etc)


Unless specified in the listing you may not receive the exact mug pictured, that includes handedness (everyone seems to have a different definition of handedness). We list our mugs by design and color. If you have concrete opinions on which way the design should face when held in a particular hand please contact us before you order to make sure the handedness you desire is in stock.

Glaze colors are difficult to convey by digital media. We try very hard to get our pictures true to color, but due to the reflective and dynamic nature of glaze as well as the differences between monitor settings they may not be exact.


What if an item arrives broken?


Please make sure to inspect your item upon receipt. If any of our ware is damaged when you receive it please let us know immediately and we'll take care of you!


Why don't you use bubble wrap?


Because it's terrible. Seriously.

We found that no matter how many layers of bubble wrap we use rims and handles always manage to find a space between the bubbles and break. Since switching to heavy indented kraft paper as our packaging material our breakage rate is almost zero.

Also, it is recycled and recyclable!


Is there a discount on shipping multiple mugs?


Sadly, no. In the interest of getting each and every mug to its new home in one, solid, undamaged piece we ship each mug individually. We won't make exceptions on it. Too many tears have been shed.


Gift Purchases


Our mugs make great gifts, and they can be shipped to friends and family all over the world! If you are surprising a loved one with a mug please watch the tracking information! Check with them within a day or two that it was marked as delivered. It is much more likely to find lost mugs within the first couple days after delivery.


Lost/Delayed Package


If your package has been marked 'delivered' but isn't at your home call your local post office as soon as possible. They have the resources to help you track down your package. Don't hesitate call them back a couple times. Sometimes it takes a few days to figure out what happened to your package.

Do contact us and keep us apprised of the situation. Unfortunately, there is very little that we can do until the post office marks the delivery as lost.


## Reviews for this item (49)

5.0/5

item average

5.0Item quality

5.0Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Love it

Beautiful

Fast shipping

Well packaged

Gift-worthy

Love the shop

Great product


Filter by category


Appearance (24)


Quality (17)


Shipping & Packaging (15)


Comfort (4)


Seller service (4)


Description accuracy (2)


Value (1)


Sizing & Fit (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/62f677/21778658/iusa_75x75.21778658_n7f9.jpg?version=0)

[Tara Egan](https://www.etsy.com/people/smiletara?ref=l_review)
Nov 20, 2024


My mug is beautiful. It looks just as described and seems very sturdy. It shipped super quickly and I'm delighted!



![](https://i.etsystatic.com/iusa/62f677/21778658/iusa_75x75.21778658_n7f9.jpg?version=0)

[Tara Egan](https://www.etsy.com/people/smiletara?ref=l_review)
Nov 20, 2024


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/70b91c/111731537/iusa_75x75.111731537_2qgl.jpg?version=0)

[daniela pardo](https://www.etsy.com/people/danielap1?ref=l_review)
Mar 24, 2024


I had broken my last purchase so I had to replace it. Love their mugs, great designs.



![daniela pardo added a photo of their purchase](https://i.etsystatic.com/iap/228642/6010874513/iap_300x300.6010874513_td3pa6p9.jpg?version=0)

![](https://i.etsystatic.com/iusa/70b91c/111731537/iusa_75x75.111731537_2qgl.jpg?version=0)

[daniela pardo](https://www.etsy.com/people/danielap1?ref=l_review)
Mar 24, 2024


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/9d1ceb/58973119/iusa_75x75.58973119_mnba.jpg?version=0)

[Dana Mae](https://www.etsy.com/people/u5bv4di8?ref=l_review)
Mar 13, 2024


Big fan of these mugs! Shipping was good and item wrapped with care. Feels lovely in hand.



![Dana Mae added a photo of their purchase](https://i.etsystatic.com/iap/a3e7c7/5887341363/iap_300x300.5887341363_7pcfe3r3.jpg?version=0)

![](https://i.etsystatic.com/iusa/9d1ceb/58973119/iusa_75x75.58973119_mnba.jpg?version=0)

[Dana Mae](https://www.etsy.com/people/u5bv4di8?ref=l_review)
Mar 13, 2024


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/440359/93369269/iusa_75x75.93369269_5rbr.jpg?version=0)

[Christine Lamoreaux](https://www.etsy.com/people/meyebaine?ref=l_review)
Mar 10, 2024


Purrfect in every way conceivable



![](https://i.etsystatic.com/iusa/440359/93369269/iusa_75x75.93369269_5rbr.jpg?version=0)

[Christine Lamoreaux](https://www.etsy.com/people/meyebaine?ref=l_review)
Mar 10, 2024


View all reviews for this item

### Photos from reviews

![Monica added a photo of their purchase](https://i.etsystatic.com/iap/cd6675/4429490327/iap_300x300.4429490327_scb84v95.jpg?version=0)

![daniela added a photo of their purchase](https://i.etsystatic.com/iap/228642/6010874513/iap_300x300.6010874513_td3pa6p9.jpg?version=0)

![Dana added a photo of their purchase](https://i.etsystatic.com/iap/a3e7c7/5887341363/iap_300x300.5887341363_7pcfe3r3.jpg?version=0)

![daniela added a photo of their purchase](https://i.etsystatic.com/iap/3fed86/5476534526/iap_300x300.5476534526_bbymexrs.jpg?version=0)

![Danielle added a photo of their purchase](https://i.etsystatic.com/iap/72031b/3003810160/iap_300x300.3003810160_ep9pll43.jpg?version=0)

![Kaycee added a photo of their purchase](https://i.etsystatic.com/iap/e19c86/2975223605/iap_300x300.2975223605_s0w7t2vw.jpg?version=0)

![torena added a photo of their purchase](https://i.etsystatic.com/iap/8decda/2907250328/iap_300x300.2907250328_2buuncr9.jpg?version=0)

![Travis added a photo of their purchase](https://i.etsystatic.com/iap/64b592/2629071958/iap_300x300.2629071958_d04w940n.jpg?version=0)

[![MesireeCeramics](https://i.etsystatic.com/iusa/b72e01/34403628/iusa_75x75.34403628_c5yd.jpg?version=0)](https://www.etsy.com/shop/MesireeCeramics?ref=shop_profile&listing_id=588348210)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[MesireeCeramics](https://www.etsy.com/shop/MesireeCeramics?ref=shop_profile&listing_id=588348210)

[Owned by Desiree and Mary](https://www.etsy.com/shop/MesireeCeramics?ref=shop_profile&listing_id=588348210) \|

Howell, Michigan

5.0
(3.9k)


11.6k sales

12 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=33722091&referring_id=588348210&referring_type=listing&recipient_id=33722091&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDozMzcyMjA5MToxNzYyODA3NjMyOjY0NWE4ZDEyNTNmNjdjMzJmZjZjMmFlMWJiNDgzY2Nh&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F588348210%2F16-oz-cat-mug-cats-books-and-tea-crazy%3Famp%253Bclick_sum%3Dd61cdda8%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bsts%3D1)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/MesireeCeramics?ref=lp_mys_mfts)

- [![Snail Mug 16 oz - Nature Lover Gift Handmade Stoneware Coffee Mug - Tea Lover Gift Nature Mug - Large Tea Mug](https://i.etsystatic.com/8161260/r/il/706d14/7385615211/il_340x270.7385615211_bwfs.jpg)\\
\\
**Snail Mug 16 oz - Nature Lover Gift Handmade Stoneware Coffee Mug - Tea Lover Gift Nature Mug - Large Tea Mug**\\
\\
$53.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/255755849/snail-mug-16-oz-nature-lover-gift?click_key=4e649525e5892a2fe0e42c9142dfe9bd%3ALT0e51b868190939101b40baf49ee5739c355f8d76&click_sum=09c34a0c&ls=r&ref=related-1&sts=1&content_source=4e649525e5892a2fe0e42c9142dfe9bd%253ALT0e51b868190939101b40baf49ee5739c355f8d76 "Snail Mug 16 oz - Nature Lover Gift Handmade Stoneware Coffee Mug - Tea Lover Gift Nature Mug - Large Tea Mug")




Add to Favorites


- [![Jackalope Mug 16oz - Handmade Stoneware Coffee Mug Jackalope Art - Mythical Creatures Fairytale Gift Unique Coffee Mugs](https://i.etsystatic.com/8161260/r/il/202f8e/7300748245/il_340x270.7300748245_8x8f.jpg)\\
\\
**Jackalope Mug 16oz - Handmade Stoneware Coffee Mug Jackalope Art - Mythical Creatures Fairytale Gift Unique Coffee Mugs**\\
\\
$53.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/484953493/jackalope-mug-16oz-handmade-stoneware?click_key=4e649525e5892a2fe0e42c9142dfe9bd%3ALTe88b84d378b12fce8c5d13440507dc0f017608e7&click_sum=afdb8796&ls=r&ref=related-2&sts=1&content_source=4e649525e5892a2fe0e42c9142dfe9bd%253ALTe88b84d378b12fce8c5d13440507dc0f017608e7 "Jackalope Mug 16oz - Handmade Stoneware Coffee Mug Jackalope Art - Mythical Creatures Fairytale Gift Unique Coffee Mugs")




Add to Favorites


- [![Crow Mug 16oz - Dark Academia Handmade Stoneware Coffee Mug - Cute Coffee Mug - Unique Coffee Mugs - Coffee Lover Gift Large Mug](https://i.etsystatic.com/8161260/r/il/5901ad/7183600285/il_340x270.7183600285_qof6.jpg)\\
\\
**Crow Mug 16oz - Dark Academia Handmade Stoneware Coffee Mug - Cute Coffee Mug - Unique Coffee Mugs - Coffee Lover Gift Large Mug**\\
\\
$53.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4303293780/crow-mug-16oz-dark-academia-handmade?click_key=4e649525e5892a2fe0e42c9142dfe9bd%3ALTcf30d4e533a04ffa46be3690cdbd0501305127f0&click_sum=4508c57b&ls=r&ref=related-3&sts=1&content_source=4e649525e5892a2fe0e42c9142dfe9bd%253ALTcf30d4e533a04ffa46be3690cdbd0501305127f0 "Crow Mug 16oz - Dark Academia Handmade Stoneware Coffee Mug - Cute Coffee Mug - Unique Coffee Mugs - Coffee Lover Gift Large Mug")




Add to Favorites


- [![Jackalope Mug 16oz - Handmade Stoneware Coffee Mug Jackalope Art - Mythical Creatures Fairytale Gift Unique Coffee Mugs](https://i.etsystatic.com/8161260/r/il/888e7e/7295027750/il_340x270.7295027750_405b.jpg)\\
\\
**Jackalope Mug 16oz - Handmade Stoneware Coffee Mug Jackalope Art - Mythical Creatures Fairytale Gift Unique Coffee Mugs**\\
\\
$53.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1405800032/jackalope-mug-16oz-handmade-stoneware?click_key=4e649525e5892a2fe0e42c9142dfe9bd%3ALT8e6ab3eec7dab91d5b90527dcfcb735529d8975d&click_sum=ca00c925&ls=r&ref=related-4&sts=1&content_source=4e649525e5892a2fe0e42c9142dfe9bd%253ALT8e6ab3eec7dab91d5b90527dcfcb735529d8975d "Jackalope Mug 16oz - Handmade Stoneware Coffee Mug Jackalope Art - Mythical Creatures Fairytale Gift Unique Coffee Mugs")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 8, 2025


[655 favorites](https://www.etsy.com/listing/588348210/16-oz-cat-mug-cats-books-and-tea-crazy/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=d61cdda8&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Kitchen & Dining](https://www.etsy.com/c/home-and-living/kitchen-and-dining?amp%3Bclick_sum=d61cdda8&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Drink & Barware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware?amp%3Bclick_sum=d61cdda8&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Drinkware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware?amp%3Bclick_sum=d61cdda8&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Mugs](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/mugs?amp%3Bclick_sum=d61cdda8&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=breadcrumb_listing)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F588348210%2F16-oz-cat-mug-cats-books-and-tea-crazy%3Famp%253Bclick_sum%3Dd61cdda8%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bsts%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgwNzYzMjo5Y2RkMDFlNTQ3NzE4YjZkYThlYWFmNGFjM2FhZDQ2Mg==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F588348210%2F16-oz-cat-mug-cats-books-and-tea-crazy%3Famp%253Bclick_sum%3Dd61cdda8%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bsts%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/588348210/16-oz-cat-mug-cats-books-and-tea-crazy?amp;click_sum=d61cdda8&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3&amp;sts=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F588348210%2F16-oz-cat-mug-cats-books-and-tea-crazy%3Famp%253Bclick_sum%3Dd61cdda8%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bsts%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for MesireeCeramics

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: before item has shipped

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## Seller details

### Other details

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=33722091&referring_id=8161260&referring_type=shop&recipient_id=33722091&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Item in the photo is in **Primary color: Sky**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Primary color: Rain**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Primary color: Ironstone**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Primary color: Birch**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Primary color: Purple**




Select this option








Option selected!













This option is sold out.



Click to zoom

- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug Sky](https://i.etsystatic.com/8161260/r/il/e0dc07/7295077396/il_300x300.7295077396_fzu8.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 2](https://i.etsystatic.com/8161260/r/il/c7fc80/7343024605/il_300x300.7343024605_kujx.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 3](https://i.etsystatic.com/8161260/r/il/3ab996/7295077392/il_300x300.7295077392_3un1.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 4](https://i.etsystatic.com/8161260/r/il/6ebceb/7295077390/il_300x300.7295077390_2rj3.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug Rain](https://i.etsystatic.com/8161260/r/il/bb8db8/7343024617/il_300x300.7343024617_py4o.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 6](https://i.etsystatic.com/8161260/r/il/a9746d/7343024611/il_300x300.7343024611_gdru.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug Ironstone](https://i.etsystatic.com/8161260/r/il/29b0e2/7343024619/il_300x300.7343024619_n4hx.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 8](https://i.etsystatic.com/8161260/r/il/1aca5b/7343024623/il_300x300.7343024623_ovl4.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 9](https://i.etsystatic.com/8161260/r/il/9e2823/7343024613/il_300x300.7343024613_c7vd.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug Birch](https://i.etsystatic.com/8161260/r/il/6ee491/7343024615/il_300x300.7343024615_eujm.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 11](https://i.etsystatic.com/8161260/r/il/57577b/7343024609/il_300x300.7343024609_sarx.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug Purple](https://i.etsystatic.com/8161260/r/il/1fe280/7295077402/il_300x300.7295077402_i0is.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 13](https://i.etsystatic.com/8161260/r/il/c88cfe/7343024625/il_300x300.7343024625_cqhf.jpg)
- ![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug image 14](https://i.etsystatic.com/8161260/r/il/54267e/7295077386/il_300x300.7295077386_h5b7.jpg)

- ![](https://i.etsystatic.com/iap/cd6675/4429490327/iap_640x640.4429490327_scb84v95.jpg?version=0)

5 out of 5 stars

- Color:

White


Perfect! Beautiful cup. Husband loves it! Thanks!

![](https://i.etsystatic.com/iusa/7effdc/94775525/iusa_75x75.94775525_9klx.jpg?version=0)

Nov 25, 2022


[Monica Hart](https://www.etsy.com/people/monicahart744)

Purchased item:

[![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug](https://i.etsystatic.com/8161260/r/il/e0dc07/7295077396/il_170x135.7295077396_fzu8.jpg)\\
\\
16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug\\
\\
$53.00](https://www.etsy.com/listing/588348210/16-oz-cat-mug-cats-books-and-tea-crazy?ref=ap-listing)

Purchased item:

[![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug](https://i.etsystatic.com/8161260/r/il/e0dc07/7295077396/il_170x135.7295077396_fzu8.jpg)\\
\\
16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug\\
\\
$53.00](https://www.etsy.com/listing/588348210/16-oz-cat-mug-cats-books-and-tea-crazy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/228642/6010874513/iap_640x640.6010874513_td3pa6p9.jpg?version=0)

5 out of 5 stars

- Color:

Pink


I had broken my last purchase so I had to replace it. Love their mugs, great designs.

![](https://i.etsystatic.com/iusa/70b91c/111731537/iusa_75x75.111731537_2qgl.jpg?version=0)

May 2, 2024


[daniela pardo](https://www.etsy.com/people/danielap1)

Purchased item:

[![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug](https://i.etsystatic.com/8161260/r/il/e0dc07/7295077396/il_170x135.7295077396_fzu8.jpg)\\
\\
16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug\\
\\
$53.00](https://www.etsy.com/listing/588348210/16-oz-cat-mug-cats-books-and-tea-crazy?ref=ap-listing)

Purchased item:

[![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug](https://i.etsystatic.com/8161260/r/il/e0dc07/7295077396/il_170x135.7295077396_fzu8.jpg)\\
\\
16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug\\
\\
$53.00](https://www.etsy.com/listing/588348210/16-oz-cat-mug-cats-books-and-tea-crazy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/a3e7c7/5887341363/iap_640x640.5887341363_7pcfe3r3.jpg?version=0)

5 out of 5 stars

- Color:

Chartreuse


Big fan of these mugs! Shipping was good and item wrapped with care. Feels lovely in hand.

![](https://i.etsystatic.com/iusa/9d1ceb/58973119/iusa_75x75.58973119_mnba.jpg?version=0)

Mar 13, 2024


[Dana Mae](https://www.etsy.com/people/u5bv4di8)

Purchased item:

[![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug](https://i.etsystatic.com/8161260/r/il/e0dc07/7295077396/il_170x135.7295077396_fzu8.jpg)\\
\\
16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug\\
\\
$53.00](https://www.etsy.com/listing/588348210/16-oz-cat-mug-cats-books-and-tea-crazy?ref=ap-listing)

Purchased item:

[![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug](https://i.etsystatic.com/8161260/r/il/e0dc07/7295077396/il_170x135.7295077396_fzu8.jpg)\\
\\
16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug\\
\\
$53.00](https://www.etsy.com/listing/588348210/16-oz-cat-mug-cats-books-and-tea-crazy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/3fed86/5476534526/iap_640x640.5476534526_bbymexrs.jpg?version=0)

5 out of 5 stars

- Color:

White


Super cute, I’m ready for this to be my new favorite mug. Love it!

![](https://i.etsystatic.com/iusa/70b91c/111731537/iusa_75x75.111731537_2qgl.jpg?version=0)

Nov 6, 2023


[daniela pardo](https://www.etsy.com/people/danielap1)

Purchased item:

[![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug](https://i.etsystatic.com/8161260/r/il/e0dc07/7295077396/il_170x135.7295077396_fzu8.jpg)\\
\\
16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug\\
\\
$53.00](https://www.etsy.com/listing/588348210/16-oz-cat-mug-cats-books-and-tea-crazy?ref=ap-listing)

Purchased item:

[![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug](https://i.etsystatic.com/8161260/r/il/e0dc07/7295077396/il_170x135.7295077396_fzu8.jpg)\\
\\
16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug\\
\\
$53.00](https://www.etsy.com/listing/588348210/16-oz-cat-mug-cats-books-and-tea-crazy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/72031b/3003810160/iap_640x640.3003810160_ep9pll43.jpg?version=0)

5 out of 5 stars

- Color:

Gray


Love the cat mug, it’s perfect!

Apr 9, 2021


[Danielle Moore](https://www.etsy.com/people/daniekat)

Purchased item:

[![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug](https://i.etsystatic.com/8161260/r/il/e0dc07/7295077396/il_170x135.7295077396_fzu8.jpg)\\
\\
16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug\\
\\
$53.00](https://www.etsy.com/listing/588348210/16-oz-cat-mug-cats-books-and-tea-crazy?ref=ap-listing)

Purchased item:

[![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug](https://i.etsystatic.com/8161260/r/il/e0dc07/7295077396/il_170x135.7295077396_fzu8.jpg)\\
\\
16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug\\
\\
$53.00](https://www.etsy.com/listing/588348210/16-oz-cat-mug-cats-books-and-tea-crazy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/e19c86/2975223605/iap_640x640.2975223605_s0w7t2vw.jpg?version=0)

5 out of 5 stars

- Color:

Copper


Mar 8, 2021


[Kaycee](https://www.etsy.com/people/fdxzsear)

Purchased item:

[![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug](https://i.etsystatic.com/8161260/r/il/e0dc07/7295077396/il_170x135.7295077396_fzu8.jpg)\\
\\
16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug\\
\\
$53.00](https://www.etsy.com/listing/588348210/16-oz-cat-mug-cats-books-and-tea-crazy?ref=ap-listing)

Purchased item:

[![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug](https://i.etsystatic.com/8161260/r/il/e0dc07/7295077396/il_170x135.7295077396_fzu8.jpg)\\
\\
16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug\\
\\
$53.00](https://www.etsy.com/listing/588348210/16-oz-cat-mug-cats-books-and-tea-crazy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/8decda/2907250328/iap_640x640.2907250328_2buuncr9.jpg?version=0)

5 out of 5 stars

- Color:

Bright Blue


I am in love with this mug! One of my favorite shades of blue and this cat is adorable. Makes me wish I was left-handed to I could look at it all the time :) You two are truly skilled!

![](https://i.etsystatic.com/iusa/64e66b/85065469/iusa_75x75.85065469_6elo.jpg?version=0)

Feb 28, 2021


[torena](https://www.etsy.com/people/torena)

Purchased item:

[![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug](https://i.etsystatic.com/8161260/r/il/e0dc07/7295077396/il_170x135.7295077396_fzu8.jpg)\\
\\
16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug\\
\\
$53.00](https://www.etsy.com/listing/588348210/16-oz-cat-mug-cats-books-and-tea-crazy?ref=ap-listing)

Purchased item:

[![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug](https://i.etsystatic.com/8161260/r/il/e0dc07/7295077396/il_170x135.7295077396_fzu8.jpg)\\
\\
16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug\\
\\
$53.00](https://www.etsy.com/listing/588348210/16-oz-cat-mug-cats-books-and-tea-crazy?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/64b592/2629071958/iap_640x640.2629071958_d04w940n.jpg?version=0)

5 out of 5 stars

- Color:

Gray


I love my cat mug. I buy many from this seller and love them all. Looking forward to my next order arriving.

![](https://i.etsystatic.com/iusa/c11772/113995023/iusa_75x75.113995023_9t9c.jpg?version=0)

Nov 1, 2020


[Travis](https://www.etsy.com/people/travisvigue)

Purchased item:

[![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug](https://i.etsystatic.com/8161260/r/il/e0dc07/7295077396/il_170x135.7295077396_fzu8.jpg)\\
\\
16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug\\
\\
$53.00](https://www.etsy.com/listing/588348210/16-oz-cat-mug-cats-books-and-tea-crazy?ref=ap-listing)

Purchased item:

[![16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug](https://i.etsystatic.com/8161260/r/il/e0dc07/7295077396/il_170x135.7295077396_fzu8.jpg)\\
\\
16 oz Cat Mug - Cats Books and Tea Crazy Cat Lady Handmade Stoneware Coffee Mug - Mother of Cats Big Coffee Mug\\
\\
$53.00](https://www.etsy.com/listing/588348210/16-oz-cat-mug-cats-books-and-tea-crazy?ref=ap-listing)