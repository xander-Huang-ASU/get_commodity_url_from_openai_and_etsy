[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1808083071/caffeine-loving-cat-carved-ceramic-mug?amp;click_sum=1e592db7&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;sts=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=1e592db7&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-0)
- [Kitchen & Dining](https://www.etsy.com/c/home-and-living/kitchen-and-dining?amp%3Bclick_sum=1e592db7&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-1)
- [Drink & Barware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware?amp%3Bclick_sum=1e592db7&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-2)
- [Drinkware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware?amp%3Bclick_sum=1e592db7&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-3)
- [Mugs](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/mugs?amp%3Bclick_sum=1e592db7&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-4)


Add to Favorites


- ![May include: A brown ceramic coffee mug with a white square design featuring a cartoon cat holding a coffee mug. The cat is smiling and has a striped pattern.](https://i.etsystatic.com/31890761/r/il/ebd9a9/6371447700/il_794xN.6371447700_e15o.jpg)
- ![May include: A yellow ceramic coffee mug with a white image of a cat holding a cup. The cat is wearing a collar with a bell. The mug has a handle on the left side.](https://i.etsystatic.com/31890761/r/il/81eeb7/6419439657/il_794xN.6419439657_bktr.jpg)
- ![Caffeine Loving Cat Carved Ceramic Mug 14 oz Roasting Beans Blue](https://i.etsystatic.com/31890761/r/il/6bd390/6817987277/il_794xN.6817987277_7032.jpg)
- ![Caffeine Loving Cat Carved Ceramic Mug 14 oz image 4](https://i.etsystatic.com/31890761/r/il/877b6b/6596919994/il_794xN.6596919994_3jy1.jpg)
- ![Caffeine Loving Cat Carved Ceramic Mug 14 oz Roasting Beans Brown](https://i.etsystatic.com/31890761/r/il/740e0c/6691551720/il_794xN.6691551720_9zqa.jpg)
- ![May include: A brown ceramic mug with a white cat illustration holding a cup. The cat is sitting and has a white background. The mug has a brown handle.](https://i.etsystatic.com/31890761/r/il/537ebd/6419439653/il_794xN.6419439653_3289.jpg)
- ![Caffeine Loving Cat Carved Ceramic Mug 14 oz Caffeine Cat Blue](https://i.etsystatic.com/31890761/r/il/ad36ed/6648750201/il_794xN.6648750201_qwoh.jpg)
- ![Caffeine Loving Cat Carved Ceramic Mug 14 oz image 8](https://i.etsystatic.com/31890761/r/il/f35ce2/6645035915/il_794xN.6645035915_ff80.jpg)
- ![Caffeine Loving Cat Carved Ceramic Mug 14 oz image 9](https://i.etsystatic.com/31890761/r/il/07f8a9/6739584699/il_794xN.6739584699_e5fi.jpg)

- ![May include: A brown ceramic coffee mug with a white square design featuring a cartoon cat holding a coffee mug. The cat is smiling and has a striped pattern.](https://i.etsystatic.com/31890761/c/1360/1360/735/26/il/ebd9a9/6371447700/il_75x75.6371447700_e15o.jpg)
- ![May include: A yellow ceramic coffee mug with a white image of a cat holding a cup. The cat is wearing a collar with a bell. The mug has a handle on the left side.](https://i.etsystatic.com/31890761/r/il/81eeb7/6419439657/il_75x75.6419439657_bktr.jpg)
- ![Caffeine Loving Cat Carved Ceramic Mug 14 oz Roasting Beans Blue](https://i.etsystatic.com/31890761/r/il/6bd390/6817987277/il_75x75.6817987277_7032.jpg)
- ![Caffeine Loving Cat Carved Ceramic Mug 14 oz image 4](https://i.etsystatic.com/31890761/r/il/877b6b/6596919994/il_75x75.6596919994_3jy1.jpg)
- ![Caffeine Loving Cat Carved Ceramic Mug 14 oz Roasting Beans Brown](https://i.etsystatic.com/31890761/r/il/740e0c/6691551720/il_75x75.6691551720_9zqa.jpg)
- ![May include: A brown ceramic mug with a white cat illustration holding a cup. The cat is sitting and has a white background. The mug has a brown handle.](https://i.etsystatic.com/31890761/r/il/537ebd/6419439653/il_75x75.6419439653_3289.jpg)
- ![Caffeine Loving Cat Carved Ceramic Mug 14 oz Caffeine Cat Blue](https://i.etsystatic.com/31890761/r/il/ad36ed/6648750201/il_75x75.6648750201_qwoh.jpg)
- ![Caffeine Loving Cat Carved Ceramic Mug 14 oz image 8](https://i.etsystatic.com/31890761/r/il/f35ce2/6645035915/il_75x75.6645035915_ff80.jpg)
- ![Caffeine Loving Cat Carved Ceramic Mug 14 oz image 9](https://i.etsystatic.com/31890761/r/il/07f8a9/6739584699/il_75x75.6739584699_e5fi.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1808083071%2Fcaffeine-loving-cat-carved-ceramic-mug%23report-overlay-trigger)

In 18 carts

Price:$32.99


Loading


# Caffeine Loving Cat Carved Ceramic Mug 14 oz

[MonumentalMisc](https://www.etsy.com/shop/MonumentalMisc?ref=shop-header-name&listing_id=1808083071&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1808083071/caffeine-loving-cat-carved-ceramic-mug?amp;click_sum=1e592db7&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;sts=1#reviews)

Arrives soon! Get it by

Nov 13-15


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Primary color


Select a color

Caffeine Cat Brown

Caffeine Cat Blue

Roasting Beans Brown

Roasting Beans Blue \[Sold out\]

Please select a color


4 payments of **$8.24** at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Item details

### Highlights

Made by [MonumentalMisc](https://www.etsy.com/shop/MonumentalMisc)

- Materials: Ceramic, porcelain


This listing is for one 14 ounce mug with the Caffeinated Cat design, or the "Roasting the beans" design carved into either a matte brown or glossy blue glaze. Being a big cat fan myself, I wanted to create something with a similar energy to the Matsumoto Hoji Unimpressed Frog. If you are a fan of that artwork, check out my other listings.

The high-quality carved ceramic ensures durability, and feel that can't be achieved with printed designs.

Mugs are fully vitrified and glazed commercial mugs. This is a different brand than my other mugs. Handmade in Japan with a smaller capacity, geared toward the slow coffee style. They offer great quality, which gives repeatable results for carving.

Orders of two or more mugs get free USPS Ground Advantage Shipping 🎉 You can mix an match between any of my listings, as long as they are in the same order.

Mugs are microwave, dishwasher safe, and lead free.

If you are a big frog fan, and haven't seen my other listing, follow this link ↓↓↓

[https://monumentalmisc.etsy.com/listing/1685358667/unimpressed-frog-ceramic-mug-16oz](https://monumentalmisc.etsy.com/listing/1685358667/unimpressed-frog-ceramic-mug-15oz)

If you happen to to be in need of a cast iron pan with a map engraved into it, perfect for sixth anniversaries, weddings, or celebrating your friend's new home... Take a look at my other listing...

[https://monumentalmisc.etsy.com/listing/1512701256/cast-iron-pan-with-personalized-map](https://monumentalmisc.etsy.com/listing/1512701256/cast-iron-pan-with-personalized-map)

## Shipping and return policies

Loading


- Order today to get by

**Nov 13-15**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges not accepted




But please contact me if you have problems with your order


- Ships from: **Old Bridge, NJ**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## Reviews for this item (24)

4.8/5

item average

4.8Item quality

5.0Shipping

5.0Customer service

95%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Love it

Fast shipping

Well packaged

Looks great

Cute

As described

Excellent communication


Filter by category


Quality (9)


Appearance (8)


Shipping & Packaging (8)


Seller service (4)


Description accuracy (3)


Sizing & Fit (2)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/befe9c/84185617/iusa_75x75.84185617_6cod.jpg?version=0)

[Samuel Wynn](https://www.etsy.com/people/samwynn53?ref=l_review)
Nov 5, 2025


exactly as described, delivered very very quickly. thank you!



![](https://i.etsystatic.com/iusa/befe9c/84185617/iusa_75x75.84185617_6cod.jpg?version=0)

[Samuel Wynn](https://www.etsy.com/people/samwynn53?ref=l_review)
Nov 5, 2025


![](https://i.etsystatic.com/iusa/bfb250/99618305/iusa_75x75.99618305_a74y.jpg?version=0)

Response from Craig

Thanks for the order and reviews on both mugs!!!



5 out of 5 stars
5

This item

[Kathy](https://www.etsy.com/people/ssq4oglsb9bohwps?ref=l_review)
Nov 3, 2025


I sent this to a wonderful neighbor who found my run away cat Willie. Always put a name tag collar on every cat you love. That's how she found me. Cat on mug resembles Willie. Really nice workmanship. Thanks so much!



[Kathy](https://www.etsy.com/people/ssq4oglsb9bohwps?ref=l_review)
Nov 3, 2025


![](https://i.etsystatic.com/iusa/bfb250/99618305/iusa_75x75.99618305_a74y.jpg?version=0)

Response from Craig

Thank you so much for the order and great review, I'm so happy you and Willie got reunited!!!!!!!!!!!!!!!!!!!! :)



5 out of 5 stars
5

This item

[Kelly](https://www.etsy.com/people/7p6l1ulpxotkd08i?ref=l_review)
Sep 15, 2025


Super cute addition to the kitchen!



[Kelly](https://www.etsy.com/people/7p6l1ulpxotkd08i?ref=l_review)
Sep 15, 2025


![](https://i.etsystatic.com/iusa/bfb250/99618305/iusa_75x75.99618305_a74y.jpg?version=0)

Response from Craig

Thanks for another great review! :) :)



5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/95f28e/36870307/iusa_75x75.36870307_ib4g.jpg?version=0)

[Holly S.](https://www.etsy.com/people/hollysorensen2?ref=l_review)
Sep 12, 2025


Smaller than I thought it would be but such cute mugs! These have become our favorite mugs to grab for coffee.



![](https://i.etsystatic.com/iusa/95f28e/36870307/iusa_75x75.36870307_ib4g.jpg?version=0)

[Holly S.](https://www.etsy.com/people/hollysorensen2?ref=l_review)
Sep 12, 2025


![](https://i.etsystatic.com/iusa/bfb250/99618305/iusa_75x75.99618305_a74y.jpg?version=0)

Response from Craig

Thanks! Hmm, I'll have to move the photos with the dimensions earlier in the gallery if that might help people. Thanks again!



View all reviews for this item

### Photos from reviews

![Tna added a photo of their purchase](https://i.etsystatic.com/iap/72db25/7212350489/iap_300x300.7212350489_murpthm3.jpg?version=0)

![Andrew added a photo of their purchase](https://i.etsystatic.com/iap/56ee54/6774326613/iap_300x300.6774326613_hcnq5kyg.jpg?version=0)

![Rebecca added a photo of their purchase](https://i.etsystatic.com/iap/59896c/6507963169/iap_300x300.6507963169_5mpwtddu.jpg?version=0)

[![MonumentalMisc](https://i.etsystatic.com/iusa/bfb250/99618305/iusa_75x75.99618305_a74y.jpg?version=0)](https://www.etsy.com/shop/MonumentalMisc?ref=shop_profile&listing_id=1808083071)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[MonumentalMisc](https://www.etsy.com/shop/MonumentalMisc?ref=shop_profile&listing_id=1808083071)

[Owned by Craig](https://www.etsy.com/shop/MonumentalMisc?ref=shop_profile&listing_id=1808083071) \|

United States

5.0
(576)


2.4k sales

4 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=528277571&referring_id=1808083071&referring_type=listing&recipient_id=528277571&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo1MjgyNzc1NzE6MTc2MjgwNzQ5MTowNjJhYmFmN2Y2ZDQyNzYyZWI2NGM5NTIzNTk3MDRjZA%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1808083071%2Fcaffeine-loving-cat-carved-ceramic-mug%3Famp%253Bclick_sum%3D1e592db7%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bsts%3D1)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/MonumentalMisc?ref=lp_mys_mfts)

- [![Carved Ceramic with Opossum or Raccoon Theme Mug 15 oz](https://i.etsystatic.com/31890761/r/il/bf8bdc/6805611718/il_340x270.6805611718_a30n.jpg)\\
\\
**Carved Ceramic with Opossum or Raccoon Theme Mug 15 oz**\\
\\
$34.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1905897421/carved-ceramic-with-opossum-or-raccoon?click_key=1e817c684202a8274acb639c95b7c771%3ALTb0e012dad696c348e66ff16c430f45c2da7e7699&click_sum=d8361c83&ls=r&ref=related-1&sts=1&content_source=1e817c684202a8274acb639c95b7c771%253ALTb0e012dad696c348e66ff16c430f45c2da7e7699 "Carved Ceramic with Opossum or Raccoon Theme Mug 15 oz")




Add to Favorites


- [![Unimpressed Frog Ceramic Mug 15oz Matsumoto Hoji](https://i.etsystatic.com/31890761/c/1999/1999/428/0/il/aa2ec6/6373854029/il_340x270.6373854029_ma2j.jpg)\\
\\
**Unimpressed Frog Ceramic Mug 15oz Matsumoto Hoji**\\
\\
$30.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1685358667/unimpressed-frog-ceramic-mug-15oz?click_key=1e817c684202a8274acb639c95b7c771%3ALT14ea5fe2753a41c56f9ed0bd6fc90cac5e0da220&click_sum=57d9ea85&ls=r&ref=related-2&sts=1&content_source=1e817c684202a8274acb639c95b7c771%253ALT14ea5fe2753a41c56f9ed0bd6fc90cac5e0da220 "Unimpressed Frog Ceramic Mug 15oz Matsumoto Hoji")




Add to Favorites


- [![Ito Jakuchu Frog Carved Ceramic Mug 15oz](https://i.etsystatic.com/31890761/c/1742/1742/537/488/il/133eeb/6972839573/il_340x270.6972839573_eqdp.jpg)\\
\\
**Ito Jakuchu Frog Carved Ceramic Mug 15oz**\\
\\
$34.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4317617705/ito-jakuchu-frog-carved-ceramic-mug-15oz?click_key=1e817c684202a8274acb639c95b7c771%3ALTa521c74f374b3caa535774c46812c2567425a1e4&click_sum=98067eee&ls=r&ref=related-3&sts=1&content_source=1e817c684202a8274acb639c95b7c771%253ALTa521c74f374b3caa535774c46812c2567425a1e4 "Ito Jakuchu Frog Carved Ceramic Mug 15oz")




Add to Favorites


- [![Coquí Mug, Carved Petroglyph in Ceramic](https://i.etsystatic.com/31890761/r/il/e27607/6724995379/il_340x270.6724995379_l1vt.jpg)\\
\\
**Coquí Mug, Carved Petroglyph in Ceramic**\\
\\
$30.99\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1755920092/coqui-mug-carved-petroglyph-in-ceramic?click_key=2d2eed62aeb6e751021cc0774a511e3641dcb840%3A1755920092&click_sum=558b86cb&ref=related-4&sts=1 "Coquí Mug, Carved Petroglyph in Ceramic")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 9, 2025


[553 favorites](https://www.etsy.com/listing/1808083071/caffeine-loving-cat-carved-ceramic-mug/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=1e592db7&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Kitchen & Dining](https://www.etsy.com/c/home-and-living/kitchen-and-dining?amp%3Bclick_sum=1e592db7&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Drink & Barware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware?amp%3Bclick_sum=1e592db7&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Drinkware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware?amp%3Bclick_sum=1e592db7&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Mugs](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/mugs?amp%3Bclick_sum=1e592db7&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-1&%3Bsts=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Kitchen & Dining

[Xl Wood Tray - US](https://www.etsy.com/market/xl_wood_tray) [Crochet trivets avocado green by HausModern](https://www.etsy.com/listing/1347192377/crochet-trivets-avocado-green-hot-pad) [Loft 'King Of Cheese' Wooden Cheese Knife Block - Kitchen & Dining](https://www.etsy.com/listing/1530757358/loft-king-of-cheese-wooden-cheese-knife) [MicaceousDreams](https://www.etsy.com/shop/MicaceousDreams) [VTG Little Rs Rubby Salt n Pepper AVON - Kitchen & Dining](https://www.etsy.com/listing/1095859332/vtg-little-rs-rubby-salt-n-pepper-avon) [Shop Military Car Magnets](https://www.etsy.com/market/military_car_magnets) [Cornish Therm O Ware for Sale](https://www.etsy.com/market/cornish_therm_o_ware) [Camping flour sack dish towel - Kitchen & Dining](https://www.etsy.com/listing/1125632867/camping-flour-sack-dish-towel) [Buy Bourbon Trail Passport Online](https://www.etsy.com/market/bourbon_trail_passport) [Buy Cozumel Spoon Online](https://www.etsy.com/market/cozumel_spoon) [Cricket Mug for Sale](https://www.etsy.com/market/cricket_mug)

Shopping

[6 Little Penguins for Sale](https://www.etsy.com/market/6_little_penguins)

Paper

[Buy Government Stickers Online](https://www.etsy.com/market/government_stickers) [Buy Hallmark Sympathy Cards Online](https://www.etsy.com/market/hallmark_sympathy_cards)

Furniture

[Bachelor Chest Pair - US](https://www.etsy.com/market/bachelor_chest_pair)

Video Games

[Shop Asus Rog Ally Mount](https://www.etsy.com/market/asus_rog_ally_mount)

Collectibles

[1950s Head Vase for Sale](https://www.etsy.com/market/1950s_head_vase)

Prints

[Shop Oklahoma Oilfield Art](https://www.etsy.com/market/oklahoma_oilfield_art)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1808083071%2Fcaffeine-loving-cat-carved-ceramic-mug%3Famp%253Bclick_sum%3D1e592db7%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bsts%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgwNzQ5MTo0YTYyNTY5NTk4NzBmZjg5MmNiNzRiNWExZTRhNWE1Mg==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1808083071%2Fcaffeine-loving-cat-carved-ceramic-mug%3Famp%253Bclick_sum%3D1e592db7%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bsts%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1808083071/caffeine-loving-cat-carved-ceramic-mug?amp;click_sum=1e592db7&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-1&amp;sts=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1808083071%2Fcaffeine-loving-cat-carved-ceramic-mug%3Famp%253Bclick_sum%3D1e592db7%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-1%26amp%253Bsts%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for MonumentalMisc

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: before item has shipped

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Item in the photo is in **Primary color: Caffeine Cat Brown**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Primary color: Roasting Beans Blue**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Primary color: Roasting Beans Brown**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Primary color: Caffeine Cat Blue**




Select this option








Option selected!













This option is sold out.



Click to zoom

- ![May include: A brown ceramic coffee mug with a white square design featuring a cartoon cat holding a coffee mug. The cat is smiling and has a striped pattern.](https://i.etsystatic.com/31890761/c/1360/1360/735/26/il/ebd9a9/6371447700/il_300x300.6371447700_e15o.jpg)
- ![May include: A yellow ceramic coffee mug with a white image of a cat holding a cup. The cat is wearing a collar with a bell. The mug has a handle on the left side.](https://i.etsystatic.com/31890761/r/il/81eeb7/6419439657/il_300x300.6419439657_bktr.jpg)
- ![Caffeine Loving Cat Carved Ceramic Mug 14 oz Roasting Beans Blue](https://i.etsystatic.com/31890761/r/il/6bd390/6817987277/il_300x300.6817987277_7032.jpg)
- ![Caffeine Loving Cat Carved Ceramic Mug 14 oz image 4](https://i.etsystatic.com/31890761/r/il/877b6b/6596919994/il_300x300.6596919994_3jy1.jpg)
- ![Caffeine Loving Cat Carved Ceramic Mug 14 oz Roasting Beans Brown](https://i.etsystatic.com/31890761/r/il/740e0c/6691551720/il_300x300.6691551720_9zqa.jpg)
- ![May include: A brown ceramic mug with a white cat illustration holding a cup. The cat is sitting and has a white background. The mug has a brown handle.](https://i.etsystatic.com/31890761/r/il/537ebd/6419439653/il_300x300.6419439653_3289.jpg)
- ![Caffeine Loving Cat Carved Ceramic Mug 14 oz Caffeine Cat Blue](https://i.etsystatic.com/31890761/r/il/ad36ed/6648750201/il_300x300.6648750201_qwoh.jpg)
- ![Caffeine Loving Cat Carved Ceramic Mug 14 oz image 8](https://i.etsystatic.com/31890761/r/il/f35ce2/6645035915/il_300x300.6645035915_ff80.jpg)
- ![Caffeine Loving Cat Carved Ceramic Mug 14 oz image 9](https://i.etsystatic.com/31890761/r/il/07f8a9/6739584699/il_300x300.6739584699_e5fi.jpg)

- ![](https://i.etsystatic.com/iap/72db25/7212350489/iap_640x640.7212350489_murpthm3.jpg?version=0)

5 out of 5 stars

- Color:

Caffeine Cat Blue


I loved these so much I ordered 2 more. The cat design on the blue cups is nice to look at. The cups are also sturdy.

Sep 2, 2025


[Tna Bz](https://www.etsy.com/people/rjg557o7tvvlydsz)

Purchased item:

[![Caffeine Loving Cat Carved Ceramic Mug 14 oz](https://i.etsystatic.com/31890761/c/1360/1360/735/26/il/ebd9a9/6371447700/il_170x135.6371447700_e15o.jpg)\\
\\
Caffeine Loving Cat Carved Ceramic Mug 14 oz\\
\\
$32.99](https://www.etsy.com/listing/1808083071/caffeine-loving-cat-carved-ceramic-mug?ref=ap-listing)

Purchased item:

[![Caffeine Loving Cat Carved Ceramic Mug 14 oz](https://i.etsystatic.com/31890761/c/1360/1360/735/26/il/ebd9a9/6371447700/il_170x135.6371447700_e15o.jpg)\\
\\
Caffeine Loving Cat Carved Ceramic Mug 14 oz\\
\\
$32.99](https://www.etsy.com/listing/1808083071/caffeine-loving-cat-carved-ceramic-mug?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/56ee54/6774326613/iap_640x640.6774326613_hcnq5kyg.jpg?version=0)

5 out of 5 stars

- Color:

Caffeine Cat Blue


I ordered this along with the green frog mug, both look great

Mar 18, 2025


[Andrew](https://www.etsy.com/people/lxwmjold)

Purchased item:

[![Caffeine Loving Cat Carved Ceramic Mug 14 oz](https://i.etsystatic.com/31890761/c/1360/1360/735/26/il/ebd9a9/6371447700/il_170x135.6371447700_e15o.jpg)\\
\\
Caffeine Loving Cat Carved Ceramic Mug 14 oz\\
\\
$32.99](https://www.etsy.com/listing/1808083071/caffeine-loving-cat-carved-ceramic-mug?ref=ap-listing)

Purchased item:

[![Caffeine Loving Cat Carved Ceramic Mug 14 oz](https://i.etsystatic.com/31890761/c/1360/1360/735/26/il/ebd9a9/6371447700/il_170x135.6371447700_e15o.jpg)\\
\\
Caffeine Loving Cat Carved Ceramic Mug 14 oz\\
\\
$32.99](https://www.etsy.com/listing/1808083071/caffeine-loving-cat-carved-ceramic-mug?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/59896c/6507963169/iap_640x640.6507963169_5mpwtddu.jpg?version=0)

5 out of 5 stars

Fast shipping. Seller answered questions quickly and helped me correct mailing address. Mug is SO cute and creative. I love it.

Nov 25, 2024


[Rebecca](https://www.etsy.com/people/fkwoopjs)

Purchased item:

[![Caffeine Loving Cat Carved Ceramic Mug 14 oz](https://i.etsystatic.com/31890761/c/1360/1360/735/26/il/ebd9a9/6371447700/il_170x135.6371447700_e15o.jpg)\\
\\
Caffeine Loving Cat Carved Ceramic Mug 14 oz\\
\\
$32.99](https://www.etsy.com/listing/1808083071/caffeine-loving-cat-carved-ceramic-mug?ref=ap-listing)

Purchased item:

[![Caffeine Loving Cat Carved Ceramic Mug 14 oz](https://i.etsystatic.com/31890761/c/1360/1360/735/26/il/ebd9a9/6371447700/il_170x135.6371447700_e15o.jpg)\\
\\
Caffeine Loving Cat Carved Ceramic Mug 14 oz\\
\\
$32.99](https://www.etsy.com/listing/1808083071/caffeine-loving-cat-carved-ceramic-mug?ref=ap-listing)