[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1645159017/blue-pink-crochet-shoulder-bag-handmade?amp;click_sum=6947c34f&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;pro=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Bags & Purses](https://www.etsy.com/c/bags-and-purses?amp%3Bclick_sum=6947c34f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bpro=1&explicit=1&ref=catnav_breadcrumb-0)
- [Handbags](https://www.etsy.com/c/bags-and-purses/handbags?amp%3Bclick_sum=6947c34f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bpro=1&explicit=1&ref=catnav_breadcrumb-1)
- [Shoulder Bags](https://www.etsy.com/c/bags-and-purses/handbags/shoulder-bags?amp%3Bclick_sum=6947c34f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bpro=1&explicit=1&ref=catnav_breadcrumb-2)


Add to Favorites


- ![May include: A blue and pink crocheted bag with a gold chain strap. The strap has pink accents.](https://i.etsystatic.com/43031656/r/il/442245/5623800028/il_794xN.5623800028_8v55.jpg)
- Loading



















Hm, we’re having trouble loading this video.





Try to refresh the page or come back later.


- ![May include: A blue and pink crocheted handbag with a gold chain strap.](https://i.etsystatic.com/43031656/r/il/b05190/5671873259/il_794xN.5671873259_axlo.jpg)
- ![May include: A blue and pink crocheted handbag with a gold chain strap. The bag has a striped design with a pink stripe in the center.](https://i.etsystatic.com/43031656/r/il/0d6535/5623800030/il_794xN.5623800030_ln17.jpg)
- ![May include: A blue and pink crocheted handbag with a gold chain strap. The bag has a striped design with alternating blue and pink sections.](https://i.etsystatic.com/43031656/r/il/ea7af3/5623800022/il_794xN.5623800022_fmol.jpg)
- ![May include: A crocheted handbag with a pink and blue striped design. The bag has a gold chain strap with pink accents.](https://i.etsystatic.com/43031656/r/il/040f8e/5671873277/il_794xN.5671873277_b67p.jpg)
- ![May include: A blue and pink crocheted handbag with a gold chain strap. The bag has a pink stripe in the center and is made of thick yarn.](https://i.etsystatic.com/43031656/r/il/1eb95b/5623800026/il_794xN.5623800026_e4e5.jpg)
- ![May include: A blue and pink crocheted handbag with a gold chain strap. The bag has a pink lining and a gold clasp.](https://i.etsystatic.com/43031656/r/il/5d2f17/5623800068/il_794xN.5623800068_btkz.jpg)
- ![May include: A crocheted handbag with a pink and blue striped design. The bag has a gold chain strap.](https://i.etsystatic.com/43031656/r/il/95b6fb/5671873301/il_794xN.5671873301_n9lo.jpg)
- ![May include: A crocheted handbag with a blue and pink striped design and a gold chain strap.](https://i.etsystatic.com/43031656/r/il/22b7f6/5671873305/il_794xN.5671873305_jc86.jpg)

- ![May include: A blue and pink crocheted bag with a gold chain strap. The strap has pink accents.](https://i.etsystatic.com/43031656/r/il/442245/5623800028/il_75x75.5623800028_8v55.jpg)
- ![Product video](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/IMG_7801_yyo6zo.jpg)

- ![May include: A blue and pink crocheted handbag with a gold chain strap.](https://i.etsystatic.com/43031656/r/il/b05190/5671873259/il_75x75.5671873259_axlo.jpg)
- ![May include: A blue and pink crocheted handbag with a gold chain strap. The bag has a striped design with a pink stripe in the center.](https://i.etsystatic.com/43031656/r/il/0d6535/5623800030/il_75x75.5623800030_ln17.jpg)
- ![May include: A blue and pink crocheted handbag with a gold chain strap. The bag has a striped design with alternating blue and pink sections.](https://i.etsystatic.com/43031656/r/il/ea7af3/5623800022/il_75x75.5623800022_fmol.jpg)
- ![May include: A crocheted handbag with a pink and blue striped design. The bag has a gold chain strap with pink accents.](https://i.etsystatic.com/43031656/r/il/040f8e/5671873277/il_75x75.5671873277_b67p.jpg)
- ![May include: A blue and pink crocheted handbag with a gold chain strap. The bag has a pink stripe in the center and is made of thick yarn.](https://i.etsystatic.com/43031656/r/il/1eb95b/5623800026/il_75x75.5623800026_e4e5.jpg)
- ![May include: A blue and pink crocheted handbag with a gold chain strap. The bag has a pink lining and a gold clasp.](https://i.etsystatic.com/43031656/r/il/5d2f17/5623800068/il_75x75.5623800068_btkz.jpg)
- ![May include: A crocheted handbag with a pink and blue striped design. The bag has a gold chain strap.](https://i.etsystatic.com/43031656/r/il/95b6fb/5671873301/il_75x75.5671873301_n9lo.jpg)
- ![May include: A crocheted handbag with a blue and pink striped design and a gold chain strap.](https://i.etsystatic.com/43031656/r/il/22b7f6/5671873305/il_75x75.5671873305_jc86.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1645159017%2Fblue-pink-crochet-shoulder-bag-handmade%23report-overlay-trigger)

9 views in the last 24 hours

NowPrice:$44.85


Original Price:
$69.00


Loading


35% off


•

Sale ends on November 20


# Blue & Pink Crochet Shoulder Bag – Handmade Evening Purse

[ZNBoutiqueDesign](https://www.etsy.com/shop/ZNBoutiqueDesign?ref=shop-header-name&listing_id=1645159017&from_page=listing)

[5 out of 5 stars](https://www.etsy.com/listing/1645159017/blue-pink-crochet-shoulder-bag-handmade?amp;click_sum=6947c34f&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;pro=1#reviews)

Arrives soon! Get it by

Nov 13-17


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Made by [ZNBoutiqueDesign](https://www.etsy.com/shop/ZNBoutiqueDesign)

- Materials: Tshirt yarn, Fabric, Chain, Handle, Magnet



Ready for shipping!!

Material: tshirt yarn, gold chain, acrylic handle,cotton fabric, magnet!

Handmade crochet shoulder bag!!

It’s lined!!

Dimensions:10 inch (25 cm)x 7 inch (18cm)

Handle:16 inch (41cm)

Gold chain :40 inch (101cm)

Removable Chain and handle!!

Do not machine wash!

Do not bleach!!

Spot clean with gentle soap!


## Shipping and return policies

Loading


- Order today to get by

**Nov 13-17**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges not accepted




But please contact me if you have problems with your order


- Free shipping


- Ships from: **Pittsburgh, PA**


Deliver to United States

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------AustraliaCanadaFranceGermanyGreeceIndiaIrelandItalyJapanNew ZealandPolandPortugalSpainThe NetherlandsUnited KingdomUnited States\-\-\--------AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelgiumBelizeBeninBermudaBhutanBoliviaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo, Republic ofCook IslandsCosta RicaCroatiaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland Islands (Malvinas)Faroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHoly See (Vatican City State)HondurasHong KongHungaryIcelandIndiaIndonesiaIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKosovoKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesia, Federated States ofMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmar (Burma)NamibiaNauruNepalNetherlands AntillesNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorthern Mariana IslandsNorwayOmanPakistanPalauPalestinian Territory, OccupiedPanamaPapua New GuineaParaguayPeruPhilippinesPolandPortugalPuerto RicoQatarReunionRomaniaRwandaSaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSao Tome and PrincipeSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSint Maarten (Dutch part)SlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia and the South Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandTaiwanTajikistanTanzaniaThailandThe NetherlandsTimor-LesteTogoTokelauTongaTrinidadTunisiaTürkiyeTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited KingdomUnited StatesUnited States Minor Outlying IslandsUruguayU.S. Virgin IslandsUzbekistanVanuatuVenezuelaVietnamWallis and FutunaWestern SaharaYemenZaire (Democratic Republic of Congo)ZambiaZimbabwe

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

## Be the first to review this item

This is a unique item, and there are no reviews yet. See what customers say about other items from this shop.


Read reviews for other items


[![ZNBoutiqueDesign](https://i.etsystatic.com/iusa/78f770/103337085/iusa_75x75.103337085_9skr.jpg?version=0)](https://www.etsy.com/shop/ZNBoutiqueDesign?ref=shop_profile&listing_id=1645159017)

[ZNBoutiqueDesign](https://www.etsy.com/shop/ZNBoutiqueDesign?ref=shop_profile&listing_id=1645159017)

[Owned by ZN](https://www.etsy.com/shop/ZNBoutiqueDesign?ref=shop_profile&listing_id=1645159017) \|

United States

5.0
(7)


13 sales

2.5 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=782194515&referring_id=1645159017&referring_type=listing&recipient_id=782194515&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo3ODIxOTQ1MTU6MTc2MjgyMjM1NTpmNGVlNDk4NmJlMjlkODFmMzM3N2JmZDczZjY2YTdhMw%3D%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1645159017%2Fblue-pink-crochet-shoulder-bag-handmade%3Famp%253Bclick_sum%3D6947c34f%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bpro%3D1)

This seller usually responds **within a few hours.**

## All reviews from this shop (7)

Show all

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Loading

Why are these reviews shown?

All reviews are from verified buyers. Reviews are shown automatically based on factors like recency, whether they include comments, your chosen language, and whether the rating reflects the typical experience with the shop.

## More from this shop

[Visit shop](https://www.etsy.com/shop/ZNBoutiqueDesign?ref=lp_mys_mfts)

- [![Handmade  Crochet Shoulder Bag with Leather Handle/Latte  Purse / women bag / Gift for her](https://i.etsystatic.com/43031656/r/il/0caa4c/6658706824/il_340x270.6658706824_ddxt.jpg)\\
\\
**Handmade Crochet Shoulder Bag with Leather Handle/Latte Purse / women bag / Gift for her**\\
\\
Sale Price $75.00\\
$75.00\\
\\
$150.00\\
Original Price $150.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1862860840/handmade-crochet-shoulder-bag-with?click_key=c5629fcf233593ad1e70a8f2d966b9e9%3ALTc16cbadd1361808e77e45bf5ab51b927fad3a645&click_sum=116a50ce&ls=r&ref=related-1&pro=1&content_source=c5629fcf233593ad1e70a8f2d966b9e9%253ALTc16cbadd1361808e77e45bf5ab51b927fad3a645 "Handmade  Crochet Shoulder Bag with Leather Handle/Latte  Purse / women bag / Gift for her")




Add to Favorites


- [![Handmade Crochet Rose Bag, Brown & Latte Knitted Purse/ Macrame yarn/ Women Bag](https://i.etsystatic.com/43031656/r/il/204aca/6694124019/il_340x270.6694124019_2yzc.jpg)\\
\\
**Handmade Crochet Rose Bag, Brown & Latte Knitted Purse/ Macrame yarn/ Women Bag**\\
\\
Sale Price $49.50\\
$49.50\\
\\
$99.00\\
Original Price $99.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1874636387/handmade-crochet-rose-bag-brown-latte?click_key=c5629fcf233593ad1e70a8f2d966b9e9%3ALT8c84cb34b559da72810b7a120fcfa33075cae0c2&click_sum=1a7483c4&ls=r&ref=related-2&pro=1&content_source=c5629fcf233593ad1e70a8f2d966b9e9%253ALT8c84cb34b559da72810b7a120fcfa33075cae0c2 "Handmade Crochet Rose Bag, Brown & Latte Knitted Purse/ Macrame yarn/ Women Bag")




Add to Favorites


- [![Handmade Black Crochet Ruffle Bag, Leather Bottom, Chain Strap/ Purse/ Shoulder Bag](https://i.etsystatic.com/43031656/r/il/a75c34/6707151873/il_340x270.6707151873_46w1.jpg)\\
\\
**Handmade Black Crochet Ruffle Bag, Leather Bottom, Chain Strap/ Purse/ Shoulder Bag**\\
\\
Sale Price $75.00\\
$75.00\\
\\
$150.00\\
Original Price $150.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1874898375/handmade-black-crochet-ruffle-bag?click_key=c5629fcf233593ad1e70a8f2d966b9e9%3ALTfd5bfd24173e4ec0689ee277799f685c80d0f2c5&click_sum=443f2705&ls=r&ref=related-3&pro=1&content_source=c5629fcf233593ad1e70a8f2d966b9e9%253ALTfd5bfd24173e4ec0689ee277799f685c80d0f2c5 "Handmade Black Crochet Ruffle Bag, Leather Bottom, Chain Strap/ Purse/ Shoulder Bag")




Add to Favorites


- [![Gift set for teen and women /Motivational Water bottle gift set/purple water bottle/pink water bottle](https://i.etsystatic.com/43031656/r/il/095246/6466988595/il_340x270.6466988595_rl1i.jpg)\\
\\
**Gift set for teen and women /Motivational Water bottle gift set/purple water bottle/pink water bottle**\\
\\
Sale Price $52.00\\
$52.00\\
\\
$65.00\\
Original Price $65.00\\
\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1801036366/gift-set-for-teen-and-women-motivational?click_key=c23feaf37b446fc8bf4a6b79b52c51e4fbd6637c%3A1801036366&click_sum=efb495da&ref=related-4&pro=1 "Gift set for teen and women /Motivational Water bottle gift set/purple water bottle/pink water bottle")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Sep 2, 2025


[6 favorites](https://www.etsy.com/listing/1645159017/blue-pink-crochet-shoulder-bag-handmade/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?amp%3Bclick_sum=6947c34f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bpro=1&explicit=1&ref=breadcrumb_listing) [Handbags](https://www.etsy.com/c/bags-and-purses/handbags?amp%3Bclick_sum=6947c34f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bpro=1&explicit=1&ref=breadcrumb_listing) [Shoulder Bags](https://www.etsy.com/c/bags-and-purses/handbags/shoulder-bags?amp%3Bclick_sum=6947c34f&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-2&%3Bpro=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Gender Neutral Adult Clothing

[Let's Keep the Dumbfuckery to a Minimum Today Shirt - Gender-Neutral Adult Clothing](https://www.etsy.com/listing/1622075356/lets-keep-the-dumbfuckery-to-a-minimum) [Royal Typewriter Tshirt by InkHavenApparel](https://www.etsy.com/listing/1708187596/royal-typewriter-tshirt-typewriter-shirt)

Watches

[Shop Pocket Watch Crest](https://www.etsy.com/market/pocket_watch_crest)

Books

[Shop Catalog Request](https://www.etsy.com/market/catalog_request)

Wallets & Money Clips

[Buy Coach Leather Credit Card Wallet Online](https://www.etsy.com/market/coach_leather_credit_card_wallet)

Home Decor

[Red Victorian Bold Floral Removable Wallpaper For Kitchen](https://www.etsy.com/listing/877054941/birds-and-flower-wallpaper-red-victorian)

Mens Clothing

[Vintage 1970's Thin Blue "Happy Hollow Farm Wisconsin" Button Down Work Shirt / S to M by CordialQuailVintage](https://www.etsy.com/listing/4351060008/vintage-1970s-thin-blue-happy-hollow)

Beads Gems & Cabochons

[Buy Ice Skating Gifts Bulk Online](https://www.etsy.com/market/ice_skating_gifts_bulk)

Floral Arranging Supplies

[Stevie 1950's German Silk Hibiscus Millinery Flower- Spring by Petershams](https://www.etsy.com/listing/1615842816/stevie-1950s-german-silk-hibiscus)

Collectibles

[Two Antique Green Blob Top Beverage Bottles](https://www.etsy.com/listing/1755170451/two-antique-green-blob-top-beverage) [Buy Ny Fox Police Lock Online](https://www.etsy.com/market/ny_fox_police_lock)

Cleaning Supplies

[ChelseaBPorterMakes](https://www.etsy.com/shop/ChelseaBPorterMakes)

Car Parts & Accessories

[Bumper Car Ornament for Sale](https://www.etsy.com/market/bumper_car_ornament)

Blanks

[Shop Sublimation Magnetic Car Sign Blanks](https://www.etsy.com/market/sublimation_magnetic_car_sign_blanks)

Stamps & Seals

[Encouragement Rubber Stamp Set with Phrases Like Good Job Way to Go and Icons Great for Teachers Cards Scrapbooks Kids Crafts - Stamps & Seals](https://www.etsy.com/listing/4338249465/encouragement-rubber-stamp-set-with)

Kitchen & Dining

[Thermo Serv Southwest Conference Mug Vintage NCAA College Football by PlethoraOfJunk](https://www.etsy.com/listing/4345790502/thermo-serv-southwest-conference-mug)

Shopping

[Knitted Baby Bonnets For Sale for Sale](https://www.etsy.com/market/knitted_baby_bonnets_for_sale)

Handbags

[Buy 1960s Green Handbag Online](https://www.etsy.com/market/1960s_green_handbag)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1645159017%2Fblue-pink-crochet-shoulder-bag-handmade%3Famp%253Bclick_sum%3D6947c34f%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bpro%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgyMjM1NTphZDYzNGZmMzg5OWUyMjA1ZTYwNDM3ODY2NGE4NzE0YQ==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1645159017%2Fblue-pink-crochet-shoulder-bag-handmade%3Famp%253Bclick_sum%3D6947c34f%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bpro%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1645159017/blue-pink-crochet-shoulder-bag-handmade?amp;click_sum=6947c34f&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-2&amp;pro=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1645159017%2Fblue-pink-crochet-shoulder-bag-handmade%3Famp%253Bclick_sum%3D6947c34f%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-2%26amp%253Bpro%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Loading



Click to zoom

- ![May include: A blue and pink crocheted bag with a gold chain strap. The strap has pink accents.](https://i.etsystatic.com/43031656/r/il/442245/5623800028/il_300x300.5623800028_8v55.jpg)
- ![listing-video-1](https://v.etsystatic.com/video/upload/ar_1:1,c_fill,h_105,q_auto,w_105/IMG_7801_yyo6zo.jpg)

- ![May include: A blue and pink crocheted handbag with a gold chain strap.](https://i.etsystatic.com/43031656/r/il/b05190/5671873259/il_300x300.5671873259_axlo.jpg)
- ![May include: A blue and pink crocheted handbag with a gold chain strap. The bag has a striped design with a pink stripe in the center.](https://i.etsystatic.com/43031656/r/il/0d6535/5623800030/il_300x300.5623800030_ln17.jpg)
- ![May include: A blue and pink crocheted handbag with a gold chain strap. The bag has a striped design with alternating blue and pink sections.](https://i.etsystatic.com/43031656/r/il/ea7af3/5623800022/il_300x300.5623800022_fmol.jpg)
- ![May include: A crocheted handbag with a pink and blue striped design. The bag has a gold chain strap with pink accents.](https://i.etsystatic.com/43031656/r/il/040f8e/5671873277/il_300x300.5671873277_b67p.jpg)
- ![May include: A blue and pink crocheted handbag with a gold chain strap. The bag has a pink stripe in the center and is made of thick yarn.](https://i.etsystatic.com/43031656/r/il/1eb95b/5623800026/il_300x300.5623800026_e4e5.jpg)
- ![May include: A blue and pink crocheted handbag with a gold chain strap. The bag has a pink lining and a gold clasp.](https://i.etsystatic.com/43031656/r/il/5d2f17/5623800068/il_300x300.5623800068_btkz.jpg)
- ![May include: A crocheted handbag with a pink and blue striped design. The bag has a gold chain strap.](https://i.etsystatic.com/43031656/r/il/95b6fb/5671873301/il_300x300.5671873301_n9lo.jpg)
- ![May include: A crocheted handbag with a blue and pink striped design and a gold chain strap.](https://i.etsystatic.com/43031656/r/il/22b7f6/5671873305/il_300x300.5671873305_jc86.jpg)

Scroll previousScroll next