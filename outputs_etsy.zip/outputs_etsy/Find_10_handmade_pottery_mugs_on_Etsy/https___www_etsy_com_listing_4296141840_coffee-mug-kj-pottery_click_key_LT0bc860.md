[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?amp;click_sum=f9c5e5c4&amp;ls=a&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=Find+10+handmade+pottery+mugs+on+Etsy&amp;ref=search_grid-308840-1-1&amp;sr_prefetch=1&amp;pf_from=search&amp;frs=1&amp;cns=1&amp;pop=1&amp;sts=1&amp;variation0=5347386183#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=f9c5e5c4&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+handmade+pottery+mugs+on+Etsy&%3Bref=search_grid-308840-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bfrs=1&%3Bcns=1&%3Bpop=1&%3Bsts=1&%3Bvariation0=5347386183&explicit=1&ref=catnav_breadcrumb-0)
- [Kitchen & Dining](https://www.etsy.com/c/home-and-living/kitchen-and-dining?amp%3Bclick_sum=f9c5e5c4&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+handmade+pottery+mugs+on+Etsy&%3Bref=search_grid-308840-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bfrs=1&%3Bcns=1&%3Bpop=1&%3Bsts=1&%3Bvariation0=5347386183&explicit=1&ref=catnav_breadcrumb-1)
- [Drink & Barware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware?amp%3Bclick_sum=f9c5e5c4&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+handmade+pottery+mugs+on+Etsy&%3Bref=search_grid-308840-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bfrs=1&%3Bcns=1&%3Bpop=1&%3Bsts=1&%3Bvariation0=5347386183&explicit=1&ref=catnav_breadcrumb-2)
- [Drinkware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware?amp%3Bclick_sum=f9c5e5c4&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+handmade+pottery+mugs+on+Etsy&%3Bref=search_grid-308840-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bfrs=1&%3Bcns=1&%3Bpop=1&%3Bsts=1&%3Bvariation0=5347386183&explicit=1&ref=catnav_breadcrumb-3)
- [Mugs](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/mugs?amp%3Bclick_sum=f9c5e5c4&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+handmade+pottery+mugs+on+Etsy&%3Bref=search_grid-308840-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bfrs=1&%3Bcns=1&%3Bpop=1&%3Bsts=1&%3Bvariation0=5347386183&explicit=1&ref=catnav_breadcrumb-4)

Etsy’s Pick

Etsy’s Picks are hand selected by our style experts to highlight items from shops that have shown quality, reliability and style.

[Discover More](https://www.etsy.com/featured/hub/etsy-picks?ref=listing_etsys_pick_signal)


Add to Favorites


- ![May include: A ceramic mug with a speckled gray glaze on the top half, a brown glaze on the bottom half, and a thin orange stripe separating the two glazes. The mug has a rounded handle.](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_794xN.6863380545_2ae7.jpg)
- ![May include: A speckled light green ceramic mug with a brown stripe around the middle. The mug has a rounded handle.](https://i.etsystatic.com/7825028/r/il/aeda4c/6863380347/il_794xN.6863380347_bc33.jpg)
- ![May include: A black ceramic mug with a brown stripe around the top and bottom. The mug has a handle and is sitting on a wooden surface.](https://i.etsystatic.com/7825028/r/il/3e70ba/6863380311/il_794xN.6863380311_6eki.jpg)
- ![May include: A ceramic mug with a yellow, brown, and blue speckled glaze. The mug has a wide, rounded base and a handle that curves out from the side.](https://i.etsystatic.com/7825028/r/il/58977e/6815390016/il_794xN.6815390016_mdew.jpg)
- ![May include: A speckled yellow ceramic mug with a brown handle and two brown bands around the mug.](https://i.etsystatic.com/7825028/r/il/5121e9/6815390260/il_794xN.6815390260_9d36.jpg)
- ![May include: A speckled tan ceramic mug with a blue and orange stripe design. The mug has a rounded handle.](https://i.etsystatic.com/7825028/r/il/553467/6863380541/il_794xN.6863380541_5poq.jpg)

- ![May include: A ceramic mug with a speckled gray glaze on the top half, a brown glaze on the bottom half, and a thin orange stripe separating the two glazes. The mug has a rounded handle.](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_75x75.6863380545_2ae7.jpg)
- ![May include: A speckled light green ceramic mug with a brown stripe around the middle. The mug has a rounded handle.](https://i.etsystatic.com/7825028/r/il/aeda4c/6863380347/il_75x75.6863380347_bc33.jpg)
- ![May include: A black ceramic mug with a brown stripe around the top and bottom. The mug has a handle and is sitting on a wooden surface.](https://i.etsystatic.com/7825028/r/il/3e70ba/6863380311/il_75x75.6863380311_6eki.jpg)
- ![May include: A ceramic mug with a yellow, brown, and blue speckled glaze. The mug has a wide, rounded base and a handle that curves out from the side.](https://i.etsystatic.com/7825028/r/il/58977e/6815390016/il_75x75.6815390016_mdew.jpg)
- ![May include: A speckled yellow ceramic mug with a brown handle and two brown bands around the mug.](https://i.etsystatic.com/7825028/r/il/5121e9/6815390260/il_75x75.6815390260_9d36.jpg)
- ![May include: A speckled tan ceramic mug with a blue and orange stripe design. The mug has a rounded handle.](https://i.etsystatic.com/7825028/r/il/553467/6863380541/il_75x75.6863380541_5poq.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F4296141840%2Fcoffee-mug-kj-pottery%23report-overlay-trigger)

In 20+ carts

Price:$47.00


Loading


# Coffee Mug - KJ Pottery

[KJPottery](https://www.etsy.com/shop/KJPottery?ref=shop-header-name&listing_id=4296141840&from_page=listing)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?amp;click_sum=f9c5e5c4&amp;ls=a&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=Find+10+handmade+pottery+mugs+on+Etsy&amp;ref=search_grid-308840-1-1&amp;sr_prefetch=1&amp;pf_from=search&amp;frs=1&amp;cns=1&amp;pop=1&amp;sts=1&amp;variation0=5347386183#reviews)

Returns & exchanges accepted

Glaze Color


Select an option

Sand & Cobalt Blue

Smoke & Brown Metal

Black & Black

Moss & Moss

Yellow & Yellow

Yellow & Denim

Please select an option


From **$16/month**, or 4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


**Star Seller.** This seller consistently earned 5-star reviews, shipped on time, and replied quickly to any messages they received.


## Item details

### Highlights

Made by [KJPottery](https://www.etsy.com/shop/KJPottery)

- Materials: Ceramic


- Capacity: 12 fluid ounces

This is KJ Pottery’s take on the perfect everyday ceramic mug—your go-to for morning coffee, afternoon tea, or your favorite cozy drink. Each mug is hand-thrown on the wheel, crafted with care in our studio, and glazed in one of our signature KJ Pottery glaze colors.

With a clean, straight-sided shape and a comfortable handle, this mug is designed for daily use and timeless style.

Product Features:

\- Handmade ceramic mug – each piece is wheel-thrown and individually glazed

\- Holds approx. 10–12 oz – great for coffee, tea, lattes, and hot chocolate

\- Straight-sided modern design – clean lines and a sturdy base

\- Food safe, microwave safe, and dishwasher safe

\- Available in classic KJ Pottery glaze colors

\- Made in the USA – handcrafted in our small-batch pottery studio in Spokane Washington

\- Perfect for everyday use or gifting

How to Order:

This listing is for one handmade mug.

\- To order a matching set of mugs, choose your quantity from the drop-down menu

\- To order mugs in multiple glaze colors, add each color to your cart separately

Shipping & Production:

Each mug is made to order, so please allow 1–2 weeks for your piece to be created and shipped. We take great care in crafting and packaging every item so it arrives ready to enjoy or gift.


## Shipping and return policies

Loading


- Order today to get by

**Nov 20-Dec 6**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns & exchanges accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 7 days


- Free shipping


- Ships from: **Spokane, WA**


Deliver to United States

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## Meet your sellers

![Kelsey Jo Johnson](https://i.etsystatic.com/7825028/r/isla/a55726/21766097/isla_75x75.21766097_nsrsbmf7.jpg)

Kelsey Jo Johnson

Owner of [KJPottery](https://www.etsy.com/shop/KJPottery?ref=l2-about-shopname&from_page=listing)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDozMDQzMzQ0NDoxNzYyODA2NzkwOmMwODViNTdmZjJmMDgyNDQ5ODU5OGQzZDM4Y2M2MjZm&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F4296141840%2Fcoffee-mug-kj-pottery%3Famp%253Bclick_sum%3Df9c5e5c4%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DFind%2B10%2Bhandmade%2Bpottery%2Bmugs%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-308840-1-1%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bfrs%3D1%26amp%253Bcns%3D1%26amp%253Bpop%3D1%26amp%253Bsts%3D1%26amp%253Bvariation0%3D5347386183)

[Message Kelsey Jo](https://www.etsy.com/messages/new?with_id=30433444&referring_id=4296141840&referring_type=listing&recipient_id=30433444&from_action=contact-seller)

This seller usually responds **within 24 hours.**

View shop registration details


Captcha failed to load. Try using a different browser or disabling ad blockers.

## Reviews for this item (45)

4.9/5

item average

5.0Item quality

4.8Shipping

4.9Customer service

98%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Beautiful

Love it

Great quality

Great product

Gift-worthy

Excellent craftsmanship

Would recommend


Filter by category


Quality (26)


Appearance (17)


Comfort (7)


Shipping & Packaging (7)


Description accuracy (5)


Seller service (3)


Sizing & Fit (1)


Condition (1)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/ddfbaa/82868613/iusa_75x75.82868613_9xpj.jpg?version=0)

[Joy Sheerer](https://www.etsy.com/people/joyseven?ref=l_review)
Nov 5, 2025


Great looking mug, bought for a gift



![](https://i.etsystatic.com/iusa/ddfbaa/82868613/iusa_75x75.82868613_9xpj.jpg?version=0)

[Joy Sheerer](https://www.etsy.com/people/joyseven?ref=l_review)
Nov 5, 2025


5 out of 5 stars
5

This item

[catlicht1](https://www.etsy.com/people/catlicht1?ref=l_review)
Nov 1, 2025


Lovely cups, feel great drinking out of, the colors are fabulous.



![catlicht1 added a photo of their purchase](https://i.etsystatic.com/iap/0a159b/7346911152/iap_300x300.7346911152_37ko1rfb.jpg?version=0)

[catlicht1](https://www.etsy.com/people/catlicht1?ref=l_review)
Nov 1, 2025


5 out of 5 stars
5

This item

[Kellie Lee Mintern](https://www.etsy.com/people/misheps1?ref=l_review)
Oct 31, 2025


Beautiful mug!! Thank you so much for such quality and fast shipping. I'll be back 🙂



![Kellie Lee Mintern added a photo of their purchase](https://i.etsystatic.com/iap/370d49/7344331344/iap_300x300.7344331344_ob55u2ph.jpg?version=0)

[Kellie Lee Mintern](https://www.etsy.com/people/misheps1?ref=l_review)
Oct 31, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/6bbbb5/42300664/iusa_75x75.42300664_j6rs.jpg?version=0)

[Grant Thomas](https://www.etsy.com/people/grantthomas5?ref=l_review)
Oct 29, 2025


Great product that will last for ages.



![](https://i.etsystatic.com/iusa/6bbbb5/42300664/iusa_75x75.42300664_j6rs.jpg?version=0)

[Grant Thomas](https://www.etsy.com/people/grantthomas5?ref=l_review)
Oct 29, 2025


View all reviews for this item

### Photos from reviews

![Connor added a photo of their purchase](https://i.etsystatic.com/iap/98e9fc/7339197855/iap_300x300.7339197855_8p1muuve.jpg?version=0)

![Kris added a photo of their purchase](https://i.etsystatic.com/iap/f88471/7329923812/iap_300x300.7329923812_9xs46ygl.jpg?version=0)

![joshua added a photo of their purchase](https://i.etsystatic.com/iap/a85de1/7224450245/iap_300x300.7224450245_2ot137a6.jpg?version=0)

![edwin added a photo of their purchase](https://i.etsystatic.com/iap/4bf4e9/7123835978/iap_300x300.7123835978_nhuun0el.jpg?version=0)

![edwin added a photo of their purchase](https://i.etsystatic.com/iap/61c9aa/7123833588/iap_300x300.7123833588_m7pyywxy.jpg?version=0)

![Julie added a photo of their purchase](https://i.etsystatic.com/iap/454ee5/7141140594/iap_300x300.7141140594_nzt963nv.jpg?version=0)

![Kellie added a photo of their purchase](https://i.etsystatic.com/iap/370d49/7344331344/iap_300x300.7344331344_ob55u2ph.jpg?version=0)

![sprakersmith added a photo of their purchase](https://i.etsystatic.com/iap/06402a/7016184938/iap_300x300.7016184938_q9cmulid.jpg?version=0)

![catlicht1 added a photo of their purchase](https://i.etsystatic.com/iap/0a159b/7346911152/iap_300x300.7346911152_37ko1rfb.jpg?version=0)

![Daniel added a photo of their purchase](https://i.etsystatic.com/iap/00696e/7032125128/iap_300x300.7032125128_9obn8004.jpg?version=0)

[![KJPottery](https://i.etsystatic.com/iusa/cf5903/42985865/iusa_75x75.42985865_btjh.jpg?version=0)](https://www.etsy.com/shop/KJPottery?ref=shop_profile&listing_id=4296141840)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[KJPottery](https://www.etsy.com/shop/KJPottery?ref=shop_profile&listing_id=4296141840)

[Owned by Kelsey Jo Johnson](https://www.etsy.com/shop/KJPottery?ref=shop_profile&listing_id=4296141840) \|

Spokane, Washington

4.8
(3.2k)


19.4k sales

12 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=30433444&referring_id=4296141840&referring_type=listing&recipient_id=30433444&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDozMDQzMzQ0NDoxNzYyODA2NzkwOmMwODViNTdmZjJmMDgyNDQ5ODU5OGQzZDM4Y2M2MjZm&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F4296141840%2Fcoffee-mug-kj-pottery%3Famp%253Bclick_sum%3Df9c5e5c4%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DFind%2B10%2Bhandmade%2Bpottery%2Bmugs%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-308840-1-1%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bfrs%3D1%26amp%253Bcns%3D1%26amp%253Bpop%3D1%26amp%253Bsts%3D1%26amp%253Bvariation0%3D5347386183)

This seller usually responds **within 24 hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/KJPottery?ref=lp_mys_mfts)

- [![Coffee Mug - KJ Pottery](https://i.etsystatic.com/7825028/r/il/02291b/4800337448/il_340x270.4800337448_s1n9.jpg)\\
\\
**Coffee Mug - KJ Pottery**\\
\\
$47.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1457257689/coffee-mug-kj-pottery?click_key=f242d26215b555169d7ed73658ce99e6%3ALT1654f2f8317459733009f57cca14a9c2380a3dde&click_sum=bf0a301f&ls=r&ref=related-1&sts=1&content_source=f242d26215b555169d7ed73658ce99e6%253ALT1654f2f8317459733009f57cca14a9c2380a3dde "Coffee Mug - KJ Pottery")




Add to Favorites


- [![Tumbler - KJ Pottery](https://i.etsystatic.com/7825028/r/il/422932/6815407590/il_340x270.6815407590_1lep.jpg)\\
\\
**Tumbler - KJ Pottery**\\
\\
$37.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4296143006/tumbler-kj-pottery?click_key=f242d26215b555169d7ed73658ce99e6%3ALTa5c0fb2120db1f43a1eaaad9a37f5a4a6ffda021&click_sum=c9f91fe0&ls=r&ref=related-2&sts=1&content_source=f242d26215b555169d7ed73658ce99e6%253ALTa5c0fb2120db1f43a1eaaad9a37f5a4a6ffda021 "Tumbler - KJ Pottery")




Add to Favorites


- [![Small Bowls - KJ Pottery](https://i.etsystatic.com/7825028/r/il/386e49/5466651330/il_340x270.5466651330_go45.jpg)\\
\\
**Small Bowls - KJ Pottery**\\
\\
$31.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1588384776/small-bowls-kj-pottery?click_key=f242d26215b555169d7ed73658ce99e6%3ALT4b41777116d21e5b4ca524209a7fa05e48ec0800&click_sum=4619edc5&ls=r&ref=related-3&sts=1&content_source=f242d26215b555169d7ed73658ce99e6%253ALT4b41777116d21e5b4ca524209a7fa05e48ec0800 "Small Bowls - KJ Pottery")




Add to Favorites


- [![Handmade Ceramic Salad Plate - Small Wheel-Thrown Dinnerware by KJ Pottery](https://i.etsystatic.com/7825028/r/il/d9fb2e/1075616595/il_340x270.1075616595_3kvk.jpg)\\
\\
**Handmade Ceramic Salad Plate - Small Wheel-Thrown Dinnerware by KJ Pottery**\\
\\
$47.00\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/460116026/handmade-ceramic-salad-plate-small-wheel?click_key=a54695d298de1605e42d1c77233c5c4f8a2b0929%3A460116026&click_sum=5ac8ebdd&ref=related-4&sts=1 "Handmade Ceramic Salad Plate - Small Wheel-Thrown Dinnerware by KJ Pottery")




Add to Favorites



Loading...

Loading


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 9, 2025


[803 favorites](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=f9c5e5c4&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+handmade+pottery+mugs+on+Etsy&%3Bref=search_grid-308840-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bfrs=1&%3Bcns=1&%3Bpop=1&%3Bsts=1&%3Bvariation0=5347386183&explicit=1&ref=breadcrumb_listing) [Kitchen & Dining](https://www.etsy.com/c/home-and-living/kitchen-and-dining?amp%3Bclick_sum=f9c5e5c4&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+handmade+pottery+mugs+on+Etsy&%3Bref=search_grid-308840-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bfrs=1&%3Bcns=1&%3Bpop=1&%3Bsts=1&%3Bvariation0=5347386183&explicit=1&ref=breadcrumb_listing) [Drink & Barware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware?amp%3Bclick_sum=f9c5e5c4&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+handmade+pottery+mugs+on+Etsy&%3Bref=search_grid-308840-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bfrs=1&%3Bcns=1&%3Bpop=1&%3Bsts=1&%3Bvariation0=5347386183&explicit=1&ref=breadcrumb_listing) [Drinkware](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware?amp%3Bclick_sum=f9c5e5c4&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+handmade+pottery+mugs+on+Etsy&%3Bref=search_grid-308840-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bfrs=1&%3Bcns=1&%3Bpop=1&%3Bsts=1&%3Bvariation0=5347386183&explicit=1&ref=breadcrumb_listing) [Mugs](https://www.etsy.com/c/home-and-living/kitchen-and-dining/drink-and-barware/drinkware/mugs?amp%3Bclick_sum=f9c5e5c4&%3Bls=a&%3Bga_order=most_relevant&%3Bga_search_type=all&%3Bga_view_type=gallery&%3Bga_search_query=Find+10+handmade+pottery+mugs+on+Etsy&%3Bref=search_grid-308840-1-1&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bfrs=1&%3Bcns=1&%3Bpop=1&%3Bsts=1&%3Bvariation0=5347386183&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Costume Accessories

[Julie Newmar Catwoman Mask for Sale](https://www.etsy.com/market/julie_newmar_catwoman_mask)

Womens Clothing

[Buy Womens Western Button Up Shirts Online](https://www.etsy.com/market/womens_western_button_up_shirts)

Drawing & Illustration

[Shop Police Woman Svg](https://www.etsy.com/market/police_woman_svg)

Shopping

[Freshman 28 Png - US](https://www.etsy.com/market/freshman_28_png)

Kitchen & Dining

[Inu! - The Original DIY Crystal Water Bottle with Clear Quartz - Lava Black by OfficialVitaJuwel](https://www.etsy.com/listing/814470054/inu-the-original-diy-crystal-water) [Pottery Mugs - US](https://www.etsy.com/market/pottery_mugs) [Pirate Face Mug for Sale](https://www.etsy.com/market/pirate_face_mug) [16oz Snowglobe Tumbler With Toppers - US](https://www.etsy.com/market/16oz_snowglobe_tumbler_with_toppers) [A pair of Indiana Glass amber creamer/small pitchers in their diamond point design on a petal base. Dish 1412 by StemwareAndSuch](https://www.etsy.com/listing/1385949816/a-pair-of-indiana-glass-amber) [Shop Tiered Wedding Cake Stand](https://www.etsy.com/market/tiered_wedding_cake_stand) [Tulipan by Frank Smith Sterling Silver Flatware Set for 12 Service 72 pcs S mono by antiquecupboardstore](https://www.etsy.com/listing/697104570/tulipan-by-frank-smith-sterling-silver) [Cheap Stanleys 40 Ounces - US](https://www.etsy.com/market/cheap_stanleys_40_ounces)

Home Decor

[English Pub Sign - US](https://www.etsy.com/market/english_pub_sign) [Antique hand painted vase by HarrisonHavenShoppes](https://www.etsy.com/listing/1323353943/antique-hand-painted-vase)

Hats & Caps

[Gold Jeweled Wedding Hats - US](https://www.etsy.com/market/gold_jeweled_wedding_hats)

Rings

[1.5 Mm Silver Band for Sale](https://www.etsy.com/market/1.5_mm_silver_band)

Gender Neutral Adult Clothing

[Bride Or Die Funny Bachelorette Party Shirts Til Death Do Us Party Halloween Bachelorette Favors Gothic Bride Tshirt Skeleton Bach Tee Group by AuthenticDesignedArt](https://www.etsy.com/listing/4340911919/bride-or-die-funny-bachelorette-party)

Keychains & Lanyards

[Buy Slay The Spire Keychain Online](https://www.etsy.com/market/slay_the_spire_keychain)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F4296141840%2Fcoffee-mug-kj-pottery%3Famp%253Bclick_sum%3Df9c5e5c4%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DFind%2B10%2Bhandmade%2Bpottery%2Bmugs%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-308840-1-1%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bfrs%3D1%26amp%253Bcns%3D1%26amp%253Bpop%3D1%26amp%253Bsts%3D1%26amp%253Bvariation0%3D5347386183&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgwNjc5MDpkZDdlYzA0NmRiYmZjYTBlNDM3M2YzYjU3MGFmOWMzMg==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F4296141840%2Fcoffee-mug-kj-pottery%3Famp%253Bclick_sum%3Df9c5e5c4%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DFind%2B10%2Bhandmade%2Bpottery%2Bmugs%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-308840-1-1%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bfrs%3D1%26amp%253Bcns%3D1%26amp%253Bpop%3D1%26amp%253Bsts%3D1%26amp%253Bvariation0%3D5347386183) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?amp;click_sum=f9c5e5c4&amp;ls=a&amp;ga_order=most_relevant&amp;ga_search_type=all&amp;ga_view_type=gallery&amp;ga_search_query=Find+10+handmade+pottery+mugs+on+Etsy&amp;ref=search_grid-308840-1-1&amp;sr_prefetch=1&amp;pf_from=search&amp;frs=1&amp;cns=1&amp;pop=1&amp;sts=1&amp;variation0=5347386183#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F4296141840%2Fcoffee-mug-kj-pottery%3Famp%253Bclick_sum%3Df9c5e5c4%26amp%253Bls%3Da%26amp%253Bga_order%3Dmost_relevant%26amp%253Bga_search_type%3Dall%26amp%253Bga_view_type%3Dgallery%26amp%253Bga_search_query%3DFind%2B10%2Bhandmade%2Bpottery%2Bmugs%2Bon%2BEtsy%26amp%253Bref%3Dsearch_grid-308840-1-1%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bfrs%3D1%26amp%253Bcns%3D1%26amp%253Bpop%3D1%26amp%253Bsts%3D1%26amp%253Bvariation0%3D5347386183)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for KJPottery

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 24 hours of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## Seller details

### Location

Need to get in touch with the seller? Try [messaging them](https://www.etsy.com/messages/new?with_id=30433444&referring_id=7825028&referring_type=shop&recipient_id=30433444&from_action=contact-seller) on Etsy first.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


- Item in the photo is in **Glaze Color: Smoke & Brown Metal**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Glaze Color: Moss & Moss**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Glaze Color: Black & Black**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Glaze Color: Yellow & Denim**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Glaze Color: Yellow & Yellow**




Select this option








Option selected!













This option is sold out.


- Item in the photo is in **Glaze Color: Sand & Cobalt Blue**




Select this option








Option selected!













This option is sold out.



Click to zoom

- ![May include: A ceramic mug with a speckled gray glaze on the top half, a brown glaze on the bottom half, and a thin orange stripe separating the two glazes. The mug has a rounded handle.](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_300x300.6863380545_2ae7.jpg)
- ![May include: A speckled light green ceramic mug with a brown stripe around the middle. The mug has a rounded handle.](https://i.etsystatic.com/7825028/r/il/aeda4c/6863380347/il_300x300.6863380347_bc33.jpg)
- ![May include: A black ceramic mug with a brown stripe around the top and bottom. The mug has a handle and is sitting on a wooden surface.](https://i.etsystatic.com/7825028/r/il/3e70ba/6863380311/il_300x300.6863380311_6eki.jpg)
- ![May include: A ceramic mug with a yellow, brown, and blue speckled glaze. The mug has a wide, rounded base and a handle that curves out from the side.](https://i.etsystatic.com/7825028/r/il/58977e/6815390016/il_300x300.6815390016_mdew.jpg)
- ![May include: A speckled yellow ceramic mug with a brown handle and two brown bands around the mug.](https://i.etsystatic.com/7825028/r/il/5121e9/6815390260/il_300x300.6815390260_9d36.jpg)
- ![May include: A speckled tan ceramic mug with a blue and orange stripe design. The mug has a rounded handle.](https://i.etsystatic.com/7825028/r/il/553467/6863380541/il_300x300.6863380541_5poq.jpg)

- ![](https://i.etsystatic.com/iap/98e9fc/7339197855/iap_640x640.7339197855_8p1muuve.jpg?version=0)

5 out of 5 stars

- Glaze Color:

Yellow & Denim


Fantastic piece of pottery, Well made and the glaze looks fantastic. I use it as my daily mug now.

Oct 15, 2025


[Connor Fischer](https://www.etsy.com/people/connorjfischer)

Purchased item:

[![Coffee Mug - KJ Pottery](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_170x135.6863380545_2ae7.jpg)\\
\\
Coffee Mug - KJ Pottery\\
\\
$47.00](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?ref=ap-listing)

Purchased item:

[![Coffee Mug - KJ Pottery](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_170x135.6863380545_2ae7.jpg)\\
\\
Coffee Mug - KJ Pottery\\
\\
$47.00](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/f88471/7329923812/iap_640x640.7329923812_9xs46ygl.jpg?version=0)

5 out of 5 stars

- Glaze Color:

Smoke & Brown Metal


The large mug is a little shorter and squattier than I anticipated but I like it. Well made, and works great for my daily cup of coffee.

Oct 27, 2025


[Kris Kline](https://www.etsy.com/people/gugrlwyzo4umd7h8)

Purchased item:

[![Coffee Mug - KJ Pottery](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_170x135.6863380545_2ae7.jpg)\\
\\
Coffee Mug - KJ Pottery\\
\\
$47.00](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?ref=ap-listing)

Purchased item:

[![Coffee Mug - KJ Pottery](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_170x135.6863380545_2ae7.jpg)\\
\\
Coffee Mug - KJ Pottery\\
\\
$47.00](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/a85de1/7224450245/iap_640x640.7224450245_2ot137a6.jpg?version=0)

5 out of 5 stars

- Glaze Color:

Smoke & Brown Metal


I absolutely love my mug. I ordered this after breaking my favorite coffee mug, and I think this one is even better! Gorgeous colors, excellent craftsmanship, feels great in the hand.

![](https://i.etsystatic.com/iusa/0e9545/53248689/iusa_75x75.53248689_r8jq.jpg?version=0)

Sep 6, 2025


[joshua heath](https://www.etsy.com/people/heathmusic)

Purchased item:

[![Coffee Mug - KJ Pottery](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_170x135.6863380545_2ae7.jpg)\\
\\
Coffee Mug - KJ Pottery\\
\\
$47.00](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?ref=ap-listing)

Purchased item:

[![Coffee Mug - KJ Pottery](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_170x135.6863380545_2ae7.jpg)\\
\\
Coffee Mug - KJ Pottery\\
\\
$47.00](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/4bf4e9/7123835978/iap_640x640.7123835978_nhuun0el.jpg?version=0)

5 out of 5 stars

- Glaze Color:

Moss & Moss


Cup is crafted beautifully. Great mug for our Coffee cup collection!

Aug 19, 2025


[edwin](https://www.etsy.com/people/ikgng4c0)

Purchased item:

[![Coffee Mug - KJ Pottery](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_170x135.6863380545_2ae7.jpg)\\
\\
Coffee Mug - KJ Pottery\\
\\
$47.00](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?ref=ap-listing)

Purchased item:

[![Coffee Mug - KJ Pottery](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_170x135.6863380545_2ae7.jpg)\\
\\
Coffee Mug - KJ Pottery\\
\\
$47.00](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/61c9aa/7123833588/iap_640x640.7123833588_m7pyywxy.jpg?version=0)

5 out of 5 stars

- Glaze Color:

Grey & Yellow


Nice and well made, beautiful looking color!

Aug 19, 2025


[edwin](https://www.etsy.com/people/ikgng4c0)

Purchased item:

[![Coffee Mug - KJ Pottery](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_170x135.6863380545_2ae7.jpg)\\
\\
Coffee Mug - KJ Pottery\\
\\
$47.00](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?ref=ap-listing)

Purchased item:

[![Coffee Mug - KJ Pottery](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_170x135.6863380545_2ae7.jpg)\\
\\
Coffee Mug - KJ Pottery\\
\\
$47.00](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/454ee5/7141140594/iap_640x640.7141140594_nzt963nv.jpg?version=0)

5 out of 5 stars

- Glaze Color:

Moss & Moss


Very happy with the beautiful color and quality.

![](https://i.etsystatic.com/iusa/6cfa2c/94877414/iusa_75x75.94877414_w0hd.jpg?version=0)

Aug 25, 2025


[Julie Hundt](https://www.etsy.com/people/8ugnehg5)

Purchased item:

[![Coffee Mug - KJ Pottery](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_170x135.6863380545_2ae7.jpg)\\
\\
Coffee Mug - KJ Pottery\\
\\
$47.00](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?ref=ap-listing)

Purchased item:

[![Coffee Mug - KJ Pottery](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_170x135.6863380545_2ae7.jpg)\\
\\
Coffee Mug - KJ Pottery\\
\\
$47.00](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/370d49/7344331344/iap_640x640.7344331344_ob55u2ph.jpg?version=0)

5 out of 5 stars

- Glaze Color:

Grey & Yellow


Beautiful mug!! Thank you so much for such quality and fast shipping. I'll be back 🙂

Oct 31, 2025


[Kellie Lee Mintern](https://www.etsy.com/people/misheps1)

Purchased item:

[![Coffee Mug - KJ Pottery](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_170x135.6863380545_2ae7.jpg)\\
\\
Coffee Mug - KJ Pottery\\
\\
$47.00](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?ref=ap-listing)

Purchased item:

[![Coffee Mug - KJ Pottery](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_170x135.6863380545_2ae7.jpg)\\
\\
Coffee Mug - KJ Pottery\\
\\
$47.00](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/06402a/7016184938/iap_640x640.7016184938_q9cmulid.jpg?version=0)

5 out of 5 stars

- Glaze Color:

Smoke & Brown Metal


Beautiful and unique mugs. Nice addition to the plates and bowls bought previously. Thanks!

Jul 13, 2025


[sprakersmith](https://www.etsy.com/people/sprakersmith)

Purchased item:

[![Coffee Mug - KJ Pottery](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_170x135.6863380545_2ae7.jpg)\\
\\
Coffee Mug - KJ Pottery\\
\\
$47.00](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?ref=ap-listing)

Purchased item:

[![Coffee Mug - KJ Pottery](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_170x135.6863380545_2ae7.jpg)\\
\\
Coffee Mug - KJ Pottery\\
\\
$47.00](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/0a159b/7346911152/iap_640x640.7346911152_37ko1rfb.jpg?version=0)

5 out of 5 stars

- Glaze Color:

Moss & Moss


Lovely cups, feel great drinking out of, the colors are fabulous.

Nov 1, 2025


[catlicht1](https://www.etsy.com/people/catlicht1)

Purchased item:

[![Coffee Mug - KJ Pottery](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_170x135.6863380545_2ae7.jpg)\\
\\
Coffee Mug - KJ Pottery\\
\\
$47.00](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?ref=ap-listing)

Purchased item:

[![Coffee Mug - KJ Pottery](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_170x135.6863380545_2ae7.jpg)\\
\\
Coffee Mug - KJ Pottery\\
\\
$47.00](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/00696e/7032125128/iap_640x640.7032125128_9obn8004.jpg?version=0)

5 out of 5 stars

- Glaze Color:

Yellow & Denim


Love it. Used it for the first time today

Jul 18, 2025


[Daniel](https://www.etsy.com/people/c9xjf1au5nmvc3ne)

Purchased item:

[![Coffee Mug - KJ Pottery](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_170x135.6863380545_2ae7.jpg)\\
\\
Coffee Mug - KJ Pottery\\
\\
$47.00](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?ref=ap-listing)

Purchased item:

[![Coffee Mug - KJ Pottery](https://i.etsystatic.com/7825028/r/il/d7f677/6863380545/il_170x135.6863380545_2ae7.jpg)\\
\\
Coffee Mug - KJ Pottery\\
\\
$47.00](https://www.etsy.com/listing/4296141840/coffee-mug-kj-pottery?ref=ap-listing)