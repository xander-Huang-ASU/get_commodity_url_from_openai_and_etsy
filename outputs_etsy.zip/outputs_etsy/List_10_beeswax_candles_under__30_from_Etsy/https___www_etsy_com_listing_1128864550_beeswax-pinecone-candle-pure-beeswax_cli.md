[Etsy](https://www.etsy.com/?ref=lgo)

Categories


[Accessories](https://www.etsy.com/c/accessories?ref=catnav-1) [Art & Collectibles](https://www.etsy.com/c/art-and-collectibles?ref=catnav-66) [Baby](https://www.etsy.com/c/baby?ref=catnav-12545) [Bags & Purses](https://www.etsy.com/c/bags-and-purses?ref=catnav-132) [Bath & Beauty](https://www.etsy.com/c/bath-and-beauty?ref=catnav-199) [Books, Movies & Music](https://www.etsy.com/c/books-movies-and-music?ref=catnav-323) [Clothing](https://www.etsy.com/c/clothing?ref=catnav-374) [Craft Supplies & Tools](https://www.etsy.com/c/craft-supplies-and-tools?ref=catnav-562) [Electronics & Accessories](https://www.etsy.com/c/electronics-and-accessories?ref=catnav-825) [Gifts](https://www.etsy.com/c/gifts?ref=catnav-12584) [Home & Living](https://www.etsy.com/c/home-and-living?ref=catnav-891) [Jewelry](https://www.etsy.com/c/jewelry?ref=catnav-1179) [Paper & Party Supplies](https://www.etsy.com/c/paper-and-party-supplies?ref=catnav-1250) [Pet Supplies](https://www.etsy.com/c/pet-supplies?ref=catnav-1351) [Shoes](https://www.etsy.com/c/shoes?ref=catnav-1429) [Toys & Games](https://www.etsy.com/c/toys-and-games?ref=catnav-1552) [Weddings](https://www.etsy.com/c/weddings?ref=catnav-1633)

Browse


Search for items or shops

Clear search

[Skip to Content](https://www.etsy.com/listing/1128864550/beeswax-pinecone-candle-pure-beeswax?amp;click_sum=85dadfd5&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3&amp;sts=1#content)

- Sign in

-
Gifts


- [0](https://www.etsy.com/cart?ref=hdr-cart) Cart

- [Gifts](https://www.etsy.com/featured/hub/gifts?ref=gift_global_nav)
- [Our Top 100 Gifts](https://www.etsy.com/r/curated/top-100-gifts?sections=1412989769685&ref=111025Top100_cat_nav)
- [Home Favorites](https://www.etsy.com/featured/hub/home-favorites?ref=contentful_promo_cat_nav-5)
- [Fashion Finds](https://www.etsy.com/featured/hub/fashion-favorites?ref=contentful_promo_cat_nav-6)
- [Registry](https://www.etsy.com/registry?ref=contentful_promo_cat_nav-8)
- [Gift Cards](https://www.etsy.com/giftcards?ref=contentful_promo_cat_nav-9)

- [Homepage](https://www.etsy.com/?ref=catnav_breadcrumb-home)
- [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=85dadfd5&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-0)
- [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=85dadfd5&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-1)
- [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=85dadfd5&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-2)
- [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=85dadfd5&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-3)
- [Votive Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/votive-candles?amp%3Bclick_sum=85dadfd5&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=catnav_breadcrumb-4)

Etsy’s Pick

Etsy’s Picks are hand selected by our style experts to highlight items from shops that have shown quality, reliability and style.

[Discover More](https://www.etsy.com/featured/hub/etsy-picks?ref=listing_etsys_pick_signal)


Add to Favorites


- ![May include: Four yellow beeswax pine cone candles on a wooden surface. The candles are different sizes and shapes. The candles are a natural yellow color and have a rough texture. The candles are a popular choice for home decor and aromatherapy.](https://i.etsystatic.com/6767952/r/il/f0a1d9/3540879102/il_794xN.3540879102_i2z7.jpg)
- ![May include: A yellow beeswax candle shaped like a pine cone. The candle has a white wick and is sitting on a wooden surface.](https://i.etsystatic.com/6767952/r/il/8e0f1c/3588518397/il_794xN.3588518397_jdg6.jpg)
- ![May include: A small, yellow beeswax candle shaped like a pine cone with a white wick. The candle is sitting on a wooden surface.](https://i.etsystatic.com/6767952/r/il/9ff9ff/3588518935/il_794xN.3588518935_sys9.jpg)

- ![May include: Four yellow beeswax pine cone candles on a wooden surface. The candles are different sizes and shapes. The candles are a natural yellow color and have a rough texture. The candles are a popular choice for home decor and aromatherapy.](https://i.etsystatic.com/6767952/r/il/f0a1d9/3540879102/il_75x75.3540879102_i2z7.jpg)
- ![May include: A yellow beeswax candle shaped like a pine cone. The candle has a white wick and is sitting on a wooden surface.](https://i.etsystatic.com/6767952/r/il/8e0f1c/3588518397/il_75x75.3588518397_jdg6.jpg)
- ![May include: A small, yellow beeswax candle shaped like a pine cone with a white wick. The candle is sitting on a wooden surface.](https://i.etsystatic.com/6767952/r/il/9ff9ff/3588518935/il_75x75.3588518935_sys9.jpg)

[Report this item to Etsy](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1128864550%2Fbeeswax-pinecone-candle-pure-beeswax%23report-overlay-trigger)

In 12 carts

Price:$3.49+


Loading


# Beeswax Pinecone Candle ~ Pure Beeswax Candles from Beekeepers Hive

Designed by [KlineHoneyBeeFarm](https://www.etsy.com/shop/KlineHoneyBeeFarm)

Star Seller


Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.


[5 out of 5 stars](https://www.etsy.com/listing/1128864550/beeswax-pinecone-candle-pure-beeswax?amp;click_sum=85dadfd5&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3&amp;sts=1#reviews)

Arrives soon! Get it by

Nov 13-17


Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.

if you order today

Returns accepted

Size


Select an option

Small ($3.49)

Medium ($4.95)

Please select an option


Quantity



123456789101112131415

4 payments at 0% interest with
KlarnaLearn more


You can only make an offer when buying a single item


Add to cart



Loading


## Item details

### Highlights

Designed by [KlineHoneyBeeFarm](https://www.etsy.com/shop/KlineHoneyBeeFarm)

- Materials: beeswax, candle wick



You will receive, your choice!

Medium Pinecone:

Finished size: 3¾” x 1¾”

Weighs over 2.5 oz wax

Small Pinecone:

Finished: 2" x 2"

Weighs over 1 oz. of wax

Great for fall and year round centerpieces.

Each Pinecone will be different, and have its own unique flaws. Just like in Nature.

This beeswax is harvested right from our own bees. We take our capping once or twice a year from our hives after we harvest the honey, melt it and filter it and process it into blocks, candles or what ever we desire.

No longer just for candles—put this natural material to work around the house.

If you should need a larger quantity we have plenty on hand. Please let me know if we can help in any way.

Beeswax is the only fuel to emit (Negative Ions) when burning. Dust, hair, odors and other things floating in the air are doing so because the particles are positively charged. Allergens and toxins become positively charged through static electricity created by heating systems and friction caused by normal activity (such as when you walk across the carpet). Pure beeswax candles help rid your home of toxins by emitting negatively, charged ions, as well as, burning away positively charged particles that float toward the burning halo flame. This process cleans the air of positive ions such as dust, odors, toxins, pollen, mold, dust mites feces, and viruses. This is beneficial for people who have allergies, and environmental sensitivities.


## Shipping and return policies

Loading


- Order today to get by

**Nov 13-17**




Your order should arrive by this date if you buy today. To calculate an [estimated delivery date](https://help.etsy.com/hc/articles/360020601674) you can count on, we look at things like the carrier's latest transit times, the seller's processing time and shipping history, and where the order is shipping to and from.


- Returns accepted




Buyers are responsible for return shipping costs. If the item is not returned in its original condition, the buyer is responsible for any loss in value.






within 14 days


- Ships from: **Rootstown, OH**


Get shipping cost

There was a problem calculating your shipping. Please try again.

Country

\-\-\--------United States

Zip code


- Please enter a valid zip code.


Submit



Loading


## Did you know?

**Etsy Purchase Protection**

Shop confidently on Etsy knowing if something goes wrong with an order, we've got your back for all eligible purchases —
[see program terms](https://www.etsy.com/etsy-purchase-protection)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

Etsy invests in climate solutions like electric trucks and carbon offsets for every delivery. [See how](https://www.etsy.com/climateimpact?ref=listing)

View additional shop policies

## FAQs

When Should I order my Baby Shower/Wedding Favors


We recommend having your order arrive no sooner than 2-3 weeks prior to your event. We would like your guests to have the freshest product for your event. We do ship fast, Just ask!


How long are Honey Sticks good for?


Our honey sticks will be good forever. We do recommend using them within 12-18 months of purchase, to ensure freshness, as they remain liquid. Honey sticks will however, begin to crystalize or form sugar crystals over time. Completly edible and a few prefer this texture.


What is "Raw Honey"


Raw honey is basically unheated, unprocessed and unfiltered. No mixing, blending, straight from a beehive.  All honey is liquid once extracted from the hive. Because some floral varietals of honey tend to granulate and appear sugary over time, some honey companies process/heat and stabilize their honey to stop crystallization and keep their honey in clear, desirable form on the shelves, other wise known as pasteurization.  All Raw honey will crystallize, some in weeks or maybe a few months.  Crystallization ensures a pure product.

Our honey is "Raw"

Crystallization is a natural and reversible process.  Simply place jar in warm water to liquefy.  Do not microwave or refrigerate.


Do you send out an email newsletter?


http://klinefarm.us16.list-manage.com/subscribe?u=c4b2fc37482edd1270c1e9c7c&id=25e9494828

Please follow the link and fill out the information needed for our monthly newsletter.


## Reviews for this item (23)

5.0/5

item average

5.0Item quality

5.0Shipping

5.0Customer service

100%
Buyers recommend

Loading


Buyer highlights, summarized by AI

Smells amazing

Fast shipping

Adorable

Great quality

Beautiful

Love it

Wonderful seller


Filter by category


Quality (9)


Appearance (6)


Shipping & Packaging (5)


Seller service (3)

Suggested

Suggested

Most recent

Highest Rating

Lowest Rating

5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/571263/31701453/iusa_75x75.31701453_tmcr.jpg?version=0)

[Michele Kirbach](https://www.etsy.com/people/mmmk33?ref=l_review)
Oct 7, 2025


Adorable design!! High quality beeswax, smells amazing!



![](https://i.etsystatic.com/iusa/571263/31701453/iusa_75x75.31701453_tmcr.jpg?version=0)

[Michele Kirbach](https://www.etsy.com/people/mmmk33?ref=l_review)
Oct 7, 2025


5 out of 5 stars
5

This item

![](https://i.etsystatic.com/iusa/914169/53484520/iusa_75x75.53484520_5vzd.jpg?version=0)

[Carly Meyer](https://www.etsy.com/people/CarlyMichelexx?ref=l_review)
Feb 7, 2025


Gorgeous candles burn cleanly and smell beautiful. I only burn beeswax as I love the gentle honey smell and warm glow. Will be reordering these next time I restock!



![](https://i.etsystatic.com/iusa/914169/53484520/iusa_75x75.53484520_5vzd.jpg?version=0)

[Carly Meyer](https://www.etsy.com/people/CarlyMichelexx?ref=l_review)
Feb 7, 2025


5 out of 5 stars
5

This item

[Leah](https://www.etsy.com/people/uxcs6eh9?ref=l_review)
Dec 6, 2024


These pure beeswax pinecone candles are even even more adorable in person & are so fragrant!



![Leah added a photo of their purchase](https://i.etsystatic.com/iap/e1adac/6486516584/iap_300x300.6486516584_t3qhfcwj.jpg?version=0)

[Leah](https://www.etsy.com/people/uxcs6eh9?ref=l_review)
Dec 6, 2024


5 out of 5 stars
5

This item

[Amelia](https://www.etsy.com/people/FITZA?ref=l_review)
Sep 5, 2024


Absolutely wonderful candles. In love with them. Thank you!



[Amelia](https://www.etsy.com/people/FITZA?ref=l_review)
Sep 5, 2024


View all reviews for this item

### Photos from reviews

![Leah added a photo of their purchase](https://i.etsystatic.com/iap/e1adac/6486516584/iap_300x300.6486516584_t3qhfcwj.jpg?version=0)

![Kelly added a photo of their purchase](https://i.etsystatic.com/iap/cae1b3/4495671543/iap_300x300.4495671543_fztaym57.jpg?version=0)

[![KlineHoneyBeeFarm](https://i.etsystatic.com/iusa/41ce23/88713482/iusa_75x75.88713482_1bw0.jpg?version=0)](https://www.etsy.com/shop/KlineHoneyBeeFarm?ref=shop_profile&listing_id=1128864550)

Star Seller

Star Sellers have an outstanding track record for providing a great customer experience—they consistently earned 5-star reviews, shipped orders on time, and replied quickly to any messages they received.

[KlineHoneyBeeFarm](https://www.etsy.com/shop/KlineHoneyBeeFarm?ref=shop_profile&listing_id=1128864550)

[Owned by Kline Honey Bee](https://www.etsy.com/shop/KlineHoneyBeeFarm?ref=shop_profile&listing_id=1128864550) \|

Rootstown, Ohio

5.0
(11.7k)


44.1k sales

13 years on Etsy

[Message seller](https://www.etsy.com/messages/new?with_id=17994510&referring_id=1128864550&referring_type=listing&recipient_id=17994510&from_action=contact-seller)

[Following\\
\\
Follow shop](https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDoxNzk5NDUxMDoxNzYyODIzOTQ1OmFiZDQyMzFlZmExYTMwZGQ5ZjI2ODE3NWRhZWI1NjMw&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1128864550%2Fbeeswax-pinecone-candle-pure-beeswax%3Famp%253Bclick_sum%3D85dadfd5%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bsts%3D1)

This seller usually responds **within a few hours.**

Smooth shippingHas a history of shipping on time with tracking.

Speedy repliesHas a history of replying to messages quickly.

Rave reviewsAverage review rating is 4.8 or higher.

## More from this shop

[Visit shop](https://www.etsy.com/shop/KlineHoneyBeeFarm?ref=lp_mys_mfts)

- [![Beeswax Christmas Tree Trio Pure Beeswax Candles from Beekeepers Hive](https://i.etsystatic.com/6767952/r/il/23140d/5586110425/il_340x270.5586110425_h5ck.jpg)\\
\\
**Beeswax Christmas Tree Trio Pure Beeswax Candles from Beekeepers Hive**\\
\\
$15.95\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1618917099/beeswax-christmas-tree-trio-pure-beeswax?click_key=6df0d0d15068e56c60ef4efdf0a1ec29%3ALT740f5da5827be853b32462eed03444ce2af4d9c0&click_sum=ebe7730f&ls=r&ref=related-1&sts=1&content_source=6df0d0d15068e56c60ef4efdf0a1ec29%253ALT740f5da5827be853b32462eed03444ce2af4d9c0 "Beeswax Christmas Tree Trio Pure Beeswax Candles from Beekeepers Hive")




Add to Favorites


- [![Large Beeswax Pinecone Candle Pure Beeswax Candles from Beekeepers Hive](https://i.etsystatic.com/6767952/c/2244/1783/0/364/il/e94d45/3446661967/il_340x270.3446661967_kwaa.jpg)\\
\\
**Large Beeswax Pinecone Candle Pure Beeswax Candles from Beekeepers Hive**\\
\\
$20.95\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/1102769531/large-beeswax-pinecone-candle-pure?click_key=6df0d0d15068e56c60ef4efdf0a1ec29%3ALT67545cc1b4d78448ae01ee5e4273f631c0da860c&click_sum=a52af023&ls=r&ref=related-2&sts=1&content_source=6df0d0d15068e56c60ef4efdf0a1ec29%253ALT67545cc1b4d78448ae01ee5e4273f631c0da860c "Large Beeswax Pinecone Candle Pure Beeswax Candles from Beekeepers Hive")




Add to Favorites


- [![3pc. Beeswax Pinecone Candle Trio- Pure Beeswax Candles from Beekeepers Hive](https://i.etsystatic.com/6767952/c/2244/1783/0/1198/il/5d1de5/4294945702/il_340x270.4294945702_94z5.jpg)\\
\\
**3pc. Beeswax Pinecone Candle Trio- Pure Beeswax Candles from Beekeepers Hive**\\
\\
$24.95\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/260113651/3pc-beeswax-pinecone-candle-trio-pure?click_key=6df0d0d15068e56c60ef4efdf0a1ec29%3ALT9ed9b88695c974fc45b4ccb26a2b55f88de50990&click_sum=c810e3cd&ls=r&ref=related-3&sts=1&content_source=6df0d0d15068e56c60ef4efdf0a1ec29%253ALT9ed9b88695c974fc45b4ccb26a2b55f88de50990 "3pc. Beeswax Pinecone Candle Trio- Pure Beeswax Candles from Beekeepers Hive")




Add to Favorites


- [![Hand Dipped 8&quot; Slim Beeswax Taper Candlestick - Candle Dripless Pure Beeswax from Beekeepers Hives](https://i.etsystatic.com/6767952/r/il/bd9680/7204318162/il_340x270.7204318162_i5uq.jpg)\\
\\
**Hand Dipped 8" Slim Beeswax Taper Candlestick - Candle Dripless Pure Beeswax from Beekeepers Hives**\\
\\
$6.95\\
\\
Add to cart\\
\\
Loading](https://www.etsy.com/listing/4370726833/hand-dipped-8-slim-beeswax-taper?click_key=6383820ac792c7294d96eefb53c169f6a259d68b%3A4370726833&click_sum=d385bb5b&ref=related-4&sts=1 "Hand Dipped 8\" Slim Beeswax Taper Candlestick - Candle Dripless Pure Beeswax from Beekeepers Hives")




Add to Favorites



Loading...

Loading


**Disclaimer:** Button/coin batteries may cause serious injury and even death if swallowed. Items containing button/coin batteries should not be easily accessible without the use of a tool. Sellers are responsible for complying with all applicable labeling, design, testing, packaging, and other safety requirements. Etsy assumes no responsibility for the accuracy or contents of a seller’s listing. If you have questions about button/coin batteries, contact the seller by sending a Message. See Etsy's [Terms of Use](https://www.etsy.com/legal/terms-of-use/?ref=product_safety_banner_info_button_batteries_risk#warranties) for more information.

Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading...


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Loading


Listed on Nov 7, 2025


[153 favorites](https://www.etsy.com/listing/1128864550/beeswax-pinecone-candle-pure-beeswax/favoriters?ref=l2-collection-count)

[Homepage](https://www.etsy.com/?ref=breadcrumb_listing) [Home & Living](https://www.etsy.com/c/home-and-living?amp%3Bclick_sum=85dadfd5&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Home Decor](https://www.etsy.com/c/home-and-living/home-decor?amp%3Bclick_sum=85dadfd5&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Candles & Home Fragrances](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances?amp%3Bclick_sum=85dadfd5&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles?amp%3Bclick_sum=85dadfd5&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=breadcrumb_listing) [Votive Candles](https://www.etsy.com/c/home-and-living/home-decor/candles-and-home-fragrances/candles/votive-candles?amp%3Bclick_sum=85dadfd5&%3Bsr_prefetch=1&%3Bpf_from=search&%3Bref=search2_top_narrowing_intent_modules_high_craftsmanship-3&%3Bsts=1&explicit=1&ref=breadcrumb_listing)

Looking for more? Find it on Etsy

Looking for more? Find it on Etsy

Home Decor

[Vintage Bird Wall Art Framed - US](https://www.etsy.com/market/vintage_bird_wall_art_framed) [Dog Wallpaper](https://www.etsy.com/listing/1263568497/dog-wallpaper-wall-mural-peel-and-stick) [Corgi Wall Art](https://www.etsy.com/listing/1896931489/corgi-wall-art-vintage-meadow-dog-print) [Bumblebee Bow for Wreath - Home Decor](https://www.etsy.com/listing/1219483980/bumblebee-bow-for-wreath-bow-wreath-bow) [Halloween Decor Throw Pillow Cover](https://www.etsy.com/listing/1554110511/halloween-decor-throw-pillow-cover) [Brass Pineapple Wall Candlestick Holder Pair - Home Decor](https://www.etsy.com/listing/1265283186/brass-pineapple-wall-candlestick-holder) [Lawn Signs Slow Down for Sale](https://www.etsy.com/market/lawn_signs_slow_down) [Abstract Ocean Waves Wallpaper: Coastal Beach House Wall Mural; Minimalist Peel and Stick or Traditional Decor](https://www.etsy.com/listing/1516360097/abstract-ocean-waves-wallpaper-coastal) [Shop School Office Theme Ideas](https://www.etsy.com/market/school_office_theme_ideas) [Buy Theodore Roosevelt Headphone Stand Online](https://www.etsy.com/market/theodore_roosevelt_headphone_stand) [Helen Keller Sign for Sale](https://www.etsy.com/market/helen_keller_sign)

Patches & Pins

[Shop England Rugby Patch](https://www.etsy.com/market/england_rugby_patch)

Paper

[Work Birthday Questionnaire for Sale](https://www.etsy.com/market/work_birthday_questionnaire)

Drawing & Illustration

[Christmas Snowman Png](https://www.etsy.com/listing/1337183447/i-am-snow-cute-png-sublimation-design)

Toys

[Dwayne Johnson 3d Print Worm for Sale](https://www.etsy.com/market/dwayne_johnson_3d_print_worm)

Earrings

[925 Sterling Silver Swarovski Cristal Teardrop Hook Dangle Earrings - Earrings](https://www.etsy.com/listing/1345941356/925-sterling-silver-swarovski-cristal)

Accessories

[Flower wedding hair comb. Pearl bridal hair comb. Gold wedding hair piece. Prom hair jewelry. Flower hair comb SLcomb1050g](https://www.etsy.com/listing/1877782957/flower-wedding-hair-comb-pearl-bridal)

Shopping

[Nicolas Cage Quote - US](https://www.etsy.com/market/nicolas_cage_quote)

Loading


There was a problem loading the content


Try again

Yes! Send me exclusive offers, unique gift ideas, and personalized tips for shopping and selling on Etsy.

Enter your email

Subscribe


Loading


Captcha failed to load. Try using a different browser or disabling ad blockers.

Please enter a valid email address.


Looks like you already have an account! Please [Log in](https://www.etsy.com/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1128864550%2Fbeeswax-pinecone-candle-pure-beeswax%3Famp%253Bclick_sum%3D85dadfd5%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bsts%3D1&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc2MjgyMzk0NTpmNGEyZWMzYWZmYmQxZWZkY2ZjN2M5ZDJjMzJhOTlhNw==) to subscribe.


You've already signed up for some newsletters, but you haven't confirmed your address. [Register](https://www.etsy.com/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1128864550%2Fbeeswax-pinecone-candle-pure-beeswax%3Famp%253Bclick_sum%3D85dadfd5%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bsts%3D1) to confirm your address.


You've been successfully signed up!


Great! We've sent you an email to confirm your subscription.


There was a problem subscribing you to this newsletter.


Etsy is powered by 100% renewable electricity.


Etsy’s 100% renewable electricity commitment includes the electricity used by the data centers that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsy’s global offices and employees working remotely from home in the US.


### Shop

Shop


- [Gift cards](https://www.etsy.com/giftcards?ref=ftr)
- [Etsy Registry](https://www.etsy.com/registry?ref=ftr)
- [Sitemap](https://www.etsy.com/categories)
- [Etsy blog](https://www.etsy.com/blog/en/?ref=ftr)
- [Etsy United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)
- [Etsy Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)
- [Etsy Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA)

### Sell

Sell


- [Sell on Etsy](https://www.etsy.com/sell?ref=ftr)
- [Teams](https://community.etsy.com/pages/etsy-teams/)
- [Forums](https://community.etsy.com/feed/)
- [Affiliates & Creators](https://www.etsy.com/affiliates?ref=ftr)

### About

About


- [Etsy, Inc.](https://www.etsy.com/about?ref=ftr)
- [Policies](https://www.etsy.com/legal?ref=ftr)
- [Investors](https://investors.etsy.com/)
- [Careers](https://www.etsy.com/careers?ref=ftr)
- [Press](https://www.etsy.com/press?ref=ftr)
- [Impact](https://www.etsy.com/impact?ref=ftr)

### Help

Help


- [Help Center](https://www.etsy.com/help?ref=ftr)
- [Privacy settings](https://www.etsy.com/listing/1128864550/beeswax-pinecone-candle-pure-beeswax?amp;click_sum=85dadfd5&amp;sr_prefetch=1&amp;pf_from=search&amp;ref=search2_top_narrowing_intent_modules_high_craftsmanship-3&amp;sts=1#)

- [Instagram](https://www.etsy.com/social-tracking?network=instagram)
- [Facebook](https://www.etsy.com/social-tracking?network=facebook)
- [Pinterest](https://www.etsy.com/social-tracking?network=pinterest)
- [Youtube](https://www.etsy.com/social-tracking?network=youtube)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[Download the Etsy App](https://etsy.app.link/d7nDUdp49V)

[US  United States   \|   English (US)   \|   $ (USD)](https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F1128864550%2Fbeeswax-pinecone-candle-pure-beeswax%3Famp%253Bclick_sum%3D85dadfd5%26amp%253Bsr_prefetch%3D1%26amp%253Bpf_from%3Dsearch%26amp%253Bref%3Dsearch2_top_narrowing_intent_modules_high_craftsmanship-3%26amp%253Bsts%3D1)

© 2025 Etsy, Inc.


- [Terms of Use](https://www.etsy.com/legal/terms-of-use?ref=ftr)
- [Privacy](https://www.etsy.com/legal/privacy/?ref=ftr)
- [Interest-based ads](https://www.etsy.com/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services)
- [Local Shops](https://www.etsy.com/search/shops)
- Regions







Regions Etsy does business in:









[Australia](https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU)



[Austria](https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT)



[Belgium](https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE)



[Canada](https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA)



[Canada (French)](https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA)



[Denmark](https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK)



[Finland](https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI)







[France](https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR)



[Germany](https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE)



[Hong Kong](https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK)



[India](https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN)



[Ireland](https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE)



[Israel](https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL)



[Italy](https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT)







[Japan](https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP)



[Mexico](https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX)



[New Zealand](https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ)



[Norway](https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO)



[Poland](https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL)



[Portugal](https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT)



[Singapore](https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG)







[Spain](https://www.etsy.com/es?locale_override=EUR%7Ces%7CES)



[Sweden](https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE)



[Switzerland](https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH)



[The Netherlands](https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL)



[United Kingdom](https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB)



[United States](https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS)










Got it


## Update your settings

Set where you live, what language you speak, and the currency you use. [Learn more.](https://www.etsy.com/help/article/493)

Cancel


Loading


Save


Loading


# Your Etsy Privacy Settings

In order to give you the best experience, we use cookies and similar technologies for performance, analytics, personalization, advertising, and to help our site function. Want to know more? Read our [Cookie Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies). You can change your preferences any time in your Privacy Settings.

Update settings


Essential Cookies Only

Accept All Cookies

### Privacy Settings

Etsy uses cookies and similar technologies to give you a better experience, enabling things like:

- basic site functions
- ensuring secure, safe transactions
- secure account login
- remembering account, browser, and regional preferences
- remembering privacy and security settings
- analysing site traffic and usage
- personalized search, content, and recommendations
- helping sellers understand their audience
- showing relevant, targeted ads on and off Etsy

Detailed information can be found in Etsy’s [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies-and-tracking-technologies) and our [Privacy Policy](https://www.etsy.com/legal/privacy).

## Required Cookies & Technologies

Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.

Always on

## Site Customization

Cookies and similar technologies are used to improve your experience, to do things like:

- remember your login, general, and regional preferences
- personalize content, search, recommendations, and offers

Without these technologies, things like personalized recommendations, your account preferences, or localisation may not work correctly. Find out more in our [Cookies & Similar Technologies Policy.](https://www.etsy.com/legal/cookies-and-tracking-technologies)

On


## Personalized Advertising

To enable personalized advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information they’ve collected about you. Turning off the personalized advertising setting won’t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.

Personalized advertising may be considered a “sale” or “sharing” of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalized advertising allows you to exercise your right to opt out. Learn more in our [Privacy Policy.](https://www.etsy.com/legal/privacy/), [Help Center](https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising), and [Cookies & Similar Technologies Policy](https://www.etsy.com/legal/cookies).

Off


Saved

Done

## Shop policies for KlineHoneyBeeFarm

### Returns & exchanges

See item details for return and exchange eligibility.


### Cancellations

Cancellations: accepted

Request a cancellation: within 4 hours of purchase

### Payments

Secure options


PaypalVisaMastercardDiscoverApple PayKlarnaGiftcard

Accepts Etsy Gift Cards and Etsy Credits


Etsy keeps your payment information secure. Etsy shops never receive your credit card information.


## What’s wrong with this listing?

### Add more details

### Share more specifics to help us review this item and protect our marketplace.

Choose a reason…There’s a problem with my orderIt uses my intellectual property without permissionI don’t think it meets Etsy’s policiesChoose a reason…

The first thing you should do is contact the seller directly.

If you’ve already done that, your item hasn’t arrived, or it’s not as described, you can report that to Etsy by opening a case.

[Report a problem with an order](https://www.etsy.com/help/article/5307)

We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.

If you’d like to file an allegation of infringement, you’ll need to follow the process described in our [Copyright and Intellectual Property Policy](https://www.etsy.com/legal/ip).

[Review how we define handmade, vintage and supplies](https://www.etsy.com/legal/sellers#allowed)

[See a list of prohibited items and materials](https://www.etsy.com/legal/prohibited)

[Read our mature content policy](https://www.etsy.com/legal/policy/listing-mature-content-correctly/242665462117)

Tell us why you're reporting this item

It's not handmade, vintage, or craft supplies

It's pornographic

It's hate speech or harassment

It's a threat to minor safety

It promotes violence or self-harm

It's dangerous or hazardous

It's violating a specific law or regulation

It violates a policy that's not listed here

Please choose a reason

Include anything else we should know about this item

Make sure to add more details.


Add more details, including a law or regulation name (10 characters min).


By submitting this report, you confirm the information and claims in this form are accurate.


Go back


Next

Submit report


Click to zoom

- ![May include: Four yellow beeswax pine cone candles on a wooden surface. The candles are different sizes and shapes. The candles are a natural yellow color and have a rough texture. The candles are a popular choice for home decor and aromatherapy.](https://i.etsystatic.com/6767952/r/il/f0a1d9/3540879102/il_300x300.3540879102_i2z7.jpg)
- ![May include: A yellow beeswax candle shaped like a pine cone. The candle has a white wick and is sitting on a wooden surface.](https://i.etsystatic.com/6767952/r/il/8e0f1c/3588518397/il_300x300.3588518397_jdg6.jpg)
- ![May include: A small, yellow beeswax candle shaped like a pine cone with a white wick. The candle is sitting on a wooden surface.](https://i.etsystatic.com/6767952/r/il/9ff9ff/3588518935/il_300x300.3588518935_sys9.jpg)

- ![](https://i.etsystatic.com/iap/e1adac/6486516584/iap_640x640.6486516584_t3qhfcwj.jpg?version=0)

5 out of 5 stars

- Size:

Small


These pure beeswax pinecone candles are even even more adorable in person & are so fragrant!

Dec 6, 2024


[Leah](https://www.etsy.com/people/uxcs6eh9)

Purchased item:

[![Beeswax Pinecone Candle ~ Pure Beeswax Candles from Beekeepers Hive](https://i.etsystatic.com/6767952/r/il/f0a1d9/3540879102/il_170x135.3540879102_i2z7.jpg)\\
\\
Beeswax Pinecone Candle ~ Pure Beeswax Candles from Beekeepers Hive\\
\\
$3.49](https://www.etsy.com/listing/1128864550/beeswax-pinecone-candle-pure-beeswax?ref=ap-listing)

Purchased item:

[![Beeswax Pinecone Candle ~ Pure Beeswax Candles from Beekeepers Hive](https://i.etsystatic.com/6767952/r/il/f0a1d9/3540879102/il_170x135.3540879102_i2z7.jpg)\\
\\
Beeswax Pinecone Candle ~ Pure Beeswax Candles from Beekeepers Hive\\
\\
$3.49](https://www.etsy.com/listing/1128864550/beeswax-pinecone-candle-pure-beeswax?ref=ap-listing)

- ![](https://i.etsystatic.com/iap/cae1b3/4495671543/iap_640x640.4495671543_fztaym57.jpg?version=0)

5 out of 5 stars

- Size:

Small


These are perfect! Smell amazing. Tiny works of art.

![](https://i.etsystatic.com/iusa/a64543/66302979/iusa_75x75.66302979_8gny.jpg?version=0)

Dec 19, 2022


[Kelly B](https://www.etsy.com/people/kellyinlaos)

Purchased item:

[![Beeswax Pinecone Candle ~ Pure Beeswax Candles from Beekeepers Hive](https://i.etsystatic.com/6767952/r/il/f0a1d9/3540879102/il_170x135.3540879102_i2z7.jpg)\\
\\
Beeswax Pinecone Candle ~ Pure Beeswax Candles from Beekeepers Hive\\
\\
$3.49](https://www.etsy.com/listing/1128864550/beeswax-pinecone-candle-pure-beeswax?ref=ap-listing)

Purchased item:

[![Beeswax Pinecone Candle ~ Pure Beeswax Candles from Beekeepers Hive](https://i.etsystatic.com/6767952/r/il/f0a1d9/3540879102/il_170x135.3540879102_i2z7.jpg)\\
\\
Beeswax Pinecone Candle ~ Pure Beeswax Candles from Beekeepers Hive\\
\\
$3.49](https://www.etsy.com/listing/1128864550/beeswax-pinecone-candle-pure-beeswax?ref=ap-listing)